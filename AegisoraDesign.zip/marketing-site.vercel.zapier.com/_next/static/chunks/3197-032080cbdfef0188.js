"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3197], {
        39917: (e, t, n) => {
            n.d(t, {
                l: () => function e(t, n = " ", E = {}) {
                    if (!t || !t.content || !Array.isArray(t.content)) return "";
                    let a = t;
                    return t.nodeType === r.nA.DOCUMENT && E.stripEmptyTrailingParagraph && (a = r._$.stripEmptyTrailingParagraphFromDocument(t)), a.content.reduce((t, i, l) => {
                        let s;
                        if (r._$.isText(i)) s = i.value;
                        else if ((r._$.isBlock(i) || r._$.isInline(i)) && !(s = e(i, n, E)).length) return t;
                        let o = a.content[l + 1];
                        return t + s + (o && r._$.isBlock(o) ? n : "")
                    }, "")
                }
            });
            var r = n(88505)
        },
        84593: (e, t, n) => {
            n.d(t, {
                i: () => o
            });
            var r = n(92594),
                E = n(88505);
            let a = {
                    [E.nA.DOCUMENT]: (e, t) => t,
                    [E.nA.PARAGRAPH]: (e, t) => r.createElement("p", null, t),
                    [E.nA.HEADING_1]: (e, t) => r.createElement("h1", null, t),
                    [E.nA.HEADING_2]: (e, t) => r.createElement("h2", null, t),
                    [E.nA.HEADING_3]: (e, t) => r.createElement("h3", null, t),
                    [E.nA.HEADING_4]: (e, t) => r.createElement("h4", null, t),
                    [E.nA.HEADING_5]: (e, t) => r.createElement("h5", null, t),
                    [E.nA.HEADING_6]: (e, t) => r.createElement("h6", null, t),
                    [E.nA.EMBEDDED_ENTRY]: (e, t) => r.createElement("div", null, t),
                    [E.nA.EMBEDDED_RESOURCE]: (e, t) => r.createElement("div", null, t),
                    [E.nA.UL_LIST]: (e, t) => r.createElement("ul", null, t),
                    [E.nA.OL_LIST]: (e, t) => r.createElement("ol", null, t),
                    [E.nA.LIST_ITEM]: (e, t) => r.createElement("li", null, t),
                    [E.nA.QUOTE]: (e, t) => r.createElement("blockquote", null, t),
                    [E.nA.HR]: () => r.createElement("hr", null),
                    [E.nA.TABLE]: (e, t) => r.createElement("table", null, r.createElement("tbody", null, t)),
                    [E.nA.TABLE_ROW]: (e, t) => r.createElement("tr", null, t),
                    [E.nA.TABLE_HEADER_CELL]: (e, t) => r.createElement("th", null, t),
                    [E.nA.TABLE_CELL]: (e, t) => r.createElement("td", null, t),
                    [E.XD.ASSET_HYPERLINK]: e => l(E.XD.ASSET_HYPERLINK, e),
                    [E.XD.ENTRY_HYPERLINK]: e => l(E.XD.ENTRY_HYPERLINK, e),
                    [E.XD.RESOURCE_HYPERLINK]: e => s(E.XD.RESOURCE_HYPERLINK, e),
                    [E.XD.EMBEDDED_ENTRY]: e => l(E.XD.EMBEDDED_ENTRY, e),
                    [E.XD.EMBEDDED_RESOURCE]: (e, t) => s(E.XD.EMBEDDED_RESOURCE, e),
                    [E.XD.HYPERLINK]: (e, t) => r.createElement("a", {
                        href: e.data.uri
                    }, t)
                },
                i = {
                    [E.j7.BOLD]: e => r.createElement("b", null, e),
                    [E.j7.ITALIC]: e => r.createElement("i", null, e),
                    [E.j7.UNDERLINE]: e => r.createElement("u", null, e),
                    [E.j7.CODE]: e => r.createElement("code", null, e),
                    [E.j7.SUPERSCRIPT]: e => r.createElement("sup", null, e),
                    [E.j7.SUBSCRIPT]: e => r.createElement("sub", null, e),
                    [E.j7.STRIKETHROUGH]: e => r.createElement("s", null, e)
                };

            function l(e, t) {
                return r.createElement("span", {
                    key: t.data.target.sys.id
                }, "type: ", t.nodeType, " id: ", t.data.target.sys.id)
            }

            function s(e, t) {
                return r.createElement("span", {
                    key: t.data.target.sys.urn
                }, "type: ", t.nodeType, " urn: ", t.data.target.sys.urn)
            }

            function o(e, t = {}) {
                if (!e) return null;
                let n = e;
                return t.stripEmptyTrailingParagraph && (n = E._$.stripEmptyTrailingParagraphFromDocument(e)),
                    function e(t, n) {
                        let {
                            renderNode: a,
                            renderMark: i,
                            renderText: l,
                            preserveWhitespace: s
                        } = n;
                        if (E._$.isText(t)) {
                            let e = l ? l(t.value) : t.value;
                            if (s && !l) {
                                let t = (e = e.replace(/ {2,}/g, e => "\xa0".repeat(e.length))).split("\n"),
                                    n = [];
                                t.forEach((e, E) => {
                                    n.push(e), E !== t.length - 1 && n.push(r.createElement("br", null))
                                }), e = n
                            }
                            return t.marks.reduce((e, t) => i[t.type] ? i[t.type](e) : e, e)
                        } {
                            var o;
                            let E = (o = t.content, o.map((t, E) => {
                                var a;
                                return a = e(t, n), (0, r.isValidElement)(a) && null === a.key ? (0, r.cloneElement)(a, {
                                    key: E
                                }) : a
                            }));
                            return t.nodeType && a[t.nodeType] ? a[t.nodeType](t, E) : r.createElement(r.Fragment, null, E)
                        }
                    }(n, {
                        renderNode: { ...a,
                            ...t.renderNode
                        },
                        renderMark: { ...i,
                            ...t.renderMark
                        },
                        renderText: t.renderText,
                        preserveWhitespace: t.preserveWhitespace
                    })
            }
        },
        88505: (e, t, n) => {
            n.d(t, {
                nA: () => E,
                XD: () => a,
                j7: () => i,
                _$: () => r
            });
            var r = {};
            n.r(r), n.d(r, {
                isBlock: () => u,
                isEmptyParagraph: () => p,
                isInline: () => h,
                isText: () => D,
                stripEmptyTrailingParagraphFromDocument: () => _
            });
            var E = function(e) {
                    return e.DOCUMENT = "document", e.PARAGRAPH = "paragraph", e.HEADING_1 = "heading-1", e.HEADING_2 = "heading-2", e.HEADING_3 = "heading-3", e.HEADING_4 = "heading-4", e.HEADING_5 = "heading-5", e.HEADING_6 = "heading-6", e.OL_LIST = "ordered-list", e.UL_LIST = "unordered-list", e.LIST_ITEM = "list-item", e.HR = "hr", e.QUOTE = "blockquote", e.EMBEDDED_ENTRY = "embedded-entry-block", e.EMBEDDED_ASSET = "embedded-asset-block", e.EMBEDDED_RESOURCE = "embedded-resource-block", e.TABLE = "table", e.TABLE_ROW = "table-row", e.TABLE_CELL = "table-cell", e.TABLE_HEADER_CELL = "table-header-cell", e
                }({}),
                a = function(e) {
                    return e.ASSET_HYPERLINK = "asset-hyperlink", e.EMBEDDED_ENTRY = "embedded-entry-inline", e.EMBEDDED_RESOURCE = "embedded-resource-inline", e.ENTRY_HYPERLINK = "entry-hyperlink", e.HYPERLINK = "hyperlink", e.RESOURCE_HYPERLINK = "resource-hyperlink", e
                }({}),
                i = function(e) {
                    return e.BOLD = "bold", e.ITALIC = "italic", e.UNDERLINE = "underline", e.CODE = "code", e.SUPERSCRIPT = "superscript", e.SUBSCRIPT = "subscript", e.STRIKETHROUGH = "strikethrough", e
                }({});
            let l = [E.PARAGRAPH, E.HEADING_1, E.HEADING_2, E.HEADING_3, E.HEADING_4, E.HEADING_5, E.HEADING_6, E.OL_LIST, E.UL_LIST, E.HR, E.QUOTE, E.EMBEDDED_ENTRY, E.EMBEDDED_ASSET, E.EMBEDDED_RESOURCE, E.TABLE],
                s = [E.PARAGRAPH, E.HEADING_1, E.HEADING_2, E.HEADING_3, E.HEADING_4, E.HEADING_5, E.HEADING_6, E.OL_LIST, E.UL_LIST, E.HR, E.QUOTE, E.EMBEDDED_ENTRY, E.EMBEDDED_ASSET, E.EMBEDDED_RESOURCE];
            E.TABLE, E.TABLE_ROW, E.TABLE_CELL, E.TABLE_HEADER_CELL, E.HR, E.EMBEDDED_ENTRY, E.EMBEDDED_ASSET, E.EMBEDDED_RESOURCE;
            let o = {
                    [E.OL_LIST]: [E.LIST_ITEM],
                    [E.UL_LIST]: [E.LIST_ITEM],
                    [E.LIST_ITEM]: s,
                    [E.QUOTE]: [E.PARAGRAPH],
                    [E.TABLE]: [E.TABLE_ROW],
                    [E.TABLE_ROW]: [E.TABLE_CELL, E.TABLE_HEADER_CELL],
                    [E.TABLE_CELL]: [E.PARAGRAPH, E.UL_LIST, E.OL_LIST],
                    [E.TABLE_HEADER_CELL]: [E.PARAGRAPH]
                },
                A = [E.HEADING_1, E.HEADING_2, E.HEADING_3, E.HEADING_4, E.HEADING_5, E.HEADING_6];

            function c(e, t) {
                for (let n of Object.keys(e))
                    if (t === e[n]) return !0;
                return !1
            }

            function h(e) {
                return c(a, e.nodeType)
            }

            function u(e) {
                return c(E, e.nodeType)
            }

            function D(e) {
                return "text" === e.nodeType
            }

            function p(e) {
                if (e.nodeType !== E.PARAGRAPH || 1 !== e.content.length) return !1;
                let t = e.content[0];
                return "text" === t.nodeType && "" === t.value
            }

            function _(e) {
                return !(null != e && "object" == typeof e && "content" in e && Array.isArray(e.content)) || e.content.length < 2 ? e : p(e.content[e.content.length - 1]) ? { ...e,
                    content: e.content.slice(0, -1)
                } : e
            }[E.PARAGRAPH, ...A], E.DOCUMENT, E.PARAGRAPH, E.HEADING_1, E.HEADING_2, E.HEADING_3, E.HEADING_4, E.HEADING_5, E.HEADING_6, E.OL_LIST, E.UL_LIST, E.LIST_ITEM, E.HR, E.QUOTE, E.EMBEDDED_ENTRY, E.EMBEDDED_ASSET, a.HYPERLINK, a.ENTRY_HYPERLINK, a.ASSET_HYPERLINK, a.EMBEDDED_ENTRY, i.BOLD, i.CODE, i.ITALIC, i.UNDERLINE, E.DOCUMENT, E.PARAGRAPH;
            let T = ({
                path: e,
                property: t,
                typeName: n,
                value: r
            }) => ({
                details: `The type of "${t}" is incorrect, expected type: ${n}`,
                name: "type",
                path: e.toArray(),
                type: n,
                value: r
            });
            class L {
                obj;
                path;
                _errors = [];
                constructor(e, t) {
                    this.obj = e, this.path = t
                } catch = (...e) => {
                    this._errors.push(...e)
                };
                get errors() {
                    let e = e => JSON.stringify({
                        details: e.details,
                        path: e.path
                    });
                    return this._errors.filter((t, n) => this._errors.findIndex(n => e(t) === e(n)) === n)
                }
                exists = e => e in this.obj || (this.catch((({
                    property: e,
                    path: t
                }) => ({
                    details: `The property "${e}" is required here`,
                    name: "required",
                    path: t.toArray()
                }))({
                    property: e,
                    path: this.path.of(e)
                })), !1);
                object = e => {
                    let t = e ? this.obj[e] : this.obj;
                    if (e && !this.exists(e)) return !1;
                    if ("object" == typeof t && !Array.isArray(t) && null !== t) return !0;
                    let n = e ? this.path.of(e) : this.path,
                        r = e ? ? this.path.last() ? ? "value";
                    return this.catch(T({
                        typeName: "Object",
                        property: r,
                        path: n,
                        value: t
                    })), !1
                };
                string = e => {
                    let t = this.obj[e];
                    return (!e || !!this.exists(e)) && ("string" == typeof t || (this.catch(T({
                        typeName: "String",
                        property: e,
                        path: this.path.of(e),
                        value: t
                    })), !1))
                };
                number = (e, t) => {
                    let n = this.obj[e];
                    return !!t && !(e in this.obj) || !!this.exists(e) && (!("number" != typeof n || Number.isNaN(n)) || (this.catch(T({
                        typeName: "Number",
                        property: e,
                        path: this.path.of(e),
                        value: n
                    })), !1))
                };
                array = e => {
                    let t = this.obj[e];
                    return (!e || !!this.exists(e)) && (!!Array.isArray(t) || (this.catch(T({
                        typeName: "Array",
                        property: e,
                        path: this.path.of(e),
                        value: t
                    })), !1))
                };
                enum = (e, t) => {
                    let n = this.obj[e];
                    return !!("string" == typeof n && t.includes(n)) || (this.catch((({
                        expected: e,
                        value: t,
                        path: n
                    }) => ({
                        details: "Value must be one of expected values",
                        name: "in",
                        expected: [...e].sort(),
                        path: n.toArray(),
                        value: t
                    }))({
                        expected: t,
                        value: n,
                        path: this.path.of(e)
                    })), !1)
                };
                empty = e => {
                    if (!this.array(e)) return !1;
                    let t = this.obj[e];
                    return 0 === t.length || (this.catch((({
                        max: e,
                        value: t,
                        path: n
                    }) => ({
                        name: "size",
                        max: e,
                        path: n.toArray(),
                        details: `Size must be at most ${e}`,
                        value: t
                    }))({
                        max: 0,
                        value: t,
                        path: this.path.of(e)
                    })), !1)
                };
                minLength = (e, t) => {
                    if (!this.array(e)) return !1;
                    let n = this.obj[e];
                    return n.length >= t || (this.catch((({
                        min: e,
                        value: t,
                        path: n
                    }) => ({
                        name: "size",
                        min: e,
                        path: n.toArray(),
                        details: `Size must be at least ${e}`,
                        value: t
                    }))({
                        min: t,
                        value: n,
                        path: this.path.of(e)
                    })), !1)
                };
                noAdditionalProperties = e => {
                    let t = Object.keys(this.obj).sort().filter(t => !e.includes(t));
                    return t.forEach(e => this.catch((({
                        property: e,
                        path: t
                    }) => ({
                        details: `The property "${e}" is not expected`,
                        name: "unexpected",
                        path: t.toArray()
                    }))({
                        property: e,
                        path: this.path.of(e)
                    }))), 0 === t.length
                };
                each = (e, t) => {
                    if (!this.array(e)) return;
                    let n = this.obj[e],
                        r = !1;
                    n.forEach((n, E) => {
                        if (r) return;
                        let a = t(n, this.path.of(e).of(E));
                        a.length > 0 && (r = !0), this.catch(...a)
                    })
                }
            }
            let R = [];
            class d {
                contentRule;
                validateData;
                constructor(e, t) {
                    this.contentRule = e, this.validateData = t
                }
                assert(e, t) {
                    let n = new L(e, t);
                    if (!n.object()) return n.errors;
                    n.noAdditionalProperties(["nodeType", "data", "content"]);
                    let {
                        nodeTypes: r,
                        min: E = 0
                    } = Array.isArray(this.contentRule) ? {
                        nodeTypes: this.contentRule
                    } : this.contentRule(e, t);
                    if (0 === r.length && E > 0) throw Error(`Invalid content rule. Cannot have enforce a 'min' of ${E} with no nodeTypes`);
                    if (n.minLength("content", E), 0 === r.length ? n.empty("content") : n.each("content", (e, t) => {
                            let n = new L(e, t);
                            return n.object() && n.enum("nodeType", r), n.errors
                        }), n.object("data")) {
                        let r = this.validateData ? .(e.data, t.of("data")) ? ? [];
                        n.catch(...r)
                    }
                    return n.errors
                }
            }
            class y extends d {
                linkType;
                type;
                constructor(e, t) {
                    super(t, (e, t) => this.assertLink(e, t)), this.linkType = e, this.type = this.linkType.startsWith("Contentful:") ? "ResourceLink" : "Link"
                }
                assertLink = (e, t) => {
                    let n = new L(e, t);
                    if (n.object("target")) {
                        let r = new L(e.target.sys, t.of("target").of("sys"));
                        r.object() && (r.enum("type", [this.type]), r.enum("linkType", [this.linkType]), "Link" === this.type ? (r.string("id"), r.noAdditionalProperties(["type", "linkType", "id"])) : "ResourceLink" === this.type && (r.string("urn"), r.noAdditionalProperties(["type", "linkType", "urn"]))), n.catch(...r.errors)
                    }
                    return n.noAdditionalProperties(["target"]), n.errors
                }
            }
            class I extends d {
                constructor() {
                    super(["text"], (e, t) => this.assertLink(e, t))
                }
                assertLink = (e, t) => {
                    let n = new L(e, t);
                    return n.string("uri"), n.noAdditionalProperties(["uri"]), n.errors
                }
            }
            let N = (e, t) => new d(e, t),
                H = (e, t) => new y(e, t);
            N([...Object.values(a), "text"].sort()), N([E.LIST_ITEM]), H("Entry", R), N(() => ({
                nodeTypes: [E.PARAGRAPH],
                min: 1
            }), (e, t) => {
                let n = new L(e, t);
                return n.noAdditionalProperties(["colspan", "rowspan"]), n.number("colspan", !0), n.number("rowspan", !0), n.errors
            }), E.DOCUMENT, N(l), E.PARAGRAPH, E.HEADING_1, E.HEADING_2, E.HEADING_3, E.HEADING_4, E.HEADING_5, E.HEADING_6, E.QUOTE, N(o[E.QUOTE]), E.EMBEDDED_ENTRY, E.EMBEDDED_ASSET, H("Asset", R), E.EMBEDDED_RESOURCE, H("Contentful:Entry", R), E.HR, N(R), E.OL_LIST, E.UL_LIST, E.LIST_ITEM, N([...s].sort()), E.TABLE, N(() => ({
                nodeTypes: [E.TABLE_ROW],
                min: 1
            })), E.TABLE_ROW, N(() => ({
                nodeTypes: [E.TABLE_CELL, E.TABLE_HEADER_CELL],
                min: 1
            })), E.TABLE_CELL, E.TABLE_HEADER_CELL, a.HYPERLINK, new I, a.EMBEDDED_ENTRY, a.EMBEDDED_RESOURCE, H("Contentful:Entry", R), a.ENTRY_HYPERLINK, H("Entry", ["text"]), a.ASSET_HYPERLINK, H("Asset", ["text"]), a.RESOURCE_HYPERLINK, H("Contentful:Entry", ["text"])
        }
    }
]);