"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
            [8003], {
                18003: (e, t, n) => {
                        let r, i, o, a, s, u, c, l, d, f, p, m, g, y, v, h, b, S, _, E;
                        n.r(t), n.d(t, {
                            DEFAULT_TRACKED_RESOURCE_HEADERS: () => ns,
                            DefaultPrivacyLevel: () => t5,
                            datadogRum: () => oE
                        });
                        let w = {
                                ACTION: "action",
                                ERROR: "error",
                                LONG_TASK: "long_task",
                                VIEW: "view",
                                VIEW_UPDATE: "view_update",
                                RESOURCE: "resource",
                                VITAL: "vital"
                            },
                            C = {
                                LONG_TASK: "long-task",
                                LONG_ANIMATION_FRAME: "long-animation-frame"
                            },
                            A = {
                                INITIAL_LOAD: "initial_load",
                                ROUTE_CHANGE: "route_change",
                                SESSION_RENEWAL: "session_renewal",
                                BF_CACHE: "bf_cache"
                            },
                            R = {
                                CLICK: "click",
                                CUSTOM: "custom"
                            },
                            T = {
                                RAGE_CLICK: "rage_click",
                                ERROR_CLICK: "error_click",
                                DEAD_CLICK: "dead_click"
                            },
                            k = {
                                DURATION: "duration",
                                OPERATION_STEP: "operation_step"
                            };

                        function O(e, t) {
                            t.lastIndex = 0;
                            let n = t.exec(e);
                            if (!n) return;
                            let [r, i] = n;
                            return i || r
                        }
                        let I = /[a-zA-Z_$]/,
                            x = /[a-zA-Z0-9_$]/,
                            N = /[0-9]/,
                            M = /[a-fA-F0-9]/,
                            L = {
                                0: () => !1,
                                1: () => !1,
                                2: e => I.test(e),
                                3: e => x.test(e),
                                4: e => "." === e,
                                5: e => "[" === e,
                                6: e => "]" === e,
                                7: e => N.test(e),
                                8: e => "'\"".includes(e),
                                9: (e, t) => e === t.quote,
                                10: () => !0,
                                11: e => "\\" === e,
                                12: (e, t) => void 0 === t.escapeSequence ? `${t.quote}/\\bfnrtu`.includes(e) : !!t.escapeSequence.startsWith("u") && t.escapeSequence.length < 5 && M.test(e)
                            },
                            D = {
                                0: [2, 5],
                                1: [],
                                2: [3, 4, 5, 1],
                                3: [3, 4, 5, 1],
                                4: [2],
                                5: [8, 7],
                                6: [4, 5, 1],
                                7: [7, 6],
                                8: [11, 9, 10],
                                9: [6],
                                10: [11, 9, 10],
                                11: [12],
                                12: [12, 11, 9, 10]
                            },
                            P = [2, 3, 7, 10],
                            U = [4, 5, 6],
                            $ = {
                                '"': '"',
                                "'": "'",
                                "/": "/",
                                "\\": "\\",
                                b: "\b",
                                f: "\f",
                                n: "\n",
                                r: "\r",
                                t: "	"
                            };

                        function V() {
                            return new Date().getTime()
                        }

                        function q() {
                            return V()
                        }

                        function F(e) {
                            return "number" != typeof e ? e : Math.round(1e6 * e)
                        }

                        function H() {
                            return performance.now()
                        }

                        function G() {
                            return {
                                relative: H(),
                                timeStamp: q()
                            }
                        }

                        function j() {
                            return {
                                relative: 0,
                                timeStamp: W()
                            }
                        }

                        function K(e) {
                            return {
                                relative: e,
                                timeStamp: function(e) {
                                    let t = V() - performance.now();
                                    return t > W() ? Math.round(t + e) : Math.round(W() + e)
                                }(e)
                            }
                        }

                        function B(e) {
                            return {
                                relative: e - W(),
                                timeStamp: e
                            }
                        }

                        function W() {
                            return void 0 === r && (r = performance.timing ? .navigationStart ? ? performance.timeOrigin), r
                        }

                        function z(e) {
                            return null === e ? "null" : Array.isArray(e) ? "array" : typeof e
                        }

                        function Y(e) {
                            return "object" === z(e)
                        }

                        function J(e) {
                            return "string" == typeof e || e instanceof RegExp || "function" == typeof e
                        }
                        let X = (e, t) => "__proto__" === e ? void 0 : t;

                        function Z(e) {
                            try {
                                return JSON.parse(e, X)
                            } catch {}
                        }

                        function Q(e) {
                            return 0 === Object.keys(e).length
                        }

                        function ee(e, t) {
                            let n = {};
                            for (let r of Object.keys(e)) n[r] = t(e[r]);
                            return n
                        }

                        function et(e) {
                            return e ? (parseInt(e, 10) ^ 16 * Math.random() >> parseInt(e, 10) / 4).toString(16) : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, et)
                        }
                        let en = /(\S+?)\s*=\s*(.*?)(?:;|$)/g;

                        function er(e, t) {
                            for (en.lastIndex = 0;;) {
                                let n = en.exec(e);
                                if (n) {
                                    if (n[1] === t) return n[2]
                                } else break
                            }
                        }

                        function ei(e, t, n = "") {
                            let r = e.charCodeAt(t - 1),
                                i = r >= 55296 && r <= 56319 ? t + 1 : t;
                            return e.length <= i ? e : `${e.slice(0,i)}${n}`
                        }
                        let eo = {
                            hit: "success",
                            miss: "missing",
                            error: "failure"
                        };

                        function ea(e, t) {
                            try {
                                localStorage.setItem(e, JSON.stringify(t))
                            } catch {}
                        }
                        let es = "https://docs.datadoghq.com",
                            eu = "More details:",
                            ec = {
                                log: "log",
                                debug: "debug",
                                info: "info",
                                warn: "warn",
                                error: "error"
                            },
                            el = console,
                            ed = {
                                log: el.log,
                                debug: el.debug,
                                info: el.info,
                                warn: el.warn,
                                error: el.error
                            };

                        function ef(e) {
                            return {
                                debug: ed.debug.bind(el, e),
                                log: ed.log.bind(el, e),
                                info: ed.info.bind(el, e),
                                warn: ed.warn.bind(el, e),
                                error: ed.error.bind(el, e)
                            }
                        }
                        let ep = ef("Datadog Browser SDK:"),
                            em = `${es}/real_user_monitoring/browser/troubleshooting`,
                            eg = globalThis,
                            ey = "WorkerGlobalScope" in eg,
                            ev = !1;

                        function eh(e) {
                            ev = e
                        }
                        let eb = function(e, t) {
                                function n(e) {
                                    return function(...t) {
                                        return r(e, this, t)
                                    }
                                }

                                function r(e, t, n) {
                                    try {
                                        return e.apply(t, n)
                                    } catch (e) {
                                        i(e)
                                    }
                                }

                                function i(n) {
                                    let r = t => {
                                        ev && e.error("[MONITOR]", t)
                                    };
                                    r(n);
                                    try {
                                        t(n)
                                    } catch (e) {
                                        r(e)
                                    }
                                }
                                return {
                                    monitored: function(e, t, r) {
                                        r.value = n(r.value)
                                    },
                                    monitor: n,
                                    callMonitored: r,
                                    monitorError: i
                                }
                            }(ef("Datadog SDK:"), e => i ? .(e)),
                            eS = eb.monitor,
                            e_ = eb.callMonitored,
                            eE = eb.monitorError;

                        function ew(e) {
                            let t = eg.queueMicrotask;
                            "function" == typeof t ? t(eS(e)) : Promise.resolve().then(eS(e))
                        }
                        var eC = class {
                            constructor(e) {
                                this.onFirstSubscribe = e, this.observers = []
                            }
                            subscribe(e) {
                                return this.addObserver(e), {
                                    unsubscribe: () => this.removeObserver(e)
                                }
                            }
                            notify(e) {
                                this.observers.forEach(t => t(e))
                            }
                            addObserver(e) {
                                this.observers.push(e), 1 === this.observers.length && this.onFirstSubscribe && (this.onLastUnsubscribe = this.onFirstSubscribe(this) || void 0)
                            }
                            removeObserver(e) {
                                this.observers = this.observers.filter(t => e !== t), !this.observers.length && this.onLastUnsubscribe && this.onLastUnsubscribe()
                            }
                        };

                        function eA(...e) {
                            return new eC(t => {
                                let n = e.map(e => e.subscribe(e => t.notify(e)));
                                return () => n.forEach(e => e.unsubscribe())
                            })
                        }
                        var eR = class extends eC {
                            constructor(e, t) {
                                super(), this.maxBufferSize = e, this.onDrop = t, this.buffer = [], this.droppedCount = 0
                            }
                            notify(e) {
                                this.buffer.push(e), this.buffer.length > this.maxBufferSize && (this.buffer.shift(), this.droppedCount++), super.notify(e)
                            }
                            subscribe(e) {
                                let t = !1;
                                return ew(() => {
                                    for (let n of this.buffer) {
                                        if (t) return;
                                        e(n)
                                    }
                                    t || this.addObserver(e)
                                }), {
                                    unsubscribe: () => {
                                        t = !0, this.removeObserver(e)
                                    }
                                }
                            }
                            unbuffer() {
                                ew(() => {
                                    this.droppedCount > 0 && this.onDrop && this.onDrop(this.droppedCount), this.maxBufferSize = this.buffer.length = 0
                                })
                            }
                        };
                        let eT = function(e) {
                                return e.SESSION_REPLAY_RECORD_CANVAS = "session_replay_record_canvas", e.TRACK_INTAKE_REQUESTS = "track_intake_requests", e.TRACK_WEBSOCKETS = "track_websockets", e
                            }({}),
                            ek = new Set;

                        function eO(e, t) {
                            let n;
                            return eg.Zone && "function" == typeof eg.Zone.__symbol__ && (n = e[eg.Zone.__symbol__(t)]), n || (n = e[t]), n
                        }

                        function eI(e, t) {
                            return eO(eg, "setTimeout")(eS(e), t)
                        }

                        function ex(e) {
                            eO(eg, "clearTimeout")(e)
                        }

                        function eN(e, t) {
                            return eO(eg, "setInterval")(eS(e), t)
                        }

                        function eM(e) {
                            eO(eg, "clearInterval")(e)
                        }

                        function eL(e, t, n) {
                            let r, i, o = n ? .leading === void 0 || n.leading,
                                a = n ? .trailing === void 0 || n.trailing,
                                s = !1;
                            return {
                                throttled: (...n) => {
                                    if (s) {
                                        r = n;
                                        return
                                    }
                                    o ? e(...n) : r = n, s = !0, i = eI(() => {
                                        a && r && e(...r), s = !1, r = void 0
                                    }, t)
                                },
                                cancel: () => {
                                    ex(i), s = !1, r = void 0
                                }
                            }
                        }

                        function eD() {}

                        function eP(e) {
                            let t = [],
                                n = eK(e, "stack"),
                                r = String(e);
                            if (n ? .startsWith(r) && (n = n.slice(r.length)), n && n.split("\n").forEach(e => {
                                    let n = function(e) {
                                        let t = eV.exec(e);
                                        if (!t) return;
                                        let n = t[2] ? .indexOf("native") === 0,
                                            r = t[2] ? .indexOf("eval") === 0,
                                            i = eq.exec(t[2]);
                                        return r && i && (t[2] = i[1], t[3] = i[2], t[4] = i[3]), {
                                            args: n ? [t[2]] : [],
                                            column: t[4] ? +t[4] : void 0,
                                            func: t[1] || "?",
                                            line: t[3] ? +t[3] : void 0,
                                            url: n ? void 0 : t[2]
                                        }
                                    }(e) || function(e) {
                                        let t = eF.exec(e);
                                        if (t) return {
                                            args: [],
                                            column: t[4] ? +t[4] : void 0,
                                            func: t[1] || "?",
                                            line: t[3] ? +t[3] : void 0,
                                            url: t[2]
                                        }
                                    }(e) || function(e) {
                                        let t = eH.exec(e);
                                        if (t) return {
                                            args: [],
                                            column: t[4] ? +t[4] : void 0,
                                            func: t[1] || "?",
                                            line: +t[3],
                                            url: t[2]
                                        }
                                    }(e) || function(e) {
                                        let t = eG.exec(e);
                                        if (!t) return;
                                        let n = t[3] && t[3].indexOf(" > eval") > -1,
                                            r = ej.exec(t[3]);
                                        return n && r && (t[3] = r[1], t[4] = r[2], t[5] = void 0), {
                                            args: t[2] ? t[2].split(",") : [],
                                            column: t[5] ? +t[5] : void 0,
                                            func: t[1] || "?",
                                            line: t[4] ? +t[4] : void 0,
                                            url: t[3]
                                        }
                                    }(e);
                                    n && (!n.func && n.line && (n.func = "?"), t.push(n))
                                }), t.length > 0 && function() {
                                    if (void 0 !== o) return o;
                                    class e extends Error {
                                        constructor() {
                                            super(), this.name = "Error"
                                        }
                                    }
                                    let [t, n] = [e, Error].map(e => new e);
                                    return o = eW(Object.getPrototypeOf(t)) && n.stack !== t.stack
                                }() && e instanceof Error) {
                                let n = [],
                                    r = e;
                                for (;
                                    (r = Object.getPrototypeOf(r)) && eW(r);) {
                                    let e = r.constructor ? .name || "?";
                                    n.push(e)
                                }
                                for (let e = n.length - 1; e >= 0 && t[0] ? .func === n[e]; e--) t.shift()
                            }
                            return {
                                message: eK(e, "message"),
                                name: eK(e, "name"),
                                stack: t
                            }
                        }
                        let eU = "((?:blob|native|eval|<anonymous>|[a-zA-Z][a-zA-Z0-9+.-]*:\\/\\/|\\w+\\.|\\/).*?)",
                            e$ = "(?::(\\d+))",
                            eV = RegExp(`^\\s*at (.*?) ?\\(${eU}${e$}?${e$}?\\)?\\s*$`, "i"),
                            eq = RegExp(`\\((\\S*)${e$}${e$}\\)`),
                            eF = RegExp(`^\\s*at\\s*(?:(.*)?(?: @))?\\s*${eU}${e$}?${e$}??\\s*$`, "i"),
                            eH = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i,
                            eG = /^\s*(.*?)(?:\((.*?)\))?(?:(?:(?:^|@)((?:file|https?|blob|chrome|webpack|resource|capacitor|\[native).*?|[^@]*bundle|\[wasm code\])(?::(\d+))?(?::(\d+))?)|@)\s*$/i,
                            ej = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;

                        function eK(e, t) {
                            return Y(e) && "string" == typeof e[t] ? e[t] : void 0
                        }
                        let eB = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?([\s\S]*)$/;

                        function eW(e) {
                            return String(e.constructor).startsWith("class ")
                        }

                        function ez(e) {
                            let t, n = Error(e);
                            return n.name = "HandlingStack", e_(() => {
                                let e = eP(n);
                                e.stack = e.stack.slice(2), t = eY(e)
                            }), t
                        }

                        function eY(e) {
                            let t = eJ(e);
                            return e.stack.forEach(e => {
                                let n = "?" === e.func ? "<anonymous>" : e.func,
                                    r = e.args && e.args.length > 0 ? `(${e.args.join(", ")})` : "",
                                    i = e.line ? `:${e.line}` : "",
                                    o = e.line && e.column ? `:${e.column}` : "";
                                t += `
  at ${n}${r} @ ${e.url}${i}${o}`
                            }), t
                        }

                        function eJ(e) {
                            return `${e.name||"Error"}: ${e.message}`
                        }

                        function eX(e, t, n) {
                            if ("object" != typeof e || null === e) return JSON.stringify(e);
                            let r = eZ(Object.prototype),
                                i = eZ(Array.prototype),
                                o = eZ(Object.getPrototypeOf(e)),
                                a = eZ(e);
                            try {
                                return JSON.stringify(e, t, n)
                            } catch {
                                return "<error: unable to serialize object>"
                            } finally {
                                r(), i(), o(), a()
                            }
                        }

                        function eZ(e) {
                            let t = e.toJSON;
                            return t ? (delete e.toJSON, () => {
                                e.toJSON = t
                            }) : eD
                        }
                        let eQ = "No stack, consider using an instance of Error";

                        function e0(e) {
                            try {
                                return e instanceof Error || "[object Error]" === Object.prototype.toString.call(e)
                            } catch {
                                return !1
                            }
                        }

                        function e1(e) {
                            let {
                                env: t,
                                service: n,
                                version: r,
                                datacenter: i,
                                sdkVersion: o,
                                variant: a
                            } = e, s = [e3("sdk_version", o ? ? "7.13.0")];
                            return t && s.push(e3("env", t)), n && s.push(e3("service", n)), r && s.push(e3("version", r)), i && s.push(e3("datacenter", i)), a && s.push(e3("variant", a)), s
                        }

                        function e3(e, t) {
                            var n;
                            let r = t ? `${e}:${t}` : e;
                            return (r.length > 200 || (n = r, RegExp("[^\\p{Ll}\\p{Lo}0-9_:./-]", "u").test(n))) && ep.warn(`Tag ${r} doesn't meet tag requirements and will be sanitized. ${eu} ${es}/getting_started/tagging/#defining-tags`), r.replace(/,/g, "_")
                        }

                        function e2(e, t) {
                            let n = eg.__ddBrowserSdkExtensionCallback;
                            n && n({
                                type: e,
                                payload: t
                            })
                        }

                        function e4() {
                            let {
                                navigator: e
                            } = eg;
                            return {
                                status: e ? .onLine ? "connected" : "not_connected",
                                interfaces: e ? .connection ? .type ? [e.connection.type] : void 0,
                                effective_type: e ? .connection ? .effectiveType
                            }
                        }
                        let e5 = function(e) {
                            return e.RECORDS = "records", e.PROFILES = "profiles", e
                        }({});

                        function e6() {
                            let e = eg.DatadogEventBridge;
                            if (e) return {
                                getCapabilities: () => JSON.parse(e.getCapabilities ? .() || "[]"),
                                getPrivacyLevel: () => e.getPrivacyLevel ? .(),
                                getIsTraceSampled: () => JSON.parse(e.getIsTraceSampled ? .() || "null"),
                                getAllowedWebViewHosts: () => JSON.parse(e.getAllowedWebViewHosts()),
                                send(t, n, r) {
                                    e.send(JSON.stringify({
                                        eventType: t,
                                        event: n,
                                        view: r ? {
                                            id: r
                                        } : void 0
                                    }))
                                }
                            }
                        }

                        function e8(e = eg.location ? .hostname) {
                            return e6() ? .getAllowedWebViewHosts().some(t => (function(e, t) {
                                if (!t.includes("*")) return e === t || e.endsWith(`.${t}`);
                                let n = t.split("*");
                                if (2 !== n.length) return ep.error(`Invalid WebView host pattern "${t}": only one wildcard (*) is supported.`), !1;
                                let [r, i] = n;
                                return e.length > r.length + i.length && e.startsWith(r) && e.endsWith(i)
                            })(e, t)) ? ? !1
                        }
                        let e7 = /[^\u0000-\u007F]/;

                        function e9(e) {
                            return e7.test(e) ? new TextEncoder().encode(e).length : e.length
                        }

                        function te(e, t) {
                            return eO(eg, "fetch")(e, t)
                        }
                        let tt = 0x1400000;

                        function tn(e, t, n, r, i, o) {
                            0 === t.transportStatus && 0 === t.queuedPayloads.size() && t.bandwidthMonitor.canHandle(e) ? tr(e, t, n, o, {
                                onSuccess: () => ti(0, t, n, r, i, o),
                                onFailure: () => {
                                    t.queuedPayloads.enqueue(e) || o.notify({
                                            type: "queue-full",
                                            bandwidth: t.bandwidthMonitor.stats(),
                                            payload: e
                                        }),
                                        function e(t, n, r, i, o) {
                                            2 === t.transportStatus && eI(() => {
                                                tr(t.queuedPayloads.first(), t, n, o, {
                                                    onSuccess: () => {
                                                        t.queuedPayloads.dequeue(), t.currentBackoffTime = 1e3, ti(1, t, n, r, i, o)
                                                    },
                                                    onFailure: () => {
                                                        t.currentBackoffTime = Math.min(6e4, 2 * t.currentBackoffTime), e(t, n, r, i, o)
                                                    }
                                                })
                                            }, t.currentBackoffTime)
                                        }(t, n, r, i, o)
                                }
                            }) : t.queuedPayloads.enqueue(e) || o.notify({
                                type: "queue-full",
                                bandwidth: t.bandwidthMonitor.stats(),
                                payload: e
                            })
                        }

                        function tr(e, t, n, r, {
                            onSuccess: i,
                            onFailure: o
                        }) {
                            t.bandwidthMonitor.add(e), n(e, n => {
                                var a;
                                t.bandwidthMonitor.remove(e), "opaque" !== (a = n).type && (0 === a.status && !navigator.onLine || 408 === a.status || 429 === a.status || a.status >= 500) ? (t.transportStatus = t.bandwidthMonitor.ongoingRequestCount > 0 ? 1 : 2, e.retry = {
                                    count: e.retry ? e.retry.count + 1 : 1,
                                    lastFailureStatus: n.status
                                }, r.notify({
                                    type: "failure",
                                    bandwidth: t.bandwidthMonitor.stats(),
                                    payload: e
                                }), o()) : (t.transportStatus = 0, r.notify({
                                    type: "success",
                                    bandwidth: t.bandwidthMonitor.stats(),
                                    payload: e
                                }), i())
                            })
                        }

                        function ti(e, t, n, r, i, o) {
                            0 === e && t.queuedPayloads.isFull() && !t.queueFullReported && (i(`Reached max ${r} events size queued for upload: ${tt/1048576}MiB`), t.queueFullReported = !0);
                            let a = t.queuedPayloads;
                            for (t.queuedPayloads = to(); a.size() > 0;) tn(a.dequeue(), t, n, r, i, o)
                        }

                        function to() {
                            let e = [];
                            return {
                                bytesCount: 0,
                                enqueue(t) {
                                    return !this.isFull() && (e.push(t), this.bytesCount += t.bytesCount, !0)
                                },
                                first: () => e[0],
                                dequeue() {
                                    let t = e.shift();
                                    return t && (this.bytesCount -= t.bytesCount), t
                                },
                                size: () => e.length,
                                isFull() {
                                    return this.bytesCount >= tt
                                }
                            }
                        }
                        let ta = !1;

                        function ts(e, t, n) {
                            te(e.build("fetch", t), {
                                method: "POST",
                                body: t.data,
                                mode: "cors"
                            }).then(eS(e => n ? .({
                                status: e.status,
                                type: e.type
                            }))).catch(eS(() => n ? .({
                                status: 0
                            })))
                        }

                        function tu(e, t) {
                            for (let n = e.length - 1; n >= 0; n -= 1) {
                                let r = e[n];
                                if (t(r, n, e)) return r
                            }
                        }

                        function tc(e) {
                            return Object.values(e)
                        }

                        function tl(e) {
                            return Object.entries(e)
                        }
                        let td = function(e) {
                            return e.BEFORE_UNLOAD = "beforeunload", e.CLICK = "click", e.DBL_CLICK = "dblclick", e.KEY_DOWN = "keydown", e.LOAD = "load", e.POP_STATE = "popstate", e.SCROLL = "scroll", e.TOUCH_START = "touchstart", e.TOUCH_END = "touchend", e.TOUCH_MOVE = "touchmove", e.VISIBILITY_CHANGE = "visibilitychange", e.PAGE_SHOW = "pageshow", e.FREEZE = "freeze", e.RESUME = "resume", e.DOM_CONTENT_LOADED = "DOMContentLoaded", e.POINTER_DOWN = "pointerdown", e.POINTER_UP = "pointerup", e.POINTER_CANCEL = "pointercancel", e.HASH_CHANGE = "hashchange", e.PAGE_HIDE = "pagehide", e.MOUSE_DOWN = "mousedown", e.MOUSE_UP = "mouseup", e.MOUSE_MOVE = "mousemove", e.FOCUS = "focus", e.BLUR = "blur", e.CONTEXT_MENU = "contextmenu", e.RESIZE = "resize", e.CHANGE = "change", e.INPUT = "input", e.PLAY = "play", e.PAUSE = "pause", e.SECURITY_POLICY_VIOLATION = "securitypolicyviolation", e.SELECTION_CHANGE = "selectionchange", e.STORAGE = "storage", e.UNHANDLED_REJECTION = "unhandledrejection", e
                        }({});

                        function tf(e, t, n, r) {
                            return tp(e, [t], n, r)
                        }

                        function tp(e, t, n, {
                            once: r,
                            capture: i,
                            passive: o
                        } = {}) {
                            let s = eS(e => {
                                    (e.isTrusted || e.__ddIsTrusted || !1 !== a) && (r && d(), n(e))
                                }),
                                u = o ? {
                                    capture: i,
                                    passive: o
                                } : i,
                                c = window.EventTarget && e instanceof EventTarget ? window.EventTarget.prototype : e,
                                l = eO(c, "addEventListener");

                            function d() {
                                let n = eO(c, "removeEventListener");
                                t.forEach(t => n.call(e, t, s, u))
                            }
                            return t.forEach(t => l.call(e, t, s, u)), {
                                stop: d
                            }
                        }

                        function tm(e, t) {
                            if (!e) return !1;
                            try {
                                return tf(e, t, eD).stop(), !0
                            } catch {
                                return !1
                            }
                        }
                        let tg = {
                            HIDDEN: "visibility_hidden",
                            UNLOADING: "before_unload",
                            PAGEHIDE: "page_hide",
                            FROZEN: "page_frozen"
                        };

                        function ty() {
                            return new eC(e => {
                                let t = eg.window;
                                if (!t) return;
                                let {
                                    stop: n
                                } = tp(t, ["visibilitychange", "freeze"], t => {
                                    "visibilitychange" === t.type && "hidden" === document.visibilityState ? e.notify({
                                        reason: tg.HIDDEN
                                    }) : "freeze" === t.type && e.notify({
                                        reason: tg.FROZEN
                                    })
                                }, {
                                    capture: !0
                                }), r = tf(t, "beforeunload", () => {
                                    e.notify({
                                        reason: tg.UNLOADING
                                    })
                                }).stop;
                                return () => {
                                    n(), r()
                                }
                            })
                        }

                        function tv() {
                            let e = "",
                                t = 0;
                            return {
                                isAsync: !1,
                                get isEmpty() {
                                    return !e
                                },
                                write(n, r) {
                                    let i = e9(n);
                                    t += i, e += n, r && r(i)
                                },
                                finish(e) {
                                    e(this.finishSync())
                                },
                                finishSync() {
                                    let n = {
                                        output: e,
                                        outputBytesCount: t,
                                        rawBytesCount: t,
                                        pendingData: ""
                                    };
                                    return e = "", t = 0, n
                                },
                                estimateEncodedBytesCount: e => e.length
                            }
                        }
                        let th = ey ? 1 : 50;

                        function tb({
                            encoder: e = tv(),
                            endpoints: t,
                            reportError: n
                        }) {
                            let r = function(e, t, n = 16384) {
                                    let r = new eC,
                                        i = {
                                            transportStatus: 0,
                                            currentBackoffTime: 1e3,
                                            bandwidthMonitor: {
                                                ongoingRequestCount: 0,
                                                ongoingByteCount: 0,
                                                canHandle(e) {
                                                    return 0 === this.ongoingRequestCount || this.ongoingByteCount + e.bytesCount <= 81920 && this.ongoingRequestCount < 32
                                                },
                                                add(e) {
                                                    this.ongoingRequestCount += 1, this.ongoingByteCount += e.bytesCount
                                                },
                                                remove(e) {
                                                    this.ongoingRequestCount -= 1, this.ongoingByteCount -= e.bytesCount
                                                },
                                                stats() {
                                                    return {
                                                        ongoingByteCount: this.ongoingByteCount,
                                                        ongoingRequestCount: this.ongoingRequestCount
                                                    }
                                                }
                                            },
                                            queuedPayloads: to(),
                                            queueFullReported: !1
                                        };
                                    return {
                                        observable: r,
                                        send: n => {
                                            for (let o of e) tn(n, i, (e, t) => {
                                                ts(o, e, t)
                                            }, o.trackType, t, r)
                                        },
                                        sendOnExit: t => {
                                            for (let r of e) ! function(e, t, n) {
                                                if (n.bytesCount < t) try {
                                                    let t = e.build("beacon", n);
                                                    if (navigator.sendBeacon(t, n.data)) return
                                                } catch (e) {
                                                    var r;
                                                    r = e, ta || (ta = !0, eE(r))
                                                }
                                                ts(e, n)
                                            }(r, n, t)
                                        }
                                    }
                                }(t, n),
                                i = function({
                                    pageMayExitObservable: e
                                }) {
                                    let t, n, r = new eC,
                                        i = e.subscribe(e => {
                                            t = e.reason;
                                            try {
                                                r.notify(e.reason)
                                            } finally {
                                                t = void 0
                                            }
                                            u(e.reason)
                                        }),
                                        o = new eC(() => () => {
                                            i.unsubscribe()
                                        }),
                                        a = 0,
                                        s = 0;

                                    function u(e) {
                                        if (0 === s) return;
                                        let t = s,
                                            r = a;
                                        s = 0, a = 0, ex(n), n = void 0, o.notify({
                                            reason: e,
                                            messagesCount: t,
                                            bytesCount: r
                                        })
                                    }
                                    return {
                                        flushObservable: o,
                                        prepareUrgentFlushObservable: r,
                                        forceFlush: u,
                                        get messagesCount() {
                                            return s
                                        },
                                        notifyBeforeAddMessage(e) {
                                            a + e >= 16384 && u(t ? ? "bytes_limit"), s += 1, a += e, void 0 === n && (n = eI(() => {
                                                u("duration_limit")
                                            }, 3e4))
                                        },
                                        notifyAfterAddMessage(e = 0) {
                                            a += e, s >= th ? u(t ? ? "messages_limit") : a >= 16384 && u(t ? ? "bytes_limit")
                                        }
                                    }
                                }({
                                    pageMayExitObservable: ty()
                                }),
                                o = {},
                                a = i.flushObservable.subscribe(t => (function(t) {
                                    var n;
                                    let i = tc(o).join("\n");
                                    o = {};
                                    let a = (n = t.reason, tc(tg).includes(n)),
                                        s = a ? r.sendOnExit : r.send;
                                    if (a && e.isAsync) {
                                        let t = e.finishSync();
                                        t.outputBytesCount && s(tS(t));
                                        let n = [t.pendingData, i].filter(Boolean).join("\n");
                                        n && s({
                                            data: n,
                                            bytesCount: e9(n)
                                        })
                                    } else i && e.write(e.isEmpty ? i : `
${i}`), e.finish(e => {
                                        s(tS(e))
                                    })
                                })(t));

                            function s(t, n) {
                                let r = eX(t),
                                    a = e.estimateEncodedBytesCount(r);
                                if (a >= 262144) return void ep.warn(`Discarded a message whose size was bigger than the maximum allowed size ${256}KiB. ${eu} ${em}/#technical-limitations`);
                                if (void 0 !== n) {
                                    let t;
                                    void 0 !== o[n] ? t = a - e.estimateEncodedBytesCount(o[n]) : (i.notifyBeforeAddMessage(a), t = 0), o[n] = r, i.notifyAfterAddMessage(t)
                                } else i.notifyBeforeAddMessage(a), e.write(e.isEmpty ? r : `
${r}`, e => {
                                    i.notifyAfterAddMessage(e - a)
                                })
                            }
                            return {
                                get isEmpty() {
                                    return 0 === i.messagesCount
                                },
                                add: s,
                                upsert: s,
                                prepareUrgentFlushObservable: i.prepareUrgentFlushObservable,
                                forceFlush: i.forceFlush,
                                flushObservable: i.flushObservable,
                                stop: a.unsubscribe
                            }
                        }

                        function tS(e) {
                            return {
                                data: "string" == typeof e.output ? e.output : new Blob([e.output], {
                                    type: "text/plain"
                                }),
                                bytesCount: e.outputBytesCount,
                                encoding: e.encoding
                            }
                        }
                        let t_ = {
                                LOG: "log",
                                CONFIGURATION: "configuration",
                                USAGE: "usage"
                            },
                            tE = "datad0g.com",
                            tw = "datadoghq.com",
                            tC = ["ddsource", "dd-api-key", "dd-request-id"];

                        function tA(e) {
                            return tR(e, eg.document ? .baseURI ? ? eg.location ? .href).href
                        }

                        function tR(e, t) {
                            let n = function() {
                                if (!s) {
                                    let e = !1;
                                    try {
                                        e = "http://a/b" === new eg.URL("b", "http://a").href
                                    } catch {}
                                    s = e ? eg.URL : function() {
                                        if (!u) {
                                            let e, t;
                                            try {
                                                (e = document.createElement("iframe")).style.display = "none", document.body.appendChild(e), t = e.contentWindow ? ? eg
                                            } catch {
                                                t = eg
                                            }
                                            u = {
                                                URL: t.URL
                                            }, e ? .remove()
                                        }
                                        return u
                                    }().URL
                                }
                                return s
                            }();
                            try {
                                return void 0 !== t ? new n(e, t) : new n(e)
                            } catch (e) {
                                throw Error(`Failed to construct URL: ${String(e)}`)
                            }
                        }

                        function tT(e, t, n) {
                            return {
                                build: (r, i) => tO({
                                    proxy: e.proxy,
                                    site: e.site,
                                    path: `/api/v2/${t}`,
                                    parameters: function({
                                        clientToken: e,
                                        source: t = "browser"
                                    }, n, r, {
                                        retry: i,
                                        encoding: o
                                    }, a = []) {
                                        let s = [`ddsource=${t}`, `dd-api-key=${e}`, `dd-evp-origin-version=${encodeURIComponent("7.13.0")}`, "dd-evp-origin=browser", `dd-request-id=${function e(t){return t?(parseInt(t,10)^16*Math.random()>>parseInt(t,10)/4).toString(16):"10000000-1000-4000-8000-100000000000".replace(/[018]/g,e)}()}`].concat(a);
                                        return o && s.push(`dd-evp-encoding=${o}`), "rum" === n && (s.push(`batch_time=${q()}`, `_dd.api=${r}`), i && s.push(`_dd.retry_count=${i.count}`, `_dd.retry_after=${i.lastFailureStatus}`)), s.join("&")
                                    }(e, t, r, i, n)
                                }),
                                trackType: t
                            }
                        }

                        function tk({
                            replica: e,
                            proxy: t,
                            source: n
                        }, r) {
                            if (e) return tT({
                                clientToken: e.clientToken,
                                proxy: t,
                                source: n,
                                site: tw
                            }, r, "rum" === r ? [`application.id=${e.applicationId}`] : void 0)
                        }

                        function tO({
                            proxy: e,
                            site: t = tw,
                            path: n,
                            parameters: r = "",
                            subdomain: i
                        }) {
                            let o = n;
                            if (r && (o += `?${r}`), "string" == typeof e) {
                                let t = `${tA(e)}?ddforward=${encodeURIComponent(o)}`;
                                return i && (t += `&ddforwardSubdomain=${i}`), t
                            }
                            if ("function" == typeof e) return e({
                                path: n,
                                parameters: r,
                                subdomain: i
                            });
                            let a = t.split("."),
                                s = a.pop(),
                                u = `browser-intake-${a.join("-")}.${s}`;
                            return i && (u = `${i}.${u}`), `https://${u}${o}`
                        }

                        function tI(e, t, n) {
                            if (void 0 === t) return e;
                            if ("object" != typeof t || null === t) return t;
                            if (t instanceof Date) return new Date(t.getTime());
                            if (t instanceof RegExp) return new RegExp(t.source, t.flags);
                            if (n.hasAlreadyBeenSeen(t)) return;
                            if (Array.isArray(t)) {
                                let r = Array.isArray(e) ? e : [];
                                for (let e = 0; e < t.length; ++e) r[e] = tI(r[e], t[e], n);
                                return r
                            }
                            let r = "object" === z(e) ? e : {};
                            for (let e in t) Object.prototype.hasOwnProperty.call(t, e) && "__proto__" !== e && (r[e] = tI(r[e], t[e], n));
                            return r
                        }

                        function tx(e) {
                            return tI(void 0, e, tM())
                        }

                        function tN(...e) {
                            let t;
                            for (let n of e) null != n && (t = tI(t, n, tM()));
                            return t
                        }

                        function tM() {
                            let e = new WeakSet;
                            return {
                                hasAlreadyBeenSeen(t) {
                                    let n = e.has(t);
                                    return n || e.add(t), n
                                }
                            }
                        }

                        function tL() {
                            let e = [];
                            return {
                                register: t => (e.push(t), {
                                    unregister() {
                                        e = e.filter(e => e !== t)
                                    }
                                }),
                                trigger(t) {
                                    let n = [];
                                    for (let r of e) {
                                        let e = r(t);
                                        if ("DISCARDED" === e) return tD;
                                        "SKIPPED" !== e && n.push(e)
                                    }
                                    return tN(...n)
                                }
                            }
                        }
                        let tD = "DISCARDED",
                            tP = "SKIPPED";

                        function tU(e) {
                            return 0 !== e && 100 * Math.random() <= e
                        }
                        let t$ = ["https://www.datadoghq-browser-agent.com", "https://www.datad0g-browser-agent.com", "https://d3uc069fcn7uxw.cloudfront.net", "https://d20xtzwzcl0ceb.cloudfront.net", "http://localhost", "<anonymous>"],
                            tV = function(e) {
                                return e.LOGS = "browser-logs-sdk", e.RUM = "browser-rum-sdk", e
                            }({}),
                            tq = function(e) {
                                return e.CUSTOMER_DATA_METRIC_NAME = "Customer data measures", e.REMOTE_CONFIGURATION_METRIC_NAME = "remote configuration metrics", e.RECORDER_INIT_METRICS_TELEMETRY_NAME = "Recorder init metrics", e.SEGMENT_METRICS_TELEMETRY_NAME = "Segment network request metrics", e.SESSION_MANAGER_INIT_METRICS_TELEMETRY_NAME = "Session manager init metrics", e
                            }({}),
                            tF = ["ddog-gov.com", "us2.ddog-gov.com"];

                        function tH() {
                            return c || (c = new eR(100)), c
                        }

                        function tG(e, t) {
                            ev && ep.debug("[Telemetry]", e, t), tH().notify({
                                rawEvent: {
                                    type: t_.LOG,
                                    message: e,
                                    status: "debug",
                                    ...t
                                }
                            })
                        }

                        function tj(e, t) {
                            tH().notify({
                                rawEvent: {
                                    type: t_.LOG,
                                    status: "error",
                                    ... function(e) {
                                        if (e0(e)) {
                                            var t;
                                            let n = eP(e);
                                            return {
                                                error: {
                                                    kind: n.name,
                                                    stack: eY(((t = n).stack = t.stack.filter(e => !e.url || t$.some(t => e.url.startsWith(t))), t))
                                                },
                                                message: n.message
                                            }
                                        }
                                        return {
                                            error: {
                                                stack: eQ
                                            },
                                            message: `Uncaught ${eX(e)}`
                                        }
                                    }(e),
                                    ...t
                                }
                            })
                        }

                        function tK(e, t) {
                            tH().notify({
                                rawEvent: {
                                    type: t_.LOG,
                                    message: e,
                                    status: "debug",
                                    ...t
                                },
                                metricName: e
                            })
                        }

                        function tB(e) {
                            tH().notify({
                                rawEvent: {
                                    type: t_.USAGE,
                                    usage: e
                                }
                            })
                        }

                        function tW(e, t, n = 0, r) {
                            let i = new Date;
                            i.setTime(i.getTime() + n);
                            let o = `expires=${i.toUTCString()}`,
                                a = r ? .crossSite ? "none" : "strict",
                                s = r ? .domain ? `;domain=${r.domain}` : "",
                                u = r ? .secure ? ";secure" : "",
                                c = r ? .partitioned ? ";partitioned" : "";
                            document.cookie = `${e}=${t};${o};path=/;samesite=${a}${s}${u}${c}`
                        }

                        function tz(e) {
                            let t = er(document.cookie, e);
                            if ("" !== t) return t
                        }

                        function tY(e) {
                            return (function(e) {
                                let t = new Map;
                                for (en.lastIndex = 0;;) {
                                    let n = en.exec(e);
                                    if (n) {
                                        let e = n[1],
                                            r = n[2];
                                        t.has(e) ? t.get(e).push(r) : t.set(e, [r])
                                    } else break
                                }
                                return t
                            })(document.cookie).get(e) || []
                        }

                        function tJ(e) {
                            return l || (l = function(e) {
                                let t = new Map;
                                for (en.lastIndex = 0;;) {
                                    let n = en.exec(e);
                                    if (n) t.set(n[1], n[2]);
                                    else break
                                }
                                return t
                            }(document.cookie)), l.get(e)
                        }
                        let tX = ["applicationId", "service", "env", "version", "sessionSampleRate", "sessionReplaySampleRate", "telemetrySampleRate", "trackAnonymousUser", "trackUserInteractions", "trackResources", "trackLongTasks", "traceContextInjection", "actionNameAttribute", "defaultPrivacyLevel", "enablePrivacyForActionName", "traceSampleRate", "trackSessionAcrossSubdomains", "allowedTracingUrls", "allowedTrackingOrigins"];
                        async function tZ(e, t) {
                            let n, r = t0(),
                                i = await t3(e);
                            return i.ok ? (r.increment("fetch", "success"), n = tQ(e, i.value, t, r)) : (r.increment("fetch", "failure"), ep.error(i.error)), tK(tq.REMOTE_CONFIGURATION_METRIC_NAME, {
                                metrics: r.get()
                            }), n
                        }

                        function tQ(e, t, n, r) {
                            let i = { ...e
                            };
                            if (t.rum) {
                                let e = t.rum;
                                tX.forEach(t => {
                                    t in e && (i[t] = o(e[t]))
                                }), Object.keys(n).forEach(t => {
                                    var r;
                                    void 0 !== e[t] && (r = n[t], e[t].forEach(({
                                        key: e,
                                        value: t
                                    }) => {
                                        r.setContextProperty(e, o(t))
                                    }))
                                })
                            }
                            return t.profiling ? .sampleRate !== void 0 && (i.profilingSampleRate = t.profiling.sampleRate), i;

                            function o(e) {
                                if (Array.isArray(e)) return e.map(o);
                                if (Y(e)) {
                                    if ("rcSerializedType" in e) {
                                        let n = e.rcSerializedType;
                                        switch (n) {
                                            case "string":
                                                return e.value;
                                            case "regex":
                                                return t1(e.value);
                                            case "dynamic":
                                                let i;
                                                var t = e;
                                                let o = t.strategy;
                                                switch (o) {
                                                    case "cookie":
                                                        i = function({
                                                            name: e
                                                        }) {
                                                            let t = tz(e);
                                                            return r.increment("cookie", void 0 !== t ? "success" : "missing"), t
                                                        }(t);
                                                        break;
                                                    case "dom":
                                                        i = function({
                                                            selector: e,
                                                            attribute: t
                                                        }) {
                                                            var n, i;
                                                            let o;
                                                            try {
                                                                o = document.querySelector(e)
                                                            } catch {
                                                                ep.error(`Invalid selector in the remote configuration: '${e}'`), r.increment("dom", "failure");
                                                                return
                                                            }
                                                            if (!o) return void r.increment("dom", "missing");
                                                            if (n = o, i = t, "password" === n.getAttribute("type") && "value" === i) {
                                                                ep.error(`Forbidden element selected by the remote configuration: '${e}'`), r.increment("dom", "failure");
                                                                return
                                                            }
                                                            let a = void 0 !== t ? o.getAttribute(t) : o.textContent;
                                                            return null === a ? void r.increment("dom", "missing") : (r.increment("dom", "success"), a)
                                                        }(t);
                                                        break;
                                                    case "js":
                                                        i = function({
                                                            path: e
                                                        }) {
                                                            let t = window,
                                                                n = function(e) {
                                                                    let t, n = [],
                                                                        r = 0,
                                                                        i = {
                                                                            quote: void 0,
                                                                            escapeSequence: void 0
                                                                        },
                                                                        o = "";
                                                                    for (let u of e) {
                                                                        if (!(t = D[r].find(e => L[e](u, i)))) return [];
                                                                        if (void 0 !== i.escapeSequence && 12 !== t) {
                                                                            var a, s;
                                                                            if (a = i.escapeSequence, !("\"'/\\bfnrt".includes(a) || a.startsWith("u") && 5 === a.length)) return [];
                                                                            o += (s = i.escapeSequence).startsWith("u") ? String.fromCharCode(parseInt(s.slice(1), 16)) : $[s], i.escapeSequence = void 0
                                                                        }
                                                                        P.includes(t) ? o += u : U.includes(t) && "" !== o ? (n.push(o), o = "") : 12 === t ? i.escapeSequence = i.escapeSequence ? `${i.escapeSequence}${u}` : u : 8 === t ? i.quote = u : 9 === t && (i.quote = void 0), r = t
                                                                    }
                                                                    return D[r].includes(1) ? ("" !== o && n.push(o), n) : []
                                                                }(e);
                                                            if (0 === n.length) {
                                                                ep.error(`Invalid JSON path in the remote configuration: '${e}'`), r.increment("js", "failure");
                                                                return
                                                            }
                                                            for (let i of n) {
                                                                if (!(i in t)) return void r.increment("js", "missing");
                                                                try {
                                                                    t = t[i]
                                                                } catch (t) {
                                                                    ep.error(`Error accessing: '${e}'`, t), r.increment("js", "failure");
                                                                    return
                                                                }
                                                            }
                                                            return r.increment("js", "success"), t
                                                        }(t);
                                                        break;
                                                    case "localStorage":
                                                        i = function({
                                                            key: e
                                                        }) {
                                                            let t;
                                                            try {
                                                                t = localStorage.getItem(e)
                                                            } catch {
                                                                r.increment("localStorage", "failure");
                                                                return
                                                            }
                                                            return r.increment("localStorage", null !== t ? "success" : "missing"), t ? ? void 0
                                                        }(t);
                                                        break;
                                                    default:
                                                        ep.error(`Unsupported remote configuration: "strategy": "${o}"`);
                                                        return
                                                }
                                                let a = t.extractor;
                                                return void 0 !== a && "string" == typeof i ? function(e, t) {
                                                    let n = t1(e.value);
                                                    if (void 0 !== n) return O(t, n)
                                                }(a, i) : i;
                                            default:
                                                ep.error(`Unsupported remote configuration: "rcSerializedType": "${n}"`);
                                                return
                                        }
                                    }
                                    return ee(e, o)
                                }
                                return e
                            }
                        }

                        function t0() {
                            let e = {
                                fetch: {}
                            };
                            return {
                                get: () => e,
                                increment: (t, n) => {
                                    e[t] || (e[t] = {}), e[t][n] || (e[t][n] = 0), e[t][n] = e[t][n] + 1
                                }
                            }
                        }

                        function t1(e) {
                            try {
                                return new RegExp(e)
                            } catch {
                                ep.error(`Invalid regex in the remote configuration: '${e}'`)
                            }
                        }
                        async function t3(e) {
                            let t;
                            try {
                                t = await te(function(e) {
                                    if (e.remoteConfigurationProxy) return e.remoteConfigurationProxy;
                                    let t = t2(e);
                                    return tO({
                                        site: e.site,
                                        path: `/v1/${encodeURIComponent(t)}.json`,
                                        subdomain: "sdk-configuration"
                                    })
                                }(e))
                            } catch {
                                t = void 0
                            }
                            if (!t ? .ok) return {
                                ok: !1,
                                error: Error("Error fetching the remote configuration.")
                            };
                            let n = await t.json();
                            return n.rum || n.profiling ? {
                                ok: !0,
                                value: n,
                                lastModified: function(e) {
                                    let t = e.headers ? .get("last-modified");
                                    if (!t) return;
                                    let n = new Date(t).getTime();
                                    return isNaN(n) ? void 0 : n
                                }(t)
                            } : {
                                ok: !1,
                                error: Error("No remote configuration for RUM.")
                            }
                        }

                        function t2(e) {
                            return e.remoteConfiguration ? .id ? ? e.remoteConfigurationId
                        }
                        let t4 = {
                                GRANTED: "granted",
                                NOT_GRANTED: "not-granted"
                            },
                            t5 = {
                                ALLOW: "allow",
                                MASK: "mask",
                                MASK_USER_INPUT: "mask-user-input",
                                MASK_UNLESS_ALLOWLISTED: "mask-unless-allowlisted"
                            },
                            t6 = {
                                ALL: "all",
                                SAMPLED: "sampled"
                            },
                            t8 = {
                                clientToken: {
                                    type: "string",
                                    required: !0
                                },
                                service: {
                                    type: "string"
                                },
                                env: {
                                    type: "string"
                                },
                                version: {
                                    type: "string"
                                },
                                site: {
                                    type: "site",
                                    default: tw
                                },
                                proxy: {
                                    type: "union",
                                    variants: [{
                                        type: "string"
                                    }, {
                                        type: "function",
                                        signature: void 0
                                    }]
                                },
                                sessionSampleRate: {
                                    type: "percentage",
                                    default: 100
                                },
                                telemetrySampleRate: {
                                    type: "percentage",
                                    default: 20
                                },
                                telemetryConfigurationSampleRate: {
                                    type: "percentage",
                                    default: 5
                                },
                                telemetryUsageSampleRate: {
                                    type: "percentage",
                                    default: 5
                                },
                                silentMultipleInit: {
                                    type: "boolean",
                                    default: !1,
                                    strict: !1
                                },
                                storeContextsAcrossPages: {
                                    type: "boolean",
                                    default: !1,
                                    strict: !1
                                },
                                trackAnonymousUser: {
                                    type: "boolean",
                                    default: !0,
                                    strict: !1
                                },
                                useSecureSessionCookie: {
                                    type: "boolean",
                                    default: !1,
                                    strict: !1
                                },
                                usePartitionedCrossSiteSessionCookie: {
                                    type: "boolean",
                                    default: !1,
                                    strict: !1
                                },
                                trackSessionAcrossSubdomains: {
                                    type: "boolean",
                                    default: !1,
                                    strict: !1
                                },
                                allowedTrackingOrigins: {
                                    type: "match-option",
                                    multiple: !0,
                                    strict: !1
                                },
                                trackingConsent: {
                                    type: "enum",
                                    values: t4,
                                    default: t4.GRANTED
                                },
                                beforeSend: {
                                    type: "function",
                                    signature: void 0
                                },
                                source: {
                                    type: "enum",
                                    values: ["browser", "flutter", "unity"],
                                    default: "browser",
                                    strict: !1
                                },
                                sessionPersistence: {
                                    type: "enum",
                                    values: ["cookie", "local-storage", "memory"],
                                    multiple: !0,
                                    strict: !1
                                },
                                replica: {
                                    type: "schema",
                                    schema: {
                                        clientToken: {
                                            type: "string",
                                            required: !0
                                        },
                                        applicationId: {
                                            type: "string"
                                        }
                                    }
                                },
                                datacenter: {
                                    type: "string"
                                },
                                sdkVersion: {
                                    type: "string"
                                },
                                variant: {
                                    type: "string"
                                }
                            };

                        function t7(e, t) {
                            return (...n) => {
                                try {
                                    return e(...n)
                                } catch (e) {
                                    ep.error(t, e)
                                }
                            }
                        }

                        function t9(e, t) {
                            return +e.toFixed(t)
                        }

                        function ne(e) {
                            return "number" == typeof e
                        }

                        function nt(e) {
                            return Array.isArray(e) && e.length > 0
                        }

                        function nn(e, t, n) {
                            let r = {};
                            for (let [i, o] of Object.entries(e)) {
                                let e = t[i],
                                    a = o.multiple ? function(e, t, n) {
                                        if (null == t) return;
                                        if ("enum" === e.type && e.allowAll && "all" === t) return no(e.values).slice();
                                        let r = Array.isArray(t) ? t : [t],
                                            i = [];
                                        for (let t of r) {
                                            let r = ni(e, t, n);
                                            if (void 0 === r) {
                                                if (!1 !== e.strict) return
                                            } else i.push(r)
                                        }
                                        if (!1 !== e.strict || 0 !== i.length || !(r.length > 0)) return i
                                    }(o, e, n) : ni(o, e, n);
                                if (void 0 === a) {
                                    if (null != e && "" !== e) {
                                        if (n.error(function(e, t) {
                                                switch (t.type) {
                                                    case "string":
                                                        return `"${e}" must be a non-empty string`;
                                                    case "number":
                                                        if (void 0 !== t.min && void 0 !== t.max) return `"${e}" must be a number between ${t.min} and ${t.max}`;
                                                        if (void 0 !== t.min) return `"${e}" must be a number greater than or equal to ${t.min}`;
                                                        if (void 0 !== t.max) return `"${e}" must be a number less than or equal to ${t.max}`;
                                                        return `"${e}" must be a finite number`;
                                                    case "percentage":
                                                        return `"${e}" must be a number between 0 and 100`;
                                                    case "boolean":
                                                        return `"${e}" must be a boolean`;
                                                    case "site":
                                                        return `"${e}" must be a valid Datadog site. ${eu} ${es}/getting_started/site/.`;
                                                    case "match-option":
                                                        return `"${e}" must be a string, RegExp, or function`;
                                                    case "enum":
                                                        return `"${e}" must be one of: "${no(t.values).join('", "')}"`;
                                                    case "union":
                                                        return `"${e}" does not match any expected type`;
                                                    case "schema":
                                                        return `"${e}" is not a valid object`;
                                                    case "function":
                                                        return `"${e}" must be a function`
                                                }
                                            }(i, o)), o.required || !1 !== o.strict) return
                                    } else if (o.required) return void n.error(`"${i}" is required`);
                                    r[i] = "default" in o ? tx(o.default) : void 0
                                } else r[i] = a
                            }
                            return r
                        }
                        let nr = /(datadog|ddog|datad0g|dd0g)/;

                        function ni(e, t, n) {
                            if ("schema" === e.type) {
                                if ("object" != typeof t || null === t) return;
                                return nn(e.schema, t, n)
                            }
                            if ("union" === e.type) {
                                if (null == t) return;
                                for (let r of e.variants) {
                                    let e = ni(r, t, n);
                                    if (void 0 !== e) return e
                                }
                                return
                            }
                            if (null != t) switch (e.type) {
                                case "function":
                                    return "function" == typeof t ? t : void 0;
                                case "string":
                                    return "string" == typeof t && t.length > 0 ? t : void 0;
                                case "number":
                                    return "number" == typeof t && Number.isFinite(t) && (void 0 === e.min || t >= e.min) && (void 0 === e.max || t <= e.max) ? t : void 0;
                                case "percentage":
                                    return "number" == typeof t && t >= 0 && t <= 100 ? t : void 0;
                                case "boolean":
                                    return "boolean" == typeof t ? t : !1 === e.strict ? !!t : void 0;
                                case "site":
                                    if ("string" != typeof t || !nr.test(t)) return;
                                    return t;
                                case "match-option":
                                    return J(t) ? t : void 0;
                                case "enum":
                                    return "string" == typeof t && no(e.values).includes(t) ? t : void 0
                            }
                        }

                        function no(e) {
                            return Array.isArray(e) ? e : Object.values(e)
                        }
                        let na = ["tracecontext", "datadog"],
                            ns = ["cache-control", "etag", "age", "expires", "content-type", "content-encoding", "vary", "content-length", "server-timing", "x-cache", "cf-cache-status", "x-vercel-cache"],
                            nu = { ...t8,
                                applicationId: {
                                    type: "string",
                                    required: !0
                                },
                                actionNameAttribute: {
                                    type: "string"
                                },
                                workerUrl: {
                                    type: "string"
                                },
                                subdomain: {
                                    type: "string"
                                },
                                sessionReplaySampleRate: {
                                    type: "percentage",
                                    default: 0
                                },
                                traceSampleRate: {
                                    type: "percentage",
                                    default: 100
                                },
                                profilingSampleRate: {
                                    type: "percentage",
                                    default: 0
                                },
                                compressIntakeRequests: {
                                    type: "boolean",
                                    default: !1
                                },
                                trackUserInteractions: {
                                    type: "boolean",
                                    default: !0,
                                    strict: !1
                                },
                                trackResources: {
                                    type: "boolean",
                                    default: !0,
                                    strict: !1
                                },
                                trackLongTasks: {
                                    type: "boolean",
                                    default: !0,
                                    strict: !1
                                },
                                trackViewsManually: {
                                    type: "boolean",
                                    default: !1,
                                    strict: !1
                                },
                                betaEnableViewUpdates: {
                                    type: "boolean"
                                },
                                betaTrackWebSockets: {
                                    type: "boolean",
                                    default: !1,
                                    strict: !1
                                },
                                enablePrivacyForActionName: {
                                    type: "boolean",
                                    default: !0
                                },
                                propagateTraceBaggage: {
                                    type: "boolean",
                                    default: !0
                                },
                                startSessionReplayRecordingManually: {
                                    type: "boolean",
                                    default: !1,
                                    strict: !1
                                },
                                sessionReplayCanvasRecording: {
                                    type: "schema",
                                    schema: {
                                        enable: {
                                            type: "boolean",
                                            required: !0
                                        },
                                        maxFramesPerSecond: {
                                            type: "number",
                                            min: 0,
                                            max: 5,
                                            default: 1
                                        },
                                        hashingMaxDimension: {
                                            type: "number",
                                            min: 1,
                                            max: 100,
                                            default: 100
                                        },
                                        maxImageDimension: {
                                            type: "number",
                                            min: 1,
                                            max: 1e3,
                                            default: 1e3
                                        }
                                    }
                                },
                                defaultPrivacyLevel: {
                                    type: "enum",
                                    values: t5,
                                    default: t5.MASK_USER_INPUT,
                                    strict: !1
                                },
                                traceContextInjection: {
                                    type: "enum",
                                    values: t6,
                                    default: t6.SAMPLED,
                                    strict: !1
                                },
                                excludedActivityUrls: {
                                    type: "match-option",
                                    multiple: !0,
                                    default: []
                                },
                                allowedTracingUrls: {
                                    type: "union",
                                    multiple: !0,
                                    strict: !1,
                                    default: [],
                                    variants: [{
                                        type: "match-option"
                                    }, {
                                        type: "schema",
                                        schema: {
                                            match: {
                                                type: "match-option",
                                                required: !0
                                            },
                                            propagatorTypes: {
                                                type: "enum",
                                                values: ["datadog", "b3", "b3multi", "tracecontext"],
                                                multiple: !0,
                                                strict: !1,
                                                default: na
                                            }
                                        }
                                    }]
                                },
                                plugins: {
                                    type: "schema",
                                    multiple: !0,
                                    strict: !1,
                                    default: [],
                                    schema: {
                                        name: {
                                            type: "string",
                                            required: !0
                                        },
                                        getConfigurationTelemetry: {
                                            type: "function",
                                            strict: !1,
                                            signature: void 0
                                        },
                                        onInit: {
                                            type: "function",
                                            strict: !1,
                                            signature: void 0
                                        },
                                        onRumStart: {
                                            type: "function",
                                            strict: !1,
                                            signature: void 0
                                        }
                                    }
                                },
                                trackFeatureFlagsForEvents: {
                                    type: "enum",
                                    values: ["vital", "action", "long_task", "resource"],
                                    multiple: !0,
                                    strict: !1,
                                    default: []
                                }
                            };

                        function nc(e) {
                            return J(e) ? {
                                match: e,
                                propagatorTypes: na
                            } : Y(e) && J(e.match) && (null === e.propagatorTypes || void 0 === e.propagatorTypes || Array.isArray(e.propagatorTypes)) ? {
                                match: e.match,
                                propagatorTypes: e.propagatorTypes || na
                            } : void 0
                        }
                        let nl = ["request", "response", "any"];
                        var nd = class {
                            constructor() {
                                this.callbacks = {}
                            }
                            notify(e, t) {
                                let n = this.callbacks[e];
                                n && n.forEach(e => e(t))
                            }
                            subscribe(e, t) {
                                return this.callbacks[e] || (this.callbacks[e] = []), this.callbacks[e].push(t), {
                                    unsubscribe: () => {
                                        this.callbacks[e] = this.callbacks[e].filter(e => t !== e)
                                    }
                                }
                            }
                        };
                        let nf = 144e5,
                            np = 9e5,
                            nm = {
                                COOKIE: "cookie",
                                MEMORY: "memory",
                                LOCAL_STORAGE: "local-storage"
                            },
                            ng = 1 / 0,
                            ny = new Set;

                        function nv({
                            expireDelay: e,
                            maxEntries: t
                        }) {
                            let n = [],
                                r = () => {
                                    if (!e) return;
                                    let t = H() - e;
                                    for (; n.length > 0 && n[n.length - 1].endTime < t;) n.pop()
                                };
                            return e && (f || (f = eN(() => void ny.forEach(e => e()), 6e4)), ny.add(r)), {
                                add: function(e, r) {
                                    let i = {
                                        value: e,
                                        startTime: r,
                                        endTime: ng,
                                        remove: () => {
                                            var e = n;
                                            let t = e.indexOf(i);
                                            t >= 0 && e.splice(t, 1)
                                        },
                                        close: e => {
                                            i.endTime = e
                                        }
                                    };
                                    return t && n.length >= t && n.pop(), n.unshift(i), i
                                },
                                find: function(e = ng, t = {
                                    returnInactive: !1
                                }) {
                                    for (let r of n)
                                        if (r.startTime <= e) {
                                            if (t.returnInactive || e <= r.endTime) return r.value;
                                            break
                                        }
                                },
                                closeActive: function(e) {
                                    let t = n[0];
                                    t ? .endTime === ng && t.close(e)
                                },
                                findAll: function(e = ng, t = 0) {
                                    let r = e + t;
                                    return n.filter(t => t.startTime <= r && e <= t.endTime).map(e => e.value)
                                },
                                findAllEntries: function(e = ng, t = 0) {
                                    let r = e + t;
                                    return n.filter(t => t.startTime <= r && e <= t.endTime)
                                },
                                getEntries: function(e) {
                                    return n.filter(t => t.startTime === e)
                                },
                                reset: function() {
                                    n = []
                                },
                                stop: function() {
                                    ny.delete(r), 0 === ny.size && f && (eM(f), f = void 0)
                                }
                            }
                        }
                        let nh = {
                                DOCUMENT: "document",
                                XHR: "xhr",
                                BEACON: "beacon",
                                FETCH: "fetch",
                                CSS: "css",
                                JS: "js",
                                IMAGE: "image",
                                FONT: "font",
                                MEDIA: "media",
                                WEBSOCKET: "websocket",
                                OTHER: "other"
                            },
                            nb = {
                                FETCH: nh.FETCH,
                                XHR: nh.XHR
                            },
                            nS = [
                                [nh.DOCUMENT, e => "navigation" === e],
                                [nh.XHR, e => "xmlhttprequest" === e],
                                [nh.FETCH, e => "fetch" === e],
                                [nh.BEACON, e => "beacon" === e],
                                [nh.CSS, (e, t) => /\.css$/i.test(t)],
                                [nh.JS, (e, t) => /\.js$/i.test(t)],
                                [nh.IMAGE, (e, t) => ["image", "img", "icon"].includes(e) || null !== /\.(gif|jpg|jpeg|tiff|png|svg|ico)$/i.exec(t)],
                                [nh.FONT, (e, t) => null !== /\.(woff|eot|woff2|ttf)$/i.exec(t)],
                                [nh.MEDIA, (e, t) => ["audio", "video"].includes(e) || null !== /\.(mp3|mp4)$/i.exec(t)]
                            ];

                        function n_(...e) {
                            for (let t = 1; t < e.length; t += 1)
                                if (e[t - 1] > e[t]) return !1;
                            return !0
                        }

                        function nE(e, t, n) {
                            if (e <= t && t <= n) return {
                                duration: F(n - t),
                                start: F(t - e)
                            }
                        }

                        function nw(e) {
                            var t;
                            return e && (!tC.every(t => e.includes(t)) || (t = eT.TRACK_INTAKE_REQUESTS, ek.has(t)))
                        }
                        let nC = /data:(.+)?(;base64)?,/g;

                        function nA(e, t = 24e3) {
                            if (e.length <= t || !e.startsWith("data:")) return e;
                            let n = e.substring(0, 100).match(nC);
                            return n ? `${n[0]}[...]` : e
                        }

                        function nR(e) {
                            return new eC(t => {
                                let n, r = e => {
                                        let n = e.filter(e => {
                                            var t;
                                            return !("resource" === (t = e).entryType && (!nw(t.name) || !(t.duration >= 0)))
                                        });
                                        n.length > 0 && t.notify(n)
                                    },
                                    i = !0,
                                    o = new PerformanceObserver(eS(e => {
                                        i ? n = eI(() => r(e.getEntries())) : r(e.getEntries())
                                    }));
                                return o.observe(e), i = !1, !p && void 0 !== window.performance && "getEntries" in performance && "addEventListener" in performance && (p = tf(performance, "resourcetimingbufferfull", () => {
                                    performance.clearResourceTimings()
                                })), () => {
                                    o.disconnect(), ex(n)
                                }
                            })
                        }

                        function nT(e) {
                            return PerformanceObserver.supportedEntryTypes.includes(e)
                        }

                        function nk(e) {
                            return e.nodeType === Node.TEXT_NODE
                        }

                        function nO(e) {
                            return e.nodeType === Node.ELEMENT_NODE
                        }

                        function nI(e) {
                            return !!e.host && e.nodeType === Node.DOCUMENT_FRAGMENT_NODE && nO(e.host)
                        }

                        function nx(e) {
                            if (e.parentElement) return e.parentElement;
                            let t = e.parentNode;
                            return t && nI(t) ? t.host : null
                        }
                        let nN = "Masked Element",
                            nM = ["data-dd-action-name", "data-testid", "data-test", "data-qa", "data-cy", "data-test-id", "data-qa-id", "data-testing", "data-component", "data-element", "data-source-file"],
                            nL = [nq, n$],
                            nD = [nq, function(e) {
                                if ("BODY" === e.tagName) return;
                                let t = e.classList;
                                for (let n = 0; n < t.length; n += 1) {
                                    let r = t[n];
                                    if (!nU(r)) return `${CSS.escape(e.tagName)}.${CSS.escape(r)}`
                                }
                            }, nV];

                        function nP(e, t) {
                            if (!e.isConnected) return;
                            let n = function(e) {
                                    let t = [],
                                        n = e;
                                    for (; n;) {
                                        let e = n.getRootNode();
                                        if (t.push({
                                                rootNode: e,
                                                target: n
                                            }), nI(e)) n = e.host;
                                        else break
                                    }
                                    return t.reverse()
                                }(e),
                                r = [];
                            for (let {
                                    rootNode: e,
                                    target: i
                                } of n) {
                                let n = function(e, t, n) {
                                    let r, i = e;
                                    for (; i && "HTML" !== i.nodeName;) {
                                        let e = nG(i, t, nL, nj, n, r);
                                        if (e) return nB(e, r);
                                        r = nB(nG(i, t, nD, nK, n, r) || function(e) {
                                            let t = nH(e);
                                            return `${CSS.escape(e.tagName)}:nth-of-type(${t})`
                                        }(i), r), i = i.parentElement
                                    }
                                    return r
                                }(i, e, t);
                                if (!n) return;
                                r.push(n)
                            }
                            return r.join("::shadow ")
                        }

                        function nU(e) {
                            return /[0-9]/.test(e)
                        }

                        function n$(e) {
                            if (e.id && !nU(e.id)) return `#${CSS.escape(e.id)}`
                        }

                        function nV(e) {
                            return CSS.escape(e.tagName)
                        }

                        function nq(e, t) {
                            if (t) {
                                let e = n(t);
                                if (e) return e
                            }
                            for (let e of nM) {
                                let t = n(e);
                                if (t) return t
                            }

                            function n(t) {
                                if (e.hasAttribute(t)) return `${CSS.escape(e.tagName)}${nF(t,e.getAttribute(t))}`
                            }
                        }

                        function nF(e, t) {
                            return `[${e}="${CSS.escape(t)}"]`
                        }

                        function nH(e) {
                            let t = e.parentNode.firstElementChild,
                                n = 1;
                            for (; t && t !== e;) t.tagName === e.tagName && (n += 1), t = t.nextElementSibling;
                            return n
                        }

                        function nG(e, t, n, r, i, o) {
                            for (let a of n) {
                                let n = a(e, i);
                                if (n && r(e, t, n, o)) return n
                            }
                        }

                        function nj(e, t, n, r) {
                            return 1 === t.querySelectorAll(nB(n, r)).length
                        }

                        function nK(e, t, n, r) {
                            let i;
                            if (void 0 === r) i = e => e.matches(n);
                            else {
                                let e = nB(`${n}:scope`, r);
                                i = t => null !== t.querySelector(e)
                            }
                            let o = e.previousElementSibling;
                            for (; o;) {
                                if (i(o)) return !1;
                                o = o.previousElementSibling
                            }
                            for (o = e.nextElementSibling; o;) {
                                if (i(o)) return !1;
                                o = o.nextElementSibling
                            }
                            return !0
                        }

                        function nB(e, t) {
                            return t ? `${e}>${t}` : e
                        }
                        let nW = {
                                IGNORE: "ignore",
                                HIDDEN: "hidden",
                                ALLOW: t5.ALLOW,
                                MASK: t5.MASK,
                                MASK_USER_INPUT: t5.MASK_USER_INPUT,
                                MASK_UNLESS_ALLOWLISTED: t5.MASK_UNLESS_ALLOWLISTED
                            },
                            nz = {
                                INPUT: !0,
                                OUTPUT: !0,
                                TEXTAREA: !0,
                                SELECT: !0,
                                OPTION: !0,
                                DATALIST: !0,
                                OPTGROUP: !0
                            };

                        function nY(e) {
                            return `[data-dd-privacy="${e}"], .dd-privacy-${e}`
                        }

                        function nJ(e, t, n) {
                            if (n ? .has(e)) return n.get(e);
                            let r = nI(e) ? e.host : e.parentNode,
                                i = r ? nJ(r, t, n) : t,
                                o = function(e, t) {
                                    switch (t) {
                                        case nW.HIDDEN:
                                        case nW.IGNORE:
                                            return t
                                    }
                                    switch (e) {
                                        case nW.ALLOW:
                                        case nW.MASK:
                                        case nW.MASK_USER_INPUT:
                                        case nW.MASK_UNLESS_ALLOWLISTED:
                                        case nW.HIDDEN:
                                        case nW.IGNORE:
                                            return e;
                                        default:
                                            return t
                                    }
                                }(function(e) {
                                    if (nO(e)) {
                                        if ("BASE" === e.tagName) return nW.ALLOW;
                                        if ("INPUT" === e.tagName) {
                                            if ("password" === e.type || "email" === e.type || "tel" === e.type || "hidden" === e.type) return nW.MASK;
                                            let t = e.getAttribute("autocomplete");
                                            if (t && (t.startsWith("cc-") || t.endsWith("-password"))) return nW.MASK
                                        }
                                        if (e.matches(nY(nW.HIDDEN))) return nW.HIDDEN;
                                        if (e.matches(nY(nW.MASK))) return nW.MASK;
                                        if (e.matches(nY(nW.MASK_UNLESS_ALLOWLISTED))) return nW.MASK_UNLESS_ALLOWLISTED;
                                        if (e.matches(nY(nW.MASK_USER_INPUT))) return nW.MASK_USER_INPUT;
                                        if (e.matches(nY(nW.ALLOW))) return nW.ALLOW;
                                        if (function(e) {
                                                if ("SCRIPT" === e.nodeName) return !0;
                                                if ("LINK" === e.nodeName) {
                                                    let e = t("rel");
                                                    return /preload|prefetch/i.test(e) && "script" === t("as") || "shortcut icon" === e || "icon" === e
                                                }
                                                if ("META" === e.nodeName) {
                                                    let n = t("name"),
                                                        r = t("rel"),
                                                        i = t("property");
                                                    return /^msapplication-tile(image|color)$/.test(n) || "application-name" === n || "icon" === r || "apple-touch-icon" === r || "shortcut icon" === r || "keywords" === n || "description" === n || /^(og|twitter|fb):/.test(i) || /^(og|twitter):/.test(n) || "pinterest" === n || "robots" === n || "googlebot" === n || "bingbot" === n || e.hasAttribute("http-equiv") || "author" === n || "generator" === n || "framework" === n || "publisher" === n || "progid" === n || /^article:/.test(i) || /^product:/.test(i) || "google-site-verification" === n || "yandex-verification" === n || "csrf-token" === n || "p:domain_verify" === n || "verify-v1" === n || "verification" === n || "shopify-checkout-api-token" === n
                                                }

                                                function t(t) {
                                                    return (e.getAttribute(t) || "").toLowerCase()
                                                }
                                                return !1
                                            }(e)) return nW.IGNORE
                                    }
                                }(e), i);
                            return n && n.set(e, o), o
                        }

                        function nX(e) {
                            if (!e || e.nodeType !== e.ELEMENT_NODE) return !1;
                            if ("INPUT" === e.tagName) switch (e.type) {
                                case "button":
                                case "color":
                                case "reset":
                                case "submit":
                                    return !1
                            }
                            return !!nz[e.tagName]
                        }

                        function nZ(e) {
                            return !e ? .trim() || window.$DD_ALLOW ? .has(e.toLocaleLowerCase()) || !1
                        }
                        let nQ = new Map;

                        function n0(e, t) {
                            if (100 === t) return !0;
                            if (0 === t) return !1;
                            let n = nQ.get(t);
                            if (e === n ? .sessionId) return n.decision;
                            let r = function(e, t) {
                                let n = 1 n << 64 n;
                                return Number(0xf6b75ab2bc471c7 n * e % n) <= t / 100 * Number(n)
                            }(BigInt(`0x${e.split("-")[4]}`), t);
                            return nQ.set(t, {
                                sessionId: e,
                                decision: r
                            }), r
                        }

                        function n1(e, t, n, {
                            computeHandlingStack: r
                        } = {}) {
                            let i = e[t];
                            if ("function" != typeof i)
                                if (!(t in e && "string" == typeof t && t.startsWith("on"))) return {
                                    stop: eD
                                };
                                else i = eD;
                            let o = !1,
                                {
                                    stop: a
                                } = n3(e, t, i, function() {
                                    if (o) return i.apply(this, arguments);
                                    let e = Array.from(arguments);
                                    return n2(n, {
                                        target: this,
                                        parameters: e,
                                        handlingStack: r ? ez("instrumented method") : void 0
                                    }, () => i.apply(this, e))
                                });
                            return {
                                stop: () => {
                                    o = !0, a()
                                }
                            }
                        }

                        function n3(e, t, n, r) {
                            return e[t] = r, {
                                stop: () => {
                                    e[t] === r && (e[t] = n)
                                }
                            }
                        }

                        function n2(e, t, n) {
                            let r;
                            e_(e, null, [{ ...t,
                                onPostCall: e => {
                                    r = e
                                }
                            }]);
                            let i = n();
                            return r && e_(r, null, [i]), i
                        }

                        function n4(e) {
                            let t = crypto.getRandomValues(new Uint32Array(2)),
                                n = BigInt(t[0]) + (BigInt(t[1]) << 32 n);
                            return 63 === e && (n &= 0x7fffffffffffffff n), n
                        }

                        function n5(e) {
                            return e.toString(16).padStart(16, "0")
                        }

                        function n6(e, t, n = !1) {
                            return e.some(e => {
                                try {
                                    if ("function" == typeof e) return e(t);
                                    if (e instanceof RegExp) return e.lastIndex = 0, e.test(t);
                                    if ("string" == typeof e) return n ? t.startsWith(e) : e === t
                                } catch (e) {
                                    ep.error(e)
                                }
                                return !1
                            })
                        }

                        function n8(e) {
                            0 !== e.status || e.isAborted || (e.traceId = void 0, e.spanId = void 0, e.traceSampled = void 0)
                        }

                        function n7(e, t, n, r, i, o) {
                            let a = n.findTrackedSession();
                            if (!a) return;
                            let s = e.allowedTracingUrls.find(e => n6([e.match], t.url, !0));
                            if (!s) return;
                            let u = n0(a.id, e.sessionSampleRate * e.traceSampleRate / 100),
                                c = e8() ? e6() ? .getIsTraceSampled() ? ? u : u;
                            (c || e.traceContextInjection === t6.ALL) && (t.traceSampled = c, t.traceId = n4(64), t.spanId = n4(63), o(function(e, t, n, r, i, o, a, s) {
                                let u = {};
                                if (i.forEach(r => {
                                        switch (r) {
                                            case "datadog":
                                                Object.assign(u, {
                                                    "x-datadog-origin": "rum",
                                                    "x-datadog-parent-id": t.toString(),
                                                    "x-datadog-sampling-priority": n ? "1" : "0",
                                                    "x-datadog-trace-id": e.toString()
                                                });
                                                break;
                                            case "tracecontext":
                                                Object.assign(u, {
                                                    traceparent: `00-0000000000000000${n5(e)}-${n5(t)}-0${n?"1":"0"}`,
                                                    tracestate: `dd=s:${n?"1":"0"};o:rum`
                                                });
                                                break;
                                            case "b3":
                                                Object.assign(u, {
                                                    b3: `${n5(e)}-${n5(t)}-${n?"1":"0"}`
                                                });
                                                break;
                                            case "b3multi":
                                                Object.assign(u, {
                                                    "X-B3-TraceId": n5(e),
                                                    "X-B3-SpanId": n5(t),
                                                    "X-B3-Sampled": n ? "1" : "0"
                                                })
                                        }
                                    }), s.propagateTraceBaggage) {
                                    let e = {
                                            "session.id": r
                                        },
                                        t = o.getContext().id;
                                    "string" == typeof t && (e["user.id"] = t);
                                    let n = a.getContext().id;
                                    "string" == typeof n && (e["account.id"] = n);
                                    let i = Object.entries(e).map(([e, t]) => `${e}=${encodeURIComponent(t)}`).join(",");
                                    i && (u.baggage = i)
                                }
                                return u
                            }(t.traceId, t.spanId, t.traceSampled, a.id, s.propagatorTypes, r, i, e)))
                        }

                        function n9(e, t) {
                            return t.allowedGraphQlUrls.find(t => n6([t.match], e))
                        }
                        let re = new WeakMap;

                        function rt() {
                            return m || (m = "XMLHttpRequest" in eg ? new eC(e => {
                                let {
                                    stop: t
                                } = n1(XMLHttpRequest.prototype, "open", rn), {
                                    stop: n
                                } = n1(XMLHttpRequest.prototype, "send", t => {
                                    ! function({
                                        target: e,
                                        parameters: [t],
                                        handlingStack: n
                                    }, r) {
                                        let i = re.get(e);
                                        if (!i) return;
                                        i.state = "start", i.startClocks = G(), i.isAborted = !1, i.xhr = e, i.handlingStack = n, i.requestBody = t;
                                        let o = !1,
                                            {
                                                stop: a
                                            } = n1(e, "onreadystatechange", () => {
                                                e.readyState === XMLHttpRequest.DONE && s()
                                            }),
                                            s = () => {
                                                var t;
                                                u(), a(), o || (o = !0, t = i.startClocks.timeStamp, i.duration = q() - t, i.status = e.status, "string" == typeof e.response && (i.responseBody = e.response), r.notify({ ...i,
                                                    state: "complete"
                                                }))
                                            },
                                            {
                                                stop: u
                                            } = tf(e, "loadend", s);
                                        r.notify(i)
                                    }(t, e)
                                }, {
                                    computeHandlingStack: !0
                                }), {
                                    stop: r
                                } = n1(XMLHttpRequest.prototype, "abort", rr);
                                return () => {
                                    t(), n(), r()
                                }
                            }) : new eC), m
                        }

                        function rn({
                            target: e,
                            parameters: [t, n]
                        }) {
                            re.set(e, {
                                state: "open",
                                method: String(t).toUpperCase(),
                                url: tA(String(n))
                            })
                        }

                        function rr({
                            target: e
                        }) {
                            let t = re.get(e);
                            t && (t.isAborted = !0)
                        }
                        let ri = {
                                AGENT: "agent",
                                CONSOLE: "console",
                                CUSTOM: "custom",
                                SOURCE: "source",
                                REPORT: "report"
                            },
                            ro = function(e) {
                                return e.UNCAUGHT = "Uncaught", e.PROVIDED = "Provided", e
                            }({}),
                            ra = function(e) {
                                return e.HANDLED = "handled", e.UNHANDLED = "unhandled", e
                            }({});

                        function rs(e, t = 225280) {
                            let n = eZ(Object.prototype),
                                r = eZ(Array.prototype);
                            try {
                                let n = [],
                                    r = new WeakMap,
                                    i = ru(e, "$", void 0, n, r),
                                    o = JSON.stringify(i),
                                    a = o ? o.length : 0;
                                if (a > t) return void rc(t, "discarded", e);
                                for (; n.length > 0 && a < t;) {
                                    let i = n.shift(),
                                        o = 0;
                                    if (Array.isArray(i.source))
                                        for (let s = 0; s < i.source.length; s++) {
                                            let u = ru(i.source[s], i.path, s, n, r);
                                            if (void 0 !== u ? a += JSON.stringify(u).length : a += 4, a += o, o = 1, a > t) {
                                                rc(t, "truncated", e);
                                                break
                                            }
                                            i.target[s] = u
                                        } else
                                            for (let s in i.source)
                                                if (Object.prototype.hasOwnProperty.call(i.source, s)) {
                                                    let u = ru(i.source[s], i.path, s, n, r);
                                                    if (void 0 !== u && (a += JSON.stringify(u).length + o + s.length + 3, o = 1), a > t) {
                                                        rc(t, "truncated", e);
                                                        break
                                                    }
                                                    i.target[s] = u
                                                }
                                }
                                return i
                            } finally {
                                n(), r()
                            }
                        }

                        function ru(e, t, n, r, i) {
                            let o = function(e) {
                                if (("object" != typeof e || null === e) && "function" != typeof e) return e;
                                if ("function" == typeof e.toJSON) try {
                                    return e.toJSON()
                                } catch {}
                                return e
                            }(e);
                            if (!o || "object" != typeof o) {
                                var a;
                                return "bigint" == typeof(a = o) ? `[BigInt] ${a.toString()}` : "function" == typeof a ? `[Function] ${a.name||"unknown"}` : "symbol" == typeof a ? `[Symbol] ${a.description||a.toString()}` : a
                            }
                            let s = function e(t) {
                                try {
                                    if (t instanceof Event) {
                                        var n;
                                        return {
                                            type: (n = t).type,
                                            isTrusted: n.isTrusted,
                                            currentTarget: n.currentTarget ? e(n.currentTarget) : null,
                                            target: n.target ? e(n.target) : null
                                        }
                                    }
                                    if (t instanceof RegExp) return `[RegExp] ${t.toString()}`;
                                    let r = Object.prototype.toString.call(t).match(/\[object (.*)\]/);
                                    if (r ? .[1]) return `[${r[1]}]`
                                } catch {}
                                return "[Unserializable]"
                            }(o);
                            if ("[Object]" !== s && "[Array]" !== s && "[Error]" !== s) return s;
                            if (i.has(e)) return `[Reference seen at ${i.get(e)}]`;
                            let u = void 0 !== n ? `${t}.${n}` : t,
                                c = Array.isArray(o) ? [] : {};
                            return i.set(e, u), r.push({
                                source: o,
                                target: c,
                                path: u
                            }), c
                        }

                        function rc(e, t, n) {
                            ep.warn(`The data provided has been ${t} as it is over the limit of ${e} characters:`, n)
                        }
                        let rl = new Map,
                            rd = new Set,
                            rf = !1;

                        function rp() {
                            let e = eg.window ? .DD_SOURCE_CODE_CONTEXT;
                            if (!e) return;
                            let t = !1,
                                n = !1,
                                r = !1;
                            for (let [i, o] of Object.entries(e)) {
                                if (t = t || void 0 !== o.ddDebugId, n = n || void 0 !== o.service, r = r || void 0 !== o.version, rd.has(i)) continue;
                                rd.add(i);
                                let e = eP({
                                    stack: i
                                }).stack[0] ? .url;
                                e && !rl.has(e) && rl.set(e, o)
                            }
                            rf || (rf = !0, tB({
                                feature: "source-code-context",
                                use_debug_id: t,
                                use_service: n,
                                use_version: r
                            }))
                        }

                        function rm(e) {
                            rp();
                            let t = new Set,
                                n = [];
                            for (let r of e) {
                                if (t.has(r)) continue;
                                t.add(r);
                                let e = rl.get(r) ? .ddDebugId;
                                void 0 !== e && n.push({
                                    url: r,
                                    id: e
                                })
                            }
                            return n.length ? n : void 0
                        }

                        function rg({
                            originalError: e,
                            stackTrace: t,
                            source: n,
                            useFallbackStack: r = !0,
                            nonErrorPrefix: i
                        }) {
                            var o, a, s, u;
                            let c = e0(e);
                            return {
                                source: n,
                                type: t ? t.name : void 0,
                                message: (o = t, a = c, s = i, u = e, o ? .message && o ? .name ? o.message : a ? "Empty message" : s ? `${s} ${eX(rs(u))}` : eX(rs(u))),
                                stack: t ? eY(t) : r ? eQ : void 0
                            }
                        }

                        function ry(e) {
                            return e ? .stack.map(e => e.url).filter(e => !!e) ? ? []
                        }

                        function rv({
                            stackTrace: e,
                            originalError: t,
                            handlingStack: n,
                            componentStack: r,
                            startClocks: i,
                            nonErrorPrefix: o,
                            useFallbackStack: a = !0,
                            source: s,
                            handling: u
                        }) {
                            var c;
                            let l = e ? ? (e0(t) ? eP(t) : void 0),
                                d = e0(t) ? function(e) {
                                    let t = [],
                                        n = e.cause;
                                    for (; null != n && t.length < 10;) {
                                        let e = e0(n),
                                            r = e ? eP(n) : void 0;
                                        t.push({
                                            originalError: n,
                                            stackTrace: r
                                        }), n = e ? n.cause : void 0
                                    }
                                    return t
                                }(t) : [],
                                f = rg({
                                    originalError: t,
                                    stackTrace: l,
                                    source: s,
                                    useFallbackStack: a,
                                    nonErrorPrefix: o
                                }),
                                p = d.map(({
                                    originalError: e,
                                    stackTrace: t
                                }) => rg({
                                    originalError: e,
                                    stackTrace: t,
                                    source: s,
                                    useFallbackStack: !1
                                }));
                            return {
                                startClocks: i,
                                handling: u,
                                handlingStack: n,
                                componentStack: r,
                                originalError: t,
                                ...f,
                                debugIds: function(e, t) {
                                    let n = t.flatMap(({
                                        stackTrace: e
                                    }) => ry(e));
                                    return rm(ry(e).concat(n))
                                }(l, d),
                                causes: p.length ? p : void 0,
                                fingerprint: e0(c = t) && "dd_fingerprint" in c ? String(c.dd_fingerprint) : void 0,
                                context: function(e) {
                                    if (Y(e)) return e.dd_context
                                }(t)
                            }
                        }
                        async function rh(e) {
                            let t = e.getReader(),
                                n = [];
                            for (;;) {
                                let e = await t.read();
                                if (e.done) break;
                                n.push(e.value)
                            }
                            t.cancel().catch(eD);
                            if (1 === n.length) return n[0];
                            let r = new Uint8Array(n.reduce((e, t) => e + t.length, 0)),
                                i = 0;
                            for (let e of n) r.set(e, i), i += e.length;
                            return r
                        }
                        let rb = function(e) {
                                return e[e.IGNORE = 0] = "IGNORE", e[e.COLLECT = 1] = "COLLECT", e
                            }({}),
                            rS = [];

                        function r_({
                            responseBodyAction: e
                        } = {}) {
                            return e && rS.push(e), g || (g = new eC(e => {
                                if (!eg.fetch) return;
                                let {
                                    stop: t
                                } = n1(eg, "fetch", t => (function({
                                    parameters: e,
                                    onPostCall: t,
                                    handlingStack: n
                                }, r) {
                                    let [i, o] = e, a = o ? .method;
                                    void 0 === a && i instanceof Request && (a = i.method);
                                    let s = void 0 !== a ? String(a).toUpperCase() : "GET",
                                        u = i instanceof Request ? i.url : tA(String(i)),
                                        c = {
                                            state: "start",
                                            init: o,
                                            input: i,
                                            method: s,
                                            startClocks: G(),
                                            url: u,
                                            handlingStack: n,
                                            isAbortedOnStart: i instanceof Request && i.signal ? .aborted || o ? .signal ? .aborted || !1
                                        };
                                    r.notify(c), e[0] = c.input, e[1] = c.init, t(e => {
                                        rE(r, e, c).catch(eE)
                                    })
                                })(t, e), {
                                    computeHandlingStack: !0
                                });
                                return t
                            })), g
                        }
                        async function rE(e, t, n) {
                            let r;
                            try {
                                r = await t
                            } catch (t) {
                                e.notify({ ...n,
                                    state: "resolve",
                                    status: 0,
                                    isAborted: n.init ? .signal ? .aborted || t instanceof DOMException && t.code === DOMException.ABORT_ERR,
                                    error: t
                                });
                                return
                            }
                            if (n.response = r, n.status = r.status, n.responseType = r.type, n.isAborted = !1, 1 === rS.reduce((e, t) => Math.max(e, t(n)), 0)) {
                                let e = function(e) {
                                    try {
                                        return e.clone()
                                    } catch {
                                        return
                                    }
                                }(r);
                                if (e ? .body) try {
                                    let t = await rh(e.body);
                                    n.responseBody = new TextDecoder().decode(t)
                                } catch {}
                            }
                            e.notify({ ...n,
                                state: "resolve"
                            })
                        }
                        let rw = {},
                            rC = function(e) {
                                return e[e.RUNTIME_ERROR = 0] = "RUNTIME_ERROR", e[e.FETCH = 1] = "FETCH", e[e.XHR = 2] = "XHR", e[e.CONSOLE = 3] = "CONSOLE", e
                            }({}),
                            rA = 1;

                        function rR(e) {
                            e.requestIndex || (e.requestIndex = rA++)
                        }

                        function rT(e) {
                            return "string" == typeof e ? e9(e) : e instanceof ArrayBuffer || ArrayBuffer.isView(e) ? e.byteLength : "undefined" != typeof Blob && e instanceof Blob ? e.size : 0
                        }

                        function rk(e, t, n) {
                            var r, i;
                            if (void 0 === e.openClocks) return;
                            let o = (r = e.openClocks.timeStamp, t.timeStamp - r);
                            if ("in" === n && void 0 === e.firstMessageInOffset ? e.firstMessageInOffset = o : "out" === n && void 0 === e.firstMessageOutOffset && (e.firstMessageOutOffset = o), "in" === n) {
                                if (void 0 !== e.lastMessageInAt) {
                                    let n = (i = e.lastMessageInAt, t.timeStamp - i);
                                    n > e.longestInboundSilence && (e.longestInboundSilence = n)
                                }
                                e.lastMessageInAt = t.timeStamp
                            }
                        }

                        function rO(e) {
                            return ne(e) && e < 0 ? void 0 : e
                        }

                        function rI(e, t, n, r, i, o) {
                            let a, s = function(e, t, n, r) {
                                    return new eC(i => {
                                        let o, a = [],
                                            s = 0;
                                        return a.push(t.subscribe(e => {
                                            e.every(rN) || u()
                                        }), n.subscribe(u), nR({
                                            type: "resource"
                                        }).subscribe(e => {
                                            e.some(e => !rx(r, e.name)) && u()
                                        }), e.subscribe(7, e => {
                                            rx(r, e.url) || (void 0 === o && (o = e.requestIndex), s += 1, u())
                                        }), e.subscribe(8, e => {
                                            rx(r, e.url) || void 0 === o || e.requestIndex < o || (s -= 1, u())
                                        })), () => {
                                            a.forEach(e => e.unsubscribe())
                                        };

                                        function u() {
                                            i.notify({
                                                isBusy: s > 0
                                            })
                                        }
                                    })
                                }(e, t, n, r),
                                u = !1,
                                c = eI(eS(() => p({
                                    hadActivity: !1
                                })), 100),
                                l = void 0 !== o ? eI(eS(() => p({
                                    hadActivity: !0,
                                    end: q()
                                })), o) : void 0,
                                d = s.subscribe(({
                                    isBusy: e
                                }) => {
                                    ex(c), ex(a);
                                    let t = q();
                                    e || (a = eI(eS(() => p({
                                        hadActivity: !0,
                                        end: t
                                    })), 100))
                                }),
                                f = () => {
                                    u = !0, ex(c), ex(a), ex(l), d.unsubscribe()
                                };

                            function p(e) {
                                u || (f(), i(e))
                            }
                            return {
                                stop: f
                            }
                        }

                        function rx(e, t) {
                            return n6(e.excludedActivityUrls, t)
                        }

                        function rN(e) {
                            let t = "characterData" === e.type ? e.target.parentElement : e.target;
                            return !!(t && nO(t) && t.matches("[data-dd-excluded-activity-mutations], [data-dd-excluded-activity-mutations] *"))
                        }

                        function rM({
                            lifeCycle: e,
                            isChildEvent: t,
                            onChange: n = eD
                        }) {
                            let r = {
                                    errorCount: 0,
                                    longTaskCount: 0,
                                    resourceCount: 0,
                                    actionCount: 0,
                                    frustrationCount: 0
                                },
                                i = e.subscribe(14, e => {
                                    if ("view" !== e.type && "vital" !== e.type && t(e)) switch (e.type) {
                                        case w.ERROR:
                                            r.errorCount += 1, n();
                                            break;
                                        case w.ACTION:
                                            r.actionCount += 1, e.action.frustration && (r.frustrationCount += e.action.frustration.type.length), n();
                                            break;
                                        case w.LONG_TASK:
                                            r.longTaskCount += 1, n();
                                            break;
                                        case w.RESOURCE:
                                            e._dd ? .discarded || (r.resourceCount += 1, n())
                                    }
                                });
                            return {
                                stop: () => {
                                    i.unsubscribe()
                                },
                                eventCounts: r
                            }
                        }
                        let rL = 3e5;

                        function rD(e) {
                            let t = nv({
                                    expireDelay: rL
                                }),
                                n = new Map;

                            function r(e) {
                                n.delete(e.key), e.eventCounts ? .stop()
                            }

                            function i() {
                                n.forEach(e => {
                                    r(e)
                                }), t.reset()
                            }
                            let o = e.subscribe(11, i);
                            return {
                                start: function(i, o, a, s) {
                                    let u = et(),
                                        c = t.add(u, o.relative),
                                        l = n.get(i);
                                    l && r(l);
                                    let d = {
                                        id: u,
                                        key: i,
                                        startClocks: o,
                                        data: a,
                                        historyEntry: c,
                                        eventCounts: s ? .isChildEvent ? rM({
                                            lifeCycle: e,
                                            isChildEvent: s.isChildEvent(u)
                                        }) : void 0
                                    };
                                    return n.set(i, d), d
                                },
                                stop: function(e, t, i) {
                                    var o;
                                    let a = n.get(e);
                                    if (!a) return;
                                    let s = i ? tN(a.data, i) : a.data;
                                    a.historyEntry.close(t.relative);
                                    let u = (o = a.startClocks.timeStamp, t.timeStamp - o),
                                        c = a.eventCounts ? .eventCounts;
                                    return r(a), { ...s,
                                        id: a.id,
                                        startClocks: a.startClocks,
                                        duration: u,
                                        counts: c
                                    }
                                },
                                discard: function(e) {
                                    let t = n.get(e);
                                    if (!t) return;
                                    let i = t.eventCounts ? .eventCounts;
                                    return r(t), t.historyEntry.remove(), { ...t.data,
                                        id: t.id,
                                        startClocks: t.startClocks,
                                        counts: i
                                    }
                                },
                                getCounts: function(e) {
                                    return n.get(e) ? .eventCounts ? .eventCounts
                                },
                                findId: function(e) {
                                    return t.findAll(e)
                                },
                                stopAll: function() {
                                    o.unsubscribe(), i(), t.stop()
                                }
                            }
                        }
                        let rP = ["HTML", "BODY"],
                            rU = nM.concat(["role", "type", "disabled", "readonly", "tabindex", "draggable", "target", "rel", "download", "method", "action", "enctype", "autocomplete"]);

                        function r$(e, t) {
                            let n = function(e, t) {
                                let n = e;
                                for (; n;) {
                                    if (n.matches(t)) return n;
                                    n = nx(n)
                                }
                                return null
                            }(e, `[${t}]`);
                            if (n) return rG(rH(n.getAttribute(t).trim()))
                        }
                        let rV = [(e, t, n) => {
                                if ("labels" in e && e.labels && e.labels.length > 0) return rK(e.labels[0], t, n)
                            }, e => {
                                if ("INPUT" === e.nodeName) {
                                    let t = e.getAttribute("type");
                                    if ("button" === t || "submit" === t || "reset" === t) return {
                                        name: e.value,
                                        nameSource: "text_content"
                                    }
                                }
                            }, (e, t, n) => {
                                if ("BUTTON" === e.nodeName || "LABEL" === e.nodeName || "button" === e.getAttribute("role")) return rK(e, t, n)
                            }, (e, t, n) => rj(e, "aria-label", t, n), (e, t, n) => {
                                let r = e.getAttribute("aria-labelledby");
                                if (r) return {
                                    name: r.split(/\s+/).map(t => (function(e, t) {
                                        let n = e.getRootNode();
                                        if (n instanceof ShadowRoot) {
                                            let e = n.getElementById(t);
                                            if (e) return e
                                        }
                                        return e.ownerDocument ? e.ownerDocument.getElementById(t) : null
                                    })(e, t)).filter(e => !!e).map(e => rB(e, t, n)).join(" "),
                                    nameSource: "text_content"
                                }
                            }, (e, t, n) => rj(e, "alt", t, n), (e, t, n) => rj(e, "name", t, n), (e, t, n) => rj(e, "title", t, n), (e, t, n) => rj(e, "placeholder", t, n), (e, t, n) => {
                                if ("options" in e && e.options.length > 0) return rK(e.options[0], t, n)
                            }],
                            rq = [(e, t, n) => rK(e, t, n)];

                        function rF(e, t, n, r) {
                            let i = e,
                                o = 0;
                            for (; o <= 10 && i && "BODY" !== i.nodeName && "HTML" !== i.nodeName && "HEAD" !== i.nodeName;) {
                                for (let e of t) {
                                    let t = e(i, n, r);
                                    if (t) {
                                        let {
                                            name: e,
                                            nameSource: n
                                        } = t, r = e ? .trim();
                                        if (r) return {
                                            name: rG(rH(r)),
                                            nameSource: n
                                        }
                                    }
                                }
                                if ("FORM" === i.nodeName) break;
                                i = nx(i), o += 1
                            }
                        }

                        function rH(e) {
                            return e.replace(/\s+/g, " ")
                        }

                        function rG(e) {
                            return e.length > 100 ? `${ei(e,100)} [...]` : e
                        }

                        function rj(e, t, n, r) {
                            let {
                                enablePrivacyForActionName: i,
                                defaultPrivacyLevel: o
                            } = n, a = e.getAttribute(t);
                            if (a && i) {
                                var s, u;
                                let i = nJ(e, o, r);
                                (function(e, t, n, r, i) {
                                    if (r !== nW.MASK && r !== nW.MASK_UNLESS_ALLOWLISTED || "data-dd-privacy" === t || nM.includes(t) || t === i.actionNameAttribute) return !1;
                                    switch (t) {
                                        case "title":
                                        case "alt":
                                        case "placeholder":
                                        case "aria-label":
                                        case "name":
                                            return !0
                                    }
                                    return !!("A" === e && "href" === t || "IFRAME" === e && "srcdoc" === t || n && t.startsWith("data-")) || ("IMG" === e || "SOURCE" === e) && ("src" === t || "srcset" === t)
                                })(e.tagName, t, a, i, n) && (s = a, u = nN, a = nZ(s) ? s : u || s.replace(/\S/g, "x"))
                            } else a || (a = "");
                            return {
                                name: a,
                                nameSource: "standard_attribute"
                            }
                        }

                        function rK(e, t, n) {
                            return {
                                name: rB(e, t, n) || "",
                                nameSource: "text_content"
                            }
                        }

                        function rB(e, t, n) {
                            if (e.isContentEditable) return;
                            let {
                                enablePrivacyForActionName: r,
                                actionNameAttribute: i,
                                defaultPrivacyLevel: o
                            } = t, a = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, function(e) {
                                let t = nJ(e, o, n);
                                if (r && t && function(e, t) {
                                        switch (t) {
                                            case nW.MASK:
                                            case nW.HIDDEN:
                                            case nW.IGNORE:
                                                return !0;
                                            case nW.MASK_UNLESS_ALLOWLISTED:
                                                if (nk(e)) return !!nX(e.parentNode) || !nZ(e.textContent || "");
                                                return nX(e);
                                            case nW.MASK_USER_INPUT:
                                                return nk(e) ? nX(e.parentNode) : nX(e);
                                            default:
                                                return !1
                                        }
                                    }(e, t)) return NodeFilter.FILTER_REJECT;
                                if (nO(e)) {
                                    if (e.hasAttribute("data-dd-action-name") || i && e.hasAttribute(i)) return NodeFilter.FILTER_REJECT;
                                    let t = getComputedStyle(e);
                                    if ("visible" !== t.visibility || "none" === t.display || t.contentVisibility && "visible" !== t.contentVisibility) return NodeFilter.FILTER_REJECT
                                }
                                return NodeFilter.FILTER_ACCEPT
                            }), s = "";
                            for (; a.nextNode();) {
                                let e = a.currentNode;
                                if (nO(e)) {
                                    ("BR" === e.nodeName || "P" === e.nodeName || ["block", "flex", "grid", "list-item", "table", "table-caption"].includes(getComputedStyle(e).display)) && (s += " ");
                                    continue
                                }
                                s += e.textContent || ""
                            }
                            return s.replace(/\s+/g, " ").trim()
                        }

                        function rW() {
                            let e = window.getSelection();
                            return !e || e.isCollapsed
                        }

                        function rz(e) {
                            return e.target instanceof Element && !1 !== e.isPrimary
                        }

                        function rY(e) {
                            if ((2 & e.ignore) != 0 || e.hasPageActivity || e.getUserActivity().input || e.getUserActivity().scroll) return !1;
                            let t = e.event.target;
                            return "LABEL" === t.tagName && t.hasAttribute("for") && (t = document.getElementById(t.getAttribute("for"))), !t ? .matches('input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="range"]),textarea,select,[contenteditable],[contenteditable] *,canvas,a[href],a[href] *')
                        }
                        let rJ = new Map;

                        function rX(e, t) {
                            rJ.set(e, t), rJ.forEach((e, t) => {
                                H() - t > 1e4 && rJ.delete(t)
                            })
                        }

                        function rZ(e) {
                            return t => t.action ? .id ? .includes(e) ? ? !1
                        }

                        function rQ(e) {
                            var t;
                            if (e.composed && nO(t = e.target) && t.shadowRoot && "function" == typeof e.composedPath) {
                                let t = e.composedPath();
                                if (t.length > 0 && t[0] instanceof Element) return t[0]
                            }
                            return e.target
                        }

                        function r0(e) {
                            let t = "events" in e,
                                n = rO(F(e.duration));
                            return {
                                rawRumEvent: {
                                    type: w.ACTION,
                                    date: e.startClocks.timeStamp,
                                    action: {
                                        id: e.id,
                                        target: {
                                            name: e.name
                                        },
                                        type: e.type,
                                        ...void 0 !== n && {
                                            loading_time: n
                                        },
                                        ...e.counts && {
                                            error: {
                                                count: e.counts.errorCount
                                            },
                                            long_task: {
                                                count: e.counts.longTaskCount
                                            },
                                            resource: {
                                                count: e.counts.resourceCount
                                            }
                                        },
                                        frustration: {
                                            type: e.frustrationTypes
                                        }
                                    },
                                    ...t ? {
                                        _dd: {
                                            action: {
                                                target: {
                                                    selector: e.target ? .selector || void 0,
                                                    width: e.target ? .width || void 0,
                                                    height: e.target ? .height || void 0,
                                                    composed_path_selector: e.target ? .composedPathSelector
                                                },
                                                position: e.position,
                                                name_source: e.nameSource
                                            }
                                        }
                                    } : {
                                        context: e.context
                                    }
                                },
                                duration: e.duration,
                                startClocks: e.startClocks,
                                domainContext: t ? {
                                    events: e.events
                                } : {
                                    handlingStack: e.handlingStack
                                }
                            }
                        }
                        let r1 = {
                            intervention: "intervention",
                            cspViolation: "csp_violation"
                        };

                        function r3(e) {
                            return {
                                startClocks: G(),
                                source: ri.REPORT,
                                handling: "unhandled",
                                ...e
                            }
                        }

                        function r2(e, t, n, r, i) {
                            return n ? eY({
                                name: e,
                                message: t,
                                stack: [{
                                    func: "?",
                                    url: n,
                                    line: r ? ? void 0,
                                    column: i ? ? void 0
                                }]
                            }) : void 0
                        }

                        function r4() {
                            if (nT("navigation")) {
                                let e = performance.getEntriesByType("navigation")[0];
                                if (e && !(e.loadEventEnd > 0 && e.domComplete <= 0)) return e
                            }
                            let e = function() {
                                    let e = {},
                                        t = performance.timing;
                                    for (let n in t)
                                        if (ne(t[n])) {
                                            let r = t[n];
                                            e[n] = 0 === r ? 0 : r - W()
                                        }
                                    return e
                                }(),
                                t = {
                                    entryType: "navigation",
                                    initiatorType: "navigation",
                                    name: window.location.href,
                                    startTime: 0,
                                    duration: e.loadEventEnd,
                                    decodedBodySize: 0,
                                    encodedBodySize: 0,
                                    transferSize: 0,
                                    workerStart: 0,
                                    toJSON: () => ({ ...t,
                                        toJSON: void 0
                                    }),
                                    ...e
                                };
                            return t
                        }

                        function r5(e) {
                            return e.responseStart >= 0 && e.responseStart <= H() ? e.responseStart : void 0
                        }
                        let r6 = 12e4;

                        function r8(e, t) {
                            let n = t && Number(t);
                            if (e && n) return {
                                traceId: e,
                                traceTime: n
                            }
                        }

                        function r7(e) {
                            if (e && e.nodeType === Node.COMMENT_NODE) {
                                let t = /^\s*DATADOG;(.*?)\s*$/.exec(e.data);
                                if (t) return t[1]
                            }
                        }

                        function r9(e, t) {
                            return document.readyState === e || "complete" === document.readyState ? (t(), {
                                stop: eD
                            }) : tf(window, "complete" === e ? "load" : "DOMContentLoaded", t, {
                                once: !0
                            })
                        }

                        function ie(e, t, n) {
                            var r, i;
                            let o = t ? function(e, t) {
                                if (e.traceSampled && e.traceId && e.spanId) return {
                                    _dd: {
                                        span_id: e.spanId.toString(),
                                        trace_id: e.traceId.toString(),
                                        rule_psr: t.rulePsr
                                    }
                                }
                            }(t, n) : function(e, t) {
                                if ("navigation" !== e.initiatorType) return;
                                let n = function(e) {
                                    let t = function(e) {
                                        let t = e.querySelector("meta[name=dd-trace-id]"),
                                            n = e.querySelector("meta[name=dd-trace-time]");
                                        return r8(t ? .content, n ? .content)
                                    }(e) || function(e) {
                                        let t = function(e) {
                                            for (let t = 0; t < e.childNodes.length; t += 1) {
                                                let n = r7(e.childNodes[t]);
                                                if (n) return n
                                            }
                                            if (e.body)
                                                for (let t = e.body.childNodes.length - 1; t >= 0; t -= 1) {
                                                    let n = e.body.childNodes[t],
                                                        r = r7(n);
                                                    if (r) return r;
                                                    if (!nk(n)) break
                                                }
                                        }(e);
                                        if (t) return r8(er(t, "trace-id"), er(t, "trace-time"))
                                    }(e);
                                    if (!(!t || t.traceTime <= W() - r6)) return t.traceId
                                }(document);
                                if (n) return {
                                    _dd: {
                                        trace_id: n,
                                        span_id: n4(63).toString(),
                                        rule_psr: t.rulePsr
                                    }
                                }
                            }(e, n);
                            if (!n.trackResources && !o) return;
                            let a = K(e.startTime),
                                s = function(e) {
                                    let {
                                        duration: t,
                                        startTime: n,
                                        responseEnd: r
                                    } = e;
                                    return "navigation" === e.initiatorType || 0 === t && n < r ? r - n : t
                                }(e),
                                u = function(e, t) {
                                    let n = t.trackResourceHeaders;
                                    if (0 === n.length || !e) return;
                                    let r = n.filter(t => void 0 === t.url || n6([t.url], e.url, !0));
                                    if (0 === r.length) return;
                                    let i = r.filter(e => void 0 === e.location || "any" === e.location || "response" === e.location),
                                        o = r.filter(e => void 0 === e.location || "any" === e.location || "request" === e.location),
                                        a = i.length > 0 ? function(e, t) {
                                            if (e.type === nb.FETCH && e.response) return ii(e.response.headers, t);
                                            if (e.type === nb.XHR && e.xhr) {
                                                let n = e.xhr.getAllResponseHeaders();
                                                if (n) try {
                                                    return ii(new Headers(function(e) {
                                                        let t = [];
                                                        for (let n of e.trim().split(/\r\n/)) {
                                                            let e = n.indexOf(":");
                                                            e > 0 && t.push([n.substring(0, e).trim(), n.substring(e + 1).trim()])
                                                        }
                                                        return t
                                                    }(n)), t)
                                                } catch {}
                                            }
                                        }(e, i) : void 0,
                                        s = o.length > 0 ? function(e, t) {
                                            let n;
                                            if (e.type === nb.FETCH) return e.init ? .headers ? n = new Headers(e.init.headers) : e.input instanceof Request && (n = e.input.headers), n ? ii(n, t) : void 0
                                        }(e, o) : void 0;
                                    if (a || s) return {
                                        resource: {
                                            request: s ? {
                                                headers: s
                                            } : void 0,
                                            response: a ? {
                                                headers: a
                                            } : void 0
                                        }
                                    }
                                }(t, n);
                            return {
                                startClocks: a,
                                duration: s,
                                rawRumEvent: tN({
                                    date: a.timeStamp,
                                    resource: {
                                        id: et(),
                                        duration: F(s),
                                        type: function(e) {
                                            let t = e.name;
                                            if (! function(e) {
                                                    try {
                                                        return !!tR(e)
                                                    } catch {
                                                        return !1
                                                    }
                                                }(t)) return nh.OTHER;
                                            let n = function(e) {
                                                let t = tR(e).pathname;
                                                return "/" === t[0] ? t : `/${t}`
                                            }(t);
                                            for (let [t, r] of nS)
                                                if (r(e.initiatorType, n)) return t;
                                            return nh.OTHER
                                        }(e),
                                        method: t ? .method,
                                        status_code: t ? t.status : 0 === (r = e.responseStatus) ? void 0 : r,
                                        url: t ? nA(t.url) : e.name,
                                        protocol: "" === e.nextHopProtocol ? void 0 : e.nextHopProtocol,
                                        delivery_type: "" === e.deliveryType ? "other" : e.deliveryType,
                                        graphql: t && function(e, t) {
                                            let n = n9(e.url, t);
                                            if (n) {
                                                let t = function(e, t = !1) {
                                                    let n;
                                                    if ("POST" === e.method ? n = function(e) {
                                                            if (!e || "string" != typeof e) return;
                                                            let t = Z(e);
                                                            if (t) return {
                                                                query: t.query,
                                                                operationName: t.operationName,
                                                                variables: t.variables ? JSON.stringify(t.variables) : void 0,
                                                                operationType: t.operationType
                                                            }
                                                        }(e.requestBody) : "GET" === e.method && (n = function(e) {
                                                            let t = tR(e).searchParams,
                                                                n = t.get("variables"),
                                                                r = n && void 0 !== Z(n) ? n : void 0;
                                                            return {
                                                                query: t.get("query") || void 0,
                                                                operationName: t.get("operationName") || void 0,
                                                                variables: r,
                                                                operationType: t.get("operationType") || void 0
                                                            }
                                                        }(e.url)), n) return function(e, t) {
                                                        let n, r, i;
                                                        if (e.query) {
                                                            var o;
                                                            let i = e.query.trim();
                                                            o = i, n = o.match(/^\s*(query|mutation|subscription)\b/i) ? .[1], t && (r = ei(i, 32768, "..."))
                                                        }
                                                        if (!n) {
                                                            let t = e.operationType;
                                                            ("query" === t || "mutation" === t || "subscription" === t) && (n = t)
                                                        }
                                                        return e.variables && (i = e.variables), {
                                                            operationType: n,
                                                            operationName: e.operationName,
                                                            variables: i,
                                                            payload: r
                                                        }
                                                    }(n, t)
                                                }(e, n.trackPayload);
                                                if (t) {
                                                    if (n.trackResponseErrors && e.responseBody) {
                                                        let n = function(e) {
                                                            let t = Z(e);
                                                            if (t && "object" == typeof t && nt(t.errors)) return t.errors.map(e => ({
                                                                message: e.message,
                                                                path: e.path,
                                                                locations: e.locations,
                                                                code: e.extensions ? .code
                                                            }))
                                                        }(e.responseBody);
                                                        n && (t.error_count = n.length, t.errors = n)
                                                    }
                                                    return t
                                                }
                                                return
                                            }
                                        }(t, n),
                                        render_blocking_status: e.renderBlockingStatus,
                                        ... function(e) {
                                            if (e.startTime < e.responseStart) {
                                                let {
                                                    encodedBodySize: t,
                                                    decodedBodySize: n,
                                                    transferSize: r
                                                } = e;
                                                return {
                                                    size: n,
                                                    encoded_body_size: t,
                                                    decoded_body_size: n,
                                                    transfer_size: r
                                                }
                                            }
                                            return {
                                                size: void 0,
                                                encoded_body_size: void 0,
                                                decoded_body_size: void 0,
                                                transfer_size: void 0
                                            }
                                        }(e),
                                        ... function(e) {
                                            if (! function(e) {
                                                    var t;
                                                    let n = n_(e.startTime, e.fetchStart, e.domainLookupStart, e.domainLookupEnd, e.connectStart, e.connectEnd, e.requestStart, e.responseStart, e.responseEnd),
                                                        r = !((t = e).redirectEnd > t.startTime) || n_(e.startTime, e.redirectStart, e.redirectEnd, e.fetchStart);
                                                    return n && r
                                                }(e)) return;
                                            let {
                                                startTime: t,
                                                fetchStart: n,
                                                workerStart: r,
                                                redirectStart: i,
                                                redirectEnd: o,
                                                domainLookupStart: a,
                                                domainLookupEnd: s,
                                                connectStart: u,
                                                secureConnectionStart: c,
                                                connectEnd: l,
                                                requestStart: d,
                                                responseStart: f,
                                                responseEnd: p
                                            } = e, m = {
                                                download: nE(t, f, p),
                                                first_byte: nE(t, d, f)
                                            };
                                            return 0 < r && r < n && (m.worker = nE(t, r, n)), n < l && (m.connect = nE(t, u, l), u <= c && c <= l && (m.ssl = nE(t, c, l))), n < s && (m.dns = nE(t, a, s)), t < o && (m.redirect = nE(t, i, o)), m
                                        }(e)
                                    },
                                    type: w.RESOURCE,
                                    _dd: {
                                        discarded: !n.trackResources
                                    }
                                }, o, function(e) {
                                    let t = e.contentType;
                                    if (t) return {
                                        resource: {
                                            response: {
                                                headers: {
                                                    "content-type": t
                                                }
                                            }
                                        }
                                    }
                                }(e), u),
                                domainContext: {
                                    performanceEntry: e,
                                    isManual: !1,
                                    isAborted: !!(i = t) && i.isAborted,
                                    isWebSocket: !1,
                                    handlingStack: i ? .handlingStack,
                                    requestInit: i ? .init,
                                    requestInput: i ? .input,
                                    response: i ? .response,
                                    error: i ? .error,
                                    xhr: i ? .xhr
                                }
                            }
                        }
                        let it = /(token|cookie|secret|authorization|(api|secret|access|app).?key|(client|connecting|real).?ip|forwarded)/,
                            ir = e => ns.includes(e);

                        function ii(e, t) {
                            let n = {},
                                r = 0,
                                i = !1;
                            return e.forEach((e, o) => {
                                if (r >= 100) {
                                    i || (ep.warn("Maximum number of headers (100) has been reached. Further headers are dropped."), i = !0);
                                    return
                                }
                                let a = o.toLowerCase();
                                if (it.test(a)) return;
                                let s = t.find(e => n6([e.name ? ? ir], a));
                                if (!s) return;
                                let {
                                    extractor: u
                                } = s, c = u ? O(e, u) : e;
                                void 0 !== c && (c.length > 128 && ep.warn(`Header "${a}" value was truncated from ${c.length} to 128 characters.`), n[a] = ei(c, 128), r++)
                            }), r > 0 ? n : void 0
                        }
                        let io = 6e5,
                            ia = 6e5;

                        function is(e, t = window) {
                            if ("hidden" === document.visibilityState) return {
                                timeStamp: 0,
                                stop: eD
                            };
                            if (nT("visibility-state")) {
                                let t = performance.getEntriesByType("visibility-state").filter(e => "hidden" === e.name).find(t => t.startTime >= e.relative);
                                if (t) return {
                                    timeStamp: t.startTime,
                                    stop: eD
                                }
                            }
                            let n = 1 / 0,
                                {
                                    stop: r
                                } = tp(t, [td.PAGE_HIDE, td.VISIBILITY_CHANGE], e => {
                                    (e.type === td.PAGE_HIDE || "hidden" === document.visibilityState) && (n = e.timeStamp, r())
                                }, {
                                    capture: !0
                                });
                            return {
                                get timeStamp() {
                                    return n
                                },
                                stop: r
                            }
                        }
                        let iu = e => {
                            let t = e.previousRect.width * e.previousRect.height;
                            return t + e.currentRect.width * e.currentRect.height - ((e, t) => {
                                let n = Math.max(e.left, t.left),
                                    r = Math.max(e.top, t.top),
                                    i = Math.min(e.right, t.right),
                                    o = Math.min(e.bottom, t.bottom);
                                return n >= i || r >= o ? 0 : (i - n) * (o - r)
                            })(e.previousRect, e.currentRect)
                        };

                        function ic({
                            x: e,
                            y: t,
                            width: n,
                            height: r
                        }) {
                            return {
                                x: e,
                                y: t,
                                width: n,
                                height: r
                            }
                        }
                        let il = 0,
                            id = 1 / 0,
                            ip = 0,
                            im = () => v ? il : window.performance.interactionCount || 0,
                            ig = 6e4;

                        function iy(e) {
                            return Math.min(e, ig)
                        }

                        function iv() {
                            let e = window.visualViewport;
                            return e ? {
                                width: Number(e.width * e.scale),
                                height: Number(e.height * e.scale)
                            } : {
                                width: Number(window.innerWidth || 0),
                                height: Number(window.innerHeight || 0)
                            }
                        }

                        function ih(e, t, n) {
                            let r = { ...e
                            };
                            for (let [e, {
                                    required: i,
                                    type: o
                                }] of Object.entries(t)) "string" !== o || ib(r[e]) || (r[e] = String(r[e])), i && ib(r[e]) && ep.warn(`The property ${e} of ${n} is required; context will not be sent to the intake.`);
                            return r
                        }

                        function ib(e) {
                            return null == e || "" === e
                        }

                        function iS(e = "", {
                            propertiesConfig: t = {}
                        } = {}) {
                            let n = {},
                                r = new eC,
                                i = {
                                    getContext: () => tx(n),
                                    setContext: o => {
                                        ! function(e) {
                                            let t = "object" === z(e);
                                            return t || ep.error("Unsupported context:", e), t
                                        }(o) ? i.clearContext(): n = rs(ih(o, t, e)), r.notify()
                                    },
                                    setContextProperty: (i, o) => {
                                        n = rs(ih({ ...n,
                                            [i]: o
                                        }, t, e)), r.notify()
                                    },
                                    removeContextProperty: i => {
                                        delete n[i], ih(n, t, e), r.notify()
                                    },
                                    clearContext: () => {
                                        n = {}, r.notify()
                                    },
                                    changeObservable: r
                                };
                            return i
                        }
                        let i_ = 3e5,
                            iE = 3e5;

                        function iw(e) {
                            let t = e.indexOf("?");
                            return t < 0 ? e : e.slice(0, t)
                        }

                        function iC(e, t) {
                            let n = new Set;
                            for (let r of e) r.startsWith(`${t}.`) && n.add(r.slice(t.length + 1));
                            return n
                        }
                        let iA = function(e) {
                            return e[e.REPLAY = 1] = "REPLAY", e[e.RUM = 2] = "RUM", e[e.TELEMETRY = 4] = "TELEMETRY", e[e.PROFILING = 6] = "PROFILING", e
                        }({});

                        function iR() {
                            return eg.location
                        }

                        function iT(e) {
                            return Object.prototype.hasOwnProperty.call(history, e) ? history : History.prototype
                        }

                        function ik() {
                            0 !== b.batchCount && (tK(tq.CUSTOMER_DATA_METRIC_NAME, b), ix())
                        }

                        function iO() {
                            return {
                                min: 1 / 0,
                                max: 0,
                                sum: 0
                            }
                        }

                        function iI(e, t) {
                            e.sum += t, e.min = Math.min(e.min, t), e.max = Math.max(e.max, t)
                        }

                        function ix() {
                            b = {
                                batchCount: 0,
                                batchBytesCount: iO(),
                                batchMessagesCount: iO()
                            }
                        }

                        function iN() {
                            return "hidden" === document.visibilityState ? "hidden" : document.hasFocus() ? "active" : "passive"
                        }

                        function iM(e) {
                            let {
                                startClocks: t,
                                type: n,
                                name: r,
                                description: i,
                                context: o,
                                handlingStack: a
                            } = e, s = {
                                id: (e.type === k.DURATION ? e.id : void 0) ? ? et(),
                                type: n,
                                name: r,
                                description: i,
                                ...n === k.DURATION ? {
                                    duration: F(e.duration)
                                } : {
                                    step_type: e.stepType,
                                    operation_key: e.operationKey,
                                    failure_reason: e.failureReason
                                }
                            };
                            return {
                                rawRumEvent: {
                                    date: t.timeStamp,
                                    vital: s,
                                    type: w.VITAL,
                                    context: o
                                },
                                startClocks: t,
                                duration: n === k.DURATION ? e.duration : void 0,
                                domainContext: a ? {
                                    handlingStack: a
                                } : {}
                            }
                        }
                        async function iL(e, t) {
                            let n = `dd_cookie_test_${et()}`,
                                r = "test",
                                i = e(n, t);
                            try {
                                return await i.getAllAndSet(() => ({
                                    value: r,
                                    expireDelay: 6e4
                                })), (await i.getAll()).includes(r)
                            } catch (e) {
                                return ep.error(e), !1
                            } finally {
                                try {
                                    await i.delete()
                                } catch {}
                            }
                        }

                        function iD(e, t) {
                            let n = eg.cookieStore,
                                r = new eC(() => tf(n, "change", t => {
                                    (t.changed.some(t => t.name === e) || t.deleted.some(t => t.name === e)) && r.notify()
                                }).stop);
                            return {
                                getAll: async () => (await n.getAll(e)).map(e => e.value),
                                delete: () => n.delete({
                                    name: e,
                                    domain: t.domain,
                                    path: "/",
                                    partitioned: t.partitioned
                                }),
                                async getAllAndSet(r) {
                                    let i = await n.getAll(e),
                                        {
                                            value: o,
                                            expireDelay: a
                                        } = r(i.map(e => e.value));
                                    try {
                                        await n.set({
                                            name: e,
                                            value: o,
                                            expires: V() + a,
                                            path: "/",
                                            sameSite: t.crossSite ? "none" : "strict",
                                            domain: t.domain,
                                            secure: t.secure,
                                            partitioned: t.partitioned
                                        })
                                    } catch (n) {
                                        if (!e.startsWith("dd_cookie_test_")) {
                                            let r = tY(e);
                                            tG("Failed to set cookie using Cookie Store API", {
                                                "error.message": n.message,
                                                newValue: o,
                                                cookieOptions: { ...t
                                                },
                                                cookies: i.map(e => ({ ...e
                                                })),
                                                cookieCount: i.length,
                                                documentCookies: r
                                            })
                                        }
                                    }
                                },
                                observable: r
                            }
                        }

                        function iP(e, t) {
                            let n = tY(e),
                                r = new eC(() => {
                                    let t = eN(() => {
                                        i(tY(e))
                                    }, 1e3);
                                    return () => {
                                        eM(t)
                                    }
                                });

                            function i(e) {
                                String(e) !== String(n) && (n = e, r.notify())
                            }
                            return {
                                getAll: () => Promise.resolve(tY(e)),
                                async getAllAndSet(n) {
                                    let {
                                        value: r,
                                        expireDelay: o
                                    } = n(tY(e));
                                    tW(e, r, o, t), await Promise.resolve(), i([r])
                                },
                                async delete() {
                                    tW(e, "", 0, t), await Promise.resolve(), i([])
                                },
                                observable: r
                            }
                        }

                        function iU() {
                            let e = eg.cookieStore;
                            return !!(e && tm(e, "change"))
                        }

                        function i$(e, t) {
                            let n = tz(e),
                                r = eN(() => {
                                    let r = tz(e);
                                    r !== n && (n = r, t(r))
                                }, 1e3);
                            return () => {
                                eM(r)
                            }
                        }
                        let iV = "datadog-synthetics-",
                            iq = `${iV}public-id`,
                            iF = `${iV}result-id`,
                            iH = `${iV}injects-rum`,
                            iG = `${iV}rum-context`;

                        function ij() {
                            return !ey && !!(eg._DATADOG_SYNTHETICS_INJECTS_RUM || tJ(iH))
                        }

                        function iK() {
                            var e;
                            let t = function() {
                                let e = eg._DATADOG_SYNTHETICS_RUM_CONTEXT;
                                if (e) return e;
                                let t = tJ(iG);
                                return t ? Z(decodeURIComponent(t)) : {
                                    test_id: window._DATADOG_SYNTHETICS_PUBLIC_ID || tJ(iq),
                                    result_id: window._DATADOG_SYNTHETICS_RESULT_ID || tJ(iF)
                                }
                            }();
                            return "object" == typeof(e = t) && null !== e && "string" == typeof e.test_id && "string" == typeof e.result_id ? t : void 0
                        }

                        function iB(e) {
                            return "object" === z(e)
                        }

                        function iW(e, t, n = 3e3) {
                            let r = 0,
                                i = !1;
                            return {
                                isLimitReached() {
                                    if (0 === r && eI(() => {
                                            r = 0
                                        }, 6e4), (r += 1) <= n || i) return i = !1, !1;
                                    if (r === n + 1) {
                                        i = !0;
                                        try {
                                            t(`Reached max number of ${e}s by minute: ${n}`)
                                        } finally {
                                            i = !1
                                        }
                                    }
                                    return !0
                                }
                            }
                        }
                        let iz = {
                                "view.name": "string",
                                "view.url": "string",
                                "view.referrer": "string",
                                context: "object",
                                service: "string",
                                version: "string"
                            },
                            iY = {
                                [w.VIEW]: { ...iz,
                                    "view.performance.lcp.resource_url": "string"
                                },
                                [w.ERROR]: { ...iz,
                                    "error.message": "string",
                                    "error.stack": "string",
                                    "error.handling_stack": "string",
                                    "error.resource.url": "string",
                                    "error.fingerprint": "string",
                                    "_dd.debug_ids": "array"
                                },
                                [w.RESOURCE]: { ...iz,
                                    "resource.url": "string",
                                    "resource.graphql.variables": "string",
                                    "resource.request.headers": "object",
                                    "resource.response.headers": "object",
                                    "resource.websocket.close_reason": "string",
                                    "resource.websocket.protocol": "string"
                                },
                                [w.ACTION]: { ...iz,
                                    "action.target.name": "string"
                                },
                                [w.LONG_TASK]: { ...iz,
                                    "long_task.scripts[].source_url": "string",
                                    "long_task.scripts[].invoker": "string",
                                    "_dd.debug_ids": "array"
                                },
                                [w.VITAL]: iz
                            },
                            iJ = [w.ACTION, w.ERROR, w.LONG_TASK, w.RESOURCE, w.VITAL],
                            iX = "_dd_tab_id",
                            iZ = [];

                        function iQ(e, t, n) {
                            var r, i;
                            if ("undefined" == typeof window || "undefined" == typeof localStorage) return;
                            let o = (r = t, i = n, `_dd_c_${r}_${i}`);
                            iZ.push(tf(window, "storage", ({
                                key: t
                            }) => {
                                o === t && e.setContext(s())
                            })), e.changeObservable.subscribe(function() {
                                localStorage.setItem(o, JSON.stringify(e.getContext()))
                            });
                            let a = tN(s(), e.getContext());

                            function s() {
                                let e = localStorage.getItem(o);
                                return e ? Z(e) ? ? {} : {}
                            }
                            Q(a) || e.setContext(a)
                        }

                        function i0() {
                            return iS("global context")
                        }

                        function i1() {
                            return iS("user", {
                                propertiesConfig: {
                                    id: {
                                        type: "string"
                                    },
                                    name: {
                                        type: "string"
                                    },
                                    email: {
                                        type: "string"
                                    }
                                }
                            })
                        }

                        function i3() {
                            return iS("account", {
                                propertiesConfig: {
                                    id: {
                                        type: "string",
                                        required: !0
                                    },
                                    name: {
                                        type: "string"
                                    }
                                }
                            })
                        }

                        function i2(e) {
                            return !!e && "function" == typeof e.then
                        }

                        function i4(e, t, n, r) {
                            return eS((...i) => (r && tB({
                                feature: r
                            }), e()[t][n](...i)))
                        }

                        function i5(e, t, n) {
                            e.changeObservable.subscribe(() => {
                                let r = e.getContext();
                                n.notify(e => e[t].setContext(r))
                            })
                        }
                        let i6 = {
                                userContext: "userContext",
                                globalContext: "globalContext",
                                accountContext: "accountContext"
                            },
                            i8 = {
                                getContext: "getContext",
                                setContext: "setContext",
                                setContextProperty: "setContextProperty",
                                removeContextProperty: "removeContextProperty",
                                clearContext: "clearContext"
                            };

                        function i7(e, t) {
                            t.silentMultipleInit || ep.error(`${e} is already initialized.`)
                        }
                        let i9 = ["chrome-extension://", "moz-extension://"];

                        function oe(e) {
                            return i9.some(t => e.includes(t))
                        }
                        let ot = /^([a-zA-Z]+)=([a-z0-9-]+)$/;

                        function on(e) {
                            return e.created ? Number(e.created) : void 0
                        }

                        function or(e) {
                            let t = e.expire && Number(e.expire),
                                n = on(e);
                            if (t && n) return Math.min(t, n + nf)
                        }

                        function oi(e, t) {
                            let n = {
                                isExpired: "1"
                            };
                            return t.trackAnonymousUser && e ? .anonymousId && (n.anonymousId = e ? .anonymousId), n
                        }

                        function oo(e) {
                            return void 0 !== e.isExpired || ! function(e) {
                                let t = or(e);
                                return !!t && V() < t
                            }(e)
                        }

                        function oa(e) {
                            e.expire = String(V() + np)
                        }

                        function os(e) {
                            return tl(e).map(([e, t]) => "anonymousId" === e ? `aid=${t}` : `${e}=${t}`).join("&")
                        }

                        function ou(e) {
                            let t = {};
                            return e && (-1 !== e.indexOf("&") || ot.test(e)) && e.split("&").forEach(e => {
                                let n = ot.exec(e);
                                if (null !== n) {
                                    let [, e, r] = n;
                                    "aid" === e ? t.anonymousId = r : t[e] = r
                                }
                            }), t
                        }

                        function oc(e, t) {
                            return Q(e) ? (t.trackAnonymousUser && (e.anonymousId = et()), oi(e, t)) : e
                        }

                        function ol(e, t) {
                            if (Q(e)) return e;
                            let n = e;
                            return oo(e) && (n = oi(e, t)), n.id || (n.id = et(), n.created = String(V())), t.trackAnonymousUser && !n.anonymousId && (n.anonymousId = et()), delete n.isExpired, oa(n), n
                        }
                        let od = "_dd_s_v2",
                            of = "_dd_s";
                        async function op(e) {
                            let t = function(e) {
                                let t = {};
                                if (t.secure = e.useSecureSessionCookie || e.usePartitionedCrossSiteSessionCookie, t.crossSite = e.usePartitionedCrossSiteSessionCookie, t.partitioned = e.usePartitionedCrossSiteSessionCookie, e.trackSessionAcrossSubdomains) {
                                    let e = function(e = eg.location ? .hostname ? ? "", t = "undefined" != typeof document ? document.referrer : "") {
                                        if ("undefined" != typeof document) {
                                            if (void 0 === d) {
                                                let n = function(e, t) {
                                                    try {
                                                        return e || tR(t).hostname
                                                    } catch {}
                                                }(e, t);
                                                if (n) {
                                                    let e = `dd_site_test_${et()}`,
                                                        t = n.split("."),
                                                        r = t.pop();
                                                    for (; t.length && !tz(e);) tW(e, "test", 1e3, {
                                                        domain: r = `${t.pop()}.${r}`
                                                    });
                                                    tW(e, "", 0, {
                                                        domain: r
                                                    }), d = r
                                                }
                                            }
                                            return d
                                        }
                                    }();
                                    if (!e) return;
                                    t.domain = e
                                }
                                return t
                            }(e);
                            if (t) {
                                if (iU() && await iL(iD, t)) return {
                                    type: nm.COOKIE,
                                    cookieOptions: t,
                                    cookieApi: 1
                                };
                                if (await iL(iP, t)) return {
                                    type: nm.COOKIE,
                                    cookieOptions: t,
                                    cookieApi: 0
                                }
                            }
                        }

                        function om(e, t) {
                            let n;
                            for (let r of e.slice().reverse())
                                if ((n = ou(r)).c === t) break;
                            return delete n ? .c, n ? ? {}
                        }

                        function og(e) {
                            return ((e.domain ? e.domain.split(".").length - 1 : 0) << 1 | !!e.crossSite).toString(16)
                        }
                        let oy = "_DD_SESSION";
                        async function ov(e) {
                            var t;
                            for (let n of void 0 !== (t = e.sessionPersistence) ? t : ey ? [nm.MEMORY] : [nm.COOKIE]) {
                                let t = await
                                function(e, t) {
                                    switch (e) {
                                        case nm.COOKIE:
                                            return op(t);
                                        case nm.LOCAL_STORAGE:
                                            try {
                                                let e = et(),
                                                    t = `_dd_test_${e}`;
                                                localStorage.setItem(t, e);
                                                let n = localStorage.getItem(t);
                                                return localStorage.removeItem(t), e === n ? {
                                                    type: nm.LOCAL_STORAGE
                                                } : void 0
                                            } catch {
                                                return
                                            }
                                        case nm.MEMORY:
                                            return {
                                                type: nm.MEMORY
                                            };
                                        default:
                                            ep.error(`Invalid session persistence '${String(e)}'`);
                                            return
                                    }
                                }(n, e);
                                if (void 0 !== t) return t
                            }
                        }
                        let oh = 432e5,
                            ob = [];
                        async function oS(e, t) {
                            let n, r = H(),
                                i = new eC,
                                o = new eC,
                                a = await ov(e);
                            if (!a) return void ep.warn("No storage available for session. We will not send any data.");
                            let s = function(e, t) {
                                    switch (e.type) {
                                        case nm.COOKIE:
                                            return function(e, t) {
                                                var n, r;
                                                let {
                                                    cookieOptions: i,
                                                    cookieApi: o
                                                } = e, a = new eC, s = !!t.trackAnonymousUser, u = og(i), c = (n = o, r = i, 1 === n ? iD(od, r) : iP(od, r)), l = !0;

                                                function d(e) {
                                                    return c.getAllAndSet(t => {
                                                        var n, r;
                                                        let o = om(t, u);
                                                        return l && Q(o) && (o = om(tY( of ), u)), l = !1, {
                                                            value: (n = e(o), r = i, os(Q(n) ? n : { ...n,
                                                                c: og(r)
                                                            })),
                                                            expireDelay: s ? 31536e6 : nf
                                                        }
                                                    })
                                                }
                                                return c.observable.subscribe(() => {
                                                    c.getAll().then(e => {
                                                        a.notify(om(e, u))
                                                    }).catch(e => eE(Error(`Error while reading session cookies on change: ${e}`)))
                                                }), {
                                                    async setSessionState(e, t) {
                                                        "undefined" != typeof navigator && navigator.locks ? await navigator.locks.request(od, () => d(e)).catch(e => {
                                                            var t;
                                                            if (!((t = e) instanceof Error && ("AbortError" === t.name || t.message.includes("no longer runnable")))) throw e
                                                        }) : (E = (E ? ? Promise.resolve()).then(() => d(e)), await E)
                                                    },
                                                    sessionObservable: a
                                                }
                                            }(e, t);
                                        case nm.LOCAL_STORAGE:
                                            let n = new eC(e => tf(window, "storage", t => {
                                                    "_dd_s_v2" === t.key && t.storageArea === localStorage && e.notify(ou(t.newValue))
                                                }).stop),
                                                r = !0;
                                            return {
                                                async setSessionState(e, t) {
                                                    let i = ou(localStorage.getItem(od));
                                                    r && Q(i) && (i = ou(localStorage.getItem( of ))), r = !1;
                                                    let o = e(i);
                                                    localStorage.setItem(od, os(o)), await Promise.resolve(), n.notify(o)
                                                },
                                                sessionObservable: n
                                            };
                                        case nm.MEMORY:
                                            eg._DD_SESSION || (eg[oy] = {});
                                            let i = eg[oy],
                                                o = new eC,
                                                a = i.onChange;
                                            return i.onChange = e => {
                                                a ? .(e), o.notify(e)
                                            }, {
                                                async setSessionState(e, t) {
                                                    let n = { ...e(i.state ? ? {})
                                                    };
                                                    i.state = n, await Promise.resolve(), i.onChange ? .(n)
                                                },
                                                sessionObservable: o
                                            }
                                    }
                                }(a, e),
                                u = nv({
                                    maxEntries: 1e3
                                });
                            ob.push(() => u.stop());
                            let c = !1,
                                {
                                    throttled: l,
                                    cancel: d
                                } = eL(() => {
                                    c = !1, s.setSessionState(t => ol(t, e), "expandOrRenewOnActivity").catch(eE)
                                }, 1e3);
                            ob.push(d), ob.push(() => ex(n));
                            let f = !1;
                            ob.push(() => {
                                f = !0
                            });
                            let p = await m().catch(e => eE(Error(`Error while resolving initial session state: ${e}`)));
                            if (p && !f) {
                                for (; !t.isGranted();)
                                    if (v(), await new Promise(e => t.onGrantedOnce(e)), f || !(p = await m().catch(eE)) || f) return;
                                return u.add(h(p), j().relative), g(p),
                                    function() {
                                        let e = s.sessionObservable.subscribe(e => {
                                            g(e), y(e)
                                        });
                                        ob.push(() => e.unsubscribe())
                                    }(), t.observable.subscribe(() => {
                                        t.isGranted() ? (c = !1, s.setSessionState(t => ol(t, e), "expandOrRenewOnConsent").catch(eE)) : v()
                                    }), ey || (function(e) {
                                        let {
                                            stop: t
                                        } = tp(window, ["click", "touchstart", "keydown", "scroll"], e, {
                                            capture: !0,
                                            passive: !0
                                        });
                                        ob.push(t)
                                    }(() => {
                                        t.isGranted() && l()
                                    }), function(e) {
                                        let t = () => {
                                                "visible" === document.visibilityState && e()
                                            },
                                            {
                                                stop: n
                                            } = tf(document, "visibilitychange", t);
                                        ob.push(n);
                                        let r = eN(t, 6e4);
                                        ob.push(() => {
                                            eM(r)
                                        })
                                    }(() => {
                                        c || s.setSessionState(e => {
                                            var t;
                                            return oo(t = e) || Q(t) || !t.id || oa(t), t
                                        }, "expandOnVisibility").catch(eE)
                                    }), function(e) {
                                        let {
                                            stop: t
                                        } = tf(window, "resume", e, {
                                            capture: !0
                                        });
                                        ob.push(t)
                                    }(() => {
                                        s.setSessionState(t => oc(t, e), "initializeOnResume").catch(eE)
                                    })), tK("Session manager init metrics", {
                                        metrics: {
                                            duration: H() - r
                                        }
                                    }), {
                                        findSession: (e, t) => u.find(e, t),
                                        findTrackedSession: (t, {
                                            returnInactive: n = !1,
                                            maxAge: r = oh
                                        } = {}) => {
                                            let i = u.find(t, {
                                                returnInactive: n
                                            });
                                            if (i && "invalid" !== i.id && n0(i.id, e.sessionSampleRate) && !(V() - i.createdAt > r)) return i
                                        },
                                        renewObservable: i,
                                        expireObservable: o,
                                        expire: v,
                                        updateSessionState: e => {
                                            s.setSessionState(t => ({ ...t,
                                                ...e
                                            }), "updateState").catch(eE)
                                        }
                                    }
                            }
                            async function m() {
                                let t = {};
                                return await s.setSessionState(n => t = ol(oc(n, e), e), "initialize"), t
                            }

                            function g(r) {
                                ex(n);
                                let i = or(r);
                                i && (n = eI(() => {
                                    s.setSessionState(n => oo(n) ? (t.isGranted() || delete n.anonymousId, oi(n, e)) : n, "expireOnTimeout").catch(eE)
                                }, i - V()))
                            }

                            function y(e) {
                                let t = u.find(),
                                    n = t ? .id !== void 0,
                                    r = void 0 !== e.id,
                                    a = n && r && t.id !== e.id;
                                if (n && (!r || a) && (c = !0, o.notify(), u.closeActive(H())), r && (!n || a)) {
                                    if (c) return;
                                    u.add(h(e), H()), i.notify()
                                } else n && r && !a && (t.isReplayForced = !!e.forcedReplay)
                            }

                            function v() {
                                d();
                                let n = oi(u.find(), e);
                                t.isGranted() || delete n.anonymousId, y(n), s.setSessionState(n => (t.isGranted() || delete n.anonymousId, oi(n, e)), "expire").catch(eE)
                            }

                            function h(e) {
                                let t = on(e) ? ? q();
                                return e.id ? {
                                    id: e.id,
                                    isReplayForced: !!e.forcedReplay,
                                    anonymousId: e.anonymousId,
                                    createdAt: t
                                } : {
                                    id: "invalid",
                                    isReplayForced: !1,
                                    anonymousId: void 0,
                                    createdAt: t
                                }
                            }
                        }

                        function o_(e, t) {
                            if (void 0 !== e) return "string" != typeof e ? void ep.warn(`Invalid ${t} provided (expected a string, got ${typeof e}). Ignoring.`) : rs(e)
                        }
                        let oE = function(e, t, n = {}) {
                                let r = function(e) {
                                        let t = new eC;

                                        function n() {
                                            return e === t4.GRANTED
                                        }
                                        return {
                                            tryToInit(t) {
                                                e || (e = t)
                                            },
                                            onGrantedOnce(e) {
                                                if (n()) e();
                                                else {
                                                    let r = t.subscribe(() => {
                                                        n() && (e(), r.unsubscribe())
                                                    })
                                                }
                                            },
                                            update(n) {
                                                e = n, t.notify()
                                            },
                                            isGranted: n,
                                            observable: t
                                        }
                                    }(),
                                    o = function() {
                                        let e = new eR(500, e => {
                                                tG("Early data collection dropped data on unbuffer", {
                                                    count: e
                                                })
                                            }),
                                            t = [];

                                        function n(n, r) {
                                            t.push(r.subscribe(t => {
                                                e.notify({
                                                    type: n,
                                                    data: t
                                                })
                                            }))
                                        }
                                        return n(0, new eC(e => {
                                            var t, n;
                                            let r = (t, n) => {
                                                    let r = rv({
                                                        stackTrace: n,
                                                        originalError: t,
                                                        startClocks: G(),
                                                        nonErrorPrefix: "Uncaught",
                                                        source: ri.SOURCE,
                                                        handling: "unhandled"
                                                    });
                                                    e.notify(r)
                                                },
                                                {
                                                    stop: i
                                                } = (t = r, n1(eg, "onerror", ({
                                                    parameters: [e, n, r, i, o]
                                                }) => {
                                                    let a;
                                                    e0(o) || (a = function(e, t, n, r) {
                                                        var i;
                                                        let o, a;
                                                        if (void 0 === t) return;
                                                        let {
                                                            name: s,
                                                            message: u
                                                        } = (i = e, "[object String]" === ({}).toString.call(i) && ([, o, a] = eB.exec(i)), {
                                                            name: o,
                                                            message: a
                                                        });
                                                        return {
                                                            name: s,
                                                            message: u,
                                                            stack: [{
                                                                url: t,
                                                                column: r,
                                                                line: n
                                                            }]
                                                        }
                                                    }(e, n, r, i)), t(o ? ? e, a)
                                                })),
                                                {
                                                    stop: o
                                                } = (n = r, tm(eg.window, "unhandledrejection") ? n1(eg, "onunhandledrejection", ({
                                                    parameters: [e]
                                                }) => {
                                                    n(e.reason || "Empty reason")
                                                }) : {
                                                    stop: eD
                                                });
                                            return () => {
                                                i(), o()
                                            }
                                        })), n(1, r_()), n(2, rt()), n(3, eA(...Object.values(ec).map(e => {
                                            var t;
                                            return rw[e] || (rw[e] = (t = e, new eC(e => {
                                                let n = el[t];
                                                return el[t] = (...r) => {
                                                    n.apply(console, r);
                                                    let i = ez("console error");
                                                    e_(() => {
                                                        e.notify(function(e, t, n) {
                                                            let r = e.map(e => {
                                                                var t;
                                                                return "string" == typeof(t = e) ? rs(t) : e0(t) ? eJ(eP(t)) : eX(rs(t), void 0, 2)
                                                            }).join(" ");
                                                            if (t === ec.error) {
                                                                let i = rv({
                                                                    originalError: e.find(e0),
                                                                    handlingStack: n,
                                                                    startClocks: G(),
                                                                    source: ri.CONSOLE,
                                                                    handling: "handled",
                                                                    nonErrorPrefix: "Provided",
                                                                    useFallbackStack: !1
                                                                });
                                                                return i.message = r, {
                                                                    api: t,
                                                                    message: r,
                                                                    handlingStack: n,
                                                                    error: i
                                                                }
                                                            }
                                                            return {
                                                                api: t,
                                                                message: r,
                                                                error: void 0,
                                                                handlingStack: n
                                                            }
                                                        }(r, t, i))
                                                    })
                                                }, () => {
                                                    el[t] = n
                                                }
                                            }))), rw[e]
                                        }))), {
                                            observable: e,
                                            stop: () => t.forEach(e => e.unsubscribe())
                                        }
                                    }(),
                                    s = function({
                                        ignoreInitIfSyntheticsWillInjectRum: e = !0,
                                        startDeflateWorker: t,
                                        sdkName: n
                                    }, r, o) {
                                        let s, u, c, l, d, f, p = new eR(500, e => {
                                                tG("preStartRum buffer data lost", {
                                                    count: e
                                                })
                                            }),
                                            m = i0();
                                        i5(m, i6.globalContext, p);
                                        let g = i1();
                                        i5(g, i6.userContext, p);
                                        let y = i3();
                                        i5(y, i6.accountContext, p);
                                        let v = {
                                                assembleEventDefaults: tL(),
                                                assembleTelemetry: tL(),
                                                assembleEvent: tL()
                                            },
                                            h = r.observable.subscribe(_),
                                            b = {},
                                            S = !1;

                                        function _() {
                                            let e;
                                            if (S || !c || !l || !d || !f) return;
                                            if (h.unsubscribe(), l.trackViewsManually) {
                                                if (!s) return;
                                                e = s.options
                                            }
                                            let t = l.trackViewsManually ? s ? .callback : void 0,
                                                n = o(l, d, u, e, f, v);
                                            S = !0, p.subscribe(e => {
                                                e !== t && e(n)
                                            }), p.unbuffer()
                                        }

                                        function E(e, o, a) {
                                            var s;
                                            let p = e8();
                                            if (p && (e = { ...s = e,
                                                    service: s.service || s.applicationId,
                                                    applicationId: "00000000-aaaa-0000-aaaa-000000000000",
                                                    clientToken: "empty",
                                                    sessionSampleRate: 100,
                                                    defaultPrivacyLevel: s.defaultPrivacyLevel ? ? e6() ? .getPrivacyLevel()
                                                }), c = e, l) return void i7("DD_RUM", e);
                                            let m = function(e, t) {
                                                var n, r, i;
                                                let o = e && "object" == typeof e ? nn(nu, e, ep) : void ep.error("Configuration must be an object");
                                                if (!o) return;
                                                let a = o.allowedTracingUrls.map(nc).filter(Boolean);
                                                if (a.length > 0 && !o.service) return void ep.error("Service needs to be configured when tracing is enabled");
                                                let s = (n = eT.SESSION_REPLAY_RECORD_CANVAS, ek.has(n)) ? o.sessionReplayCanvasRecording : void 0;
                                                return { ...o,
                                                    service: o.service || o.applicationId,
                                                    sessionReplayCanvasRecording: s,
                                                    betaEnableViewUpdates: (r = o.betaEnableViewUpdates, i = o.proxy, !e8() && (r ? ? !1)),
                                                    allowedTracingUrls: a,
                                                    beforeSend: o.beforeSend ? t7(o.beforeSend, "beforeSend threw an error:") : void 0,
                                                    rulePsr: ne(e.traceSampleRate) ? e.traceSampleRate / 100 : void 0,
                                                    trackResourceHeaders: function(e) {
                                                        let t = e.trackResourceHeaders;
                                                        if (void 0 === t || !1 === t) return [];
                                                        if (!0 === t) return ns.map(e => ({
                                                            name: e
                                                        }));
                                                        if (!Array.isArray(t)) return ep.warn("trackResourceHeaders should be true or an array of MatchHeader"), [];
                                                        if (0 === t.length) return ep.warn("trackResourceHeaders is an empty array, no headers will be captured"), [];
                                                        let n = [];
                                                        return t.forEach((e, t) => {
                                                            if (!Y(e)) return void ep.warn(`trackResourceHeaders[${t}] should be a MatchHeader object`);
                                                            if (void 0 !== e.name && !J(e.name)) return void ep.warn(`trackResourceHeaders[${t}].name should be a MatchOption`);
                                                            if (void 0 !== e.url && !J(e.url)) return void ep.warn(`trackResourceHeaders[${t}].url should be a MatchOption`);
                                                            if (void 0 !== e.extractor && !(e.extractor instanceof RegExp)) return void ep.warn(`trackResourceHeaders[${t}].extractor should be a RegExp`);
                                                            if (void 0 !== e.location && ("string" != typeof e.location || !nl.includes(e.location))) return void ep.warn(`trackResourceHeaders[${t}].location should be 'request', 'response', or 'any'`);
                                                            let {
                                                                name: r,
                                                                ...i
                                                            } = e;
                                                            n.push({ ...i,
                                                                ...void 0 !== r ? {
                                                                    name: "string" == typeof r ? r.toLowerCase() : r
                                                                } : {}
                                                            })
                                                        }), n
                                                    }(e),
                                                    allowedGraphQlUrls: function(e) {
                                                        if (!e.allowedGraphQlUrls) return [];
                                                        if (!Array.isArray(e.allowedGraphQlUrls)) return ep.warn("allowedGraphQlUrls should be an array"), [];
                                                        let t = [];
                                                        return e.allowedGraphQlUrls.forEach(e => {
                                                            J(e) ? t.push({
                                                                match: e,
                                                                trackPayload: !1,
                                                                trackResponseErrors: !1
                                                            }) : Y(e) && J(e.match) && t.push({
                                                                match: e.match,
                                                                trackPayload: !!e.trackPayload,
                                                                trackResponseErrors: !!e.trackResponseErrors
                                                            })
                                                        }), t
                                                    }(e),
                                                    remoteConfigurationId: t2(e)
                                                }
                                            }(e, n);
                                            if (m && function(e, t) {
                                                    let n = eg.location,
                                                        r = n ? n.origin : "",
                                                        i = e.allowedTrackingOrigins;
                                                    if (!i) return ! function(e, t = "") {
                                                        return !oe(e) && oe(t.split("\n").filter(e => {
                                                            let t = e.trim();
                                                            return t.length && /^at\s+|@/.test(t)
                                                        })[1] || "")
                                                    }(r, t) || (ep.error("Running the Browser SDK in a Web extension content script is forbidden unless the `allowedTrackingOrigins` option is provided."), !1);
                                                    let o = n6(i, r);
                                                    return o || ep.error("SDK initialized on a non-allowed domain."), o
                                                }(m, o ? ? "")) {
                                                if (m.compressIntakeRequests && !p && t && !(u = t(m, "Datadog RUM", eD))) return;
                                                l = m, r.tryToInit(m.trackingConsent), r.onGrantedOnce(() => {
                                                    let t, {
                                                        assembleTelemetry: o
                                                    } = v;
                                                    if (o.register(() => r.isGranted() ? tP : tD), f = function(e, t, n, r) {
                                                            let o = new eC,
                                                                {
                                                                    enabled: a,
                                                                    metricsEnabled: s
                                                                } = function(e, t, n, r, o, a = 1, s = 15) {
                                                                    let u = {},
                                                                        c = !tF.includes(t.site) && tU(t.telemetrySampleRate),
                                                                        l = {
                                                                            [t_.LOG]: c,
                                                                            [t_.CONFIGURATION]: c && tU(t.telemetryConfigurationSampleRate),
                                                                            [t_.USAGE]: c && tU(t.telemetryUsageSampleRate),
                                                                            metric: c && tU(a)
                                                                        },
                                                                        d = {
                                                                            is_local_file: eg.location ? .protocol === "file:",
                                                                            is_worker: ey
                                                                        },
                                                                        f = tH();
                                                                    return f.subscribe(({
                                                                        rawEvent: i,
                                                                        metricName: a
                                                                    }) => {
                                                                        if (a && !l.metric || !l[i.type]) return;
                                                                        let c = a || i.status || i.type,
                                                                            f = u[c];
                                                                        if (f || (f = u[c] = new Set), f.size >= s) return;
                                                                        let p = eX(i);
                                                                        if (f.has(p)) return;
                                                                        let m = n.trigger({
                                                                            startTime: G().relative
                                                                        });
                                                                        if (m === tD) return;
                                                                        let g = function(e, n, r, i) {
                                                                            let a = {
                                                                                type: "telemetry",
                                                                                date: G().timeStamp,
                                                                                service: n,
                                                                                version: "7.13.0",
                                                                                source: "browser",
                                                                                _dd: {
                                                                                    format_version: 2
                                                                                },
                                                                                telemetry: tN(r, {
                                                                                    runtime_env: i,
                                                                                    connectivity: e4(),
                                                                                    sdk_setup: "npm",
                                                                                    sdk_name: o
                                                                                }),
                                                                                ddtags: e1(t).join(","),
                                                                                experimental_features: Array.from(ek)
                                                                            };
                                                                            return tN(a, e)
                                                                        }(m, e, i, d);
                                                                        r.notify(g), e2("telemetry", g), f.add(p)
                                                                    }), f.unbuffer(), i || (i = tj), {
                                                                        enabled: c,
                                                                        metricsEnabled: l.metric
                                                                    }
                                                                }(e, t, n, o, r),
                                                                {
                                                                    stop: u
                                                                } = function(e, t) {
                                                                    let n = [];
                                                                    if (e8()) {
                                                                        let e = e6(),
                                                                            r = t.subscribe(t => e.send("internal_telemetry", t));
                                                                        n.push(r.unsubscribe)
                                                                    } else {
                                                                        let r = [tT(e, "rum")],
                                                                            i = tk(e, "rum");
                                                                        i && e.site === tE && r.push(i);
                                                                        let o = tb({
                                                                            endpoints: r,
                                                                            reportError: eD
                                                                        });
                                                                        n.push(o.stop);
                                                                        let a = t.subscribe(o.add);
                                                                        n.push(a.unsubscribe)
                                                                    }
                                                                    return {
                                                                        stop: () => n.forEach(e => e())
                                                                    }
                                                                }(t, o);
                                                            return {
                                                                stop: u,
                                                                enabled: a,
                                                                metricsEnabled: s
                                                            }
                                                        }(tV.RUM, m, o, n), ey) return void ep.warn("The RUM SDK is not supported in a web or service worker environment.");
                                                    (e8() ? (t = {
                                                        id: et(),
                                                        isReplayForced: !1,
                                                        anonymousId: void 0,
                                                        createdAt: q()
                                                    }, Promise.resolve({
                                                        findSession: () => t,
                                                        findTrackedSession: () => t,
                                                        renewObservable: new eC,
                                                        expireObservable: new eC,
                                                        expire: eD,
                                                        updateSessionState: e => {
                                                            t = { ...t,
                                                                ...e
                                                            }
                                                        }
                                                    })) : oS(m, r)).then(t => {
                                                        if (t) {
                                                            var r, i, s;
                                                            r = d = t, i = {
                                                                application: {
                                                                    id: m.applicationId
                                                                }
                                                            }, o.register(({
                                                                startTime: e
                                                            }) => {
                                                                let t = r.findTrackedSession(e);
                                                                return t ? {
                                                                    session: {
                                                                        id: t.id
                                                                    },
                                                                    anonymous_id: t.anonymousId,
                                                                    ...i
                                                                } : tP
                                                            }), s = function(e, t, n) {
                                                                var r, i, o, a, s;
                                                                let u = {
                                                                    session_sample_rate: e.sessionSampleRate,
                                                                    telemetry_sample_rate: e.telemetrySampleRate,
                                                                    telemetry_configuration_sample_rate: e.telemetryConfigurationSampleRate,
                                                                    telemetry_usage_sample_rate: e.telemetryUsageSampleRate,
                                                                    use_before_send: !!e.beforeSend,
                                                                    use_partitioned_cross_site_session_cookie: e.usePartitionedCrossSiteSessionCookie,
                                                                    use_secure_session_cookie: e.useSecureSessionCookie,
                                                                    use_proxy: !!e.proxy,
                                                                    silent_multiple_init: e.silentMultipleInit,
                                                                    track_session_across_subdomains: e.trackSessionAcrossSubdomains,
                                                                    track_anonymous_user: e.trackAnonymousUser,
                                                                    session_persistence: Array.isArray(e.sessionPersistence) ? e.sessionPersistence[0] : e.sessionPersistence,
                                                                    store_contexts_across_pages: !!e.storeContextsAcrossPages,
                                                                    allow_untrusted_events: !!e.allowUntrustedEvents,
                                                                    tracking_consent: e.trackingConsent,
                                                                    use_allowed_tracking_origins: Array.isArray(e.allowedTrackingOrigins),
                                                                    source: e.source,
                                                                    sdk_version: e.sdkVersion,
                                                                    variant: e.variant
                                                                };
                                                                return {
                                                                    session_replay_sample_rate: e.sessionReplaySampleRate,
                                                                    start_session_replay_recording_manually: e.startSessionReplayRecordingManually,
                                                                    trace_sample_rate: e.traceSampleRate,
                                                                    trace_context_injection: e.traceContextInjection,
                                                                    propagate_trace_baggage: e.propagateTraceBaggage,
                                                                    action_name_attribute: e.actionNameAttribute,
                                                                    use_allowed_tracing_urls: nt(e.allowedTracingUrls),
                                                                    use_allowed_graph_ql_urls: nt(e.allowedGraphQlUrls),
                                                                    use_track_graph_ql_payload: nt(r = e.allowedGraphQlUrls) && r.some(e => Y(e) && e.trackPayload),
                                                                    use_track_graph_ql_response_errors: nt(i = e.allowedGraphQlUrls) && i.some(e => Y(e) && e.trackResponseErrors),
                                                                    selected_tracing_propagators: function(e) {
                                                                        let t = new Set;
                                                                        return nt(e.allowedTracingUrls) && e.allowedTracingUrls.forEach(e => {
                                                                            nc(e) ? .propagatorTypes.forEach(e => t.add(e))
                                                                        }), Array.from(t)
                                                                    }(e),
                                                                    default_privacy_level: e.defaultPrivacyLevel,
                                                                    enable_privacy_for_action_name: e.enablePrivacyForActionName,
                                                                    use_excluded_activity_urls: nt(e.excludedActivityUrls),
                                                                    use_worker_url: !!e.workerUrl,
                                                                    compress_intake_requests: e.compressIntakeRequests,
                                                                    track_views_manually: e.trackViewsManually,
                                                                    track_user_interactions: e.trackUserInteractions,
                                                                    track_resources: e.trackResources,
                                                                    track_long_task: e.trackLongTasks,
                                                                    plugins: e.plugins ? .map(e => ({
                                                                        name: e.name,
                                                                        ...e.getConfigurationTelemetry ? .()
                                                                    })),
                                                                    track_feature_flags_for_events: e.trackFeatureFlagsForEvents,
                                                                    remote_configuration_id: t2(e),
                                                                    remote_configuration: n && {
                                                                        last_modified: n.lastModified,
                                                                        last_synced: n.lastSynced,
                                                                        first_applied: n.firstApplied,
                                                                        sync_id: n.syncId
                                                                    },
                                                                    profiling_sample_rate: e.profilingSampleRate,
                                                                    use_remote_configuration_proxy: !!e.remoteConfigurationProxy,
                                                                    track_resource_headers: !0 === (o = e.trackResourceHeaders) ? "default_headers" : Array.isArray(o) ? "custom" : void 0,
                                                                    beta_enable_view_updates: (a = e.betaEnableViewUpdates, s = e.proxy, !e8() && (a ? ? !1)),
                                                                    beta_track_web_sockets: e.betaTrackWebSockets,
                                                                    ...u
                                                                }
                                                            }(e, n, a), tH().notify({
                                                                rawEvent: {
                                                                    type: t_.CONFIGURATION,
                                                                    configuration: s
                                                                }
                                                            }), _()
                                                        }
                                                    }).catch(eE)
                                                })
                                            }
                                        }
                                        return {
                                            init(t, n, r) {
                                                var i, o;
                                                if (!t) return void ep.error("Missing configuration");
                                                if (Array.isArray(i = t.enableExperimentalFeatures) && i.filter(e => Object.keys(eT).some(t => eT[t] === e)).forEach(e => {
                                                        ek.add(e)
                                                    }), o = t.allowUntrustedEvents, !0 !== a && (a = o ? ? !1), c = t, e && ij()) return;
                                                let s = function(e, t) {
                                                    if (!e) return !0;
                                                    let n = e.map(e => e.onInit ? .(t));
                                                    return n.some(i2) ? Promise.all(n).then(e => !e.includes(!1)) : !n.includes(!1)
                                                }(t.plugins, {
                                                    initConfiguration: t,
                                                    publicApi: n,
                                                    registerAssembleEventHook: v.assembleEvent.register
                                                });

                                                function u() {
                                                    if (t2(t)) {
                                                        let e = {
                                                            user: g,
                                                            context: m
                                                        };
                                                        if (t.remoteConfigurationId || t.remoteConfiguration ? .sync) tZ(t, e).then(e => {
                                                            e && E(e, r)
                                                        }).catch(eE);
                                                        else {
                                                            let n = function(e, t) {
                                                                let n = function({
                                                                        remoteConfigurationId: e
                                                                    }) {
                                                                        let t = `dd_rc_${e}`;
                                                                        return {
                                                                            read() {
                                                                                let e;
                                                                                try {
                                                                                    e = localStorage.getItem(t)
                                                                                } catch {
                                                                                    return {
                                                                                        status: "error"
                                                                                    }
                                                                                }
                                                                                if (null === e) return {
                                                                                    status: "miss"
                                                                                };
                                                                                let n = Z(e);
                                                                                return void 0 === n || ! function(e) {
                                                                                    if ("object" != typeof e || null === e) return !1;
                                                                                    let t = "version" in e && 3 === e.version,
                                                                                        n = "config" in e && "object" == typeof e.config && null !== e.config,
                                                                                        r = "metadata" in e && Y(e.metadata) && "string" == typeof e.metadata.syncId && "number" == typeof e.metadata.lastSynced;
                                                                                    return t && n && r
                                                                                }(n) ? (this.remove(), {
                                                                                    status: "error"
                                                                                }) : {
                                                                                    status: "hit",
                                                                                    config: n.config,
                                                                                    metadata: n.metadata
                                                                                }
                                                                            },
                                                                            remove() {
                                                                                try {
                                                                                    localStorage.removeItem(t)
                                                                                } catch {}
                                                                            },
                                                                            write(e, n) {
                                                                                let r = this.read();
                                                                                ("hit" !== r.status || JSON.stringify(r.config) !== JSON.stringify(e)) && ea(t, {
                                                                                    version: 3,
                                                                                    config: e,
                                                                                    metadata: {
                                                                                        lastModified: n,
                                                                                        lastSynced: q(),
                                                                                        syncId: et()
                                                                                    }
                                                                                })
                                                                            },
                                                                            stampFirstApplied(e) {
                                                                                if (void 0 !== e.metadata.firstApplied) return e.metadata;
                                                                                let n = { ...e.metadata,
                                                                                    firstApplied: q()
                                                                                };
                                                                                return ea(t, {
                                                                                    version: 3,
                                                                                    config: e.config,
                                                                                    metadata: n
                                                                                }), n
                                                                            }
                                                                        }
                                                                    }({
                                                                        remoteConfigurationId: t2(e)
                                                                    }),
                                                                    r = t0(),
                                                                    i = n.read();
                                                                return (r.increment("cache", eo[i.status]), t3(e).then(e => {
                                                                    e.ok ? (r.increment("fetch", "success"), n.write(e.value, e.lastModified)) : (r.increment("fetch", "failure"), ep.error(e.error))
                                                                }).catch(eE).finally(() => {
                                                                    tK(tq.REMOTE_CONFIGURATION_METRIC_NAME, {
                                                                        metrics: r.get()
                                                                    })
                                                                }), "hit" === i.status) ? {
                                                                    metadata: n.stampFirstApplied(i),
                                                                    initConfiguration: tQ(e, i.config, t, r)
                                                                } : e.remoteConfiguration ? .required ? void 0 : {
                                                                    initConfiguration: e
                                                                }
                                                            }(t, e);
                                                            n && E(n.initConfiguration, r, n.metadata)
                                                        }
                                                    } else E(t, r)
                                                }
                                                "boolean" == typeof s ? s && u() : s.then(e => {
                                                    e && u()
                                                }).catch(eE)
                                            },
                                            get initConfiguration() {
                                                return c
                                            },
                                            getInternalContext: eD,
                                            stopSession: eD,
                                            addTiming(e, t = q()) {
                                                p.notify(n => n.addTiming(e, t))
                                            },
                                            setLoadingTime: e => {
                                                p.notify(t => t.setLoadingTime(e))
                                            },
                                            startView(e, t = G()) {
                                                let n = n => {
                                                    n.startView(e, t)
                                                };
                                                p.notify(n), s || (s = {
                                                    options: e,
                                                    callback: n
                                                }, _())
                                            },
                                            setViewName(e) {
                                                p.notify(t => t.setViewName(e))
                                            },
                                            setViewContext(e) {
                                                p.notify(t => t.setViewContext(e))
                                            },
                                            setViewContextProperty(e, t) {
                                                p.notify(n => n.setViewContextProperty(e, t))
                                            },
                                            getViewContext: () => b,
                                            globalContext: m,
                                            userContext: g,
                                            accountContext: y,
                                            addAction(e) {
                                                p.notify(t => t.addAction(e))
                                            },
                                            startAction(e, t) {
                                                let n = G();
                                                p.notify(r => r.startAction(e, t, n))
                                            },
                                            stopAction(e, t) {
                                                let n = G();
                                                p.notify(r => r.stopAction(e, t, n))
                                            },
                                            startResource(e, t) {
                                                let n = G();
                                                p.notify(r => r.startResource(e, t, n))
                                            },
                                            stopResource(e, t) {
                                                let n = G();
                                                p.notify(r => r.stopResource(e, t, n))
                                            },
                                            addError(e) {
                                                p.notify(t => t.addError(e))
                                            },
                                            addFeatureFlagEvaluation(e, t) {
                                                p.notify(n => n.addFeatureFlagEvaluation(e, t))
                                            },
                                            startDurationVital(e, t) {
                                                let n = G();
                                                p.notify(r => r.startDurationVital(e, t, n))
                                            },
                                            stopDurationVital(e, t) {
                                                let n = G();
                                                p.notify(r => r.stopDurationVital(e, t, n))
                                            },
                                            addDurationVital(e) {
                                                p.notify(t => t.addDurationVital(e))
                                            },
                                            addOperationStepVital: (e, t, n, r) => {
                                                p.notify(i => i.addOperationStepVital(rs(e), t, rs(n), rs(r)))
                                            }
                                        }
                                    }(n, r, (r, i, a, u, c, l) => {
                                        let d = a && n.createDeflateEncoder ? e => n.createDeflateEncoder(a, e) : tv,
                                            f = function(e, t, n, r, i, o, a, s, u, c) {
                                                let l = [],
                                                    d = new nd;
                                                d.subscribe(14, e => e2("rum", e)), t.expireObservable.subscribe(() => d.notify(10, {
                                                    endClocks: G()
                                                })), t.renewObservable.subscribe(() => d.notify(11));
                                                let f = e => {
                                                    d.notify(15, {
                                                        error: {
                                                            message: e,
                                                            source: ri.AGENT,
                                                            startClocks: G()
                                                        }
                                                    }), tG("Error reported to customer", {
                                                        "error.message": e
                                                    })
                                                };
                                                if (e8()) {
                                                    var p;
                                                    let e = e6();
                                                    d.subscribe(14, t => {
                                                        e.send("rum", t)
                                                    });
                                                    let t = ty().subscribe(e => {
                                                        d.notify(12, e.reason)
                                                    });
                                                    l.push(() => t.unsubscribe())
                                                } else {
                                                    let n = function(e, t, n, r, i) {
                                                            let o = [tT(e, "rum")],
                                                                a = tk(e, "rum");
                                                            a && o.push(a);
                                                            let s = tb({
                                                                encoder: i(iA.RUM),
                                                                endpoints: o,
                                                                reportError: n
                                                            });
                                                            r.subscribe(() => s.forceFlush("session_expire"));
                                                            let {
                                                                dispatch: u,
                                                                stop: c
                                                            } = function(e, t) {
                                                                let n, r, i = !1,
                                                                    o = 0,
                                                                    {
                                                                        unsubscribe: a
                                                                    } = e.flushObservable.subscribe(() => {
                                                                        i = !1, r = n
                                                                    });
                                                                return {
                                                                    dispatch: a => {
                                                                        if (a.type !== w.VIEW) return void e.add(a);
                                                                        if (!t) return void e.upsert(a, a.view.id);
                                                                        let s = a.view.id;
                                                                        if (!a.view.is_active) {
                                                                            s === n ? .view.id && (n = void 0, r = void 0, i = !1, o = 0), e.upsert(a, s);
                                                                            return
                                                                        }
                                                                        if (s !== n ? .view.id) {
                                                                            o = 0, e.upsert(a, s), n = a, i = !e.isEmpty;
                                                                            return
                                                                        }
                                                                        if (n = a, i) return void e.upsert(a, s);
                                                                        if ((o += 1) >= 100) {
                                                                            o = 0, e.upsert(a, s), i = !e.isEmpty;
                                                                            return
                                                                        }
                                                                        if (r) {
                                                                            let t = function(e, t) {
                                                                                let n = function e(t, n, r) {
                                                                                    let i = {},
                                                                                        o = r ? .replaceKeys ? ? new Set,
                                                                                        a = r ? .appendKeys ? ? new Set,
                                                                                        s = r ? .ignoreKeys ? ? new Set;
                                                                                    for (let r of Object.keys(t)) {
                                                                                        if (s.has(r)) continue;
                                                                                        let u = t[r],
                                                                                            c = n[r];
                                                                                        if (!o.has(r) && Y(u) && Y(c)) {
                                                                                            let t = e(u, c, {
                                                                                                replaceKeys: iC(o, r),
                                                                                                appendKeys: iC(a, r),
                                                                                                ignoreKeys: iC(s, r)
                                                                                            });
                                                                                            t && (i[r] = t)
                                                                                        } else a.has(r) && Array.isArray(u) && Array.isArray(c) ? u.length > c.length && (i[r] = u.slice(c.length)) : ! function e(t, n) {
                                                                                            if (t === n) return !0;
                                                                                            if (null === t || "object" != typeof t || null === n || "object" != typeof n) return t === n;
                                                                                            if (Array.isArray(t) && Array.isArray(n)) return t.length === n.length && t.every((t, r) => e(t, n[r]));
                                                                                            if (Array.isArray(t) || Array.isArray(n)) return !1;
                                                                                            let r = Object.keys(t),
                                                                                                i = Object.keys(n);
                                                                                            return r.length === i.length && r.every(r => i.includes(r) && e(t[r], n[r]))
                                                                                        }(u, c) && (i[r] = u)
                                                                                    }
                                                                                    for (let e of Object.keys(n)) e in t || (i[e] = null);
                                                                                    return Object.keys(i).length > 0 ? i : void 0
                                                                                }(e, t, {
                                                                                    replaceKeys: new Set(["view.custom_timings", "context", "connectivity", "usr", "device", "privacy"]),
                                                                                    appendKeys: new Set(["_dd.page_states"]),
                                                                                    ignoreKeys: new Set(["date", "type", "application", "session", "view.id", "view.url", "_dd.document_version", "_dd.format_version"])
                                                                                });
                                                                                if (n) return tN(n, {
                                                                                    type: w.VIEW_UPDATE,
                                                                                    date: e.date,
                                                                                    application: e.application,
                                                                                    session: e.session,
                                                                                    view: {
                                                                                        id: e.view.id,
                                                                                        url: e.view.url
                                                                                    },
                                                                                    _dd: {
                                                                                        document_version: e._dd.document_version,
                                                                                        format_version: e._dd.format_version
                                                                                    }
                                                                                })
                                                                            }(a, r);
                                                                            t && (e2("rum", t), e.upsert(t, s))
                                                                        }
                                                                    },
                                                                    stop: a
                                                                }
                                                            }(s, e.betaEnableViewUpdates);
                                                            t.subscribe(14, u);
                                                            let l = s.stop.bind(s);
                                                            return s.stop = () => {
                                                                c(), l()
                                                            }, s
                                                        }(e, d, f, t.expireObservable, o),
                                                        r = n.prepareUrgentFlushObservable.subscribe(e => {
                                                            d.notify(12, e)
                                                        });
                                                    l.push(() => r.unsubscribe()), l.push(() => n.stop()), p = n.flushObservable, s.metricsEnabled && (ix(), S = !1, d.subscribe(14, () => {
                                                        S = !0
                                                    }), p.subscribe(({
                                                        bytesCount: e,
                                                        messagesCount: t
                                                    }) => {
                                                        S && (S = !1, b.batchCount += 1, iI(b.batchBytesCount, e), iI(b.batchMessagesCount, t))
                                                    }), eN(ik, 1e4))
                                                }
                                                let {
                                                    stop: m,
                                                    ...g
                                                } = function(e, t, n, r, i, o, a, s, u) {
                                                    var c, l, d, f;
                                                    let p, m = [],
                                                        g = function() {
                                                            let e = function() {
                                                                let e, t = window;
                                                                if (t.Zone && (e = eO(t, "MutationObserver"), t.MutationObserver && e === t.MutationObserver)) {
                                                                    let n = new t.MutationObserver(eD);
                                                                    e = eO(n, "originalInstance") ? .constructor
                                                                }
                                                                return e || (e = t.MutationObserver), e
                                                            }();
                                                            return new eC(t => {
                                                                let n = new e(eS(e => t.notify(e)));
                                                                return n.observe(document, {
                                                                    attributes: !0,
                                                                    characterData: !0,
                                                                    childList: !0,
                                                                    subtree: !0
                                                                }), () => n.disconnect()
                                                            })
                                                        }(),
                                                        b = (p = { ...iR()
                                                        }, new eC(e => {
                                                            var t;
                                                            let {
                                                                stop: n
                                                            } = function(e) {
                                                                let {
                                                                    stop: t
                                                                } = n1(iT("pushState"), "pushState", ({
                                                                    onPostCall: t
                                                                }) => {
                                                                    t(e)
                                                                }), {
                                                                    stop: n
                                                                } = n1(iT("replaceState"), "replaceState", ({
                                                                    onPostCall: t
                                                                }) => {
                                                                    t(e)
                                                                }), {
                                                                    stop: r
                                                                } = tf(window, td.POP_STATE, e);
                                                                return {
                                                                    stop: () => {
                                                                        t(), n(), r()
                                                                    }
                                                                }
                                                            }(i), {
                                                                stop: r
                                                            } = (t = i, tf(window, td.HASH_CHANGE, t));

                                                            function i() {
                                                                if (p.href === iR().href) return;
                                                                let t = { ...iR()
                                                                };
                                                                e.notify({
                                                                    newLocation: t,
                                                                    oldLocation: p
                                                                }), p = t
                                                            }
                                                            return () => {
                                                                n(), r()
                                                            }
                                                        })),
                                                        {
                                                            observable: S,
                                                            stop: E
                                                        } = function() {
                                                            let e = new eC,
                                                                {
                                                                    stop: t
                                                                } = n1(window, "open", () => e.notify());
                                                            return {
                                                                observable: e,
                                                                stop: t
                                                            }
                                                        }();
                                                    m.push(E);
                                                    let {
                                                        assembleEventDefaults: O
                                                    } = t;
                                                    O.register(({
                                                        eventType: e
                                                    }) => {
                                                        let t = n.source;
                                                        return {
                                                            type: e,
                                                            _dd: {
                                                                format_version: 2,
                                                                drift: Math.round(V() - (W() + performance.now())),
                                                                configuration: {
                                                                    session_sample_rate: t9(n.sessionSampleRate, 3),
                                                                    session_replay_sample_rate: t9(n.sessionReplaySampleRate, 3),
                                                                    profiling_sample_rate: t9(n.profilingSampleRate, 3),
                                                                    trace_sample_rate: t9(n.traceSampleRate, 3)
                                                                },
                                                                browser_sdk_version: e8() ? "7.13.0" : void 0,
                                                                sdk_name: s
                                                            },
                                                            application: {
                                                                id: n.applicationId
                                                            },
                                                            date: q(),
                                                            source: t
                                                        }
                                                    });
                                                    let I = function(e, t = 500) {
                                                        let n, r = nv({
                                                            expireDelay: nf,
                                                            maxEntries: 4e3
                                                        });
                                                        nT("visibility-state") && performance.getEntriesByType("visibility-state").forEach(e => {
                                                            o("hidden" === e.name ? "hidden" : "active", e.startTime)
                                                        }), o(iN(), H());
                                                        let {
                                                            stop: i
                                                        } = tp(window, [td.PAGE_SHOW, td.FOCUS, td.BLUR, td.VISIBILITY_CHANGE, td.RESUME, td.FREEZE, td.PAGE_HIDE], e => {
                                                            var t;
                                                            o((t = e).type === td.FREEZE ? "frozen" : t.type === td.PAGE_HIDE ? t.persisted ? "frozen" : "terminated" : iN(), e.timeStamp)
                                                        }, {
                                                            capture: !0
                                                        });

                                                        function o(e, t = H()) {
                                                            e !== n && (n = e, r.closeActive(t), r.add({
                                                                state: n,
                                                                startTime: t
                                                            }, t))
                                                        }

                                                        function a(e, t, n) {
                                                            return r.findAll(t, n).some(t => t.state === e)
                                                        }
                                                        return e.register(({
                                                            startTime: e,
                                                            duration: n = 0,
                                                            eventType: i
                                                        }) => i === w.VIEW ? {
                                                            type: i,
                                                            _dd: {
                                                                page_states: function(e, t, n) {
                                                                    if (0 !== e.length) return e.slice(-n).reverse().map(({
                                                                        state: e,
                                                                        startTime: n
                                                                    }) => ({
                                                                        state: e,
                                                                        start: F(n - t)
                                                                    }))
                                                                }(r.findAll(e, n), e, t)
                                                            }
                                                        } : i === w.ACTION || i === w.ERROR ? {
                                                            type: i,
                                                            view: {
                                                                in_foreground: a("active", e, 0)
                                                            }
                                                        } : tP), {
                                                            wasInPageStateDuringPeriod: a,
                                                            addPageState: o,
                                                            stop: () => {
                                                                i(), r.stop()
                                                            }
                                                        }
                                                    }(O);
                                                    m.push(() => I.stop());
                                                    let x = function(e) {
                                                        let t = nv({
                                                            expireDelay: nf
                                                        });
                                                        return e.subscribe(1, e => {
                                                            var n;
                                                            t.add({
                                                                service: (n = e).service,
                                                                version: n.version,
                                                                context: n.context,
                                                                id: n.id,
                                                                name: n.name,
                                                                startClocks: n.startClocks
                                                            }, e.startClocks.relative)
                                                        }), e.subscribe(6, ({
                                                            endClocks: e
                                                        }) => {
                                                            t.closeActive(e.relative)
                                                        }), e.subscribe(3, e => {
                                                            let n = t.find(e.startClocks.relative);
                                                            n && (e.name && (n.name = e.name), e.context && (n.context = e.context), n.sessionIsActive = e.sessionIsActive)
                                                        }), e.subscribe(11, () => {
                                                            t.reset()
                                                        }), {
                                                            findView: (e, n) => t.find(e, n),
                                                            stop: () => {
                                                                t.stop()
                                                            }
                                                        }
                                                    }(e);
                                                    m.push(() => x.stop());
                                                    let N = function(e, t, n) {
                                                        let r, i = nv({
                                                            expireDelay: nf
                                                        });
                                                        e.subscribe(1, ({
                                                            startClocks: e,
                                                            url: t
                                                        }) => {
                                                            let n = eg.location.href,
                                                                o = void 0 !== t ? tR(t, n).href : n;
                                                            i.add(a({
                                                                url: o,
                                                                referrer: r || document.referrer
                                                            }), e.relative), r = o
                                                        }), e.subscribe(6, ({
                                                            endClocks: e
                                                        }) => {
                                                            i.closeActive(e.relative)
                                                        });
                                                        let o = n.subscribe(({
                                                            newLocation: e
                                                        }) => {
                                                            let t = i.find();
                                                            if (t) {
                                                                let n = H();
                                                                i.closeActive(n), i.add(a({
                                                                    url: e.href,
                                                                    referrer: t.referrer
                                                                }), n)
                                                            }
                                                        });

                                                        function a({
                                                            url: e,
                                                            referrer: t
                                                        }) {
                                                            return {
                                                                url: e,
                                                                referrer: t
                                                            }
                                                        }
                                                        return t.register(({
                                                            startTime: e,
                                                            eventType: t
                                                        }) => {
                                                            let n = i.find(e);
                                                            return n ? {
                                                                type: t,
                                                                view: {
                                                                    url: n.url,
                                                                    referrer: n.referrer
                                                                }
                                                            } : tD
                                                        }), {
                                                            findUrl: e => i.find(e),
                                                            stop: () => {
                                                                o.unsubscribe(), i.stop()
                                                            }
                                                        }
                                                    }(e, O, b);
                                                    m.push(() => N.stop());
                                                    let M = function(e, t, n) {
                                                        let r = nv({
                                                            expireDelay: nf
                                                        });
                                                        return e.subscribe(1, ({
                                                            startClocks: e
                                                        }) => {
                                                            r.add({}, e.relative)
                                                        }), e.subscribe(6, ({
                                                            endClocks: e
                                                        }) => {
                                                            r.closeActive(e.relative)
                                                        }), t.register(({
                                                            startTime: e,
                                                            eventType: t
                                                        }) => {
                                                            if (!n.trackFeatureFlagsForEvents.concat([w.VIEW, w.ERROR]).includes(t)) return tP;
                                                            let i = r.find(e);
                                                            return !i || Q(i) ? tP : {
                                                                type: t,
                                                                feature_flags: i
                                                            }
                                                        }), {
                                                            addFeatureFlagEvaluation: (e, t) => {
                                                                let n = r.find();
                                                                n && (n[e] = t)
                                                            }
                                                        }
                                                    }(e, O, n);
                                                    O.register(({
                                                        eventType: e,
                                                        startTime: t
                                                    }) => {
                                                        var o, a;
                                                        let s, u, c, l = r.findTrackedSession(t),
                                                            d = x.findView(t);
                                                        return l && d ? (e === w.VIEW ? (s = !!i.getReplayStats(d.id) || void 0, u = 1 == (o = l, a = n, e8() ? +!! function(e) {
                                                            let t = e6();
                                                            return !!t && t.getCapabilities().includes(e)
                                                        }(e5.RECORDS) : n0(o.id, a.sessionSampleRate * a.sessionReplaySampleRate / 100) ? 1 : 2 * !!o.isReplayForced), c = !!d.sessionIsActive && void 0) : s = !!i.isRecording() || void 0, {
                                                            type: e,
                                                            session: {
                                                                id: l.id,
                                                                type: "user",
                                                                has_replay: s,
                                                                sampled_for_replay: u,
                                                                is_active: c
                                                            }
                                                        }) : tD
                                                    }), O.register(({
                                                        eventType: e
                                                    }) => ({
                                                        type: e,
                                                        connectivity: e4()
                                                    }));
                                                    let L = (_ || (_ = function() {
                                                        try {
                                                            let e = sessionStorage.getItem(iX);
                                                            if (e) return e;
                                                            let t = et();
                                                            return sessionStorage.setItem(iX, t), t
                                                        } catch {
                                                            return
                                                        }
                                                    }() ? ? et()), _);
                                                    O.register(() => ({
                                                        tab: {
                                                            id: L
                                                        }
                                                    }));
                                                    let D = function(e, t, n, r) {
                                                            let i = i0();
                                                            return t.storeContextsAcrossPages && iQ(i, "rum", 2), e.register(() => {
                                                                let e = i.getContext();
                                                                return r ? {
                                                                    context: e
                                                                } : e
                                                            }), i
                                                        }(O, n, 0, !0),
                                                        P = function(e, t, n, r) {
                                                            let i = i1();
                                                            return t.storeContextsAcrossPages && iQ(i, "rum", 1), e.register(({
                                                                eventType: e,
                                                                startTime: r
                                                            }) => {
                                                                let o = i.getContext(),
                                                                    a = n.findTrackedSession(r);
                                                                return (a ? .anonymousId && !o.anonymous_id && t.trackAnonymousUser && (o.anonymous_id = a.anonymousId), Q(o)) ? tP : {
                                                                    type: e,
                                                                    usr: o
                                                                }
                                                            }), i
                                                        }(O, n, r, 0),
                                                        U = function(e, t, n) {
                                                            let r = i3();
                                                            return t.storeContextsAcrossPages && iQ(r, "rum", 4), e.register(() => {
                                                                let e = r.getContext();
                                                                return Q(e) || !e.id ? tP : {
                                                                    account: e
                                                                }
                                                            }), r
                                                        }(O, n, 0),
                                                        $ = function(e, t, n, r, i) {
                                                            let o, {
                                                                unsubscribe: a
                                                            } = e.subscribe(0, t => {
                                                                e.notify(13, r0(t))
                                                            });
                                                            i.trackUserInteractions && (o = function(e, t, n, r) {
                                                                let i, o = rD(e),
                                                                    a = new eC;
                                                                e.subscribe(5, c), e.subscribe(12, c);
                                                                let {
                                                                    stop: s
                                                                } = function({
                                                                    onPointerDown: e,
                                                                    onPointerUp: t
                                                                }) {
                                                                    let n, r, i = {
                                                                            selection: !1,
                                                                            input: !1,
                                                                            scroll: !1
                                                                        },
                                                                        o = [tf(window, td.POINTER_DOWN, t => {
                                                                            rz(t) && (n = rW(), i = {
                                                                                selection: !1,
                                                                                input: !1,
                                                                                scroll: !1
                                                                            }, r = e(t))
                                                                        }, {
                                                                            capture: !0
                                                                        }), tf(window, td.SELECTION_CHANGE, () => {
                                                                            n && rW() || (i.selection = !0)
                                                                        }, {
                                                                            capture: !0
                                                                        }), tf(window, td.SCROLL, () => {
                                                                            i.scroll = !0
                                                                        }, {
                                                                            capture: !0,
                                                                            passive: !0
                                                                        }), tf(window, td.POINTER_UP, e => {
                                                                            if (rz(e) && r) {
                                                                                let n = i;
                                                                                t(r, e, () => n), r = void 0
                                                                            }
                                                                        }, {
                                                                            capture: !0
                                                                        }), tf(window, td.INPUT, () => {
                                                                            i.input = !0
                                                                        }, {
                                                                            capture: !0
                                                                        })];
                                                                    return {
                                                                        stop: () => {
                                                                            o.forEach(e => e.stop())
                                                                        }
                                                                    }
                                                                }({
                                                                    onPointerDown: i => (function(e, t, n, r, i) {
                                                                        let o;
                                                                        if ((o = e.enablePrivacyForActionName ? nJ(rQ(r), e.defaultPrivacyLevel) : nW.ALLOW) === nW.HIDDEN) return;
                                                                        let a = function(e, t, n) {
                                                                                let r = rQ(e),
                                                                                    i = r.getBoundingClientRect(),
                                                                                    o = nP(r, n.actionNameAttribute),
                                                                                    a = function(e, t) {
                                                                                        let n = e.filter(e => e instanceof Element && !rP.includes(e.tagName));
                                                                                        if (0 === n.length) return "";
                                                                                        let r = t ? [t].concat(rU) : rU,
                                                                                            i = "";
                                                                                        for (let e of n)
                                                                                            if ((i += function(e, t) {
                                                                                                    let n = nV(e),
                                                                                                        r = n$(e),
                                                                                                        i = Array.from(e.classList).filter(e => !nU(e)).sort().map(e => `.${CSS.escape(e)}`).join(""),
                                                                                                        o = function(e, t) {
                                                                                                            let n = [];
                                                                                                            for (let r of Array.from(e.attributes)) t.includes(r.name) && n.push(nF(r.name, r.value));
                                                                                                            return n.sort().join("")
                                                                                                        }(e, t),
                                                                                                        a = function(e) {
                                                                                                            let t = Array.from(e.parentNode.children);
                                                                                                            if (t.length <= 1) return "";
                                                                                                            let n = t.filter(t => t.tagName === e.tagName),
                                                                                                                r = t.indexOf(e),
                                                                                                                i = nH(e);
                                                                                                            return `:nth-child(${r+1})${n.length>1?`:nth-of-type(${i})`:""}`
                                                                                                        }(e);
                                                                                                    return `${n}${r||""}${o}${i}${a};`
                                                                                                }(e, r)).length >= 2048) return ei(i, 2048);
                                                                                        return i
                                                                                    }(e.composedPath(), n.actionNameAttribute);
                                                                                o && rX(e.timeStamp, o);
                                                                                let {
                                                                                    name: s,
                                                                                    nameSource: u
                                                                                } = function(e, t, n = nW.ALLOW) {
                                                                                    let r = new Map,
                                                                                        {
                                                                                            actionNameAttribute: i
                                                                                        } = t,
                                                                                        o = r$(e, "data-dd-action-name") || i && r$(e, i);
                                                                                    return o ? {
                                                                                        name: o,
                                                                                        nameSource: "custom_attribute"
                                                                                    } : n === nW.MASK ? {
                                                                                        name: nN,
                                                                                        nameSource: "mask_placeholder"
                                                                                    } : rF(e, rV, t, r) || rF(e, rq, t, r) || {
                                                                                        name: "",
                                                                                        nameSource: "blank"
                                                                                    }
                                                                                }(r, n, t);
                                                                                return {
                                                                                    type: R.CLICK,
                                                                                    target: {
                                                                                        width: Math.round(i.width),
                                                                                        height: Math.round(i.height),
                                                                                        selector: o,
                                                                                        composedPathSelector: a || void 0
                                                                                    },
                                                                                    position: {
                                                                                        x: Math.round(e.clientX - i.left),
                                                                                        y: Math.round(e.clientY - i.top)
                                                                                    },
                                                                                    name: s,
                                                                                    nameSource: u
                                                                                }
                                                                            }(r, o, e),
                                                                            s = !1;
                                                                        return rI(t, n, i, e, e => {
                                                                            s = e.hadActivity
                                                                        }, 100), {
                                                                            clickActionBase: a,
                                                                            ignore: function(e) {
                                                                                let t = 0,
                                                                                    n = e;
                                                                                for (; n;) {
                                                                                    let e = n.getAttribute("data-dd-ignore-frustration");
                                                                                    if (null !== e) {
                                                                                        let n = e.split(/\s+/);
                                                                                        if ("" === e.trim() || n.includes("all")) return 7;
                                                                                        n.includes("rage-click") && (t |= 1), n.includes("dead-click") && (t |= 2), n.includes("error-click") && (t |= 4)
                                                                                    }
                                                                                    if (7 === t) break;
                                                                                    n = nx(n)
                                                                                }
                                                                                return t
                                                                            }(rQ(r)),
                                                                            hadActivityOnPointerDown: () => s
                                                                        }
                                                                    })(r, e, t, i, n),
                                                                    onPointerUp: ({
                                                                        clickActionBase: i,
                                                                        ignore: s,
                                                                        hadActivityOnPointerDown: c
                                                                    }, l, d) => {
                                                                        ! function(e, t, n, r, i, o, a, s, u, c, l, d) {
                                                                            let f = function e(t, n, r, i, o, a) {
                                                                                let s, u = et(),
                                                                                    c = K(a.timeStamp),
                                                                                    l = n.start(u, c, i, {
                                                                                        isChildEvent: rZ
                                                                                    });
                                                                                t.notify(16, l);
                                                                                let d = 0,
                                                                                    f = [],
                                                                                    p = new eC;

                                                                                function m(e) {
                                                                                    0 === d && (d = 1, s = e ? n.stop(u, B(e)) : n.discard(u), p.notify())
                                                                                }
                                                                                return {
                                                                                    event: a,
                                                                                    ignore: o,
                                                                                    stop: m,
                                                                                    stopObservable: p,
                                                                                    get hasError() {
                                                                                        let e = s ? .counts ? ? n.getCounts(u);
                                                                                        return !!e && e.errorCount > 0
                                                                                    },
                                                                                    get hasPageActivity() {
                                                                                        return s && "duration" in s
                                                                                    },
                                                                                    getUserActivity: r,
                                                                                    addFrustration: e => {
                                                                                        f.push(e)
                                                                                    },
                                                                                    get startClocks() {
                                                                                        return c
                                                                                    },
                                                                                    isStopped: () => 1 === d || 2 === d,
                                                                                    clone: () => e(t, n, r, i, o, a),
                                                                                    validate: e => {
                                                                                        if (m(), 1 !== d || !s) return;
                                                                                        let n = {
                                                                                            frustrationTypes: f,
                                                                                            events: e ? ? [a],
                                                                                            event: a,
                                                                                            ...s,
                                                                                            counts: s.counts
                                                                                        };
                                                                                        t.notify(0, n), d = 2
                                                                                    },
                                                                                    discard: () => {
                                                                                        m(), d = 2
                                                                                    }
                                                                                }
                                                                            }(t, i, l, s, u, c);
                                                                            a(f);
                                                                            let p = s ? .target ? .selector;
                                                                            p && rX(c.timeStamp, p);
                                                                            let {
                                                                                stop: m
                                                                            } = rI(t, n, r, e, e => {
                                                                                e.hadActivity && e.end < f.startClocks.timeStamp ? f.discard() : e.hadActivity ? f.stop(e.end) : d() ? f.stop(f.startClocks.timeStamp) : f.stop()
                                                                            }, 1e4), g = t.subscribe(5, ({
                                                                                endClocks: e
                                                                            }) => {
                                                                                f.stop(e.timeStamp)
                                                                            }), y = t.subscribe(12, () => {
                                                                                f.stop(q())
                                                                            }), v = o.subscribe(() => {
                                                                                f.stop()
                                                                            });
                                                                            f.stopObservable.subscribe(() => {
                                                                                y.unsubscribe(), g.unsubscribe(), m(), v.unsubscribe()
                                                                            })
                                                                        }(r, e, t, n, o, a, u, i, s, l, d, c)
                                                                    }
                                                                });
                                                                return {
                                                                    stop: () => {
                                                                        c(), a.notify(), s(), o.stopAll()
                                                                    },
                                                                    findActionId: o.findId
                                                                };

                                                                function u(e) {
                                                                    if (!i ? .tryAppend(e)) {
                                                                        let t = e.clone(),
                                                                            n = function(e, t) {
                                                                                let n, r = [],
                                                                                    i = 0;

                                                                                function o(e) {
                                                                                    e.stopObservable.subscribe(a), r.push(e), ex(n), n = eI(s, 1e3)
                                                                                }

                                                                                function a() {
                                                                                    1 === i && r.every(e => e.isStopped()) && (i = 2, t(r))
                                                                                }

                                                                                function s() {
                                                                                    ex(n), 0 === i && (i = 1, a())
                                                                                }
                                                                                return o(e), {
                                                                                    tryAppend: e => {
                                                                                        var t, n, a, u;
                                                                                        return 0 === i && (!(r.length > 0) || (t = r[r.length - 1], n = e, (1 & t.ignore) != 0 == ((1 & n.ignore) != 0) && t.event.target === n.event.target && 100 >= (a = t.event, u = n.event, Math.sqrt(Math.pow(a.clientX - u.clientX, 2) + Math.pow(a.clientY - u.clientY, 2))) && t.event.timeStamp - n.event.timeStamp <= 1e3) ? (o(e), !0) : (s(), !1))
                                                                                    },
                                                                                    stop: () => {
                                                                                        s()
                                                                                    }
                                                                                }
                                                                            }(e, e => {
                                                                                (function(e, t) {
                                                                                    let {
                                                                                        isRage: n
                                                                                    } = function(e, t) {
                                                                                        if (function(e) {
                                                                                                if (e.some(e => (1 & e.ignore) != 0 || e.getUserActivity().selection || e.getUserActivity().scroll)) return !1;
                                                                                                for (let t = 0; t < e.length - 2; t += 1)
                                                                                                    if (e[t + 3 - 1].event.timeStamp - e[t].event.timeStamp <= 1e3) return !0;
                                                                                                return !1
                                                                                            }(e)) return t.addFrustration(T.RAGE_CLICK), e.some(rY) && t.addFrustration(T.DEAD_CLICK), t.hasError && (4 & t.ignore) == 0 && t.addFrustration(T.ERROR_CLICK), {
                                                                                            isRage: !0
                                                                                        };
                                                                                        let n = e.some(e => e.getUserActivity().selection);
                                                                                        return e.forEach(e => {
                                                                                            e.hasError && (4 & e.ignore) == 0 && e.addFrustration(T.ERROR_CLICK), rY(e) && !n && e.addFrustration(T.DEAD_CLICK)
                                                                                        }), {
                                                                                            isRage: !1
                                                                                        }
                                                                                    }(e, t);
                                                                                    n ? (e.forEach(e => e.discard()), t.stop(q()), t.validate(e.map(e => e.event))) : (t.discard(), e.forEach(e => e.validate()))
                                                                                })(e, t), i === n && (i = void 0)
                                                                            });
                                                                        i = n
                                                                    }
                                                                }

                                                                function c() {
                                                                    i && i.stop()
                                                                }
                                                            }(e, n, r, i));
                                                            let s = function(e, t) {
                                                                    let n = rD(e);
                                                                    return {
                                                                        addAction: function(e) {
                                                                            t({
                                                                                id: et(),
                                                                                frustrationTypes: [],
                                                                                ...e
                                                                            })
                                                                        },
                                                                        startAction: function(t, r = {}, i = G()) {
                                                                            let o = r.actionKey ? ? t,
                                                                                a = n.start(o, i, {
                                                                                    name: t,
                                                                                    ...r
                                                                                }, {
                                                                                    isChildEvent: rZ
                                                                                });
                                                                            e.notify(16, a)
                                                                        },
                                                                        stopAction: function(e, r = {}, i = G()) {
                                                                            let o = r.actionKey ? ? e,
                                                                                a = n.stop(o, i, r);
                                                                            if (!a) return;
                                                                            let s = [];
                                                                            a.counts && a.counts.errorCount > 0 && s.push(T.ERROR_CLICK), t({ ...a,
                                                                                type: a.type || R.CUSTOM,
                                                                                frustrationTypes: s
                                                                            })
                                                                        },
                                                                        findActionId: n.findId,
                                                                        stop: n.stopAll
                                                                    }
                                                                }(e, t => {
                                                                    e.notify(13, r0(t))
                                                                }),
                                                                u = {
                                                                    findActionId: e => {
                                                                        let t = s.findActionId(e),
                                                                            n = o ? .findActionId(e) ? ? [];
                                                                        return t.concat(n)
                                                                    }
                                                                };
                                                            return t.assembleEventDefaults.register(({
                                                                startTime: e,
                                                                eventType: t
                                                            }) => {
                                                                if (t !== w.ERROR && t !== w.RESOURCE && t !== w.LONG_TASK) return tP;
                                                                let n = t === w.LONG_TASK ? e + 1 : e,
                                                                    r = u.findActionId(n);
                                                                return r.length ? {
                                                                    type: t,
                                                                    action: {
                                                                        id: r
                                                                    }
                                                                } : tP
                                                            }), t.assembleTelemetry.register(({
                                                                startTime: e
                                                            }) => ({
                                                                action: {
                                                                    id: u.findActionId(e)
                                                                }
                                                            })), {
                                                                addAction: s.addAction,
                                                                startAction: s.startAction,
                                                                stopAction: s.stopAction,
                                                                actionContexts: u,
                                                                stop: () => {
                                                                    a(), s.stop(), o ? .stop()
                                                                }
                                                            }
                                                        }(e, t, g, S, n);
                                                    m.push($.stop);
                                                    let Y = {
                                                            addEvent: (t, n, r, i) => {
                                                                iJ.includes(n.type) && e.notify(13, {
                                                                    startClocks: K(t),
                                                                    rawRumEvent: n,
                                                                    domainContext: r,
                                                                    duration: i
                                                                })
                                                            }
                                                        },
                                                        J = function(e) {
                                                            let t, n = requestAnimationFrame(eS(() => {
                                                                    t = iv()
                                                                })),
                                                                r = (!h && (h = new eC(e => {
                                                                    let {
                                                                        throttled: t
                                                                    } = eL(() => {
                                                                        e.notify(iv())
                                                                    }, 200);
                                                                    return tf(window, td.RESIZE, t, {
                                                                        capture: !0,
                                                                        passive: !0
                                                                    }).stop
                                                                })), h).subscribe(e => {
                                                                    t = e
                                                                }).unsubscribe;
                                                            return e.register(({
                                                                eventType: e
                                                            }) => ({
                                                                type: e,
                                                                display: t ? {
                                                                    viewport: t
                                                                } : void 0
                                                            })), {
                                                                stop: () => {
                                                                    r(), n && cancelAnimationFrame(n)
                                                                }
                                                            }
                                                        }(O);
                                                    m.push(J.stop);
                                                    let X = function(e, t = function(e) {
                                                        let t = iU() ? (e, t) => tf(eg.cookieStore, td.CHANGE, n => {
                                                            let r = n.changed.find(t => t.name === e) || n.deleted.find(t => t.name === e);
                                                            r && t(r.value)
                                                        }).stop : i$;
                                                        return new eC(n => t(e, e => n.notify(e)))
                                                    }("datadog-ci-visibility-test-execution-id")) {
                                                        let n = tJ("datadog-ci-visibility-test-execution-id") || function() {
                                                                let e = window.Cypress;
                                                                if (e) try {
                                                                    return e.env("traceId")
                                                                } catch {
                                                                    ep.warn("Failed to read Cypress test execution id via Cypress.env(). Upgrade dd-trace-js to >= 5.88.0 to keep RUM ↔ test correlation working.");
                                                                    return
                                                                }
                                                            }(),
                                                            r = t.subscribe(e => {
                                                                n = e
                                                            });
                                                        return e.register(({
                                                            eventType: e
                                                        }) => "string" != typeof n ? tP : {
                                                            type: e,
                                                            session: {
                                                                type: "ci_test"
                                                            },
                                                            ci_test: {
                                                                test_execution_id: n
                                                            }
                                                        }), {
                                                            stop: () => {
                                                                r.unsubscribe()
                                                            }
                                                        }
                                                    }(O);
                                                    m.push(X.stop), O.register(({
                                                        eventType: e
                                                    }) => iK() ? {
                                                        type: e,
                                                        session: {
                                                            type: "synthetics"
                                                        },
                                                        synthetics: { ...iK(),
                                                            injected: ij()
                                                        }
                                                    } : tP);
                                                    let Z = {
                                                        [w.ERROR]: iW(w.ERROR, u, void 0),
                                                        [w.ACTION]: iW(w.ACTION, u, f),
                                                        [w.VITAL]: iW(w.VITAL, u, f)
                                                    };
                                                    e.subscribe(13, ({
                                                        startClocks: r,
                                                        duration: i,
                                                        rawRumEvent: o,
                                                        domainContext: a
                                                    }) => {
                                                        let s = {
                                                                eventType: o.type,
                                                                rawRumEvent: o,
                                                                domainContext: a,
                                                                startTime: r.relative,
                                                                duration: i
                                                            },
                                                            u = t.assembleEventDefaults.trigger(s);
                                                        if (u === tD) return;
                                                        let c = t.assembleEvent.trigger(s);
                                                        if (c === tD) return;
                                                        let l = tN(u, o, c, {
                                                            ddtags: e1(n).join(",")
                                                        });
                                                        (function(e, t, n, r) {
                                                            if (t) {
                                                                let r = function(e, t, n) {
                                                                    let r = tx(e),
                                                                        i = n(r);
                                                                    return tl(t).forEach(([t, n]) => (function e(t, n, r, i) {
                                                                        let [o, ...a] = r;
                                                                        if ("[]" === o) {
                                                                            Array.isArray(t) && Array.isArray(n) && t.forEach((t, r) => e(t, n[r], a, i));
                                                                            return
                                                                        }
                                                                        if (iB(t) && iB(n)) {
                                                                            if (a.length > 0) return e(t[o], n[o], a, i);
                                                                            ! function(e, t, n, r) {
                                                                                if (e[t] === n) return;
                                                                                let i = z(n);
                                                                                i === r ? e[t] = rs(n) : "object" === r && ("undefined" === i || "null" === i) ? e[t] = {} : "array" === r && ("undefined" === i || "null" === i) && (e[t] = [])
                                                                            }(t, o, n[o], i)
                                                                        }
                                                                    })(e, r, t.split(/\.|(?=\[\])/), n)), i
                                                                }(e, iY[e.type], e => t(e, n));
                                                                if (!1 === r && e.type !== w.VIEW) return !1;
                                                                !1 === r && ep.warn("Can't dismiss view events using beforeSend!")
                                                            }
                                                            return !r[e.type] ? .isLimitReached()
                                                        })(l, n.beforeSend, a, Z) && (Q(l.context) && delete l.context, e.notify(14, l))
                                                    });
                                                    let {
                                                        addTiming: en,
                                                        setLoadingTime: er,
                                                        startView: eo,
                                                        setViewName: ea,
                                                        setViewContext: es,
                                                        setViewContextProperty: eu,
                                                        getViewContext: el,
                                                        stop: ed
                                                    } = (e.subscribe(4, t => e.notify(13, function(e, t, n) {
                                                        let r = n.getReplayStats(e.id),
                                                            i = e.commonViewMetrics ? .cumulativeLayoutShift ? .devicePixelRatio,
                                                            o = {
                                                                _dd: {
                                                                    document_version: e.documentVersion,
                                                                    replay_stats: r,
                                                                    cls: i ? {
                                                                        device_pixel_ratio: i
                                                                    } : void 0,
                                                                    configuration: {
                                                                        start_session_replay_recording_manually: t.startSessionReplayRecordingManually,
                                                                        remote_configuration_id: t.remoteConfigurationId
                                                                    }
                                                                },
                                                                date: e.startClocks.timeStamp,
                                                                type: w.VIEW,
                                                                view: {
                                                                    action: {
                                                                        count: e.eventCounts.actionCount
                                                                    },
                                                                    frustration: {
                                                                        count: e.eventCounts.frustrationCount
                                                                    },
                                                                    cumulative_layout_shift: e.commonViewMetrics.cumulativeLayoutShift ? .value,
                                                                    cumulative_layout_shift_time: F(e.commonViewMetrics.cumulativeLayoutShift ? .time),
                                                                    cumulative_layout_shift_target_selector: e.commonViewMetrics.cumulativeLayoutShift ? .targetSelector,
                                                                    first_byte: F(e.initialViewMetrics.navigationTimings ? .firstByte),
                                                                    dom_complete: F(e.initialViewMetrics.navigationTimings ? .domComplete),
                                                                    dom_content_loaded: F(e.initialViewMetrics.navigationTimings ? .domContentLoaded),
                                                                    dom_interactive: F(e.initialViewMetrics.navigationTimings ? .domInteractive),
                                                                    error: {
                                                                        count: e.eventCounts.errorCount
                                                                    },
                                                                    first_contentful_paint: F(e.initialViewMetrics.firstContentfulPaint),
                                                                    interaction_to_next_paint: F(e.commonViewMetrics.interactionToNextPaint ? .value),
                                                                    interaction_to_next_paint_time: F(e.commonViewMetrics.interactionToNextPaint ? .time),
                                                                    interaction_to_next_paint_target_selector: e.commonViewMetrics.interactionToNextPaint ? .targetSelector,
                                                                    is_active: e.isActive,
                                                                    name: e.name,
                                                                    largest_contentful_paint: F(e.initialViewMetrics.largestContentfulPaint ? .value),
                                                                    largest_contentful_paint_target_selector: e.initialViewMetrics.largestContentfulPaint ? .targetSelector,
                                                                    load_event: F(e.initialViewMetrics.navigationTimings ? .loadEvent),
                                                                    loading_time: rO(F(e.commonViewMetrics.loadingTime)),
                                                                    loading_type: e.loadingType,
                                                                    long_task: {
                                                                        count: e.eventCounts.longTaskCount
                                                                    },
                                                                    performance: function({
                                                                        cumulativeLayoutShift: e,
                                                                        interactionToNextPaint: t
                                                                    }, {
                                                                        firstContentfulPaint: n,
                                                                        largestContentfulPaint: r
                                                                    }) {
                                                                        return {
                                                                            cls: e && {
                                                                                score: e.value,
                                                                                timestamp: F(e.time),
                                                                                target_selector: e.targetSelector,
                                                                                previous_rect: e.previousRect,
                                                                                current_rect: e.currentRect
                                                                            },
                                                                            fcp: n && {
                                                                                timestamp: F(n)
                                                                            },
                                                                            inp: t && {
                                                                                duration: F(t.value),
                                                                                timestamp: F(t.time),
                                                                                target_selector: t.targetSelector,
                                                                                sub_parts: t.subParts ? {
                                                                                    input_delay: F(t.subParts.inputDelay),
                                                                                    processing_duration: F(t.subParts.processingDuration),
                                                                                    presentation_delay: F(t.subParts.presentationDelay)
                                                                                } : void 0
                                                                            },
                                                                            lcp: r && {
                                                                                timestamp: F(r.value),
                                                                                target_selector: r.targetSelector,
                                                                                resource_url: r.resourceUrl,
                                                                                sub_parts: r.subParts ? {
                                                                                    load_delay: F(r.subParts.loadDelay),
                                                                                    load_time: F(r.subParts.loadTime),
                                                                                    render_delay: F(r.subParts.renderDelay)
                                                                                } : void 0
                                                                            }
                                                                        }
                                                                    }(e.commonViewMetrics, e.initialViewMetrics),
                                                                    resource: {
                                                                        count: e.eventCounts.resourceCount
                                                                    },
                                                                    time_spent: F(e.duration)
                                                                },
                                                                display: e.commonViewMetrics.scroll ? {
                                                                    scroll: {
                                                                        max_depth: e.commonViewMetrics.scroll.maxDepth,
                                                                        max_depth_scroll_top: e.commonViewMetrics.scroll.maxDepthScrollTop,
                                                                        max_scroll_height: e.commonViewMetrics.scroll.maxScrollHeight,
                                                                        max_scroll_height_time: F(e.commonViewMetrics.scroll.maxScrollHeightTime)
                                                                    }
                                                                } : void 0,
                                                                privacy: {
                                                                    replay_level: t.defaultPrivacyLevel
                                                                },
                                                                device: {
                                                                    locale: navigator.language,
                                                                    locales: navigator.languages,
                                                                    time_zone: function() {
                                                                        try {
                                                                            return new Intl.DateTimeFormat().resolvedOptions().timeZone
                                                                        } catch {
                                                                            return
                                                                        }
                                                                    }()
                                                                }
                                                            };
                                                        return Q(e.customTimings) || (o.view.custom_timings = ee(e.customTimings, F)), {
                                                            rawRumEvent: o,
                                                            startClocks: e.startClocks,
                                                            duration: e.duration,
                                                            domainContext: {
                                                                location: e.location,
                                                                handlingStack: e.handlingStack
                                                            }
                                                        }
                                                    }(t, n, i))), t.assembleEventDefaults.register(({
                                                        startTime: e,
                                                        eventType: t
                                                    }) => {
                                                        let n = x.findView(e);
                                                        return n ? {
                                                            type: t,
                                                            service: n.service,
                                                            version: n.version,
                                                            context: n.context,
                                                            view: {
                                                                id: n.id,
                                                                name: n.name
                                                            }
                                                        } : tD
                                                    }), t.assembleTelemetry.register(({
                                                        startTime: e
                                                    }) => ({
                                                        view: {
                                                            id: x.findView(e) ? .id
                                                        }
                                                    })), function(e, t, n, r, i, o, a) {
                                                        let s, u, c = new Set,
                                                            l = d(A.INITIAL_LOAD, j(), a);

                                                        function d(i, o, a) {
                                                            let s = function(e, t, n, r, i, o = G(), a) {
                                                                var s;
                                                                let u, c = et(),
                                                                    l = new eC,
                                                                    d = {},
                                                                    f = 0,
                                                                    p = { ...window.location
                                                                    },
                                                                    m = iS(),
                                                                    g = !0,
                                                                    y = a ? .name,
                                                                    h = a ? .service || r.service,
                                                                    b = a ? .version || r.version,
                                                                    S = a ? .context,
                                                                    _ = a ? .handlingStack;
                                                                S && m.setContext(S);
                                                                let E = {
                                                                    id: c,
                                                                    name: y,
                                                                    startClocks: o,
                                                                    service: h,
                                                                    version: b,
                                                                    context: S,
                                                                    url: a ? .url
                                                                };
                                                                e.notify(1, E), e.notify(2, E);
                                                                let {
                                                                    throttled: w,
                                                                    cancel: C
                                                                } = eL(F, 3e3, {
                                                                    leading: !1
                                                                }), {
                                                                    setLoadEvent: R,
                                                                    setViewEnd: T,
                                                                    stop: k,
                                                                    stopINPTracking: O,
                                                                    getCommonViewMetrics: I,
                                                                    setLoadingTime: x
                                                                } = function(e, t, n, r, i, o, a) {
                                                                    let s = {},
                                                                        u = !1,
                                                                        c = !1,
                                                                        {
                                                                            stop: l,
                                                                            setLoadEvent: d
                                                                        } = function(e, t, n, r, i, o, a) {
                                                                            let s = i === A.INITIAL_LOAD,
                                                                                u = !0,
                                                                                c = [],
                                                                                l = is(o);

                                                                            function d() {
                                                                                if (!u && !s && c.length > 0) {
                                                                                    let e = Math.max(...c);
                                                                                    e < l.timeStamp - o.relative && a(e)
                                                                                }
                                                                            }
                                                                            let {
                                                                                stop: f
                                                                            } = rI(e, t, n, r, e => {
                                                                                if (u) {
                                                                                    var t;
                                                                                    u = !1, e.hadActivity && c.push((t = o.timeStamp, e.end - t)), d()
                                                                                }
                                                                            });
                                                                            return {
                                                                                stop: () => {
                                                                                    f(), l.stop()
                                                                                },
                                                                                setLoadEvent: e => {
                                                                                    s && (s = !1, c.push(e), d())
                                                                                }
                                                                            }
                                                                        }(e, t, n, r, o, a, e => {
                                                                            u || (s.loadingTime = e, i())
                                                                        }),
                                                                        {
                                                                            stop: f
                                                                        } = function(e, t, n = function(e = 1e3) {
                                                                            return new eC(t => {
                                                                                let n = eL(function() {
                                                                                        t.notify(function() {
                                                                                            let e = function() {
                                                                                                    let e = window.visualViewport;
                                                                                                    return Math.round(e ? e.pageTop - e.offsetTop : void 0 !== window.scrollY ? window.scrollY : window.pageYOffset || 0)
                                                                                                }(),
                                                                                                {
                                                                                                    height: t
                                                                                                } = iv();
                                                                                            return {
                                                                                                scrollHeight: Math.round((document.scrollingElement || document.documentElement).scrollHeight),
                                                                                                scrollDepth: Math.round(t + e),
                                                                                                scrollTop: e
                                                                                            }
                                                                                        }())
                                                                                    }, e, {
                                                                                        leading: !1,
                                                                                        trailing: !0
                                                                                    }),
                                                                                    r = document.scrollingElement || document.documentElement,
                                                                                    i = new ResizeObserver(eS(n.throttled));
                                                                                r && i.observe(r);
                                                                                let o = tf(window, td.SCROLL, n.throttled, {
                                                                                    passive: !0
                                                                                });
                                                                                return () => {
                                                                                    n.cancel(), i.disconnect(), o.stop()
                                                                                }
                                                                            })
                                                                        }()) {
                                                                            let r = 0,
                                                                                i = 0,
                                                                                o = 0,
                                                                                a = n.subscribe(({
                                                                                    scrollDepth: n,
                                                                                    scrollTop: a,
                                                                                    scrollHeight: s
                                                                                }) => {
                                                                                    let u = !1;
                                                                                    (n > r && (r = n, u = !0), s > i) && (i = s, o = H() - e.relative, u = !0);
                                                                                    u && t({
                                                                                        maxDepth: Math.min(r, i),
                                                                                        maxDepthScrollTop: a,
                                                                                        maxScrollHeight: i,
                                                                                        maxScrollHeightTime: o
                                                                                    })
                                                                                });
                                                                            return {
                                                                                stop: () => a.unsubscribe()
                                                                            }
                                                                        }(a, e => {
                                                                            s.scroll = e
                                                                        }),
                                                                        {
                                                                            stop: p
                                                                        } = function(e, t, n) {
                                                                            let r, i, o, a, s;
                                                                            if (!(nT("layout-shift") && "WeakRef" in window)) return {
                                                                                stop: eD
                                                                            };
                                                                            let u = 0;
                                                                            n({
                                                                                value: 0
                                                                            });
                                                                            let c = (a = 0, s = 0, {
                                                                                    update: e => {
                                                                                        let t;
                                                                                        return void 0 === i || e.startTime - o >= 1e3 || e.startTime - i >= 5e3 ? (i = o = e.startTime, s = a = e.value, t = !0) : (a += e.value, o = e.startTime, (t = e.value > s) && (s = e.value)), {
                                                                                            cumulatedValue: a,
                                                                                            isMaxValue: t
                                                                                        }
                                                                                    }
                                                                                }),
                                                                                l = nR({
                                                                                    type: "layout-shift",
                                                                                    buffered: !0
                                                                                }).subscribe(i => {
                                                                                    for (let o of i) {
                                                                                        if (o.hadRecentInput || o.startTime < t) continue;
                                                                                        let {
                                                                                            cumulatedValue: i,
                                                                                            isMaxValue: a
                                                                                        } = c.update(o);
                                                                                        if (a) {
                                                                                            let e = function(e) {
                                                                                                let t;
                                                                                                for (let n of e)
                                                                                                    if (n.node && nO(n.node)) {
                                                                                                        let e = iu(n);
                                                                                                        (!t || iu(t) < e) && (t = n)
                                                                                                    }
                                                                                                return t
                                                                                            }(o.sources);
                                                                                            r = {
                                                                                                target: e ? .node ? new WeakRef(e.node) : void 0,
                                                                                                time: o.startTime - t,
                                                                                                previousRect: e ? .previousRect,
                                                                                                currentRect: e ? .currentRect,
                                                                                                devicePixelRatio: window.devicePixelRatio
                                                                                            }
                                                                                        }
                                                                                        if (i > u) {
                                                                                            u = i;
                                                                                            let t = r ? .target ? .deref();
                                                                                            n({
                                                                                                value: t9(u, 4),
                                                                                                targetSelector: t && nP(t, e.actionNameAttribute),
                                                                                                time: r ? .time,
                                                                                                previousRect: r ? .previousRect ? ic(r.previousRect) : void 0,
                                                                                                currentRect: r ? .currentRect ? ic(r.currentRect) : void 0,
                                                                                                devicePixelRatio: r ? .devicePixelRatio
                                                                                            })
                                                                                        }
                                                                                    }
                                                                                });
                                                                            return {
                                                                                stop: () => {
                                                                                    l.unsubscribe()
                                                                                }
                                                                            }
                                                                        }(r, a.relative, e => {
                                                                            s.cumulativeLayoutShift = e, i()
                                                                        }),
                                                                        {
                                                                            stop: m,
                                                                            getInteractionToNextPaint: g,
                                                                            setViewEnd: y
                                                                        } = function(e, t, n) {
                                                                            let r;
                                                                            if (!(nT("event") && window.PerformanceEventTiming && "interactionId" in PerformanceEventTiming.prototype)) return {
                                                                                getInteractionToNextPaint: () => void 0,
                                                                                setViewEnd: eD,
                                                                                stop: eD
                                                                            };
                                                                            let i = 1 / 0,
                                                                                {
                                                                                    getViewInteractionCount: o,
                                                                                    stopViewInteractionCount: a
                                                                                } = function(e) {
                                                                                    "interactionCount" in performance || v || (v = new window.PerformanceObserver(eS(e => {
                                                                                        e.getEntries().forEach(e => {
                                                                                            e.interactionId && (id = Math.min(id, e.interactionId), il = ((ip = Math.max(ip, e.interactionId)) - id) / 7 + 1)
                                                                                        })
                                                                                    }))).observe({
                                                                                        type: "event",
                                                                                        buffered: !0,
                                                                                        durationThreshold: 0
                                                                                    });
                                                                                    let t = e === A.INITIAL_LOAD ? 0 : im(),
                                                                                        n = {
                                                                                            stopped: !1
                                                                                        };
                                                                                    return {
                                                                                        getViewInteractionCount: () => n.stopped ? n.interactionCount : im() - t,
                                                                                        stopViewInteractionCount: () => {
                                                                                            n = {
                                                                                                stopped: !0,
                                                                                                interactionCount: im() - t
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }(n),
                                                                                s = function(e) {
                                                                                    let t = [];

                                                                                    function n() {
                                                                                        t.sort((e, t) => t.duration - e.duration).splice(10)
                                                                                    }
                                                                                    return {
                                                                                        process(e) {
                                                                                            let r = t.findIndex(t => e.interactionId === t.interactionId),
                                                                                                i = t[t.length - 1]; - 1 !== r ? e.duration > t[r].duration && (t[r] = e, n()) : (t.length < 10 || e.duration > i.duration) && (t.push(e), n())
                                                                                        },
                                                                                        estimateP98Interaction() {
                                                                                            let n = Math.min(t.length - 1, Math.floor(e() / 50));
                                                                                            return t[n]
                                                                                        },
                                                                                        isTracked: e => t.some(t => t.interactionId === e)
                                                                                    }
                                                                                }(o),
                                                                                u = function(e) {
                                                                                    let t = new Map;

                                                                                    function n(e, t) {
                                                                                        e.startTime = Math.min(t.startTime, e.startTime), e.processingStart = Math.min(t.processingStart, e.processingStart), e.processingEnd = Math.max(t.processingEnd, e.processingEnd)
                                                                                    }
                                                                                    return {
                                                                                        process(e) {
                                                                                            if (void 0 === e.interactionId || !e.processingStart || !e.processingEnd) return;
                                                                                            let r = e.startTime + e.duration,
                                                                                                i = t.get(e.interactionId);
                                                                                            if (i) return void n(i, e);
                                                                                            for (let [, i] of t.entries())
                                                                                                if (8 >= Math.abs(r - i.referenceRenderTime)) {
                                                                                                    n(i, e), t.set(e.interactionId, i);
                                                                                                    return
                                                                                                }
                                                                                            t.set(e.interactionId, {
                                                                                                startTime: e.startTime,
                                                                                                processingStart: e.processingStart,
                                                                                                processingEnd: e.processingEnd,
                                                                                                referenceRenderTime: r
                                                                                            })
                                                                                        },
                                                                                        pruneUntracked() {
                                                                                            for (let [n] of t) e.isTracked(n) || t.delete(n)
                                                                                        },
                                                                                        computeSubParts(e, n) {
                                                                                            var r;
                                                                                            if (!e.processingStart || !e.processingEnd || void 0 === e.interactionId) return;
                                                                                            let i = t.get(e.interactionId);
                                                                                            if (!i) return;
                                                                                            let o = Math.max(i.startTime + n, i.processingStart),
                                                                                                a = Math.min(i.processingEnd, o);
                                                                                            return {
                                                                                                inputDelay: (r = i.startTime, i.processingStart - r),
                                                                                                processingDuration: a - i.processingStart,
                                                                                                presentationDelay: o - a
                                                                                            }
                                                                                        },
                                                                                        stop() {
                                                                                            t.clear()
                                                                                        }
                                                                                    }
                                                                                }(s),
                                                                                c = nR({
                                                                                    type: "first-input",
                                                                                    buffered: !0
                                                                                }).subscribe(d),
                                                                                l = nR({
                                                                                    type: "event",
                                                                                    durationThreshold: 40,
                                                                                    buffered: !0
                                                                                }).subscribe(d);

                                                                            function d(n) {
                                                                                for (let e of n) e.interactionId && e.startTime >= t && e.startTime <= i && (s.process(e), u.process(e));
                                                                                u.pruneUntracked();
                                                                                let o = s.estimateP98Interaction();
                                                                                o && function(n) {
                                                                                    let i = n.startTime - t;
                                                                                    if (n.duration !== r ? .duration || i !== r.startTime) {
                                                                                        let t = function(e) {
                                                                                            let t = rJ.get(e);
                                                                                            return rJ.delete(e), t
                                                                                        }(n.startTime);
                                                                                        !t && n.target && nO(n.target) && (t = nP(n.target, e.actionNameAttribute)), r = {
                                                                                            duration: n.duration,
                                                                                            startTime: i,
                                                                                            targetSelector: t
                                                                                        }
                                                                                    }
                                                                                    r.subParts = u.computeSubParts(n, iy(r.duration))
                                                                                }(o)
                                                                            }
                                                                            return {
                                                                                getInteractionToNextPaint: () => r ? {
                                                                                    value: iy(r.duration),
                                                                                    targetSelector: r.targetSelector,
                                                                                    time: r.startTime,
                                                                                    subParts: r.subParts
                                                                                } : o() ? {
                                                                                    value: 0
                                                                                } : void 0,
                                                                                setViewEnd: e => {
                                                                                    i = e, a()
                                                                                },
                                                                                stop: () => {
                                                                                    l.unsubscribe(), c.unsubscribe(), u.stop()
                                                                                }
                                                                            }
                                                                        }(r, a.relative, o);
                                                                    return {
                                                                        stop: () => {
                                                                            l(), p(), f()
                                                                        },
                                                                        stopINPTracking: m,
                                                                        setLoadEvent: d,
                                                                        setViewEnd: e => {
                                                                            c = !0, y(e)
                                                                        },
                                                                        getCommonViewMetrics: () => (s.interactionToNextPaint = g(), s),
                                                                        setLoadingTime: e => {
                                                                            var t;
                                                                            if (c) return;
                                                                            let n = (t = a.timeStamp, (e ? ? q()) - t);
                                                                            u || l(), u = !0, s.loadingTime = n, i()
                                                                        }
                                                                    }
                                                                }(e, t, n, r, V, i, o), {
                                                                    stop: N,
                                                                    initialViewMetrics: M
                                                                } = i === A.INITIAL_LOAD ? function(e, t, n, r) {
                                                                    var i, o;
                                                                    let a = {},
                                                                        {
                                                                            stop: s
                                                                        } = (i = e => {
                                                                            n(e.loadEvent), a.navigationTimings = e, r()
                                                                        }, function(e) {
                                                                            let t, {
                                                                                stop: n
                                                                            } = r9("complete", () => {
                                                                                t = eI(() => e())
                                                                            });
                                                                            return {
                                                                                stop: () => {
                                                                                    n(), ex(t)
                                                                                }
                                                                            }
                                                                        }(() => {
                                                                            var e;
                                                                            let t = r4();
                                                                            t.loadEventEnd <= 0 || i({
                                                                                domComplete: (e = t).domComplete,
                                                                                domContentLoaded: e.domContentLoadedEventEnd,
                                                                                domInteractive: e.domInteractive,
                                                                                loadEvent: e.loadEventEnd,
                                                                                firstByte: r5(e)
                                                                            })
                                                                        })),
                                                                        u = is(t),
                                                                        {
                                                                            stop: c
                                                                        } = (o = e => {
                                                                            a.firstContentfulPaint = e, r()
                                                                        }, {
                                                                            stop: nR({
                                                                                type: "paint",
                                                                                buffered: !0
                                                                            }).subscribe(e => {
                                                                                let t = e.find(e => "first-contentful-paint" === e.name && e.startTime < u.timeStamp && e.startTime < io);
                                                                                t && o(t.startTime)
                                                                            }).unsubscribe
                                                                        }),
                                                                        {
                                                                            stop: l
                                                                        } = function(e, t, n, r) {
                                                                            let i = 1 / 0,
                                                                                {
                                                                                    stop: o
                                                                                } = tp(n, [td.POINTER_DOWN, td.KEY_DOWN], e => {
                                                                                    i = e.timeStamp
                                                                                }, {
                                                                                    capture: !0,
                                                                                    once: !0
                                                                                }),
                                                                                a = 0,
                                                                                s = nR({
                                                                                    type: "largest-contentful-paint",
                                                                                    buffered: !0
                                                                                }).subscribe(n => {
                                                                                    let o = tu(n, e => "largest-contentful-paint" === e.entryType && e.startTime < i && e.startTime < t.timeStamp && e.startTime < ia && e.size > a);
                                                                                    if (o) {
                                                                                        var s;
                                                                                        let t;
                                                                                        o.element && (t = nP(o.element, e.actionNameAttribute));
                                                                                        let n = "" === (s = o).url ? void 0 : s.url,
                                                                                            i = o.startTime,
                                                                                            u = function(e, t) {
                                                                                                let n = r5(r4());
                                                                                                if (void 0 === n) return;
                                                                                                let r = e ? function(e, t) {
                                                                                                        let n = function() {
                                                                                                            if (nT("resource")) return performance.getEntriesByType("resource")
                                                                                                        }();
                                                                                                        if (n) return tu(n, n => n.name === e && n.startTime <= t)
                                                                                                    }(e, t) : void 0,
                                                                                                    i = r ? Math.max(n, r.requestStart || r.startTime) : n,
                                                                                                    o = Math.min(t, Math.max(i, r ? .responseEnd || 0));
                                                                                                return {
                                                                                                    loadDelay: i - n,
                                                                                                    loadTime: o - i,
                                                                                                    renderDelay: t - o
                                                                                                }
                                                                                            }(n, i);
                                                                                        r({
                                                                                            value: i,
                                                                                            targetSelector: t,
                                                                                            resourceUrl: n,
                                                                                            subParts: u
                                                                                        }), a = o.size
                                                                                    }
                                                                                });
                                                                            return {
                                                                                stop: () => {
                                                                                    o(), s.unsubscribe()
                                                                                }
                                                                            }
                                                                        }(e, u, window, e => {
                                                                            a.largestContentfulPaint = e, r()
                                                                        });
                                                                    return {
                                                                        stop: function() {
                                                                            s(), c(), l(), u.stop()
                                                                        },
                                                                        initialViewMetrics: a
                                                                    }
                                                                }(r, o, R, V) : {
                                                                    stop: eD,
                                                                    initialViewMetrics: {}
                                                                };
                                                                i === A.BF_CACHE && (s = o.relative, requestAnimationFrame(() => {
                                                                    requestAnimationFrame(() => {
                                                                        (e => {
                                                                            M.firstContentfulPaint = e, M.largestContentfulPaint = {
                                                                                value: e
                                                                            }, V()
                                                                        })(H() - s)
                                                                    })
                                                                }));
                                                                let {
                                                                    stop: L,
                                                                    eventCounts: D
                                                                } = function(e, t, n) {
                                                                    let {
                                                                        stop: r,
                                                                        eventCounts: i
                                                                    } = rM({
                                                                        lifeCycle: e,
                                                                        isChildEvent: e => e.view.id === t,
                                                                        onChange: n
                                                                    });
                                                                    return {
                                                                        stop: r,
                                                                        eventCounts: i
                                                                    }
                                                                }(e, c, V), P = eN(F, i_), U = e.subscribe(12, e => {
                                                                    e === tg.UNLOADING && F()
                                                                });

                                                                function $() {
                                                                    e.notify(3, {
                                                                        id: c,
                                                                        name: y,
                                                                        context: m.getContext(),
                                                                        startClocks: o,
                                                                        sessionIsActive: g
                                                                    })
                                                                }

                                                                function V() {
                                                                    $(), w()
                                                                }

                                                                function F() {
                                                                    C(), $(), f += 1;
                                                                    let t = void 0 === u ? q() : u.timeStamp;
                                                                    e.notify(4, {
                                                                        customTimings: d,
                                                                        documentVersion: f,
                                                                        id: c,
                                                                        name: y,
                                                                        service: h,
                                                                        version: b,
                                                                        context: m.getContext(),
                                                                        loadingType: i,
                                                                        location: p,
                                                                        handlingStack: _,
                                                                        startClocks: o,
                                                                        commonViewMetrics: I(),
                                                                        initialViewMetrics: M,
                                                                        duration: t - o.timeStamp,
                                                                        isActive: void 0 === u,
                                                                        sessionIsActive: g,
                                                                        eventCounts: D
                                                                    })
                                                                }
                                                                return F(), m.changeObservable.subscribe(V), {
                                                                    get name() {
                                                                        return y
                                                                    },
                                                                    service: h,
                                                                    version: b,
                                                                    contextManager: m,
                                                                    stopObservable: l,
                                                                    end(t = {}) {
                                                                        u || (u = t.endClocks ? ? G(), g = t.sessionIsActive ? ? !0, e.notify(5, {
                                                                            endClocks: u
                                                                        }), e.notify(6, {
                                                                            endClocks: u
                                                                        }), eM(P), T(u.relative), k(), U.unsubscribe(), F(), eI(() => {
                                                                            this.stop()
                                                                        }, iE))
                                                                    },
                                                                    stop() {
                                                                        N(), L(), O(), l.notify()
                                                                    },
                                                                    addTiming(e, t) {
                                                                        if (u) return;
                                                                        let n = t < 31536e6 ? t : t - o.timeStamp;
                                                                        d[function(e) {
                                                                            let t = e.replace(/[^a-zA-Z0-9-_.@$]/g, "_");
                                                                            return t !== e && ep.warn(`Invalid timing name: ${e}, sanitized to: ${t}`), t
                                                                        }(e)] = n, V()
                                                                    },
                                                                    setLoadingTime: x,
                                                                    setViewName(e) {
                                                                        y = e, F()
                                                                    }
                                                                }
                                                            }(e, t, n, r, i, o, a);
                                                            return c.add(s), s.stopObservable.subscribe(() => {
                                                                c.delete(s)
                                                            }), s
                                                        }
                                                        return e.subscribe(11, () => {
                                                            l = d(A.SESSION_RENEWAL, void 0, {
                                                                name: l.name,
                                                                service: l.service,
                                                                version: l.version,
                                                                context: l.contextManager.getContext()
                                                            })
                                                        }), e.subscribe(10, ({
                                                            endClocks: e
                                                        }) => {
                                                            l.end({
                                                                sessionIsActive: !1,
                                                                endClocks: e
                                                            })
                                                        }), o && (u = i.subscribe(({
                                                            oldLocation: e,
                                                            newLocation: t
                                                        }) => {
                                                            var n, r;
                                                            n = e, r = t, (n.pathname !== r.pathname || ! function(e) {
                                                                let t = e.substring(1);
                                                                return "" !== t && !!document.getElementById(t)
                                                            }(r.hash) && iw(r.hash) !== iw(n.hash)) && (l.end(), l = d(A.ROUTE_CHANGE))
                                                        }), s = function(e) {
                                                            let {
                                                                stop: t
                                                            } = tf(window, td.PAGE_SHOW, t => {
                                                                t.persisted && e(t)
                                                            }, {
                                                                capture: !0
                                                            });
                                                            return t
                                                        }(e => {
                                                            l.end();
                                                            let t = K(e.timeStamp);
                                                            l = d(A.BF_CACHE, t, void 0)
                                                        })), {
                                                            addTiming: (e, t = q()) => {
                                                                l.addTiming(e, t)
                                                            },
                                                            setLoadingTime: e => l.setLoadingTime(e),
                                                            startView: (e, t) => {
                                                                l.end({
                                                                    endClocks: t
                                                                }), l = d(A.ROUTE_CHANGE, t, e)
                                                            },
                                                            setViewContext: e => {
                                                                l.contextManager.setContext(e)
                                                            },
                                                            setViewContextProperty: (e, t) => {
                                                                l.contextManager.setContextProperty(e, t)
                                                            },
                                                            setViewName: e => {
                                                                l.setViewName(e)
                                                            },
                                                            getViewContext: () => l.contextManager.getContext(),
                                                            stop: () => {
                                                                u && u.unsubscribe(), s && s(), l.end(), c.forEach(e => e.stop())
                                                            }
                                                        }
                                                    }(e, g, S, n, b, !n.trackViewsManually, o));
                                                    O.register(({
                                                        domainContext: e,
                                                        rawRumEvent: t
                                                    }) => {
                                                        var n, r;
                                                        let i, o = (n = e, "long_task" === (r = t).type && "long-animation-frame" === r.long_task.entry_type ? r.long_task.scripts[0] ? .source_url : ("handlingStack" in n && (i = n.handlingStack), "error" === r.type && r.error.stack && (i = r.error.stack), eP({
                                                            stack: i
                                                        }).stack[0] ? .url));
                                                        if (!o) return tP;
                                                        let a = (rp(), rl.get(o));
                                                        return a ? {
                                                            type: t.type,
                                                            service: a.service,
                                                            version: a.version
                                                        } : tP
                                                    }), m.push(ed);
                                                    let ef = function(e, t) {
                                                        let n = function() {
                                                                let e = [];

                                                                function t(t) {
                                                                    let r;
                                                                    if (!t || t.didTimeout) {
                                                                        let e = performance.now();
                                                                        r = () => 30 - (performance.now() - e)
                                                                    } else r = t.timeRemaining.bind(t);
                                                                    for (; r() > 0 && e.length;) e.shift()();
                                                                    e.length && n()
                                                                }

                                                                function n() {
                                                                    ! function(e, t) {
                                                                        if (window.requestIdleCallback && window.cancelIdleCallback) {
                                                                            let n = window.requestIdleCallback(eS(e), t);
                                                                            return () => window.cancelIdleCallback(n)
                                                                        }
                                                                        var n = e;
                                                                        let r = V(),
                                                                            i = eI(() => {
                                                                                n({
                                                                                    didTimeout: !1,
                                                                                    timeRemaining: () => Math.max(0, 50 - (V() - r))
                                                                                })
                                                                            }, 0)
                                                                    }(t, {
                                                                        timeout: 1e3
                                                                    })
                                                                }
                                                                return {
                                                                    push(t) {
                                                                        1 === e.push(t) && n()
                                                                    },
                                                                    stop() {
                                                                        e.length = 0
                                                                    }
                                                                }
                                                            }(),
                                                            r = function(e) {
                                                                let t = new Set,
                                                                    n = e.subscribe(8, e => {
                                                                        t.add(e), t.size > 1e3 && t.delete(t.values().next().value)
                                                                    });
                                                                return {
                                                                    getMatchingRequest(e) {
                                                                        let n, r = 1 / 0;
                                                                        for (let i of t) {
                                                                            let t = e.startTime - i.startClocks.relative;
                                                                            0 <= t && t < r && i.url === e.name && (r = Math.abs(t), n = i)
                                                                        }
                                                                        return n && t.delete(n), n
                                                                    },
                                                                    stop() {
                                                                        n.unsubscribe()
                                                                    }
                                                                }
                                                            }(e);
                                                        e.subscribe(9, n => {
                                                            let r = function(e, t) {
                                                                var n;
                                                                let r = (n = e.startClocks.timeStamp, e.endClocks.timeStamp - n),
                                                                    i = {
                                                                        date: e.startClocks.timeStamp,
                                                                        type: w.RESOURCE,
                                                                        resource: {
                                                                            id: et(),
                                                                            type: nh.WEBSOCKET,
                                                                            url: e.url,
                                                                            duration: F(r),
                                                                            websocket: {
                                                                                connection_id: e.connectionId,
                                                                                handshake_succeeded: e.handshakeSucceeded,
                                                                                start_time: e.startClocks.timeStamp,
                                                                                end_time: e.endClocks.timeStamp,
                                                                                start_view_id: e.startViewId,
                                                                                end_view_id: e.endViewId,
                                                                                tracking_end_reason: e.trackingEndReason,
                                                                                close_code: e.closeCode,
                                                                                close_reason: e.closeReason,
                                                                                was_clean: e.wasClean,
                                                                                messages_in: e.messagesIn,
                                                                                messages_out: e.messagesOut,
                                                                                time_to_first_message_in: F(e.firstMessageInOffset),
                                                                                time_to_first_message_out: F(e.firstMessageOutOffset),
                                                                                last_message_in_at: e.lastMessageInAt,
                                                                                longest_inbound_silence: F(e.longestInboundSilence),
                                                                                inbound_idle_duration_before_close: F(e.inboundIdleDurationBeforeClose),
                                                                                buffered_amount_max: e.bufferedAmountMax,
                                                                                protocol: e.protocol,
                                                                                setup_duration: F(e.setupDuration)
                                                                            }
                                                                        },
                                                                        _dd: {
                                                                            discarded: !t.trackResources
                                                                        }
                                                                    };
                                                                return {
                                                                    startClocks: e.startClocks,
                                                                    duration: r,
                                                                    rawRumEvent: i,
                                                                    domainContext: {
                                                                        isWebSocket: !0,
                                                                        isManual: !1,
                                                                        webSocket: e.webSocket
                                                                    }
                                                                }
                                                            }(n, t);
                                                            r && e.notify(13, r)
                                                        });
                                                        let i = nR({
                                                                type: "resource",
                                                                buffered: !0
                                                            }).subscribe(n => {
                                                                for (let i of n) "xmlhttprequest" === i.initiatorType || "fetch" === i.initiatorType ? eI(() => {
                                                                    let n = ie(i, r.getMatchingRequest(i), t);
                                                                    n && e.notify(13, n)
                                                                }, 50) : a(() => ie(i, void 0, t))
                                                            }),
                                                            {
                                                                stop: o
                                                            } = r9("interactive", () => {
                                                                a(() => ie(r4(), void 0, t))
                                                            });

                                                        function a(t) {
                                                            n.push(() => {
                                                                let n = t();
                                                                n && e.notify(13, n)
                                                            })
                                                        }
                                                        let s = rD(e),
                                                            u = {
                                                                startResource: function(e, t = {}, n = G()) {
                                                                    let r = t.resourceKey ? ? e;
                                                                    s.start(r, n, {
                                                                        url: e,
                                                                        ...t
                                                                    })
                                                                },
                                                                stopResource: function(t, n = {}, r = G()) {
                                                                    var i;
                                                                    let o = n.resourceKey ? ? t,
                                                                        a = s.stop(o, r, {
                                                                            context: n.context,
                                                                            type: n.type
                                                                        });
                                                                    if (!a) return;
                                                                    let u = (i = a.startClocks.relative, r.relative - i),
                                                                        c = {
                                                                            date: a.startClocks.timeStamp,
                                                                            type: w.RESOURCE,
                                                                            resource: {
                                                                                id: a.id,
                                                                                type: a.type || nh.OTHER,
                                                                                url: nA(a.url),
                                                                                duration: F(u),
                                                                                method: a.method,
                                                                                status_code: n.statusCode,
                                                                                size: n.size
                                                                            },
                                                                            _dd: {},
                                                                            context: a.context
                                                                        };
                                                                    e.notify(13, {
                                                                        rawRumEvent: c,
                                                                        startClocks: a.startClocks,
                                                                        duration: u,
                                                                        domainContext: {
                                                                            isManual: !0
                                                                        }
                                                                    })
                                                                }
                                                            };
                                                        return {
                                                            startResource: u.startResource,
                                                            stopResource: u.stopResource,
                                                            stop: () => {
                                                                o(), n.stop(), i.unsubscribe(), s.stopAll()
                                                            }
                                                        }
                                                    }(e, n);
                                                    m.push(ef.stop);
                                                    let {
                                                        stop: em
                                                    } = function(e, t) {
                                                        let n = nR({
                                                            type: nT("long-animation-frame") ? "long-animation-frame" : "longtask",
                                                            buffered: !0
                                                        }).subscribe(n => {
                                                            for (let r of n) {
                                                                if (!t.trackLongTasks) break;
                                                                let n = K(r.startTime),
                                                                    i = function(e, t) {
                                                                        let n = et(),
                                                                            r = F(e.duration),
                                                                            i = {
                                                                                date: t.timeStamp,
                                                                                type: w.LONG_TASK,
                                                                                _dd: {
                                                                                    discarded: !1
                                                                                }
                                                                            };
                                                                        if ("longtask" === e.entryType) return { ...i,
                                                                            long_task: {
                                                                                id: n,
                                                                                entry_type: C.LONG_TASK,
                                                                                duration: r
                                                                            }
                                                                        };
                                                                        let o = rm(e.scripts.map(e => e.sourceURL).filter(e => !!e));
                                                                        return { ...i,
                                                                            _dd: {
                                                                                discarded: !1,
                                                                                debug_ids: o
                                                                            },
                                                                            long_task: {
                                                                                id: n,
                                                                                entry_type: C.LONG_ANIMATION_FRAME,
                                                                                duration: r,
                                                                                blocking_duration: F(e.blockingDuration),
                                                                                first_ui_event_timestamp: F(e.firstUIEventTimestamp),
                                                                                render_start: F(e.renderStart),
                                                                                style_and_layout_start: F(e.styleAndLayoutStart),
                                                                                start_time: F(e.startTime),
                                                                                scripts: e.scripts.map(e => ({
                                                                                    duration: F(e.duration),
                                                                                    pause_duration: F(e.pauseDuration),
                                                                                    forced_style_and_layout_duration: F(e.forcedStyleAndLayoutDuration),
                                                                                    start_time: F(e.startTime),
                                                                                    execution_start: F(e.executionStart),
                                                                                    source_url: e.sourceURL,
                                                                                    source_function_name: e.sourceFunctionName,
                                                                                    source_char_position: e.sourceCharPosition,
                                                                                    invoker: e.invoker,
                                                                                    invoker_type: e.invokerType,
                                                                                    window_attribution: e.windowAttribution
                                                                                }))
                                                                            }
                                                                        }
                                                                    }(r, n);
                                                                e.notify(13, {
                                                                    rawRumEvent: i,
                                                                    startClocks: n,
                                                                    duration: r.duration,
                                                                    domainContext: {
                                                                        performanceEntry: r
                                                                    }
                                                                })
                                                            }
                                                        });
                                                        return {
                                                            stop: () => n.unsubscribe()
                                                        }
                                                    }(e, n);
                                                    m.push(em);
                                                    let {
                                                        addError: ey
                                                    } = function(e, t) {
                                                        var n, r;
                                                        let i = new eC;
                                                        return t.subscribe(({
                                                            data: e,
                                                            type: t
                                                        }) => {
                                                            t === rC.RUNTIME_ERROR ? i.notify(e) : t === rC.CONSOLE && e.api === ec.error && i.notify(e.error)
                                                        }), n = i, (function(e) {
                                                            var t;
                                                            let n = [];
                                                            e.includes(r1.cspViolation) && n.push(new eC(e => {
                                                                if (!tm(document, "securitypolicyviolation")) return;
                                                                let {
                                                                    stop: t
                                                                } = tf(document, "securitypolicyviolation", t => {
                                                                    e.notify(function(e) {
                                                                        let t = `'${e.blockedURI}' blocked by '${e.effectiveDirective}' directive`;
                                                                        return r3({
                                                                            type: e.effectiveDirective,
                                                                            message: `${r1.cspViolation}: ${t}`,
                                                                            originalError: e,
                                                                            csp: {
                                                                                disposition: e.disposition
                                                                            },
                                                                            stack: r2(e.effectiveDirective, e.originalPolicy ? `${t} of the policy "${ei(e.originalPolicy,100,"...")}"` : "no policy", e.sourceFile, e.lineNumber, e.columnNumber),
                                                                            debugIds: e.sourceFile ? rm([e.sourceFile]) : void 0
                                                                        })
                                                                    }(t))
                                                                });
                                                                return t
                                                            }));
                                                            let r = e.filter(e => e !== r1.cspViolation);
                                                            return r.length && n.push((t = r, new eC(e => {
                                                                if (!window.ReportingObserver) return;
                                                                let n = eS((t, n) => t.forEach(t => e.notify(function(e) {
                                                                        let {
                                                                            type: t,
                                                                            body: n
                                                                        } = e;
                                                                        return r3({
                                                                            type: n.id,
                                                                            message: `${t}: ${n.message}`,
                                                                            originalError: e,
                                                                            stack: r2(n.id, n.message, n.sourceFile, n.lineNumber, n.columnNumber),
                                                                            debugIds: n.sourceFile ? rm([n.sourceFile]) : void 0
                                                                        })
                                                                    }(t)))),
                                                                    r = new window.ReportingObserver(n, {
                                                                        types: t,
                                                                        buffered: !0
                                                                    });
                                                                return r.observe(), () => {
                                                                    r.disconnect()
                                                                }
                                                            }))), eA(...n)
                                                        })([r1.cspViolation, r1.intervention]).subscribe(e => n.notify(e)), i.subscribe(t => e.notify(15, {
                                                            error: t
                                                        })), (r = e).subscribe(15, ({
                                                            error: e
                                                        }) => {
                                                            r.notify(13, function(e) {
                                                                let t = {
                                                                        date: e.startClocks.timeStamp,
                                                                        error: {
                                                                            id: et(),
                                                                            message: e.message,
                                                                            source: e.source,
                                                                            stack: e.stack,
                                                                            handling_stack: e.handlingStack,
                                                                            component_stack: e.componentStack,
                                                                            type: e.type,
                                                                            handling: e.handling,
                                                                            causes: e.causes,
                                                                            source_type: "browser",
                                                                            fingerprint: e.fingerprint,
                                                                            csp: e.csp
                                                                        },
                                                                        _dd: {
                                                                            debug_ids: e.debugIds
                                                                        },
                                                                        type: w.ERROR,
                                                                        context: e.context
                                                                    },
                                                                    n = {
                                                                        error: e.originalError,
                                                                        handlingStack: e.handlingStack
                                                                    };
                                                                return {
                                                                    rawRumEvent: t,
                                                                    startClocks: e.startClocks,
                                                                    domainContext: n
                                                                }
                                                            }(e))
                                                        }), {
                                                            addError: ({
                                                                error: e,
                                                                handlingStack: t,
                                                                componentStack: n,
                                                                startClocks: i,
                                                                context: o
                                                            }) => {
                                                                let a = rv({
                                                                    originalError: e,
                                                                    handlingStack: t,
                                                                    componentStack: n,
                                                                    startClocks: i,
                                                                    nonErrorPrefix: ro.PROVIDED,
                                                                    source: ri.CUSTOM,
                                                                    handling: ra.HANDLED
                                                                });
                                                                a.context = tN(a.context, o), r.notify(15, {
                                                                    error: a
                                                                })
                                                            }
                                                        }
                                                    }(e, a);
                                                    ! function(e, t, n, r, i, o) {
                                                        let a = {
                                                            clearTracingIfNeeded: n8,
                                                            traceFetch: e => n7(t, e, n, r, i, t => {
                                                                if (e.input instanceof Request && !e.init ? .headers) e.input = new Request(e.input), Object.keys(t).forEach(n => {
                                                                    e.input.headers.append(n, t[n])
                                                                });
                                                                else {
                                                                    e.init = { ...e.init
                                                                    };
                                                                    let n = [];
                                                                    e.init.headers instanceof Headers ? e.init.headers.forEach((e, t) => {
                                                                        n.push([t, e])
                                                                    }) : Array.isArray(e.init.headers) ? e.init.headers.forEach(e => {
                                                                        n.push(e)
                                                                    }) : e.init.headers && Object.keys(e.init.headers).forEach(t => {
                                                                        n.push([t, e.init.headers[t]])
                                                                    }), e.init.headers = n.concat(tl(t))
                                                                }
                                                            }),
                                                            traceXhr: (e, o) => n7(t, e, n, r, i, e => {
                                                                try {
                                                                    Object.keys(e).forEach(t => {
                                                                        o.setRequestHeader(t, e[t])
                                                                    })
                                                                } catch {}
                                                            })
                                                        };
                                                        (function(e, t, n) {
                                                            let r = [];
                                                            r.push(rt().subscribe(e => {
                                                                "start" === e.state && nw(e.url) && (t.traceXhr(e, e.xhr), rR(e))
                                                            })), r.push(n.subscribe(({
                                                                data: n,
                                                                type: r
                                                            }) => {
                                                                if (r === rC.XHR && nw(n.url)) switch (n.state) {
                                                                    case "start":
                                                                        rR(n), e.notify(7, {
                                                                            requestIndex: n.requestIndex,
                                                                            url: n.url
                                                                        });
                                                                        break;
                                                                    case "complete":
                                                                        t.clearTracingIfNeeded(n), e.notify(8, { ...n,
                                                                            type: nb.XHR,
                                                                            isAbortedOnStart: !1
                                                                        })
                                                                }
                                                            }))
                                                        })(e, a, o),
                                                        function(e, t, n, r) {
                                                            let i = [];
                                                            i.push(r_({
                                                                responseBodyAction: e => n9(e.url, t) ? .trackResponseErrors ? rb.COLLECT : rb.IGNORE
                                                            }).subscribe(e => {
                                                                "start" === e.state && nw(e.url) && (n.traceFetch(e), rR(e))
                                                            })), i.push(r.subscribe(({
                                                                data: t,
                                                                type: r
                                                            }) => {
                                                                if (r === rC.FETCH && nw(t.url)) switch (t.state) {
                                                                    case "start":
                                                                        rR(t), e.notify(7, {
                                                                            requestIndex: t.requestIndex,
                                                                            url: t.url
                                                                        });
                                                                        break;
                                                                    case "resolve":
                                                                        var i;
                                                                        n.clearTracingIfNeeded(t), e.notify(8, { ...t,
                                                                            duration: (i = t.startClocks.timeStamp, q() - i),
                                                                            type: nb.FETCH,
                                                                            requestBody: t.init ? .body
                                                                        })
                                                                }
                                                            }))
                                                        }(e, t, a, o)
                                                    }(e, n, r, P, U, a);
                                                    let ev = function(e, t) {
                                                        let n = rD(e);

                                                        function r(n) {
                                                            t.wasInPageStateDuringPeriod("frozen", n.startClocks.relative, n.duration) || e.notify(13, iM(n))
                                                        }
                                                        return {
                                                            addOperationStepVital: function(t, n, r, i) {
                                                                let {
                                                                    operationKey: o,
                                                                    context: a,
                                                                    description: s,
                                                                    handlingStack: u
                                                                } = r || {}, c = {
                                                                    name: t,
                                                                    type: k.OPERATION_STEP,
                                                                    operationKey: o,
                                                                    failureReason: i,
                                                                    stepType: n,
                                                                    startClocks: G(),
                                                                    context: rs(a),
                                                                    description: s,
                                                                    handlingStack: u
                                                                };
                                                                e.notify(13, iM(c))
                                                            },
                                                            addDurationVital: r,
                                                            startDurationVital: function(t, r = {}, i = G()) {
                                                                let {
                                                                    id: o
                                                                } = n.start(r.vitalKey ? ? t, i, {
                                                                    name: t,
                                                                    ...r
                                                                });
                                                                e.notify(17, {
                                                                    id: o,
                                                                    name: t,
                                                                    startClocks: i,
                                                                    ...r
                                                                })
                                                            },
                                                            stopDurationVital: function(e, t = {}, i = G()) {
                                                                let o = n.stop(t.vitalKey ? ? e, i, t);
                                                                o && r({
                                                                    type: k.DURATION,
                                                                    ...o
                                                                })
                                                            }
                                                        }
                                                    }(e, I);
                                                    if (n.trackResources && (n.betaTrackWebSockets || (c = eT.TRACK_WEBSOCKETS, ek.has(c)))) {
                                                        let t = function(e, t, n) {
                                                            let r = function(e, t, n, r) {
                                                                    let i = new Map;

                                                                    function o(t, i, o) {
                                                                        let a = function(e, t, n, r) {
                                                                            var i, o;
                                                                            let a = t.at,
                                                                                s = "session_end" === n ? r.findView(a.relative, {
                                                                                    returnInactive: !0
                                                                                }) ? .id : r.findView(a.relative) ? .id,
                                                                                u = void 0 !== e.lastMessageInAt ? (i = e.lastMessageInAt, a.timeStamp - i) : void 0,
                                                                                {
                                                                                    openClocks: c,
                                                                                    ...l
                                                                                } = e;
                                                                            return { ...l,
                                                                                endClocks: a,
                                                                                endViewId: s,
                                                                                inboundIdleDurationBeforeClose: u,
                                                                                trackingEndReason: n,
                                                                                handshakeSucceeded: void 0 !== c,
                                                                                setupDuration: e.setupDuration ? ? (o = e.startClocks.timeStamp, a.timeStamp - o),
                                                                                closeCode: t.code,
                                                                                closeReason: t.reason,
                                                                                wasClean: t.wasClean
                                                                            }
                                                                        }(t, i, o, n);
                                                                        e.notify(9, a), r({
                                                                            id: et(),
                                                                            name: "websocket-closed",
                                                                            type: k.DURATION,
                                                                            startClocks: a.endClocks,
                                                                            duration: 0,
                                                                            context: rs({
                                                                                url: a.url,
                                                                                connection_id: a.connectionId
                                                                            })
                                                                        })
                                                                    }
                                                                    let a = t.subscribe(e => {
                                                                        switch (e.state) {
                                                                            case "connecting":
                                                                                {
                                                                                    let t = et(),
                                                                                        o = n.findView(e.startClocks.relative) ? .id,
                                                                                        a = function(e) {
                                                                                            let t = tR(e);
                                                                                            return t.search = "", t.href
                                                                                        }(e.url),
                                                                                        s = {
                                                                                            webSocket: e.instance,
                                                                                            connectionId: t,
                                                                                            url: a,
                                                                                            startClocks: e.startClocks,
                                                                                            startViewId: o,
                                                                                            messagesIn: {
                                                                                                count: 0,
                                                                                                size: 0
                                                                                            },
                                                                                            messagesOut: {
                                                                                                count: 0,
                                                                                                size: 0
                                                                                            },
                                                                                            longestInboundSilence: 0,
                                                                                            bufferedAmountMax: 0
                                                                                        };i.set(e.instance, s),
                                                                                    r({
                                                                                        id: et(),
                                                                                        name: "websocket-connecting",
                                                                                        type: k.DURATION,
                                                                                        startClocks: e.startClocks,
                                                                                        duration: 0,
                                                                                        context: rs({
                                                                                            url: a,
                                                                                            connection_id: t
                                                                                        })
                                                                                    });
                                                                                    return
                                                                                }
                                                                            case "open":
                                                                                {
                                                                                    var t;
                                                                                    let n = i.get(e.instance);
                                                                                    if (!n) return;n.openClocks = e.openClocks,
                                                                                    n.protocol = e.protocol,
                                                                                    t = n.startClocks.timeStamp,
                                                                                    n.setupDuration = e.openClocks.timeStamp - t;
                                                                                    return
                                                                                }
                                                                            case "message-in":
                                                                                {
                                                                                    let t = i.get(e.instance);
                                                                                    if (!t) return;t.messagesIn.count += 1,
                                                                                    t.messagesIn.size += e.size,
                                                                                    rk(t, e.at, "in");
                                                                                    return
                                                                                }
                                                                            case "message-out":
                                                                                {
                                                                                    let t = i.get(e.instance);
                                                                                    if (!t) return;e.bufferedAmountPreSend > t.bufferedAmountMax && (t.bufferedAmountMax = e.bufferedAmountPreSend),
                                                                                    t.messagesOut.count += 1,
                                                                                    t.messagesOut.size += e.size,
                                                                                    rk(t, e.at, "out");
                                                                                    return
                                                                                }
                                                                            case "closed":
                                                                                {
                                                                                    let t = i.get(e.instance);
                                                                                    if (!t) return;i.delete(e.instance),
                                                                                    o(t, e, "close_event");
                                                                                    return
                                                                                }
                                                                        }
                                                                    });
                                                                    return {
                                                                        flushOpenConnections: (e, t = G()) => {
                                                                            i.forEach(n => {
                                                                                o(n, {
                                                                                    at: t
                                                                                }, e)
                                                                            }), i.clear()
                                                                        },
                                                                        stop: () => {
                                                                            a.unsubscribe(), i.clear()
                                                                        }
                                                                    }
                                                                }(e, (y || (y = new eC(e => {
                                                                    if ("function" != typeof eg.WebSocket) return;
                                                                    let {
                                                                        stop: t
                                                                    } = function(e, t, n, {
                                                                        computeHandlingStack: r
                                                                    } = {}) {
                                                                        let i = e[t];
                                                                        if ("function" != typeof i) return {
                                                                            stop: eD
                                                                        };
                                                                        let o = !1,
                                                                            a = function() {
                                                                                if (!new.target) return Reflect.apply(i, this, Array.from(arguments));
                                                                                let e = new.target === a ? i : new.target;
                                                                                if (o) return Reflect.construct(i, arguments, e);
                                                                                let t = Array.from(arguments);
                                                                                return n2(n, {
                                                                                    parameters: t,
                                                                                    handlingStack: r ? ez("instrumented constructor") : void 0
                                                                                }, () => Reflect.construct(i, t, e))
                                                                            },
                                                                            s = function(e, t) {
                                                                                for (let n of [].concat(Object.getOwnPropertyNames(t), Object.getOwnPropertySymbols(t))) {
                                                                                    let r = Object.getOwnPropertyDescriptor(t, n);
                                                                                    Object.defineProperty(e, n, r)
                                                                                }
                                                                                let {
                                                                                    stop: n
                                                                                } = n3(t.prototype, "constructor", t.prototype.constructor, e);
                                                                                return n
                                                                            }(a, i),
                                                                            {
                                                                                stop: u
                                                                            } = n3(e, t, i, a);
                                                                        return {
                                                                            stop: () => {
                                                                                o = !0, s(), u()
                                                                            }
                                                                        }
                                                                    }(eg, "WebSocket", ({
                                                                        parameters: t,
                                                                        onPostCall: n
                                                                    }) => {
                                                                        let r = Array.isArray(t[1]) ? [].concat(t[1]) : t[1],
                                                                            i = G();
                                                                        n(t => {
                                                                            e.notify({
                                                                                    state: "connecting",
                                                                                    instance: t,
                                                                                    url: t.url,
                                                                                    protocols: r,
                                                                                    startClocks: i
                                                                                }),
                                                                                function(e, t) {
                                                                                    let {
                                                                                        stop: n
                                                                                    } = tf(e, "open", () => {
                                                                                        t.notify({
                                                                                            state: "open",
                                                                                            instance: e,
                                                                                            openClocks: G(),
                                                                                            protocol: e.protocol || ""
                                                                                        }), n()
                                                                                    }), {
                                                                                        stop: r
                                                                                    } = tf(e, "message", n => {
                                                                                        t.notify({
                                                                                            state: "message-in",
                                                                                            instance: e,
                                                                                            size: rT(n.data),
                                                                                            at: G()
                                                                                        })
                                                                                    }), {
                                                                                        stop: i
                                                                                    } = tf(e, "close", n => {
                                                                                        t.notify({
                                                                                            state: "closed",
                                                                                            instance: e,
                                                                                            code: n.code,
                                                                                            reason: n.reason,
                                                                                            wasClean: n.wasClean,
                                                                                            at: G()
                                                                                        }), r(), i()
                                                                                    })
                                                                                }(t, e)
                                                                        })
                                                                    }), {
                                                                        stop: n
                                                                    } = n1(eg.WebSocket.prototype, "send", ({
                                                                        target: t,
                                                                        parameters: [n],
                                                                        onPostCall: r
                                                                    }) => {
                                                                        let i = rT(n),
                                                                            o = t.bufferedAmount;
                                                                        r(() => {
                                                                            e.notify({
                                                                                state: "message-out",
                                                                                instance: t,
                                                                                size: i,
                                                                                bufferedAmountPreSend: o,
                                                                                at: G()
                                                                            })
                                                                        })
                                                                    });
                                                                    return () => {
                                                                        t(), n()
                                                                    }
                                                                })), y), t, n),
                                                                i = e.subscribe(10, ({
                                                                    endClocks: e
                                                                }) => {
                                                                    r.flushOpenConnections("session_end", e)
                                                                });
                                                            return {
                                                                stop: () => {
                                                                    i.unsubscribe(), r.flushOpenConnections("session_end"), r.stop()
                                                                }
                                                            }
                                                        }(e, x, ev.addDurationVital);
                                                        m.push(t.stop)
                                                    }
                                                    let eh = (l = n.applicationId, d = $.actionContexts, {
                                                        get: e => {
                                                            let t = x.findView(e),
                                                                n = N.findUrl(e),
                                                                i = r.findTrackedSession(e);
                                                            if (i && t && n) {
                                                                let r = d.findActionId(e);
                                                                return {
                                                                    application_id: l,
                                                                    session_id: i.id,
                                                                    user_action: r ? {
                                                                        id: r
                                                                    } : void 0,
                                                                    view: {
                                                                        id: t.id,
                                                                        name: t.name,
                                                                        referrer: n.referrer,
                                                                        url: n.url
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    });
                                                    return {
                                                        addAction: $.addAction,
                                                        startAction: $.startAction,
                                                        stopAction: $.stopAction,
                                                        startResource: ef.startResource,
                                                        stopResource: ef.stopResource,
                                                        addEvent: Y.addEvent,
                                                        addError: ey,
                                                        addTiming: en,
                                                        setLoadingTime: er,
                                                        addFeatureFlagEvaluation: M.addFeatureFlagEvaluation,
                                                        startView: eo,
                                                        setViewContext: es,
                                                        setViewContextProperty: eu,
                                                        getViewContext: el,
                                                        setViewName: ea,
                                                        viewHistory: x,
                                                        sessionManager: r,
                                                        stopSession: () => r.expire(),
                                                        getInternalContext: eh.get,
                                                        startDurationVital: ev.startDurationVital,
                                                        stopDurationVital: ev.stopDurationVital,
                                                        addDurationVital: ev.addDurationVital,
                                                        addOperationStepVital: ev.addOperationStepVital,
                                                        globalContext: D,
                                                        userContext: P,
                                                        accountContext: U,
                                                        stop: () => m.forEach(e => e())
                                                    }
                                                }(d, u, e, t, n, i, a, c, f);
                                                return l.push(m), a.unbuffer(), l.push(() => r.stop()), { ...g,
                                                    lifeCycle: d,
                                                    sessionManager: t,
                                                    stopSession: () => t.expire(),
                                                    telemetry: s,
                                                    stop: () => {
                                                        l.forEach(e => e())
                                                    },
                                                    hooks: u
                                                }
                                            }(r, i, e, t, u, d, o.observable, c, l, n.sdkName);
                                        e.onRumStart(f.lifeCycle, r, i, f.viewHistory, a, f.telemetry), t.onRumStart(f.lifeCycle, f.hooks, r, i, f.viewHistory, d), p = s, m = f, s = { ...p,
                                            init: e => {
                                                i7("DD_RUM", e)
                                            },
                                            getInternalContext: m.getInternalContext,
                                            stopSession: m.stopSession,
                                            getViewContext: m.getViewContext,
                                            globalContext: m.globalContext,
                                            userContext: m.userContext,
                                            accountContext: m.accountContext
                                        };
                                        var p, m, g = r.plugins,
                                            E = {
                                                addEvent: f.addEvent,
                                                addError: f.addError
                                            };
                                        for (let e of g ? ? []) e.onRumStart ? .(E);
                                        return f
                                    }),
                                    u = () => s,
                                    c = (e, t) => {
                                        let n = ez("vital");
                                        e_(() => {
                                            tB({
                                                feature: "add-operation-step-vital",
                                                action_type: "start"
                                            }), s.addOperationStepVital(e, "start", { ...t,
                                                handlingStack: n
                                            })
                                        })
                                    },
                                    l = eS((e, t) => {
                                        tB({
                                            feature: "add-operation-step-vital",
                                            action_type: "succeed"
                                        }), s.addOperationStepVital(e, "end", t)
                                    }),
                                    d = eS((e, t, n) => {
                                        tB({
                                            feature: "add-operation-step-vital",
                                            action_type: "fail"
                                        }), s.addOperationStepVital(e, "end", n, t)
                                    }),
                                    f = function(e) {
                                        let t = {
                                            version: "7.13.0",
                                            onReady(e) {
                                                e()
                                            },
                                            ...e
                                        };
                                        return Object.defineProperty(t, "_setDebug", {
                                            get: () => eh,
                                            enumerable: !1
                                        }), t
                                    }({
                                        init: e => {
                                            let t = Error().stack;
                                            e_(() => s.init(e, f, t))
                                        },
                                        setTrackingConsent: eS(e => {
                                            r.update(e), tB({
                                                feature: "set-tracking-consent",
                                                tracking_consent: e
                                            })
                                        }),
                                        setViewName: eS(e => {
                                            s.setViewName(o_(e, "view name")), tB({
                                                feature: "set-view-name"
                                            })
                                        }),
                                        setViewContext: eS(e => {
                                            s.setViewContext(e), tB({
                                                feature: "set-view-context"
                                            })
                                        }),
                                        setViewContextProperty: eS((e, t) => {
                                            s.setViewContextProperty(e, t), tB({
                                                feature: "set-view-context-property"
                                            })
                                        }),
                                        getViewContext: eS(() => (tB({
                                            feature: "set-view-context-property"
                                        }), s.getViewContext())),
                                        getInternalContext: eS(e => s.getInternalContext(e)),
                                        getInitConfiguration: eS(() => tx(s.initConfiguration)),
                                        addAction: (e, t) => {
                                            let n = ez("action");
                                            e_(() => {
                                                s.addAction({
                                                    name: rs(e),
                                                    context: rs(t),
                                                    startClocks: G(),
                                                    type: R.CUSTOM,
                                                    handlingStack: n
                                                }), tB({
                                                    feature: "add-action"
                                                })
                                            })
                                        },
                                        startAction: eS((e, t) => {
                                            tB({
                                                feature: "start-action"
                                            }), s.startAction(rs(e), {
                                                type: rs(t ? .type),
                                                context: rs(t ? .context),
                                                actionKey: t ? .actionKey
                                            })
                                        }),
                                        stopAction: eS((e, t) => {
                                            tB({
                                                feature: "stop-action"
                                            }), s.stopAction(rs(e), {
                                                type: rs(t ? .type),
                                                context: rs(t ? .context),
                                                actionKey: t ? .actionKey
                                            })
                                        }),
                                        startResource: eS((e, t) => {
                                            tB({
                                                feature: "start-resource"
                                            }), s.startResource(rs(e), {
                                                type: rs(t ? .type),
                                                method: rs(t ? .method),
                                                context: rs(t ? .context),
                                                resourceKey: t ? .resourceKey
                                            })
                                        }),
                                        stopResource: eS((e, t) => {
                                            tB({
                                                feature: "stop-resource"
                                            }), s.stopResource(rs(e), {
                                                type: rs(t ? .type),
                                                statusCode: t ? .statusCode,
                                                size: t ? .size,
                                                context: rs(t ? .context),
                                                resourceKey: t ? .resourceKey
                                            })
                                        }),
                                        addError: (e, t) => {
                                            let n = ez("error");
                                            e_(() => {
                                                s.addError({
                                                    error: e,
                                                    handlingStack: n,
                                                    context: rs(t),
                                                    startClocks: G()
                                                }), tB({
                                                    feature: "add-error"
                                                })
                                            })
                                        },
                                        addTiming: eS((e, t) => {
                                            s.addTiming(rs(e), t)
                                        }),
                                        setViewLoadingTime: eS(() => {
                                            let e = q();
                                            s.setLoadingTime(e), tB({
                                                feature: "addViewLoadingTime"
                                            })
                                        }),
                                        setGlobalContext: i4(u, i6.globalContext, i8.setContext, "set-global-context"),
                                        getGlobalContext: i4(u, i6.globalContext, i8.getContext, "get-global-context"),
                                        setGlobalContextProperty: i4(u, i6.globalContext, i8.setContextProperty, "set-global-context-property"),
                                        removeGlobalContextProperty: i4(u, i6.globalContext, i8.removeContextProperty, "remove-global-context-property"),
                                        clearGlobalContext: i4(u, i6.globalContext, i8.clearContext, "clear-global-context"),
                                        setUser: i4(u, i6.userContext, i8.setContext, "set-user"),
                                        getUser: i4(u, i6.userContext, i8.getContext, "get-user"),
                                        setUserProperty: i4(u, i6.userContext, i8.setContextProperty, "set-user-property"),
                                        removeUserProperty: i4(u, i6.userContext, i8.removeContextProperty, "remove-user-property"),
                                        clearUser: i4(u, i6.userContext, i8.clearContext, "clear-user"),
                                        setAccount: i4(u, i6.accountContext, i8.setContext, "set-account"),
                                        getAccount: i4(u, i6.accountContext, i8.getContext, "get-account"),
                                        setAccountProperty: i4(u, i6.accountContext, i8.setContextProperty, "set-account-property"),
                                        removeAccountProperty: i4(u, i6.accountContext, i8.removeContextProperty, "remove-account-property"),
                                        clearAccount: i4(u, i6.accountContext, i8.clearContext, "clear-account"),
                                        startView: e => {
                                            let t = ez("view");
                                            e_(() => {
                                                let n = "object" == typeof e ? e : {
                                                    name: e
                                                };
                                                s.startView({ ...n,
                                                    name: o_(n.name, "view name"),
                                                    service: o_(n.service, "view service"),
                                                    version: o_(n.version, "view version"),
                                                    handlingStack: t
                                                }), tB({
                                                    feature: "start-view"
                                                })
                                            })
                                        },
                                        stopSession: eS(() => {
                                            s.stopSession(), tB({
                                                feature: "stop-session"
                                            })
                                        }),
                                        addFeatureFlagEvaluation: eS((e, t) => {
                                            s.addFeatureFlagEvaluation(rs(e), rs(t)), tB({
                                                feature: "add-feature-flag-evaluation"
                                            })
                                        }),
                                        getSessionReplayLink: eS(() => e.getSessionReplayLink()),
                                        startSessionReplayRecording: eS(t => {
                                            e.start(t), tB({
                                                feature: "start-session-replay-recording",
                                                force: t ? .force
                                            })
                                        }),
                                        stopSessionReplayRecording: eS(() => e.stop()),
                                        addDurationVital: (e, t) => {
                                            let n = ez("vital");
                                            e_(() => {
                                                tB({
                                                    feature: "add-duration-vital"
                                                }), s.addDurationVital({
                                                    id: et(),
                                                    name: rs(e),
                                                    type: k.DURATION,
                                                    startClocks: B(t.startTime),
                                                    duration: t.duration,
                                                    context: rs(t ? .context),
                                                    description: rs(t ? .description),
                                                    handlingStack: n
                                                })
                                            })
                                        },
                                        startDurationVital: (e, t) => {
                                            let n = ez("vital");
                                            e_(() => {
                                                tB({
                                                    feature: "start-duration-vital"
                                                }), s.startDurationVital(rs(e), {
                                                    vitalKey: t ? .vitalKey,
                                                    context: rs(t ? .context),
                                                    description: rs(t ? .description),
                                                    handlingStack: n
                                                })
                                            })
                                        },
                                        stopDurationVital: eS((e, t) => {
                                            tB({
                                                feature: "stop-duration-vital"
                                            }), s.stopDurationVital(rs(e), {
                                                vitalKey: t ? .vitalKey,
                                                context: rs(t ? .context),
                                                description: rs(t ? .description)
                                            })
                                        }),
                                        startOperation: c,
                                        succeedOperation: l,
                                        failOperation: d,
                                        startFeatureOperation: c,
                                        succeedFeatureOperation: l,
                                        failFeatureOperation: d,
                                        DEFAULT_TRACKED_RESOURCE_HEADERS: ns
                                    });
                                return f
                            }(function() {
                                    let e = eD;
                                    return {
                                        start: eD,
                                        stop: eD,
                                        onRumStart(t, n) {
                                            e = () => (function(e, {
                                                        session: t,
                                                        viewContext: n,
                                                        errorType: r
                                                    }) {
                                                        let i = t ? t.id : "no-session-id",
                                                            o = [];
                                                        return void 0 !== r && o.push(`error-type=${r}`), n && (o.push(`seed=${n.id}`), o.push(`from=${n.startClocks.timeStamp}`)), `${function(e){let t=e.site,n=e.subdomain||function(e){switch(e.site){case tw:case"datadoghq.eu":return"app";case tE:return"dd";default:return}}(e);return`
                                                        https: //${n?`${n}.`:""}${t}`}(e)}/rum/replay/sessions/${i}?${o.join("&")}`})(n,{errorType:"slim-package"})},isRecording:()=>!1,getReplayStats:()=>void 0,getSessionReplayLink:()=>e()}}(),{onRumStart:eD,stop:eD},{sdkName:"rum-slim"});!function(e,t,n){let r=e[t];r&&!r.q&&r.version&&ep.warn("SDK is loaded more than once. This is unsupported and might have unexpected behavior."),e[t]=n,r?.q&&r.q.forEach(e=>t7(e,"onReady callback threw an error:")())}(eg,"DD_RUM",oE)}}]);