"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7023], {
        23362: (e, t, n) => {
            n.d(t, {
                default: () => i.a
            });
            var r = n(75713),
                i = n.n(r)
        },
        38576: (e, t, n) => {
            n.d(t, {
                UR: () => ei,
                qM: () => eo
            });
            var r = Object.create,
                i = Object.defineProperty,
                o = Object.getOwnPropertyDescriptor,
                a = Object.getOwnPropertyNames,
                s = Object.getPrototypeOf,
                l = Object.prototype.hasOwnProperty,
                c = (e, t, n) => (n = null == e ? {} : r(s(e)), ((e, t, n, r) => {
                    if (t && "object" == typeof t || "function" == typeof t)
                        for (var s, c = a(t), u = 0, d = c.length; u < d; u++) s = c[u], l.call(e, s) || s === n || i(e, s, {
                            get: (e => t[e]).bind(null, s),
                            enumerable: !(r = o(t, s)) || r.enumerable
                        });
                    return e
                })(!t && e && e.__esModule && l.call(e, "default") ? n : i(n, "default", {
                    value: e,
                    enumerable: !0
                }), e)),
                u = (e, t) => () => (t || (e((t = {
                    exports: {}
                }).exports, t), e = null), t.exports),
                d = {
                    0: 8203,
                    1: 8204,
                    2: 8205,
                    3: 8290,
                    4: 8291,
                    5: 8288,
                    6: 65279,
                    7: 8289,
                    8: 119155,
                    9: 119156,
                    a: 119157,
                    b: 119158,
                    c: 119159,
                    d: 119160,
                    e: 119161,
                    f: 119162
                },
                f = {
                    0: 8203,
                    1: 8204,
                    2: 8205,
                    3: 65279
                },
                p = {
                    0: String.fromCodePoint(f[0]),
                    1: String.fromCodePoint(f[1]),
                    2: String.fromCodePoint(f[2]),
                    3: String.fromCodePoint(f[3])
                },
                h = [, , , , ].fill(String.fromCodePoint(f[0])).join(""),
                g = Object.fromEntries(Object.entries(p).map(e => [e[1], +e[0]])),
                v = Object.fromEntries(Object.entries(d).map(e => e.reverse())),
                m = `${Object.values(d).map(e=>`\\u{${e.toString(16)}}`).join("")}`,
                b = RegExp(`[${m}]{4,}`, "gu"),
                E = u((e, t) => {
                    var n = Object.prototype.hasOwnProperty,
                        r = Object.prototype.toString;
                    t.exports = function(e, t, i) {
                        if ("[object Function]" !== r.call(t)) throw TypeError("iterator must be a function");
                        var o = e.length;
                        if (o === +o)
                            for (var a = 0; a < o; a++) t.call(i, e[a], a, e);
                        else
                            for (var s in e) n.call(e, s) && t.call(i, e[s], s, e)
                    }
                }),
                y = ["nt_experiences", "nt_name", "nt_description", "nt_audience_id", "nt_rules", "nt_metadata", "nt_experience_id", "nt_type", "nt_config", "nt_audience", "nt_variants"],
                _ = y.map(e => e.replace(/_([a-z])/g, (e, t) => t.toUpperCase()));
            [...y, ..._];
            var O = {
                    version: "4.10.25"
                },
                T = !1,
                C = e => (...t) => {
                    T && console[e](...t)
                },
                w = {
                    error: C("error"),
                    warn: C("warn"),
                    log: C("log")
                },
                I = new Set(["AREA", "BASE", "BR", "COL", "EMBED", "HR", "IMG", "INPUT", "LINK", "META", "PARAM", "SOURCE", "TRACK", "WBR"]);

            function S(e, t, n) {
                let r = { ...t,
                    method: e,
                    source: "live-preview-sdk",
                    location: window.location.href,
                    version: O.version
                };
                w.log("Send message", r), n.forEach(e => {
                    window.top ? .postMessage(r, e)
                })
            }

            function M(e, t = 100) {
                let n;
                return (...r) => {
                    clearTimeout(n), n = setTimeout(() => {
                        e.apply(this, r)
                    }, t)
                }
            }
            var A = ((e, t) => () => (t || (e((t = {
                    exports: {}
                }).exports, t), e = null), t.exports))((e, t) => {
                    var n, r, i = "__lodash_hash_undefined__",
                        o = "[object Arguments]",
                        a = "[object Array]",
                        s = "[object Boolean]",
                        l = "[object Date]",
                        c = "[object Error]",
                        u = "[object Function]",
                        d = "[object Map]",
                        f = "[object Number]",
                        p = "[object Object]",
                        h = "[object Promise]",
                        g = "[object RegExp]",
                        v = "[object Set]",
                        m = "[object String]",
                        b = "[object WeakMap]",
                        E = "[object ArrayBuffer]",
                        y = "[object DataView]",
                        _ = /^\[object .+?Constructor\]$/,
                        O = /^(?:0|[1-9]\d*)$/,
                        T = {};
                    T["[object Float32Array]"] = T["[object Float64Array]"] = T["[object Int8Array]"] = T["[object Int16Array]"] = T["[object Int32Array]"] = T["[object Uint8Array]"] = T["[object Uint8ClampedArray]"] = T["[object Uint16Array]"] = T["[object Uint32Array]"] = !0, T[o] = T[a] = T[E] = T[s] = T[y] = T[l] = T[c] = T[u] = T[d] = T[f] = T[p] = T[g] = T[v] = T[m] = T[b] = !1;
                    var C = "object" == typeof global && global && global.Object === Object && global,
                        w = "object" == typeof self && self && self.Object === Object && self,
                        I = C || w || Function("return this")(),
                        S = "object" == typeof e && e && !e.nodeType && e,
                        M = S && "object" == typeof t && t && !t.nodeType && t,
                        A = M && M.exports === S,
                        D = A && C.process,
                        L = function() {
                            try {
                                return D && D.binding && D.binding("util")
                            } catch {}
                        }(),
                        j = L && L.isTypedArray;

                    function R(e) {
                        var t = -1,
                            n = Array(e.size);
                        return e.forEach(function(e, r) {
                            n[++t] = [r, e]
                        }), n
                    }

                    function N(e) {
                        var t = -1,
                            n = Array(e.size);
                        return e.forEach(function(e) {
                            n[++t] = e
                        }), n
                    }
                    var P = Array.prototype,
                        U = Function.prototype,
                        x = Object.prototype,
                        z = I["__core-js_shared__"],
                        B = U.toString,
                        k = x.hasOwnProperty,
                        G = function() {
                            var e = /[^.]+$/.exec(z && z.keys && z.keys.IE_PROTO || "");
                            return e ? "Symbol(src)_1." + e : ""
                        }(),
                        F = x.toString,
                        $ = RegExp("^" + B.call(k).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                        V = A ? I.Buffer : void 0,
                        Y = I.Symbol,
                        H = I.Uint8Array,
                        q = x.propertyIsEnumerable,
                        K = P.splice,
                        Z = Y ? Y.toStringTag : void 0,
                        J = Object.getOwnPropertySymbols,
                        W = V ? V.isBuffer : void 0,
                        X = (n = Object.keys, r = Object, function(e) {
                            return n(r(e))
                        }),
                        Q = eT(I, "DataView"),
                        ee = eT(I, "Map"),
                        et = eT(I, "Promise"),
                        en = eT(I, "Set"),
                        er = eT(I, "WeakMap"),
                        ei = eT(Object, "create"),
                        eo = eI(Q),
                        ea = eI(ee),
                        es = eI(et),
                        el = eI(en),
                        ec = eI(er),
                        eu = Y ? Y.prototype : void 0,
                        ed = eu ? eu.valueOf : void 0;

                    function ef(e) {
                        var t = -1,
                            n = null == e ? 0 : e.length;
                        for (this.clear(); ++t < n;) {
                            var r = e[t];
                            this.set(r[0], r[1])
                        }
                    }

                    function ep(e) {
                        var t = -1,
                            n = null == e ? 0 : e.length;
                        for (this.clear(); ++t < n;) {
                            var r = e[t];
                            this.set(r[0], r[1])
                        }
                    }

                    function eh(e) {
                        var t = -1,
                            n = null == e ? 0 : e.length;
                        for (this.clear(); ++t < n;) {
                            var r = e[t];
                            this.set(r[0], r[1])
                        }
                    }

                    function eg(e) {
                        var t = -1,
                            n = null == e ? 0 : e.length;
                        for (this.__data__ = new eh; ++t < n;) this.add(e[t])
                    }

                    function ev(e) {
                        var t = this.__data__ = new ep(e);
                        this.size = t.size
                    }

                    function em(e, t) {
                        for (var n = e.length; n--;)
                            if (eS(e[n][0], t)) return n;
                        return -1
                    }

                    function eb(e) {
                        var t;
                        return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : Z && Z in Object(e) ? function(e) {
                            var t = k.call(e, Z),
                                n = e[Z];
                            try {
                                e[Z] = void 0;
                                var r = !0
                            } catch {}
                            var i = F.call(e);
                            return r && (t ? e[Z] = n : delete e[Z]), i
                        }(e) : (t = e, F.call(t))
                    }

                    function eE(e) {
                        return eN(e) && eb(e) == o
                    }

                    function ey(e, t, n, r, i, o) {
                        var a = 1 & n,
                            s = e.length,
                            l = t.length;
                        if (s != l && !(a && l > s)) return !1;
                        var c = o.get(e);
                        if (c && o.get(t)) return c == t;
                        var u = -1,
                            d = !0,
                            f = 2 & n ? new eg : void 0;
                        for (o.set(e, t), o.set(t, e); ++u < s;) {
                            var p = e[u],
                                h = t[u];
                            if (r) var g = a ? r(h, p, u, t, e, o) : r(p, h, u, e, t, o);
                            if (void 0 !== g) {
                                if (g) continue;
                                d = !1;
                                break
                            }
                            if (f) {
                                if (! function(e, t) {
                                        for (var n = -1, r = null == e ? 0 : e.length; ++n < r;)
                                            if (t(e[n], n, e)) return !0;
                                        return !1
                                    }(t, function(e, t) {
                                        if (!f.has(t) && (p === e || i(p, e, n, r, o))) return f.push(t)
                                    })) {
                                    d = !1;
                                    break
                                }
                            } else if (!(p === h || i(p, h, n, r, o))) {
                                d = !1;
                                break
                            }
                        }
                        return o.delete(e), o.delete(t), d
                    }

                    function e_(e) {
                        var t;
                        return t = eU(e), eA(e) ? t : function(e, t) {
                            for (var n = -1, r = t.length, i = e.length; ++n < r;) e[i + n] = t[n];
                            return e
                        }(t, eC(e))
                    }

                    function eO(e, t) {
                        var n, r, i = e.__data__;
                        return ("string" == (r = typeof(n = t)) || "number" == r || "symbol" == r || "boolean" == r ? "__proto__" !== n : null === n) ? i["string" == typeof t ? "string" : "hash"] : i.map
                    }

                    function eT(e, t) {
                        var n, r = e ? .[t];
                        return !(!eR(r) || (n = r, G && G in n)) && (eL(r) ? $ : _).test(eI(r)) ? r : void 0
                    }
                    ef.prototype.clear = function() {
                        this.__data__ = ei ? ei(null) : {}, this.size = 0
                    }, ef.prototype.delete = function(e) {
                        var t = this.has(e) && delete this.__data__[e];
                        return this.size -= !!t, t
                    }, ef.prototype.get = function(e) {
                        var t = this.__data__;
                        if (ei) {
                            var n = t[e];
                            return n === i ? void 0 : n
                        }
                        return k.call(t, e) ? t[e] : void 0
                    }, ef.prototype.has = function(e) {
                        var t = this.__data__;
                        return ei ? void 0 !== t[e] : k.call(t, e)
                    }, ef.prototype.set = function(e, t) {
                        var n = this.__data__;
                        return this.size += +!this.has(e), n[e] = ei && void 0 === t ? i : t, this
                    }, ep.prototype.clear = function() {
                        this.__data__ = [], this.size = 0
                    }, ep.prototype.delete = function(e) {
                        var t = this.__data__,
                            n = em(t, e);
                        return !(n < 0) && (n == t.length - 1 ? t.pop() : K.call(t, n, 1), --this.size, !0)
                    }, ep.prototype.get = function(e) {
                        var t = this.__data__,
                            n = em(t, e);
                        return n < 0 ? void 0 : t[n][1]
                    }, ep.prototype.has = function(e) {
                        return em(this.__data__, e) > -1
                    }, ep.prototype.set = function(e, t) {
                        var n = this.__data__,
                            r = em(n, e);
                        return r < 0 ? (++this.size, n.push([e, t])) : n[r][1] = t, this
                    }, eh.prototype.clear = function() {
                        this.size = 0, this.__data__ = {
                            hash: new ef,
                            map: new(ee || ep),
                            string: new ef
                        }
                    }, eh.prototype.delete = function(e) {
                        var t = eO(this, e).delete(e);
                        return this.size -= !!t, t
                    }, eh.prototype.get = function(e) {
                        return eO(this, e).get(e)
                    }, eh.prototype.has = function(e) {
                        return eO(this, e).has(e)
                    }, eh.prototype.set = function(e, t) {
                        var n = eO(this, e),
                            r = n.size;
                        return n.set(e, t), this.size += +(n.size != r), this
                    }, eg.prototype.add = eg.prototype.push = function(e) {
                        return this.__data__.set(e, i), this
                    }, eg.prototype.has = function(e) {
                        return this.__data__.has(e)
                    }, ev.prototype.clear = function() {
                        this.__data__ = new ep, this.size = 0
                    }, ev.prototype.delete = function(e) {
                        var t = this.__data__,
                            n = t.delete(e);
                        return this.size = t.size, n
                    }, ev.prototype.get = function(e) {
                        return this.__data__.get(e)
                    }, ev.prototype.has = function(e) {
                        return this.__data__.has(e)
                    }, ev.prototype.set = function(e, t) {
                        var n = this.__data__;
                        if (n instanceof ep) {
                            var r = n.__data__;
                            if (!ee || r.length < 199) return r.push([e, t]), this.size = ++n.size, this;
                            n = this.__data__ = new eh(r)
                        }
                        return n.set(e, t), this.size = n.size, this
                    };
                    var eC = J ? function(e) {
                            return null == e ? [] : function(e, t) {
                                for (var n = -1, r = null == e ? 0 : e.length, i = 0, o = []; ++n < r;) {
                                    var a = e[n];
                                    t(a, n, e) && (o[i++] = a)
                                }
                                return o
                            }(J(e = Object(e)), function(t) {
                                return q.call(e, t)
                            })
                        } : function() {
                            return []
                        },
                        ew = eb;

                    function eI(e) {
                        if (null != e) {
                            try {
                                return B.call(e)
                            } catch {}
                            try {
                                return e + ""
                            } catch {}
                        }
                        return ""
                    }

                    function eS(e, t) {
                        return e === t || e != e && t != t
                    }(Q && ew(new Q(new ArrayBuffer(1))) != y || ee && ew(new ee) != d || et && ew(et.resolve()) != h || en && ew(new en) != v || er && ew(new er) != b) && (ew = function(e) {
                        var t = eb(e),
                            n = t == p ? e.constructor : void 0,
                            r = n ? eI(n) : "";
                        if (r) switch (r) {
                            case eo:
                                return y;
                            case ea:
                                return d;
                            case es:
                                return h;
                            case el:
                                return v;
                            case ec:
                                return b
                        }
                        return t
                    });
                    var eM = eE(function() {
                            return arguments
                        }()) ? eE : function(e) {
                            return eN(e) && k.call(e, "callee") && !q.call(e, "callee")
                        },
                        eA = Array.isArray,
                        eD = W || function() {
                            return !1
                        };

                    function eL(e) {
                        if (!eR(e)) return !1;
                        var t = eb(e);
                        return t == u || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t
                    }

                    function ej(e) {
                        return "number" == typeof e && e > -1 && e % 1 == 0 && e <= 0x1fffffffffffff
                    }

                    function eR(e) {
                        var t = typeof e;
                        return null != e && ("object" == t || "function" == t)
                    }

                    function eN(e) {
                        return "object" == typeof e && !!e
                    }
                    var eP = j ? function(e) {
                        return j(e)
                    } : function(e) {
                        return eN(e) && ej(e.length) && !!T[eb(e)]
                    };

                    function eU(e) {
                        return null != e && ej(e.length) && !eL(e) ? function(e, t) {
                            var n, r, i = eA(e),
                                o = !i && eM(e),
                                a = !i && !o && eD(e),
                                s = !i && !o && !a && eP(e),
                                l = i || o || a || s,
                                c = l ? function(e, t) {
                                    for (var n = -1, r = Array(e); ++n < e;) r[n] = t(n);
                                    return r
                                }(e.length, String) : [],
                                u = c.length;
                            for (var d in e) {
                                k.call(e, d) && !(l && ("length" == d || a && ("offset" == d || "parent" == d) || s && ("buffer" == d || "byteLength" == d || "byteOffset" == d) || (n = d, r = u, (r ? ? = 0x1fffffffffffff) && ("number" == typeof n || O.test(n)) && n > -1 && n % 1 == 0 && n < r))) && c.push(d)
                            }
                            return c
                        }(e) : function(e) {
                            if (n = (t = e) && t.constructor, t !== ("function" == typeof n && n.prototype || x)) return X(e);
                            var t, n, r = [];
                            for (var i in Object(e)) k.call(e, i) && "constructor" != i && r.push(i);
                            return r
                        }(e)
                    }
                    t.exports = function(e, t) {
                        return function e(t, n, r, i, u) {
                            return t === n || (null != t && null != n && (eN(t) || eN(n)) ? function(e, t, n, r, i, u) {
                                var h = eA(e),
                                    b = eA(t),
                                    _ = h ? a : ew(e),
                                    O = b ? a : ew(t);
                                _ = _ == o ? p : _, O = O == o ? p : O;
                                var T = _ == p,
                                    C = O == p,
                                    w = _ == O;
                                if (w && eD(e)) {
                                    if (!eD(t)) return !1;
                                    h = !0, T = !1
                                }
                                if (w && !T) return u || = new ev, h || eP(e) ? ey(e, t, n, r, i, u) : function(e, t, n, r, i, o, a) {
                                    switch (n) {
                                        case y:
                                            if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) break;
                                            e = e.buffer, t = t.buffer;
                                        case E:
                                            return !(e.byteLength != t.byteLength || !o(new H(e), new H(t)));
                                        case s:
                                        case l:
                                        case f:
                                            return eS(+e, +t);
                                        case c:
                                            return e.name == t.name && e.message == t.message;
                                        case g:
                                        case m:
                                            return e == t + "";
                                        case d:
                                            var u = R;
                                        case v:
                                            var p = 1 & r;
                                            if (u || = N, e.size != t.size && !p) break;
                                            var h = a.get(e);
                                            if (h) return h == t;
                                            r |= 2, a.set(e, t);
                                            var b = ey(u(e), u(t), r, i, o, a);
                                            return a.delete(e), b;
                                        case "[object Symbol]":
                                            if (ed) return ed.call(e) == ed.call(t)
                                    }
                                    return !1
                                }(e, t, _, n, r, i, u);
                                if (!(1 & n)) {
                                    var I = T && k.call(e, "__wrapped__"),
                                        S = C && k.call(t, "__wrapped__");
                                    if (I || S) return i(I ? e.value() : e, S ? t.value() : t, n, r, u || = new ev)
                                }
                                return !!w && function(e, t, n, r, i, o) {
                                    var a = 1 & n,
                                        s = e_(e),
                                        l = s.length;
                                    if (l != e_(t).length && !a) return !1;
                                    for (var c = l; c--;) {
                                        var u = s[c];
                                        if (!(a ? u in t : k.call(t, u))) return !1
                                    }
                                    var d = o.get(e);
                                    if (d && o.get(t)) return d == t;
                                    var f = !0;
                                    o.set(e, t), o.set(t, e);
                                    for (var p = a; ++c < l;) {
                                        var h = e[u = s[c]],
                                            g = t[u];
                                        if (r) var v = a ? r(g, h, u, t, e, o) : r(h, g, u, e, t, o);
                                        if (!(void 0 === v ? h === g || i(h, g, n, r, o) : v)) {
                                            f = !1;
                                            break
                                        }
                                        p || = "constructor" == u
                                    }
                                    if (f && !p) {
                                        var m = e.constructor,
                                            b = t.constructor;
                                        m != b && "constructor" in e && "constructor" in t && !("function" == typeof m && m instanceof m && "function" == typeof b && b instanceof b) && (f = !1)
                                    }
                                    return o.delete(e), o.delete(t), f
                                }(e, t, n, r, i, u || = new ev)
                            }(t, n, r, i, e, u) : t != t && n != n)
                        }(e, t)
                    }
                }),
                D = c(A(), 1),
                L = function(e) {
                    return e.FIELD_ID = "data-contentful-field-id", e.ENTRY_ID = "data-contentful-entry-id", e.ASSET_ID = "data-contentful-asset-id", e.LOCALE = "data-contentful-locale", e.SPACE = "data-contentful-space", e.ENVIRONMENT = "data-contentful-environment", e
                }({}),
                j = function(e) {
                    return e.MOUSE_MOVE = "MOUSE_MOVE", e.SCROLL_START = "SCROLL_START", e.SCROLL_END = "SCROLL_END", e.RESIZE_START = "RESIZE_START", e.RESIZE_END = "RESIZE_END", e.TAGGED_ELEMENTS = "TAGGED_ELEMENTS", e.INSPECTOR_MODE_CHANGED = "INSPECTOR_MODE_CHANGED", e
                }({}),
                R = {
                    0: 8203,
                    1: 8204,
                    2: 8205,
                    3: 8290,
                    4: 8291,
                    5: 8288,
                    6: 65279,
                    7: 8289,
                    8: 119155,
                    9: 119156,
                    a: 119157,
                    b: 119158,
                    c: 119159,
                    d: 119160,
                    e: 119161,
                    f: 119162
                },
                N = {
                    0: 8203,
                    1: 8204,
                    2: 8205,
                    3: 65279
                },
                P = {
                    0: String.fromCodePoint(N[0]),
                    1: String.fromCodePoint(N[1]),
                    2: String.fromCodePoint(N[2]),
                    3: String.fromCodePoint(N[3])
                };
            [, , , , ].fill(String.fromCodePoint(N[0])).join(""), Object.fromEntries(Object.entries(P).map(e => [e[1], +e[0]])), Object.fromEntries(Object.entries(R).map(e => e.reverse()));
            var U = `${Object.values(R).map(e=>`\\u{${e.toString(16)}}`).join("")}`,
                x = RegExp(`[${U}]{4,}`, "gu");

            function z(e, t) {
                return e.href === t.href
            }

            function B({
                root: e = window.document,
                options: t
            }) {
                var n, r;
                let i, o = [...t.ignoreManuallyTaggedElements ? [] : e.querySelectorAll(`[${L.ASSET_ID}][${L.FIELD_ID}], [${L.ENTRY_ID}][${L.FIELD_ID}]`)].map(e => ({
                        element: e,
                        attributes: function(e, t) {
                            if (!(e && e.nodeType === Node.ELEMENT_NODE && !(!e.hasAttribute(L.FIELD_ID) || !e.hasAttribute(L.ENTRY_ID) && !e.hasAttribute(L.ASSET_ID)))) return null;
                            let n = {
                                fieldId: e.getAttribute(L.FIELD_ID),
                                locale: e.getAttribute(L.LOCALE) ? ? t.locale,
                                environment: e.getAttribute(L.ENVIRONMENT) ? ? t.environment,
                                space: e.getAttribute(L.SPACE) ? ? t.space,
                                manuallyTagged: !0
                            };
                            if (!n.fieldId) return w.warn("Element is missing field ID attribute and cannot be tagged", {
                                id: e.getAttribute(L.ENTRY_ID) ? ? e.getAttribute(L.ASSET_ID),
                                sharedProps: n
                            }), null;
                            let r = e.getAttribute(L.ENTRY_ID);
                            if (r) return { ...n,
                                entryId: r
                            };
                            let i = e.getAttribute(L.ASSET_ID);
                            return i ? { ...n,
                                assetId: i
                            } : null
                        }(e, t)
                    })).filter(({
                        attributes: e
                    }) => null !== e),
                    a = [];
                for (let {
                        node: t,
                        text: r
                    } of (n = "body" in e ? e.body : e, i = [], "function" == typeof n.matches && n.matches("*") && (i = [n]), [...i, ...Array.from(n.querySelectorAll("*:not(script,style,meta,title)"))].map(e => {
                        var t;
                        return {
                            node: e,
                            text: (t = e).matches("input[type=submit], input[type=button], input[type=reset]") ? t.value : t.matches("img, video") ? t.alt : Array.from(t.childNodes).filter(e => e.nodeType === Node.TEXT_NODE && !!e.textContent).map(e => e.textContent).join("")
                        }
                    }).filter(({
                        text: e
                    }) => !!(e && e.match(x))))) {
                    let e = function(e) {
                        let t = e.match(b);
                        return t ? function(e, t = !1) {
                            let n = Array.from(e),
                                r = 1 / 0,
                                i = -1;
                            for (let e = 0; e < n.length; ++e) n[e] === h[0] && n[e + 1] === h[1] && n[e + 2] === h[2] && n[e + 3] === h[3] && (r = Math.min(r, e), i = Math.max(i, e));
                            if (-1 === i) return function(e, t) {
                                let n = [];
                                for (let t = .5 * e.length; t--;) {
                                    let r = `${v[e[2*t].codePointAt(0)]}${v[e[2*t+1].codePointAt(0)]}`;
                                    n.unshift(String.fromCharCode(parseInt(r, 16)))
                                }
                                let r = [],
                                    i = [n.join("")],
                                    o = 10;
                                for (; i.length;) {
                                    let e = i.shift();
                                    try {
                                        if (r.push(JSON.parse(e)), t) break
                                    } catch (n) {
                                        if (!o--) throw n;
                                        let t = +n.message.match(/\sposition\s(\d+)$/) ? .[1];
                                        if (!t) throw n;
                                        i.unshift(e.substring(0, t), e.substring(t))
                                    }
                                }
                                return r
                            }(n, t);
                            for (let e = r; e <= i; ++e)
                                if (!((n.length - e) % 4)) try {
                                    let r = n.slice(e + 4),
                                        i = new Uint8Array(r.length / 4);
                                    for (let e = 0; e < i.length; e++) i[e] = g[r[4 * e]] << 6 | g[r[4 * e + 1]] << 4 | g[r[4 * e + 2]] << 2 | g[r[4 * e + 3]];
                                    let o = new TextDecoder().decode(i);
                                    if (t) {
                                        let e = o.indexOf("\0");
                                        return -1 === e && (e = o.length), [JSON.parse(o.slice(0, e))]
                                    }
                                    return o.split("\0").filter(Boolean).map(e => JSON.parse(e))
                                } catch {}
                            return []
                        }(t[0], !0)[0] : void 0
                    }(r);
                    if (!e || !e.origin.includes("contentful.com")) {
                        w.warn("Element has missing or invalid ContentSourceMap, please check if you have correctly enabled ContentSourceMaps and that the element's data originates from Contentful", {
                            node: t,
                            sourceMap: e
                        });
                        continue
                    }
                    if (!(function(e, t) {
                            for (let n of t)
                                if (n.element === e || n.element.contains(e)) return !0;
                            return !1
                        }(t, o) || a.some(n => n.element.contains(t) && z(n.sourceMap, e)))) {
                        if (t.matches("img")) {
                            let n = t.closest("figure") || t.closest("picture") || t;
                            a.push({
                                element: n,
                                sourceMap: e
                            });
                            continue
                        }
                        a.push({
                            element: t,
                            sourceMap: e
                        })
                    }
                }
                let s = a.filter((e, t) => a.findIndex(t => !(!z(e.sourceMap, t.sourceMap) || e.element !== t.element)) === t);
                for (let {
                        element: e,
                        sourceMap: t
                    } of s) {
                    let n = null;
                    if (t.href) {
                        let r = function(e) {
                            try {
                                let t = new URL(e),
                                    n = t.searchParams.get("focusedField"),
                                    r = t.searchParams.get("focusedLocale"),
                                    i = t.pathname.split("/").filter(Boolean),
                                    o = i.indexOf("spaces"),
                                    a = i.indexOf("environments"),
                                    s = -1 === o ? void 0 : i[o + 1],
                                    l = -1 === a ? void 0 : i[a + 1],
                                    c, u, d = i.indexOf("entries"),
                                    f = i.indexOf("assets");
                                return -1 === d ? -1 !== f && (c = "Asset", u = i[f + 1]) : (c = "Entry", u = i[d + 1]), c && u ? n ? r ? s && l ? {
                                    entityId: u,
                                    entityType: c,
                                    fieldId: n,
                                    locale: r,
                                    space: s,
                                    environment: l
                                } : (console.warn("Missing space or environment in href path", {
                                    href: e
                                }), null) : (console.warn("Missing focusedLocale query parameter in href", {
                                    href: e
                                }), null) : (console.warn("Missing focusedField query parameter in href", {
                                    href: e
                                }), null) : (console.warn("Unable to determine entityType or entityId from href", {
                                    href: e
                                }), null)
                            } catch (t) {
                                return console.warn("Invalid href URL", {
                                    href: e,
                                    error: t
                                }), null
                            }
                        }(t.href);
                        if (!r) continue;
                        if ("Asset" === r.entityType) n = {
                            fieldId: r.fieldId,
                            locale: r.locale,
                            space: r.space,
                            environment: r.environment,
                            assetId: r.entityId
                        };
                        else if ("Entry" === r.entityType) n = {
                            fieldId: r.fieldId,
                            locale: r.locale,
                            space: r.space,
                            environment: r.environment,
                            entryId: r.entityId
                        };
                        else {
                            w.warn("Unknown entityType", {
                                element: e,
                                sourceMap: t
                            });
                            continue
                        }
                    } else {
                        if (t.contentful && (r = t.contentful) && "string" == typeof r.entity && "string" == typeof r.field && "string" == typeof r.locale && "string" == typeof r.space && "string" == typeof r.environment && ("Asset" === r.entityType || "Entry" === r.entityType)) {
                            let r = t.contentful;
                            if (!r.entity || !r.field || !r.locale || !r.space || !r.environment) {
                                w.warn("Element has missing information in their ContentSourceMap, please check if you have restricted the platform for the encoding. (Missing parameters in `contentful`)", {
                                    element: e,
                                    sourceMap: t
                                });
                                continue
                            }
                            let i = {
                                fieldId: r.field,
                                locale: r.locale,
                                space: r.space,
                                environment: r.environment
                            };
                            if ("Asset" === r.entityType) i.assetId = r.entity, n = i;
                            else if ("Entry" === r.entityType) i.entryId = r.entity, n = i;
                            else {
                                w.warn("Unknown entityType in contentful data", {
                                    element: e,
                                    sourceMap: t
                                });
                                continue
                            }
                        } else {
                            w.warn("Element has neither href nor contentful data in their ContentSourceMap, unable to extract attributes.", {
                                element: e,
                                sourceMap: t
                            });
                            continue
                        }
                    }
                    o.push({
                        element: e,
                        attributes: n
                    })
                }
                let l = o.filter(({
                    attributes: e
                }) => e ? .manuallyTagged === !1 || !e ? .manuallyTagged).length;
                return {
                    taggedElements: o,
                    manuallyTaggedCount: o.length - l,
                    automaticallyTaggedCount: l,
                    autoTaggedElements: s
                }
            }

            function k({
                options: e
            }) {
                return [...new Set(B({
                    options: e
                }).taggedElements.map(e => e.attributes && "entryId" in e.attributes ? e.attributes.entryId : null).filter(Boolean))]
            }
            var G = class {
                    options;
                    delay = 300;
                    isScrolling = !1;
                    scrollTimeout;
                    isResizing = !1;
                    resizeTimeout;
                    hoveredElement;
                    taggedElements = [];
                    manuallyTaggedCount = 0;
                    automaticallyTaggedCount = 0;
                    releaseId;
                    intersectionObserver;
                    observersCB = [];
                    cleanupCB = [];
                    constructor(e) {
                        this.options = e, this.intersectionObserver = new IntersectionObserver(e => {
                            let t = this.taggedElements;
                            for (let n of e)
                                if (n.isIntersecting)
                                    for (let e of t) e.element === n.target && (e.coordinates = n.intersectionRect, e.isVisible = n.target.checkVisibility({
                                        checkOpacity: !0,
                                        checkVisibilityCSS: !0
                                    }));
                            this.taggedElements = t, this.sendTaggedElements()
                        }, {
                            threshold: .15
                        })
                    }
                    init = () => {
                        this.cleanupCB = [this.addScrollListener(), this.addMutationListener(document.body), this.addResizeListener(), this.addHoverListener()], this.updateElements()
                    };
                    cleanup = () => {
                        this.observersCB.forEach(e => e()), this.cleanupCB.forEach(e => e())
                    };
                    receiveMessage = e => {
                        if (e.method === j.INSPECTOR_MODE_CHANGED) {
                            let {
                                isInspectorActive: t,
                                releaseId: n
                            } = e;
                            this.releaseId = n, t ? this.init() : this.cleanup()
                        }
                    };
                    observe = e => {
                        this.intersectionObserver.observe(e);
                        let t = this.addMutationListener(e);
                        this.observersCB.push(t, () => this.intersectionObserver.unobserve(e))
                    };
                    addScrollListener = () => {
                        let {
                            targetOrigin: e
                        } = this.options, t = () => {
                            this.isScrolling || (this.isScrolling = !0, S(j.SCROLL_START, {}, e)), this.scrollTimeout && clearTimeout(this.scrollTimeout), this.scrollTimeout = setTimeout(() => {
                                this.isScrolling = !1, S(j.SCROLL_END, {}, e), this.updateElements()
                            }, this.delay)
                        }, n = {
                            capture: !0,
                            passive: !0
                        };
                        return window.addEventListener("scroll", t, n), () => window.removeEventListener("scroll", t, n)
                    };
                    addMutationListener = e => {
                        let t = new MutationObserver(() => {
                            this.updateElements()
                        });
                        return t.observe(e, {
                            characterData: !0,
                            attributes: !0,
                            attributeFilter: [L.ENTRY_ID, L.FIELD_ID, L.LOCALE, L.SPACE, L.ENVIRONMENT, "class", "style"],
                            childList: !0,
                            subtree: !0
                        }), () => t.disconnect()
                    };
                    addResizeListener = () => {
                        let {
                            targetOrigin: e
                        } = this.options, t = new ResizeObserver(() => {
                            this.isResizing || (this.isResizing = !0, S(j.RESIZE_START, {}, e)), this.resizeTimeout && clearTimeout(this.resizeTimeout), this.resizeTimeout = setTimeout(() => {
                                this.isResizing = !1, S(j.RESIZE_END, {}, e), this.updateElements()
                            }, this.delay)
                        });
                        return t.observe(document.body), () => t.disconnect()
                    };
                    addHoverListener = () => {
                        let e = M(e => {
                                let t;
                                for (let n of e) {
                                    let e = n;
                                    if ("BODY" === e.nodeName) break;
                                    let r = this.taggedElements.find(t => t.element === e);
                                    if (r) {
                                        t = r;
                                        break
                                    }
                                }
                                this.hoveredElement = t ? .element, this.updateElements()
                            }, this.delay),
                            t = t => {
                                e(t.composedPath())
                            };
                        return window.addEventListener("mouseover", t, {
                            passive: !0
                        }), () => window.removeEventListener("mouseover", t)
                    };
                    sendTaggedElements = () => {
                        S(j.TAGGED_ELEMENTS, {
                            elements: this.taggedElements.map(e => ({
                                coordinates: e.coordinates,
                                isVisible: !!e.isVisible,
                                attributes: e.attributes,
                                isHovered: this.hoveredElement === e.element,
                                isCoveredByOtherElement: !!e.isCoveredByOtherElement,
                                snapshot: function(e) {
                                    return I.has(e.element.tagName.toUpperCase()) ? {
                                        [e.element.tagName.toLowerCase()]: Array.from(e.element.attributes).map(e => `${e.name}="${e.value}"`).join(" ")
                                    } : {
                                        [e.element.tagName.toLowerCase()]: e.element.innerHTML
                                    }
                                }(e)
                            })),
                            automaticallyTaggedCount: this.automaticallyTaggedCount,
                            manuallyTaggedCount: this.manuallyTaggedCount,
                            ...void 0 !== this.releaseId && {
                                releaseId: this.releaseId
                            }
                        }, this.options.targetOrigin)
                    };
                    updateElements = () => {
                        let {
                            taggedElements: e,
                            manuallyTaggedCount: t,
                            automaticallyTaggedCount: n
                        } = B({
                            options: this.options
                        }), r = ((e, t = window.document) => ((e, t = window.document) => e.map(e => ({ ...e,
                            isVisible: e.element.checkVisibility({
                                checkOpacity: !0,
                                checkVisibilityCSS: !0
                            }),
                            isCoveredByOtherElement: ((e, t, n = window.document) => {
                                let {
                                    top: r,
                                    right: i,
                                    bottom: o,
                                    left: a
                                } = t, s = n.elementFromPoint(a + 1, r + 1), l = n.elementFromPoint(i - 1, r + 1), c = n.elementFromPoint(a + 1, o - 1), u = n.elementFromPoint(i - 1, o - 1), d = t => !!t && (e === t || e.contains(t));
                                return [d(s), d(l), d(c), d(u)].filter(Boolean).length < 2
                            })(e.element, e.coordinates, t)
                        })))(e.map(({
                            element: e,
                            attributes: t
                        }) => ({
                            element: e,
                            coordinates: e.getBoundingClientRect(),
                            attributes: t
                        })), t))(e);
                        (0, D.default)(r, this.taggedElements) || (this.observersCB.forEach(e => e()), this.observersCB = [], this.taggedElements = r, e.forEach(({
                            element: e
                        }) => this.observe(e)), this.manuallyTaggedCount = t, this.automaticallyTaggedCount = n)
                    }
                },
                {
                    parse: F,
                    stringify: $
                } = JSON,
                {
                    keys: V
                } = Object,
                Y = String,
                H = "object",
                q = (e, t) => t,
                K = (e, t, n) => {
                    let r = Y(t.push(n) - 1);
                    return e.set(n, r), r
                },
                Z = function(e) {
                    return e.CONNECTED = "CONNECTED", e.DISCONNECTED = "DISCONNECTED", e.ERROR = "ERROR", e.TAGGED_FIELD_CLICKED = "TAGGED_FIELD_CLICKED", e.URL_CHANGED = "URL_CHANGED", e.SUBSCRIBED = "SUBSCRIBED", e.UNSUBSCRIBED = "UNSUBSCRIBED", e.ENTRY_UPDATED = "ENTRY_UPDATED", e.ENTRY_SAVED = "ENTRY_SAVED", e.DEBUG_MODE_ENABLED = "DEBUG_MODE_ENABLED", e
                }(Z || {}),
                J = class {
                    subscriptions = new Map;
                    defaultLocale;
                    sendMessage;
                    constructor({
                        locale: e,
                        targetOrigin: t
                    }) {
                        this.defaultLocale = e, this.sendMessage = (e, n) => S(e, n, t)
                    }
                    async receiveMessage(e) {
                        if (e.method === Z.ENTRY_UPDATED) {
                            let {
                                data: t,
                                subscriptionId: n
                            } = e, r = this.subscriptions.get(n);
                            r ? (r.callback(t), r.data = t, this.subscriptions.set(n, r)) : w.error("Received an update for an unknown subscription", {
                                subscriptionId: n,
                                data: t,
                                subscriptions: this.subscriptions
                            })
                        }
                    }
                    subscribe(e) {
                        let t = `${performance.now()}-${Math.random().toString(36).slice(2)}`,
                            n = e.locale ? ? this.defaultLocale;
                        this.subscriptions.set(t, { ...e
                        });
                        let r = {
                            locale: n,
                            event: "edit",
                            id: t,
                            config: ((e, t, n) => {
                                let r = t && typeof t === H ? (e, n) => "" === e || -1 < t.indexOf(e) ? n : void 0 : t || q,
                                    i = new Map,
                                    o = [],
                                    a = [],
                                    s = +K(i, o, r.call({
                                        "": e
                                    }, "", e)),
                                    l = !s;
                                for (; s < o.length;) l = !0, a[s] = $(o[s++], c, n);
                                return "[" + a.join(",") + "]";

                                function c(e, t) {
                                    if (l) return l = !l, t;
                                    let n = r.call(this, e, t);
                                    switch (typeof n) {
                                        case H:
                                            if (null === n) break;
                                        case "string":
                                            return i.get(n) || K(i, o, n)
                                    }
                                    return n
                                }
                            })(e)
                        };
                        return this.sendMessage(Z.SUBSCRIBED, r), () => {
                            this.sendMessage(Z.UNSUBSCRIBED, r), this.subscriptions.delete(t)
                        }
                    }
                },
                W = class {
                    locale;
                    options;
                    inspectorModeEnabled;
                    subscription;
                    constructor({
                        locale: e,
                        options: t,
                        inspectorModeEnabled: n
                    }) {
                        this.locale = e, this.options = t, this.inspectorModeEnabled = n
                    }
                    subscribe(e) {
                        return this.subscription && w.log("There is already a subscription for the save event, the existing one will be replaced."), this.subscription = e, () => {
                            this.subscription = void 0
                        }
                    }
                    receiveMessage(e) {
                        if (e.method === Z.ENTRY_SAVED && this.subscription) {
                            let {
                                entity: t
                            } = e;
                            this.inspectorModeEnabled ? k({
                                options: this.options
                            }).includes(t.sys.id) && this.subscription(t) : this.subscription(t)
                        }
                    }
                },
                X = (O.version, ["https://app.contentful.com", "https://app.eu.contentful.com", "http://localhost:3001"]),
                Q = class e {
                    static initialized = !1;
                    static inspectorMode = null;
                    static liveUpdates = null;
                    static saveEvent = null;
                    static inspectorModeEnabled = !0;
                    static liveUpdatesEnabled = !0;
                    static locale;
                    static space;
                    static environment;
                    static sendMessage;
                    static targetOrigin;
                    static init(t) {
                        if ("object" != typeof t || !t ? .locale) throw Error("Init function has to be called with a locale configuration (for example: `ContentfulLivePreview.init({ locale: 'en-US'})`)");
                        let {
                            debugMode: n,
                            enableInspectorMode: r,
                            enableLiveUpdates: i,
                            locale: o,
                            environment: a,
                            space: s,
                            targetOrigin: l
                        } = t;
                        if ("u" > typeof window) {
                            if (! function() {
                                    try {
                                        return window.top ? .location.href !== window.location.href
                                    } catch {
                                        return !0
                                    }
                                }()) return this.liveUpdatesEnabled = !1, Promise.resolve(null);
                            if (n && (T = n), "boolean" == typeof r && (this.inspectorModeEnabled = r), "boolean" == typeof i && (this.liveUpdatesEnabled = i), this.locale = o, this.space = s, this.environment = a, this.initTargetOrigin(l), this.initialized) return w.log("You have already initialized the Live Preview SDK."), Promise.resolve(e.inspectorMode);
                            this.inspectorModeEnabled && (this.inspectorMode = new G({
                                    locale: o,
                                    space: s,
                                    environment: a,
                                    targetOrigin: this.targetOrigin,
                                    ignoreManuallyTaggedElements: t.experimental ? .ignoreManuallyTaggedElements
                                })), this.liveUpdatesEnabled && (this.liveUpdates = new J({
                                    locale: o,
                                    targetOrigin: this.targetOrigin
                                }), this.saveEvent = new W({
                                    locale: o,
                                    options: {
                                        locale: this.locale,
                                        space: this.space,
                                        environment: this.environment,
                                        targetOrigin: this.targetOrigin
                                    },
                                    inspectorModeEnabled: this.inspectorModeEnabled
                                })), window.addEventListener("message", e => {
                                    if ("object" == typeof e.data && e.data && "source" in e.data && "live-preview-editor" === e.data.source) {
                                        if (w.log("Received message", e.data), e.data.method === Z.DEBUG_MODE_ENABLED) return void(T = !0);
                                        this.inspectorModeEnabled && this.inspectorMode ? .receiveMessage(e.data), this.liveUpdatesEnabled && (this.liveUpdates ? .receiveMessage(e.data), this.saveEvent ? .receiveMessage(e.data))
                                    }
                                }),
                                function(e, t = 500) {
                                    let n = window.location.href,
                                        r = setInterval(() => {
                                            let t = window.location.href;
                                            t !== n && (n = t, e(t))
                                        }, t)
                                }(() => {
                                    S(Z.URL_CHANGED, {
                                        action: Z.URL_CHANGED,
                                        taggedElementCount: document.querySelectorAll(`[${L.ENTRY_ID}]`).length
                                    }, this.targetOrigin)
                                });
                            let {
                                taggedElements: c,
                                manuallyTaggedCount: u,
                                automaticallyTaggedCount: d
                            } = this.inspectorModeEnabled ? B({
                                options: {
                                    locale: this.locale,
                                    space: this.space,
                                    environment: this.environment
                                }
                            }) : {
                                taggedElements: [],
                                manuallyTaggedCount: 0,
                                automaticallyTaggedCount: 0
                            }, f = c.length;
                            return S(Z.CONNECTED, {
                                action: Z.CONNECTED,
                                connected: !0,
                                tags: f,
                                taggedElementCount: f,
                                locale: this.locale,
                                isInspectorEnabled: this.inspectorModeEnabled,
                                isLiveUpdatesEnabled: this.liveUpdatesEnabled,
                                manuallyTaggedElementCount: u,
                                automaticallyTaggedElementCount: d,
                                hideCoveredElementOutlines: t.experimental ? .hideCoveredElementOutlines,
                                version: O.version
                            }, this.targetOrigin), this.initialized = !0, Promise.resolve(e.inspectorMode)
                        }
                    }
                    static initTargetOrigin(e) {
                        if (e) this.targetOrigin = Array.isArray(e) ? e : [e];
                        else {
                            let e = window.location.ancestorOrigins,
                                t = e ? X.find(t => e.contains(t)) : X.find(e => document.referrer.includes(e));
                            if (!t) throw Error("The current origin is not supported. Please provide a targetOrigin in the live preview configuration.");
                            this.targetOrigin = [t]
                        }
                    }
                    static subscribe(e, t) {
                        if (!this.liveUpdatesEnabled) return () => {};
                        let n = "string" == typeof e ? e : "edit",
                            r = "object" == typeof e ? e : t;
                        if ("save" === n) {
                            if (!this.saveEvent) throw Error("Save event is not initialized, please call `ContentfulLivePreview.init()` first.");
                            return this.saveEvent.subscribe(r.callback)
                        }
                        if (!this.liveUpdates) throw Error("Live updates are not initialized, please call `ContentfulLivePreview.init()` first.");
                        return this.liveUpdates.subscribe(r)
                    }
                    static getProps(e) {
                        let {
                            fieldId: t,
                            locale: n,
                            environment: r,
                            space: i
                        } = e;
                        if (!this.inspectorModeEnabled) return null;
                        if (t) {
                            let o = { ...n ? {
                                    [L.LOCALE]: n
                                } : {},
                                ...r ? {
                                    [L.ENVIRONMENT]: r
                                } : {},
                                ...i ? {
                                    [L.SPACE]: i
                                } : {},
                                [L.FIELD_ID]: t
                            };
                            if (n && (o[L.LOCALE] = n), void 0 !== e.assetId) return { ...o,
                                [L.ASSET_ID]: e.assetId
                            };
                            if (void 0 !== e.entryId) return { ...o,
                                [L.ENTRY_ID]: e.entryId
                            }
                        }
                        return w.warn("Missing property for inspector mode", { ...e
                        }), null
                    }
                    static toggleInspectorMode() {
                        return this.inspectorModeEnabled = !this.inspectorModeEnabled, this.inspectorModeEnabled
                    }
                    static toggleLiveUpdatesMode() {
                        return this.liveUpdatesEnabled = !this.liveUpdatesEnabled, this.liveUpdatesEnabled
                    }
                    static openEntryInEditor(e) {
                        let t = {
                            locale: this.locale,
                            environment: this.environment,
                            space: this.space
                        };
                        if (void 0 !== e.assetId && e.fieldId || void 0 !== e.entryId && e.fieldId) {
                            var n, r;
                            return void(n = { ...t,
                                ...e
                            }, r = this.targetOrigin, S("TAGGED_FIELD_CLICKED", {
                                action: "TAGGED_FIELD_CLICKED",
                                ...n
                            }, r))
                        }
                        w.error("Please provide field id and entry/asset id to openEntryInEditor.", { ...e
                        })
                    }
                    static getEntryList() {
                        return k({
                            options: {
                                locale: this.locale,
                                space: this.space,
                                environment: this.environment
                            }
                        })
                    }
                },
                ee = n(92594),
                et = n(11002),
                en = c(A(), 1),
                er = (0, ee.createContext)(null);

            function ei(e) {
                let {
                    children: t,
                    locale: n,
                    space: r,
                    environment: i,
                    debugMode: o = !1,
                    enableInspectorMode: a = !0,
                    enableLiveUpdates: s = !0,
                    targetOrigin: l,
                    experimental: c
                } = e;
                if (!n) throw Error('ContentfulLivePreviewProvider has to be called with a locale property (for example: `<ContentfulLivePreviewProvider locale="en-US">{children}</ContentfulLivePreviewProvider>`');
                Q.init({
                    locale: n,
                    space: r,
                    environment: i,
                    debugMode: o,
                    enableInspectorMode: a,
                    enableLiveUpdates: s,
                    targetOrigin: l,
                    experimental: c
                });
                let u = (0, ee.useMemo)(() => ({
                    locale: n,
                    space: r,
                    environment: i,
                    debugMode: o,
                    enableInspectorMode: a,
                    enableLiveUpdates: s,
                    targetOrigin: l
                }), [n, r, i, o, a, s, l]);
                return (0, et.jsx)(er.Provider, {
                    value: u,
                    children: t
                })
            }

            function eo(e, t) {
                var n, r;
                let i, o, a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                    [s, l] = (0, ee.useState)({
                        data: e,
                        version: 1
                    }),
                    c = (0, ee.useRef)(e),
                    u = (0, ee.useRef)(M(l)),
                    d = (0, ee.useContext)(er),
                    f = "object" == typeof t ? t : {
                        locale: t,
                        skip: a
                    },
                    p = (0, ee.useMemo)(() => (!d || !!d.enableLiveUpdates) && !f.skip && !!(Array.isArray(e) && e.length || e && "object" == typeof e && Object.keys(e).length), [d, f.skip, e]);
                return n = () => {
                    if (c.current !== e && (l({
                            data: e,
                            version: 1
                        }), c.current = e), p) return Q.subscribe("edit", {
                        data: e,
                        locale: f.locale,
                        query: f.query,
                        callback: e => {
                            u.current(t => ({
                                data: e,
                                version: t.version + 1
                            }))
                        }
                    })
                }, r = [e, p, f.locale, f.query], (0, ee.useEffect)(n, (i = (0, ee.useRef)(r), o = (0, ee.useRef)(0), (0, en.default)(r, i.current) || (i.current = r, o.current += 1), (0, ee.useMemo)(() => i.current, [o.current]))), s.data
            }
        },
        75713: (e, t, n) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), ! function(e, t) {
                for (var n in t) Object.defineProperty(e, n, {
                    enumerable: !0,
                    get: t[n]
                })
            }(t, {
                default: function() {
                    return l
                },
                getImageProps: function() {
                    return s
                }
            });
            let r = n(97452),
                i = n(41495),
                o = n(89779),
                a = r._(n(20597));

            function s(e) {
                let {
                    props: t
                } = (0, i.getImgProps)(e, {
                    defaultLoader: a.default,
                    imgConf: {
                        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                        imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                        path: "/_next/image",
                        loader: "default",
                        dangerouslyAllowSVG: !1,
                        unoptimized: !1
                    }
                });
                for (let [e, n] of Object.entries(t)) void 0 === n && delete t[e];
                return {
                    props: t
                }
            }
            let l = o.Image
        }
    }
]);