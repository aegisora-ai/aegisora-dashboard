(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5470], {
        1783: e => {
            e.exports = {
                code: "ContentfulRichText_code__jLRUs",
                "table-scroll": "ContentfulRichText_table-scroll__7yzeR",
                table: "ContentfulRichText_table__H9DIV"
            }
        },
        9188: (e, t, n) => {
            "use strict";
            n.d(t, {
                LocalizationProvider: () => o,
                useLocalization: () => c
            });
            var l = n(11002),
                a = n(92594),
                i = n(74185);
            let r = (0, a.createContext)(null);

            function c() {
                let e = (0, a.useContext)(r);
                if (!e) throw Error("useLocalization must be used within a <LocalizationProvider>");
                return e
            }

            function o(e) {
                var t, n;
                let c = null != (t = e.origin) ? t : "https://zapier.com",
                    o = (0, a.useRef)(!!e.availableLocales),
                    [s, u] = (0, a.useState)(null),
                    [d, h] = (0, a.useState)(() => (0, i.vx)(e.pathname)),
                    [f, p] = (0, a.useState)(null != (n = e.availableLocales) ? n : null);
                return (0, a.useEffect)(() => {
                    u((0, i.Je)())
                }, []), (0, a.useEffect)(() => {
                    let e = (0, i.vx)(window.location.pathname, window.location.search);
                    h(e), "en" === e.locale ? ((0, i.rQ)("en"), window.location.replace(e.pathname + e.search)) : e.locale && (u(e.locale), (0, i.rQ)(e.locale))
                }, [e.pathname]), (0, a.useEffect)(() => {
                    d.pathname && (o.current ? o.current = !1 : (0, i.Rc)(d.pathname, c).then(p))
                }, [d.pathname, c]), (0, a.useEffect)(() => {
                    s && "en" !== s && !d.locale && (null == f ? void 0 : f.includes(s)) && !(0, i.zE)(d.pathname) && window.location.replace((0, i.Ro)(d, s))
                }, [d.pathname, d.locale, s, f]), (0, l.jsx)(r.Provider, {
                    value: {
                        url: d,
                        pref: s,
                        availableLocales: f,
                        origin: c
                    },
                    children: e.children
                })
            }
        },
        15581: (e, t, n) => {
            "use strict";
            n.d(t, {
                NextLocalizationProvider: () => r
            });
            var l = n(11002),
                a = n(99235),
                i = n(9188);

            function r(e) {
                let t = (0, a.usePathname)();
                return (0, l.jsx)(i.LocalizationProvider, { ...e,
                    pathname: t
                })
            }
        },
        34139: (e, t, n) => {
            "use strict";
            n.d(t, {
                G: () => r
            });
            var l = n(11002),
                a = n(62473),
                i = n(23362);

            function r(e) {
                var t, n, r, c;
                let o = e.src,
                    s = e.decorative ? "" : e.alt;
                if (e.asset && ("url" in e.asset ? (o = e.asset.url, null != s || (s = e.asset.description)) : "fields" in e.asset && (o = null != (n = null == (t = e.asset.fields.file) ? void 0 : t.url) ? n : o, null != s || (s = e.asset.fields.description))), !o) return null;
                o.startsWith("//") && (o = "https:".concat(o));
                let u = null != s ? s : "",
                    d = new URL(o),
                    h = d.pathname.endsWith(".svg"),
                    f = d.pathname.endsWith(".gif"),
                    p = null != (r = e.priority) ? r : "high" === e.fetchPriority,
                    {
                        width: m,
                        height: v
                    } = function(e, t, n) {
                        if (t && n) return {
                            width: t,
                            height: n
                        };
                        if (e && "url" in e && e.width && e.height) return {
                            width: e.width,
                            height: e.height
                        };
                        if (e && "fields" in e) {
                            var l, i;
                            let t = null == (i = e.fields.file) || null == (l = i.details) ? void 0 : l.image;
                            if ((null == t ? void 0 : t.width) && (null == t ? void 0 : t.height)) return {
                                width: t.width,
                                height: t.height
                            }
                        }
                        return {
                            width: null != t ? t : a.KT,
                            height: null != n ? n : a.dm
                        }
                    }(e.asset, e.width, e.height),
                    g = null != e.width && null != e.height;
                return (0, l.jsx)(i.default, {
                    src: o,
                    alt: u,
                    width: m,
                    height: v,
                    priority: p,
                    fetchPriority: p ? "high" : e.fetchPriority,
                    quality: null != (c = e.quality) ? c : 80,
                    unoptimized: h || f,
                    className: e.className,
                    style: g ? void 0 : {
                        width: "100%",
                        height: "auto"
                    }
                })
            }
        },
        52504: (e, t, n) => {
            "use strict";
            n.d(t, {
                G: () => b,
                M: () => m
            });
            var l = n(11002),
                a = n(84593),
                i = n(88505),
                r = n(96091),
                c = n(39917),
                o = n(34702),
                s = n.n(o),
                u = n(34139),
                d = n(92855),
                h = n.n(d);

            function f(e) {
                let {
                    entry: t
                } = e, {
                    asset: n,
                    caption: i,
                    maxWidth: r,
                    hyperlink: o
                } = t.fields;
                if (!n) return null;
                let {
                    alt: d,
                    decorative: f
                } = function(e) {
                    let {
                        alt: t,
                        caption: n,
                        hyperlink: l,
                        name: a
                    } = e.fields;
                    if (void 0 !== t) {
                        let e = t.trim();
                        if ("" !== e) return {
                            alt: e,
                            decorative: !1
                        };
                        if (!l) return {
                            alt: "",
                            decorative: !0
                        }
                    }
                    if (l) {
                        let e = n ? (0, c.l)(n).trim() : "";
                        return "" !== e ? {
                            alt: e,
                            decorative: !1
                        } : {
                            alt: a.trim(),
                            decorative: !1
                        }
                    }
                    return {
                        decorative: !1
                    }
                }(t), p = (0, l.jsx)(u.G, {
                    asset: n,
                    ...void 0 !== d ? {
                        alt: d
                    } : {},
                    decorative: f,
                    className: h().image
                }), v = o ? (0, l.jsx)(s(), {
                    href: o,
                    className: h().imageLink,
                    children: p
                }) : p, g = i && (0, a.i)(i, m);
                return (0, l.jsxs)("figure", {
                    className: h().figure,
                    style: r ? {
                        maxWidth: "".concat(r, "px"),
                        marginInline: "auto"
                    } : void 0,
                    children: [v, g && (0, l.jsx)("figcaption", {
                        className: h().caption,
                        children: g
                    })]
                })
            }

            function p(e) {
                var t;
                return {
                    renderMark: {
                        [i.j7.BOLD]: e => (0, l.jsx)("strong", {
                            children: e
                        }),
                        [i.j7.ITALIC]: e => (0, l.jsx)("em", {
                            children: e
                        }),
                        ...null == e ? void 0 : e.renderMark
                    },
                    renderNode: {
                        [i.XD.HYPERLINK]: (e, t) => (0, l.jsx)(s(), {
                            href: e.data.uri,
                            children: t
                        }),
                        ...null == e ? void 0 : e.renderNode
                    },
                    renderText: null != (t = null == e ? void 0 : e.renderText) ? t : e => e.split("\n").reduce((e, t, n) => [...e, n > 0 && (0, l.jsx)("br", {}, n), n > 0 ? t.trimStart() : t], [])
                }
            }
            let m = p({
                renderNode: {
                    [i.nA.PARAGRAPH]: (e, t) => (0, l.jsx)("span", {
                        children: t
                    })
                }
            });
            var v = n(1783),
                g = n.n(v);
            let x = new Set(Object.values(i.nA)),
                _ = e => (0, l.jsx)("code", {
                    className: g().code,
                    children: e
                }),
                j = p({
                    renderMark: {
                        [i.j7.CODE]: _
                    }
                });

            function w(e) {
                return (0, a.i)({
                    nodeType: i.nA.DOCUMENT,
                    data: {},
                    content: e.content
                }, j)
            }

            function E(e, t, n) {
                let a = e.content;
                return (0, l.jsx)("tr", {
                    children: a.map((e, n) => e.nodeType === i.nA.TABLE_HEADER_CELL ? (0, l.jsx)("th", {
                        scope: "thead" === t ? "col" : 0 === n ? "row" : "col",
                        children: w(e)
                    }, n) : (0, l.jsx)("td", {
                        children: w(e)
                    }, n))
                }, n)
            }
            let y = p({
                renderMark: {
                    [i.j7.CODE]: _
                },
                renderNode: {
                    [i.nA.EMBEDDED_ENTRY]: e => {
                        let t = e.data.target;
                        return t && "richImage" === t.sys.contentType.sys.id ? (0, l.jsx)(f, {
                            entry: t
                        }) : null
                    },
                    [i.nA.TABLE]: e => {
                        var t;
                        let n = e.content,
                            a = n[0],
                            r = !!(null == a || null == (t = a.content) ? void 0 : t.length) && a.content.every(e => e.nodeType === i.nA.TABLE_HEADER_CELL),
                            c = r ? [a] : [],
                            o = r ? n.slice(1) : n;
                        return (0, l.jsx)("div", {
                            className: g()["table-scroll"],
                            role: "region",
                            "aria-label": "Table",
                            tabIndex: 0,
                            children: (0, l.jsxs)("table", {
                                className: g().table,
                                children: [c.length > 0 && (0, l.jsx)("thead", {
                                    children: c.map((e, t) => E(e, "thead", t))
                                }), (0, l.jsx)("tbody", {
                                    children: o.map((e, t) => E(e, "tbody", t))
                                })]
                            })
                        })
                    }
                }
            });

            function b(e) {
                return (0, l.jsx)(r.sD, {
                    className: e.className,
                    disableDefaultStyles: e.disableDefaultStyles,
                    children: (0, a.i)(function e(t) {
                        return t.content ? { ...t,
                            content: t.content.map((n, l) => x.has(t.nodeType) && 0 === l && "text" === n.nodeType ? { ...n,
                                value: n.value.trimStart()
                            } : n.content ? e(n) : n)
                        } : t
                    }(e.document), y)
                })
            }
        },
        62473: (e, t, n) => {
            "use strict";
            n.d(t, {
                KT: () => l,
                Y9: () => i,
                dm: () => a,
                nK: () => r
            });
            let l = 800,
                a = 600,
                i = 120,
                r = 24
        },
        74185: (e, t, n) => {
            "use strict";
            n.d(t, {
                Je: () => r,
                Rc: () => d,
                Ro: () => s,
                YZ: () => i,
                rQ: () => c,
                vx: () => o,
                zE: () => u
            });
            var l = n(88811);
            let a = "preferred_locale",
                i = {
                    de: "Deutsch",
                    en: "English",
                    es: "Espa\xf1ol",
                    fr: "Fran\xe7ais",
                    ja: "日本語"
                };

            function r() {
                return (0, l.v8)(a) || null
            }

            function c(e) {
                (0, l.o)(a, e, {
                    category: "essential",
                    path: "/",
                    maxAge: 31536e3,
                    sameSite: "lax",
                    secure: window.isSecureContext
                })
            }

            function o() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                    n = Object.keys(i).find(t => e.startsWith("/".concat(t, "/")) || e === "/".concat(t));
                return {
                    pathname: n ? e.slice(n.length + 1) || "/" : e,
                    locale: null != n ? n : "",
                    search: t
                }
            }

            function s(e, t) {
                return "en" === t ? "".concat(e.pathname).concat(e.search) : "/".concat(t).concat(e.pathname).concat(e.search)
            }

            function u(e) {
                return /^(?:\/[a-z]{2}(?:-[a-z]{2})?)?\/apps\/[a-z0-9-]+\/integrations\/[a-z0-9-]+\/?$/i.test(e)
            }
            async function d(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "https://zapier.com";
                try {
                    var n;
                    let l = await fetch("".concat(t, "/api/localization/lookup?path=").concat(encodeURIComponent(e), "&v=2"));
                    if (!l.ok) return [];
                    return null != (n = (await l.json()).locales) ? n : []
                } catch (e) {
                    return []
                }
            }
        },
        77871: (e, t, n) => {
            "use strict";
            n.d(t, {
                LocaleSelector: () => c
            });
            var l = n(11002),
                a = n(96091),
                i = n(9188),
                r = n(74185);

            function c() {
                let {
                    pref: e,
                    availableLocales: t,
                    url: n
                } = (0, i.useLocalization)();
                return (0, l.jsx)(a.rI, {
                    className: e ? "" : a.Fo.hidden,
                    label: (n.locale || "en").toUpperCase(),
                    "aria-label": "Select language: ".concat(r.YZ[n.locale || e || "en"]),
                    openEventDetails: {
                        interaction_name: "locale_selector_open"
                    },
                    closeEventDetails: {
                        interaction_name: "locale_selector_close"
                    },
                    children: Object.entries(r.YZ).map(i => {
                        let [c, o] = i, s = !(null == t ? void 0 : t.includes(c));
                        return (0, l.jsxs)(a._2, {
                            className: "sl_opaque",
                            href: s ? void 0 : (0, r.Ro)(n, c),
                            external: !0,
                            disabled: s,
                            selected: e === c,
                            onClick: "en" === c ? () => (0, r.rQ)("en") : void 0,
                            clickEventDetails: {
                                interaction_name: "locale_select",
                                interaction_raw_text: o,
                                option_selected: o
                            },
                            children: [o, " - ", c.toUpperCase()]
                        }, c)
                    })
                })
            }
        },
        92855: e => {
            e.exports = {
                figure: "RichImage_figure__lFqdB",
                imageLink: "RichImage_imageLink__tZgtg",
                image: "RichImage_image__czjuO",
                caption: "RichImage_caption__fwy_0"
            }
        }
    }
]);