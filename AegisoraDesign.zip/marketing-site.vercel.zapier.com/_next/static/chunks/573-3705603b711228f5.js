(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [573], {
        30928: e => {
            e.exports = {
                content: "SecuritySection_content__QAFJp",
                featuresWrapper: "SecuritySection_featuresWrapper__KVndt",
                header: "SecuritySection_header__evAKt",
                features: "SecuritySection_features__IKDNA",
                feature: "SecuritySection_feature__cqc5O",
                featureTitle: "SecuritySection_featureTitle__CDm21",
                controlsWrapper: "SecuritySection_controlsWrapper___9Gkc",
                divider: "SecuritySection_divider__nsfRh",
                dividerIcon: "SecuritySection_dividerIcon__d_4oI",
                controls: "SecuritySection_controls__Hvrfo",
                controlsTitle: "SecuritySection_controlsTitle__H0d0v",
                controlsList: "SecuritySection_controlsList__9mWOY",
                controlBadge: "SecuritySection_controlBadge__ms89P",
                ctaWrapper: "SecuritySection_ctaWrapper__jEEAP"
            }
        },
        76329: e => {
            e.exports = {
                root: "FluidDeterminismSection_root__KmSpH",
                container: "FluidDeterminismSection_container__xLO3N",
                header: "FluidDeterminismSection_header__kkyMa",
                eyebrow: "FluidDeterminismSection_eyebrow__QzYf7",
                heading: "FluidDeterminismSection_heading__CEwI0",
                intro: "FluidDeterminismSection_intro__r0NS8",
                interactive: "FluidDeterminismSection_interactive__IPpSK",
                sliderRow: "FluidDeterminismSection_sliderRow__Fw4mL",
                sliderArrow: "FluidDeterminismSection_sliderArrow__tvPBm",
                sliderWrap: "FluidDeterminismSection_sliderWrap__rDDTQ",
                trackHitArea: "FluidDeterminismSection_trackHitArea__GIiZn",
                track: "FluidDeterminismSection_track__CbsS4",
                trackFill: "FluidDeterminismSection_trackFill__8bsaq",
                trackStop: "FluidDeterminismSection_trackStop__nYmYf",
                trackStopActive: "FluidDeterminismSection_trackStopActive__qOzqF",
                thumb: "FluidDeterminismSection_thumb__9wWZ1",
                cards: "FluidDeterminismSection_cards__qPs75",
                card: "FluidDeterminismSection_card__AK3PR",
                cardActive: "FluidDeterminismSection_cardActive__N_tY6",
                cardTitle: "FluidDeterminismSection_cardTitle__MhxAo",
                cardDescription: "FluidDeterminismSection_cardDescription__Tzik4",
                detail: "FluidDeterminismSection_detail__2pFQ3",
                media: "FluidDeterminismSection_media__c3m4v",
                mediaWithImage: "FluidDeterminismSection_mediaWithImage__IZHca",
                mediaImage: "FluidDeterminismSection_mediaImage__Rgkxf",
                mediaImageActive: "FluidDeterminismSection_mediaImageActive__q2drf",
                mediaPlaceholder: "FluidDeterminismSection_mediaPlaceholder__GZVK2",
                detailCopy: "FluidDeterminismSection_detailCopy__Rgztv",
                detailCopyInner: "FluidDeterminismSection_detailCopyInner__IGTsV",
                detailCopyFade: "FluidDeterminismSection_detailCopyFade__DxXJh",
                workflowLabel: "FluidDeterminismSection_workflowLabel__ShviX",
                workflowTitle: "FluidDeterminismSection_workflowTitle__HH1vT",
                workflowDescription: "FluidDeterminismSection_workflowDescription__cJbAz"
            }
        },
        88002: (e, i, t) => {
            "use strict";
            t.d(i, {
                FluidDeterminismSection: () => _
            });
            var a = t(11002),
                r = t(34139),
                n = t(96091),
                s = t(7151),
                l = t(90935),
                o = t(92594);
            let c = [{
                id: "deterministic",
                title: "Deterministic",
                description: "You choose the tools and steps. Every step follows fixed rules and runs the same way every time.",
                workflow: {
                    label: "Deterministic:",
                    title: "Ticket intake",
                    description: "You set the steps. Every ticket gets an auto-reply and goes to a rep, the same way every time."
                },
                media: {
                    src: "https://images.ctfassets.net/27w7hkots21d/6VyyWifqMC7WHz6CCpURQA/9b114b3a274c13e3a331709d3a5d02a7/FD_Slider_Frame_1.png",
                    label: "Ticket intake workflow diagram"
                }
            }, {
                id: "deterministic-ai",
                title: "Deterministic + AI",
                description: "AI handles a single task in a workflow, like writing or summarizing. Deterministic steps handle the rest.",
                workflow: {
                    label: "Deterministic + AI:",
                    title: "Drafted replies",
                    description: "AI writes a response to the actual question instead of a canned auto-reply. Sending it and assigning a rep still run as fixed steps."
                },
                media: {
                    src: "https://images.ctfassets.net/27w7hkots21d/4fTmAKo4hahs6ZKqynSWAn/8e3ea9261839c5f43215c694b9fd8206/FD_Slider_Frame_2.png",
                    label: "Drafted replies workflow diagram"
                }
            }, {
                id: "deterministic-agent",
                title: "Deterministic + agent",
                description: "An embedded agent uses approved tools and instructions to complete multi-step work, then hands it off to deterministic steps.",
                workflow: {
                    label: "Deterministic + agent:",
                    title: "Priority triage",
                    description: "An agent drafts the reply and judges urgency, then hands off — urgent tickets to a rep, routine ones answered and closed."
                },
                media: {
                    src: "https://images.ctfassets.net/27w7hkots21d/1Mj7RRJ2KiP6tz3CjE2Zs0/583d56f184f94c5aa50dbe307a99dbe2/FD_Slider_Frame_3.png",
                    label: "Priority triage workflow diagram"
                }
            }, {
                id: "fully-agentic",
                title: "Fully agentic",
                description: "An agent plans, adapts, and works across tools to achieve your goal, bringing you in for review as needed.",
                workflow: {
                    label: "Fully agentic:",
                    title: "Queue management",
                    description: "An agent works across tickets and emails using your instructions, knowledge, and tools, deciding what to answer and what to escalate."
                },
                media: {
                    src: "https://images.ctfassets.net/27w7hkots21d/44f1RvrhKqQ6vZCWsB4XdF/e59d2418bc8c6c9075664a5050f03193/FD_Slider_Frame_4.png",
                    label: "Queue management workflow diagram"
                }
            }];
            var d = t(76329),
                m = t.n(d);
            let u = [11.33, 37.11, 62.97, 100];

            function _() {
                var e;
                let [i, t] = (0, o.useState)(0), d = (0, o.useRef)(null), _ = (0, o.useCallback)(e => {
                    t(Math.max(0, Math.min(c.length - 1, e)))
                }, []), p = null != (e = u[i]) ? e : 0, h = c[i], w = c.some(e => e.media);
                return (0, a.jsx)("section", {
                    className: m().root,
                    "aria-labelledby": "fluid-determinism-heading",
                    children: (0, a.jsxs)("div", {
                        className: (0, l.A)(m().container, n.Fo.containerXL),
                        children: [(0, a.jsxs)("header", {
                            className: m().header,
                            children: [(0, a.jsx)(n.gN, {
                                className: m().eyebrow,
                                children: (0, a.jsx)("p", {
                                    children: "Adjust automatically"
                                })
                            }), (0, a.jsx)(n.gN, {
                                children: (0, a.jsx)("h2", {
                                    id: "fluid-determinism-heading",
                                    className: m().heading,
                                    children: "The Fluid Determinism difference"
                                })
                            }), (0, a.jsx)(n.gN, {
                                children: (0, a.jsx)("p", {
                                    className: m().intro,
                                    children: "Fluid Determinism is Zapier’s unique approach to cost-effective, reliable AI. You build with natural language; Zapier suggests where to use AI and then adjusts your workflow as it runs—reducing token use for steps that run the same way every time but adding it back when the unexpected happens."
                                })
                            })]
                        }), (0, a.jsxs)("div", {
                            className: m().interactive,
                            children: [(0, a.jsxs)(n.gN, {
                                className: m().sliderRow,
                                children: [(0, a.jsx)("button", {
                                    type: "button",
                                    className: m().sliderArrow,
                                    "aria-label": "Previous agency level",
                                    disabled: 0 === i,
                                    onClick: () => _(i - 1),
                                    children: (0, a.jsx)(s.In, {
                                        name: "arrowSmallLeft",
                                        size: 20,
                                        "aria-hidden": !0
                                    })
                                }), (0, a.jsx)("div", {
                                    className: m().sliderWrap,
                                    children: (0, a.jsxs)("div", {
                                        className: m().trackHitArea,
                                        onPointerDown: function(e) {
                                            if (!d.current) return;
                                            let i = d.current.getBoundingClientRect();

                                            function t(e) {
                                                var t;
                                                let a, r;
                                                return t = (e - i.left) / i.width * 100, a = 0, r = 1 / 0, u.forEach((e, i) => {
                                                    let n = Math.abs(t - e);
                                                    n < r && (r = n, a = i)
                                                }), a
                                            }

                                            function a(e) {
                                                _(t(e.clientX))
                                            }
                                            document.addEventListener("pointermove", a), document.addEventListener("pointerup", function e(i) {
                                                _(t(i.clientX)), document.removeEventListener("pointermove", a), document.removeEventListener("pointerup", e)
                                            }), _(t(e.clientX))
                                        },
                                        children: [(0, a.jsxs)("div", {
                                            className: m().track,
                                            ref: d,
                                            children: [(0, a.jsx)("div", {
                                                className: m().trackFill,
                                                style: {
                                                    "--fill": "".concat(p, "%")
                                                },
                                                "aria-hidden": !0
                                            }), c.map((e, t) => {
                                                var r;
                                                let n = null != (r = u[t]) ? r : 0;
                                                return (0, a.jsx)("button", {
                                                    type: "button",
                                                    className: (0, l.A)(m().trackStop, t <= i && m().trackStopActive),
                                                    style: {
                                                        left: "".concat(n, "%")
                                                    },
                                                    "aria-label": "Go to ".concat(e.title),
                                                    "aria-current": t === i ? "step" : void 0,
                                                    onClick: e => {
                                                        e.stopPropagation(), _(t)
                                                    }
                                                }, e.id)
                                            })]
                                        }), (0, a.jsx)("div", {
                                            className: m().thumb,
                                            style: {
                                                left: "".concat(p, "%")
                                            },
                                            role: "slider",
                                            tabIndex: 0,
                                            "aria-valuemin": 0,
                                            "aria-valuemax": c.length - 1,
                                            "aria-valuenow": i,
                                            "aria-valuetext": h.title,
                                            onKeyDown: function(e) {
                                                switch (e.key) {
                                                    case "ArrowLeft":
                                                    case "ArrowDown":
                                                        e.preventDefault(), _(i - 1);
                                                        break;
                                                    case "ArrowRight":
                                                    case "ArrowUp":
                                                        e.preventDefault(), _(i + 1);
                                                        break;
                                                    case "Home":
                                                        e.preventDefault(), _(0);
                                                        break;
                                                    case "End":
                                                        e.preventDefault(), _(c.length - 1)
                                                }
                                            }
                                        })]
                                    })
                                }), (0, a.jsx)("button", {
                                    type: "button",
                                    className: m().sliderArrow,
                                    "aria-label": "Next agency level",
                                    disabled: i === c.length - 1,
                                    onClick: () => _(i + 1),
                                    children: (0, a.jsx)(s.In, {
                                        name: "arrowSmallRight",
                                        size: 20,
                                        "aria-hidden": !0
                                    })
                                })]
                            }), (0, a.jsx)("div", {
                                className: m().cards,
                                role: "tablist",
                                "aria-label": "Agency levels",
                                children: c.map((e, t) => {
                                    let r = t === i;
                                    return (0, a.jsxs)("button", {
                                        type: "button",
                                        role: "tab",
                                        id: "fluid-determinism-tab-".concat(e.id),
                                        "aria-selected": r,
                                        "aria-controls": "fluid-determinism-panel-".concat(e.id),
                                        className: (0, l.A)(m().card, r && m().cardActive),
                                        onClick: () => _(t),
                                        children: [(0, a.jsx)("h3", {
                                            className: m().cardTitle,
                                            children: e.title
                                        }), (0, a.jsx)("p", {
                                            className: m().cardDescription,
                                            children: e.description
                                        })]
                                    }, e.id)
                                })
                            })]
                        }), (0, a.jsxs)("div", {
                            className: m().detail,
                            id: "fluid-determinism-panel-".concat(h.id),
                            role: "tabpanel",
                            "aria-labelledby": "fluid-determinism-tab-".concat(h.id),
                            children: [(0, a.jsx)("div", {
                                className: (0, l.A)(m().media, w && m().mediaWithImage),
                                "data-step": h.id,
                                ...!h.media && {
                                    "aria-label": "".concat(h.workflow.title, " workflow diagram")
                                },
                                children: w ? c.map((e, t) => e.media ? (0, a.jsx)(r.G, {
                                    src: e.media.src,
                                    alt: e.media.label,
                                    width: 1e3,
                                    height: 1e3,
                                    className: (0, l.A)(m().mediaImage, t === i && m().mediaImageActive),
                                    "aria-hidden": t !== i
                                }, e.id) : null) : (0, a.jsxs)("span", {
                                    className: m().mediaPlaceholder,
                                    children: [h.workflow.title, " workflow diagram"]
                                })
                            }), (0, a.jsx)("div", {
                                className: m().detailCopy,
                                children: (0, a.jsxs)("div", {
                                    className: m().detailCopyInner,
                                    children: [(0, a.jsx)("p", {
                                        className: m().workflowLabel,
                                        children: h.workflow.label
                                    }), (0, a.jsx)("h3", {
                                        className: m().workflowTitle,
                                        children: h.workflow.title
                                    }), (0, a.jsx)("p", {
                                        className: m().workflowDescription,
                                        children: h.workflow.description
                                    })]
                                }, h.id)
                            })]
                        })]
                    })
                })
            }
        }
    }
]);