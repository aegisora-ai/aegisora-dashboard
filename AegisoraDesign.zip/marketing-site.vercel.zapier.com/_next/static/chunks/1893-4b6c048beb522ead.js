(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1893], {
        2941: (e, i, t) => {
            "use strict";
            t.d(i, {
                g: () => G,
                q: () => U
            });
            var s = t(11002);

            function l(e) {
                return "hubSpotForm" === e.sys.contentType.sys.id
            }
            var d = t(52986),
                n = t(12985),
                r = t(37327),
                a = t(45277),
                o = t(98159),
                f = t(49657),
                u = t(96091),
                c = t(92594),
                m = t(84420);

            function g(e) {
                let {
                    entry: i
                } = e, t = Array.isArray(i.fields.defaultValues) ? Object.fromEntries(i.fields.defaultValues.map(e => {
                    let {
                        field: i,
                        value: t
                    } = e;
                    return [i, t]
                })) : void 0;
                return (0, s.jsx)(u.ar, {
                    portalID: i.fields.portalID,
                    formID: i.fields.formID,
                    heading: i.fields.heading,
                    bindings: i.fields.bindings,
                    defaultValues: t,
                    skeletonRows: i.fields.skeletonRows
                })
            }
            var b = t(34139),
                p = t(5515),
                h = t(52504),
                v = t(90935),
                y = t(35807),
                x = t.n(y),
                j = t(32527);

            function _(e) {
                let {
                    data: i,
                    id: t,
                    heading: l
                } = e;
                if (!(null == i ? void 0 : i.length)) return null;
                let [d = [], ...n] = i, r = Array.from({
                    length: Math.max(d.length, ...n.map(e => e.length))
                }), a = l && t ? "".concat(t, "-heading") : void 0;
                return (0, s.jsxs)("div", {
                    className: x().root,
                    id: t,
                    children: [l ? (0, s.jsx)("h2", {
                        id: a,
                        className: (0, v.A)(x().heading, u.Fo.headingLG, u.Fo.textBalance, u.Fo.textCenter),
                        children: l
                    }) : null, (0, s.jsx)(j.TableScroll, {
                        ariaLabel: l || "Table",
                        labelledBy: a,
                        children: (0, s.jsxs)("table", {
                            className: (0, v.A)(x().table, u.Fo.bodySM, u.Fo.textNeutral700),
                            children: [(0, s.jsx)("thead", {
                                children: (0, s.jsx)("tr", {
                                    children: r.map((e, i) => {
                                        var t;
                                        return (0, s.jsx)("th", {
                                            scope: "col",
                                            className: (0, v.A)(u.Fo.fontSemibold, u.Fo.uppercase, u.Fo.textNeutral700),
                                            children: null != (t = d[i]) ? t : ""
                                        }, i)
                                    })
                                })
                            }), (0, s.jsx)("tbody", {
                                children: n.map((e, i) => (0, s.jsx)("tr", {
                                    children: r.map((i, t) => {
                                        var l, d;
                                        return 0 === t ? (0, s.jsx)("th", {
                                            scope: "row",
                                            children: null != (l = e[t]) ? l : ""
                                        }, t) : (0, s.jsx)("td", {
                                            children: null != (d = e[t]) ? d : ""
                                        }, t)
                                    })
                                }, i))
                            })]
                        })
                    })]
                })
            }

            function w(e) {
                return "signUpForm" === e.sys.contentType.sys.id
            }
            var T = t(84732),
                k = t(25794),
                A = t(58311),
                I = t.n(A),
                N = t(75566),
                S = t(18213);

            function U(e, i) {
                return "card" === e.sys.contentType.sys.id ? (0, s.jsx)(u.Zp, {
                    heading: e.fields.heading,
                    body: e.fields.body,
                    href: e.fields.href,
                    cta: e.fields.cta,
                    appIcons: (0, S.g7)(e.fields.appIcons),
                    background: e.fields.background,
                    surface: i,
                    icon: e.fields.icon ? {
                        name: e.fields.icon,
                        color: e.fields.iconColor
                    } : void 0,
                    image: e.fields.image ? (0, s.jsx)(b.G, {
                        asset: e.fields.image,
                        alt: (0, p.O)(e.fields.image)
                    }) : void 0
                }) : l(e) ? (0, s.jsx)(g, {
                    entry: e
                }) : (0, d.N)(e) ? (0, s.jsx)(u.B0, {
                    heading: e.fields.heading,
                    body: e.fields.body,
                    href: e.fields.href,
                    cta: e.fields.cta,
                    surface: i,
                    icon: e.fields.icon ? {
                        name: e.fields.icon,
                        color: e.fields.iconColor
                    } : void 0
                }) : "stat" === e.sys.contentType.sys.id ? (0, s.jsx)(u.ro, {
                    figure: e.fields.figure,
                    caption: e.fields.caption
                }) : (0, n.s)(e) ? (0, s.jsx)(u.Gm, {
                    quote: e.fields.quote,
                    author: e.fields.authorName ? {
                        name: e.fields.authorName,
                        title: e.fields.authorTitle,
                        avatar: e.fields.authorAvatar && (0, s.jsx)(b.G, {
                            asset: e.fields.authorAvatar,
                            alt: e.fields.authorName,
                            width: 48,
                            height: 48
                        })
                    } : void 0,
                    logo: e.fields.logo && (0, s.jsx)(b.G, {
                        asset: e.fields.logo,
                        decorative: !0
                    })
                }) : "youtubeEmbed" === e.sys.contentType.sys.id ? (0, s.jsx)(N.T, {
                    title: e.fields.title,
                    videoID: e.fields.videoID
                }) : "planCard" === e.sys.contentType.sys.id ? (0, s.jsx)(u.Mt, {
                    badgeText: e.fields.badgeText,
                    title: e.fields.title,
                    features: e.fields.features,
                    background: e.fields.background,
                    cta: e.fields.ctaText ? {
                        text: e.fields.ctaText,
                        href: e.fields.ctaUrl,
                        hasArrow: e.fields.ctaHasArrow,
                        variant: e.fields.ctaVariant
                    } : void 0
                }) : G(e)
            }

            function E(e) {
                var i, t, l, d, n, r;
                return (0, s.jsx)(u.Ce, {
                    title: e.fields.title,
                    src: e.fields.url || (null == (l = e.fields.asset) || null == (t = l.fields) || null == (i = t.file) ? void 0 : i.url) || "",
                    poster: e.fields.posterURL || (null == (r = e.fields.posterAsset) || null == (n = r.fields) || null == (d = n.file) ? void 0 : d.url),
                    controls: e.fields.controls,
                    hideStartButton: e.fields.hideStartButton,
                    autoPlay: e.fields.autoPlay,
                    loop: e.fields.loop,
                    muted: e.fields.muted,
                    disableEvents: e.fields.disableEvents
                })
            }

            function G(e) {
                var i, t, d, n, y, x, j;
                let A = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    N = !1 === A.animate ? { ...e,
                        fields: { ...e.fields,
                            animate: !1
                        }
                    } : e;
                if ("arcadeEmbed" === N.sys.contentType.sys.id) return (0, s.jsx)(m.ArcadeEmbed, {
                    flowId: N.fields.flowId,
                    title: N.fields.title
                });
                if ("cta" === N.sys.contentType.sys.id) {
                    let e = null == (t = N.fields.backgroundImage) || null == (i = t.fields.file) ? void 0 : i.url,
                        l = e && /^\/\/[a-z0-9]/i.test(e) ? "https:".concat(e) : void 0;
                    return (0, s.jsx)(u.J0, {
                        name: N.fields.name,
                        heading: N.fields.heading,
                        subheading: N.fields.subheading,
                        buttons: N.fields.buttons,
                        background: N.fields.background,
                        backgroundImage: l,
                        animate: N.fields.animate,
                        paddingTop: N.fields.paddingTop,
                        paddingBottom: N.fields.paddingBottom,
                        id: N.fields.id
                    })
                }
                if ("faq" === N.sys.contentType.sys.id) return (0, s.jsx)(u.Tw, {
                    name: N.fields.name,
                    heading: N.fields.heading,
                    items: N.fields.items,
                    animate: N.fields.animate,
                    id: N.fields.id
                });
                if ("featuredTestimonial" === N.sys.contentType.sys.id) return (0, s.jsx)(u.a$, {
                    quote: N.fields.quote,
                    author: {
                        name: N.fields.name,
                        title: N.fields.title
                    },
                    background: N.fields.background,
                    href: N.fields.href,
                    cta: N.fields.cta,
                    animate: N.fields.animate,
                    stats: Array.isArray(N.fields.stats) ? N.fields.stats : void 0,
                    id: N.fields.id,
                    media: N.fields.image ? (0, s.jsx)(b.G, {
                        asset: N.fields.image,
                        alt: (0, p.O)(N.fields.image)
                    }) : void 0
                });
                if ("hero" === N.sys.contentType.sys.id) return (0, s.jsx)(u.lq, {
                    name: N.fields.name,
                    heading: N.fields.heading,
                    subheading: N.fields.subheading,
                    buttons: N.fields.buttons,
                    background: N.fields.background,
                    alignment: N.fields.alignment,
                    eyebrow: function(e) {
                        if (e.fields.eyebrowText || e.fields.eyebrowBadge || e.fields.eyebrowImage) return {
                            text: e.fields.eyebrowText,
                            badge: e.fields.eyebrowBadge,
                            image: e.fields.eyebrowImage && (0, s.jsx)(b.G, {
                                asset: e.fields.eyebrowImage,
                                alt: (0, p.O)(e.fields.eyebrowImage)
                            })
                        }
                    }(N),
                    media: function(e) {
                        var i, t, d, n, r, a, o, f, c, m;
                        if (e.fields.video) return n = e.fields.video, (0, s.jsx)(u.Ce, {
                            title: n.fields.title,
                            src: n.fields.url || (null == (o = n.fields.asset) || null == (a = o.fields) || null == (r = a.file) ? void 0 : r.url) || "",
                            poster: n.fields.posterURL || (null == (m = n.fields.posterAsset) || null == (c = m.fields) || null == (f = c.file) ? void 0 : f.url),
                            controls: n.fields.controls,
                            hideStartButton: n.fields.hideStartButton,
                            autoPlay: n.fields.autoPlay,
                            loop: n.fields.loop,
                            muted: n.fields.muted,
                            disableEvents: n.fields.disableEvents
                        });
                        if (e.fields.videoUrl) return (0, s.jsx)(u.Ce, {
                            src: e.fields.videoUrl,
                            title: null != (d = e.fields.videoTitle) ? d : e.fields.heading,
                            controls: "native"
                        });
                        if (e.fields.gifUrl) return /\.(mp4|webm|mov|m4v)(\?|$)/i.test(e.fields.gifUrl) ? (0, s.jsx)(u.Gs, {
                            src: e.fields.gifUrl
                        }) : (0, s.jsx)(b.G, {
                            src: e.fields.gifUrl,
                            decorative: !0,
                            priority: !0
                        });
                        if (!e.fields.image && !e.fields.form) return;
                        let h = e.fields.form && l(e.fields.form) ? (0, s.jsx)(g, {
                            entry: e.fields.form
                        }) : e.fields.form && w(e.fields.form) && (0, s.jsx)(k.SignUpForm, {});
                        if (h && (null == (t = e.fields.image) || null == (i = t.fields.file) ? void 0 : i.url)) {
                            let i = (0, T.A)(e.fields.image.fields.file.url);
                            return (0, s.jsx)("div", {
                                className: (0, v.A)(I().formBackground, e.fields.form && w(e.fields.form) && I().signUp),
                                style: {
                                    backgroundImage: i
                                },
                                children: h
                            })
                        }
                        return h || (0, s.jsx)(b.G, {
                            asset: e.fields.image,
                            alt: (0, p.O)(e.fields.image),
                            priority: !0
                        })
                    }(N),
                    id: N.fields.id,
                    features: Array.isArray(N.fields.features) ? N.fields.features : void 0,
                    animate: N.fields.animate
                });
                if ((0, r.i)(N)) return (0, s.jsx)(b.G, {
                    asset: N.fields.asset,
                    alt: (0, p.O)(N.fields.asset)
                });
                if ("logoBar" === N.sys.contentType.sys.id) return (0, s.jsx)(u.d1, {
                    logos: N.fields.logos.map(e => {
                        var i, t, s, l;
                        return {
                            src: null != (s = null == e || null == (i = e.fields.file) ? void 0 : i.url) ? s : "",
                            alt: null != (l = null == e || null == (t = e.fields.file) ? void 0 : t.fileName) ? l : ""
                        }
                    }),
                    eyebrow: N.fields.showEyebrow ? "Trusted by 3.4 million companies" : void 0,
                    ticker: N.fields.ticker,
                    animate: N.fields.animate,
                    id: N.fields.id
                });
                if ("prose" === N.sys.contentType.sys.id) return (0, s.jsx)(u.s7, {
                    heading: N.fields.heading,
                    background: N.fields.background,
                    alignment: N.fields.alignment,
                    differentiateLinks: N.fields.differentiateLinks,
                    width: N.fields.width,
                    animate: N.fields.animate,
                    id: N.fields.id,
                    children: (0, s.jsx)(h.G, {
                        document: N.fields.content,
                        disableDefaultStyles: !0
                    })
                });
                if ("river" === N.sys.contentType.sys.id) {
                    let e;
                    return N.fields.video ? e = E(N.fields.video) : N.fields.videoUrl ? e = (0, s.jsx)(u.Ce, {
                        src: N.fields.videoUrl,
                        title: null != (n = N.fields.videoTitle) ? n : N.fields.heading,
                        controls: "native"
                    }) : N.fields.gifUrl ? e = /\.(mp4|webm|mov|m4v)(\?|$)/i.test(N.fields.gifUrl) ? (0, s.jsx)(u.Gs, {
                        src: N.fields.gifUrl
                    }) : (0, s.jsx)(b.G, {
                        src: N.fields.gifUrl,
                        decorative: !0
                    }) : N.fields.image && (e = (0, s.jsx)(b.G, {
                        asset: N.fields.image,
                        alt: (0, p.O)(N.fields.image)
                    })), (0, s.jsx)(u.jF, {
                        name: N.fields.name,
                        heading: N.fields.heading,
                        body: N.fields.body,
                        href: N.fields.href,
                        cta: N.fields.cta,
                        buttons: null == (d = N.fields.buttons) ? void 0 : d.filter(e => !!e.text).map(e => ({
                            text: e.text,
                            href: e.href,
                            variant: e.variant
                        })),
                        reversed: N.fields.reversed,
                        background: N.fields.background,
                        animate: N.fields.animate,
                        id: N.fields.id,
                        media: e
                    })
                }
                if ("riverAccordion" === N.sys.contentType.sys.id) return (0, s.jsx)(u.vR, {
                    reversed: N.fields.reversed,
                    animate: N.fields.animate,
                    id: N.fields.id,
                    items: Array.isArray(N.fields.items) ? N.fields.items.map(e => ({
                        heading: e.heading,
                        body: e.body,
                        href: e.href,
                        cta: e.cta,
                        media: function(e) {
                            if (e.video) {
                                var i, t;
                                return (0, s.jsx)(u.Ce, {
                                    title: null != (t = null != (i = e.video.title) ? i : e.heading) ? t : "",
                                    src: e.video.url,
                                    poster: e.video.posterURL,
                                    controls: "native",
                                    autoPlay: e.video.autoPlay,
                                    loop: e.video.loop,
                                    muted: e.video.muted
                                })
                            }
                            return e.image ? (0, s.jsx)(b.G, {
                                src: e.image.url,
                                alt: e.image.alt
                            }) : null
                        }(e)
                    })) : []
                });
                if ((0, a.S)(N)) return function(e) {
                    var i, t, l;
                    let d = null == (t = e.fields.backgroundImage) || null == (i = t.fields.file) ? void 0 : i.url,
                        n = d && /^\/\/[a-z0-9]/i.test(d) ? "https:".concat(d) : void 0;
                    return (0, s.jsx)(u.wn, {
                        heading: e.fields.heading,
                        subheading: e.fields.subheading,
                        eyebrow: e.fields.eyebrow,
                        layout: e.fields.layout,
                        background: e.fields.background,
                        backgroundImage: n,
                        alignment: e.fields.alignment,
                        paddingTop: e.fields.paddingTop,
                        paddingBottom: e.fields.paddingBottom,
                        animate: e.fields.animate,
                        id: e.fields.id,
                        buttons: e.fields.buttons,
                        buttonPlacement: e.fields.buttonPlacement,
                        children: null == (l = e.fields.children) ? void 0 : l.map(i => {
                            if (!i) return null;
                            let t = U(i, e.fields.background);
                            return t ? (0, s.jsx)(c.Fragment, {
                                children: t
                            }, i.sys.id) : null
                        })
                    })
                }(N);
                if ((0, o.G)(N)) {
                    let e = null != (x = null == (y = N.fields.tabs) ? void 0 : y.filter(e => !!e).map(e => ({
                        text: e.fields.tabTitle,
                        content: e.fields.content ? G(e.fields.content) : null
                    }))) ? x : [];
                    return (0, s.jsx)(u.qF, {
                        name: N.fields.internalTitle,
                        heading: N.fields.heading,
                        subheading: N.fields.subheading,
                        background: N.fields.background,
                        tabs: e,
                        id: N.fields.id
                    })
                }
                if ("table" === N.sys.contentType.sys.id) {
                    let e = (null != (j = N.fields.rows) ? j : []).map(e => {
                        var i;
                        return (null != (i = e.cells) ? i : []).map(e => ({
                            content: e.content,
                            icon: e.icon,
                            color: e.color,
                            tooltip: e.tooltip,
                            isHeader: e.isHeader,
                            href: e.href,
                            openInNewTab: e.openInNewTab,
                            background: e.background
                        }))
                    });
                    return (0, s.jsx)(u.XI, {
                        headers: N.fields.headers,
                        rows: e,
                        valueAlignment: N.fields.valueAlignment,
                        background: N.fields.background
                    })
                }
                return "gridTable" === N.sys.contentType.sys.id ? (0, s.jsx)(_, {
                    data: function(e) {
                        let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "	";
                        if (!e) return [];
                        let t = e.replace(/\r\n?/g, "\n").replace(/\n+$/, "");
                        return "" === t ? [] : t.split("\n").map(e => e.split(i))
                    }(N.fields.data),
                    id: N.fields.id,
                    heading: N.fields.heading
                }) : (0, f.c)(N) ? E(N) : null
            }
        },
        5515: (e, i, t) => {
            "use strict";

            function s(e) {
                var i, t, s;
                if (e) {
                    if ("fields" in e) {
                        let s = null == (i = e.fields.title) ? void 0 : i.trim(),
                            l = null == (t = e.fields.description) ? void 0 : t.trim();
                        return s || l || void 0
                    }
                    if ("url" in e) return (null == (s = e.description) ? void 0 : s.trim()) || void 0
                }
            }
            t.d(i, {
                O: () => s
            })
        },
        12985: (e, i, t) => {
            "use strict";

            function s(e) {
                return "testimonial" === e.sys.contentType.sys.id
            }
            t.d(i, {
                s: () => s
            })
        },
        18213: (e, i, t) => {
            "use strict";

            function s(e) {
                if (!Array.isArray(e)) return;
                let i = e.filter(e => {
                    var i;
                    return null == e || null == (i = e.icon) ? void 0 : i.url
                }).map(e => {
                    var i;
                    return {
                        image: {
                            src: e.icon.url.startsWith("//") ? "https:".concat(e.icon.url) : e.icon.url,
                            alt: null != (i = e.icon.description) ? i : ""
                        },
                        ...e.href && {
                            href: e.href
                        }
                    }
                });
                return i.length > 0 ? i : void 0
            }

            function l(e) {
                var i;
                return {
                    heading: null != (i = e.fields.heading) ? i : "",
                    subheading: e.fields.subheading,
                    ...e.fields.link && {
                        link: e.fields.link
                    },
                    appIcons: e.fields.appIcons
                }
            }

            function d(e) {
                let i = s(e.fields.appIcons);
                return {
                    heading: e.fields.heading,
                    body: e.fields.body,
                    href: e.fields.href,
                    cta: e.fields.cta,
                    appIcons: i
                }
            }
            t.d(i, {
                DV: () => l,
                g7: () => s,
                zR: () => d
            })
        },
        25317: e => {
            e.exports = {
                root: "YouTubeEmbed_root__NqV4C",
                iframe: "YouTubeEmbed_iframe__Dvwuf",
                overlay: "YouTubeEmbed_overlay__fM3i2",
                thumbnail: "YouTubeEmbed_thumbnail__DeTeP",
                icon: "YouTubeEmbed_icon__fhXI3"
            }
        },
        25794: (e, i, t) => {
            "use strict";
            t.r(i), t.d(i, {
                SignUpForm: () => o
            });
            var s = t(11002),
                l = t(92629),
                d = t(96091),
                n = t(90935),
                r = t(67949),
                a = t.n(r);

            function o(e) {
                return (0, s.jsx)("div", {
                    className: (0, n.A)("fs-exclude", a().root, d.Fo.bgNeutral100, d.Fo.containerXS),
                    children: (0, s.jsx)(l.XS, {
                        googleCaptchaSiteKey: "6Lda9zoUAAAAAOwhmrgGDo_l4zcHOYWujO9Q_qnS",
                        googleSSOEnabled: e.showGoogleSignUp,
                        hideFieldsUntilFocus: !0
                    })
                })
            }
        },
        32527: (e, i, t) => {
            "use strict";
            t.d(i, {
                TableScroll: () => r
            });
            var s = t(11002),
                l = t(92594),
                d = t(35807),
                n = t.n(d);

            function r(e) {
                let {
                    children: i,
                    ariaLabel: t,
                    labelledBy: d
                } = e, r = (0, l.useRef)(null), [a, o] = (0, l.useState)({
                    start: !1,
                    end: !1
                }), f = (0, l.useCallback)(() => {
                    let e = r.current;
                    if (!e) return;
                    let i = e.scrollWidth - e.clientWidth;
                    o({
                        start: e.scrollLeft > 1,
                        end: e.scrollLeft < i - 1
                    })
                }, []);
                (0, l.useEffect)(() => {
                    f();
                    let e = r.current;
                    if (!e || "undefined" == typeof ResizeObserver) return;
                    let i = new ResizeObserver(f);
                    return i.observe(e), () => i.disconnect()
                }, [f]);
                let u = a.start || a.end;
                return (0, s.jsx)("div", {
                    className: n()["scroll-wrap"],
                    "data-overflow-start": a.start || void 0,
                    "data-overflow-end": a.end || void 0,
                    children: (0, s.jsx)("div", {
                        ref: r,
                        className: n().scroll,
                        role: u ? "region" : void 0,
                        "aria-labelledby": u ? d : void 0,
                        "aria-label": u && !d ? t : void 0,
                        tabIndex: u ? 0 : void 0,
                        onScroll: f,
                        children: i
                    })
                })
            }
        },
        35807: e => {
            e.exports = {
                root: "GridTable_root__fnmtM",
                heading: "GridTable_heading__Su3jl",
                "scroll-wrap": "GridTable_scroll-wrap__sisDu",
                scroll: "GridTable_scroll__p8Nnk",
                table: "GridTable_table__p_DEn"
            }
        },
        37327: (e, i, t) => {
            "use strict";

            function s(e) {
                return "image" === e.sys.contentType.sys.id
            }
            t.d(i, {
                i: () => s
            })
        },
        45277: (e, i, t) => {
            "use strict";

            function s(e) {
                return "section" === e.sys.contentType.sys.id
            }
            t.d(i, {
                S: () => s
            })
        },
        47739: e => {
            e.exports = {
                wrapper: "ArcadeEmbed_wrapper__toiPJ",
                iframe: "ArcadeEmbed_iframe__ZZsxV"
            }
        },
        49657: (e, i, t) => {
            "use strict";

            function s(e) {
                return "video" === e.sys.contentType.sys.id
            }
            t.d(i, {
                c: () => s
            })
        },
        52986: (e, i, t) => {
            "use strict";

            function s(e) {
                return "pillar" === e.sys.contentType.sys.id
            }
            t.d(i, {
                N: () => s
            })
        },
        58311: e => {
            e.exports = {
                formBackground: "Page_formBackground__3gcBB",
                signUp: "Page_signUp__RJAW2"
            }
        },
        67949: e => {
            e.exports = {
                root: "SignUpForm_root__pC57O"
            }
        },
        75566: (e, i, t) => {
            "use strict";
            t.d(i, {
                T: () => s.YouTubeEmbed
            });
            var s = t(91786)
        },
        84420: (e, i, t) => {
            "use strict";
            t.d(i, {
                ArcadeEmbed: () => a
            });
            var s = t(11002),
                l = t(96091),
                d = t(92594),
                n = t(47739),
                r = t.n(n);

            function a(e) {
                let {
                    flowId: i,
                    title: t,
                    className: n
                } = e, a = (0, d.useRef)(null), o = (0, d.useRef)(null), {
                    emitUserInteractionEvent: f
                } = (0, l.z1)(), {
                    isActive: u
                } = (0, l.Jn)(), c = (0, d.useRef)(!1);
                (0, d.useEffect)(() => {
                    let e = a.current;
                    if (!e) return;
                    let t = new IntersectionObserver(e => {
                        let [t] = e;
                        t.isIntersecting && !c.current && (c.current = !0, f({
                            event_action: "view",
                            interaction_name: "arcade_embed_viewed",
                            custom_tracking_fields: {
                                flow_id: i
                            }
                        }))
                    }, {
                        threshold: .5
                    });
                    return t.observe(e), () => t.disconnect()
                }, [i, f]), (0, d.useEffect)(() => {
                    if (!u) {
                        var e, i;
                        null == (i = o.current) || null == (e = i.contentWindow) || e.postMessage({
                            event: "pause"
                        }, "*")
                    }
                }, [u]);
                let m = "https://demo.arcade.software/".concat(i, "?embed&embed_mobile=tab&embed_desktop=inline&show_copy_link=true");
                return (0, s.jsx)("div", {
                    ref: a,
                    className: n,
                    children: (0, s.jsx)("div", {
                        className: r().wrapper,
                        children: (0, s.jsx)("iframe", {
                            ref: o,
                            className: r().iframe,
                            src: m,
                            title: null != t ? t : "Arcade demo",
                            loading: "lazy",
                            allowFullScreen: !0,
                            allow: "clipboard-write"
                        })
                    })
                })
            }
        },
        84732: (e, i, t) => {
            "use strict";

            function s(e) {
                let {
                    quality: i = 80,
                    formats: t = ["avif", "webp"]
                } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, s = e;
                s.startsWith("//") && (s = "https:".concat(s));
                let l = new URL(s);
                l.searchParams.set("q", String(i));
                let d = l.toString();
                return "image-set(".concat(t.map(e => 'url("'.concat(d, "&fm=").concat(e, '") type("image/').concat(e, '")')).join(", "), ")")
            }

            function l(e) {
                return e.startsWith("https://images.ctfassets.net/")
            }
            t.d(i, {
                A: () => s,
                X: () => l
            })
        },
        91786: (e, i, t) => {
            "use strict";
            t.r(i), t.d(i, {
                YouTubeEmbed: () => f
            });
            var s = t(11002),
                l = t(96091),
                d = t(7151),
                n = t(90935),
                r = t(92594),
                a = t(25317),
                o = t.n(a);

            function f(e) {
                let i = "https://www.youtube-nocookie.com/embed/".concat(e.videoID, "?rel=0&modestbranding=1&autoplay=1"),
                    t = "https://img.youtube.com/vi/".concat(e.videoID, "/maxresdefault.jpg"),
                    [a, f] = (0, r.useState)(!1),
                    {
                        emitUserInteractionEvent: u
                    } = (0, l.z1)();
                return (0, s.jsx)("div", {
                    className: (0, n.A)(o().root, e.className),
                    children: a ? (0, s.jsx)("iframe", {
                        className: o().iframe,
                        src: i,
                        title: e.title,
                        allow: "encrypted-media; picture-in-picture",
                        loading: "lazy",
                        allowFullScreen: !0
                    }) : (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("img", {
                            className: o().thumbnail,
                            src: t,
                            alt: ""
                        }), (0, s.jsx)("button", {
                            type: "button",
                            className: o().overlay,
                            "aria-label": "Play video".concat(e.title ? ": ".concat(e.title) : ""),
                            onClick: () => {
                                f(!0), u({
                                    event_action: "click",
                                    interaction_name: "youtube_embed_played",
                                    custom_tracking_fields: {
                                        video_id: e.videoID
                                    }
                                })
                            },
                            children: (0, s.jsx)("div", {
                                className: o().icon,
                                children: (0, s.jsx)(d.In, {
                                    name: "actionPlayFill",
                                    size: 32,
                                    "aria-label": "Play video"
                                })
                            })
                        })]
                    })
                })
            }
        },
        98159: (e, i, t) => {
            "use strict";

            function s(e) {
                return "tabbedSection" === e.sys.contentType.sys.id
            }
            t.d(i, {
                G: () => s
            })
        },
        98457: (e, i, t) => {
            "use strict";
            t.d(i, {
                LivePreviewProvider: () => d
            });
            var s = t(11002),
                l = t(38576);

            function d(e) {
                return (0, s.jsx)(l.UR, {
                    locale: "en-US",
                    targetOrigin: "https://app.contentful.com",
                    enableLiveUpdates: !0,
                    children: e.children
                })
            }
        }
    }
]);