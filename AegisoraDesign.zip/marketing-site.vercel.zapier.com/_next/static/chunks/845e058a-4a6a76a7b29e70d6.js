"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1805], {
        92629: (e, t, r) => {
            r.d(t, {
                XS: () => ek
            });
            var i = r(77162),
                a = r(242),
                n = r(78687),
                o = r(93461),
                s = r(82705),
                l = r(72437),
                c = r(95245),
                d = r(92594),
                u = r(21748),
                m = r(13885),
                p = r(95251),
                h = r(320);
            r(47655);
            var f = r(91384),
                g = r(94481),
                _ = r(7151),
                y = r(5519),
                w = r(7969),
                S = r.n(w),
                b = r(99910),
                v = r.n(b),
                C = r(76909),
                I = r.n(C);

            function N({
                signupFunnel: e,
                signupType: t,
                selectedApis: r
            }) {
                let i = "undefined" != typeof window ? window.location.href : "server-side";
                try {
                    return (0, s.emit)({
                        system_name: "identity",
                        timestamp_ms: new Date().getTime(),
                        absolute_url: window.location.toString(),
                        referrer: document.referrer,
                        signup_funnel: e,
                        signup_type: t,
                        selected_apis: r instanceof Array ? r.join(",") : r,
                        signup_location: i
                    }, "web_analytics.tracking.user_interaction.SignupUserInteractionEvent")
                } catch (e) {
                    (0, l.Cp)(e, {
                        tags: {
                            type: "dispatchSignupUserInteractionEvent"
                        }
                    })
                }
            }
            let x = {
                "facebook-sso": "facebook_sso",
                sso: "sso",
                "flab-abs": "flab_abs",
                direct: "direct",
                "flab-sso": "flab_sso",
                "google-one-tap": "google_one_tap",
                "google-sso": "google_sso",
                "microsoft-sso": "microsoft_sso"
            };

            function Y({
                event_action: e,
                destination_url_address: t,
                interaction_goal: r,
                interaction_name: i,
                custom_tracking_fields: a,
                experiment_flag: n,
                experiment_name: o,
                interaction_raw_text: c,
                node_zap_id: d,
                option_selected: u,
                zap_creation_attempt_id: m,
                session_id: p,
                account_id: h,
                release_id: f,
                visitor_id: g
            }) {
                try {
                    return (0, s.emit)({
                        system_name: "identity",
                        timestamp_ms: new Date().getTime(),
                        absolute_url: window.location.toString(),
                        referrer: document.referrer,
                        account_id: h,
                        node_zap_id: d,
                        zap_creation_attempt_id: m,
                        release_id: f,
                        experiment_flag: n,
                        experiment_name: o,
                        interaction_name: i,
                        interaction_raw_text: c,
                        interaction_goal: r,
                        option_selected: u,
                        event_action: e,
                        destination_url_address: t,
                        custom_tracking_fields: a,
                        session_id: p,
                        visitor_id: g
                    }, "web_analytics.tracking.user_interaction.UserInteractionEvent")
                } catch (e) {
                    (0, l.Cp)(e, {
                        tags: {
                            type: "dispatchUserInteractionEvent"
                        }
                    })
                }
            }
            let D = {
                root: (0, c.AH)("background:", n.Tj.neutral100, ";", ""),
                description: {
                    name: "1fgdcyd",
                    styles: "margin-bottom:24px"
                },
                recaptcha: {
                    name: "1fd7y38",
                    styles: "display:flex;justify-content:center;margin-top:30px"
                }
            };

            function F(e) {
                let {
                    trackEvent: t
                } = (0, m.useTrackingContext)();
                return (0, d.useEffect)(() => {
                    t("signup: captcha rendered"), N({
                        signupFunnel: "signup_captcha_rendered",
                        signupType: "direct"
                    })
                }, []), (0, o.FD)("section", {
                    css: D.root,
                    "data-testid": "auth-captcha",
                    children: [(0, o.Y)("p", {
                        className: `${n.Fo.body} ${n.Fo.textCenter}`,
                        css: D.description,
                        children: "Looks like our robots want to make sure you're not one!"
                    }), (0, o.Y)(u.A, {
                        css: D.recaptcha,
                        sitekey: e.googleCaptchaSiteKey,
                        onChange: e.onCaptchaVerification,
                        onExpired: function() {
                            t("signup: captcha verification failed", {
                                reason: "captcha expired"
                            }), N({
                                signupFunnel: "signup_captcha_verification_failed",
                                signupType: "direct"
                            }), e.onCaptchaExpiration && e.onCaptchaExpiration()
                        }
                    })]
                })
            }

            function k(e) {
                window.location.href = e
            }
            let E = "auth_type",
                R = (0, f.Hy)({
                    afterResponse: [f.cM]
                }),
                U = "Yikes! Something went wrong when trying to sign up. If you keep having trouble, please contact support.",
                O = "partner_quick_account_creations",
                T = function(e) {
                    return e.IS_EMAIL_VERIFICATION_REQUIRED = "IS_EMAIL_VERIFICATION_REQUIRED", e.IS_MISSING_CSRF = "IS_MISSING_CSRF", e.IS_VALID_SIGNUP = "IS_VALID_SIGNUP", e.TRYING_TOO_OFTEN = "TRYING_TOO_OFTEN", e.UNKNOWN_ERROR = "UNKNOWN_ERROR", e
                }({}),
                A = {
                    captcha_required: "captcha",
                    password1: "password"
                };

            function L(e) {
                return ({
                    direct: "email",
                    "google-sso": "google",
                    "facebook-sso": "facebook",
                    "microsoft-sso": "microsoft"
                })[e]
            }

            function M(e) {
                (0, p.o)(E, e, {
                    category: "essential"
                })
            }
            let P = function(e) {
                return e.auto_join = "auto_join", e.invite_only = "invite_only", e
            }({});
            async function j({
                email: e
            }) {
                let t, r, n;
                if (!v()(e)) {
                    let o = await R((0, a.addTruthyParamsToUrl)(i.DS.DOMAIN_DISCOVERY_URL, {
                        email: e
                    }));
                    if (t = o.body ? .account, r = o.body ? .user, null == (n = o.body ? .errors) && o.status > 399) throw "Error occurred calling " + i.DS.DOMAIN_DISCOVERY_URL + " response.status: " + o.status + " response.body: " + o.body
                }
                return {
                    account: t ? {
                        id: t.id,
                        name: t.name,
                        logoUrl: t.logo_url,
                        accessPolicy: t.access_policy,
                        ssoUrl: t.sso_url,
                        hasSamlSso: t.has_saml_sso,
                        domain: e.split("@")[1],
                        isDomainCaptureBlocked: t.is_domain_capture_blocked
                    } : null,
                    user: r ? ? null,
                    errors: n ? ? null
                }
            }
            let G = {
                    email: "",
                    firstName: "",
                    lastName: "",
                    password: ""
                },
                V = {
                    captcha: !1,
                    email: !1,
                    firstName: !1,
                    lastName: !1,
                    password: !1
                };

            function $(e) {
                window.location.href = e
            }
            async function q(e, t, r, n) {
                await B();
                let o = {
                    captcha: e.captcha,
                    email: e.email,
                    first_name: e.firstName,
                    last_name: e.lastName,
                    password: e.password,
                    password1: e.password,
                    selected_apis: r
                };
                e.invitation && (o.invitation = e.invitation), e.userProvisioningMethod === O && (o.user_provisioning_method = O);
                let s = await R(i.DS.SIGNUP_API_URL, {
                        method: "POST",
                        body: o
                    }),
                    l = function(e) {
                        let t = {},
                            r = T.IS_VALID_SIGNUP,
                            a = "";
                        try {
                            let n = e.body.errors;
                            if (e.body ? .requires_email_verification) return {
                                errors: t,
                                redirectUrl: i.DS.VERIFY_EMAIL_URL,
                                type: T.IS_EMAIL_VERIFICATION_REQUIRED
                            };
                            if (e.headers ? .get("content-type") ? .includes("application/json") || (t.error = "It looks like you have cookies disabled", r = T.IS_MISSING_CSRF, a = i.DS.COOKIE_ERROR_URL), 429 === e.status && (t.error = "It looks like you are trying too often. If you’re having trouble, please contact support.", r = T.TRYING_TOO_OFTEN), Array.isArray(n) && n.length > 0) {
                                let i = n[0];
                                if (i && "string" == typeof i && (t.error = i, r === T.IS_VALID_SIGNUP && (r = T.UNKNOWN_ERROR)), i && "object" == typeof i && i ? .message && (t.error = i ? .message, r === T.IS_VALID_SIGNUP && (r = T.UNKNOWN_ERROR)), n.forEach(e => {
                                        if ("string" == typeof e) return;
                                        let r = e ? .fields;
                                        r && r.forEach(e => {
                                            t[A[e.key] || S()(e.key)] = e.message
                                        })
                                    }), 0 === Object.keys(t).length) throw e
                            }
                        } catch (e) {
                            t.error = U, r === T.IS_VALID_SIGNUP && (r = T.UNKNOWN_ERROR)
                        }
                        return {
                            errors: t,
                            redirectUrl: a,
                            type: r
                        }
                    }(s);
                if (l.redirectUrl) {
                    let r = {
                        next: t
                    };
                    l.type === T.IS_EMAIL_VERIFICATION_REQUIRED && (r.email = e.email), n((0, a.addTruthyParamsToUrl)(l.redirectUrl, r))
                }
                return 0 === Object.keys(l.errors || {}).length && M("email"), {
                    didRedirect: !!l.redirectUrl,
                    userId: s ? .body ? .id,
                    ...l
                }
            }

            function H(e) {
                return { ...G,
                    email: e.email || G.email,
                    firstName: e.firstName || G.firstName,
                    lastName: e.lastName || G.lastName,
                    invitation: e.invitation,
                    userProvisioningMethod: e.metadata ? .userProvisioningMethod,
                    skipOnboarding: e.metadata ? .skipOnboarding
                }
            }

            function B() {
                return (0, p.o)(E, "", {
                    category: "essential",
                    expires: new Date(Date.now() - 10)
                }), R(i.DS.LOGOUT_API_URL, {
                    headers: {
                        Accept: "application/json"
                    }
                })
            }
            let z = {
                root: {
                    name: "bjn8wh",
                    styles: "position:relative"
                },
                icon: {
                    name: "1jjdi7g",
                    styles: "display:flex;width:20px;position:absolute;left:16px"
                }
            };

            function Z({
                children: e,
                icon: t,
                ...r
            }) {
                return (0, o.FD)(n.$n, { ...r,
                    variant: "secondary",
                    fullWidth: !0,
                    css: z.root,
                    children: [(0, o.Y)("div", {
                        css: z.icon,
                        children: t
                    }), e]
                })
            }

            function W() {
                return (0, o.FD)("svg", {
                    width: "21",
                    height: "21",
                    viewBox: "0 0 21 21",
                    fill: "none",
                    children: [(0, o.Y)("title", {
                        children: "Continue with SSO logo"
                    }), (0, o.Y)("path", {
                        d: "M10.7715 0.184814C5.26148 0.184814 0.771484 4.67481 0.771484 10.1848C0.771484 13.6648 2.56148 16.7248 5.26148 18.5248L6.47148 15.1848H15.0715L15.5715 16.5648C14.2315 17.5748 12.5715 18.1848 10.7715 18.1848C9.69148 18.1848 8.67148 17.9648 7.73148 17.5848L7.05148 19.4648C8.20148 19.9248 9.45148 20.1848 10.7715 20.1848C16.2815 20.1848 20.7715 15.6948 20.7715 10.1848C20.7715 4.67481 16.2815 0.184814 10.7715 0.184814ZM17.1315 15.0148L16.4715 13.1848H5.07148L4.41148 15.0148C3.38148 13.6648 2.77148 11.9948 2.77148 10.1848C2.77148 5.77481 6.36148 2.18481 10.7715 2.18481C15.1815 2.18481 18.7715 5.77481 18.7715 10.1848C18.7715 11.9948 18.1615 13.6648 17.1315 15.0148Z",
                        fill: n.Tj.neutral800
                    }), (0, o.Y)("path", {
                        d: "M10.7615 4.22485C8.70148 4.22485 7.02148 5.90485 7.02148 7.96485C7.02148 10.0249 8.70148 11.7049 10.7615 11.7049C12.8215 11.7049 14.5015 10.0249 14.5015 7.96485C14.5015 5.90485 12.8215 4.22485 10.7615 4.22485ZM10.7615 9.70485C9.80148 9.70485 9.02148 8.92485 9.02148 7.96485C9.02148 7.00485 9.80148 6.22485 10.7615 6.22485C11.7215 6.22485 12.5015 7.00485 12.5015 7.96485C12.5015 8.92485 11.7215 9.70485 10.7615 9.70485Z",
                        fill: n.Tj.neutral800
                    })]
                })
            }

            function J({
                children: e,
                href: t,
                next: r,
                onTrackSignupConversion: n,
                onTrackSignupIntent: s,
                params: c = {},
                passThrough: u = !1,
                routeTo: m = k,
                shouldOpenInChildWindow: p = !0,
                type: h,
                icon: f = (0, o.Y)(W, {})
            }) {
                let g = (0, a.addParamsToUrl)(t, {
                        in_child_window: p,
                        next: r,
                        ...c
                    }),
                    _ = (0, d.useCallback)(async e => {
                        if (e.origin !== new URL(g, window.location.origin).origin || "string" != typeof e.data) return;
                        let t = {};
                        try {
                            t = JSON.parse(e.data), "string" == typeof t && (t = JSON.parse(t))
                        } catch (t) {
                            (0, l.Cp)(t, {
                                extra: {
                                    eventDataLength: e.data.length
                                }
                            });
                            return
                        }
                        let {
                            nextUrl: r
                        } = t;
                        if (!r) return void(0, l.wd)("SSOButton: Error deciphering next URL from posted window message. nextUrl is empty");
                        let o = (0, a.extractParams)(r);
                        o.new_signup && n && await (0, i.uJ)(Promise.resolve().then(() => n(h, o.customuser_id)).catch(l.Cp), i.qZ), m((0, a.addParamsToUrl)(i.DS.REDIRECT_URL, {
                            next: (0, a.removeParamsFromUrl)(r, ["customuser_id"])
                        }))
                    }, [n, m, g, h]),
                    y = (0, d.useRef)(_);
                (0, d.useEffect)(() => {
                    y.current = _
                }, [_]);
                let w = (0, d.useCallback)(e => {
                    y.current(e)
                }, []);
                (0, d.useEffect)(() => () => {
                    window.removeEventListener("message", w)
                }, [w]);
                let S = (0, d.useCallback)(e => {
                    e.preventDefault();
                    let t = L(h);
                    if (t && M(t), u && r) return void m(r);
                    s && s(h), p ? (window.addEventListener("message", w), window.open(g, "_blank", "noopener,height=600,width=980,resizable=yes,scrollbars=yes")) : m(g)
                }, [r, w, s, u, m, p, g, h]);
                return (0, o.Y)(Z, {
                    href: g,
                    icon: f,
                    onClick: S,
                    children: e
                })
            }

            function K() {
                return (0, o.FD)("svg", {
                    height: "21",
                    preserveAspectRatio: "xMidYMid",
                    viewBox: "0 0 256 262",
                    width: "21",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, o.Y)("title", {
                        children: "Google Logo"
                    }), (0, o.Y)("path", {
                        d: "M255.878 133.451c0-10.734-.871-18.567-2.756-26.69H130.55v48.448h71.947c-1.45 12.04-9.283 30.172-26.69 42.356l-.244 1.622 38.755 30.023 2.685.268c24.659-22.774 38.875-56.282 38.875-96.027",
                        fill: "#4285F4"
                    }), (0, o.Y)("path", {
                        d: "M130.55 261.1c35.248 0 64.839-11.605 86.453-31.622l-41.196-31.913c-11.024 7.688-25.82 13.055-45.257 13.055-34.523 0-63.824-22.773-74.269-54.25l-1.531.13-40.298 31.187-.527 1.465C35.393 231.798 79.49 261.1 130.55 261.1",
                        fill: "#34A853"
                    }), (0, o.Y)("path", {
                        d: "M56.281 156.37c-2.756-8.123-4.351-16.827-4.351-25.82 0-8.994 1.595-17.697 4.206-25.82l-.073-1.73L15.26 71.312l-1.335.635C5.077 89.644 0 109.517 0 130.55s5.077 40.905 13.925 58.602l42.356-32.782",
                        fill: "#FBBC05"
                    }), (0, o.Y)("path", {
                        d: "M130.55 50.479c24.514 0 41.05 10.589 50.479 19.438l36.844-35.974C195.245 12.91 165.798 0 130.55 0 79.49 0 35.393 29.301 13.925 71.947l42.211 32.783c10.59-31.477 39.891-54.251 74.414-54.251",
                        fill: "#EB4335"
                    })]
                })
            }

            function X({
                children: e = "Continue with Google",
                next: t,
                onTrackSignupIntent: r,
                params: i = {}
            }) {
                let n = (0, a.addParamsToUrl)("/google-sso/start?scopes=basic", {
                        next: t,
                        ...i
                    }),
                    s = (0, d.useCallback)(() => {
                        let e = h.f.googleSso,
                            t = L(e);
                        t && M(t), r && r(e)
                    }, [r]);
                return (0, o.Y)(Z, {
                    href: n,
                    icon: (0, o.Y)(K, {}),
                    onClick: s,
                    children: e
                })
            }
            let Q = {
                root: {
                    name: "1vr7vmn",
                    styles: "align-items:center;display:flex"
                },
                separator: (0, c.AH)({
                    borderTop: `1px solid ${n.Tj.neutral300}`,
                    height: 0,
                    width: "100%"
                }, "", ""),
                text: (0, c.AH)({
                    color: n.Tj.neutral600,
                    padding: "0 20px"
                }, "", "")
            };

            function ee() {
                return (0, o.FD)("div", {
                    css: Q.root,
                    "data-testid": "login-separator",
                    children: [(0, o.Y)("hr", {
                        css: Q.separator
                    }), (0, o.Y)("span", {
                        css: Q.text,
                        children: "OR"
                    }), (0, o.Y)("hr", {
                        css: Q.separator
                    })]
                })
            }

            function et() {
                return (0, o.FD)("p", {
                    className: `${n.Fo.bodySM} ${n.Fo.textNeutral800}`,
                    children: ["By signing up, you agree to Zapier's", " ", (0, o.Y)(n.N_, {
                        href: i.DS.LEGAL_URL,
                        target: "_blank",
                        children: "terms of service"
                    }), " ", "and", " ", (0, o.Y)(n.N_, {
                        href: i.DS.PRIVACY_URL,
                        target: "_blank",
                        children: "privacy policy."
                    })]
                })
            }
            let er = {
                name: "1n28aw",
                styles: "display:grid;grid-gap:25px"
            };

            function ei({
                currentUser: e,
                onClick: t,
                next: r
            }) {
                return (0, o.FD)("div", {
                    css: er,
                    children: [(0, o.FD)("p", {
                        className: `${n.Fo.body} ${n.Fo.textCenter} fs-exclude`,
                        children: ["You are currently logged in as ", e.email]
                    }), (0, o.Y)(n.$n, {
                        href: r || i.DS.DEFAULT_LOGIN_NEXT,
                        fullWidth: !0,
                        variant: "brand",
                        children: "Continue"
                    }), (0, o.Y)("p", {
                        className: `${n.Fo.body} ${n.Fo.textCenter}`,
                        children: (0, o.Y)(n.N_, {
                            onClick: t,
                            children: "Sign up as a different person"
                        })
                    })]
                })
            }

            function ea({
                next: e,
                selectedApis: t,
                shouldShowGoogleSSO: r,
                invitation: i,
                from: n
            }) {
                let s = {},
                    l = e ? (0, a.addParamsToUrl)(e, {
                        from: n
                    }, !0) : void 0;
                i && (s.invitation = i), t && (s.selected_apis = t);
                let {
                    trackSignupIntent: c
                } = (0, m.useTrackingContext)(), u = (0, d.useCallback)(e => {
                    c(e, {
                        selectedApis: t
                    }), N({
                        signupFunnel: "signup_intent",
                        signupType: x[e],
                        selectedApis: t
                    })
                }, [t, c]);
                return (0, o.Y)("div", {
                    children: r && (0, o.Y)("div", {
                        className: "google-sso-button-container",
                        children: (0, o.Y)(X, {
                            next: l,
                            onTrackSignupIntent: u,
                            params: s,
                            children: "Sign up with Google"
                        })
                    })
                })
            }
            let en = "If under 20 characters, it can't have more than 2 consecutive identical characters.",
                eo = "Must be at least 14 characters",
                es = "Must contain at least one letter",
                el = g.Ie(e => {
                    let t;
                    if ("string" != typeof e) return !1;
                    if (e.length >= 20) return e;
                    let r = 0;
                    for (let i of e) {
                        if (i !== t) {
                            r = 1, t = i;
                            continue
                        }
                        if (3 === (r += 1)) return !1
                    }
                    return e
                }, en),
                ec = g.Yj().min(14, {
                    message: eo
                }).and(g.Yj().max(512)).and(g.Yj().regex(/[a-zA-Z]/, {
                    message: es
                })).and(el),
                ed = {
                    name: "56z75u",
                    styles: "display:flex;align-items:start;gap:4px"
                };
            var eu = ({
                children: e,
                requirementIsSatisfied: t,
                testId: r
            }) => (0, o.FD)("div", {
                "data-testid": r,
                css: ed,
                children: [(0, o.Y)(_.In, {
                    name: t ? "formCheck" : "formX",
                    color: t ? "StatusSuccessStrongest" : "StatusErrorStrongest",
                    size: 20
                }), (0, o.Y)("p", {
                    className: `${n.Fo.bodySM} ${n.Fo.textNeutral800}`,
                    children: e
                })]
            });
            let em = {
                    name: "9guo87",
                    styles: "li{display:flex;flex-direction:row;}"
                },
                ep = {
                    minimumLengthPassword: "passwordRequirementMinimumLength",
                    hasLetter: "passwordRequirementValidLetter",
                    repeatedCharacter: "passwordRequirementRepeatedCharacters"
                };
            var eh = ({
                password: e,
                passwordErrors: t
            }) => {
                let [r, i] = (0, d.useState)(!1), [a, n] = (0, d.useState)(!1), [s, l] = (0, d.useState)(!1);
                (0, d.useEffect)(() => {
                    if (e.length < 1) {
                        n(!1), i(!1), l(!1);
                        return
                    }
                    n(!t ? .includes(es)), i(!t ? .includes(eo)), l(!t ? .includes(en))
                }, [e, t, n, l, i]);
                let c = [{
                    testId: ep.minimumLengthPassword,
                    requirementIsSatisfied: r,
                    requirementMessage: eo
                }, {
                    testId: ep.hasLetter,
                    requirementIsSatisfied: a,
                    requirementMessage: es
                }, {
                    testId: ep.repeatedCharacter,
                    requirementIsSatisfied: s,
                    requirementMessage: en
                }];
                return (0, o.Y)("div", {
                    css: em,
                    children: (0, o.Y)("ul", {
                        children: c.map(({
                            requirementIsSatisfied: e,
                            requirementMessage: t,
                            testId: r
                        }, i) => (0, o.Y)("li", {
                            children: (0, o.Y)(eu, {
                                testId: r,
                                requirementIsSatisfied: e,
                                children: t
                            })
                        }, i))
                    })
                })
            };
            let ef = {
                row: {
                    name: "1azpx8r",
                    styles: "margin-bottom:20px"
                },
                name: (0, c.AH)("display:grid;grid-gap:20px 16px;", i.HP.desktop, "{grid-template-columns:1fr 1fr;}", ""),
                password: {
                    name: "1vdoh3r",
                    styles: "position:relative;margin-bottom:12px"
                },
                passwordVisibility: (0, c.AH)("position:absolute;right:8px;top:35px;background:", n.Tj.neutral100, ";border:none;color:", n.Tj.neutral700, ";cursor:pointer;font-size:14px;padding:4px 8px;transition:color 150ms;&:hover{color:", n.Tj.neutral900, ";}", ""),
                hidden: {
                    name: "gsaxun",
                    styles: "margin-bottom:0;position:relative;overflow:hidden;*{position:absolute!important;left:100vw!important;}"
                }
            };

            function eg({
                formData: e,
                formErrors: t,
                handleFocus: r,
                handleSubmit: s,
                invitation: l,
                queryParams: c,
                shouldDisableEmailField: u,
                shouldFocusEmailField: m,
                shouldShowEmailField: p,
                shouldShowNameFields: h,
                shouldShowPasswordField: f,
                submittedFields: g,
                status: _
            }) {
                let [w, S] = (0, d.useState)(!1), {
                    control: b,
                    setFocus: v,
                    formState: {
                        errors: C
                    }
                } = (0, y.xW)();
                return (0, d.useEffect)(() => {
                    p && m && v("email"), f && v("password")
                }, [v, p, m, f]), (0, o.FD)("form", {
                    onSubmit: s,
                    children: [(0, o.Y)("div", {
                        css: [ef.row, !p && ef.hidden, "", ""],
                        "aria-hidden": !p,
                        inert: !p || void 0,
                        "data-testid": "emailField-wrapper",
                        children: (0, o.Y)(y.xI, {
                            name: "email",
                            control: b,
                            rules: {
                                required: !0
                            },
                            render: ({
                                field: e
                            }) => (0, o.Y)(n.ks, { ...e,
                                id: "signup-email",
                                label: "Work email *",
                                type: "email",
                                inputMode: "email",
                                autoComplete: "email",
                                disabled: u || "submitting" === _ || "success" === _,
                                error: "error" === _ && g ? .email ? t.email ? ? C.email ? .message ? .toString() : "",
                                tabIndex: p ? void 0 : -1,
                                onFocus: r
                            })
                        })
                    }), (0, o.FD)("div", {
                        css: [ef.row, ef.name, !h && ef.hidden, "", ""],
                        "aria-hidden": !h,
                        inert: !h || void 0,
                        "data-testid": "nameFields-wrapper",
                        children: [(0, o.Y)(y.xI, {
                            name: "firstName",
                            control: b,
                            rules: {
                                required: !0
                            },
                            render: ({
                                field: e
                            }) => (0, o.Y)(n.ks, { ...e,
                                id: "signup-first-name",
                                label: "First name *",
                                type: "text",
                                autoComplete: "given-name",
                                disabled: "submitting" === _ || "success" === _,
                                error: "error" === _ && g ? .firstName ? t.firstName ? ? C.firstName ? .message ? .toString() : "",
                                tabIndex: h ? void 0 : -1,
                                onFocus: r
                            })
                        }), (0, o.Y)(y.xI, {
                            name: "lastName",
                            control: b,
                            rules: {
                                required: !0
                            },
                            render: ({
                                field: e
                            }) => (0, o.Y)(n.ks, { ...e,
                                id: "signup-last-name",
                                label: "Last name *",
                                type: "text",
                                autoComplete: "family-name",
                                disabled: "submitting" === _ || "success" === _,
                                error: "error" === _ && g ? .lastName ? t.lastName ? ? C.lastName ? .message ? .toString() : "",
                                tabIndex: h ? void 0 : -1,
                                onFocus: r
                            })
                        })]
                    }), (0, o.FD)("div", {
                        css: [ef.row, !f && ef.hidden, "", ""],
                        "aria-hidden": !f,
                        inert: !f || void 0,
                        "data-testid": "passwordField-wrapper",
                        children: [(0, o.Y)(y.xI, {
                            name: "password",
                            control: b,
                            rules: {
                                validate: e => ((e, t) => {
                                    if (!t) return !0;
                                    let {
                                        success: r,
                                        error: i
                                    } = ec.safeParse(e);
                                    return r || i ? .flatten().formErrors.join(";")
                                })(e, f),
                                required: f
                            },
                            render: ({
                                field: e
                            }) => (0, o.FD)("div", {
                                css: ef.password,
                                children: [(0, o.Y)(n.ks, { ...e,
                                    id: "signup-password",
                                    label: "Password *",
                                    type: w ? "text" : "password",
                                    autoComplete: "new-password",
                                    disabled: "submitting" === _ || "success" === _,
                                    error: "error" === _ && g ? .password ? t.password ? ? C.password ? .message ? .toString() : "",
                                    tabIndex: f ? void 0 : -1,
                                    onFocus: r
                                }), (0, o.Y)("button", {
                                    type: "button",
                                    onClick: () => S(!w),
                                    css: ef.passwordVisibility,
                                    children: w ? "Hide" : "Show"
                                })]
                            })
                        }), (0, o.Y)("div", {
                            "data-testid": "password-requirements",
                            children: (0, o.Y)(eh, {
                                password: e.password,
                                passwordErrors: C.password ? .message
                            })
                        })]
                    }), (0, o.Y)("div", {
                        css: ef.row,
                        children: (0, o.Y)(et, {})
                    }), (0, o.Y)(n.$n, {
                        css: ef.row,
                        fullWidth: !0,
                        variant: "brand",
                        disabled: "submitting" === _ || "success" === _,
                        type: "submit",
                        id: "signup-submit",
                        children: "Get started for free"
                    }), (0, o.FD)("p", {
                        className: `${n.Fo.bodySM} ${n.Fo.textNeutral800} ${n.Fo.textCenter}`,
                        children: ["Already have an account?", " ", (0, o.Y)(n.N_, {
                            href: (0, a.addParamsToUrl)(i.DS.LOGIN_URL, {
                                invitation: l,
                                ...c
                            }, !0),
                            children: "Log In"
                        })]
                    })]
                })
            }
            let e_ = {
                root: {
                    name: "3kdb2q",
                    styles: "border:none;border-radius:8px;padding:32px;max-width:90vw;max-height:90vh;box-shadow:0 4px 6px -1px rgb(0 0 0 / 0.1),0 2px 4px -2px rgb(0 0 0 / 0.1);position:relative;&::backdrop{background-color:rgba(0, 0, 0, 0.5);}"
                },
                title: {
                    name: "11lu1h6",
                    styles: "margin-bottom:24px;padding-right:32px"
                },
                close: (0, c.AH)("position:absolute;top:16px;right:16px;background:none;border:none;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center;color:", n.Tj.neutral700, ";transition:color 150ms;&:hover{color:", n.Tj.neutral900, ";}", ""),
                body: {
                    name: "1878o4o",
                    styles: "display:grid;gap:20px"
                },
                footer: {
                    name: "15qpx11",
                    styles: "display:flex;justify-content:flex-end;gap:12px;margin-top:40px"
                }
            };

            function ey({
                children: e,
                onClose: t,
                maxWidth: r = "576px",
                title: i
            }) {
                let a = (0, d.useRef)(null),
                    s = (0, d.useId)();
                return (0, d.useEffect)(() => {
                    a.current ? .showModal()
                }, []), (0, o.FD)("dialog", {
                    ref: a,
                    css: e_.root,
                    style: {
                        width: r
                    },
                    onClose: t,
                    "aria-labelledby": i ? s : void 0,
                    children: [t && (0, o.Y)("button", {
                        type: "button",
                        css: e_.close,
                        onClick: () => {
                            a.current ? .close()
                        },
                        "aria-label": "Close",
                        children: (0, o.Y)(_.In, {
                            name: "formX",
                            size: 24
                        })
                    }), i && (0, o.Y)("h2", {
                        id: s,
                        className: n.Fo.headingXS,
                        css: e_.title,
                        children: i
                    }), e]
                })
            }

            function ew({
                children: e
            }) {
                return (0, o.Y)("div", {
                    className: n.Fo.body,
                    css: e_.body,
                    children: e
                })
            }

            function eS({
                children: e
            }) {
                return (0, o.Y)("div", {
                    css: e_.footer,
                    children: e
                })
            }

            function eb({
                isAutoJoin: e,
                isDomainCaptureBlocked: t,
                onClickGoToHomepage: r,
                onClickJoinTeam: i
            }) {
                return t ? (0, o.Y)(n.$n, {
                    variant: "brand",
                    size: "small",
                    onClick: r,
                    children: "Go to homepage"
                }) : e ? (0, o.Y)(n.$n, {
                    variant: "brand",
                    size: "small",
                    onClick: i,
                    children: "Join your team"
                }) : (0, o.Y)(n.$n, {
                    variant: "brand",
                    size: "small",
                    onClick: r,
                    children: "Go to homepage"
                })
            }

            function ev({
                isAutoJoin: e,
                isDomainCaptureBlocked: t
            }) {
                return t ? (0, o.Y)("p", {
                    children: "You can access Zapier from your identity provider, or contact your admin for an invite to join the account. Otherwise, use a different email to create a personal account."
                }) : e ? (0, o.Y)("p", {
                    children: "Join your team, or use a different email to create a personal account. You must be assigned the Zapier app in your identity provider to access Zapier."
                }) : (0, o.Y)("p", {
                    children: "Contact your company admin for an invite to join the account, or use a different email to create a personal account."
                })
            }

            function eC({
                onClickUseDifferentEmail: e,
                onClickJoinTeam: t,
                onClickGoToHomepage: r,
                teamName: i,
                accessPolicy: a,
                teamDomain: s,
                isDomainCaptureBlocked: l
            }) {
                (0, d.useEffect)(() => {
                    Y({
                        event_action: "click",
                        option_selected: "DOMAIN_DISCOVERY_show_modal",
                        interaction_name: "DOMAIN_DISCOVERY_show_modal",
                        interaction_raw_text: "Show the FoundTeam Modal",
                        interaction_goal: "Displays the Domain Discovery FoundTeam Modal"
                    })
                }, []);
                let c = a === P.auto_join,
                    u = v()(I()(i)) ? s : i;
                return (0, o.FD)(ey, {
                    title: "Good news, we found your team!",
                    onClose: e,
                    children: [(0, o.FD)(ew, {
                        children: [(0, o.FD)("p", {
                            children: ["Your colleagues at", " ", (0, o.Y)("span", {
                                className: n.Fo.fontSemibold,
                                children: u
                            }), " are using Zapier."]
                        }), (0, o.Y)(ev, {
                            isAutoJoin: c,
                            isDomainCaptureBlocked: l ? ? !1
                        }), (0, o.FD)("p", {
                            children: ["Having trouble?", " ", (0, o.Y)(n.N_, {
                                target: "_blank",
                                href: "https://help.zapier.com/hc/en-us/articles/26165062819725",
                                children: "Get help signing up"
                            })]
                        })]
                    }), (0, o.FD)(eS, {
                        children: [(0, o.Y)(n.$n, {
                            variant: "secondary",
                            size: "small",
                            onClick: e,
                            children: "Use a different email"
                        }), (0, o.Y)(eb, {
                            isAutoJoin: c,
                            isDomainCaptureBlocked: l ? ? !1,
                            onClickGoToHomepage: r,
                            onClickJoinTeam: t
                        })]
                    })]
                })
            }

            function eI({
                errorMessage: e,
                onClickOk: t
            }) {
                return (0, d.useEffect)(() => {
                    try {
                        (0, s.emit)({
                            system_name: "identity",
                            modal_flag: !0,
                            modal_name: "DomainCaptureErrorModal",
                            modal_view_name: "Domain Capture error"
                        }, "web_analytics.tracking.page_view.PageViewEvent")
                    } catch (e) {
                        (0, l.Cp)(e, {
                            tags: {
                                section: "DomainCaptureErrorModal",
                                type: "PageViewEvent"
                            }
                        })
                    }
                }, []), v()(e) && (e = "Something went wrong."), (0, o.FD)(ey, {
                    title: "An error occurred",
                    onClose: t,
                    children: [(0, o.FD)(ew, {
                        children: [(0, o.Y)("p", {
                            children: e
                        }), (0, o.FD)("p", {
                            children: ["If you encounter this error repeatedly,", " ", (0, o.Y)(n.N_, {
                                href: i.DS.HELP_URL,
                                target: "_blank",
                                children: "contact Support"
                            }), "."]
                        })]
                    }), (0, o.Y)(eS, {
                        children: (0, o.Y)(n.$n, {
                            variant: "secondary",
                            size: "small",
                            onClick: t,
                            children: "Close and try again"
                        })
                    })]
                })
            }

            function eN({
                email: e
            }) {
                return (0, o.FD)("p", {
                    className: n.Fo.body,
                    children: ["You're signing up as", " ", (0, o.Y)("span", {
                        className: `${n.Fo.fontSemibold} fs-exclude`,
                        children: e
                    }), "."]
                })
            }
            let ex = {
                name: "1q7mb2q",
                styles: "display:flex;align-items:center;gap:2px"
            };
            var eY = ({
                email: e,
                onClick: t
            }) => (0, o.FD)(o.FK, {
                children: [(0, o.Y)(n.$n, {
                    variant: "plain",
                    hasArrow: !1,
                    onClick: t,
                    children: (0, o.FD)("div", {
                        css: ex,
                        children: [(0, o.Y)(_.In, {
                            name: "arrowBigLeft",
                            size: 20
                        }), " Back"]
                    })
                }), (0, o.Y)(eN, {
                    email: e
                })]
            });
            let eD = {
                    name: "1878o4o",
                    styles: "display:grid;gap:20px"
                },
                eF = (0, c.AH)("margin-bottom:16px;text-align:center;", i.HP.tablet, "{text-align:left;}", "");

            function ek({
                enableEmailAutoFocus: e = !1,
                googleCaptchaSiteKey: t,
                hideFieldsUntilFocus: r = !1,
                invitation: s,
                next: c,
                queryParams: u = {},
                useCase: p,
                routeTo: h,
                selectedApis: f,
                googleSSOEnabled: g = !0,
                from: _,
                domainCaptureData: w,
                metadata: S,
                prefillData: b
            }) {
                let [C, I] = (0, d.useState)(!1), {
                    formData: x,
                    formErrors: D,
                    formMethods: k,
                    handleClearForm: E,
                    handleFocus: O,
                    handleSubmit: T,
                    isCaptchaRequired: A,
                    shouldShowEmailField: L,
                    shouldShowNameFields: M,
                    shouldShowPasswordField: P,
                    status: G,
                    submittedFields: z,
                    shouldShowGoogleSSO: Z,
                    discoveredDomainAccount: W,
                    onClickUseDifferentEmail: K,
                    onClickJoinTeam: X,
                    onClickGoToHomepage: Q
                } = function(e = {}) {
                    var t;
                    let [r, n] = (0, d.useState)("initial"), [o, s] = (0, d.useState)(!1), [c, u] = (0, d.useState)({}), [p, h] = (0, d.useState)({ ...V
                    }), [f, g] = (0, d.useState)(e.discoveredDomainAccount), _ = (0, y.mN)({
                        defaultValues: H(e),
                        mode: "onChange"
                    }), {
                        clearErrors: w,
                        reset: S,
                        handleSubmit: b,
                        watch: C,
                        setValue: I,
                        formState: {
                            touchedFields: N
                        }
                    } = _, x = C(), {
                        trackSignupIntent: D
                    } = (0, m.useTrackingContext)(), F = !!c.captcha, k = e.routeTo || $, E = !!p.email && "initial" === r || "error" === r && !c.email && !c.firstName && !c.lastName && !!c.password || "submitting" === r && !!N.password || !!x.email && !!N.password || !1, R = !E, O = (o || !e.hideFieldsUntilFocus) && !E, T = (t = e.googleSSOEnabled, !(0, i.GZ)() && (void 0 === t || !0 === t));
                    (0, d.useEffect)(() => {
                        e.email && I("email", e.email || "")
                    }, [e.email, I]), (0, d.useEffect)(() => {
                        x.captcha && A(x)
                    }, [x.captcha]);
                    let A = async t => {
                            n("submitting"), h({
                                captcha: !!t.captcha,
                                email: !!t.email,
                                firstName: !!t.firstName,
                                lastName: !!t.lastName,
                                password: !!t.password
                            });
                            try {
                                if (R && !t.invitation) {
                                    let e = await j({
                                        email: t.email
                                    });
                                    if (e ? .errors == null && e ? .account ? .id != null && e ? .user ? .id == null) return void g(e.account);
                                    if (function(e) {
                                            let t = e ? .errors;
                                            if (null != t) {
                                                var r;
                                                let e = (r = t, null == r ? "" : r.map(e => "string" == typeof e ? e : "object" == typeof e && e.message).filter(e => null != e).join(", "));
                                                if (v()(e)) throw Error("Error occurred parsing discoverDomainResult.errors: " + t);
                                                return u({
                                                    email: e
                                                }), n("error"), !0
                                            }
                                            return !1
                                        }(e)) return;
                                    g(null)
                                }
                                let r = await q(t, e.next, e.selectedApis, k);
                                if (r.didRedirect) return;
                                if (Object.keys(r ? .errors || {}).length > 0) u(r ? .errors || {}), n("error");
                                else {
                                    u({}), n("success");
                                    let r = (0, a.addTruthyParamsToUrl)(e.next || i.DS.DEFAULT_SIGNUP_NEXT, {
                                        selected_apis: e.selectedApis,
                                        from: e.from,
                                        invitation_code: t.invitation
                                    });
                                    k(r)
                                }
                            } catch (e) {
                                (0, l.Cp)(e), u({
                                    error: U
                                }), n("error")
                            }
                        },
                        L = async () => {
                            Y({
                                destination_url_address: f ? .ssoUrl,
                                event_action: "click",
                                option_selected: "DOMAIN_DISCOVERY_join_team",
                                interaction_name: "DOMAIN_DISCOVERY_join_team",
                                interaction_raw_text: "Join team Button Clicked",
                                interaction_goal: "Redirect to the Domain Capture SSO Url"
                            }), f ? .ssoUrl != null ? (await B(), k((0, a.addTruthyParamsToUrl)(f.ssoUrl, {
                                is_domain_capture_signup: "true",
                                next: e.next,
                                skip_onboarding: e.metadata ? .skipOnboarding,
                                user_provisioning_method: e.metadata ? .userProvisioningMethod
                            }))) : (g(null), u({
                                error: U
                            }), n("error"))
                        };
                    return {
                        formData: x,
                        formErrors: c,
                        formMethods: _,
                        handleClearForm: function() {
                            S(H(e)), w(), u({}), h({ ...V
                            }), n("initial")
                        },
                        handleFocus: function() {
                            o || D("direct", {
                                selected_apis: e.selectedApis
                            }), s(!0)
                        },
                        handleSubmit: b(A),
                        hasTouched: o,
                        isCaptchaRequired: F,
                        shouldShowEmailField: R,
                        shouldShowNameFields: O,
                        shouldShowPasswordField: E,
                        shouldShowGoogleSSO: T,
                        status: r,
                        submittedFields: p,
                        discoveredDomainAccount: f,
                        onClickUseDifferentEmail: () => {
                            Y({
                                event_action: "click",
                                option_selected: "DOMAIN_DISCOVERY_use_different_email",
                                interaction_name: "DOMAIN_DISCOVERY_use_different_email",
                                interaction_raw_text: "Use different email Button clicked",
                                interaction_goal: "Close the modal to enter a different email address in the sign-up form"
                            }), g(null), e.isFromSsoReturn ? (n("initial"), k(i.DS.SIGNUP_URL)) : (I("email", ""), u({
                                email: "Please choose a different email address."
                            }), n("error"))
                        },
                        onClickJoinTeam: L,
                        onClickGoToHomepage: () => {
                            Y({
                                event_action: "click",
                                option_selected: "DOMAIN_DISCOVERY_go_to_homepage",
                                interaction_name: "DOMAIN_DISCOVERY_go_to_homepage",
                                interaction_raw_text: "Go to homepage Button clicked",
                                interaction_goal: "Close the modal and redirect to the homepage"
                            }), k(i.DS.INDEX_URL)
                        }
                    }
                }({
                    discoveredDomainAccount: w ? .discoveredDomainAccount,
                    email: s ? .email || b ? .email,
                    firstName: b ? .firstName,
                    from: _,
                    googleSSOEnabled: g,
                    hideFieldsUntilFocus: r,
                    invitation: s ? .code,
                    isFromSsoReturn: w ? .isFromSsoReturn,
                    lastName: b ? .lastName,
                    metadata: S,
                    next: c,
                    routeTo: h,
                    selectedApis: f
                }), er = s ? .account.hasSamlSso, en = "";
                er && s && (en = (0, a.addParamsToUrl)(s.ssoUrl, {
                    invitation: s.code
                }));
                let eo = function() {
                    let [e, t] = (0, d.useState)(!0), [r, a] = (0, d.useState)();
                    return (0, d.useEffect)(() => {
                        !async function() {
                            let e = await R(i.DS.CURRENT_SESSION_URL);
                            t(!1), a(e.body)
                        }()
                    }, []), {
                        currentUser: r,
                        isLoading: e
                    }
                }();
                return eo.currentUser ? .email && !C ? (0, o.Y)(ei, {
                    currentUser: eo.currentUser,
                    next: c,
                    onClick: () => I(!0)
                }) : A ? (0, o.Y)(F, {
                    googleCaptchaSiteKey: t,
                    onCaptchaVerification: e => {
                        k.setValue("captcha", e || "")
                    }
                }) : (0, o.FD)("div", {
                    css: eD,
                    children: [null != W && (0, o.Y)(eC, {
                        onClickUseDifferentEmail: K,
                        onClickGoToHomepage: Q,
                        onClickJoinTeam: X,
                        teamName: W.name,
                        teamAvatarUrl: W.logoUrl,
                        accessPolicy: W.accessPolicy,
                        teamDomain: W.domain,
                        isDomainCaptureBlocked: W.isDomainCaptureBlocked
                    }), w ? .errorModalMessage && (0, o.Y)(eI, {
                        onClickOk: () => {
                            window.location.href = i.DS.SIGNUP_URL
                        },
                        errorMessage: w.errorModalMessage
                    }), P && !er && (0, o.Y)(eY, {
                        email: x.email,
                        onClick: E
                    }), L && !er && (0, o.Y)(ea, {
                        next: c,
                        selectedApis: f,
                        from: _,
                        useCaseSlug: p,
                        shouldShowGoogleSSO: Z,
                        invitation: s ? .code
                    }), er && (0, o.FD)("div", {
                        css: eD,
                        children: [(0, o.Y)("h2", {
                            className: `${n.Fo.bodyLG} ${n.Fo.textNeutral800}`,
                            css: eF,
                            children: "Sign up with your Identity Provider"
                        }), (0, o.Y)(J, {
                            href: en,
                            next: c,
                            type: "sso",
                            shouldOpenInChildWindow: !1,
                            children: "Continue with SSO"
                        })]
                    }), L && !er && Z && (0, o.Y)(ee, {}), !er && (0, o.Y)(y.Op, { ...k,
                        children: (0, o.Y)(eg, {
                            formData: x,
                            formErrors: D,
                            handleFocus: () => {
                                O(), N({
                                    signupFunnel: "signup_intent",
                                    signupType: "direct",
                                    selectedApis: f
                                })
                            },
                            handleSubmit: function(e) {
                                return N({
                                    signupFunnel: "signup",
                                    signupType: "direct",
                                    selectedApis: f
                                }), T(e)
                            },
                            invitation: s ? .code,
                            queryParams: u,
                            shouldDisableEmailField: !!s ? .email,
                            shouldFocusEmailField: !!e,
                            shouldShowEmailField: L,
                            shouldShowNameFields: M,
                            shouldShowPasswordField: P,
                            status: G,
                            submittedFields: z
                        })
                    }), D.error && "error" === G && (0, o.Y)("div", {
                        className: `${n.Fo.bodySM} ${n.Fo.textError} ${n.Fo.textCenter}`,
                        children: D.error
                    }), er && (0, o.Y)(et, {})]
                })
            }
        }
    }
]);