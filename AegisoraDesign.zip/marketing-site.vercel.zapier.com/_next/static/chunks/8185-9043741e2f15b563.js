(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8185], {
        1783: e => {
            e.exports = {
                code: "ContentfulRichText_code__jLRUs",
                "table-scroll": "ContentfulRichText_table-scroll__7yzeR",
                table: "ContentfulRichText_table__H9DIV"
            }
        },
        9188: (e, t, a) => {
            "use strict";
            a.d(t, {
                LocalizationProvider: () => s,
                useLocalization: () => l
            });
            var n = a(11002),
                o = a(92594),
                i = a(74185);
            let r = (0, o.createContext)(null);

            function l() {
                let e = (0, o.useContext)(r);
                if (!e) throw Error("useLocalization must be used within a <LocalizationProvider>");
                return e
            }

            function s(e) {
                var t, a;
                let l = null != (t = e.origin) ? t : "https://zapier.com",
                    s = (0, o.useRef)(!!e.availableLocales),
                    [c, u] = (0, o.useState)(null),
                    [d, h] = (0, o.useState)(() => (0, i.vx)(e.pathname)),
                    [_, m] = (0, o.useState)(null != (a = e.availableLocales) ? a : null);
                return (0, o.useEffect)(() => {
                    u((0, i.Je)())
                }, []), (0, o.useEffect)(() => {
                    let e = (0, i.vx)(window.location.pathname, window.location.search);
                    h(e), "en" === e.locale ? ((0, i.rQ)("en"), window.location.replace(e.pathname + e.search)) : e.locale && (u(e.locale), (0, i.rQ)(e.locale))
                }, [e.pathname]), (0, o.useEffect)(() => {
                    d.pathname && (s.current ? s.current = !1 : (0, i.Rc)(d.pathname, l).then(m))
                }, [d.pathname, l]), (0, o.useEffect)(() => {
                    c && "en" !== c && !d.locale && (null == _ ? void 0 : _.includes(c)) && !(0, i.zE)(d.pathname) && window.location.replace((0, i.Ro)(d, c))
                }, [d.pathname, d.locale, c, _]), (0, n.jsx)(r.Provider, {
                    value: {
                        url: d,
                        pref: c,
                        availableLocales: _,
                        origin: l
                    },
                    children: e.children
                })
            }
        },
        15581: (e, t, a) => {
            "use strict";
            a.d(t, {
                NextLocalizationProvider: () => r
            });
            var n = a(11002),
                o = a(99235),
                i = a(9188);

            function r(e) {
                let t = (0, o.usePathname)();
                return (0, n.jsx)(i.LocalizationProvider, { ...e,
                    pathname: t
                })
            }
        },
        23362: (e, t, a) => {
            "use strict";
            a.d(t, {
                default: () => o.a
            });
            var n = a(75713),
                o = a.n(n)
        },
        28243: (e, t, a) => {
            "use strict";
            a.r(t), a.d(t, {
                CarouselSection: () => g
            });
            var n = a(11002),
                o = a(96091),
                i = a(7151),
                r = a(92594),
                l = a(23362),
                s = a(34139),
                c = a(89816),
                u = a(62473),
                d = a(84732),
                h = a(94564),
                _ = a.n(h);

            function m(e) {
                let {
                    companyLogo: t,
                    testimonialText: a,
                    author: i,
                    stats: r,
                    storyUrl: s
                } = e;
                return (0, n.jsxs)("div", {
                    className: _().card,
                    children: [(0, n.jsx)("div", {
                        className: _().logoContainer,
                        children: (0, n.jsx)(l.default, {
                            className: _().logo,
                            src: t.url,
                            alt: t.alt,
                            width: u.Y9,
                            height: u.nK,
                            style: {
                                width: "auto",
                                height: "100%",
                                maxHeight: "24px"
                            }
                        })
                    }), (0, n.jsxs)("figure", {
                        className: _().quoteContainer,
                        children: [(0, n.jsxs)("div", {
                            className: _().quoteTextContainer,
                            children: [(0, n.jsx)("svg", {
                                width: "20",
                                height: "16",
                                viewBox: "0 0 20 16",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                "aria-hidden": "true",
                                children: (0, n.jsx)("path", {
                                    d: "M15.2229 0H19.2L15.168 8.09256H19.2V16H10.9989V8.09256L15.2229 0ZM4.19657 0H8.20114L4.14171 8.09256H8.20114V16H0V8.09256L4.19657 0Z",
                                    fill: "currentColor"
                                })
                            }), (0, n.jsx)("blockquote", {
                                className: _().quoteText,
                                children: a
                            })]
                        }), (0, n.jsxs)("figcaption", {
                            className: _().authorContainer,
                            children: ["— ", i.name, i.jobTitle ? ", ".concat(i.jobTitle) : ""]
                        })]
                    }), r && r.length > 0 && (0, n.jsx)("div", {
                        className: _().statsContainer,
                        children: r.map(e => (0, n.jsxs)("div", {
                            className: _().statContainer,
                            children: [(0, n.jsx)("p", {
                                className: _().stat,
                                children: e.stat
                            }), (0, n.jsx)("p", {
                                className: _().statDescription,
                                children: e.statDescription
                            })]
                        }, e.stat))
                    }), (0, n.jsxs)(o.N_, {
                        href: s,
                        className: _().actionContainer,
                        "aria-label": "Read full ".concat(t.alt, " story"),
                        clickEventDetails: {
                            interaction_name: "customer_story_link_clicked"
                        },
                        children: [(0, n.jsxs)("svg", {
                            width: "38",
                            height: "38",
                            viewBox: "0 0 38 38",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "aria-hidden": "true",
                            children: [(0, n.jsx)("circle", {
                                cx: "18.8694",
                                cy: "18.8694",
                                r: "18.3694",
                                className: _().arrowCircle
                            }), (0, n.jsx)("path", {
                                d: "M19.9097 28.4535L18.6574 27.2117L26.0442 19.8355H7.57715V18.0525H26.0442L18.6574 10.6763L19.9097 9.43457L29.4192 18.944L19.9097 28.4535Z",
                                className: _().arrowPath
                            })]
                        }), (0, n.jsx)("span", {
                            "aria-hidden": "true",
                            children: "Read full story"
                        })]
                    })]
                })
            }

            function g(e) {
                let {
                    heading: t,
                    subheading: a,
                    testimonials: h,
                    paddingTop: g,
                    background: f = "neutral200"
                } = e, [p, v] = (0, r.useState)(0), x = (0, c.j)(), C = h.length;
                return (0, n.jsx)(o.wn, {
                    name: "Customer stories",
                    background: f,
                    paddingTop: g,
                    heading: null != t ? t : (0, n.jsxs)(n.Fragment, {
                        children: [(0, n.jsx)("span", {
                            className: o.Fo.textBrand,
                            children: "Built for everyone,"
                        }), " from the Fortune 500 to first-time founders"]
                    }),
                    subheading: null != a ? a : "Teams use Zapier in boardrooms, spare rooms, and anywhere that AI has ROI.",
                    buttons: [{
                        text: "See more customer stories",
                        href: "/customer-stories",
                        variant: "brand"
                    }],
                    children: (0, n.jsxs)("div", {
                        className: _().inner,
                        children: [(0, n.jsxs)("div", {
                            className: _().carousel,
                            role: "region",
                            "aria-roledescription": "carousel",
                            "aria-label": "Customer testimonials",
                            children: [(0, n.jsxs)("div", {
                                "aria-live": "polite",
                                className: o.Fo.srOnly,
                                children: ["Slide ", p + 1, " of ", C]
                            }), h.map((e, t) => {
                                let a = p === t;
                                return (0, n.jsxs)("div", {
                                    className: _().carouselItemGroup,
                                    role: "group",
                                    "aria-roledescription": "slide",
                                    "aria-label": "".concat(t + 1, " of ").concat(C),
                                    "data-active": a,
                                    "aria-hidden": !a,
                                    inert: !a || void 0,
                                    style: {
                                        transform: "translateX(-".concat(100 * p, "%)"),
                                        transition: x ? "none" : "transform 1s cubic-bezier(0, 0, 0.01, 1), opacity ".concat(a ? "1.5s" : ".8s", " cubic-bezier(0, 0, 0.01, 1)")
                                    },
                                    children: [(0, n.jsx)("div", {
                                        className: _().carouselItem,
                                        children: (0, n.jsx)(m, {
                                            companyLogo: e.companyLogo,
                                            testimonialText: e.testimonialText,
                                            author: e.author,
                                            stats: e.stats,
                                            storyUrl: e.storyUrl
                                        })
                                    }), (0, d.X)(e.testimonialImage.url) ? (0, n.jsx)(s.G, {
                                        className: _().carouselImage,
                                        src: e.testimonialImage.url,
                                        alt: e.testimonialImage.alt
                                    }) : (0, n.jsx)(l.default, {
                                        className: _().carouselImage,
                                        src: e.testimonialImage.url,
                                        alt: e.testimonialImage.alt,
                                        width: u.KT,
                                        height: u.dm,
                                        style: {
                                            width: "100%",
                                            height: "auto"
                                        }
                                    })]
                                }, t)
                            })]
                        }), C > 1 && (0, n.jsxs)("div", {
                            className: _().navigationContainer,
                            role: "group",
                            "aria-label": "Slide controls",
                            children: [(0, n.jsx)("button", {
                                type: "button",
                                className: _().navButton,
                                onClick: () => {
                                    v(e => Math.max(0, e - 1))
                                },
                                disabled: 0 === p,
                                "aria-label": "Previous slide",
                                children: (0, n.jsx)(i.In, {
                                    name: "arrowBigLeft",
                                    color: "currentColor"
                                })
                            }), (0, n.jsx)("button", {
                                type: "button",
                                className: _().navButton,
                                onClick: () => {
                                    v(e => Math.min(C - 1, e + 1))
                                },
                                disabled: p === C - 1,
                                "aria-label": "Next slide",
                                children: (0, n.jsx)(i.In, {
                                    name: "arrowBigRight",
                                    color: "currentColor"
                                })
                            })]
                        })]
                    })
                })
            }
        },
        34139: (e, t, a) => {
            "use strict";
            a.d(t, {
                G: () => r
            });
            var n = a(11002),
                o = a(62473),
                i = a(23362);

            function r(e) {
                var t, a, r, l;
                let s = e.src,
                    c = e.decorative ? "" : e.alt;
                if (e.asset && ("url" in e.asset ? (s = e.asset.url, null != c || (c = e.asset.description)) : "fields" in e.asset && (s = null != (a = null == (t = e.asset.fields.file) ? void 0 : t.url) ? a : s, null != c || (c = e.asset.fields.description))), !s) return null;
                s.startsWith("//") && (s = "https:".concat(s));
                let u = null != c ? c : "",
                    d = new URL(s),
                    h = d.pathname.endsWith(".svg"),
                    _ = d.pathname.endsWith(".gif"),
                    m = null != (r = e.priority) ? r : "high" === e.fetchPriority,
                    {
                        width: g,
                        height: f
                    } = function(e, t, a) {
                        if (t && a) return {
                            width: t,
                            height: a
                        };
                        if (e && "url" in e && e.width && e.height) return {
                            width: e.width,
                            height: e.height
                        };
                        if (e && "fields" in e) {
                            var n, i;
                            let t = null == (i = e.fields.file) || null == (n = i.details) ? void 0 : n.image;
                            if ((null == t ? void 0 : t.width) && (null == t ? void 0 : t.height)) return {
                                width: t.width,
                                height: t.height
                            }
                        }
                        return {
                            width: null != t ? t : o.KT,
                            height: null != a ? a : o.dm
                        }
                    }(e.asset, e.width, e.height),
                    p = null != e.width && null != e.height;
                return (0, n.jsx)(i.default, {
                    src: s,
                    alt: u,
                    width: g,
                    height: f,
                    priority: m,
                    fetchPriority: m ? "high" : e.fetchPriority,
                    quality: null != (l = e.quality) ? l : 80,
                    unoptimized: h || _,
                    className: e.className,
                    style: p ? void 0 : {
                        width: "100%",
                        height: "auto"
                    }
                })
            }
        },
        35686: e => {
            e.exports = {
                root: "Hero_root__afH_M",
                eyebrow: "Hero_eyebrow__LMJRM",
                subheading: "Hero_subheading__Kw4ti",
                buttons: "Hero_buttons__yxzgJ",
                media: "Hero_media___P2DP",
                stats: "Hero_stats__mSqA5",
                figure: "Hero_figure__gtPSk",
                features: "Hero_features__WSHjA",
                featureLabel: "Hero_featureLabel__0O_JO",
                badgeList: "Hero_badgeList__GGqNe",
                badgeListPromoFooter: "Hero_badgeListPromoFooter__aE27_",
                promo: "Hero_promo__u502m",
                logos: "Hero_logos__nFrxE",
                logosMonochrome: "Hero_logosMonochrome__0tNTe"
            }
        },
        45820: e => {
            e.exports = {
                checkIcon: "GovernanceChecklist_checkIcon__ps__P",
                checkIconBrand: "GovernanceChecklist_checkIconBrand__XBgnQ",
                detailedList: "GovernanceChecklist_detailedList__0ETWC",
                detailedItem: "GovernanceChecklist_detailedItem__H9csR",
                detailedCopy: "GovernanceChecklist_detailedCopy__Yxzk_",
                detailedLabel: "GovernanceChecklist_detailedLabel__eyKC_",
                detailedDescription: "GovernanceChecklist_detailedDescription__iNrR7"
            }
        },
        62473: (e, t, a) => {
            "use strict";
            a.d(t, {
                KT: () => n,
                Y9: () => i,
                dm: () => o,
                nK: () => r
            });
            let n = 800,
                o = 600,
                i = 120,
                r = 24
        },
        74185: (e, t, a) => {
            "use strict";
            a.d(t, {
                Je: () => r,
                Rc: () => d,
                Ro: () => c,
                YZ: () => i,
                rQ: () => l,
                vx: () => s,
                zE: () => u
            });
            var n = a(88811);
            let o = "preferred_locale",
                i = {
                    de: "Deutsch",
                    en: "English",
                    es: "Espa\xf1ol",
                    fr: "Fran\xe7ais",
                    ja: "日本語"
                };

            function r() {
                return (0, n.v8)(o) || null
            }

            function l(e) {
                (0, n.o)(o, e, {
                    category: "essential",
                    path: "/",
                    maxAge: 31536e3,
                    sameSite: "lax",
                    secure: window.isSecureContext
                })
            }

            function s() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                    a = Object.keys(i).find(t => e.startsWith("/".concat(t, "/")) || e === "/".concat(t));
                return {
                    pathname: a ? e.slice(a.length + 1) || "/" : e,
                    locale: null != a ? a : "",
                    search: t
                }
            }

            function c(e, t) {
                return "en" === t ? "".concat(e.pathname).concat(e.search) : "/".concat(t).concat(e.pathname).concat(e.search)
            }

            function u(e) {
                return /^(?:\/[a-z]{2}(?:-[a-z]{2})?)?\/apps\/[a-z0-9-]+\/integrations\/[a-z0-9-]+\/?$/i.test(e)
            }
            async function d(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "https://zapier.com";
                try {
                    var a;
                    let n = await fetch("".concat(t, "/api/localization/lookup?path=").concat(encodeURIComponent(e), "&v=2"));
                    if (!n.ok) return [];
                    return null != (a = (await n.json()).locales) ? a : []
                } catch (e) {
                    return []
                }
            }
        },
        75713: (e, t, a) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), ! function(e, t) {
                for (var a in t) Object.defineProperty(e, a, {
                    enumerable: !0,
                    get: t[a]
                })
            }(t, {
                default: function() {
                    return s
                },
                getImageProps: function() {
                    return l
                }
            });
            let n = a(97452),
                o = a(41495),
                i = a(89779),
                r = n._(a(20597));

            function l(e) {
                let {
                    props: t
                } = (0, o.getImgProps)(e, {
                    defaultLoader: r.default,
                    imgConf: {
                        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                        imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                        path: "/_next/image",
                        loader: "default",
                        dangerouslyAllowSVG: !1,
                        unoptimized: !1
                    }
                });
                for (let [e, a] of Object.entries(t)) void 0 === a && delete t[e];
                return {
                    props: t
                }
            }
            let s = i.Image
        },
        77871: (e, t, a) => {
            "use strict";
            a.d(t, {
                LocaleSelector: () => l
            });
            var n = a(11002),
                o = a(96091),
                i = a(9188),
                r = a(74185);

            function l() {
                let {
                    pref: e,
                    availableLocales: t,
                    url: a
                } = (0, i.useLocalization)();
                return (0, n.jsx)(o.rI, {
                    className: e ? "" : o.Fo.hidden,
                    label: (a.locale || "en").toUpperCase(),
                    "aria-label": "Select language: ".concat(r.YZ[a.locale || e || "en"]),
                    openEventDetails: {
                        interaction_name: "locale_selector_open"
                    },
                    closeEventDetails: {
                        interaction_name: "locale_selector_close"
                    },
                    children: Object.entries(r.YZ).map(i => {
                        let [l, s] = i, c = !(null == t ? void 0 : t.includes(l));
                        return (0, n.jsxs)(o._2, {
                            className: "sl_opaque",
                            href: c ? void 0 : (0, r.Ro)(a, l),
                            external: !0,
                            disabled: c,
                            selected: e === l,
                            onClick: "en" === l ? () => (0, r.rQ)("en") : void 0,
                            clickEventDetails: {
                                interaction_name: "locale_select",
                                interaction_raw_text: s,
                                option_selected: s
                            },
                            children: [s, " - ", l.toUpperCase()]
                        }, l)
                    })
                })
            }
        },
        84732: (e, t, a) => {
            "use strict";

            function n(e) {
                let {
                    quality: t = 80,
                    formats: a = ["avif", "webp"]
                } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = e;
                n.startsWith("//") && (n = "https:".concat(n));
                let o = new URL(n);
                o.searchParams.set("q", String(t));
                let i = o.toString();
                return "image-set(".concat(a.map(e => 'url("'.concat(i, "&fm=").concat(e, '") type("image/').concat(e, '")')).join(", "), ")")
            }

            function o(e) {
                return e.startsWith("https://images.ctfassets.net/")
            }
            a.d(t, {
                A: () => n,
                X: () => o
            })
        },
        89816: (e, t, a) => {
            "use strict";
            a.d(t, {
                j: () => s
            });
            var n = a(92594);
            let o = "(prefers-reduced-motion: reduce)";

            function i(e) {
                let t = window.matchMedia(o);
                return t.addEventListener("change", e), () => t.removeEventListener("change", e)
            }

            function r() {
                return window.matchMedia(o).matches
            }

            function l() {
                return !1
            }

            function s() {
                return (0, n.useSyncExternalStore)(i, r, l)
            }
        },
        92855: e => {
            e.exports = {
                figure: "RichImage_figure__lFqdB",
                imageLink: "RichImage_imageLink__tZgtg",
                image: "RichImage_image__czjuO",
                caption: "RichImage_caption__fwy_0"
            }
        },
        94564: e => {
            e.exports = {
                inner: "CarouselSection_inner__up71O",
                header: "CarouselSection_header__T41Es",
                carousel: "CarouselSection_carousel__wT8X7",
                carouselItemGroup: "CarouselSection_carouselItemGroup__NWvxg",
                carouselItem: "CarouselSection_carouselItem__92XNw",
                carouselImage: "CarouselSection_carouselImage__DH3qo",
                card: "CarouselSection_card__upaJc",
                logoContainer: "CarouselSection_logoContainer__Bb8JD",
                logo: "CarouselSection_logo__e4LdA",
                quoteContainer: "CarouselSection_quoteContainer__7dRA8",
                quoteTextContainer: "CarouselSection_quoteTextContainer__cgHWl",
                quoteText: "CarouselSection_quoteText__rQisP",
                authorContainer: "CarouselSection_authorContainer__aGvTG",
                statsContainer: "CarouselSection_statsContainer__EJLRl",
                statContainer: "CarouselSection_statContainer__O7B5S",
                stat: "CarouselSection_stat__nvRt6",
                statDescription: "CarouselSection_statDescription__f2ozR",
                actionContainer: "CarouselSection_actionContainer__3zG_L",
                arrowCircle: "CarouselSection_arrowCircle__XhmFk",
                arrowPath: "CarouselSection_arrowPath__W6RfQ",
                navigationContainer: "CarouselSection_navigationContainer__qIa_v",
                navButton: "CarouselSection_navButton__b23fL"
            }
        }
    }
]);