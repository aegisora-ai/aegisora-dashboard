"use strict";
(() => {
    var e = (e, t) => () => (e && (t = e(e = 0)), t),
        t = (e, t) => () => (t || e((t = {
            exports: {}
        }).exports, t), t.exports);

    function n(e) {
        let t = location.href;
        if (e) {
            let n = new URL(t);
            if (n.pathname !== e) return n.pathname = e, n.search = "", n.href
        }
        return t
    }

    function r() {
        return !!(navigator.webdriver || navigator.userAgent.includes("Headless"))
    }
    var i, a, o, u, c, s, l, f, d, v, m, p, h, g, y, T, S, E, b, L, w, C, M, x, A, k, F, I, B, D, P, R, N, q, H, O, V, U, _, j, J, $, z, G, K, Q, W, X, Y, Z, ee, et, en, er, ei, ea, eo, eu, ec, es, el, ef = e(() => {}),
        ed = e(() => {
            s = function() {
                return window.performance && performance.getEntriesByType && performance.getEntriesByType("navigation")[0]
            }, l = function(e) {
                if ("loading" === document.readyState) return "loading";
                var t = s();
                if (t) {
                    if (e < t.domInteractive) return "loading";
                    if (0 === t.domContentLoadedEventStart || e < t.domContentLoadedEventStart) return "dom-interactive";
                    if (0 === t.domComplete || e < t.domComplete) return "dom-content-loaded"
                }
                return "complete"
            }, f = function(e) {
                var t = e.nodeName;
                return 1 === e.nodeType ? t.toLowerCase() : t.toUpperCase().replace(/^#/, "")
            }, d = function(e, t) {
                var n = "";
                try {
                    for (; e && 9 !== e.nodeType;) {
                        var r = e,
                            i = r.id ? "#" + r.id : f(r) + (r.classList && r.classList.value && r.classList.value.trim() && r.classList.value.trim().length ? "." + r.classList.value.trim().replace(/\s+/g, ".") : "");
                        if (n.length + i.length > (t || 100) - 1) return n || i;
                        if (n = n ? i + ">" + n : i, r.id) break;
                        e = r.parentNode
                    }
                } catch (a) {}
                return n
            }, v = -1, m = function() {
                return v
            }, p = function(e) {
                addEventListener("pageshow", function(t) {
                    t.persisted && (v = t.timeStamp, e(t))
                }, !0)
            }, h = function() {
                var e = s();
                return e && e.activationStart || 0
            }, g = function(e, t) {
                var n = s(),
                    r = "navigate";
                return m() >= 0 ? r = "back-forward-cache" : n && (document.prerendering || h() > 0 ? r = "prerender" : document.wasDiscarded ? r = "restore" : n.type && (r = n.type.replace(/_/g, "-"))), {
                    name: e,
                    value: void 0 === t ? -1 : t,
                    rating: "good",
                    delta: 0,
                    entries: [],
                    id: "v3-".concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12),
                    navigationType: r
                }
            }, y = function(e, t, n) {
                try {
                    if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                        var r = new PerformanceObserver(function(e) {
                            Promise.resolve().then(function() {
                                t(e.getEntries())
                            })
                        });
                        return r.observe(Object.assign({
                            type: e,
                            buffered: !0
                        }, n || {})), r
                    }
                } catch (i) {}
            }, T = function(e, t, n, r) {
                var i, a;
                return function(o) {
                    var u;
                    t.value >= 0 && (o || r) && ((a = t.value - (i || 0)) || void 0 === i) && (i = t.value, t.delta = a, t.rating = (u = t.value) > n[1] ? "poor" : u > n[0] ? "needs-improvement" : "good", e(t))
                }
            }, S = function(e) {
                requestAnimationFrame(function() {
                    return requestAnimationFrame(function() {
                        return e()
                    })
                })
            }, E = function(e) {
                var t = function(t) {
                    "pagehide" !== t.type && "hidden" !== document.visibilityState || e(t)
                };
                addEventListener("visibilitychange", t, !0), addEventListener("pagehide", t, !0)
            }, b = function(e) {
                var t = !1;
                return function(n) {
                    t || (e(n), t = !0)
                }
            }, L = -1, w = function() {
                return "hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0
            }, C = function(e) {
                "hidden" === document.visibilityState && L > -1 && (L = "visibilitychange" === e.type ? e.timeStamp : 0, x())
            }, M = function() {
                addEventListener("visibilitychange", C, !0), addEventListener("prerenderingchange", C, !0)
            }, x = function() {
                removeEventListener("visibilitychange", C, !0), removeEventListener("prerenderingchange", C, !0)
            }, A = function() {
                return L < 0 && (L = w(), M(), p(function() {
                    setTimeout(function() {
                        L = w(), M()
                    }, 0)
                })), {
                    get firstHiddenTime() {
                        return L
                    }
                }
            }, k = function(e) {
                document.prerendering ? addEventListener("prerenderingchange", function() {
                    return e()
                }, !0) : e()
            }, F = [1800, 3e3], I = function(e, t) {
                t = t || {}, k(function() {
                    var n, r = A(),
                        i = g("FCP"),
                        a = y("paint", function(e) {
                            e.forEach(function(e) {
                                "first-contentful-paint" === e.name && (a.disconnect(), e.startTime < r.firstHiddenTime && (i.value = Math.max(e.startTime - h(), 0), i.entries.push(e), n(!0)))
                            })
                        });
                    a && (n = T(e, i, F, t.reportAllChanges), p(function(r) {
                        n = T(e, i = g("FCP"), F, t.reportAllChanges), S(function() {
                            i.value = performance.now() - r.timeStamp, n(!0)
                        })
                    }))
                })
            }, B = [.1, .25], D = function(e, t) {
                var n, r;
                n = function(t) {
                    (function(e) {
                        if (e.entries.length) {
                            var t, n = e.entries.reduce(function(e, t) {
                                return e && e.value > t.value ? e : t
                            });
                            if (n && n.sources && n.sources.length) {
                                var r = (t = n.sources).find(function(e) {
                                    return e.node && 1 === e.node.nodeType
                                }) || t[0];
                                if (r) return void(e.attribution = {
                                    largestShiftTarget: d(r.node),
                                    largestShiftTime: n.startTime,
                                    largestShiftValue: n.value,
                                    largestShiftSource: r,
                                    largestShiftEntry: n,
                                    loadState: l(n.startTime)
                                })
                            }
                        }
                        e.attribution = {}
                    })(t), e(t)
                }, r = (r = t) || {}, I(b(function() {
                    var e, t = g("CLS", 0),
                        i = 0,
                        a = [],
                        o = function(n) {
                            n.forEach(function(e) {
                                if (!e.hadRecentInput) {
                                    var t = a[0],
                                        n = a[a.length - 1];
                                    i && e.startTime - n.startTime < 1e3 && e.startTime - t.startTime < 5e3 ? (i += e.value, a.push(e)) : (i = e.value, a = [e])
                                }
                            }), i > t.value && (t.value = i, t.entries = a, e())
                        },
                        u = y("layout-shift", o);
                    u && (e = T(n, t, B, r.reportAllChanges), E(function() {
                        o(u.takeRecords()), e(!0)
                    }), p(function() {
                        i = 0, e = T(n, t = g("CLS", 0), B, r.reportAllChanges), S(function() {
                            return e()
                        })
                    }), setTimeout(e, 0))
                }))
            }, P = function(e, t) {
                I(function(t) {
                    (function(e) {
                        if (e.entries.length) {
                            var t = s(),
                                n = e.entries[e.entries.length - 1];
                            if (t) {
                                var r = t.activationStart || 0,
                                    i = Math.max(0, t.responseStart - r);
                                return void(e.attribution = {
                                    timeToFirstByte: i,
                                    firstByteToFCP: e.value - i,
                                    loadState: l(e.entries[0].startTime),
                                    navigationEntry: t,
                                    fcpEntry: n
                                })
                            }
                        }
                        e.attribution = {
                            timeToFirstByte: 0,
                            firstByteToFCP: e.value,
                            loadState: l(m())
                        }
                    })(t), e(t)
                }, t)
            }, R = {
                passive: !0,
                capture: !0
            }, N = new Date, q = function(e, t) {
                i || (i = t, a = e, o = new Date, V(removeEventListener), H())
            }, H = function() {
                if (a >= 0 && a < o - N) {
                    var e = {
                        entryType: "first-input",
                        name: i.type,
                        target: i.target,
                        cancelable: i.cancelable,
                        startTime: i.timeStamp,
                        processingStart: i.timeStamp + a
                    };
                    u.forEach(function(t) {
                        t(e)
                    }), u = []
                }
            }, O = function(e) {
                if (e.cancelable) {
                    var t, n, r, i = (e.timeStamp > 1e12 ? new Date : performance.now()) - e.timeStamp;
                    "pointerdown" == e.type ? (t = function() {
                        q(i, e), r()
                    }, n = function() {
                        r()
                    }, r = function() {
                        removeEventListener("pointerup", t, R), removeEventListener("pointercancel", n, R)
                    }, addEventListener("pointerup", t, R), addEventListener("pointercancel", n, R)) : q(i, e)
                }
            }, V = function(e) {
                ["mousedown", "keydown", "touchstart", "pointerdown"].forEach(function(t) {
                    return e(t, O, R)
                })
            }, U = [100, 300], _ = function(e, t) {
                t = t || {}, k(function() {
                    var n, r = A(),
                        o = g("FID"),
                        c = function(e) {
                            e.startTime < r.firstHiddenTime && (o.value = e.processingStart - e.startTime, o.entries.push(e), n(!0))
                        },
                        s = function(e) {
                            e.forEach(c)
                        },
                        l = y("first-input", s);
                    n = T(e, o, U, t.reportAllChanges), l && E(b(function() {
                        s(l.takeRecords()), l.disconnect()
                    })), l && p(function() {
                        n = T(e, o = g("FID"), U, t.reportAllChanges), u = [], a = -1, i = null, V(addEventListener), u.push(c), H()
                    })
                })
            }, j = function(e, t) {
                _(function(t) {
                    var n, r;
                    r = (n = t).entries[0], n.attribution = {
                        eventTarget: d(r.target),
                        eventType: r.name,
                        eventTime: r.startTime,
                        eventEntry: r,
                        loadState: l(r.startTime)
                    }, e(t)
                }, t)
            }, J = 0, $ = 1 / 0, z = 0, G = function(e) {
                e.forEach(function(e) {
                    e.interactionId && ($ = Math.min($, e.interactionId), J = (z = Math.max(z, e.interactionId)) ? (z - $) / 7 + 1 : 0)
                })
            }, K = function() {
                return c ? J : performance.interactionCount || 0
            }, Q = function() {
                "interactionCount" in performance || c || (c = y("event", G, {
                    type: "event",
                    buffered: !0,
                    durationThreshold: 0
                }))
            }, W = [200, 500], X = 0, Y = function() {
                return K() - X
            }, Z = [], ee = {}, et = function(e) {
                var t = Z[Z.length - 1],
                    n = ee[e.interactionId];
                if (n || Z.length < 10 || e.duration > t.latency) {
                    if (n) n.entries.push(e), n.latency = Math.max(n.latency, e.duration);
                    else {
                        var r = {
                            id: e.interactionId,
                            latency: e.duration,
                            entries: [e]
                        };
                        ee[r.id] = r, Z.push(r)
                    }
                    Z.sort(function(e, t) {
                        return t.latency - e.latency
                    }), Z.splice(10).forEach(function(e) {
                        delete ee[e.id]
                    })
                }
            }, en = function(e, t) {
                t = t || {}, k(function() {
                    Q();
                    var n, r = g("INP"),
                        i = function(e) {
                            e.forEach(function(e) {
                                e.interactionId && et(e), "first-input" !== e.entryType || Z.some(function(t) {
                                    return t.entries.some(function(t) {
                                        return e.duration === t.duration && e.startTime === t.startTime
                                    })
                                }) || et(e)
                            });
                            var t = Z[Math.min(Z.length - 1, Math.floor(Y() / 50))];
                            t && t.latency !== r.value && (r.value = t.latency, r.entries = t.entries, n())
                        },
                        a = y("event", i, {
                            durationThreshold: t.durationThreshold || 40
                        });
                    n = T(e, r, W, t.reportAllChanges), a && (a.observe({
                        type: "first-input",
                        buffered: !0
                    }), E(function() {
                        i(a.takeRecords()), r.value < 0 && Y() > 0 && (r.value = 0, r.entries = []), n(!0)
                    }), p(function() {
                        Z = [], X = K(), n = T(e, r = g("INP"), W, t.reportAllChanges)
                    }))
                })
            }, er = function(e, t) {
                en(function(t) {
                    (function(e) {
                        if (e.entries.length) {
                            var t = e.entries.sort(function(e, t) {
                                return t.duration - e.duration || t.processingEnd - t.processingStart - (e.processingEnd - e.processingStart)
                            })[0];
                            e.attribution = {
                                eventTarget: d(t.target),
                                eventType: t.name,
                                eventTime: t.startTime,
                                eventEntry: t,
                                loadState: l(t.startTime)
                            }
                        } else e.attribution = {}
                    })(t), e(t)
                }, t)
            }, ei = [2500, 4e3], ea = {}, eo = function(e, t) {
                var n, r;
                n = function(t) {
                    (function(e) {
                        if (e.entries.length) {
                            var t = s();
                            if (t) {
                                var n = t.activationStart || 0,
                                    r = e.entries[e.entries.length - 1],
                                    i = r.url && performance.getEntriesByType("resource").filter(function(e) {
                                        return e.name === r.url
                                    })[0],
                                    a = Math.max(0, t.responseStart - n),
                                    o = Math.max(a, i ? (i.requestStart || i.startTime) - n : 0),
                                    u = Math.max(o, i ? i.responseEnd - n : 0),
                                    c = Math.max(u, r ? r.startTime - n : 0),
                                    l = {
                                        element: d(r.element),
                                        timeToFirstByte: a,
                                        resourceLoadDelay: o - a,
                                        resourceLoadTime: u - o,
                                        elementRenderDelay: c - u,
                                        navigationEntry: t,
                                        lcpEntry: r
                                    };
                                return r.url && (l.url = r.url), i && (l.lcpResourceEntry = i), void(e.attribution = l)
                            }
                        }
                        e.attribution = {
                            timeToFirstByte: 0,
                            resourceLoadDelay: 0,
                            resourceLoadTime: 0,
                            elementRenderDelay: e.value
                        }
                    })(t), e(t)
                }, r = (r = t) || {}, k(function() {
                    var e, t = A(),
                        i = g("LCP"),
                        a = function(n) {
                            var r = n[n.length - 1];
                            r && r.startTime < t.firstHiddenTime && (i.value = Math.max(r.startTime - h(), 0), i.entries = [r], e())
                        },
                        o = y("largest-contentful-paint", a);
                    if (o) {
                        e = T(n, i, ei, r.reportAllChanges);
                        var u = b(function() {
                            ea[i.id] || (a(o.takeRecords()), o.disconnect(), ea[i.id] = !0, e(!0))
                        });
                        ["keydown", "click"].forEach(function(e) {
                            addEventListener(e, u, !0)
                        }), E(u), p(function(t) {
                            e = T(n, i = g("LCP"), ei, r.reportAllChanges), S(function() {
                                i.value = performance.now() - t.timeStamp, ea[i.id] = !0, e(!0)
                            })
                        })
                    }
                })
            }, eu = [800, 1800], ec = function e(t) {
                document.prerendering ? k(function() {
                    return e(t)
                }) : "complete" !== document.readyState ? addEventListener("load", function() {
                    return e(t)
                }, !0) : setTimeout(t, 0)
            }, es = function(e, t) {
                t = t || {};
                var n = g("TTFB"),
                    r = T(e, n, eu, t.reportAllChanges);
                ec(function() {
                    var i = s();
                    if (i) {
                        var a = i.responseStart;
                        if (a <= 0 || a > performance.now()) return;
                        n.value = Math.max(a - h(), 0), n.entries = [i], r(!0), p(function() {
                            (r = T(e, n = g("TTFB", 0), eu, t.reportAllChanges))(!0)
                        })
                    }
                })
            }, el = function(e, t) {
                es(function(t) {
                    (function(e) {
                        if (e.entries.length) {
                            var t = e.entries[0],
                                n = t.activationStart || 0,
                                r = Math.max(t.domainLookupStart - n, 0),
                                i = Math.max(t.connectStart - n, 0),
                                a = Math.max(t.requestStart - n, 0);
                            e.attribution = {
                                waitingTime: r,
                                dnsTime: i - r,
                                connectionTime: a - i,
                                requestTime: e.value - a,
                                navigationEntry: t
                            }
                        } else e.attribution = {
                            waitingTime: 0,
                            dnsTime: 0,
                            connectionTime: 0,
                            requestTime: 0
                        }
                    })(t), e(t)
                }, t)
            }
        });

    function ev() {
        let e = "";
        if ("connection" in navigator) {
            let t = navigator.connection;
            null != t && t.effectiveType && (e = t.effectiveType)
        }
        return e
    }

    function em(e) {
        D(e), j(e), eo(e), P(e), er(e), el(e)
    }

    function ep(e, t) {
        let n = new Blob([JSON.stringify(e)], {
            type: "text/plain"
        });
        try {
            "keepalive" in Request.prototype ? fetch(t, {
                method: "POST",
                body: n,
                keepalive: !0,
                mode: "no-cors"
            }).catch(() => {}) : "sendBeacon" in navigator && navigator.sendBeacon(t, n)
        } catch (r) {}
    }

    function eh(e) {
        try {
            if ("CLS" === e.name) return {
                eventTarget: e.attribution.largestShiftTarget
            };
            if ("FID" === e.name || "INP" === e.name) return {
                eventTarget: e.attribution.eventTarget,
                eventType: e.attribution.eventType
            };
            if ("element" in e.attribution) return {
                eventTarget: e.attribution.element
            }
        } catch (t) {}
    }

    function eg(e, t) {
        if (Number.isInteger(e)) return e;
        let n = Math.pow(10, t);
        return Math.floor(e * n) / n
    }

    function ey(e) {
        return "CLS" === e.name ? eg(e.value, 4) : "FID" === e.name ? eg(e.value, 2) : Math.round(e.value)
    }
    var eT = e(() => {
        ed()
    });
    t(() => {
        ef(), eT(),
            function() {
                let e = [],
                    t = e => e,
                    i = document.currentScript;
                if (r()) return;
                let a = null == i ? void 0 : i.dataset.dsn,
                    o = (null == i ? void 0 : i.dataset.endpoint) || (a ? `https://vitals.vercel-insights.com/v2/vitals?dsn=${a}&ve=production` : "/_vercel/speed-insights/vitals"),
                    u = () => {
                        var n, r;
                        let a = ev(),
                            u = e.map(e => ({
                                id: e.id,
                                type: e.name,
                                route: e.route,
                                href: e.href,
                                value: ey(e),
                                attribution: eh(e)
                            })).map(e => {
                                let n = t({
                                    type: "vital",
                                    url: e.href,
                                    route: e.route
                                });
                                return n ? { ...e,
                                    href: n.url
                                } : null
                            }).filter(e => null !== e);
                        0 !== u.length && (ep({
                            speed: a,
                            metrics: u,
                            scriptVersion: "0.1.3",
                            sdkName: null != (n = null == i ? void 0 : i.getAttribute("data-sdkn")) ? n : void 0,
                            sdkVersion: null != (r = null == i ? void 0 : i.getAttribute("data-sdkv")) ? r : void 0
                        }, o), e = [])
                    },
                    c = () => {
                        var e;
                        window.si = function(e, n) {
                            "beforeSend" === e && (t = n)
                        }, null == (e = window.siq) || e.forEach(([e, t]) => {
                            window.si(e, t)
                        })
                    };
                (() => {
                    var t;
                    if (window.sil) return;
                    window.sil = !0;
                    let r = Number(null != (t = null == i ? void 0 : i.dataset.sampleRate) ? t : 1);
                    if (!(1 === r || Math.random() <= r)) return;
                    em(t => {
                        e.push({ ...t,
                            href: n(null == i ? void 0 : i.dataset.path),
                            route: null == i ? void 0 : i.dataset.route
                        }), 6 === e.length && u()
                    }), addEventListener("visibilitychange", u), addEventListener("pagehide", u), addEventListener("popstate", u);
                    let a = history.pushState.bind(history);
                    history.pushState = function(...e) {
                        a(...e);
                        try {
                            u()
                        } catch (t) {}
                    }, c()
                })()
            }()
    })()
})();