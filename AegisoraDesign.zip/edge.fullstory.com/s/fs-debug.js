//!This code is part of the Services provided by FullStory, Inc. For license information, please refer to https://www.fullstory.com/legal/terms-and-conditions/
"use strict";
! function() {
    var t = function(n, i) {
        return (t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, n) {
                t.__proto__ = n
            } || function(t, n) {
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            })(n, i)
    };

    function n(n, i) {
        if ("function" != typeof i && null !== i) throw new TypeError("Class extends value " + String(i) + " is not a constructor or null");

        function r() {
            this.constructor = n
        }
        t(n, i), n.prototype = null === i ? Object.create(i) : (r.prototype = i.prototype, new r)
    }
    var i = function() {
        return i = Object.assign || function(t) {
            for (var n, i = 1, r = arguments.length; i < r; i++)
                for (var e in n = arguments[i]) Object.prototype.hasOwnProperty.call(n, e) && (t[e] = n[e]);
            return t
        }, i.apply(this, arguments)
    };

    function r(t, n, i, r) {
        return new(i || (i = Promise))(function(e, s) {
            function o(t) {
                try {
                    a(r.next(t))
                } catch (t) {
                    s(t)
                }
            }

            function u(t) {
                try {
                    a(r["throw"](t))
                } catch (t) {
                    s(t)
                }
            }

            function a(t) {
                var n;
                t.done ? e(t.value) : (n = t.value, n instanceof i ? n : new i(function(t) {
                    t(n)
                })).then(o, u)
            }
            a((r = r.apply(t, n || [])).next())
        })
    }

    function e(t, n) {
        var i, r, e, s, o = {
            label: 0,
            sent: function() {
                if (1 & e[0]) throw e[1];
                return e[1]
            },
            trys: [],
            ops: []
        };
        return s = {
            next: u(0),
            "throw": u(1),
            "return": u(2)
        }, "function" == typeof Symbol && (s[Symbol.iterator] = function() {
            return this
        }), s;

        function u(u) {
            return function(a) {
                return function(u) {
                    if (i) throw new TypeError("Generator is already executing.");
                    for (; s && (s = 0, u[0] && (o = 0)), o;) try {
                        if (i = 1, r && (e = 2 & u[0] ? r["return"] : u[0] ? r["throw"] || ((e = r["return"]) && e.call(r), 0) : r.next) && !(e = e.call(r, u[1])).done) return e;
                        switch (r = 0, e && (u = [2 & u[0], e.value]), u[0]) {
                            case 0:
                            case 1:
                                e = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, r = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!((e = (e = o.trys).length > 0 && e[e.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!e || u[1] > e[0] && u[1] < e[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < e[1]) {
                                    o.label = e[1], e = u;
                                    break
                                }
                                if (e && o.label < e[2]) {
                                    o.label = e[2], o.ops.push(u);
                                    break
                                }
                                e[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = n.call(t, o)
                    } catch (t) {
                        u = [6, t], r = 0
                    } finally {
                        i = e = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, a])
            }
        }
    }

    function s(t, n, i) {
        if (i || 2 === arguments.length)
            for (var r, e = 0, s = n.length; e < s; e++) !r && e in n || (r || (r = Array.prototype.slice.call(n, 0, e)), r[e] = n[e]);
        return t.concat(r || Array.prototype.slice.call(n))
    }

    function o(t) {
        if ("undefined" != typeof console) {
            var n = t();
            "string" == typeof n && console.log(n)
        }
    }

    function u(t) {
        var n, i;
        return "function" == typeof(null === (n = null == t ? void 0 : t.performance) || void 0 === n ? void 0 : n.measure) && "function" == typeof(null === (i = null == t ? void 0 : t.performance) || void 0 === i ? void 0 : i.mark)
    }

    function a(t) {
        return "".concat(t, ".start")
    }

    function c(t) {
        return "".concat(t, ".end")
    }

    function h(t, n) {
        u(t) && t.performance.mark(a(n))
    }

    function f(t, n) {
        if (u(t)) try {
            t.performance.mark(c(n)), t.performance.measure(n, a(n), c(n))
        } catch (t) {
            o(function() {
                return "".concat(t)
            })
        }
    }
    var v = "Processing Event Queue: Sample Curves",
        l = "Processing Event Queue: Mutations",
        d = "Event Queue Swansong",
        p = "Event Watcher: Processing Urls",
        g = "Handle RecPage",
        w = "Initialization",
        m = "genInsert",
        y = "POST Bundle",
        b = "Sending Bundle",
        S = "Snapshot",
        _ = "Starting Event Queue Pipeline";

    function k(t) {
        var n = {};
        try {
            for (var i = t.cookie.split(";"), r = 0; r < i.length; r++) {
                var e = i[r].replace(/^\s+|\s+$/g, "").split("=");
                n[e[0]] || (n[e[0]] = e[1])
            }
        } catch (t) {
            o(function() {
                return "Exception trying to parse cookies: ".concat(t)
            })
        }
        return n
    }

    function I(t, n) {
        return function() {
            for (var i = [], r = 0; r < arguments.length; r++) i[r] = arguments[r];
            try {
                return t.apply(this, i)
            } catch (t) {
                try {
                    n && n(t)
                } catch (t) {}
            }
        }
    }
    var A = function() {},
        E = 1,
        C = 9,
        T = 4;

    function P(t) {
        try {
            var n = function(t) {
                    var n, i = null !== (n = t.ownerDocument) && void 0 !== n ? n : t;
                    return i.nodeType === C ? i : document
                }(t),
                i = n.createTreeWalker(n, NodeFilter.SHOW_ALL, null, !1);
            return i.currentNode = t, i
        } catch (t) {
            return
        }
    }

    function x(t, n) {
        var i = P(t);
        if (i)
            for (var r = i.firstChild(); r;) n(r), r = i.nextSibling()
    }

    function R(t) {
        var n = P(t);
        return n ? n.nextSibling() : null
    }

    function M(t) {
        var n = P(t);
        return n ? n.previousSibling() : null
    }

    function K(t) {
        var n = P(t);
        return n ? n.parentNode() : null
    }

    function j(t) {
        var n = P(t);
        return n ? n.firstChild() : null
    }

    function O(t) {
        return !!j(t)
    }

    function U(t, n) {
        return t.arrayIsArray(n)
    }

    function N(t, n) {
        for (var i = 0, r = t; i < r.length; i++)
            if (n(r[i])) return !0;
        return !1
    }

    function L(t) {
        return "function" == typeof t
    }

    function F(t) {
        var n = parseInt(null != t ? t : "", 10);
        return isNaN(n) ? void 0 : n
    }

    function H(t) {
        return null !== t && "object" == typeof t
    }

    function D(t, n) {
        return H(n) && !U(t, n) && n.constructor !== Date
    }

    function B(t) {
        if (null != t) {
            var n = W(t) ? t : new Date(t);
            try {
                return n.toISOString()
            } catch (n) {
                if ("string" == typeof t) return t
            }
        }
        return null
    }

    function W(t) {
        return null != t && t.constructor === Date
    }

    function z(t) {
        return "string" == typeof t
    }

    function q(t, n) {
        return 0 == t.lastIndexOf(n, 0)
    }

    function V(t, n, i) {
        for (var r in n) t.objectHasOwnProp(n, r) && i(n[r], r, n)
    }

    function $(t) {
        for (var n in t)
            if (Object.prototype.hasOwnProperty.call(t, n)) return t[n]
    }

    function G(t, n) {
        var i = 0;
        for (var r in t)
            if (Object.prototype.hasOwnProperty.call(t, r) && ++i > n) return !1;
        return i == n
    }

    function Q(t, n) {
        var i = 0;
        for (var r in t)
            if (Object.prototype.hasOwnProperty.call(t, r) && ++i > n) return !0;
        return !1
    }

    function X(t) {
        return function() {
            for (var n, i, r = this, e = [], s = 0; s < arguments.length; s++) e[s] = arguments[s];
            return "function" == typeof(null === (i = null === (n = window.Zone) || void 0 === n ? void 0 : n.root) || void 0 === i ? void 0 : i.run) ? window.Zone.root.run(function() {
                return t.apply(r, e)
            }) : t.apply(this, e)
        }
    }

    function J(t, n, i) {
        if (void 0 === i && (i = X), !t) return A;
        var r = i(t);
        return I(n ? r.bind(n) : r, function(t) {
            o(function() {
                return "Unexpected error: ".concat(t)
            })
        })
    }

    function Y(t) {
        var n = t.doctype;
        if (!n) return "";
        var i = "<!DOCTYPE ";
        return i += n.name, n.publicId && (i += " PUBLIC \"".concat(n.publicId, "\"")), n.systemId && (i += " \"".concat(n.systemId, "\"")), "".concat(i, ">")
    }

    function Z(t, n) {
        return t.jsonParse(n)
    }

    function tt(t, n, i) {
        return nt(null == t ? void 0 : t.prototype, n, i)
    }

    function nt(t, n, r, e) {
        if (!t) return function() {};
        var s = Object.getOwnPropertyDescriptor(t, n);
        if (!s || !s.configurable) return function() {};
        var o, u, a, c, h = e ? J(e) : void 0,
            f = r ? J(r) : void 0,
            v = !0,
            l = !1;
        if ("value" in s) {
            var d = s.value;
            o = function() {
                return !l && v && h && (l = !0, h(this, d), l = !1), d
            }, u = function(t) {
                d = t, !l && v && f && f(this, t)
            }, Object.defineProperty(t, n, {
                configurable: !0,
                enumerable: s.enumerable,
                get: o,
                set: u
            })
        } else {
            if (a = s.get, c = s.set, !a && !c) return function() {};
            !a || !h || t instanceof HTMLElement || (o = function() {
                var t = a.call(this);
                return !l && v && h && (l = !0, h(this, t), t = a.call(this), l = !1), t
            }), c && f && (u = function(t) {
                c.call(this, t), !l && v && f && f(this, t)
            }), Object.defineProperty(t, n, i(i({}, s), {
                get: null != o ? o : s.get,
                set: null != u ? u : s.set
            }))
        }
        return function() {
            v = !1;
            var r = Object.getOwnPropertyDescriptor(t, n);
            r && ("value" in s ? r.get === o && r.set === u && Object.defineProperty(t, n, i(i({}, s), {
                value: o ? o.call(t) : s.value
            })) : Object.defineProperty(t, n, i(i({}, r), {
                get: r.get === o && null != a ? a : r.get,
                set: r.set === u && null != c ? c : r.set
            })))
        }
    }

    function it(t, n) {
        var i = n.navigator.languages;
        return i && U(t, i) ? i.join(",") : n.navigator.userLanguage || n.navigator.language
    }

    function rt(t) {
        if (!t) return !1;
        var n = t.isConnected;
        return "boolean" == typeof n ? n : function(t) {
            for (var n = t, i = void 0; n; n = i)
                if (!(i = K(n))) return n;
            return t
        }(t).nodeType === C
    }

    function et(t, n) {
        void 0 === t && (t = []), void 0 === n && (n = 0);
        for (var i = "", r = 0, e = t; r < e.length; r++) {
            var s = e[r];
            i += "/".concat(s)
        }
        return "".concat(i, "/").concat(n)
    }
    var st = ["", "0", "1", "-1", "true", "false", "n/a", "nan", "undefined", "null", "nil", "the_id_that_you_use_in_your_app_for_this_user"],
        ot = ["811c9dc5", "350ca8af", "340ca71c", "14cd0a2b", "4db211e5", "0b069958", "3613e041", "2f8f13ba", "9b61ad43", "77074ba4", "0da3f8ec", "1c750511"];

    function ut(t) {
        var n = function() {
            return t.dateNow()
        };
        return "number" != typeof n() && (n = function() {
            return t.dateGetTime(new Date)
        }), n
    }
    var at, ct = function(t) {
        function n() {
            return !!(null == t ? void 0 : t.now)
        }
        return {
            supportsPerformanceNow: n,
            getTimeOrigin: function(i) {
                var r;
                if (n() && t) {
                    var e = t.now();
                    if ("number" == typeof e && isFinite(e) && !(e <= 0)) {
                        var s = t.timeOrigin;
                        if ("number" != typeof s) {
                            var o = ut(i)() - t.now(),
                                u = null === (r = t.timing) || void 0 === r ? void 0 : r.navigationStart;
                            s = u ? i.mathMin(o, u) : o
                        }
                        var a = i.mathFloor(s);
                        if ("number" == typeof a && isFinite(a) && !(a <= 0)) return a
                    }
                }
            }
        }
    }(self.performance);

    function ht(t) {
        return at || (at = function(t) {
            var n, i = ut(t),
                r = null !== (n = function(t) {
                    return ct.getTimeOrigin(t)
                }(t)) && void 0 !== n ? n : i();
            return {
                now: i,
                timeOrigin: r,
                msSinceDocumentStart: function() {
                    return i() - r
                }
            }
        }(t)), at
    }

    function ft(t) {
        return ht(t).now()
    }

    function vt(t) {
        return ht(t).msSinceDocumentStart()
    }
    var lt, dt, pt, gt, wt, mt, yt, bt, St, _t, kt, It, At = function(t) {
            return t.mathFloor(ft(t) / 1e3)
        },
        Et = function(t) {
            return At(t) + 31536e3
        };
    (dt = lt || (lt = {}))[2] = 2, dt[3] = 3, dt[4] = 4, dt[6] = 6, dt[8] = 8, dt[9] = 9, dt[10] = 10, dt[11] = 11, dt[12] = 12, dt[13] = 13, dt[16] = 16, dt[17] = 17, dt[18] = 18, dt[19] = 19, dt[20] = 20, dt[21] = 21, dt[22] = 22, dt[23] = 23, dt[24] = 24, dt[25] = 25, dt[32] = 32, dt[33] = 33, dt[34] = 34, dt[35] = 35, dt[36] = 36, dt[37] = 37, dt[38] = 38, dt[39] = 39, dt[40] = 40, dt[41] = 41, dt[42] = 42, dt[43] = 43, dt[48] = 48, dt[49] = 49, dt[50] = 50, dt[51] = 51, dt[52] = 52, dt[53] = 53, dt[54] = 54, dt[56] = 56, dt[57] = 57, dt[58] = 58, dt[59] = 59, dt[60] = 60, dt[61] = 61, dt[62] = 62, dt[63] = 63, dt[64] = 64, dt[65] = 65, dt[66] = 66, dt[67] = 67, dt[68] = 68, dt[69] = 69, dt[70] = 70, dt[71] = 71, dt[72] = 72, dt[73] = 73, dt[74] = 74, dt[75] = 75, dt[77] = 77, dt[78] = 78, dt[79] = 79, dt[80] = 80, dt[81] = 81, dt[82] = 82, dt[83] = 83, dt[84] = 84, dt[85] = 85, dt[86] = 86, dt[87] = 87, dt[88] = 88, dt[89] = 89, dt[90] = 90, dt[91] = 91, dt[92] = 92, dt[93] = 93, dt[94] = 94, dt[95] = 95, dt[96] = 96, dt[97] = 97, dt[98] = 98, dt[99] = 99, dt[100] = 100, dt[101] = 101, dt[102] = 102, dt[103] = 103, dt[104] = 104, dt[105] = 105, dt[106] = 106, dt[109] = 109, dt[110] = 110, dt[111] = 111, dt[112] = 112, dt[113] = 113, dt[114] = 114, dt[115] = 115, dt[116] = 116, dt[117] = 117, dt[118] = 118, dt[119] = 119, dt[120] = 120, dt[121] = 121, dt[122] = 122, dt[2e3] = 2e3, dt[2001] = 2001, dt[2002] = 2002, dt[2003] = 2003, dt[8193] = 8193, dt[8195] = 8195, dt[8196] = 8196, dt[8197] = 8197, dt[8198] = 8198, dt[8199] = 8199, (gt = pt || (pt = {}))[0] = 0, gt[1] = 1, gt[2] = 2, (mt = wt || (wt = {}))[0] = 0, mt[1] = 1, (bt = yt || (yt = {}))[0] = 0, bt[1] = 1, (_t = St || (St = {}))[0] = 0, _t[1] = 1, _t[2] = 2, _t[3] = 3, _t[4] = 4, _t[5] = 5, (It = kt || (kt = {}))[0] = 0, It[1] = 1, It[2] = 2, It[3] = 3, It[4] = 4, It[5] = 5, It[6] = 6, It[7] = 7, It[8] = 8, It[9] = 9, It[10] = 10;
    var Ct, Tt, Pt, xt, Rt, Mt, Kt, jt, Ot, Ut, Nt, Lt, Ft, Ht, Dt, Bt, Wt, zt, qt, Vt, $t, Gt, Qt, Xt, Jt, Yt, Zt, tn, nn, rn, en, sn, on, un, an, cn, hn, fn, vn, ln, dn, pn, gn, wn, mn, yn, bn, Sn, _n, kn, In, An, En, Cn, Tn, Pn, xn = ["print", "alert", "confirm"];
    (Tt = Ct || (Ct = {}))[Tt.Unset = 0] = "Unset", Tt[Tt.Entering = 1] = "Entering", Tt[Tt.Restored = 2] = "Restored", (xt = Pt || (Pt = {}))[xt.Initial = 0] = "Initial", xt[xt.Set = 1] = "Set", xt[xt.Push = 2] = "Push", xt[xt.Unshift = 3] = "Unshift", (Mt = Rt || (Rt = {}))[Mt.Index = 1] = "Index", Mt[Mt.Cached = 2] = "Cached", (jt = Kt || (Kt = {})).GrantConsent = !0, jt.RevokeConsent = !1, (Ut = Ot || (Ot = {}))[0] = 0, Ut[1] = 1, (Lt = Nt || (Nt = {}))[0] = 0, Lt[1] = 1, Lt[2] = 2, Lt[3] = 3, Lt[4] = 4, Lt[5] = 5, Lt[6] = 6, Lt[7] = 7, Lt[8] = 8, Lt[9] = 9, (Ht = Ft || (Ft = {}))[0] = 0, Ht[1] = 1, Ht[2] = 2, (Bt = Dt || (Dt = {}))[0] = 0, Bt[1] = 1, Bt[2] = 2, Bt[3] = 3, Bt[4] = 4, (zt = Wt || (Wt = {}))[0] = 0, zt[1] = 1, zt[2] = 2, zt[3] = 3, zt[4] = 4, zt[5] = 5, zt[6] = 6, zt[7] = 7, zt[8] = 8, zt[9] = 9, zt[10] = 10, zt[11] = 11, zt[12] = 12, zt[13] = 13, zt[14] = 14, zt[15] = 15, (Vt = qt || (qt = {})).Timing = ["navigationStart", "unloadEventStart", "unloadEventEnd", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "secureConnectionStart", "requestStart", "responseStart", "responseEnd", "domLoading", "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart", "loadEventEnd"], Vt.Navigation = ["name", "startTime", "duration", "initiatorType", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "secureConnectionStart", "requestStart", "responseStart", "responseEnd", "unloadEventStart", "unloadEventEnd", "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart", "loadEventEnd", "type", "redirectCount", "decodedBodySize", "encodedBodySize", "transferSize", "activationStart"], Vt.Resource = ["name", "startTime", "duration", "initiatorType", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "secureConnectionStart", "requestStart", "responseStart", "responseEnd", "decodedBodySize", "encodedBodySize", "transferSize"], Vt.Measure = ["name", "startTime", "duration"], Vt.LongAnimationFrame = ["name", "startTime", "duration", "renderStart", "styleAndLayoutStart", "blockingDuration", "firstUIEventTimestamp"], Vt.ScriptTiming = ["name", "startTime", "duration", "invokerType", "invoker", "executionStart", "sourceURL", "sourceFunctionName", "sourceCharPosition", "pauseDuration", "forcedStyleAndLayoutDuration", "windowAttribution"], Vt.Memory = ["jsHeapSizeLimit", "totalJSHeapSize", "usedJSHeapSize"], Vt.TimeOrigin = ["timeOrigin"], Vt.LayoutShift = ["startTime", "value", "hadRecentInput"], Vt.FirstInput = ["name", "startTime", "duration", "processingStart"], Vt.EventTiming = ["name", "startTime", "duration", "processingStart", "processingEnd", "interactionId", "target"], Vt.LargestContentfulPaint = ["name", "startTime", "duration", "renderTime", "loadTime", "size", "element"], Vt.EventTimingCount = ["interactionCount"], (Gt = $t || ($t = {}))[0] = 0, Gt[1] = 1, Gt[2] = 2, Gt[3] = 3, Gt[4] = 4, Gt[5] = 5, Gt[7] = 7, Gt[8] = 8, Gt[9] = 9, Gt[10] = 10, Gt[11] = 11, Gt[12] = 12, Gt[13] = 13, Gt[14] = 14, Gt[15] = 15, Gt[16] = 16, Gt[17] = 17, Gt[18] = 18, Gt[19] = 19, (Xt = Qt || (Qt = {}))[1] = 1, Xt[2] = 2, (Yt = Jt || (Jt = {}))[0] = 0, Yt[1] = 1, (tn = Zt || (Zt = {})).Document = "document", tn.Event = "evt", tn.Page = "page", tn.Session = "session", tn.User = "user", (rn = nn || (nn = {})).FsId = "fsidentity", rn.NewUid = "newuid", (sn = en || (en = {}))[1] = 1, sn[2] = 2, sn[3] = 3, (un = on || (on = {}))[0] = 0, un[1] = 1, un[2] = 2, (cn = an || (an = {}))[0] = 0, cn[1] = 1, cn[2] = 2, (fn = hn || (hn = {}))[0] = 0, fn[1] = 1, fn[2] = 2, fn[3] = 3, (ln = vn || (vn = {}))[0] = 0, ln[1] = 1, (pn = dn || (dn = {}))[0] = 0, pn[1] = 1, pn[2] = 2, (wn = gn || (gn = {}))[1] = 1, wn[2] = 2, wn[3] = 3, wn[4] = 4, wn[5] = 5, wn[6] = 6, wn[7] = 7, wn[8] = 8, wn[9] = 9, wn[10] = 10, wn[11] = 11, wn[12] = 12, wn[13] = 13, wn[14] = 14, wn[15] = 15, wn[16] = 16, wn[17] = 17, wn[18] = 18, (yn = mn || (mn = {}))[0] = 0, yn[1] = 1, yn[2] = 2, yn[3] = 3, yn[4] = 4, yn[5] = 5, yn[6] = 6, yn[7] = 7, (Sn = bn || (bn = {}))[0] = 0, Sn[1] = 1, Sn[2] = 2, Sn[3] = 3, Sn[4] = 4, Sn[5] = 5, Sn[6] = 6, (kn = _n || (_n = {}))[0] = 0, kn[1] = 1, (An = In || (In = {}))[An.Page = 1] = "Page", An[An.Bundle = 2] = "Bundle", An[An.Settings = 8] = "Settings", (Cn = En || (En = {}))[Cn.Error = 3] = "Error", Cn[Cn.Page = 4] = "Page", Cn[Cn.Bundle = 5] = "Bundle", Cn[Cn.Settings = 9] = "Settings", (Pn = Tn || (Tn = {})).MaxPerfMarksPerPage = 16384, Pn[1024] = 1024, Pn[2048] = 2048, Pn[250] = 250, Pn[142] = 142, Pn[5e3] = 5e3, Pn.HeartbeatIntervalMS = 256200, Pn.PageInactivityTimeout = 18e5, Pn.BackoffMax = 3e5, Pn.ScrollSampleInterval = 50, Pn.SyntheticClickTimeout = Pn.ScrollSampleInterval + 5, Pn[4e3] = 4e3, Pn.MaxAjaxPayloadLength = 16384, Pn.DefaultOrgSettings = {
        MaxPerfMarksPerPage: Pn.MaxPerfMarksPerPage,
        MaxConsoleLogPerPage: 1024,
        MaxAjaxPayloadLength: Pn.MaxAjaxPayloadLength,
        MaxUrlLength: 2048,
        RecordPerformanceResourceImg: !0,
        RecordPerformanceResourceTiming: !0,
        HttpRequestHeadersAllowlist: [],
        HttpResponseHeadersAllowlist: [],
        UrlPrivacyConfig: [{
            Exclude: {
                Hash: [{
                    Expression: "#.*"
                }],
                QueryParam: [{
                    Expression: "(=)(.*)"
                }]
            }
        }],
        AttributeBlocklist: [{
            Target: 0,
            Tag: "*",
            Name: "",
            Type: 1,
            Action: 0
        }]
    }, Pn.DefaultStatsSettings = {
        MaxPayloadLength: 8192,
        MaxEventTypeLength: 1024
    }, Pn.BlockedFieldValue = "__fs__redacted", Pn.DefaultRecDisabledMessage = "Capture disabled. Turn on debug mode for more information.", Pn.ShutdownMessage = "Shutdown called.", Pn.TextPlain = "text/plain";
    var Rn, Mn, Kn, jn, On, Un, Nn, Ln, Fn, Hn, Dn = "_fs_trust_event",
        Bn = "__fs",
        Wn = "_fs_currentScript",
        zn = "data-fs-namespace",
        qn = "gzip",
        Vn = "identity";
    (Mn = Rn || (Rn = {}))[Mn.Inactive = 1] = "Inactive", Mn[Mn.Pending = 2] = "Pending", Mn[Mn.ShouldFlush = 3] = "ShouldFlush", (jn = Kn || (Kn = {}))[jn.Shutdown = 1] = "Shutdown", jn[jn.Starting = 2] = "Starting", jn[jn.Started = 3] = "Started", jn[jn.Fatal = 4] = "Fatal", (Un = On || (On = {}))[0] = 0, Un[1] = 1, (Ln = Nn || (Nn = {}))[Ln.Disabled = 0] = "Disabled", Ln[Ln.CaptureCanvasOps = 1] = "CaptureCanvasOps", Ln[Ln.ScreenshotCanvas = 2] = "ScreenshotCanvas", (Hn = Fn || (Fn = {})).EndPreviewMode = "EndPreviewMode", Hn.EvtBundle = "EvtBundle", Hn.GreetFrame = "GreetFrame", Hn.InitFrameMobile = "InitFrameMobile", Hn.RequestFrameId = "RequestFrameId", Hn.RestartFrame = "RestartFrame", Hn.SetConsent = "SetConsent", Hn.SetFrameId = "SetFrameId", Hn.ShutdownFrame = "ShutdownFrame", Hn.Unknown = "Unknown";
    var $n, Gn, Qn, Xn, Jn, Yn, Zn, ti, ni, ii, ri, ei, si, oi, ui, ai, ci, hi, fi, vi, li, di, pi, gi, wi, mi, yi, bi, Si = "_fs_dwell_passed";

    function _i(t) {
        try {
            return decodeURIComponent(t)
        } catch (n) {
            return t
        }
    }

    function ki(t, n) {
        if (!n) return null;
        var i, r = n.split("#");
        if (r.length < 3) return null;
        for (var e = 2; e < r.length; e++) {
            var s = r[e];
            if (s.indexOf("/") >= 0) {
                var u = s.split("/"),
                    a = u[0],
                    c = u[1];
                r[e] = a, i = c;
                break
            }
        }
        var h = function(t, n) {
            var i = parseInt(null != n ? n : "", 10),
                r = At(t),
                e = Et(t) + 86400;
            return isNaN(i) ? e : i <= r ? void 0 : i > e ? e : i
        }(t, i);
        if (!h) return null;
        r[0];
        var f = r[1],
            v = r[2],
            l = r[3],
            d = r[4],
            p = r[5],
            g = r[6],
            w = "";
        l && (w = decodeURIComponent(l), (st.indexOf(w) >= 0 || ot.indexOf(w) >= 0) && (o(function() {
            return "Ignoring invalid app key \"".concat(w, "\" from cookie.")
        }), w = ""));
        var m, y, b = (null != v ? v : "").split(":"),
            S = b[0],
            _ = b[1],
            k = b[2],
            I = (b[3], b[4]);
        d && (m = _i(d)), g && (y = _i(g));
        var A = function(t) {
                if (!t) return {};
                var n = t.split(":"),
                    i = n[0],
                    r = n[1];
                return {
                    state: Number(i),
                    activeTimeMs: r ? F(r) : void 0
                }
            }(p),
            E = A.state,
            C = A.activeTimeMs,
            T = function(t, n, i) {
                return t && 3 === n || t && void 0 === n ? {
                    sessionUid: void 0,
                    sessionUidState: 3,
                    discardedSessionUid: t
                } : {
                    sessionUid: t,
                    sessionUidState: n,
                    discardedSessionUid: i
                }
            }(m, E, y);
        return {
            appKeyHash: w,
            expirationAbsTimeSeconds: h,
            userId: S,
            orgId: f,
            pageCount: F(I),
            sessionId: null != _ ? _ : "",
            sessionStartTime: F(k),
            sessionUid: T.sessionUid,
            sessionUidState: T.sessionUidState,
            discardedSessionUid: T.discardedSessionUid,
            sessionUidActiveTimeMs: C
        }
    }(Gn = $n || ($n = {}))[Gn.LoadEvent = 0] = "LoadEvent", Gn[Gn.MessageEvent = 1] = "MessageEvent", Gn[Gn.UnloadEvent = 2] = "UnloadEvent", Gn[Gn.ApiEvent = 3] = "ApiEvent", Gn[Gn.AllowlistCheck = 4] = "AllowlistCheck", (Xn = Qn || (Qn = {}))[Xn.Ajax = 0] = "Ajax", Xn[Xn.Animation = 1] = "Animation", Xn[Xn.Canvas = 2] = "Canvas", Xn[Xn.Console = 3] = "Console", Xn[Xn.CustomElement = 4] = "CustomElement", Xn[Xn.Dialog = 5] = "Dialog", Xn[Xn.Fullscreen = 6] = "Fullscreen", Xn[Xn.Input = 7] = "Input", Xn[Xn.Perf = 8] = "Perf", Xn[Xn.StyleSheet = 9] = "StyleSheet", Xn[Xn.Select = 10] = "Select", Xn[Xn.Popover = 11] = "Popover", (Yn = Jn || (Jn = {}))[Yn.Scroll = 1] = "Scroll", Yn[Yn.Resize = 2] = "Resize", (ti = Zn || (Zn = {}))[ti.Exclude = 2] = "Exclude", ti[ti.Mask = 4] = "Mask", ti[ti.Unmask = 8] = "Unmask", ti[ti.Watch = 16] = "Watch", ti[ti.Keep = 32] = "Keep", ti[ti.Defer = 64] = "Defer", (ii = ni || (ni = {}))[ii.Immediate = 1] = "Immediate", ii[ii.Deferred = 2] = "Deferred", (ei = ri || (ri = {}))[ei.NoInfoYet = 1] = "NoInfoYet", ei[ei.Enabled = 2] = "Enabled", ei[ei.Disabled = 3] = "Disabled", (oi = si || (si = {}))[oi.Unknown = 0] = "Unknown", oi[oi.Clean = 1] = "Clean", oi[oi.Mixed = 2] = "Mixed", oi[oi.UnrecoverableFailure = 3] = "UnrecoverableFailure", (ai = ui || (ui = {}))[ai.Initial = 0] = "Initial", ai[ai.Set = 1] = "Set", ai[ai.Delete = 2] = "Delete", ai[ai.Push = 3] = "Push", ai[ai.Unshift = 4] = "Unshift", (hi = ci || (ci = {}))[hi.NoRetry = 0] = "NoRetry", hi[hi.Retry = 1] = "Retry", (vi = fi || (fi = {}))[vi.New = 0] = "New", vi[vi.Update = 1] = "Update", (di = li || (li = {}))[di.Windex = 0] = "Windex", di[di.NodeContext = 1] = "NodeContext", di[di.Mirror = 2] = "Mirror", di[di.Node = 3] = "Node", di[di.Attrs = 4] = "Attrs", di[di.Text = 5] = "Text", (gi = pi || (pi = {}))[gi.Idle = 0] = "Idle", gi[gi.Scheduled = 1] = "Scheduled", gi[gi.Processing = 2] = "Processing", (mi = wi || (wi = {}))[mi.CSS_INHERIT = 0] = "CSS_INHERIT", mi[mi.CSS_PRIMITIVE_VALUE = 1] = "CSS_PRIMITIVE_VALUE", mi[mi.CSS_VALUE_LIST = 2] = "CSS_VALUE_LIST", mi[mi.CSS_CUSTOM = 3] = "CSS_CUSTOM", (bi = yi || (yi = {}))[bi.CSS_UNKNOWN = 0] = "CSS_UNKNOWN", bi[bi.CSS_NUMBER = 1] = "CSS_NUMBER", bi[bi.CSS_PERCENTAGE = 2] = "CSS_PERCENTAGE", bi[bi.CSS_EMS = 3] = "CSS_EMS", bi[bi.CSS_EXS = 4] = "CSS_EXS", bi[bi.CSS_PX = 5] = "CSS_PX", bi[bi.CSS_CM = 6] = "CSS_CM", bi[bi.CSS_MM = 7] = "CSS_MM", bi[bi.CSS_IN = 8] = "CSS_IN", bi[bi.CSS_PT = 9] = "CSS_PT", bi[bi.CSS_PC = 10] = "CSS_PC", bi[bi.CSS_DEG = 11] = "CSS_DEG", bi[bi.CSS_RAD = 12] = "CSS_RAD", bi[bi.CSS_GRAD = 13] = "CSS_GRAD", bi[bi.CSS_MS = 14] = "CSS_MS", bi[bi.CSS_S = 15] = "CSS_S", bi[bi.CSS_HZ = 16] = "CSS_HZ", bi[bi.CSS_KHZ = 17] = "CSS_KHZ", bi[bi.CSS_DIMENSION = 18] = "CSS_DIMENSION", bi[bi.CSS_STRING = 19] = "CSS_STRING", bi[bi.CSS_URI = 20] = "CSS_URI", bi[bi.CSS_IDENT = 21] = "CSS_IDENT", bi[bi.CSS_ATTR = 22] = "CSS_ATTR", bi[bi.CSS_COUNTER = 23] = "CSS_COUNTER", bi[bi.CSS_RECT = 24] = "CSS_RECT", bi[bi.CSS_RGBCOLOR = 25] = "CSS_RGBCOLOR", bi[bi.CSS_VW = 26] = "CSS_VW", bi[bi.CSS_VH = 27] = "CSS_VH", bi[bi.CSS_VMIN = 28] = "CSS_VMIN", bi[bi.CSS_VMAX = 29] = "CSS_VMAX";
    var Ii, Ai, Ei, Ci, Ti = "_fs_loaded",
        Pi = "_fs_namespace",
        xi = "FS",
        Ri = Mi();

    function Mi(t) {
        var n;
        try {
            var i = null != t ? t : "undefined" != typeof window ? window : void 0;
            if (!i || void 0 === i.document) return;
            return (null === (n = ji(i)) || void 0 === n ? void 0 : n.getAttribute(zn)) || void 0
        } catch (t) {
            return
        }
    }

    function Ki(t) {
        return Mi(t) || Ri || function(t) {
            return t[Pi] || xi
        }(t)
    }

    function ji(t) {
        var n, i = t.document;
        return null !== (n = i.currentScript) && void 0 !== n ? n : i[Wn]
    }

    function Oi(t, n) {
        return void 0 === n && (n = Ki(t)), t[n]
    }

    function Ui(t, n) {
        return void 0 === n && (n = Ki(t)), t[n]
    }

    function Ni(t, n) {
        return n in t && "function" == typeof t[n]
    }

    function Li(t, n, i) {
        void 0 === i && (i = "string");
        var r = t[n];
        if (typeof r === i) return r
    }

    function Fi(t) {
        return Li(t, "_fs_ext_host") || Li(t, "_fs_host")
    }

    function Hi(t) {
        return Li(t, "_fs_script")
    }

    function Di(t) {
        return Li(t, "_fs_rec_host")
    }

    function Bi(t) {
        return Li(t, "_fs_rec_settings_host")
    }

    function Wi(t) {
        return Li(t, "_fs_app_host")
    }

    function zi(t) {
        return Li(t, "_fs_ext_org") || Li(t, "_fs_org")
    }

    function qi(t) {
        var n = Li(t, "_fs_capture_on_startup", "boolean"),
            i = Li(t, "_fs_capture_on_start", "boolean");
        return void 0 === n ? void 0 === i || !i : n
    }

    function Vi(t) {
        return Li(t, "_fs_asset_map_id")
    }

    function $i(t) {
        return Li(t, "_fs_cookie_domain")
    }

    function Gi(t) {
        return Li(t, "_fs_ready", "function")
    }

    function Qi(t) {
        return !!Li(t, "_fs_run_in_iframe", "boolean")
    }

    function Xi(t) {
        return !!Li(t, "_fs_is_outer_script", "boolean")
    }

    function Ji(t) {
        return Li(t, "_fs_replay_flags")
    }

    function Yi(t) {
        return Li(t, "_fs_transport", "object")
    }

    function Zi(t) {
        return Li(t, "_fs_pagestart", "function")
    }

    function tr(t) {
        return !!Li(t, "_fs_use_socket", "boolean")
    }

    function nr(t) {
        return !!Li(t, "_fs_use_mock_protocol", "boolean")
    }

    function ir(t) {
        return Li(t, "_fs_use_webworker", "boolean")
    }

    function rr(t) {
        return !!Li(t, "_fs_use_polyfilled_apis", "boolean")
    }

    function er(t) {
        return !!Li(t, "_fs_force_local_resources", "boolean")
    }

    function sr(t) {
        return Li(t, "_fs_request", "function")
    }

    function or(t) {
        return Li(t, "_fs_beacon", "function")
    }

    function ur(t) {
        return Li(t, "_fs_settings", "object")
    }

    function ar(t) {
        return Li(t, "_fs_clientstore", "object")
    }

    function cr(t) {
        return Li(t, "_fs_identitystore", "object")
    }

    function hr(t) {
        return Li(t, "_fs_multistorage", "object")
    }

    function fr(t) {
        return Li(t, "_fs_is_wayfinder", "boolean")
    }

    function vr(t) {
        return Li(t, "_fs_disable_resume", "boolean")
    }

    function lr(t) {
        return pr(t, "_fs_enable_predictions")
    }

    function dr(t) {
        return pr(t, "_fs_enable_data_layer")
    }

    function pr(t, n) {
        var i = Li(t, n, "boolean");
        if (void 0 !== i) return i;
        var r = Li(t, n);
        return "true" === r || "false" !== r && void 0
    }

    function gr(t) {
        return Li(t, "_fs_scrub_nav_light", "boolean")
    }

    function wr(t) {
        return !!Li(t, "_fs_skip_iframe_injection", "boolean")
    }

    function mr(t) {
        return !!Li(t, "_fs_clean_value_getter", "boolean")
    }

    function yr(t) {
        return Li(t, "_fs_network_budget", "number")
    }

    function br(t) {
        var n, i = t._fs_prehooks;
        if ((n = i) instanceof WeakMap || n && Ni(n, "get") && Ni(n, "set") && Ni(n, "has") && Ni(n, "delete")) return i
    }

    function Sr(t) {
        return Li(t, "_fs_delay_on_interaction", "boolean")
    }

    function _r(t, n) {
        var i = Oi(t, n);
        if (!i) return [];
        var r = i.q;
        return r ? (delete i.q, r) : []
    }

    function kr(t, n, i) {
        var r = Oi(t, i);
        if (r) {
            var e = r.q;
            e || (e = r.q = []), e.push(n)
        }
    }

    function Ir(t, n) {
        var i = Oi(t, n);
        return (null == i ? void 0 : i._v) || "unknown"
    }

    function Ar(t, n, i) {
        if (i && "string" != typeof Li(t, n)) try {
            Object.defineProperty(t, n, {
                value: i,
                writable: !1,
                configurable: !1,
                enumerable: !0
            })
        } catch (t) {}
    }

    function Er(t, n) {
        var i, r = Oi(t, n);
        return null !== (i = null == r ? void 0 : r._native) && void 0 !== i && i
    }

    function Cr(t) {
        return "localhost" == t || "127.0.0.1" == t
    }(Ai = Ii || (Ii = {})).Consent = "consent", Ai.Log = "log", Ai.Record = "rec", (Ci = Ei || (Ei = {})).Event = "event", Ci.Page = "page", Ci.Vars = "setVars", Ci.User = "user";
    var Tr = /^([^.]+\.)*(fullstory|onfire).[^.]+(\/|$)/;

    function Pr(t) {
        return Rr(t, "edge")
    }
    var xr = ["rs", "rs-2", "edge", "www", "app"];

    function Rr(t) {
        for (var n = [], i = 1; i < arguments.length; i++) n[i - 1] = arguments[i];
        if (!t) return t;
        if (!Tr.test(t)) return t;
        if (n.some(function(n) {
                return 0 === t.lastIndexOf("".concat(n, "."), 0)
            })) return t;
        for (var r = n[0], e = 0, s = xr; e < s.length; e++) {
            var o = s[e];
            if (0 === t.lastIndexOf("".concat(o, "."), 0)) return "".concat(r, ".").concat(t.slice("".concat(o, ".").length))
        }
        return "".concat(r, ".").concat(t)
    }

    function Mr(t) {
        return Tr.test(t)
    }

    function Kr(t) {
        return /(^|\.)fullstory\.test(:\d+)?$/i.test(t)
    }

    function jr(t, n) {
        var i = t;
        if (i) {
            if (!n || !Mr(i) || Kr(i)) return i;
            var r = "";
            return 0 === i.indexOf("www.") && (i = i.slice(4), r = "www."), 0 === i.indexOf("".concat(n, ".")) && (i = i.slice("".concat(n, ".").length)), "".concat(r).concat(n, ".").concat(i)
        }
    }

    function Or(t, n) {
        if (!t || !n) return t;
        var i = t.indexOf("/"),
            r = -1 === i ? t : t.slice(0, i),
            e = -1 === i ? "" : t.slice(i);
        if (!Mr(r) || Kr(r)) return t;
        for (var s = "", o = r, u = 0, a = xr; u < a.length; u++) {
            var c = a[u];
            if (0 === o.lastIndexOf("".concat(c, "."), 0)) {
                s = "".concat(c, "."), o = o.slice(s.length);
                break
            }
        }
        return "".concat(s).concat(jr(o, n)).concat(e)
    }

    function Ur(t) {
        var n, i = null !== (n = null == t ? void 0 : t.split("-")) && void 0 !== n ? n : [];
        if (!(i.length < 3)) {
            var r = i[0],
                e = i[i.length - 1];
            if ("na1" !== e && r && !(r.length > 1)) return e
        }
    }

    function Nr(t, n) {
        return t ? Mr(t) || Cr(function(t) {
            var n = t,
                i = n.indexOf(":");
            return i >= 0 && (n = n.slice(0, i)), n
        }(t)) ? Rr(t, "app") : Rr(jr("fullstory.com", n), "app") : t
    }

    function Lr(t) {
        return t()
    }

    function Fr(t) {
        var n = Pr(t);
        if (n) return "".concat(n, "/s/fs.js")
    }

    function Hr(t, n) {
        var i = Ur(t),
            r = jr(n.host || "fullstory.com", i);
        return {
            host: r,
            appHost: Dr("appHost", n.appHost, i, function() {
                return Nr(r, i)
            }),
            recHost: Dr("recHost", n.recHost, i, function() {
                return function(t) {
                    return Rr(t, "rs", "rs-2")
                }(r)
            }),
            recSettingsHost: Dr("recSettingsHost", n.recSettingsHost, i, function() {
                return Pr(r)
            }),
            script: Dr("script", n.script, i, function() {
                return Fr(r)
            })
        }
    }

    function Dr(t, n, i, r) {
        if (!n) return r();
        var e = Or(n, i);
        return e !== n && o(function() {
            return "Realm-corrected ".concat(t, ": \"").concat(n, "\" -> \"").concat(e, "\"")
        }), e
    }

    function Br(t, n, i) {
        return t(n, i)
    }

    function Wr(t) {
        return function(n, i) {
            if ("function" == typeof t.navigator.sendBeacon) try {
                return t.navigator.sendBeacon(n, i.data)
            } catch (t) {}
            return !1
        }
    }

    function zr(t) {
        var n = "Internal error: unable to determine what JSON error was";
        try {
            n = (n = "".concat(t)).replace(/[^a-zA-Z0-9.:!, ]/g, "_")
        } catch (t) {}
        return "\"".concat(n, "\"")
    }

    function qr(t, n, i, r) {
        function e(n, i) {
            var r = 0;
            try {
                t(n, function(t, n) {
                    if (r++ > i) throw "break";
                    if ("object" == typeof n) return n
                })
            } catch (t) {
                return "break" != t
            }
            return !1
        }
        var s = function(t, n, i) {
            return void 0 === i && (i = "..."), t.length <= n ? t : t.length <= i.length || n <= i.length ? t.substring(0, n) : t.substring(0, n - i.length) + i
        };

        function o(e, u, a, c) {
            if (u < 1) return 0;
            var h = function(t) {
                switch (!0) {
                    case
                    function(t) {
                        return !(!t || t.constructor != Date)
                    }(t):
                        return n = t, isNaN(n) ? "Invalid Date" : n.toUTCString();
                    case
                    function(t) {
                        return "object" == typeof Node ? t instanceof Node : t && "object" == typeof t && t.nodeType > 0 && "string" == typeof t.nodeName
                    }(t):
                        return function(t) {
                            return t.toString()
                        }(t);
                    case void 0 === t:
                        return "undefined";
                    case "object" != typeof t || null == t:
                        return t;
                    case t instanceof Error:
                        return [t.toString(), t.stack].filter(Boolean).join(",")
                }
                var n
            }(e);
            if (void 0 !== h) {
                var f = function(n, i) {
                    var r = t(n);
                    return r && "\"" == r[0] ? s(r, i, "...\"") : r
                }(h, u);
                return "string" == typeof f && f.length <= u ? (c.tokens.push(f), f.length) : 0
            }
            if (c.cyclic) {
                c.opath.splice(a);
                var v = c.opath.lastIndexOf(e);
                if (v > -1) {
                    var l = a - v - 1,
                        d = (null == r ? void 0 : r.onCircular) ? r.onCircular(l) : "<Cycle to ancestor #".concat(l, ">");
                    return d = "\"".concat(s(d, u - 2), "\""), c.tokens.push(d), d.length
                }
                c.opath.push(e)
            }
            var p = u,
                g = function(t) {
                    return p >= t.length && (p -= t.length, c.tokens.push(t), !0)
                },
                w = function(t) {
                    var n = c.tokens.length - 1;
                    "," === c.tokens[n] ? c.tokens[n] = t : g(t)
                };
            if (p < 2) return 0;
            if (n(e)) {
                g("[");
                for (var m = 0; m < e.length && p > 0; m++) {
                    var y = o(e[m], p - 1, a + 1, c);
                    if (p -= y, 0 == y && !g("null")) break;
                    g(",")
                }
                w("]")
            } else {
                g("{");
                var b = i(e);
                for (m = 0; m < b.length && p > 0; m++) {
                    var S = b[m],
                        _ = e[S];
                    if (!g("\"".concat(S, "\":"))) break;
                    if (0 == (y = o(_, p - 1, a + 1, c))) {
                        c.tokens.pop();
                        break
                    }
                    p -= y, g(",")
                }
                w("}")
            }
            return u == 1 / 0 ? 1 : u - p
        }
        return function(t, n) {
            void 0 === n && (n = 1024);
            try {
                var i = {
                    tokens: [],
                    opath: [],
                    cyclic: e(t, n / 4)
                };
                return o(t, n, 0, i), i.tokens.join("")
            } catch (t) {
                return zr(t)
            }
        }
    }

    function Vr(t, n) {
        var i = Xr(t, n),
            r = i[0];
        return i[1] || r
    }

    function $r(t, n) {
        if (n in t) {
            var i = t[n];
            if ("number" == typeof i) return i
        }
        return 0
    }

    function Gr(t, n, r, e) {
        void 0 === r && (r = {}), void 0 === e && (e = "stringifyRawEventError");
        var s = H(n),
            o = s ? $r(n, "When") : 0,
            u = s ? $r(n, "Kind") : 0;
        return i({
            When: o,
            Kind: 113,
            Args: [Vr(t, {
                Name: e,
                Kind: u,
                err: r
            })]
        }, s && {
            PIds: n.PIds,
            FId: n.FId
        })
    }

    function Qr(t, n) {
        var i, r = Xr(t, n),
            e = r[0],
            s = r[1];
        return s ? (e = (i = Xr(t, Gr(t, n, s)))[0], (s = i[1]) ? Vr(t, Gr(t, void 0, s)) : e) : e
    }

    function Xr(t, n) {
        var i, r = Object.getOwnPropertyDescriptor(Array.prototype, "toJSON"),
            e = Object.getOwnPropertyDescriptor(String.prototype, "toJSON"),
            s = void 0;
        try {
            r && r.value && r.configurable && delete Array.prototype.toJSON, e && e.value && e.configurable && delete String.prototype.toJSON, i = t.jsonStringify(n)
        } catch (t) {
            i = "", s = zr(t)
        } finally {
            (null == r ? void 0 : r.value) && I(function() {
                return Object.defineProperty(Array.prototype, "toJSON", r)
            })(), (null == e ? void 0 : e.value) && I(function() {
                return Object.defineProperty(String.prototype, "toJSON", e)
            })()
        }
        return [i, s]
    }
    var Jr = {
            Ver: "9177873e332ed500eceb15ab9a0ab6d2fa758635",
            TS: 1791603930
        },
        Yr = /function\s*([\w\-$]+)?\s*\(/i;

    function Zr(t) {
        return t.stack || t.backtrace || t.stacktrace
    }

    function te() {
        var t, n;
        try {
            throw new Error("")
        } catch (i) {
            t = "<generated>\n", n = Zr(i)
        }
        if (!n) {
            t = "<generated-ie>\n";
            var i = [];
            try {
                for (var r = arguments.callee.caller.caller; r && i.length < 10;) {
                    var e = Yr.test(r.toString()) && RegExp.$1 || "[anonymous]";
                    i.push(e), r = r.caller
                }
            } catch (t) {
                o(function() {
                    return t.toString()
                })
            }
            n = i.join("\n")
        }
        return t + n
    }

    function ne() {
        try {
            return window.self !== window.top
        } catch (t) {
            return !0
        }
    }
    var ie = function() {
        function t(n, i) {
            var r = this;
            this.t = n, this.i = i, this.send = function(n, i, e) {
                if (void 0 === i && (i = {}), void 0 === e && (e = "error"), !(t.o <= 0 || (t.o--, r.i.useMockProtocol))) {
                    var s = r.h(n, e, i);
                    Br(r.i.beaconFn, s, {
                        data: "",
                        type: "string"
                    }) || (new Image().src = s)
                }
            }
        }
        return t.prototype.wrap = function(t, n, r) {
            var e = this;
            return void 0 === r && (r = {}), I(t, function(t) {
                e.send(n, i({
                    err: t
                }, r))
            })
        }, t.prototype.updateCfg = function(t) {
            this.i = i(i({}, this.i), t)
        }, t.prototype.h = function(t, n, i) {
            var r;
            void 0 === i && (i = {});
            var e = function(t) {
                    return H(t) && "message" in t && "name" in t
                }(i.err) ? i.err : new Error(t),
                s = t || e.message || "".concat(null !== (r = i.err) && void 0 !== r ? r : "") || "unknown error";
            e.message !== s && (i.msg = e.message);
            var o = this.i.userId && this.i.sessionId ? "".concat(this.i.userId, ":").concat(this.i.sessionId) : "NA",
                u = this.i.getLanguage(),
                a = Array.isArray(u) ? u.join(",") : u,
                c = {
                    projectRoot: this.i.origin,
                    deviceTime: ft(this.t),
                    inIframe: this.i.inFrame,
                    CompiledVersion: Jr.Ver,
                    CompiledTimestamp: Jr.TS,
                    orgId: this.i.orgId,
                    "userId:sessionId": o,
                    context: this.i.getPathname(),
                    message: s,
                    severity: n,
                    language: a,
                    stacktrace: Zr(e) || te()
                },
                h = function(t, n, i) {
                    var r = "".concat(encodeURIComponent(n), "=").concat(encodeURIComponent(i));
                    t.push(r)
                },
                f = [];
            for (var v in c) h(f, v, c[v] || "");
            for (var v in i) {
                var l = re(this.t, i[v]);
                h(f, "aux_".concat(v), l)
            }
            return "https://".concat(this.i.recHost, "/rec/except?").concat(f.join("&"))
        }, t.o = 15, t
    }();

    function re(t, n) {
        try {
            var i = typeof n;
            switch (i) {
                case "string":
                case "number":
                case "boolean":
                case "undefined":
                    return "".concat(n);
                default:
                    var r = "".concat(i, ": ").concat(Vr(t, n));
                    return "function" == typeof n.toString && (r += " (toString: ".concat(n.toString(), ")")), r
            }
        } catch (t) {
            return "failed to serialize \"".concat(null == t ? void 0 : t.message, "\"")
        }
    }
    var ee, se = {
        dateNow: function() {
            return Date.now()
        },
        dateGetTime: function() {
            return new Date().getTime()
        },
        arrayIsArray: function(t) {
            return Array.isArray(t)
        },
        jsonStringify: function(t) {
            return JSON.stringify(t)
        },
        mathFloor: function(t) {
            return Math.floor(t)
        },
        mathMin: function() {
            for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
            return Math.min.apply(Math, t)
        }
    };

    function oe() {
        return ee || (ee = new ie(se, function(t) {
            var n, i;
            try {
                var r = k(document).fs_uid,
                    e = zi(window),
                    s = r ? ki(t, r) : void 0;
                return s && s.orgId != e && (s = void 0), {
                    beaconFn: null !== (n = or(window)) && void 0 !== n ? n : Wr(window),
                    getPathname: function() {
                        var t;
                        return null === (t = document.location) || void 0 === t ? void 0 : t.pathname
                    },
                    inFrame: ne(),
                    getLanguage: function() {
                        return it(t, window) || "en"
                    },
                    orgId: null != e ? e : "",
                    origin: (null === (i = window.location) || void 0 === i ? void 0 : i.origin) || "",
                    recHost: Hr(e, {
                        host: Fi(window),
                        recHost: Di(window)
                    }).recHost || "rs.fullstory.com",
                    sessionId: null == s ? void 0 : s.sessionId,
                    useMockProtocol: nr(window) || !1,
                    userId: null == s ? void 0 : s.userId
                }
            } catch (t) {
                return {
                    beaconFn: function() {
                        return !1
                    },
                    getPathname: function() {
                        return ""
                    },
                    getLanguage: function() {
                        return "en"
                    },
                    inFrame: !1,
                    orgId: "",
                    recHost: "rs.fullstory.com",
                    useMockProtocol: !1
                }
            }
        }(se))), ee
    }
    var ue = {};

    function ae(t, n, i) {
        return void 0 === i && (i = 1), !!t || (ue[n] = ue[n] || 0, ue[n]++, !(ue[n] > i) && (oe().send("Assertion failed: ".concat(n)), t))
    }
    var ce = {};

    function he(t, n) {
        var i;
        void 0 === n && (n = {}), ce[t] = null !== (i = ce[t]) && void 0 !== i ? i : 0, ce[t]++, ce[t] > 1 || oe().send(t, n)
    }

    function fe(t, n, i) {
        return void 0 === i && (i = {}), oe().wrap(t, n, i)
    }

    function ve(t, n, i) {
        return void 0 === n && (n = {}), void 0 === i && (i = "error"), oe().send(t, n, i)
    }
    var le = navigator.userAgent,
        de = le.indexOf("MSIE ") > -1 || le.indexOf("Trident/") > -1,
        pe = (de && le.indexOf("Trident/5"), de && le.indexOf("Trident/6"), de && le.indexOf("rv:11") > -1),
        ge = le.indexOf("Edge/") > -1,
        we = le.indexOf("Opera/") > -1,
        me = (le.indexOf("CriOS"), le.indexOf("Snapchat") > -1),
        ye = /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent),
        be = /^((?!chrome|android).)*(safari)/i.test(window.navigator.userAgent),
        Se = ye || be;

    function _e() {
        var t = window.navigator.userAgent.match(/Version\/(\d+)/);
        return t && t[1] ? parseInt(t[1], 10) : -1
    }

    function ke(t) {
        if (!Se) return !1;
        var n = _e();
        return n >= 0 && n === t
    }

    function Ie(t) {
        if (!Se) return !1;
        var n = _e();
        return n >= 0 && n < t
    }
    var Ae = ke(9),
        Ee = (ke(10), Ie(8));

    function Ce(t, n) {
        for (var i = 0 === n.indexOf("on") ? function(t) {
                return "on".concat(t).concat(n.slice(2))
            } : function(t) {
                return "".concat(t).concat(n.charAt(0).toUpperCase()).concat(n.slice(1))
            }, r = 0, e = [function() {
                return n
            }, function() {
                return i("webkit")
            }, function() {
                return i("moz")
            }, function() {
                return i("ms")
            }]; r < e.length; r++) {
            var s = (0, e[r])();
            if (s in t) return s
        }
        return n
    }

    function Te(t, n) {
        var i;
        if (void 0 === n && (n = 0), !t) return !1;
        try {
            t.call(function() {})
        } catch (t) {
            return !1
        }
        var r = function(t) {
                try {
                    return void t.call(null)
                } catch (t) {
                    return (t.stack || "").replace(/__fs_nomangle_check_stack(.|\n)*$/, "")
                }
            },
            e = void 0;
        0 !== n && "number" == typeof Error.stackTraceLimit && (e = Error.stackTraceLimit, Error.stackTraceLimit = Number.POSITIVE_INFINITY);
        var s = [function() {
                throw new Error("")
            }, t],
            o = function __fs_nomangle_check_stack() {
                return s.map(r)
            }(),
            u = o[0],
            a = o[1];
        if (void 0 !== e && (Error.stackTraceLimit = e), !u || !a) return !1;
        for (var c = "\n".charCodeAt(0), h = u.length > a.length ? a.length : u.length, f = 1, v = f; v < h; v++) {
            var l = u.charCodeAt(u.length - v),
                d = a.charCodeAt(a.length - v);
            if (l != d) break;
            d != c && v != h - 1 || (f = v)
        }
        return (null !== (i = a.slice(0, a.length - f + 1).match(/\.js:\d+([:)]|$)/gm)) && void 0 !== i ? i : []).length <= n
    }
    Ie(10), Ie(12);
    var Pe = "[native code]";

    function xe(t, n) {
        try {
            return t.call(n).indexOf(Pe) >= 0
        } catch (t) {
            return !1
        }
    }
    var Re = "__zone_symbol__OriginalDelegate",
        Me = [Re, "nr@original"];

    function Ke(t, n) {
        return je(t, n)[0]
    }

    function je(t, n, i) {
        void 0 === i && (i = !1);
        var r = [];
        if (!n) return [void 0, r];
        for (var e = 0, s = Me; e < s.length; e++) {
            var o = n[s[e]];
            if ((L(o) || i && H(o)) && (r.push(o), xe(t, o))) return [o, r]
        }
        return xe(t, n) ? [n, r] : [void 0, r]
    }

    function Oe(t, n, i) {
        if ("arrayIsArray" === i) {
            var r = Ke(t, n.objectToString);
            if (!r) return;
            return n.objectToString = r,
                function(t) {
                    return "[object Array]" == r.call(t)
                }
        }
    }
    var Ue = "_fs_weak_map_key",
        Ne = function() {
            function t(t, n) {
                void 0 === n && (n = !1), this.v = n, this.S = new WeakMap(t)
            }
            return t.prototype.get = function(t) {
                return this.v || !this.S.has(t) ? this.S.get(Le(t)) : this.S.get(t)
            }, t.prototype.set = function(t, n) {
                if (!this.v) try {
                    return this.S.set(t, n), this
                } catch (t) {}
                return this._(t, n)
            }, t.prototype._ = function(t, n) {
                return t[Ue] = Le(t), this.S.set(t[Ue], n), this
            }, t.prototype["delete"] = function(t) {
                return this.S["delete"](t) || this.S["delete"](Le(t))
            }, t.prototype.has = function(t) {
                return this.S.has(t) || this.S.has(Le(t))
            }, t
        }();

    function Le(t) {
        return Object.prototype.hasOwnProperty.call(t, Ue) ? t[Ue] : {}
    }
    var Fe = function() {
        function t(t, n, i, r) {
            var e;
            void 0 === i && (i = !1), this.k = t, this.I = n, this.A = i, this.C = r, this.T = A, this.P = void 0, this.R = A, this.M = A, this.K = !1, this.j = null === (e = r.options.preHooks) || void 0 === e ? void 0 : e.get(t)
        }
        return t.prototype.before = function(t) {
            return this.T = J(t), this
        }, t.prototype.replaceSync = function(t) {
            return this.P = J(t), this
        }, t.prototype.afterSync = function(t) {
            return this.j ? this.R = He(this.C.wdx, this.C.window, t) : this.R = J(t), this
        }, t.prototype.afterAsync = function(t) {
            return this.M = He(this.C.wdx, this.C.window, t), this
        }, t.prototype.disable = function() {
            if (this.K = !1, this.O) {
                var t = this.O,
                    n = t.override,
                    i = t["native"];
                this.j && this.j[this.I] === n ? (delete this.j[this.I], this.O = void 0) : this.k[this.I] === n && (this.k[this.I] = i, this.O = void 0)
            }
        }, t.prototype.enable = function() {
            if (this.K = !0, this.O) return !0;
            if (this.O = this.U(), this.j) this.j[this.I] = this.O.override;
            else try {
                this.k[this.I] = this.O.override
            } catch (t) {
                return !1
            }
            return !0
        }, t.prototype.getTarget = function() {
            return this.k
        }, t.prototype.U = function() {
            var t = this,
                n = this,
                r = this.k[this.I],
                e = function() {
                    for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                    var s, o = {
                        that: this,
                        args: t,
                        result: null
                    };
                    return n.K && n.T(o), n.j || (s = n.P ? n.P(i(i({}, o), {
                        origFn: r
                    })) : r.apply(this, t), o.result = s), n.K && (n.R(o), n.M(o)), o.result
                };
            return this.A && (e.toString = function() {
                var n;
                return "function ".concat(null !== (n = t.I) && void 0 !== n ? n : "", "() { ").concat(Pe, " }")
            }), {
                "native": r,
                override: e
            }
        }, t
    }();

    function He(t, n, i) {
        return J(function(r) {
            t.setWindowTimeout(n, I(function() {
                i(r)
            }), 0)
        })
    }
    var De = {};

    function Be(t, n, i, r) {
        var e;
        if (void 0 === r && (r = !1), !n || "function" != typeof n[i]) return null;
        De[i] = null !== (e = De[i]) && void 0 !== e ? e : new Ne;
        var s = De[i].get(n);
        return s || (s = new Fe(n, i, r, t), De[i].set(n, s)), s.enable() ? s : null
    }

    function We(t) {
        var n = t.target,
            i = t.type,
            r = t.fn,
            e = t.options;
        void 0 !== r && null != n && ("function" == typeof n.addEventListener ? n.addEventListener(i, r, e) : "function" == typeof n.addListener ? n.addListener(r) : o(function() {
            return "Target of ".concat(i, " doesn't seem to support listeners")
        }))
    }

    function ze(t) {
        var n = t.target,
            i = t.type,
            r = t.fn,
            e = t.options;
        void 0 !== r && null != n && ("function" == typeof n.removeEventListener ? n.removeEventListener(i, r, e) : "function" == typeof n.removeListener ? n.removeListener(r) : o(function() {
            return "Target of ".concat(i, " doesn't seem to support listeners")
        }))
    }

    function qe(t) {
        t.target && (ze(t), t.target = null, t.fn = void 0)
    }
    var Ve = function() {
        function t() {
            var t = this;
            this.N = [], this.L = [], this.F = !0, this.H = !1;
            try {
                var n = Object.defineProperty({}, "passive", {
                    get: function() {
                        t.F = {
                            capture: !0,
                            passive: !0
                        }, t.H = {
                            capture: !1,
                            passive: !0
                        }
                    }
                });
                window.addEventListener("test", A, n)
            } catch (t) {}
        }
        return t.prototype.add = function(t, n, i, r, e) {
            return void 0 === e && (e = !1), this.addCustom(t, n, i, r, e)
        }, t.prototype.addCustom = function(t, n, i, r, e) {
            void 0 === e && (e = !1);
            var s = {
                target: t,
                type: n,
                fn: fe(X(function(t) {
                    (e || !1 !== t.isTrusted || "message" == n || t[Dn]) && r(t)
                }), "domlistener#custom", {
                    type: n
                }),
                options: i ? this.F : this.H
            };
            return this.N.push(s), We(s), s
        }, t.prototype.detach = function(t) {
            var n = this.N.indexOf(t);
            n >= 0 && (qe(t), this.N.splice(n, 1))
        }, t.prototype.clearAll = function() {
            for (var t = 0, n = this.N; t < n.length; t++) qe(n[t]);
            this.N = [];
            for (var i = 0, r = this.L; i < r.length; i++) r[i].clearAll();
            this.L = []
        }, t.prototype.clearChild = function(t) {
            var n = this.D(t);
            null == n || n.clearAll(), ae(!!n, "clearChild")
        }, t.prototype.createChild = function() {
            var n = new t;
            return this.L.push(n), n
        }, t.prototype.refresh = function() {
            for (var t = 0, n = this.N; t < n.length; t++) {
                var i = n[t];
                i.target && (ze(i), We(i))
            }
            for (var r = 0, e = this.L; r < e.length; r++) e[r].refresh()
        }, t.prototype.D = function(t) {
            var n = this.L.indexOf(t);
            if (n > -1) return this.L.splice(n, 1)[0]
        }, t
    }();

    function $e(t, n) {
        return n && t.pageLeft == n.pageLeft && t.pageTop == n.pageTop
    }

    function Ge(t, n) {
        return n && t.width == n.width && t.height == n.height
    }

    function Qe(t) {
        return {
            pageLeft: t.pageLeft,
            pageTop: t.pageTop,
            width: t.width,
            height: t.height
        }
    }
    var Xe = [
            ["@import\\s+\"", "\""],
            ["@import\\s+'", "'"]
        ].concat([
            ["url\\(\\s*\"", "\"\\s*\\)"],
            ["url\\(\\s*'", "'\\s*\\)"],
            ["url\\(\\s*", "\\s*\\)"]
        ]),
        Je = ".*?".concat(/(?:[^\\](?:\\\\)*)/.source),
        Ye = new RegExp(Xe.map(function(t) {
            var n = t[0],
                i = t[1];
            return "(".concat(n, ")(").concat(Je, ")(").concat(i, ")")
        }).join("|"), "g"),
        Ze = /url\(["']?(.+?)["']?\)/g,
        ts = /^\s*\/\//,
        ns = /[-\\^$*+?.()|[\]{}]/g,
        is = new RegExp(ns.source);

    function rs(t) {
        return "BackCompat" == t.compatMode
    }

    function es(t) {
        return t && t.body && t.documentElement ? rs(t) ? [t.body.clientWidth, t.body.clientHeight] : [t.documentElement.clientWidth, t.documentElement.clientHeight] : [0, 0]
    }
    var ss = function() {
        function t(t, n, i) {
            var r, e, s, o;
            this.hasKnownPosition = !1, this.pageLeft = 0, this.pageTop = 0, this.width = 0, this.height = 0, this.clientWidth = 0, this.clientHeight = 0;
            var u = n.document;
            if (u && u.documentElement && u.body) {
                r = es(u), this.clientWidth = r[0], this.clientHeight = r[1];
                var a = n.visualViewport;
                if (a) {
                    this.hasKnownPosition = !0, this.pageTop = a.pageTop - a.offsetTop, this.pageLeft = a.pageLeft - a.offsetLeft, 0 == this.pageTop && (this.pageTop = 0), 0 == this.pageLeft && (this.pageLeft = 0);
                    var c = null !== (s = cs(n, "innerWidth")) && void 0 !== s ? s : 0,
                        h = null !== (o = cs(n, "innerHeight")) && void 0 !== o ? o : 0;
                    if (c > 0 && h > 0) return this.width = c, void(this.height = h)
                }
                if (void 0 !== i && this.clientWidth == i.clientWidth && this.clientHeight == i.clientHeight && i.width > 0 && i.height > 0) return this.width = i.width, void(this.height = i.height);
                e = this.B(t, n), this.width = e[0], this.height = e[1]
            }
        }
        return t.prototype.B = function(t, n) {
            var i = os(t, n, "width", this.clientWidth, this.clientWidth + 128);
            void 0 === i && (i = cs(n, "innerWidth")), void 0 === i && (i = this.clientWidth);
            var r = os(t, n, "height", this.clientHeight, this.clientHeight + 128);
            return void 0 === r && (r = cs(n, "innerHeight")), void 0 === r && (r = this.clientHeight), [i, r]
        }, t
    }();

    function os(t, n, i, r, e) {
        if (t.matchMedia) {
            var s = r,
                o = e,
                u = t.matchMedia(n, "(min-".concat(i, ": ").concat(s, "px)"));
            if (null != u) {
                if (u.matches && t.matchMedia(n, "(max-".concat(i, ": ").concat(s, "px)")).matches) return s;
                for (; s <= o;) {
                    var a = t.mathFloor((s + o) / 2);
                    if (t.matchMedia(n, "(min-".concat(i, ": ").concat(a, "px)")).matches) {
                        if (t.matchMedia(n, "(max-".concat(i, ": ").concat(a, "px)")).matches) return a;
                        s = a + 1
                    } else o = a - 1
                }
            }
        }
    }

    function us(t, n, i) {
        return new ss(t, n, i)
    }
    var as = function(t, n) {
        this.offsetLeft = 0, this.offsetTop = 0, this.pageLeft = 0, this.pageTop = 0, this.width = 0, this.height = 0, this.scale = 0;
        var i = t.document;
        if (i.body) {
            "pageXOffset" in t ? (this.pageLeft = t.pageXOffset, this.pageTop = t.pageYOffset) : i.scrollingElement ? (this.pageLeft = i.scrollingElement.scrollLeft, this.pageTop = i.scrollingElement.scrollTop) : rs(i) ? (this.pageLeft = i.body.scrollLeft, this.pageTop = i.body.scrollTop) : i.documentElement && (i.documentElement.scrollLeft > 0 || i.documentElement.scrollTop > 0) ? (this.pageLeft = i.documentElement.scrollLeft, this.pageTop = i.documentElement.scrollTop) : (this.pageLeft = i.body.scrollLeft || 0, this.pageTop = i.body.scrollTop || 0), this.offsetLeft = this.pageLeft - n.pageLeft, this.offsetTop = this.pageTop - n.pageTop;
            var r = 0,
                e = 0;
            try {
                r = t.innerWidth, e = t.innerHeight
            } catch (t) {
                return
            }
            if (0 != r && 0 != e) {
                this.scale = n.width / r, this.scale < 1 && (this.scale = 1);
                var s = n.width - n.clientWidth,
                    o = n.height - n.clientHeight;
                this.width = r - s / this.scale, this.height = e - o / this.scale
            }
        }
    };

    function cs(t, n) {
        try {
            return t[n]
        } catch (t) {
            return
        }
    }

    function hs(t) {
        var n = [t.clientWidth, t.clientHeight];
        return t.width === t.clientWidth && t.height === t.clientHeight || n.push(t.width, t.height), n
    }

    function fs(t) {
        var n = t.tagName;
        return n ? "object" == typeof n ? "form" : n.toLowerCase() : null
    }
    var vs = /(\s*(\S+)(\s+(?:\d+w|[\d.]+x)){0,1}\s*[,])/gm,
        ls = /((\s*(\S+)(\s+(?:\d+w|[\d.]+x)){0,1}\s*(\s*\d+\S){0,1}(\s*\d+(.\d*){0,1}\S){0,1}\s*)[,])/gm,
        ds = new RegExp("[^\\s]"),
        ps = new RegExp("[\\s]*$");

    function gs(t) {
        var n = ds.exec(t);
        if (!n) return t;
        for (var i = n.index, r = (n = ps.exec(t)) ? t.length - n.index : 0, e = "\uFFFF", s = t.slice(i, t.length - r).split(/\r\n?|\n/g), o = 0; o < s.length; o++) e += "".concat(s[o].length), o != s.length - 1 && (e += ":");
        return (i || r) && (e += " ".concat(i, " ").concat(r)), e
    }
    String.prototype;
    var ws, ms, ys = [2, 4, 8],
        bs = [16, 32, 64],
        Ss = ys.concat(bs),
        _s = 1;

    function ks(t, n) {
        var i, r;
        return void 0 === n && (n = Es(t)), null !== (r = null === (i = null == n ? void 0 : n.watchKind) || void 0 === i ? void 0 : i.hasKinds()) && void 0 !== r && r
    }

    function Is(t, n) {
        var i, r;
        return void 0 === n && (n = Es(t)), null !== (r = null === (i = null == n ? void 0 : n.watchKind) || void 0 === i ? void 0 : i.has(2)) && void 0 !== r && r
    }

    function As(t, n) {
        return void 0 === n && (n = Es(t)), !n || !!n.mask
    }

    function Es(t) {
        return t ? ws.get(t) : null
    }

    function Cs(t) {
        var n;
        return null !== (n = Es(Ts(t))) && void 0 !== n ? n : void 0
    }

    function Ts(t) {
        return ms.get(t)
    }

    function Ps(t) {
        try {
            if (t) {
                var n = Es(t);
                if (n) return n.id || 0
            }
        } catch (t) {}
        return 0
    }

    function xs(t) {
        return t && !Is(t) ? Ps(t) : 0
    }

    function Rs(t) {
        var n = t.id;
        t.id = 0;
        var i = Ts(n);
        i && ws["delete"](i), ms["delete"](n)
    }

    function Ms(t, n, i) {
        n.parent && (i(n), n.parent.child == n && (n.parent.child = n.next), n.parent.lastChild == n && (n.parent.lastChild = n.prev), n.prev && (n.prev.next = n.next), n.next && (n.next.prev = n.prev), n.parent = n.prev = n.next = null, Rs(n), n.child && Ks(0, n.child, i), n.shadow && Ks(0, n.shadow, i))
    }

    function Ks(t, n, i) {
        for (var r = [n]; r.length > 0 && r.length < 1e4;) {
            var e = r.pop();
            i(e), Rs(e), e.next && r.push(e.next), e.child && r.push(e.child), e.shadow && r.push(e.shadow)
        }
        ae(r.length < 1e4, "clearIds is fast")
    }
    var js, Os = "[Circular]";

    function Us(t) {
        return js || (js = qr(t.jsonStringify, t.arrayIsArray, t.objectKeys, {
            onCircular: function() {
                return Os
            }
        })), js
    }
    var Ns, Ls, Fs = function() {
            function t(n, i) {
                var r = this;
                this.t = n, this.W = i, this.V = 0, this.$ = t.G++, this.X = fe(function() {
                    var t;
                    null === (t = r.J) || void 0 === t || t.call(r)
                }, "ticker#tick")
            }
            return t.checkForBrokenSchedulers = function(n, i) {
                return r(this, void 0, void 0, function() {
                    var r, s;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return !n.requestWindowAnimationFrame || t.Y || (r = ft(n)) - t.Z < 100 ? [2, !1] : (t.Z = r, t.Y = !0, [4, new Promise(function(t) {
                                    return n.requestWindowAnimationFrame(i, t)
                                })]);
                            case 1:
                                return e.sent(), s = [], V(n, t.tt, function(t) {
                                    var n = t.nt(r);
                                    n && s.push(n)
                                }), [4, Promise.all(s)];
                            case 2:
                                return e.sent(), n.requestWindowAnimationFrame(i, fe(function() {
                                    t.Y = !1
                                }, "checkForBrokenSchedulers")), [2, !0]
                        }
                    })
                })
            }, t.stopAll = function(t) {
                V(t, this.tt, function(t) {
                    return t.stop()
                })
            }, t.prototype.it = function(t) {
                this.J = t
            }, t.prototype.stop = function() {
                this.rt(), delete t.tt[this.$]
            }, t.prototype.et = function(n) {
                this.V = ft(this.t) + 100 + 1.5 * n, t.tt[this.$] = this
            }, t.prototype.st = function() {
                return null != t.tt[this.$]
            }, t.prototype.ot = function() {
                delete t.tt[this.$]
            }, t.prototype.nt = function(t) {
                if (t > this.V) return Promise.resolve().then(this.X)["catch"](function() {})
            }, t.tt = {}, t.G = 0, t.Y = !1, t.Z = 0, t
        }(),
        Hs = function(t) {
            function i(n, i, r) {
                var e = t.call(this, n, i) || this;
                return e.ut = r, e.ct = -1, e
            }
            return n(i, t), i.prototype.start = function(t, n) {
                var i = this;
                void 0 === n && (n = this.ut), -1 == this.ct && (this.ut = n, this.it(function() {
                    t(), i.et(i.ut)
                }), this.ct = this.t.setWindowInterval(this.W, this.X, this.ut), this.et(this.ut))
            }, i.prototype.rt = function() {
                -1 != this.ct && (this.t.clearWindowInterval(this.W, this.ct), this.ct = -1, this.it(function() {}))
            }, i
        }(Fs),
        Ds = function(t) {
            function i(n, i, r, e, s) {
                void 0 === e && (e = 0);
                for (var o = [], u = 5; u < arguments.length; u++) o[u - 5] = arguments[u];
                var a = t.call(this, n, i) || this;
                return a.ht = e, a.ft = -1, a.it(function() {
                    a.stop(), r.apply(void 0 === s ? window : s, o)
                }), a
            }
            return n(i, t), i.prototype.start = function(t) {
                return void 0 === t && (t = this.ht), this.ht = t, this.t.clearWindowTimeout(this.W, this.ft), this.ft = this.t.setWindowTimeout(this.W, this.X, this.ht), this.et(t), this
            }, i.prototype.isRunning = function() {
                return this.st()
            }, i.prototype.rt = function() {
                -1 != this.ft && (this.t.clearWindowTimeout(this.W, this.ft), this.ft = -1)
            }, i
        }(Fs),
        Bs = function() {
            function t(t, n, i, r, e) {
                this.vt = i, this.lt = e, this.dt = 0, this.gt = new Hs(t, n, r), this.open()
            }
            return t.prototype.guard = function(t) {
                var n = this;
                return function() {
                    for (var i = [], r = 0; r < arguments.length; r++) i[r] = arguments[r];
                    return 0 == n.dt ? (n.lt(), void n.dt--) : n.dt < 0 ? void 0 : (n.dt--, t.apply(this, i))
                }
            }, t.prototype.close = function() {
                return this.gt.stop(), this
            }, t.prototype.open = function() {
                var t = this;
                return this.dt = this.vt, this.gt.start(function() {
                    t.dt = t.vt
                }), this
            }, t
        }(),
        Ws = function() {
            function t(t) {
                this.t = t, this.wt = 0, this.yt = 0, this.yt = ft(this.t)
            }
            return t.prototype.wallTime = function() {
                return ft(this.t)
            }, t.prototype.now = function() {
                var t = this.wallTime() - this.yt;
                return t < 0 && this.bt("timekeeper now() is negative"), t
            }, t.prototype.startTime = function() {
                return this.yt
            }, t.prototype.setStartTime = function(t) {
                var n = this.wallTime();
                this.yt = t, t > n && (this.wt = t - n, this.wt > 1e3 && this.bt("timekeeper set with future ts"))
            }, t.prototype.bt = function(t) {
                var n = this;
                o(function() {
                    return Us(n.t)({
                        msg: t,
                        skew: n.wt,
                        startTime: n.yt,
                        wallTime: n.wallTime()
                    }, 1024)
                })
            }, t
        }();
    (Ls = Ns || (Ns = {})).Indeterminate = "indeterminate", Ls.Checked = "checked", Ls.Value = "value";
    var zs = function() {
        function t(t, n) {
            var i;
            this.C = t, this.St = n, this._t = !1, this.kt = {}, this.It = ((i = {})[Ns.Checked] = {}, i[Ns.Indeterminate] = {}, i[Ns.Value] = {}, i), this.At = {}, this.Et = [], this.Ct = {}, this.Tt = !1, this.Pt = !1, this.xt = {}, this.Rt = null, this.Mt = t.window.document
        }
        return t.prototype.start = function() {
            this.Kt() || (this._t = !0)
        }, t.prototype.hookInstance = function(t, n) {
            if ("input" === fs(n)) switch (n.type) {
                case "checkbox":
                case "radio":
                    this.jt(t, n, "checked");
                    break;
                default:
                    this.jt(t, n, "value")
            }
        }, t.prototype.addInput = function(t) {
            if (t) {
                var n = xs(t);
                if (n) {
                    if ("input" === fs(t)) {
                        var i = t;
                        this.Ot(n, i), i.indeterminate && this.Ut(i, !0)
                    }
                    var r = !1;
                    if (function(t) {
                            switch (t.type) {
                                case "checkbox":
                                    return t.checked != t.hasAttribute("checked");
                                case "radio":
                                    return t.checked || t.hasAttribute("checked");
                                default:
                                    return (t.value || "") != function(t) {
                                        if ("select" != fs(t)) return t.getAttribute("value") || "";
                                        var n = t,
                                            i = n.querySelector("option[selected]") || n.querySelector("option");
                                        return i && i.value || ""
                                    }(t)
                            }
                        }(t) && (this.Nt(t, !1, !0), r = !0), this._t && (this.kt[n] = {
                            elem: t
                        }), !r)
                        if (Gs(t)) {
                            var e = qs(this.C.wdx, t);
                            t.checked && (this.At[e] = n)
                        } else this.Lt(n, Ns.Value, $s(this.C, t))
                }
            }
        }, t.prototype.Lt = function(t, n, i) {
            this.It[n][t] = i
        }, t.prototype.Ft = function(t, n) {
            return this.It[n][t]
        }, t.prototype.Ht = function(t) {
            for (var n in this.It) delete this.It[n][t]
        }, t.prototype.Ot = function(t, n) {
            if (this.Tt) this.Pt && this.hookInstance(t, n);
            else {
                var i = "checkbox" === n.type || "radio" === n.type ? "checked" : "value",
                    r = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, i),
                    e = Object.getOwnPropertyDescriptor(n, i);
                r && e && r !== e && (this.Pt = !0, this.hookInstance(t, n)), this.Tt = !0
            }
        }, t.prototype.Dt = function(t, n) {
            void 0 === n && (n = $s(this.C, t));
            var i = xs(t);
            if (!t || !i) return !1;
            if (Gs(t)) {
                var r = qs(this.C.wdx, t);
                return this.At[r] === i != ("true" === n)
            }
            return this.Ft(i, Ns.Value) !== n
        }, t.prototype.onChange = function(t, n, i) {
            void 0 === i && (i = $s(this.C, t));
            var r = xs(t);
            t && r && (n || this.Dt(t, i)) && this.Nt(t, n)
        }, t.prototype.onInputChange = function(t) {
            if (t) {
                var n = t;
                if (n.nodeType === Node.ELEMENT_NODE) {
                    var i = Ps(n);
                    if (i) {
                        var r = n,
                            e = $s(this.C, r);
                        this.Bt(i, r, e)
                    }
                }
            }
        }, t.prototype.onKeyboardChange = function(t) {
            var n, i = function(t) {
                for (var n = t.activeElement; n && n.shadowRoot;) {
                    var i = n.shadowRoot.activeElement;
                    if (!i) return n;
                    n = i
                }
                return n
            }(this.Mt);
            i && ("value" in (n = i) || "checked" in n) && !Is(i) && this.Dt(i) && this.Nt(i, t)
        }, t.prototype.tick = function() {
            for (var t in this.kt) {
                var n = this.kt[t],
                    i = n.elem;
                if (xs(i)) try {
                    delete this.kt[t];
                    var r = $s(this.C, i);
                    if (this.Dt(i, r)) this.Nt(i);
                    else if (n.noFsIdInOption) {
                        var e = i;
                        Array.prototype.slice.call(e.options).every(function(t) {
                            return xs(t)
                        }) && (n.noFsIdInOption = !1, this.Nt(i))
                    }
                } finally {
                    this._t && (this.kt[t] = n)
                } else delete this.kt[t], this.Ht(t), Gs(i) && delete this.At[qs(this.C.wdx, i)]
            }
        }, t.prototype.stop = function() {
            for (var t, n = 0, i = this.Et; n < i.length; n++)(e = i[n])();
            for (var r in this.Ct) {
                var e;
                (e = this.Ct[r]) && "function" == typeof e && e()
            }
            this.It = ((t = {})[Ns.Checked] = {}, t[Ns.Indeterminate] = {}, t[Ns.Value] = {}, t), this.Et = [], this.Ct = {}, this.Tt = !1, this.Pt = !1
        }, t.prototype.removeInput = function(t) {
            var n = xs(t);
            n && (this.Ct[n] && (this.Ct[n](), delete this.Ct[n]), this.Ht(n))
        }, t.prototype.Nt = function(t, n, i) {
            void 0 === n && (n = !1), void 0 === i && (i = !1);
            var r = xs(t);
            if (t && r && !this.Wt(r, t)) {
                var e = $s(this.C, t);
                if (Gs(t)) {
                    var s = qs(this.C.wdx, t);
                    "false" === e && this.At[s] === r ? delete this.At[s] : "true" === e && (this.At[s] = r)
                } else this.Lt(r, Ns.Value, e);
                var o = this.zt(t, r, e, n, i);
                this.St.enqueue({
                    Kind: 114,
                    Args: [18, o]
                })
            }
        }, t.prototype.Wt = function(t, n) {
            if (this.kt[t]) return !0;
            if ("select" !== fs(n)) return !1;
            for (var i = n.options, r = 0; r < i.length; r++)
                if (!xs(i[r])) return this.kt[t] = {
                    elem: n,
                    noFsIdInOption: !0
                }, !0;
            return !1
        }, t.prototype.Ut = function(t, n) {
            var i = xs(t);
            i && this.qt(i, Ns.Indeterminate, n)
        }, t.prototype.qt = function(t, n, i) {
            this.Ft(t, n) !== i && (this.Lt(t, n, i), this.St.enqueue({
                Kind: 109,
                Args: [t, n, i]
            }))
        }, t.prototype.Kt = function() {
            var t = this,
                n = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
            return !(!n || !n.set || (this.Vt(HTMLInputElement, "value"), this.Vt(HTMLInputElement, "checked"), this.Vt(HTMLSelectElement, "value"), this.Vt(HTMLTextAreaElement, "value"), this.Vt(HTMLSelectElement, "selectedIndex"), this.Vt(HTMLOptionElement, "selected"), this.Et.push(tt(HTMLInputElement, Ns.Indeterminate, function(n, i) {
                return t.Ut(n, !!i)
            })), this.$t("stepUp"), this.$t("stepDown"), 0))
        }, t.prototype.Gt = function() {
            try {
                for (var t in this.xt) {
                    var n = this.xt[t],
                        i = n[0],
                        r = n[1];
                    this.onChange(i, !1, r)
                }
            } finally {
                this.Rt = null, this.xt = {}
            }
        }, t.prototype.Qt = function(t) {
            var n = this;
            return function(i, r) {
                var e = Vs(n.C.wdx, i),
                    s = xs(e);
                if (s) {
                    t === Ns.Checked && n.qt(s, Ns.Checked, r);
                    var o = e !== i ? $s(n.C, e) : r;
                    n.Dt(e, "".concat(o)) && n.Bt(s, e, "".concat(o))
                }
            }
        }, t.prototype.Bt = function(t, n, i) {
            this.xt[t] = [n, i], this.Rt || (this.Rt = new Ds(this.C.wdx, this.C.window, this.Gt.bind(this)), this.Rt.start())
        }, t.prototype.$t = function(t) {
            var n = this,
                i = Be(this.C, HTMLInputElement.prototype, t);
            i && (i.afterSync(function(t) {
                var i = t.that;
                n.Dt(i) && n.onInputChange(i)
            }), this.Et.push(function() {
                return i.disable()
            }))
        }, t.prototype.Vt = function(t, n) {
            this.Et.push(tt(t, n, this.Qt(n)))
        }, t.prototype.jt = function(t, n, i) {
            this.Ct[t] = nt(n, i, this.Qt(i))
        }, t.prototype.zt = function(t, n, i, r, e) {
            var s = this.C.measurer.enqueue(function() {
                    return {
                        done: !0,
                        result: Qs(t)
                    }
                }, !0),
                o = As(t);
            return function() {
                var u = o ? gs(i) : i,
                    a = function(t, n) {
                        var i;
                        if (L(n)) {
                            var r = n();
                            if (r && r[0]) return null !== (i = r[0]) && void 0 !== i && i
                        }
                        return Qs(t)
                    }(t, s);
                return [n, u, r, a, e]
            }
        }, t
    }();

    function qs(t, n) {
        if (!n) return "";
        for (var i = n; i && "form" !== fs(i);) i = K(i);
        var r = i && "form" == fs(i) ? Ps(i) : 0,
            e = n.name || "_fs_".concat(Ps(n));
        return "".concat(r, ":").concat(e)
    }

    function Vs(t, n, i) {
        if (void 0 === i && (i = 2), i <= 0) return n;
        var r = fs(n),
            e = K(n);
        return "option" !== r && "optgroup" !== r || (null == e ? void 0 : e.nodeType) !== E ? n : Vs(t, e, i - 1)
    }

    function $s(t, n) {
        if (!n) return "";
        switch (n.type) {
            case "checkbox":
            case "radio":
                return "".concat(n.checked);
            default:
                var i = t.options.cleanValueGetter && t.wdx.inputGetValue ? t.wdx.inputGetValue(n) : n.value;
                return i || (i = ""), "".concat(i)
        }
    }

    function Gs(t) {
        return t && "radio" == t.type
    }

    function Qs(t) {
        var n = !1;
        if (t && t.getBoundingClientRect) try {
            var i = t.getBoundingClientRect();
            n = i.width > 0 && i.height > 0
        } catch (t) {}
        return n
    }
    var Xs, Js, Ys, Zs, to = (Js = (Xs = window.navigator).vendor, Ys = void 0 !== window.opr, Zs = Xs.userAgent.indexOf("Edge") > -1, !!Xs.userAgent.match("CriOS") || "Google Inc." === Js && !Ys && !Zs),
        no = /Firefox/.test(window.navigator.userAgent);

    function io() {
        var t = window.navigator.userAgent.match(/Firefox\/(\d+)/);
        return t && t[1] ? parseInt(t[1], 10) : -1
    }

    function ro(t) {
        return !!no && io() < t
    }

    function eo() {
        var t = window.navigator.userAgent.match(/Chrome\/(\d+)/);
        return t && t[1] ? parseInt(t[1], 10) : -1
    }

    function so(t) {
        if (!to) return !1;
        var n = eo();
        return -1 !== n && n < t
    }!!to && eo(), no && io(), ro(28), ro(30), ro(27), so(23), so(38), so(57), so(60);
    var oo = function() {
        function t(t, n, i) {
            var r = this;
            this.C = t, this.N = i, this.Xt = new Ne(void 0, Se), this.Jt = !1, this.Yt = !1, this.G = 1, this.Zt = [], this.tn = [], this.nn = fe(function(t) {
                var n, i = function(t, n) {
                        void 0 === n && (n = window);
                        var i = n.KeyframeEffect,
                            r = t.effect;
                        return r && (void 0 === i || r instanceof i) ? r : null
                    }(t, r.rn),
                    e = function(t, n) {
                        void 0 === n && (n = window);
                        var i = n.DocumentTimeline,
                            r = t.timeline;
                        return r && (void 0 === i || r instanceof i) ? r : null
                    }(t, r.rn),
                    o = ho(t);
                if ((null == i ? void 0 : i.target) && 0 !== xs(null == i ? void 0 : i.target) && e === r.rn.document.timeline && 0 === o) {
                    var u = Ps(i.target);
                    if (r.Xt.has(i)) {
                        var a = r.Xt.get(i) || [],
                            c = (h = a[0], a.slice(1)); - 1 === c.indexOf(u) && (r.en(i, u), r.Xt.set(i, s(s([h], c, !0), [u], !1)))
                    } else {
                        var h = r.G++;
                        r.Xt.set(i, [h, u]), r.sn.enqueue({
                            Kind: 95,
                            Args: [h, u, co(r.C.wdx, i), ao(i)]
                        })
                    }
                    if (!r.Xt.has(t)) {
                        var f = r.G++,
                            v = (h = r.on(i), r.on(e));
                        switch (r.Xt.set(t, [f]), r.sn.enqueue({
                            Kind: 91,
                            Args: [f, ho(t), h, v]
                        }), t.playState) {
                            case "finished":
                                r.sn.enqueue({
                                    Kind: 92,
                                    Args: [f, ["finish", []]]
                                });
                                break;
                            case "paused":
                            case "running":
                                r.sn.enqueue({
                                    Kind: 93,
                                    Args: [f, ["currentTime", (n = t.currentTime, "number" == typeof n ? n : "undefined" != typeof CSSNumericValue && n instanceof CSSNumericValue ? n.to("ms").value : null)]]
                                });
                                var l = "paused" === t.playState ? "pause" : "play";
                                r.sn.enqueue({
                                    Kind: 92,
                                    Args: [f, [l, []]]
                                })
                        }
                        r.N.add(t, "cancel", !0, function() {
                            r.sn.enqueue({
                                Kind: 92,
                                Args: [f, ["cancel", []]]
                            })
                        }), r.N.add(t, "finish", !0, function() {
                            r.sn.enqueue({
                                Kind: 92,
                                Args: [f, ["finish", []]]
                            })
                        })
                    }
                }
            }, "_snapshotAnimation"), this.sn = n, this.rn = t.window, this.Yt = function(t) {
                void 0 === t && (t = window);
                var n = t.Animation,
                    i = t.Document,
                    r = t.Element;
                return void 0 !== n && void 0 !== n.prototype && "effect" in n.prototype && "getAnimations" in i.prototype && "animate" in r.prototype
            }(this.rn)
        }
        return Object.defineProperty(t.prototype, "nextId", {
            get: function() {
                return this.G
            },
            enumerable: !1,
            configurable: !0
        }), t.prototype.snapshot = function(t) {
            var n;
            if (this.un(t))
                for (var i = 0, r = null !== (n = t.getAnimations()) && void 0 !== n ? n : []; i < r.length; i++) {
                    var e = r[i];
                    this.nn(e)
                }
        }, t.prototype.un = function(t) {
            return this.Jt && this.Yt && "getAnimations" in t
        }, t.prototype.start = function(t) {
            var n, i = this;
            t.CaptureAnimations && (this.sn.enqueue({
                Kind: 58,
                Args: [8, this.Yt]
            }), this.Yt && (this.Jt = !0, this.an(null === (n = Be(this.C, this.rn.Element.prototype, "animate")) || void 0 === n ? void 0 : n.afterSync(function(t) {
                i.nn(t.result)
            })), this.cn("play"), this.cn("pause"), this.cn("cancel"), this.cn("finish"), this.hn("updateTiming"), this.hn("setKeyframes"), this.Zt.push(tt(KeyframeEffect, "target", function(t, n) {
                i.en(t, Ps(n))
            }))))
        }, t.prototype.stop = function() {
            this.N.clearAll(), this.Jt = !1, this.tn.forEach(function(t) {
                return t && t.disable()
            }), this.tn = [], this.Zt.forEach(function(t) {
                return t()
            }), this.Zt = []
        }, t.prototype.en = function(t, n) {
            var i = this.on(t);
            i && this.sn.enqueue({
                Kind: 97,
                Args: [i, ["target", n]]
            })
        }, t.prototype.on = function(t) {
            return (this.Xt.get(t) || [])[0]
        }, t.prototype.an = function(t) {
            t && this.tn.push(t)
        }, t.prototype.cn = function(t) {
            var n, i = this;
            this.an(null === (n = Be(this.C, Animation.prototype, t)) || void 0 === n ? void 0 : n.afterSync(function(n) {
                var r = i.on(n.that);
                r && i.sn.enqueue({
                    Kind: 92,
                    Args: [r, [t, []]]
                })
            }))
        }, t.prototype.hn = function(t) {
            var n, i = this;
            this.an(null === (n = Be(this.C, KeyframeEffect.prototype, t)) || void 0 === n ? void 0 : n.afterSync(function(n) {
                var r, e, s = i.on(n.that);
                if (s) switch (t) {
                    case "updateTiming":
                        var o = n.args[0];
                        i.sn.enqueue({
                            Kind: 96,
                            Args: [s, ["updateTiming", [uo(o)]]]
                        });
                        break;
                    case "setKeyframes":
                        var u = n.args[0];
                        i.sn.enqueue({
                            Kind: 96,
                            Args: [s, ["setKeyframes", [(r = i.C.wdx, e = u, (r.arrayIsArray(e) ? e : [e]).map(function(t) {
                                var n = [];
                                return V(r, t, function(t, i) {
                                    n.push([i, t])
                                }), [n, null, null, null]
                            }))]]]
                        })
                }
            }))
        }, t
    }();

    function uo(t) {
        var n, i;
        return [t.delay, t.direction, (i = null !== (n = t.duration) && void 0 !== n ? n : 0, "number" == typeof i || "string" == typeof i ? i : i.toString()), t.easing, t.endDelay, t.fill, t.iterationStart, "".concat(t.iterations)]
    }

    function ao(t) {
        var n = t.getTiming(),
            i = t.composite,
            r = void 0 === i ? "replace" : i,
            e = t.iterationComposite,
            o = void 0 === e ? "replace" : e;
        return s(s([], uo(n), !0), [r, o], !1)
    }

    function co(t, n) {
        return n.getKeyframes().map(function(n) {
            var i = n.composite,
                r = n.easing,
                e = n.offset,
                s = [];
            return V(t, n, function(t, n) {
                "composite" !== n && "computedOffset" !== n && "easing" !== n && "offset" !== n && s.push([n, t])
            }), [s, i, r, e]
        })
    }

    function ho(t) {
        return "animationName" in t ? 1 : "transitionProperty" in t ? 2 : 0
    }
    var fo = "#polyfillshadow";

    function vo(t, n) {
        if (n)
            for (var i in n) t.push(":".concat(i)), t.push(n[i])
    }

    function lo(t) {
        return t.nodeType === E && "http://www.w3.org/2000/svg" === t.namespaceURI
    }

    function po(t, n, i, r) {
        var e;
        try {
            var s = "invalid: no sanitizers";
            if (!ae(t.length > 0, s)) throw s;
            for (var u = 0, a = t; u < a.length; u++) a[u].sanitize(i)
        } catch (t) {
            i[4] = void 0, i[5] = void 0, o(function() {
                return "sanitizer failed: ".concat(t)
            }), ve("visitorPipeline#sanitize", {
                err: t
            })
        }
        var c = i;
        if (r) try {
            r(c)
        } catch (t) {
            o(function() {
                return "visitorPipeline action failed: ".concat(t)
            }), ve("visitorPipeline#action", {
                err: t
            })
        }
        if (!(null === (e = i[2].watchKind) || void 0 === e ? void 0 : e.has(2)))
            for (var h = 0, f = n; h < f.length; h++) {
                var v = f[h];
                try {
                    v.visit(c)
                } catch (t) {
                    o(function() {
                        return "visitor failed: ".concat(t)
                    }), ve("visitorPipeline#visit", {
                        err: t
                    })
                }
            }
    }

    function go() {
        var t, n;
        return {
            promise: new Promise(function(i, r) {
                t = i, n = r
            }),
            resolve: t,
            reject: n
        }
    }

    function wo(t, n, i) {
        return new Promise(function(r) {
            t.setWindowTimeout(n, I(r), i)
        })
    }

    function mo(t, n, i, o) {
        return r(this, void 0, void 0, function() {
            var r, u;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        return e.trys.push([0, , 2, 3]), u = new Promise(function(i, e) {
                            r = t.setWindowTimeout(n, I(function() {
                                return e(new Error("timeout"))
                            }), o)
                        }), [4, Promise.race(s(s([], i, !0), [u], !1))];
                    case 1:
                        return [2, e.sent()];
                    case 2:
                        return t.clearWindowTimeout(n, r), [7];
                    case 3:
                        return [2]
                }
            })
        })
    }
    var yo = function() {
            function t(t, n, i) {
                this.t = t, this.W = n, this.vn = i, this.ln = 0
            }
            return t.prototype.trigger = function() {
                var t = this,
                    n = ft(this.t);
                if (this.dn) return this.dn.promise;
                var i, r = n - this.ln;
                (0 === this.ln || r >= this.vn) && (this.ln = n);
                var e = new Promise(function(t) {
                    i = t
                });
                this.dn = {
                    promise: e,
                    resolve: i
                };
                var s = n - this.ln,
                    o = this.t.mathMax(0, this.vn - s);
                return this.pn = this.t.setWindowTimeout(this.W, I(function() {
                    t.pn && (t.pn = void 0);
                    var n = t.dn;
                    t.dn = void 0, null == n || n.resolve()
                }), o), e
            }, t
        }(),
        bo = function(t, n) {
            var i = function() {
                try {
                    var t = new MessageChannel;
                    return t.port1.start(), t
                } catch (t) {
                    return null
                }
            }();
            return i ? new Promise(function(t) {
                var n = i.port1,
                    r = i.port2,
                    e = function() {
                        t(), n.removeEventListener("message", e), n.close()
                    };
                n.addEventListener("message", e), r.postMessage(void 0), r.close()
            }) : wo(t, n, 0)
        },
        So = function(t, n) {
            return r(void 0, void 0, void 0, function() {
                var i;
                return e(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return (i = t.requestWindowAnimationFrame) ? [4, new Promise(function(t) {
                                return i(window, t)
                            })] : [3, 2];
                        case 1:
                            r.sent(), r.label = 2;
                        case 2:
                            return [4, bo(t, n)];
                        case 3:
                            return r.sent(), [2]
                    }
                })
            })
        };

    function _o(t, n) {
        void 0 === n && (n = 16);
        var i = ft(t) + n;
        return {
            timeRemaining: function() {
                return Math.max(0, i - ft(t))
            },
            didTimeout: !1
        }
    }

    function ko(t, n, i) {
        return r(this, void 0, void 0, function() {
            var r, s, o, u;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (r = n.ResizeObserver) ? (s = n.document, o = s.documentElement || s.body || s.head, u = null != i ? i : o, [2, new Promise(function(i) {
                            var e = new r(function() {
                                So(t, n).then(function() {
                                    e.unobserve(u), i()
                                })
                            });
                            e.observe(u)
                        })]) : [4, So(t, n)];
                    case 1:
                        return e.sent(), [2]
                }
            })
        })
    }
    var Io = function() {
        function t() {
            this.gn = 0, this.wn = {}, this.wn.next = this.wn.prev = this.wn
        }
        return t.prototype.first = function() {
            return this.wn.next.value
        }, t.prototype.last = function() {
            return this.wn.prev.value
        }, t.prototype.size = function() {
            return this.gn
        }, t.prototype.push = function(t) {
            this.gn++, Ao(this.wn.prev, {
                value: t
            })
        }, t.prototype.unshift = function(t) {
            this.gn++, Ao(this.wn, {
                value: t
            })
        }, t.prototype.pop = function() {
            return this.gn > 0 && this.gn--, Eo(this.wn.prev)
        }, t.prototype.shift = function() {
            return this.gn > 0 && this.gn--, Eo(this.wn.next)
        }, t
    }();

    function Ao(t, n) {
        var i = t.next;
        n.next = i, n.prev = t, t.next = i.prev = n
    }

    function Eo(t) {
        var n = t.prev,
            i = t.next;
        return n.next = i, i.prev = n, t.value
    }
    var Co = {
            timeRemaining: function() {
                return 1
            },
            didTimeout: !1
        },
        To = function() {
            function t(t, n) {
                void 0 === n && (n = 1), this.C = t, this.mn = n, this.G = 1, this.yn = 0, this.bn = new Io, this.Sn = {}, this._n = 1
            }
            return t.prototype.enqueue = function(t, n) {
                var i = this;
                if (void 0 === n && (n = !1), !(2 === this.yn && this._n > 16)) {
                    var r = {
                        id: this.G++,
                        isCompleted: !1,
                        process: t,
                        depth: this._n,
                        store: n
                    };
                    return this.bn.push(r), this.kn(), n ? function() {
                        return i.In(r)
                    } : void 0
                }
                he("deep recursive task")
            }, t.prototype.In = function(t) {
                try {
                    var n = t.id,
                        i = this.Sn[n];
                    return i ? (delete this.Sn[n], [i.result, i.err]) : (Po(Co, t), ae(t.isCompleted, "queue#task"), [t.result, t.err])
                } finally {
                    t.result = void 0, t.err = void 0
                }
            }, t.prototype.flush = function() {
                this.An(Co)
            }, t.prototype.kn = function() {
                0 === this.yn && (this.yn = 1, this.En())
            }, t.prototype.An = function(t) {
                if (1 === this.yn) {
                    var n = 0;
                    this.yn = 2;
                    for (var i = this.bn.first(); i && xo(n, this.mn, t);) this._n = i.depth + 1, Po(t, i), i.isCompleted && (this.bn.shift(), !i.store || void 0 === i.result && void 0 === i.err || (this.Sn[i.id] = i)), i = this.bn.first(), n++;
                    this.yn = 0, this._n = 1, this.bn.size() > 0 && this.kn()
                }
            }, t
        }();

    function Po(t, n) {
        var i;
        if (!n.isCompleted) try {
            var r = (null === (i = n.process) || void 0 === i ? void 0 : i.call(n, t)) || {
                done: !0
            };
            r.done && (n.isCompleted = !0, n.result = r.result, delete n.process)
        } catch (t) {
            n.isCompleted = !0, n.err = t, delete n.process
        }
    }

    function xo(t, n, i) {
        return t < n || i.timeRemaining() > 0
    }
    var Ro = function(t) {
            function i(n) {
                return t.call(this, n) || this
            }
            return n(i, t), i.prototype.En = function() {
                var t = this;
                bo(this.C.wdx, this.C.window).then(function() {
                    t.An(_o(t.C.wdx, 36))
                })
            }, i
        }(To),
        Mo = {
            INPUT: !0,
            TEXTAREA: !0,
            NOSCRIPT: !0
        },
        Ko = function() {
            function t(t, n, i, r, e) {
                this.C = t, this.Cn = n, this.Tn = i, this.Pn = r, this.xn = e, ws = new Map, ms = new Map, _s = 1, this.bn = new Ro(this.C)
            }
            return t.prototype.tokenizeNode = function(t, n, i, r, e, s, o) {
                var u = this,
                    a = Es(n),
                    c = Es(i),
                    h = [];
                return function(n, i) {
                    var f = _s;
                    try {
                        return u.Rn(t, a, c, r, h, e, s, o), !0
                    } catch (t) {
                        return he("tryTokenize", {
                            err: t
                        }), _s = f, !1
                    }
                }(this.C.wdx) || (h = []), h
            }, t.prototype.Rn = function(t, n, i, r, e, s, o, u) {
                for (var a, c, h = [{
                        parentMirror: n,
                        nextMirror: i,
                        node: r
                    }], f = function() {
                        var n = h.pop();
                        if (!n) return "continue";
                        if ("string" == typeof n) return "<" === n[0] && ++_s, e.push(n), "continue";
                        var i = n.node,
                            r = v.Mn(t, n, e, s, o);
                        if (null == r || (null === (a = r.watchKind) || void 0 === a ? void 0 : a.has(2))) return "continue";
                        var f = r.type === E ? i.shadowRoot : null;
                        return f || O(i) ? (null === (c = r.watchKind) || void 0 === c ? void 0 : c.has(64)) ? (u(i, 2), "continue") : (h.push("]"), function(t, n) {
                            var i = P(t);
                            if (i)
                                for (var r = i.lastChild(); r;) n(r), r = i.previousSibling()
                        }(i, function(t) {
                            t && h.push({
                                parentMirror: r,
                                nextMirror: null,
                                node: t
                            })
                        }), f && h.push({
                            parentMirror: r,
                            nextMirror: null,
                            node: f
                        }), void h.push("[")) : "continue"
                    }, v = this; h.length;) f()
            }, t.prototype.Mn = function(t, n, i, r, e) {
                var s, u, a, c, h = n.node,
                    f = n.parentMirror,
                    v = n.nextMirror,
                    l = fs(h),
                    d = function(t, n) {
                        var i;
                        try {
                            var r = null === (i = t.nodeGetNodeName) || void 0 === i ? void 0 : i.call(t, n);
                            if ("string" == typeof r) return r
                        } catch (t) {}
                        return n.nodeName
                    }(this.C.wdx, h),
                    p = h.nodeType;
                if ("script" === l || 8 === p) return null;
                var g = function(t) {
                    var n;
                    if (t === (null === (n = null == t ? void 0 : t.host) || void 0 === n ? void 0 : n.shadowRoot)) return function(t) {
                        return function(t) {
                            if (!L(t)) return !1;
                            try {
                                return xe(Function.prototype.toString, t)
                            } catch (t) {
                                return !1
                            }
                        }(t.constructor)
                    }(t) ? "#shadow" : fo
                }(h);
                if (g === fo) return null;
                var w, m, y, b, S, _ = function(t, n, i, r) {
                    void 0 === n && (n = t.nodeName), void 0 === i && (i = t.nodeType), void 0 === r && (r = fs(t));
                    var e = {
                        id: _s++,
                        name: n,
                        type: i,
                        tag: r
                    };
                    return ws.set(t, e), ms.set(e.id, t), e
                }(h, d, p, l);
                _.shadowRootType = g || (null == f ? void 0 : f.shadowRootType), f && (g ? (f.shadow = _, _.parent = f) : (this.C.wdx, w = f, y = v, Ms(0, m = _, this.xn.bind(this)), m.parent = w, m.next = y, y && (m.prev = y.prev, y.prev = m), null == m.next ? (m.prev = w.lastChild, w.lastChild = m) : m.next.prev = m, null == m.prev ? w.child = m : m.prev.next = m)), _.mask = null === (s = _.parent) || void 0 === s ? void 0 : s.mask;
                try {
                    switch (p) {
                        case 3:
                            if (void 0 === _.mask && (_.mask = !_.parent || _.parent.mask), _.mask) {
                                var k = K(h);
                                (null == k ? void 0 : k.nodeType) === E && this.Tn.observe(k)
                            }
                            S = null !== (u = h.textContent) && void 0 !== u ? u : "";
                            break;
                        case E:
                            var I = h,
                                A = this.getWatchState(I, d, !!_.shadowRootType, t);
                            if (null != A) {
                                _.watchKind = A;
                                var T = !1;
                                A.has(16) && (T = !0, null === (a = this.Pn) || void 0 === a || a.observe(I)), A.has(8) && (_.mask = !1), A.has(4) && (_.mask = !0), (A.has(2) || A.has(64)) && (T = !0), T && this.Tn.observe(I)
                            }
                            b = function(t, n) {
                                try {
                                    if (ge && "output" === n || !t.hasAttributes()) return;
                                    try {
                                        if (L(Element.prototype.getAttributeNames)) return function(t) {
                                            for (var n, i = {}, r = 0, e = null !== (n = Element.prototype.getAttributeNames.call(t)) && void 0 !== n ? n : []; r < e.length; r++) {
                                                var s = e[r];
                                                jo(i, s, t.getAttribute(s))
                                            }
                                            return i
                                        }(t)
                                    } catch (t) {}
                                    return function(t) {
                                        for (var n, i, r = {}, e = null !== (i = null === (n = t.attributes) || void 0 === n ? void 0 : n.length) && void 0 !== i ? i : 0, s = 0; s < e; s++) {
                                            var o = t.attributes[s];
                                            null != o && jo(r, o.name, o.value)
                                        }
                                        return r
                                    }(t)
                                } catch (t) {
                                    o(function() {
                                        return "get attrs failed: ".concat(t)
                                    }), ve("nodeEncoder#getAttrs", {
                                        err: t,
                                        tagName: n
                                    })
                                }
                            }(I, l)
                    }
                } catch (t) {
                    ve("nodeEncoder#_encodeNode", {
                        err: t
                    })
                }
                if (!(null === (c = _.watchKind) || void 0 === c ? void 0 : c.has(2)))
                    for (var P = 0, x = e; P < x.length; P++) {
                        var R = x[P];
                        try {
                            R.preVisit && R.preVisit(_, h)
                        } catch (t) {
                            o(function() {
                                return "pre-visitor failed: ".concat(t)
                            }), ve("visitor.preVisit", {
                                err: t
                            })
                        }
                    }
                var M = [this.C.wdx, 0, _, h, b, S],
                    j = this.bn.enqueue(function(t) {
                        var n = [];
                        return po(r, e, M, function(t) {
                            ! function(t, n) {
                                n[0], n[1];
                                var i = n[2],
                                    r = n[3],
                                    e = n[4],
                                    s = n[5],
                                    o = i.shadowRootType,
                                    u = i.watchKind,
                                    a = i.name,
                                    c = i.type,
                                    h = i.mask,
                                    f = lo(r),
                                    v = e;
                                if (10 === c) {
                                    v || (v = {});
                                    var l = r;
                                    v.name = l.name || "", v.publicId = l.publicId || "", v.systemId = l.systemId || ""
                                }! function(t, n, i, r, e, s, o, u, a) {
                                    switch (n) {
                                        default: t.push("<".concat(i));
                                        break;
                                        case 10:
                                                t.push("<!DOCTYPE"),
                                            vo(t, o);
                                            break;
                                        case 11:
                                                case C:
                                                var c = void 0;c = r || i,
                                            t.push("<".concat(c));
                                            break;
                                        case 8:
                                                t.push("<object", ":_fs_comment_ignored", "");
                                            break;
                                        case 3:
                                                t.push("<".concat(i), null != s ? s : "");
                                            break;
                                        case E:
                                                if (c = i, a && (c = "svg:".concat(c)), "script" === c) {
                                                t.push("<object", ":_fs_script_ignored", "");
                                                break
                                            }t.push("<".concat(c)),
                                            e && (e.has(2) && t.push(":".concat("_fs_excluded"), "true"), e.has(64) && t.push(":".concat("_fs_deferred"), "true")),
                                            u && t.push(":".concat("_fs_masked"), "true"),
                                            vo(t, o)
                                    }
                                }(t, c, a, o, u, s, v, !!h, f)
                            }(n, t)
                        }), {
                            done: !0,
                            result: n
                        }
                    }, !0);
                return ae("function" == typeof j, "nodeEnc#resolver"), j && i.push(function() {
                    var t = j();
                    return t && t[0] || []
                }), _
            }, t.prototype.getWatchState = function(t, n, i, r) {
                return i || null == r || Mo[n] ? this.Cn.isWatched(t) : r.get(t)
            }, t
        }();

    function jo(t, n, i) {
        null != n && null != i && (t[n] = "".concat(i))
    }
    var Oo = [{
            Selector: "input[type=password]",
            Consent: !1,
            Type: 1
        }, {
            Selector: "input[type=hidden]",
            Consent: !1,
            Type: 1
        }, {
            Selector: "[autocomplete^=cc-]",
            Consent: !1,
            Type: 1
        }, {
            Selector: "object:not([type^=\"image/\"])",
            Consent: !1,
            Type: 1
        }, {
            Selector: "embed:not([type^=\"image/\"])",
            Consent: !1,
            Type: 1
        }, {
            Selector: "noscript",
            Consent: !1,
            Type: 1
        }, {
            Selector: ".fs-hide",
            Consent: !1,
            Type: 1
        }, {
            Selector: ".fs-exclude",
            Consent: !1,
            Type: 1
        }, {
            Selector: ".fs-exclude-without-consent",
            Consent: !0,
            Type: 1
        }, {
            Selector: ".fs-mask",
            Consent: !1,
            Type: 2
        }, {
            Selector: ".fs-mask-without-consent",
            Consent: !0,
            Type: 2
        }, {
            Selector: ".fs-unmask",
            Consent: !1,
            Type: 3
        }, {
            Selector: ".fs-unmask-with-consent",
            Consent: !0,
            Type: 3
        }, {
            Selector: ".fs-block",
            Consent: !1,
            Type: 1
        }, {
            Selector: ".fs-record-with-consent",
            Consent: !0,
            Type: 1
        }],
        Uo = function(t, n) {
            return t | n
        },
        No = bs.reduce(Uo, 0),
        Lo = ys.reduce(Uo, 0),
        Fo = function() {
            function t(t) {
                void 0 === t && (t = 0), this.Kn = t
            }
            return t.prototype.has = function(t) {
                return !!(this.Kn & t)
            }, t.prototype.set = function(n) {
                if (this.Kn & Lo && n & Lo) {
                    var i = this.Kn | n,
                        r = t.jn(i);
                    this.Kn = t.On(r, this.Kn)
                } else this.Kn |= n
            }, t.prototype.hasKinds = function() {
                return 0 !== this.Kn
            }, t.areEqual = function(t, n) {
                return null == t && null == n || null != t && null != n && t.equals(n)
            }, t.prototype.getStrictestPrivacyKind = function() {
                return t.jn(this.Kn)
            }, t.jn = function(t) {
                for (var n = 0, i = ys; n < i.length; n++) {
                    var r = i[n];
                    if (t & r) return r
                }
                return null
            }, t.needsToObserve = function(t, n) {
                var i, r, e = null !== (i = null == t ? void 0 : t.Kn) && void 0 !== i ? i : 0;
                return !!((null !== (r = null == n ? void 0 : n.Kn) && void 0 !== r ? r : 0) & ~e & No)
            }, t.combineKindsPreservePrivacy = function(n, i) {
                var r, e, s = t.On(null !== (r = null == n ? void 0 : n.Kn) && void 0 !== r ? r : 0, null !== (e = null == i ? void 0 : i.Kn) && void 0 !== e ? e : 0);
                return new t(s)
            }, t.On = function(t, n) {
                return t & Lo | n & No
            }, t.prototype.equals = function(t) {
                return !!t && this.Kn === t.Kn
            }, t
        }();

    function Ho(t, n) {
        throw void 0 === n && (n = "Reached unexpected case in exhaustive switch"), new Error(n)
    }

    function Do(t, n) {
        var i = document.documentElement || document.createElement("div");
        try {
            return t.elMatches(i, n), !0
        } catch (t) {
            return ve("Browser rejected rule", {
                selector: n,
                err: t
            }, "warning"), !1
        }
    }
    var Bo = {
            1: "exclude",
            2: "mask",
            3: "unmask",
            4: "watch",
            5: "keep",
            6: "defer"
        },
        Wo = function() {
            function t(t) {
                this.t = t, this.Un = qo(), this.Nn = qo()
            }
            return t.prototype.forConsentState = function(t) {
                return t ? this.Un : this.Nn
            }, t.prototype.addElementBlockRules = function(t) {
                var n = this,
                    i = qo(),
                    r = qo();
                t.map($o).filter(function(t) {
                    return Vo(t.selector)
                }).forEach(function(t) {
                    if (t.consent) return 8 === t.kind ? void i[t.kind].push(t) : void r[t.kind].push(t);
                    i[t.kind].push(t), r[t.kind].push(t)
                });
                for (var e = document.documentElement || document.createElement("div"), s = function(t, i) {
                        try {
                            if (0 === t.length) return;
                            var r = t.map(function(t) {
                                return t.selector
                            }).join(", ");
                            n.t.elMatches(e, r), i.push(r)
                        } catch (i) {
                            ve("Browser rejected optimistic merge rule", {
                                err: i,
                                ruleCount: t.length
                            }, "warning"), n._t(t)
                        }
                    }, o = 0, u = Ss; o < u.length; o++) {
                    var a = u[o];
                    s(i[a], this.Un[a]), s(r[a], this.Nn[a])
                }
            }, t.prototype.addRule = function(t, n, i) {
                if (this.Ln(t, n, i)) return !0;
                switch (t) {
                    case 16:
                    case 8:
                    case 32:
                    case 64:
                        break;
                    default:
                        this.Un[t].length = 0, this.Un[t].push("*"), this.Nn[t].length = 0, this.Nn[t].push("*")
                }
                return !1
            }, t.prototype.Ln = function(t, n, i) {
                try {
                    if (Vo(i)) {
                        if (n) {
                            var r = this.Fn(t);
                            return Go(this.t, t, r, i)
                        }
                        return Go(this.t, t, this.Nn, i) && Go(this.t, t, this.Un, i)
                    }
                    return !0
                } catch (t) {
                    return ve("Error adding block rule", {
                        selector: i,
                        err: t
                    }), !1
                }
            }, t.prototype.addElementBlock = function(t) {
                var n = $o(t),
                    i = n.kind,
                    r = n.consent,
                    e = n.selector;
                return this.addRule(i, r, e)
            }, t.prototype._t = function(t) {
                for (var n = 0, i = t; n < i.length; n++) {
                    var r = i[n],
                        e = r.kind,
                        s = r.consent,
                        o = r.selector;
                    this.addRule(e, s, o)
                }
            }, t.prototype.Fn = function(t) {
                var n = 8 === t;
                return this.forConsentState(n)
            }, t
        }(),
        zo = function() {
            return Object.create ? Object.create(null) : {}
        };

    function qo() {
        for (var t = zo(), n = 0, i = Ss; n < i.length; n++) t[i[n]] = [];
        return t
    }

    function Vo(t) {
        return !t.match(ts) && "" != t.trim()
    }

    function $o(t) {
        var n = 2;
        switch (t.Type) {
            case 0:
            case 1:
                n = 2;
                break;
            case 2:
                n = 4;
                break;
            case 3:
                n = 8;
                break;
            case 4:
                n = 16;
                break;
            case 5:
                n = 32;
                break;
            case 6:
                n = 64;
                break;
            default:
                Ho(t.Type, "Unexpected block type: ".concat(t.Type))
        }
        return {
            kind: n,
            consent: t.Consent,
            selector: t.Selector
        }
    }

    function Go(t, n, i, r) {
        var e = document.documentElement || document.createElement("div"),
            s = n;
        switch (s) {
            case 2:
            case 4:
            case 8:
            case 16:
            case 32:
            case 64:
                break;
            default:
                s = 2
        }
        if (0 == i[s].length) return !!Do(t, r) && (i[s].push(r), !0);
        var o = i[s].length - 1,
            u = i[s][o].concat(", ", r);
        try {
            t.elMatches(e, u)
        } catch (n) {
            return !!Do(t, r) && (i[s].push(r), ve("Browser rejected merged rule", {
                kind: Bo[s],
                selector: r,
                err: n
            }, "warning"), !0)
        }
        return i[s][o] = u, !0
    }

    function Qo(t) {
        if (!(null == t ? void 0 : t.hasKinds())) return 0;
        var n = t.getStrictestPrivacyKind();
        return null === n ? 0 : ys.length - ys.indexOf(n)
    }
    var Xo = function() {
        function t(t, n) {
            void 0 === n && (n = new Wo(t)), this.t = t, this.Hn = n, this.Dn = !me
        }
        return t.prototype.initialize = function(t) {
            var n = t.blocks,
                i = t.deferreds,
                r = t.keeps,
                e = t.watches,
                o = t.canvasWatcherMode,
                u = t.noDefaultExclusions ? [] : s([], Oo, !0);
            if (n)
                for (var a = 0, c = n; a < c.length; a++) {
                    var h = c[a];
                    u.push(h)
                }
            if (0 === (null != o ? o : 0) && u.push({
                    Consent: !1,
                    Selector: "canvas",
                    Type: 1
                }), e)
                for (var f = 0, v = e; f < v.length; f++) {
                    var l = v[f];
                    u.push({
                        Type: 4,
                        Consent: Kt.RevokeConsent,
                        Selector: l.Selector
                    })
                }
            if (i)
                for (var d = 0, p = i; d < p.length; d++) {
                    var g = p[d];
                    u.push({
                        Type: 6,
                        Consent: Kt.RevokeConsent,
                        Selector: g.Selector
                    })
                }
            if (this.Hn.addElementBlockRules(u), r)
                for (var w = 0, m = r; w < m.length; w++) {
                    var y = m[w];
                    this.addElementKeep(y)
                }
        }, t.prototype.isWatched = function(t) {
            var n, i = new Fo,
                r = this.Hn.forConsentState(null !== (n = this.Bn) && void 0 !== n ? n : Kt.RevokeConsent),
                e = function(t, n, i, r) {
                    return Jo(t, n, i, r, !0)
                }(this.t, t, ys, r),
                s = e | Jo(this.t, t, bs, r);
            return i.set(s), i.hasKinds() ? i : null
        }, t.prototype.addElementBlock = function(t) {
            return this.Hn.addElementBlock(t)
        }, t.prototype.addElementKeep = function(t) {
            return 1 === t.Type && this.Wn(32, t.Consent, t.Selector)
        }, t.prototype.Wn = function(t, n, i) {
            return this.Hn.addRule(t, n, i)
        }, t.prototype.getConsent = function() {
            return this.Bn
        }, t.prototype.initializeConsent = function(t) {
            void 0 === this.Bn && this.zn(t, !1)
        }, t.prototype.setConsent = function(t) {
            this.zn(t, !0)
        }, t.prototype.zn = function(t, n) {
            void 0 === n && (n = !0), this.Bn !== t && (this.Bn = t, n && this.onConsentChange && this.onConsentChange())
        }, t.prototype.allWatchedElements = function(t) {
            var n;
            if (!this.Dn) return null;
            for (var i = new WeakMap, r = !1, e = function(t, n) {
                    var e, s = null !== (e = i.get(t)) && void 0 !== e ? e : new Fo;
                    s.set(n), i.set(t, s), r = !0
                }, s = this.Hn.forConsentState(null !== (n = this.Bn) && void 0 !== n && n), o = 0, u = Ss; o < u.length; o++)
                for (var a = u[o], c = 0, h = s[a]; c < h.length; c++) {
                    var f = h[c];
                    Zo(t) && this.t.elMatches(t, f) && e(t, a);
                    for (var v = Yo(this.t, t, f), l = 0; l < v.length; l++) e(v[l], a)
                }
            return r ? i : null
        }, t
    }();

    function Jo(t, n, i, r, e) {
        void 0 === e && (e = !1);
        for (var s = 0, o = 0, u = i; o < u.length; o++) {
            for (var a = u[o], c = !1, h = 0, f = r[a]; h < f.length; h++) {
                var v = f[h];
                if (t.elMatches(n, v)) {
                    s |= a, c = !0;
                    break
                }
            }
            if (c && e) break
        }
        return s
    }

    function Yo(t, n, i) {
        return Zo(n) ? t.elQuerySelectorAll(n, i) : function(t) {
            return t.nodeType === C
        }(n) ? t.docQuerySelectorAll(n, i) : function(t) {
            return 11 === t.nodeType
        }(n) ? t.docFragQuerySelectorAll(n, i) : n.querySelectorAll(i)
    }

    function Zo(t) {
        return t.nodeType === E
    }
    var tu = function() {
            function t(t) {
                this.C = t, this.qn = {}, this.Vn = {}, this.$n = {}, this.Gn = {}
            }
            return t.create = function(t) {
                var n, i = nu.isSupported(t.window);
                return null === (n = t.queue()) || void 0 === n || n.enqueue({
                    Kind: 58,
                    Args: [17, i]
                }), i ? new nu(t) : new iu(t)
            }, t.prototype.collect = function(t) {
                var n = [];
                for (var i in this.Vn) this.Qn(t, n, parseInt(i, 10));
                return this.Vn = {}, n
            }, t.prototype.isObserved = function(t) {
                return !!this.qn[t]
            }, t.prototype.Xn = function(t, n) {
                try {
                    var i = Ps(t);
                    if (!i) return;
                    if (t.nodeType != E) return;
                    var r = t,
                        e = function(t, n, i) {
                            if ((null == n ? void 0 : n.nodeType) !== E) return {
                                width: 0,
                                height: 0
                            };
                            if (!i || t.arrayIsArray(i) && 0 === i.length) return n.getBoundingClientRect();
                            var r = Array.isArray(i) ? i[0] : i;
                            switch (getComputedStyle(n).writingMode) {
                                case "horizontal-tb":
                                    return {
                                        width: r.inlineSize,
                                        height: r.blockSize
                                    };
                                case "vertical-lr":
                                case "vertical-rl":
                                    return {
                                        width: r.blockSize,
                                        height: r.inlineSize
                                    };
                                default:
                                    return n.getBoundingClientRect()
                            }
                        }(this.C.wdx, r, n);
                    this.Vn[i] = e;
                    var s = this.C.queue();
                    if (!this.qn[i] && void 0 !== s)
                        for (var o = this.Jn(i), u = 0, a = o; u < a.length; u++) {
                            var c = a[u];
                            s.enqueue(c)
                        }
                } catch (t) {}
            }, t.prototype.Qn = function(t, n, r) {
                for (var e = 0, s = this.Jn(r); e < s.length; e++) {
                    var o = s[e];
                    n.push(i(i({}, o), {
                        When: t
                    }))
                }
            }, t.prototype.Jn = function(t) {
                var n = this.Vn[t];
                if (!n) return [];
                var i = Cs(t);
                if (!i) return [];
                var r = i.watchKind,
                    e = n.width,
                    s = n.height,
                    o = this.qn[t];
                if (o && o.width == e && o.height == s) return [];
                this.qn[t] = {
                    width: e,
                    height: s
                };
                var u = [];
                if (null == r ? void 0 : r.has(16)) {
                    var a = 0 != e && 0 != s;
                    (!!o && 0 != o.width && 0 != o.height) != a && u.push({
                        Kind: 56,
                        Args: [t, a]
                    })
                }
                var c = Ts(i.id),
                    h = c && "scrollLeft" in c;
                if ((null == r ? void 0 : r.has(2)) || (null == r ? void 0 : r.has(64)) || i.mask || h) {
                    var f = this.$n[t],
                        v = 0 === e && 0 === s;
                    if (v && (!f || 0 === f.width && 0 === f.height) || (u.push({
                            Kind: 22,
                            Args: [t, e, s]
                        }), v ? delete this.$n[t] : this.$n[t] = {
                            width: e,
                            height: s
                        }), h) {
                        var l = c.scrollWidth,
                            d = c.scrollHeight,
                            p = this.Gn[t],
                            g = 0 === l && 0 === d;
                        g && (!p || 0 === p.width && 0 === p.height) || (u.push({
                            Kind: 43,
                            Args: [t, l, d]
                        }), g ? delete this.Gn[t] : this.Gn[t] = {
                            width: l,
                            height: d
                        })
                    }
                }
                return u
            }, t
        }(),
        nu = function(t) {
            function i(n) {
                var i = t.call(this, n) || this;
                return i.Yn = new WeakMap, i.Zn = new WeakMap, i.ti = new n.window.ResizeObserver(function(t) {
                    So(n.wdx, n.window).then(function() {
                        for (var n = 0, r = t; n < r.length; n++) {
                            var e = r[n],
                                s = e.target,
                                o = e.borderBoxSize;
                            i.Xn(s, o)
                        }
                    })
                }), i.ni = new n.window.ResizeObserver(function(t) {
                    So(n.wdx, n.window).then(function() {
                        for (var n = 0, r = t; n < r.length; n++) {
                            var e = r[n].target;
                            i.ii(e)
                        }
                    })
                }), i
            }
            return n(i, t), i.isSupported = function(t) {
                return "function" == typeof t.ResizeObserver
            }, i.prototype.observe = function(t) {
                var n = this;
                if (t && t.nodeType == E) try {
                    var i = t;
                    this.ti.unobserve(i), this.ti.observe(i), this.C.measurer.enqueue(function() {
                        n.ri(i)
                    })
                } catch (t) {
                    o(function() {
                        return "ResizeWatcher.observe: caught exception ".concat(t)
                    }), he("resize.observe", {
                        err: t
                    })
                }
            }, i.prototype.unobserveSubtree = function(t) {
                try {
                    t && t.nodeType === E && (this.ti.unobserve(t), this.ni.unobserve(t))
                } catch (t) {}
            }, i.prototype.nodeChanged = function(t) {
                var n = this,
                    i = this.Zn.get(t);
                "number" == typeof i && Ps(t) === i && this.C.measurer.enqueue(function() {
                    n.Xn(t)
                })
            }, i.prototype.ii = function(t) {
                var n = this.Yn.get(t);
                if (n)
                    for (var i in n) {
                        var r = Cs(n[i]);
                        if (r) {
                            var e = Ts(r.id);
                            e && this.Xn(e)
                        } else delete n[i]
                    }
            }, i.prototype.ri = function(t) {
                var n = this,
                    i = Ps(t);
                if (i) {
                    var r = function(t) {
                        for (var n = 0, i = t;;) {
                            if (n++ > 1e3) return null;
                            if (!i || i.nodeType != E) return null;
                            var r = i;
                            if (getComputedStyle(r).display.indexOf("inline") < 0) return r;
                            i = K(i)
                        }
                    }(t);
                    if (r && r !== t) {
                        this.Zn.set(t, i), this.Xn(t);
                        var e = this.Yn.get(r);
                        e || (e = Object.create(null), this.Yn.set(r, e)), e[i] = i, this.C.wdx.setWindowTimeout(this.C.window, I(function() {
                            n.ni.unobserve(r), n.ni.observe(r)
                        }), 0)
                    }
                }
            }, i
        }(tu),
        iu = function(t) {
            function i() {
                return null !== t && t.apply(this, arguments) || this
            }
            return n(i, t), i.prototype.observe = function(t) {
                var n = this;
                if (t && t.nodeType == E) {
                    var i = t;
                    ! function(t) {
                        if (t) {
                            var n = Ts(t.id);
                            if (n && ks(n, t))
                                for (var i = t, r = t.parent; r; r = r.parent) {
                                    if (ru(r) || (r.watchedChildren = {}), ru(i))
                                        for (var e in ru(i)) delete ru(r)[e];
                                    if (ru(r)[i.id] = i, G(ru(r), 2)) i = r;
                                    else if (Q(ru(r), 2)) break
                                }
                        }
                    }(Es(t)), this.C.measurer.enqueue(function() {
                        n.Xn(i)
                    })
                }
            }, i.prototype.unobserveSubtree = function(t) {
                var n = Es(t);
                n && function(t) {
                    var n = Ts(t.id);
                    if (n && (Q(ru(t), 0) || ks(n, t)))
                        for (var i = ru(t) && Q(ru(t), 1) || ks(n, t) ? t.id : function(t) {
                                for (var n in t)
                                    if (Object.prototype.hasOwnProperty.call(t, n)) return n
                            }(ru(t)), r = i ? t.parent : null; r && ru(r) && ru(r)[i];) {
                            if (delete ru(r)[i], G(ru(r), 1)) {
                                var e = r.id,
                                    s = $(ru(r));
                                for (r = r.parent; r && ru(r) && ru(r)[e];) delete ru(r)[e], ru(r)[s.id] = s, r = r.parent;
                                break
                            }
                            r = r.parent
                        }
                }(n)
            }, i.prototype.nodeChanged = function(t) {
                var n = this,
                    i = function(t, n) {
                        var i = [],
                            r = Es(n);
                        if (r)
                            for (var e = [r], s = 0; e.length && ++s < 1e3;) {
                                var o = e.pop(),
                                    u = Ts(o.id);
                                u && ks(u, o) && i.push(u), ru(o) && V(t, ru(o), function(t) {
                                    e.push(t)
                                })
                            } else {
                                for (var a = n; a && !Ps(a);) a = K(a);
                                a && ks(a) && i.push(a)
                            }
                        return i
                    }(this.C.wdx, t);
                this.C.measurer.enqueue(function() {
                    for (var t = 0, r = i; t < r.length; t++) {
                        var e = r[t];
                        n.Xn(e)
                    }
                })
            }, i
        }(tu);

    function ru(t) {
        return t.watchedChildren
    }
    var eu = function(t) {
        for (var n = [], i = 0, r = t; i < r.length; i++) {
            var e = r[i],
                s = {
                    Exclude: su(e.Exclude)
                };
            if (e.If) {
                s.If = [];
                for (var o = 0, u = e.If; o < u.length; o++) {
                    var a = u[o];
                    s.If.push(su(a, !0))
                }
            }
            n.push(s)
        }
        return n
    };

    function su(t, n) {
        return void 0 === n && (n = !1), {
            Hash: uu(t.Hash, n),
            Host: uu(t.Host, n),
            Path: uu(t.Path, n),
            QueryParam: uu(t.QueryParam, n),
            Query: uu(t.Query, n)
        }
    }
    var ou = "ig";

    function uu(t, n) {
        return t ? n ? [new RegExp(t.map(function(t) {
            return t.Expression
        }).join("|"), ou)] : t.map(function(t) {
            return new RegExp(t.Expression, ou)
        }) : []
    }
    var au = "--blocked--",
        cu = function(t, n, i, r) {
            if (void 0 === i && (i = au), !n || 0 === t.length) return n;
            for (var e = [], s = 0, o = t; s < o.length; s++)
                for (var u = o[s], a = 0, c = hu(u, n, r); a < c.length; a++) {
                    var h = c[a];
                    e.push(h)
                }
            if (0 === e.length) return n;
            for (var f = "", v = 0, l = 0, d = e = fu(e); l < d.length; l++) {
                var p = d[l],
                    g = p[0],
                    w = p[1];
                f += "".concat(n.substring(v, g)).concat(i), v = w
            }
            return f + n.slice(v)
        },
        hu = function(t, n, i) {
            var r, e = [];
            for (t.lastIndex = 0; null !== (r = t.exec(n));)
                if (r) {
                    if ("" === r[0]) return ".*" !== t.source && i && i("scrub: infinite loop", {
                        re: t.source
                    }), [
                        [0, n.length]
                    ];
                    if (1 !== r.length)
                        for (var s = r.index, o = 0, u = 1; u < r.length; u++) {
                            var a = r[u];
                            if (a && 0 !== a.length)
                                if (u % 2 != 1) {
                                    var c = s + o,
                                        h = c + a.length;
                                    e.push([c, h]), o += a.length
                                } else o += a.length
                        } else e.push([r.index, t.lastIndex])
                }
            return e
        },
        fu = function(t) {
            if (t.length <= 1) return t;
            t.sort(function(t, n) {
                return t[0] - n[0]
            });
            for (var n = [], i = t[0], r = 1; r < t.length; r++) {
                var e = t[r];
                i[1] <= e[0] ? (n.push(i), i = e) : i[1] < e[1] && (i[1] = e[1])
            }
            return n.push(i), n
        },
        vu = function(t) {
            var n = t.blockedToken,
                i = void 0 === n ? au : n,
                r = t.errorReporter,
                e = t.toUrl;
            return function(t, n) {
                for (var s, o, u = e(n), a = {
                        Hash: [],
                        Host: [],
                        Path: [],
                        QueryParam: [],
                        Query: []
                    }, c = 0, h = t; c < h.length; c++) {
                    var f = h[c];
                    pu(f.If, u) && wu(a, f.Exclude)
                }
                if (u.host) {
                    var v = cu(a.Host, u.host, i, r);
                    u.host = v, u.port && (s = v, o = u.port, s.substring(s.length - o.length) !== o) && (u.port = "")
                }
                if (u.pathname = cu(a.Path, mu(u.pathname, u.host), i), u.hash && (u.hash = cu(a.Hash, u.hash, i)), u.search) {
                    var l = du(a.QueryParam, u.search, i);
                    u.search = cu(a.Query, l, i)
                }
                return u.href
            }
        };
    vu({
        blockedToken: au,
        errorReporter: void 0,
        toUrl: function(t) {
            return new URL(t, document.baseURI)
        }
    });
    var lu = function(t, n) {
            if (0 === t.length || !n) return !0;
            for (var i = 0, r = n.split("?"); i < r.length; i++)
                for (var e = 0, s = r[i].replace("?", "").split("&"); e < s.length; e++) {
                    var o = s[e];
                    if (gu(t, o)) return !0
                }
            return !1
        },
        du = function(t, n, i) {
            return void 0 === i && (i = au), n.split("?").map(function(n) {
                return n.replace("?", "").split("&").map(function(n) {
                    return cu(t, n, i)
                }).join("&")
            }).join("?")
        },
        pu = function(t, n) {
            if (!t) return !0;
            for (var i = mu(n.pathname, n.host), r = 0, e = t; r < e.length; r++) {
                var s = e[r];
                if (gu(s.Hash, n.hash) && gu(s.Host, n.host) && gu(s.Path, i) && lu(s.QueryParam, n.search) && gu(s.Query, n.search)) return !0
            }
            return !1
        },
        gu = function(t, n) {
            return 0 === t.length || !n || t.every(function(t) {
                return t.lastIndex = 0, t.test(n)
            })
        },
        wu = function(t, n) {
            var i, r, e, s, o;
            (i = t.Hash).push.apply(i, n.Hash), (r = t.Host).push.apply(r, n.Host), (e = t.Path).push.apply(e, n.Path), (s = t.QueryParam).push.apply(s, n.QueryParam), (o = t.Query).push.apply(o, n.Query)
        };

    function mu(t, n) {
        return n && "/" !== t.charAt(0) ? "/".concat(t) : t
    }
    var yu = ["allowReorder", "attributeName", "attributeType", "autoReverse", "baseFrequency", "baseProfile", "calcMode", "clipPathUnits", "contentScriptType", "contentStyleType", "diffuseConstant", "edgeMode", "externalResourcesRequired", "filterRes", "filterUnits", "glyphRef", "gradientTransform", "gradientUnits", "kernelMatrix", "kernelUnitLength", "keyPoints", "keySplines", "keyTimes", "lengthAdjust", "limitingConeAngle", "markerHeight", "markerUnits", "markerWidth", "maskContentUnits", "maskUnits", "numOctaves", "pathLength", "patternContentUnits", "patternTransform", "patternUnits", "pointsAtX", "pointsAtY", "pointsAtZ", "preserveAlpha", "preserveAspectRatio", "primitiveUnits", "refX", "refY", "referrerPolicy", "repeatCount", "repeatDur", "requiredExtensions", "requiredFeatures", "specularConstant", "specularExponent", "spreadMethod", "startOffset", "stdDeviation", "stitchTiles", "surfaceScale", "systemLanguage", "tableValues", "targetX", "targetY", "textLength", "viewBox", "viewTarget", "xChannelSelector", "yChannelSelector", "zoomAndPan"].reduce(function(t, n) {
            return t[n] = n, t[n.toUpperCase()] = n, t
        }, {}),
        bu = {},
        Su = "__default";

    function _u(t) {
        void 0 === t && (t = Su);
        var n = bu[t];
        return n || (n = function() {
            var t = document.implementation.createHTMLDocument("");
            return t.head || t.documentElement.appendChild(t.createElement("head")), t.body || t.documentElement.appendChild(t.createElement("body")), t
        }(), t !== Su && (n.open(), n.write(t), n.close()), bu[t] = n), n
    }
    var ku = function() {
            function t() {
                var t = _u(),
                    n = t.getElementById("urlresolver-base");
                n || ((n = t.createElement("base")).id = "urlresolver-base", t.head.appendChild(n));
                var i = t.getElementById("urlresolver-parser");
                i || ((i = t.createElement("a")).id = "urlresolver-parser", t.head.appendChild(i)), this.base = n, this.parser = i
            }
            return t.prototype.parseUrlUsingBaseAndAnchor = function(t, n) {
                this.base.setAttribute("href", t), this.parser.setAttribute("href", n);
                var i = document.createElement("a");
                return i.href = this.parser.href, i
            }, t
        }(),
        Iu = null;

    function Au(t, n) {
        var i = t;
        if ("undefined" != typeof URL) try {
            i || (i = document.baseURI);
            var r = i ? new URL(n, i) : new URL(n);
            if (r.href) return r
        } catch (t) {}
        return (Iu || (Iu = new ku), Iu).parseUrlUsingBaseAndAnchor(t, n)
    }

    function Eu(t) {
        var n = t.document,
            i = t.location.href;
        if ("string" == typeof n.baseURI) i = n.baseURI;
        else {
            var r = n.getElementsByTagName("base")[0];
            r && r.href && (i = r.href)
        }
        return "about:blank" == i && t.parent != t ? Eu(t.parent) : i
    }
    var Cu = 16e6,
        Tu = vu({
            blockedToken: au,
            errorReporter: function(t, n) {
                ve(t, n)
            },
            toUrl: function(t) {
                return Au("", t)
            }
        }),
        Pu = /^data:/i,
        xu = function(t, n, i) {
            var r = Tn.DefaultOrgSettings.MaxUrlLength,
                e = eu(Tn.DefaultOrgSettings.UrlPrivacyConfig),
                s = eu(Tn.DefaultOrgSettings.UrlPrivacyConfig),
                o = {};

            function u(t, n) {
                var i = function(t) {
                    var n, i = o[t];
                    return i ? i.lastIndex = 0 : (i = new RegExp("".concat((n = t, is.test(n) ? n.replace(ns, "\\$&") : n), "/?(#)"), "g"), o[t] = i), i
                }(n);
                return t.replace(i, "".concat("https://fs-currenturl.invalid", "$1"))
            }

            function a(t) {
                var n = t.indexOf("#");
                return -1 === n ? t : t.substring(0, n)
            }

            function c(t) {
                try {
                    var r = a(n()),
                        e = a(i()),
                        s = u(t, e);
                    return e !== r && (s = u(s, r)), s
                } catch (n) {
                    return he("cleanCSS", {
                        err: n
                    }), t
                }
            }

            function h(n, i) {
                return t(n, i).substring(0, r)
            }

            function f(t) {
                return h(s, t)
            }

            function v(t) {
                return h(e, t)
            }

            function l(t, n) {
                if (Pu.test(t)) return t;
                switch (n.source) {
                    case "dom":
                        switch (n.type) {
                            case "frame":
                            case "iframe":
                                return v(t);
                            default:
                                return f(t)
                        }
                    case "event":
                        switch (n.type) {
                            case 63:
                            case 37:
                            case 121:
                                return f(t);
                            case 25:
                                return v(t);
                            default:
                                return Ho()
                        }
                    case "log":
                        return v(t);
                    case "page":
                        switch (n.type) {
                            case "base":
                                return v(t);
                            case "referrer":
                            case "url":
                                return f(t);
                            default:
                                return Ho()
                        }
                    case "perfEntry":
                        switch (n.type) {
                            case "frame":
                            case "iframe":
                            case "navigation":
                            case "other":
                                return v(t);
                            default:
                                return f(t)
                        }
                    default:
                        return Ho()
                }
            }

            function d(t, n, i, r, e) {
                if (null === n || "" === r) return null;
                var s, o = "style" === r ? c(e) : e,
                    u = function(t, n, i, r) {
                        var e, s, o, u, a, c, h, f, v, l, d, p, g = [],
                            w = null === (o = null === (s = null === (e = Bu().blocklist[0]) || void 0 === e ? void 0 : e[n]) || void 0 === s ? void 0 : s["static"]) || void 0 === o ? void 0 : o[r],
                            m = null === (c = null === (a = null === (u = Bu().blocklist[0]) || void 0 === u ? void 0 : u["*"]) || void 0 === a ? void 0 : a["static"]) || void 0 === c ? void 0 : c[r];
                        if (void 0 !== w && g.push(w), void 0 !== m && g.push(m), i) {
                            var y = null === (v = null === (f = null === (h = Bu().blocklist[i]) || void 0 === h ? void 0 : h[n]) || void 0 === f ? void 0 : f["static"]) || void 0 === v ? void 0 : v[r],
                                b = null === (p = null === (d = null === (l = Bu().blocklist[i]) || void 0 === l ? void 0 : l["*"]) || void 0 === d ? void 0 : d["static"]) || void 0 === p ? void 0 : p[r];
                            void 0 !== y && g.push(y), void 0 !== b && g.push(b)
                        }
                        if (Bu().hasPrefix) {
                            var S = zu(0, n, r),
                                _ = zu(0, "*", r);
                            if (void 0 !== S && g.push(S), void 0 !== _ && g.push(_), i) {
                                var k = zu(i, n, r),
                                    I = zu(i, "*", r);
                                void 0 !== k && g.push(k), void 0 !== I && g.push(I)
                            }
                        }
                        return function(t, n) {
                            if (0 !== n.length) return t.mathMin.apply(t, n)
                        }(t, g)
                    }(t, n, i, r);
                switch (u) {
                    case void 0:
                        return o;
                    case 0:
                        return null;
                    case 1:
                        return gs(o);
                    case 3:
                        return s = function(t, n, i) {
                            return "".concat(t).concat(Du).concat(i)
                        }, o.replace(Ye, function(t) {
                            for (var n = [], i = 1; i < arguments.length; i++) n[i - 1] = arguments[i];
                            var r = n[0] || n[3] || n[6] || n[9] || n[12],
                                e = (n[1] || n[4] || n[7] || n[10] || n[13], n[2] || n[5] || n[8] || n[11] || n[14]);
                            return n[15], s(r, 0, e)
                        });
                    case 2:
                        if (!("" !== o || "img" !== n && "source" !== n || "src" !== r && "srcset" !== r)) return "";
                        var a = l(o, {
                            source: "dom",
                            type: n
                        });
                        if ("#" === o[0]) {
                            var h = a.indexOf("#");
                            if (h > -1) return a.substring(h)
                        }
                        return a;
                    default:
                        return Ho()
                }
            }
            return {
                scrubUrl: l,
                scrubAttrValue: d,
                scrubAttrs: function(t, n, i, r) {
                    if (function(t, n) {
                            var i, r;
                            return "link" === t && Fu.test(null !== (i = null == n ? void 0 : n.rel) && void 0 !== i ? i : "") && !Hu.test(null !== (r = null == n ? void 0 : n.as) && void 0 !== r ? r : "")
                        }(i, n)) return {};
                    var e, s = {};
                    for (var o in n) {
                        var u = n[o],
                            a = yu[e = o] || e.toLowerCase(),
                            c = d(t, i, r, a, u);
                        null !== c && (s[a] = c)
                    }
                    return s
                },
                initializeUrlPrivacyConfig: function(t, n) {
                    e = eu(Tn.DefaultOrgSettings.UrlPrivacyConfig.concat(t)), s = eu(t), r = n || Tn.DefaultOrgSettings.MaxUrlLength
                },
                cleanCSS: c
            }
        }(Tu, function() {
            return window.location.href
        }, function() {
            return Eu(window)
        }),
        Ru = xu.scrubUrl,
        Mu = (xu.scrubAttrValue, xu.scrubAttrs),
        Ku = xu.initializeUrlPrivacyConfig,
        ju = xu.cleanCSS,
        Ou = /([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9.-]+)/gi,
        Uu = /(?:(http)|(ftp)|(ws)|(blob)|(file))[s]?:\/\/(?:[a-zA-Z]|[0-9]|[$\-_@.&+#/;:=?~']|[!*(),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+/gi;

    function Nu(t) {
        var n = t.replace(Ou, "<email>");
        return n.replace(Uu, function(t) {
            return Ru(t, {
                source: "log",
                type: "debug"
            })
        })
    }
    var Lu, Fu = /^\s*((prefetch|preload|prerender)\s*)+$/i,
        Hu = /^\s*.*((worklet|script|worker|font|fetch)\s*)+$/i,
        Du = "https://fs-excluded.invalid";

    function Bu() {
        return Lu || Wu(), Lu
    }

    function Wu(t) {
        var n, i, r, e, s, o, u, a, c, h, f, v, l, d, p, g;
        try {
            for (var w = (Lu = {
                    blocklist: {},
                    hasPrefix: !1
                }).blocklist, m = (null !== (r = null == t ? void 0 : t.length) && void 0 !== r ? r : 0) > 0 ? t : Tn.DefaultOrgSettings.AttributeBlocklist, y = {}, b = 0, S = m; b < S.length; b++) {
                var _ = S[b],
                    k = _.Action;
                switch (k) {
                    case 0:
                    case 1:
                    case 3:
                    case 2:
                        break;
                    default:
                        ve("initializeAttributeBlocklist#entryAction", {
                            entryAction: k
                        }, "warning"), k = 0
                }
                if (null !== (e = w[h = _.Target]) && void 0 !== e || (w[h] = {}), null !== (s = (f = w[_.Target])[v = _.Tag]) && void 0 !== s || (f[v] = {
                        "static": {},
                        regex: {}
                    }), 1 === _.Type) null !== (o = y[l = _.Target]) && void 0 !== o || (y[l] = {}), null !== (u = (d = y[_.Target])[p = _.Tag]) && void 0 !== u || (d[p] = {}), null !== (a = (g = y[_.Target][_.Tag])[k]) && void 0 !== a || (g[k] = []), y[_.Target][_.Tag][k].push(null !== (c = _.Name) && void 0 !== c ? c : "");
                else {
                    if (!_.Name) {
                        ve("initializeAttributeBlocklist#emptyName", {
                            entry: JSON.stringify(_)
                        }, "warning");
                        continue
                    }
                    w[_.Target][_.Tag]["static"][_.Name] = k
                }
            }
            for (var I in y)
                for (var A in y[I])
                    for (var E in y[I][A]) {
                        var C = y[I][A][E];
                        w[I][A].regex[E] = new RegExp("^(?:".concat(C.join("|"), ")"), "i"), Lu.hasPrefix = !0
                    }
        } catch (t) {
            ve("initializeAttributeBlocklist#fail", {
                err: t
            }, "warning"), Lu = {
                blocklist: (n = {}, n[0] = {
                    "*": {
                        "static": {},
                        regex: (i = {}, i[0] = /.*/, i)
                    }
                }, n),
                hasPrefix: !0
            }
        }
    }

    function zu(t, n, i) {
        var r, e, s = null === (e = null === (r = Bu().blocklist[t]) || void 0 === r ? void 0 : r[n]) || void 0 === e ? void 0 : e.regex;
        if (s)
            for (var o in s)
                if (s[o].test(i)) return Number(o)
    }
    var qu = {
        target: {
            any: 0,
            exclude: 1,
            mask: 2
        },
        action: {
            erase: 0,
            maskText: 1,
            scrubUrl: 2,
            scrubCss: 3
        },
        type: {
            "static": 0,
            prefix: 1
        }
    };

    function Vu(t) {
        var n;
        return {
            Tag: t.tag,
            Name: t.name,
            Target: qu.target[t.target],
            Action: qu.action[t.action],
            Type: qu.type[null !== (n = t.type) && void 0 !== n ? n : "static"]
        }
    }
    var $u = {
        attributeName: null,
        attributeNamespace: null,
        addedNodes: [],
        removedNodes: [],
        nextSibling: null,
        previousSibling: null,
        oldValue: null
    };

    function Gu(t) {
        return i(i(i({}, $u), t), {
            type: "childList"
        })
    }

    function Qu(t, n) {
        return 0 === n.length ? Gu({
            target: t
        }) : Gu({
            addedNodes: n,
            nextSibling: R(n[n.length - 1]),
            previousSibling: M(n[0]),
            target: t
        })
    }

    function Xu(t) {
        var n = [];
        return x(t, function(t) {
            n.push(t)
        }), Qu(t, n)
    }
    var Ju, Yu = {
        sanitize: function(t) {
            var n = t[0],
                i = (t[1], t[2]),
                r = (t[3], t[4]),
                e = t[5];
            if (r) {
                var s = function(t) {
                        var n;
                        return (null === (n = null == t ? void 0 : t.watchKind) || void 0 === n ? void 0 : n.has(2)) ? 1 : (null == t ? void 0 : t.mask) ? 2 : void 0
                    }(i),
                    o = Mu(n, r, i.tag, s);
                t[4] = o
            }
            if (e) {
                var u = function(t, n) {
                    if (!n) return "";
                    if (t.parent && "style" === t.parent.tag) {
                        var i = Ts(t.parent.id);
                        if (i && !lo(i)) return ""
                    }
                    var r = n.length;
                    return r > Cu ? (ve("Ignoring huge text node", {
                        length: r,
                        max: Cu
                    }, "warning"), "") : t.mask ? gs(n) : n
                }(i, e);
                t[5] = u
            }
        }
    };

    function Zu(t, n) {
        return Ju || (Ju = function(t, n) {
            var i, r;
            try {
                if (i = null == (r = n.MutationObserver) ? void 0 : r.prototype.constructor, rr(n)) return r;
                var e = Ae,
                    s = je(Function.prototype.toString, i, e),
                    u = s[0],
                    a = s[1];
                if (u) return u;
                var c = je(Function.prototype.toString, r, e),
                    h = c[0],
                    f = c[1];
                return h || (o(function() {
                    return "findNativeMO: no native MO found"
                }), a[0] || f[0] || i || r)
            } catch (t) {
                return i || r || void 0
            }
        }(0, n)), Ju
    }
    var ta = function() {
        function t(t) {
            this.rebuildFromSnapshot(t)
        }
        return t.create = function(n) {
            return new t(na(n))
        }, t.prototype.rebuildFromSnapshot = function(t) {
            var n = this.snapshot;
            if (this.snapshot = t, !n || n.functions !== t.functions) {
                var i = t.functions;
                this.arrayIsArray = i.arrayIsArray, this.clearWindowInterval = ia(i.clearWindowInterval), this.clearWindowTimeout = ia(i.clearWindowTimeout), this.dateGetTime = ia(i.dateGetTime), this.dateNow = i.dateNow, this.docFragQuerySelectorAll = ia(i.docFragQuerySelectorAll), this.docQuerySelectorAll = ia(i.docQuerySelectorAll), this.elMatches = ia(i.elMatches), this.elQuerySelectorAll = ia(i.elQuerySelectorAll), this.jsonParse = i.jsonParse, this.jsonStringify = i.jsonStringify, this.matchMedia = ra(i.matchMedia), this.mathAbs = i.mathAbs, this.mathFloor = i.mathFloor, this.mathMax = i.mathMax, this.mathMin = i.mathMin, this.mathPow = i.mathPow, this.mathRandom = i.mathRandom, this.mathRound = i.mathRound, this.objectHasOwnProp = ia(i.objectHasOwnProp), this.objectKeys = i.objectKeys, this.objectValues = i.objectValues || null, this.requestWindowAnimationFrame = ra(i.requestWindowAnimationFrame), this.requestWindowIdleCallback = ra(i.requestWindowIdleCallback), this.setWindowInterval = ia(i.setWindowInterval), this.setWindowTimeout = ia(i.setWindowTimeout), this.inputGetValue = ra(i.inputGetValue), this.nodeGetNodeName = ra(i.nodeGetNodeName), this.mutationObserve = ra(i.mutationObserve), this.mutationDisconnect = ra(i.mutationDisconnect), this.snapshot.dirty = t.dirty
            }
        }, t
    }();

    function na(t, n) {
        void 0 === n && (n = 0);
        var i = n,
            r = [],
            e = function(t) {
                return i = 3, r.push("Snapshot failed: ".concat(t)),
                    function() {
                        throw new Error("Invoked failed snapshot")
                    }
            },
            s = function(t) {
                try {
                    return t()
                } catch (t) {
                    return e(t.message)
                }
            },
            o = function(t) {
                try {
                    return t() || e("snapshot not found")
                } catch (t) {
                    return e(t.message)
                }
            },
            u = s(function() {
                return t.Date.now
            }),
            a = s(function() {
                return t.Date.prototype.getTime
            }),
            c = {
                arrayIsArray: s(function() {
                    return t.Array.isArray
                }),
                clearWindowInterval: s(function() {
                    return t.clearInterval
                }),
                clearWindowTimeout: s(function() {
                    return t.clearTimeout
                }),
                dateGetTime: a,
                dateNow: u,
                docFragQuerySelectorAll: o(function() {
                    var n;
                    return null === (n = t.DocumentFragment) || void 0 === n ? void 0 : n.prototype.querySelectorAll
                }),
                docQuerySelectorAll: o(function() {
                    var n;
                    return null !== (n = t.Document.prototype.querySelectorAll) && void 0 !== n ? n : t.document.querySelectorAll
                }),
                elMatches: o(function() {
                    return oa(t, ea)
                }),
                elQuerySelectorAll: o(function() {
                    return oa(t, sa)
                }),
                jsonParse: s(function() {
                    return t.JSON.parse
                }),
                jsonStringify: s(function() {
                    return t.JSON.stringify
                }),
                matchMedia: s(function() {
                    return t.matchMedia
                }),
                mathAbs: s(function() {
                    return t.Math.abs
                }),
                mathFloor: s(function() {
                    return t.Math.floor
                }),
                mathMax: s(function() {
                    return t.Math.max
                }),
                mathMin: s(function() {
                    return t.Math.min
                }),
                mathPow: s(function() {
                    return t.Math.pow
                }),
                mathRandom: s(function() {
                    return t.Math.random
                }),
                mathRound: s(function() {
                    return t.Math.round
                }),
                objectHasOwnProp: s(function() {
                    return t.Object.prototype.hasOwnProperty
                }),
                objectKeys: s(function() {
                    return t.Object.keys
                }),
                objectValues: s(function() {
                    return t.Object.values
                }),
                requestWindowAnimationFrame: s(function() {
                    return t.requestAnimationFrame
                }),
                requestWindowIdleCallback: s(function() {
                    return t.requestIdleCallback
                }),
                setWindowInterval: s(function() {
                    return t.setInterval
                }),
                setWindowTimeout: s(function() {
                    return t.setTimeout
                }),
                mutationObserve: s(function() {
                    var n;
                    return null === (n = t.MutationObserver) || void 0 === n ? void 0 : n.prototype.observe
                }),
                mutationDisconnect: s(function() {
                    var n;
                    return null === (n = t.MutationObserver) || void 0 === n ? void 0 : n.prototype.disconnect
                }),
                inputGetValue: s(function() {
                    var n;
                    return t.HTMLInputElement && (null === (n = Object.getOwnPropertyDescriptor(t.HTMLInputElement.prototype, "value")) || void 0 === n ? void 0 : n.get)
                }),
                nodeGetNodeName: s(function() {
                    var n;
                    return t.Node && (null === (n = Object.getOwnPropertyDescriptor(t.Node.prototype, "nodeName")) || void 0 === n ? void 0 : n.get)
                })
            },
            h = {
                functionToString: s(function() {
                    return t.Function.prototype.toString
                }),
                objectToString: s(function() {
                    return t.Object.prototype.toString
                })
            };
        return {
            status: i,
            functions: c,
            helpers: h,
            errors: r
        }
    }

    function ia(t) {
        return function(n) {
            for (var i = [], r = 1; r < arguments.length; r++) i[r - 1] = arguments[r];
            return t.apply(n, i)
        }
    }

    function ra(t) {
        return t ? ia(t) : null
    }

    function ea(t) {
        return t.matches || t.webkitMatchesSelector || t.msMatchesSelector || t.mozMatchesSelector
    }

    function sa(t) {
        return t.querySelectorAll
    }

    function oa(t, n) {
        var i, r, e = (null === (i = t.Element) || void 0 === i ? void 0 : i.prototype) ? n(null === (r = t.Element) || void 0 === r ? void 0 : r.prototype) : void 0,
            s = t.document ? t.document.documentElement : void 0;
        if (!s || e && s instanceof t.Element || (e = n(s)), !e) throw new Error("Unable to find Element proto function");
        return e
    }

    function ua(t, n) {
        for (var i = 0; i < n.length; i++) {
            var r = n[i];
            if (114 === r.Kind) {
                var e = r.Args,
                    s = e[0],
                    o = e[1];
                ae("function" == typeof o, "resolveEvents"), n[i].Kind = s, n[i].Args = o()
            }
            ae(114 !== r.Kind, "resolveEvents")
        }
        return n
    }

    function aa(t) {
        for (var n = [], i = 0, r = t; i < r.length; i++) {
            var e = r[i];
            if ("function" == typeof e)
                for (var s = 0, o = e(); s < o.length; s++) {
                    var u = o[s];
                    n.push(u)
                } else n.push(e)
        }
        return n
    }
    var ca = function() {
        function t(t, n, i, r, e, s) {
            void 0 === i && (i = function() {}), void 0 === e && (e = function() {}), void 0 === s && (s = function() {});
            var o = this;
            this.C = t, this.Cn = n, this.Pn = r, this.ei = e, this.si = s, this.oi = !1, this.ui = [], this.ai = [], this.ci = [], this.hi = [], this.fi = [], this.vi = !1, this.li = [], this.di = [], this.W = this.C.window, this.acceptSanitizer(Yu), this.acceptVisitor(this), this.Tn = tu.create(this.C), this.xn = function(t) {
                var n = Ts(t.id);
                fa(n) && o.Tn.unobserveSubtree(n), i(t)
            }, this.pi = new Ko(this.C, n, this.Tn, this.Pn, this.xn.bind(this)), ae(!this.Cn.onConsentChange, "mutwatcher#onConsentChange"), this.Cn.onConsentChange = function() {
                return o.updateConsent()
            }
        }
        return t.prototype.start = function(t) {
            void 0 === t && (t = this.W.document), this.wn = t, this.oi = !1;
            var n = !0;
            if (de) try {
                this.gi()
            } catch (t) {
                o(function() {
                    return "Error setting up IE workarounds for mutation watcher: ".concat(t)
                }), n = !1
            }
            if (n) {
                var i = Zu(this.C.wdx, this.C.window);
                this.wi = new i(this.mi.bind(this))
            }
        }, t.prototype.mi = function(t) {
            for (var n = 0, i = t; n < i.length; n++) {
                var r = i[n];
                this.fi.push(r)
            }
        }, t.prototype.resizer = function() {
            return this.Tn
        }, t.prototype.stop = function() {
            if (this.wi) {
                var t = this.C.wdx.mutationDisconnect;
                t ? t(this.wi) : this.wi.disconnect()
            }
            var n = Es(this.wn);
            n && Ks(this.C.wdx, n, this.xn.bind(this)), this.fi = [], de && this.yi(), this.Cn.onConsentChange = null, this.bi && (this.bi.disable(), this.bi = null)
        }, t.prototype.processMutations = function(t) {
            var n = this;
            if (!this.wn) return [];
            this.recordingIsDetached() && he("Recording is detached", {
                inFrame: this.C.recording.inFrame,
                top: this.C.window.top === this.C.window
            });
            var i = [],
                r = !1,
                e = null,
                o = function(s) {
                    return s || r ? (r || (e = n.Si(t, i, n.wn), r = !0), e) : null
                };
            if (this._i(t, i, o), this.vi && (i.push({
                    Kind: 62,
                    Args: [1],
                    When: t
                }), this.vi = !1), this.fi.length > 0 || this.ai.length > 0) {
                var u = this.ki(t, i, o),
                    a = u[0],
                    c = u[1];
                for (var h in c) i.push({
                    Kind: 4,
                    Args: c[h],
                    When: t
                });
                for (var h in a) i.push({
                    Kind: 6,
                    Args: a[h],
                    When: t
                })
            }
            var f = this.ui;
            this.ui = [];
            for (var v = 0; v < f.length; v++) {
                var l = f[v].shadowRoot;
                l && 0 != Ps(f[v]) && 0 == Ps(l) && (this.Ii(l), this.Ai(null, t, i, f[v], l))
            }
            if (i.push.apply(i, this.Tn.collect(t)), this.fi = [], this.hi.length > 0 && (i.push({
                    Kind: 106,
                    Args: s([], this.hi, !0),
                    When: t
                }), this.hi = []), this.ci.length > 0) {
                for (var d = 0, p = this.ci; d < p.length; d++) {
                    var g = p[d];
                    this.hi.push(Ps(g)), O(g) && this.fi.push(Xu(g))
                }
                this.ci = []
            }
            return i
        }, t.prototype.recordingIsDetached = function() {
            return !!this.wn && this.wn != this.W.document
        }, t.prototype._i = function(t, n, i) {
            if (!this.oi && this.wn) {
                h(window, S);
                var r = i(!0);
                this.Ei(r, t, n, null, this.wn, null), this.Tn.nodeChanged(this.wn), this.wi && this.Ii(this.wn), this.Ci(), this.oi = !0, f(window, S)
            }
        }, t.prototype.Si = function(t, n, i) {
            if (!i) return null;
            var r = ft(this.C.wdx),
                e = this.Cn.allWatchedElements(i),
                s = ft(this.C.wdx) - r;
            return n.push({
                Kind: 78,
                Args: [
                    [0, 1, 4, t, s]
                ],
                When: t
            }), e
        }, t.prototype.Ci = function() {
            var t = this;
            this.bi = Be(this.C, Element.prototype, "attachShadow", !0), this.bi && this.bi.before(function(n) {
                n.that.shadowRoot || t.ui.push(n.that)
            })
        }, t.prototype.Ii = function(t) {
            var n;
            try {
                var i = {
                        childList: !0,
                        attributes: !0,
                        characterData: !0,
                        subtree: !0,
                        attributeOldValue: !0,
                        characterDataOldValue: !0
                    },
                    r = this.C.wdx.mutationObserve;
                r ? r(this.wi, t, i) : null === (n = this.wi) || void 0 === n || n.observe(t, i)
            } catch (t) {}
        }, t.prototype.ki = function(t, n, i) {
            for (var r, e, s = this, o = {}, u = {}, a = {}, c = {}, h = function(i) {
                    try {
                        if (!Es(i)) return;
                        s.Ti(t, n, Es(i));
                        var r = Es(K(i));
                        if (r) {
                            var e = Ts(r.id);
                            fa(e) && (c[r.id] = e)
                        }
                    } catch (t) {
                        ve("mutationwatcher#refreshElem", {
                            err: t
                        })
                    }
                }, f = function(i) {
                    var s, f;
                    try {
                        var l = v.fi[i],
                            d = Ps(l.target);
                        if (!d) return "continue";
                        switch (a[d] = l.target, l.type) {
                            case "childList":
                                if ("style" === fs(l.target) && !lo(l.target)) {
                                    h(l.target);
                                    break
                                }
                                if (l.removedNodes.length > 0)
                                    for (var p = 0; p < l.removedNodes.length; ++p)(I = Es(l.removedNodes[p])) && I.id && v.Ti(t, n, I);
                                l.addedNodes.length > 0 && (c[d] = l.target);
                                break;
                            case "characterData":
                                if ((I = Es(l.target)) && !Is(l.target, I)) {
                                    var g = l.target.textContent;
                                    if (l.oldValue === g) break;
                                    var w = K(l.target);
                                    if (w && "style" === fs(w) && !lo(w)) h(w);
                                    else {
                                        var m = [v.C.wdx, 1, I, l.target, void 0, null != g ? g : void 0];
                                        po(v.li, v.di, m, function(t) {
                                            var n;
                                            o[d] = [d, null !== (n = t[5]) && void 0 !== n ? n : ""]
                                        })
                                    }
                                }
                                break;
                            case "attributes":
                                var y = l.target,
                                    b = fs(y);
                                if ("__wayfinder" == l.attributeNamespace) {
                                    "style" == b && "__wayfinder_style_v1" == l.attributeName && v.si(y);
                                    break
                                }
                                if ("link" === b && "rel" === l.attributeName && Fu.test(null !== (r = l.oldValue) && void 0 !== r ? r : "")) {
                                    h(y);
                                    break
                                }
                                var S = function(t, n) {
                                        return void 0 === n && (n = Es(t)), null == n ? void 0 : n.watchKind
                                    }(y),
                                    _ = v.Cn.isWatched(y);
                                if (Qo(_) > Qo(S)) {
                                    h(y);
                                    break
                                }
                                if (Fo.needsToObserve(S, _)) {
                                    v.Tn.observe(y), (null == _ ? void 0 : _.has(16)) && (null === (e = v.Pn) || void 0 === e || e.observe(y));
                                    var k = Es(y);
                                    k && (k.watchKind = Fo.combineKindsPreservePrivacy(S, _))
                                }
                                var I, A = (void 0 === (f = l.attributeNamespace) && (f = ""), (null === f ? "" : {
                                        "http://www.w3.org/1999/xlink": "xlink:",
                                        "http://www.w3.org/XML/1998/namespace": "xml:",
                                        "http://www.w3.org/2000/xmlns/": "xmlns:"
                                    }[f] || "") + (l.attributeName || "")),
                                    E = l.target.getAttribute(A);
                                (I = Es(l.target)) && l.oldValue != E && (m = [v.C.wdx, 1, I, l.target, (s = {}, s[A] = E || "", s), void 0], po(v.li, v.di, m, function(t) {
                                    var n, i = null !== (n = t[4]) && void 0 !== n ? n : {};
                                    for (var r in i) {
                                        var e = i[r];
                                        y.hasAttribute(r) || (e = null), u["".concat(d, " ").concat(r)] = [d, r, e]
                                    }
                                }))
                        }
                    } catch (t) {}
                }, v = this, l = 0; l < this.fi.length; ++l) f(l);
            for (var d = 0, p = this.ai; d < p.length; d++) {
                var g = p[d];
                h(g)
            }
            for (var w in this.ai = [], c) {
                var m = Es(y = c[w]);
                m && m.id && this.Pi(i, t, n, y, m)
            }
            for (var w in a) {
                var y = a[w];
                this.Tn.nodeChanged(y)
            }
            return [o, u]
        }, t.prototype.xi = function(t) {
            return this.oi && t && this.wn ? (this.Ri(this.wn), []) : []
        }, t.prototype.Ri = function(t) {
            var n = this,
                i = K(t);
            Ps(t) || !i ? x(t, function(t) {
                n.Ri(t)
            }) : this.fi.push(Qu(i, [t]))
        }, t.prototype.Pi = function(t, n, i, r, e) {
            var s = [],
                o = e.child;
            for (x(r, function(t) {
                    if (o)
                        for (var n = Es(t); o;) {
                            if (!Ps(t)) {
                                var i = Ts(o.id);
                                fa(i) && s.push({
                                    insert: [r, t, i]
                                });
                                break
                            }
                            if (n && o.id == n.id) {
                                o = o.next;
                                break
                            }
                            s.push({
                                remove: o
                            }), o = o.next
                        } else s.push({
                            insert: [r, t, null]
                        })
                }); o; o = o.next) s.push({
                remove: o
            });
            var u = !1,
                a = t(u);
            if (null === a && this.C.recording.flags().UseRuleOptimization) {
                try {
                    for (var c = 0, h = 0; h < s.length && !u; h++)(v = s[h]).insert && (c += ha(this.C.wdx, v.insert[1])) >= 1e3 && (u = !0)
                } catch (t) {
                    he("ruleOpt", {
                        err: t
                    })
                }
                u && (a = t(u))
            }
            var f = !1;
            for (h = 0; h < s.length; h++) {
                var v;
                (v = s[h]).insert ? this.Ei(a, n, i, v.insert[0], v.insert[1], v.insert[2]) : v.remove && (f = !0, this.Ti(n, i, v.remove))
            }
            ae(!f, "mutwatcher#_diff")
        }, t.prototype.Ai = function(t, n, i, r, e) {
            var s = Ps(r),
                o = ft(this.C.wdx),
                u = this.Mi(t, r, e, null),
                a = ft(this.C.wdx) - o;
            u.length > 0 && i.push({
                Kind: 114,
                Args: [68, function() {
                    return [s, aa(u)]
                }],
                When: n
            }, {
                Kind: 78,
                Args: [
                    [0, 1, 2, n, a]
                ],
                When: n
            })
        }, t.prototype.Ei = function(t, n, i, r, e, s) {
            var o = Ps(r) || -1,
                u = Ps(s) || -1,
                a = -1 === o && -1 === u,
                c = ft(this.C.wdx);
            h(this.C.window, m);
            var v = this.Mi(t, r, e, s);
            f(this.C.window, m);
            var l = ft(this.C.wdx) - c;
            v.length > 0 && (i.push({
                Kind: 114,
                Args: [2, function() {
                    return [o, u, aa(v)]
                }],
                When: n
            }, {
                Kind: 78,
                Args: [
                    [0, 1, a ? 1 : 2, n, l]
                ],
                When: n
            }), this.ei())
        }, t.prototype.Mi = function(t, n, i, r) {
            var e = this;
            return n && Is(n) ? [] : this.pi.tokenizeNode(t, n, r, i, this.li, this.di, function(t, n) {
                switch (n) {
                    case 1:
                        e.refreshElement(t);
                        break;
                    case 2:
                        e.ci.push(t)
                }
            })
        }, t.prototype.Ti = function(t, n, i) {
            var r = i.id;
            if (Ms(this.C.wdx, i, this.xn.bind(this)), n.length > 0) {
                var e = n[n.length - 1];
                if (3 == e.Kind) return void e.Args.push(r)
            }
            n.push({
                Kind: 3,
                Args: [r],
                When: t
            })
        }, t.prototype.gi = function() {
            var n = this;
            if (pe) {
                var r = Object.getOwnPropertyDescriptor(Node.prototype, "textContent"),
                    e = r && r.set;
                if (!r || !e) throw new Error("Missing textContent setter -- not safe to record mutations.");
                Object.defineProperty(Element.prototype, "textContent", i(i({}, r), {
                    set: function(t) {
                        try {
                            for (var n = void 0; n = j(this);) this.removeChild(n);
                            if (null === t || "" == t) return;
                            var i = (this.ownerDocument || document).createTextNode(t);
                            this.appendChild(i)
                        } catch (n) {
                            e && e.call(this, t)
                        }
                    }
                }))
            }
            this.Ki = new Bs(this.C.wdx, this.C.window, t.ThrottleMax, t.ThrottleInterval, function() {
                return new Ds(n.C.wdx, n.C.window, function() {
                    n.vi = !0, n.yi()
                }).start()
            });
            var s = this.Ki.guard(function(t) {
                var n = t.cssText;
                t.cssText = n
            });
            this.Ki.open(), this.ji = Be(this.C, CSSStyleDeclaration.prototype, "setProperty"), this.ji && this.ji.afterSync(function(t) {
                s(t.that)
            }), this.Oi = Be(this.C, CSSStyleDeclaration.prototype, "removeProperty"), this.Oi && this.Oi.afterSync(function(t) {
                s(t.that)
            })
        }, t.prototype.yi = function() {
            this.Ki && this.Ki.close(), this.ji && this.ji.disable(), this.Oi && this.Oi.disable()
        }, t.prototype.updateConsent = function() {
            var t = this;
            this.wn && x(this.wn, function(n) {
                return t.refreshElement(n)
            })
        }, t.prototype.refreshElement = function(t) {
            Ps(t) && this.ai.push(t)
        }, t.prototype.acceptSanitizer = function(t) {
            this.li.push(t)
        }, t.prototype.acceptVisitor = function(t) {
            this.di.push(t)
        }, t.prototype.visit = function(t) {}, t.prototype.preVisit = function(t, n) {
            if (t.type === E && !Is(n, t)) {
                var i = n;
                i.shadowRoot && this.Ii(i.shadowRoot)
            }
        }, t.ThrottleMax = 1024, t.ThrottleInterval = 1e4, t
    }();

    function ha(t, n, i) {
        void 0 === i && (i = !1);
        var r = 1;
        if (!n || n.nodeType !== E) return r;
        var e = n;
        if (r += t.elQuerySelectorAll(e, "*").length, i) {
            var s = e.shadowRoot;
            s && 11 === s.nodeType && (r += t.docFragQuerySelectorAll(s, "*").length)
        }
        return r
    }

    function fa(t) {
        return ae(!!t, "MutationWatcher#nodeNotFound")
    }
    var va, la = function(t, n, r) {
            try {
                if (-1 !== PerformanceObserver.supportedEntryTypes.indexOf(t)) {
                    var e = new PerformanceObserver(function(t) {
                            Promise.resolve().then(function() {
                                n(t.getEntries())
                            })
                        }),
                        s = i({
                            type: t,
                            buffered: !0
                        }, r);
                    return e.observe(s), e
                }
            } catch (t) {}
        },
        da = 0,
        pa = 1 / 0,
        ga = 0;

    function wa(t, n) {
        for (var i = 0, r = n; i < r.length; i++) {
            var e = r[i];
            e.interactionId && (pa = t.mathMin(pa, e.interactionId), ga = t.mathMax(ga, e.interactionId), da = ga ? (ga - pa) / 7 + 1 : 0)
        }
    }

    function ma(t) {
        "interactionCount" in performance || va || (va = la("event", wa.bind(null, t), {
            type: "event",
            buffered: !0,
            durationThreshold: 0
        }))
    }
    var ya = "first-input",
        ba = "largest-contentful-paint",
        Sa = "layout-shift",
        _a = "longtask",
        ka = "event",
        Ia = "mark",
        Aa = "measure",
        Ea = "navigation",
        Ca = "paint",
        Ta = "resource",
        Pa = "long-animation-frame",
        xa = function() {
            function t(t, n, i, r) {
                this.C = t, this.St = n, this.N = i, this.Ui = r, this.Ni = !1, this.Li = !1, this.Fi = Tn.DefaultOrgSettings.MaxPerfMarksPerPage, this.Hi = 0, this.Di = 0, this.Bi = !1, this.Wi = [], this.zi = !1
            }
            return t.prototype.initialize = function(t) {
                var n = t.resourceUploader,
                    i = t.recTimings,
                    r = t.recImgs,
                    e = t.maxPerfMarksPerPage;
                this.qi = n, this.Li = i, this.Ni = r, this.Fi = e || Tn.DefaultOrgSettings.MaxPerfMarksPerPage
            }, t.prototype.start = function() {
                var t = this;
                this.Hi = 0;
                var n = this.Vi();
                this.$i(n);
                var i = window.performance;
                i && (ma(this.C.wdx), this.Wi.length > 0 && i.addEventListener && i.removeEventListener && this.N.add(i, "resourcetimingbufferfull", !0, function() {
                    t.St.enqueue({
                        Kind: 67,
                        Args: []
                    })
                }), this.Gi(), this.Qi())
            }, t.prototype.onLoad = function() {
                if (!this.Bi) {
                    this.Bi = !0;
                    var t = window.performance;
                    t && t.timing && this.Xi(0, t.timing, qt.Timing)
                }
            }, t.prototype.tick = function() {
                this.Gi()
            }, t.prototype.stop = function() {
                this.N.clearAll(), this.qi = void 0;
                var t = [];
                if (this.Wi.length > 0) {
                    for (var n = 0, i = this.Wi; n < i.length; n++) {
                        var r = i[n];
                        t.push.apply(t, Ra(r))
                    }
                    this.Wi = []
                } else window.performance && "function" == typeof window.performance.getEntries && (t = window.performance.getEntries());
                t.length > 300 && (t = t.slice(0, 300), this.St.enqueue({
                    Kind: 67,
                    Args: []
                })), this.Gi(), this.En(t), this.C.taskQueue.flush()
            }, t.prototype.En = function(t) {
                for (var n = this, i = function(t) {
                        r.C.taskQueue.enqueue(function() {
                            return n.Ji(t)
                        })
                    }, r = this, e = 0, s = t; e < s.length; e++) i(s[e])
            }, t.prototype.Vi = function() {
                var t = this;
                if (!window.PerformanceObserver || !window.performance) return [];
                "function" == typeof window.performance.getEntries && this.En(performance.getEntries());
                var n = [];
                return [ka, ya, ba, Sa, _a, Ia, Aa, Ea, Ca, Ta, Pa].forEach(function(i) {
                    var r = {
                        buffered: !0
                    };
                    i === ka && (r.durationThreshold = 40);
                    var e = la(i, t.En.bind(t), r);
                    e && t.Wi.push(e), n.push([i, !!e])
                }), n
            }, t.prototype.Gi = function() {
                var t = window.performance;
                if ((this.C.recording.inWebView || !this.C.recording.inFrame) && t) {
                    var n = t.memory;
                    if (n) {
                        var i = n.usedJSHeapSize - this.Di;
                        (0 === this.Di || this.C.wdx.mathAbs(i / this.Di) > .2) && (this.Xi(6, n, qt.Memory), this.Di = n.usedJSHeapSize)
                    }
                }
            }, t.prototype.Qi = function() {
                var t, n = {
                    timeOrigin: (t = this.C.wdx, ht(t).timeOrigin)
                };
                this.Xi(7, n, qt.TimeOrigin)
            }, t.prototype.Ji = function(t) {
                switch (t.entryType) {
                    case ka:
                        this.Yi(), this.Xi(12, t, qt.EventTiming);
                        break;
                    case ya:
                        this.Xi(9, t, qt.FirstInput);
                        break;
                    case ba:
                        this.Xi(10, t, qt.LargestContentfulPaint);
                        break;
                    case Sa:
                        this.Xi(8, t, qt.LayoutShift);
                        break;
                    case _a:
                        this.Xi(11, t, qt.Measure);
                        break;
                    case Pa:
                        this.Zi(t);
                        break;
                    case Ia:
                        this.Xi(4, t, qt.Measure);
                        break;
                    case Aa:
                        this.Xi(5, t, qt.Measure);
                        break;
                    case Ea:
                        this.Xi(1, t, qt.Navigation, {
                            name: this.C.options.scrubNavLight ? "navigation-light" : Ea
                        });
                        break;
                    case Ca:
                        this.Xi(3, t, qt.Measure);
                        break;
                    case Ta:
                        this.tr(t)
                }
            }, t.prototype.Zi = function(t) {
                if (t.scripts)
                    for (var n = 0, i = t.scripts; n < i.length; n++) {
                        var r = i[n],
                            e = {
                                sourceURL: "script"
                            };
                        "event-listener" === r.invokerType ? e.invoker = function(t) {
                            return t.replace(/\[src=(.*)?\]/gi, function(t, n) {
                                return "[src=".concat(Ru(n, {
                                    source: "perfEntry",
                                    type: "other"
                                }), "]")
                            })
                        } : "classic-script" !== r.invokerType && "module-script" !== r.invokerType || (e.invoker = "script"), this.Xi(15, r, qt.ScriptTiming, e)
                    }
                this.Xi(14, t, qt.LongAnimationFrame)
            }, t.prototype.tr = function(t) {
                if (this.Li) {
                    var n = t.initiatorType;
                    (this.Ni || "img" !== n && "image" !== n) && this.Xi(2, t, qt.Resource, {
                        name: n
                    })
                }
            }, t.prototype.Xi = function(t, n, i, r) {
                if (void 0 === r && (r = {}), !this.atLimit(t)) {
                    for (var e = [t], s = 0, o = i; s < o.length; s++) {
                        var u = o[s],
                            a = n[u];
                        if (void 0 === a && (a = -1), u in r) {
                            var c = r[u];
                            if (L(c)) a = c(a);
                            else {
                                var h = Ru(a, {
                                        source: "perfEntry",
                                        type: c
                                    }),
                                    f = a !== h;
                                a = this.nr(t, n, h, f)
                            }
                        }
                        "target" !== u && "element" !== u || (a = xs(a)), e.push(a)
                    }
                    this.St.enqueue({
                        Kind: 57,
                        Args: e
                    })
                }
            }, t.prototype.nr = function(t, n, i, r) {
                if (2 !== t) return i;
                switch (n.initiatorType) {
                    case "":
                    case "xmlhttprequest":
                    case "fetch":
                    case "script":
                    case "beacon":
                        return i;
                    case "css":
                        if (this.qi && !r) {
                            var e = Au("", i);
                            this.qi.uploadIfNeeded(this.C.window, e, "css")
                        }
                        return this.Ui.obfuscateUrl(i, "css");
                    default:
                        return this.Ui.obfuscateUrl(i)
                }
            }, t.prototype.atLimit = function(t) {
                switch (t) {
                    case 4:
                    case 5:
                        if (this.Hi >= this.Fi) return !0;
                        this.Hi++
                }
                return !1
            }, t.prototype.$i = function(t) {
                for (var n = window.performance, i = [0, !!(null == n ? void 0 : n.timing), 1, "function" == typeof(null == n ? void 0 : n.getEntries), 2, !!(null == n ? void 0 : n.memory), 5, !!window.PerformanceObserver, 7, !!(null == n ? void 0 : n.timeOrigin)], r = 0, e = t; r < e.length; r++) {
                    var s = e[r],
                        o = s[0],
                        u = s[1];
                    switch (o) {
                        case Sa:
                            i.push(9, u);
                            break;
                        case ya:
                            i.push(10, u);
                            break;
                        case ba:
                            i.push(11, u);
                            break;
                        case _a:
                            i.push(12, u)
                    }
                }
                this.St.enqueue({
                    Kind: 58,
                    Args: i
                })
            }, t.prototype.Yi = function() {
                var t = this;
                this.zi || (this.zi = !0, this.C.taskQueue.enqueue(function() {
                    var n = va ? da : performance.interactionCount || 0;
                    t.St.enqueue({
                        Kind: 57,
                        Args: [13, n]
                    }), t.zi = !1
                }))
            }, t
        }();

    function Ra(t) {
        var n = [];
        return t.takeRecords && (n = t.takeRecords()), t.disconnect(), n
    }
    var Ma = "*",
        Ka = "**",
        ja = function() {
            function t(t, n, i) {
                void 0 === n && (n = {}), void 0 === i && (i = !1), this.id = t, this.ir = n, this.rr = i
            }
            return Object.defineProperty(t.prototype, "isTerminal", {
                get: function() {
                    return this.rr
                },
                enumerable: !1,
                configurable: !0
            }), t.prototype.markTerminal = function() {
                this.rr = !0
            }, t.prototype.edgeCount = function() {
                var t = 0;
                for (var n in this.ir) this.getEdge(n) && t++;
                return t
            }, t.prototype.setEdge = function(t, n) {
                this.ir[t] = n
            }, t.prototype.getEdge = function(t) {
                return Object.prototype.hasOwnProperty.call(this.ir, t) ? this.ir[t] : void 0
            }, t
        }();

    function Oa(t, n) {
        void 0 === n && (n = "/");
        var i = 0,
            r = new ja(i++);
        return t.forEach(function(t) {
            var e = t.trim();
            if ("" != e) {
                if (0 === e.indexOf(n) || e.lastIndexOf(n) === e.length - 1) throw new Error("Leading and trailing '".concat(n, "' separators are not supported"));
                var s = r,
                    o = e.split(n);
                o.forEach(function(t, n) {
                    var r = t.trim();
                    if ("" === r) throw new Error("Empty elements are not allowed");
                    if (r !== Ka && r !== Ma && -1 !== r.indexOf(Ma)) throw new Error("Embedded wildcards are not supported");
                    var e = s.getEdge(r);
                    e || (e = new ja(i++), s.setEdge(r, e)), n == o.length - 1 && e.markTerminal(), s = e
                })
            }
        }), r
    }
    var Ua = Oa([Ka]),
        Na = "_fs_trimmed_values";

    function La(t, n, i, r) {
        if (!cc(r)) {
            try {
                for (var e = [], s = 0, o = r; s < o.length; s++) {
                    var u = o[s];
                    if (!u) return;
                    var a = new Fa(!0 === u ? Ua : u);
                    e.push(a)
                }
                var c = function(t, n) {
                        for (var i = {}, r = function(n) {
                                i[n] = function() {
                                    for (var i = [], r = 0; r < arguments.length; r++) i[r] = arguments[r];
                                    for (var e = 0, s = t; e < s.length; e++) {
                                        var o = s[e];
                                        o[n].apply(o, i)
                                    }
                                }
                            }, e = 0, s = ["push", "pop"]; e < s.length; e++) r(s[e]);
                        return i
                    }(e),
                    h = 0,
                    f = [1],
                    v = !1;
                return t.jsonStringify(n, function(n, r) {
                    var s = r,
                        o = typeof s,
                        u = s && H(s);
                    if ("" === n && 1 === f.length) return f[0]--, u && f.push(t.objectKeys(s).length), s;
                    if (c.push(n), e.some(function(t) {
                            return t.isRedacted(!u)
                        }) && (s = Tn.BlockedFieldValue, u = !1), h += n.length + 2, u) h += 2;
                    else if (function(t, n) {
                            return null != t && "symbol" !== n && "function" !== n
                        }(s, o)) try {
                        h += s.toString().length
                    } catch (t) {} else h += 4;
                    for (h >= i && (v ? s = void 0 : (s = Na, v = !0)), f[f.length - 1]--, u && s && s !== Tn.BlockedFieldValue ? f.push(t.objectKeys(s).length) : c.pop(); f[f.length - 1] <= 0;) f.pop(), c.pop();
                    for (var a = 0, l = e; a < l.length; a++) {
                        var d = l[a].depth();
                        if (void 0 !== d && f.length > 0 && d !== f.length - 1) throw new Error("Property matcher depth out of sync")
                    }
                    return s
                })
            } catch (t) {
                ve("allowlistedJson", {
                    err: t,
                    maxLength: i,
                    ctor: n.constructor.name
                })
            }
            return "[error serializing ".concat(n.constructor.name, "]")
        }
    }
    var Fa = function() {
        function t(t) {
            this.er = 1;
            var n = [t],
                i = t.getEdge(Ka);
            i && n.push(i), this.sr = [n]
        }
        return t.positionAt = function(n, i, r) {
            void 0 === r && (r = ".");
            for (var e = new t(n), s = 0, o = i.split(r); s < o.length; s++) {
                var u = o[s];
                if (e.push(u), e.isRedacted(!1)) return null
            }
            return e
        }, t.prototype.ur = function() {
            if (this.sr.length <= 0) return [];
            var t = this.sr.length - 1,
                n = this.sr[t];
            return "number" == typeof n ? this.sr[t - 1] : n
        }, t.prototype.depth = function() {
            return this.er
        }, t.prototype.isRedacted = function(t) {
            var n = this.ur();
            return 0 === n.length || t && !n.some(function(t) {
                return t.isTerminal
            })
        }, t.prototype.push = function(t) {
            this.er++;
            var n = this.ur(),
                i = [];

            function r(n) {
                var e = n.getEdge(Ka);
                e && (i.push(e, Ha(n)), r(e));
                var s = n.getEdge(Ma);
                s && i.push(s);
                var o = n.getEdge(t);
                o && i.push(o)
            }
            for (var e = 0, s = n; e < s.length; e++) {
                var o = s[e],
                    u = o.getEdge(Ka);
                if (null == u ? void 0 : u.isTerminal) {
                    i = [Ha(o), u];
                    break
                }
                r(o)
            }
            var a = !1;
            if (i.length !== n.length) a = !0;
            else
                for (var c = 0; c < i.length; c++)
                    if (i[c].id !== n[c].id) {
                        a = !0;
                        break
                    }
            a ? this.sr.push(i) : ("number" != typeof this.sr[this.sr.length - 1] && this.sr.push(0), this.sr[this.sr.length - 1]++)
        }, t.prototype.pop = function() {
            this.er > 0 && this.er--;
            var t = this.sr[this.sr.length - 1];
            "number" == typeof t && t > 1 ? this.sr[this.sr.length - 1]-- : this.sr.pop()
        }, t.prototype.hasTerminalWildcard = function() {
            return this.ur().some(function(t) {
                var n;
                return null === (n = t.getEdge(Ka)) || void 0 === n ? void 0 : n.isTerminal
            })
        }, t.prototype.hasDescendantRules = function() {
            return this.ur().some(function(t) {
                return t.edgeCount() > 0
            })
        }, t.prototype.isAllowedTerminal = function() {
            return !this.isRedacted(!0) || this.hasTerminalWildcard()
        }, t
    }();

    function Ha(t) {
        var n, i = t.getEdge(Ka);
        if (!i) throw new Error("Node must have double-wildcard edge.");
        return t.edgeCount() <= 1 ? t : new ja(-i.id, ((n = {})[Ka] = i, n))
    }

    function Da(t) {
        for (var n = t.reduce(function(t, n) {
                return t + n.byteLength
            }, 0), i = new ArrayBuffer(n), r = new Uint8Array(i), e = 0, s = 0, o = t; s < o.length; s++) {
            var u = o[s];
            r.set(u, e), e += u.byteLength
        }
        return i
    }

    function Ba(t) {
        if (L(t.arrayBuffer)) return t.arrayBuffer();
        var n = go(),
            i = n.resolve,
            r = n.promise,
            e = new FileReader;
        return e.readAsArrayBuffer(t), e.onload = function() {
            i(e.result)
        }, e.onerror = function(t) {
            he("blob to AB", {
                err: t
            }), i(null)
        }, r
    }

    function Wa(t) {
        return r(this, arguments, void 0, function(t, n) {
            var i, r, s, o, u, a;
            return void 0 === n && (n = -1), e(this, function(e) {
                switch (e.label) {
                    case 0:
                        i = [], r = 0, e.label = 1;
                    case 1:
                        return [4, t.read()];
                    case 2:
                        return s = e.sent(), o = s.value, u = s.done, r += null !== (a = null == o ? void 0 : o.length) && void 0 !== a ? a : 0, n > -1 && r > n && o ? (i.push(o.slice(0, o.length - (r - n))), t.cancel()["catch"](function(t) {}), [2, i]) : u ? [2, i] : (void 0 !== o && i.push(o), [3, 1]);
                    case 3:
                        return [2]
                }
            })
        })
    }
    var za = function(t) {
        return r(void 0, void 0, void 0, function() {
            return e(this, function(n) {
                switch (n.label) {
                    case 0:
                        return [4, Wa(t)];
                    case 1:
                        return [2, Da(n.sent())]
                }
            })
        })
    };

    function qa() {
        return r(this, void 0, void 0, function() {
            var t, n, i, r;
            return e(this, function(e) {
                return t = new TextEncoderStream, n = new CompressionStream("gzip"), t.readable.pipeThrough(n), i = t.writable.getWriter(), r = n.readable.getReader(), [2, [{
                    write: function(t) {
                        return i.ready.then(function() {
                            return i.write(t)
                        })
                    },
                    finalize: function() {
                        return i.ready.then(function() {
                            return i.close()
                        })
                    },
                    onError: function() {
                        i.abort()["catch"](function(t) {}), r.cancel()["catch"](function(t) {})
                    }
                }, za(r)]]
            })
        })
    }

    function Va(t) {
        return r(this, void 0, void 0, function() {
            var n, i, r, s;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        return e.trys.push([0, 5, , 6]), [4, qa()];
                    case 1:
                        return s = e.sent(), n = s[0], i = s[1], [4, n.write(t)];
                    case 2:
                        return e.sent(), [4, n.finalize()];
                    case 3:
                        return e.sent(), [4, i];
                    case 4:
                        return [2, [e.sent(), null]];
                    case 5:
                        return r = e.sent(), null == n || n.onError(), [2, [null, r]];
                    case 6:
                        return [2]
                }
            })
        })
    }

    function $a() {
        return r(this, void 0, void 0, function() {
            return e(this, function(t) {
                switch (t.label) {
                    case 0:
                        return t.trys.push([0, 2, , 3]), [4, Va("fullstory")];
                    case 1:
                        return [2, null != t.sent()[0]];
                    case 2:
                        return t.sent(), [3, 3];
                    case 3:
                        return [2, !1]
                }
            })
        })
    }
    var Ga = ("TextDecoder" in window),
        Qa = ("Request" in window),
        Xa = !no && !Se,
        Ja = "ReadableStream" in window && "function" == typeof ReadableStream.prototype.tee,
        Ya = function() {
            function t(t, n) {
                this.C = t, this.ar = n, this.cr = null, this.hr = Tn.DefaultOrgSettings.MaxAjaxPayloadLength, this.vr = new Ne
            }
            return t.prototype.setMaxAjaxPayloadLength = function(t) {
                this.hr = t || Tn.DefaultOrgSettings.MaxAjaxPayloadLength
            }, t.prototype.disable = function() {
                this.cr && (this.cr.disable(), this.cr = null)
            }, t.prototype.enable = function(t) {
                var n, i = this,
                    s = Oi(t, this.C.options.namespace),
                    o = null === (n = null == s ? void 0 : s._w) || void 0 === n ? void 0 : n.fetch;
                (o || t.fetch) && (this.cr = Be(this.C, o ? s._w : t, "fetch"), this.cr && (this.cr.before(function(t) {
                    i.lr(t)
                }), this.cr.afterSync(function(t) {
                    var n = t.result;
                    t.result = r(i, void 0, void 0, function() {
                        return e(this, function(i) {
                            switch (i.label) {
                                case 0:
                                    return i.trys.push([0, 2, , 3]), [4, this.dr(n, t.args[0], t.args[1])];
                                case 1:
                                case 2:
                                    return i.sent(), [3, 3];
                                case 3:
                                    return [2, n]
                            }
                        })
                    })
                })))
            }, t.prototype.lr = function(t) {
                if (Ja && Ga && Xa) try {
                    var n = t.args[0],
                        i = t.args[1];
                    if (Qa && !z(n) && "url" in n && n instanceof Request && Xa && n.body instanceof ReadableStream && Za(n.headers)) {
                        var r = n.clone(),
                            e = nc(this.C.wdx, this.C.window, r.body, this.hr);
                        return void this.vr.set(n, e)
                    }
                    if (i) {
                        var s = yc(this.C.wdx, i.headers);
                        if (i.body && i.body instanceof ReadableStream && Za(s) && Xa) {
                            var o = i.body.tee(),
                                u = o[0],
                                a = o[1];
                            i.body = a, e = nc(this.C.wdx, this.C.window, u, this.hr), this.vr.set(i, e)
                        }
                    }
                } catch (t) {}
            }, t.prototype.dr = function(t, n, i) {
                return r(this, void 0, void 0, function() {
                    var s, o, u, a, c, h;
                    return e(this, function(f) {
                        switch (f.label) {
                            case 0:
                                return s = "GET", o = "", c = !1, "string" != typeof n ? [3, 1] : (o = n, [3, 5]);
                            case 1:
                                return "url" in n ? (o = n.url, s = n.method, u = n.body, a = n.headers, c = !!n.signal, this.vr.has(n) ? [4, this.pr(n)] : [3, 3]) : [3, 4];
                            case 2:
                                u = f.sent(), f.label = 3;
                            case 3:
                                return [3, 5];
                            case 4:
                                o = "".concat(n), f.label = 5;
                            case 5:
                                return o ? i ? (s = i.method || s, a = yc(this.C.wdx, i.headers), this.vr.has(i) ? [4, this.pr(i)] : [3, 7]) : [3, 9] : [2];
                            case 6:
                                return u = f.sent(), [3, 8];
                            case 7:
                                u = i.body || u, f.label = 8;
                            case 8:
                                c = !!i.signal || c, f.label = 9;
                            case 9:
                                return h = function(t) {
                                    return r(this, void 0, void 0, function() {
                                        var n, i, r, s, o;
                                        return e(this, function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return e.trys.push([0, 6, , 7]), [4, t];
                                                case 1:
                                                    switch (n = e.sent(), o = n.ok ? 1 : 4, n.type) {
                                                        case "opaque":
                                                        case "opaqueredirect":
                                                            o = 3;
                                                            break;
                                                        case "error":
                                                            o = 4
                                                    }
                                                    if (!tc(((i = n.headers).get("content-type") || Tn.TextPlain).split(";")[0])) return [2, ec(o, n.status, {
                                                        headers: i,
                                                        body: null
                                                    })];
                                                    r = null, e.label = 2;
                                                case 2:
                                                    return e.trys.push([2, 4, , 5]), [4, n.clone().text()];
                                                case 3:
                                                    return r = e.sent(), [3, 5];
                                                case 4:
                                                    return e.sent(), o = 2, [3, 5];
                                                case 5:
                                                    return [2, ec(o, n.status, {
                                                        headers: i,
                                                        body: r
                                                    })];
                                                case 6:
                                                    return s = e.sent(), [2, ec(o = (u = s) && "AbortError" === u.name ? 2 : 4, 0, {
                                                        headers: {
                                                            forEach: function() {}
                                                        },
                                                        body: void 0
                                                    })];
                                                case 7:
                                                    return [2]
                                            }
                                            var u
                                        })
                                    })
                                }(t), c && o.search(/\/(?:graph|graphql|gql)/i) > -1 ? [4, Promise.race([h, wo(this.C.wdx, this.C.window, 5e3)])] : [3, 11];
                            case 10:
                                f.sent(), f.label = 11;
                            case 11:
                                return this.ar.startRequest(s, o, {
                                    body: function() {
                                        return u
                                    },
                                    headers: a
                                }, h), [2]
                        }
                    })
                })
            }, t.prototype.pr = function(t) {
                return r(this, void 0, void 0, function() {
                    var n;
                    return e(this, function(i) {
                        switch (i.label) {
                            case 0:
                                return [4, Promise.race([this.vr.get(t), wo(this.C.wdx, this.C.window, 5e3).then(function() {
                                    return null
                                })])];
                            case 1:
                                return n = i.sent(), this.vr["delete"](t), [2, n]
                        }
                    })
                })
            }, t
        }();

    function Za(t) {
        var n = Tn.TextPlain;
        return null == t || t.forEach(function(t, i) {
            "content-type" === i.toLowerCase() && (n = t)
        }), tc(n)
    }

    function tc(t) {
        switch (t) {
            case "application/json":
            case "application/vnd.api+json":
            case Tn.TextPlain:
                return !0
        }
        return !1
    }

    function nc(t, n, i, s) {
        return r(this, void 0, void 0, function() {
            var r, o, u, a, c;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (!Ga) return [2, ""];
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), r = new TextDecoder, o = i.getReader(), u = Wa(o, s).then(function(t) {
                            return t.map(function(t) {
                                return r.decode(t)
                            }).join("")
                        }), a = wo(t, n, 2e3).then(function() {
                            return "_fs_timeout"
                        }), [4, Promise.race([u, a])];
                    case 2:
                        return "_fs_timeout" === (c = e.sent()) ? (o.cancel()["catch"](function(t) {}), [2, ""]) : [2, c];
                    case 3:
                        return e.sent(), [2, ""];
                    case 4:
                        return [2]
                }
            })
        })
    }
    var ic = function() {
            function t(t, n) {
                this.C = t, this.ar = n, this.gr = new WeakMap
            }
            return t.prototype.disable = function() {
                this.wr && (this.wr.disable(), this.wr = null), this.mr && (this.mr.disable(), this.mr = null), this.yr && (this.yr.disable(), this.yr = null)
            }, t.prototype.br = function(t) {
                var n = this.gr.get(t);
                if (n) return n;
                var i = {};
                return this.gr.set(t, i), i
            }, t.prototype.enable = function(t) {
                var n, i, s, o, u = this,
                    a = Oi(t, this.C.options.namespace),
                    c = (null === (n = null == a ? void 0 : a._w) || void 0 === n ? void 0 : n.XMLHttpRequest) || t.XMLHttpRequest;
                if (c) {
                    var h = c.prototype;
                    this.wr = null === (i = Be(this.C, h, "open")) || void 0 === i ? void 0 : i.before(function(t) {
                        var n = u.br(t.that);
                        n.method = t.args[0], n.url = t.args[1]
                    }), this.yr = null === (s = Be(this.C, h, "setRequestHeader")) || void 0 === s ? void 0 : s.before(function(t) {
                        var n = t.that,
                            i = t.args[0],
                            r = t.args[1],
                            e = u.br(n);
                        e.headers || (e.headers = []), e.headers.push([i, r])
                    }), this.mr = null === (o = Be(this.C, h, "send")) || void 0 === o ? void 0 : o.before(function(t) {
                        var n = t.that,
                            i = t.args[0],
                            s = u.br(n),
                            o = s.url,
                            a = s.method,
                            c = s.headers;
                        void 0 !== o && void 0 !== a && (u.gr["delete"](n), u.ar.startRequest(a, o, {
                            headers: yc(u.C.wdx, c),
                            body: i
                        }, function(t) {
                            return r(this, void 0, void 0, function() {
                                var n, i;
                                return e(this, function(r) {
                                    switch (r.label) {
                                        case 0:
                                            return [4, new Promise(function(n) {
                                                t.addEventListener("load", function() {
                                                    return n(1)
                                                }), t.addEventListener("abort", function() {
                                                    return n(2)
                                                }), t.addEventListener("readystatechange", function() {
                                                    t.readyState === XMLHttpRequest.DONE && 0 !== t.status && (t.status < 400 ? n(1) : n(4))
                                                }), t.addEventListener("error", function() {
                                                    t.readyState === t.UNSENT ? n(2) : n(4)
                                                })
                                            })];
                                        case 1:
                                            return n = r.sent(), i = function(t) {
                                                if (t) return {
                                                    forEach: function(n) {
                                                        for (var i, r = /([^:]*):\s+(.*)(?:\r\n|$)/g; i = r.exec(t);) n(i[2], i[1])
                                                    }
                                                }
                                            }(t.getAllResponseHeaders()), [2, ec(n, t.status, {
                                                headers: i,
                                                body: function() {
                                                    return "text" === t.responseType ? t.responseText : t.response
                                                }
                                            })]
                                    }
                                })
                            })
                        }(n)))
                    })
                }
            }, t.prototype.setMaxAjaxPayloadLength = function(t) {}, t
        }(),
        rc = /\r?\n|\r/;

    function ec(t, n, i) {
        return {
            state: t,
            status: n,
            data: i
        }
    }
    var sc, oc = /^data:/i,
        uc = function() {
            function t(t, n) {
                this.C = t, this.St = n, this.Jt = !1, this.Sr = new ac(t, n), this._r = new ic(t, this.Sr), this.kr = new Ya(t, this.Sr)
            }
            return t.prototype.isEnabled = function() {
                return this.Jt
            }, t.prototype.start = function(t) {
                t.AjaxWatcher && (this.Jt || (this.Jt = !0, this.St.enqueue({
                    Kind: 58,
                    Args: [4, !0]
                }), this._r.enable(this.C.window), this.kr.enable(this.C.window)))
            }, t.prototype.stop = function() {
                this.Jt && (this.Jt = !1, this._r.disable(), this.kr.disable())
            }, t.prototype.tick = function() {
                this.Sr.tick()
            }, t.prototype.setWatches = function(t) {
                this.Sr.setWatches(t)
            }, t.prototype.initialize = function(t) {
                this.Sr.initialize(t), this.kr.setMaxAjaxPayloadLength(t.maxAjaxPayloadLength)
            }, t
        }(),
        ac = function() {
            function t(t, n) {
                this.C = t, this.St = n, this.Ir = [], this.Ar = {}, this.Er = {}, this.Cr = [], this.hr = 0;
                var i = Tn.DefaultOrgSettings;
                this.initialize({
                    requests: i.HttpRequestHeadersAllowlist,
                    responses: i.HttpResponseHeadersAllowlist,
                    maxAjaxPayloadLength: i.MaxAjaxPayloadLength
                })
            }
            return t.prototype.Tr = function(t) {
                for (var n = !1, i = !1, r = [], e = [], s = 0, o = this.Ir; s < o.length; s++) {
                    var u = o[s],
                        a = u.urlPattern,
                        c = u.reqFields,
                        h = u.rspFields;
                    if (n && i) break;
                    a.test(t) && (!1 === c && (r = [!1], n = !0), n || r.push(c), !1 === h && (e = [!1], i = !0), i || e.push(h))
                }
                return [r, e]
            }, t.prototype.Pr = function(t) {
                this.Cr.push(t)
            }, t.prototype.setWatches = function(t) {
                this.Ir = t.map(function(t) {
                    return {
                        urlPattern: new RegExp(t.URLRegex),
                        reqFields: gc(t.RecordReq, t.ReqAllowlist),
                        rspFields: gc(t.RecordRsp, t.RspAllowlist)
                    }
                })
            }, t.prototype.initialize = function(t) {
                var n = this,
                    i = t.requests,
                    r = t.responses,
                    e = t.maxAjaxPayloadLength;
                this.Ar = {}, this.Er = {}, null == i || i.forEach(function(t) {
                    return n.Ar[t] = !0
                }), null == r || r.forEach(function(t) {
                    return n.Er[t] = !0
                }), this.hr = e || Tn.DefaultOrgSettings.MaxAjaxPayloadLength
            }, t.prototype.addHeaderAllowlist = function(t, n) {
                var i = this;
                null == t || t.forEach(function(t) {
                    return i.Ar[t] = !0
                }), null == n || n.forEach(function(t) {
                    return i.Er[t] = !0
                })
            }, t.prototype.tick = function() {
                for (var t = 0; t < this.Cr.length; t++) this.St.enqueue({
                    Kind: 63,
                    Args: this.Cr[t]
                });
                this.Cr = []
            }, t.prototype.startRequest = function(t, n, i, s) {
                return r(this, void 0, void 0, function() {
                    var r, o, u, a, c, h, f, v, l, d, p, g, w, m, y;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return oc.test(n) ? [2] : (r = ft(this.C.wdx), o = function(t, n) {
                                    var i = Eu(t);
                                    return null == i ? n : function(t, n) {
                                        var i, r;
                                        return null !== (r = null === (i = Au(t, n)) || void 0 === i ? void 0 : i.href) && void 0 !== r ? r : n
                                    }(i, n)
                                }(this.C.window, n), u = this.Tr(o), a = u[0], c = u[1], [4, this.Rr(a, i)]);
                            case 1:
                                return h = e.sent(), [4, s["catch"](function() {
                                    return ec(4, 0, {
                                        headers: {
                                            forEach: function() {}
                                        },
                                        body: void 0
                                    })
                                })];
                            case 2:
                                return f = e.sent(), v = f.state, l = f.status, d = f.data, p = ft(this.C.wdx) - r, [4, this.Mr(c, d)];
                            case 3:
                                return g = e.sent(), w = [t, Ru(o, {
                                    source: "event",
                                    type: 63
                                }), p, l, h.headers, g.headers, r, h.size, g.size, null !== (m = h.text) && void 0 !== m ? m : null, null !== (y = g.text) && void 0 !== y ? y : null, h.legibility, g.legibility, v], this.Pr(w), [2]
                        }
                    })
                })
            }, t.prototype.Rr = function(t, n) {
                return wc(this.C.wdx, this.Ar, t, this.hr, n)
            }, t.prototype.Mr = function(t, n) {
                return wc(this.C.wdx, this.Er, t, this.hr, n)
            }, t
        }();

    function cc(t) {
        return 0 === t.length || t.indexOf(!1) > -1
    }

    function hc(t, n, i, r) {
        return [n.length, pc(t, n, i, r)]
    }

    function fc(t, n, i, r) {
        var e = void 0;
        return cc(i) || (e = La(t, n, r, i)), [dc(t, n), e]
    }

    function vc(t, n) {
        var i = t.byteLength,
            r = void 0;
        return cc(n) || (r = "[ArrayBuffer]"), [i, r]
    }

    function lc(t, n, i, s) {
        return r(this, void 0, void 0, function() {
            var r, o, u, a, c, h, f;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (o = (r = n).size, u = r.type, cc(i)) return [2, [o, void 0]];
                        if (a = function(t) {
                                ve("ajaxwatcher#_httpBodyBlob", {
                                    err: t,
                                    blobType: u,
                                    blobSize: o
                                }, "warning")
                            }, !tc(u)) return [3, 4];
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, r.text()["catch"](function(t) {
                            a(t)
                        })];
                    case 2:
                        return (c = e.sent()) && (h = pc(t, c, i, s)) ? [2, [o, h]] : [3, 4];
                    case 3:
                        return f = e.sent(), a(f), [3, 4];
                    case 4:
                        return [2, [o, "[Blob]"]]
                }
            })
        })
    }

    function dc(t, n) {
        try {
            return t.jsonStringify(n).length
        } catch (t) {}
        return 0
    }

    function pc(t, n, i, r) {
        if (!cc(i)) try {
            return La(t, t.jsonParse(n), r, i)
        } catch (t) {
            return i.length > 0 && i.every(function(t) {
                return !0 === t
            }) ? n.slice(0, r) : void 0
        }
    }

    function gc(t, n) {
        switch (t) {
            default:
                case 0:
                return !1;
            case 1:
                    return !0;
            case 2:
                    try {
                    return Oa(n.split(rc))
                } catch (t) {
                    return o(function() {
                        return "error parsing field allowlist (".concat(n, ": ").concat(t)
                    }), !1
                }
        }
    }

    function wc(t, n, i, s, o) {
        return r(this, void 0, void 0, function() {
            var r, u, a, c, h, f, v;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        return r = "", null === (v = o.headers) || void 0 === v || v.forEach(function(t, i) {
                            var e = i.toLowerCase(),
                                s = n[e];
                            r += "".concat(e).concat(s ? ": ".concat(t) : "").concat("\r\n")
                        }), "function" != typeof(u = null == o ? void 0 : o.body) ? [3, 2] : [4, u()];
                    case 1:
                        return a = e.sent(), [3, 3];
                    case 2:
                        a = u, e.label = 3;
                    case 3:
                        return [4, mc(t, i, a, s)];
                    case 4:
                        return c = e.sent(), h = c[0], f = c[1], [2, {
                            headers: r,
                            text: f,
                            size: h,
                            legibility: 0 !== h || f ? 1 : 0
                        }]
                }
            })
        })
    }

    function mc(t, n, i) {
        return r(this, arguments, void 0, function(t, n, i, r) {
            var s;
            return void 0 === r && (r = Tn.DefaultOrgSettings.MaxAjaxPayloadLength), e(this, function(e) {
                if (null == i) return [2, [0, void 0]];
                switch (typeof i) {
                    default: return [2, [-1, cc(n) ? void 0 : "[unknown]"]];
                    case "string":
                            return [2, hc(t, i, n, r)];
                    case "object":
                            switch (s = i.constructor) {
                            case Object:
                            default:
                                return [2, fc(t, i, n, r)];
                            case Blob:
                                return [2, lc(t, i, n, r)];
                            case ArrayBuffer:
                                return [2, vc(i, n)];
                            case Document:
                            case FormData:
                            case URLSearchParams:
                            case ReadableStream:
                                return [2, [-1, cc(n) ? void 0 : "".concat(s.name)]]
                        }
                }
                return [2]
            })
        })
    }

    function yc(t, n) {
        return n ? U(t, n) ? {
            forEach: function(t) {
                for (var i = 0, r = n; i < r.length; i++) {
                    var e = r[i],
                        s = e[0];
                    t(e[1], s)
                }
            }
        } : "function" == typeof n.forEach ? n : {
            forEach: function(t) {
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && t(n[i], i)
            }
        } : n
    }
    var bc = "EventQueue not defined",
        Sc = "_fs_stylesheet_hooked",
        _c = ["CSSMediaRule", "CSSSupportsRule"],
        kc = function() {
            function t(t, n, i) {
                void 0 === i && (i = Ds);
                var r = this;
                this.C = t, this.St = n, this.tn = [], this.Et = [], this.Kr = 1, this.jr = !1, this.Or = new Map, this.Ur = new Ne, this.Nr = new Ne, this.Lr = 0, this.Fr = new Ne(void 0, Se), this.Hr = new Set, this.Dr = new Ne, this.Br = new Ne, this.Wr = new Bs(this.C.wdx, this.C.window, 1e4, 1e4, function() {
                    return setTimeout(function() {
                        r.St.enqueue({
                            Kind: 62,
                            Args: [0]
                        }), r.stop()
                    })
                }), this.addInsert = this.Wr.guard(this.addInsert), this.addDelete = this.Wr.guard(this.addDelete), this.zr = new i(this.C.wdx, this.C.window, function() {
                    r.qr()
                }, 50), this.Vr = J(function(t, n) {
                    var i, e;
                    if (!(null === (i = t.parentRule) || void 0 === i ? void 0 : i.parentStyleSheet) || !r.jr) return !0;
                    var s = t.parentRule;
                    return r.Or.has(s) || r.Or.set(s, new Set), null === (e = r.Or.get(s)) || void 0 === e || e.add(n), r.zr.isRunning() || r.zr.start(), !0
                })
            }
            return t.prototype.start = function() {
                var t, n, i = this;
                this.Wr.open();
                var r = this.C.window;
                if (r.CSSStyleSheet && r.StyleSheet) {
                    var e = r.CSSStyleSheet.prototype;
                    this.cr(e), this.$r(r), this.Gr(), this.Et.push(tt(r.StyleSheet, "disabled", function(t, n) {
                        return i.onDisableSheet(t, n)
                    })), this.Qr(null === (t = r.Document) || void 0 === t ? void 0 : t.prototype), this.Qr(null === (n = r.ShadowRoot) || void 0 === n ? void 0 : n.prototype), this.jr = !0
                }
            }, t.prototype.Qr = function(t) {
                var n = this;
                t && !this.Br.has(t) && (this.Br.set(t, !0), this.Et.push(nt(t, "adoptedStyleSheets", function(t, i) {
                    return n.onSetAdoptedStyleSheets(t, i)
                }, function(t, i) {
                    return n.Xr(t)
                })))
            }, t.prototype.$r = function(t) {
                var n, i, r = this,
                    e = function(t) {
                        var n = Be(r.C, t, "insertRule");
                        n && (n.afterSync(function(t) {
                            r.Jr(t.that, t.args[0], t.args[1])
                        }), r.tn.push(n)), (n = Be(r.C, t, "deleteRule")) && (n.afterSync(function(t) {
                            r.Yr(t.that, t.args[0])
                        }), r.tn.push(n))
                    };
                if ("function" == typeof(null === (n = t.CSSGroupingRule) || void 0 === n ? void 0 : n.prototype.insertRule)) e(t.CSSGroupingRule.prototype);
                else
                    for (var s = 0, o = _c; s < o.length; s++) {
                        var u = null === (i = t[o[s]]) || void 0 === i ? void 0 : i.prototype;
                        u && e(u)
                    }
            }, t.prototype.Gr = function() {
                var t = this;
                if (!this.jr) {
                    var n = Be(this.C, CSSStyleDeclaration.prototype, "setProperty");
                    n && (n.afterSync(function(n) {
                        t.Vr(n.that, n.args[0])
                    }), this.tn.push(n));
                    var r = CSSStyleRule.prototype,
                        e = Object.getOwnPropertyDescriptor(r, "style");
                    this.Zr || (this.Zr = null == e ? void 0 : e.get);
                    var s = this;
                    this.te = function() {
                        var t, n = null === (t = null == e ? void 0 : e.get) || void 0 === t ? void 0 : t.apply(this);
                        return J(function() {
                            n = s.ne(n)
                        })(), n
                    };
                    try {
                        Object.defineProperty(r, "style", i(i({}, e), {
                            get: s.te
                        }))
                    } catch (t) {}
                }
            }, t.prototype.ne = function(t) {
                var n = this.Ur.get(t);
                if (n) return n;
                var i = function(t, n, i) {
                        var r = i.onPropertyGet,
                            e = i.onPropertySet,
                            s = i.onPropertyDelete;
                        if ("function" != typeof t.Proxy) {
                            for (var o = [], u = function(t) {
                                    if ("function" == typeof n[t]) return "continue";
                                    var i = nt(n, t, e ? function(n, i) {
                                        return e(n, t, i)
                                    } : void 0, r ? function(n, i) {
                                        return r(n, t, i)
                                    } : void 0);
                                    o.push(i)
                                }, a = 0, c = t.Object.keys(n); a < c.length; a++) u(c[a]);
                            return {
                                proxy: n,
                                teardown: function() {
                                    return o.forEach(function(t) {
                                        return t()
                                    })
                                }
                            }
                        }
                        var h = new t.Proxy(n, {
                            get: function(t, n) {
                                var i = t[n];
                                if ("function" != typeof i) return r && "string" == typeof n && (r(t, n, i), i = t[n]), i;
                                var e = i;
                                return function() {
                                    for (var n = [], i = 0; i < arguments.length; i++) n[i] = arguments[i];
                                    var r = this;
                                    return r === h && (r = t), e.apply(r, n)
                                }
                            },
                            set: function(t, n, i) {
                                var r = t[n];
                                return t[n] = i, "function" == typeof r || "symbol" == typeof n || e && e(t, n, i), !0
                            },
                            deleteProperty: function(t, n) {
                                if ("symbol" == typeof n) return delete t[n], !0;
                                var i = (n in t);
                                return delete t[n], i && s && s(t, n), !0
                            }
                        });
                        return {
                            proxy: h,
                            teardown: function() {}
                        }
                    }(this.C.window, t, {
                        onPropertySet: I(this.Vr)
                    }),
                    r = i.proxy,
                    e = i.teardown;
                return this.Et.push(e), this.Ur.set(t, r), r
            }, t.prototype.qr = function() {
                var t = this,
                    n = this.Or;
                this.Or = new Map, n.forEach(function(n, i) {
                    var r = i.parentStyleSheet;
                    if (r) {
                        var e = t.ie(r, i);
                        if (void 0 !== e) {
                            var s = {};
                            n.forEach(function(t) {
                                s[t] = i.style[t]
                            }), t.ee(r, function(t) {
                                t.enqueue({
                                    Kind: 102,
                                    Args: [e, s]
                                })
                            })
                        }
                    }
                })
            }, t.prototype.Jr = function(t, n, i) {
                var r = Rc(this.C.wdx, t);
                this.addInsert(t.parentStyleSheet, n, i, r)
            }, t.prototype.Yr = function(t, n) {
                var i = Rc(this.C.wdx, t);
                this.addDelete(t.parentStyleSheet, n, i)
            }, t.prototype.cr = function(t) {
                var n, i = this;
                (n = Be(this.C, t, "insertRule")) && (n.afterSync(function(t) {
                    i.addInsert(t.that, t.args[0], t.args[1])
                }), this.tn.push(n)), (n = Be(this.C, t, "addRule")) && (n.afterSync(function(t) {
                    i.addInsert(t.that, "".concat(t.args[0], " {").concat(t.args[1], "}"), t.args[2])
                }), this.tn.push(n)), (n = Be(this.C, t, "deleteRule")) && (n.afterSync(function(t) {
                    i.addDelete(t.that, t.args[0])
                }), this.tn.push(n)), (n = Be(this.C, t, "removeRule")) && (n.afterSync(function(t) {
                    i.addDelete(t.that, t.args[0])
                }), this.tn.push(n)), (n = Be(this.C, t, "replaceSync")) && (n.afterSync(function(t) {
                    i.snapshotConstructedStylesheet(t.that, !0)
                }), this.tn.push(n)), (n = Be(this.C, t, "replace")) && (n.afterSync(function(t) {
                    return r(i, void 0, void 0, function() {
                        return e(this, function(n) {
                            switch (n.label) {
                                case 0:
                                    return "object" != typeof t.result || "function" != typeof t.result.then ? [2] : [4, t.result];
                                case 1:
                                    return n.sent(), this.snapshotConstructedStylesheet(t.that, !0), [2]
                            }
                        })
                    })
                }), this.tn.push(n)), Object.defineProperty(t, Sc, {
                    value: !0,
                    configurable: !0
                })
            }, t.prototype.ensureAdoptedStyleSheetsHooked = function(t) {
                this.Qr(Object.getPrototypeOf(t))
            }, t.prototype.onSetAdoptedStyleSheets = function(t, n) {
                if (this.Qr(Object.getPrototypeOf(t)), Ps(t)) {
                    var i = null != n ? n : Mc(t);
                    if (i) {
                        for (var r = [], e = 0, s = i; e < s.length; e++) {
                            var o = s[e],
                                u = this.snapshotConstructedStylesheet(o);
                            r.push(u), o.disabled && this.onDisableSheet(o, !0)
                        }
                        this.St.enqueue({
                            Kind: 72,
                            Args: [Ps(t), r]
                        }), this.Xr(t, n)
                    }
                }
            }, t.prototype.Xr = function(t, n) {
                var i = this.Dr.get(t),
                    r = null != n ? n : Mc(t);
                (!i || r && r !== i.array) && this.se(t)
            }, t.prototype.se = function(t) {
                var n = this,
                    i = Mc(t);
                if (i) {
                    var r = this.Dr.get(t);
                    if (!r || r.array !== i) {
                        this.removePushHook(t);
                        for (var e = [], s = 0, o = ["push", "splice"]; s < o.length; s++) {
                            var u = o[s],
                                a = Be(this.C, i, u);
                            a && (a.afterSync(function() {
                                n.onSetAdoptedStyleSheets(t, i)
                            }), this.Hr.add(a), e.push(a))
                        }
                        e.length > 0 && this.Dr.set(t, {
                            hooks: e,
                            array: i
                        })
                    }
                }
            }, t.prototype.snapshotEl = function(t) {
                var n = Ps(t);
                if (n && Ec(this.C.wdx, t)) {
                    var i = function(t) {
                        return t ? t.sheet : void 0
                    }(t);
                    i && this.oe([1, n], i)
                }
            }, t.prototype.processWayfinderLog = function(t) {}, t.prototype.addStyleElement = function(t) {}, t.prototype.removeStyleElement = function(t) {}, t.prototype.snapshotConstructedStylesheet = function(t, n) {
                void 0 === n && (n = !1);
                var i = Tc(this.Fr, t);
                return n || void 0 === i ? (void 0 === i && (i = this.Kr++, function(t, n, i) {
                    t.set(n, i)
                }(this.Fr, t, i)), this.oe([2, i], t), i) : i
            }, t.prototype.oe = function(t, n) {
                this.St.enqueue({
                    Kind: 90,
                    Args: [t]
                });
                var i, r, e = function(t) {
                    try {
                        return t ? t.cssRules || t.rules : void 0
                    } catch (t) {
                        return
                    }
                }(n);
                if (e) {
                    for (var s = [], o = 0; o < e.length; o++) try {
                        var u = Pc((i = this.C.wdx, r = e[o], "" != Ic.style.cssText ? r.cssText : Ac(i, r)));
                        s.push(ju(u))
                    } catch (t) {
                        s.push("html {}")
                    }
                    this.St.enqueue({
                        Kind: 60,
                        Args: [t, s, 0]
                    })
                }
            }, t.prototype.addInsert = function(t, n, i, r) {
                var e = Cc(this.Fr, t, 1);
                if (e && "string" == typeof n) {
                    var s = [e, [ju(Pc(n))]];
                    void 0 !== i && (s[2] = i), void 0 !== r && (s[3] = r), this.ee(t, function(t) {
                        return t.enqueue({
                            Kind: 60,
                            Args: s
                        })
                    })
                }
            }, t.prototype.addDelete = function(t, n, i) {
                var r = Cc(this.Fr, t, 1);
                r && this.ee(t, function(t) {
                    return t.enqueue({
                        Kind: 61,
                        Args: i ? [r, n, i] : [r, n]
                    })
                })
            }, t.prototype.onDisableSheet = function(t, n) {
                var i = Cc(this.Fr, t, 1);
                i && this.ee(t, function(t) {
                    return t.enqueue({
                        Kind: 69,
                        Args: [i, !!n]
                    })
                })
            }, t.prototype.ee = function(t, n) {
                if (t.ownerNode) return i = this.C, r = t.ownerNode, e = n, void((s = Oi(function(t) {
                    var n = t.ownerDocument;
                    return n && n.defaultView
                }(r) || i.window, i.options.namespace)) && L(s._withEventQueue) && s._withEventQueue(i.recording.pageSignature(), function(t) {
                    var n = t;
                    e({
                        enqueue: function(t) {
                            ae(null != n, bc) && n.enqueue(t)
                        },
                        enqueueFirst: function(t) {
                            ae(null != n, bc) && n.enqueueFirst(t)
                        }
                    }), n = null
                }));
                var i, r, e, s;
                n(this.St)
            }, t.prototype.ie = function(t, n) {
                var i;
                if (this.Nr.has(n)) return [2, this.Nr.get(n)];
                var r, e = void 0;
                window.CSSGroupingRule && n.parentRule && n.parentRule instanceof CSSGroupingRule ? (e = Rc(this.C.wdx, n.parentRule), r = n.parentRule.cssRules) : r = t.cssRules;
                var s = Array.prototype.indexOf.call(r, n);
                if (-1 !== s) {
                    var o = Cc(this.Fr, t, 1);
                    if (o) {
                        var u = this.Lr++;
                        return this.Nr.set(n, u), (null !== (i = null == e ? void 0 : e.length) && void 0 !== i ? i : 0) > 0 ? [1, o, s, e] : [1, o, s]
                    }
                }
            }, t.prototype.stop = function() {
                this.jr = !1, this.Wr.close();
                for (var t = 0, n = this.tn; t < n.length; t++) {
                    var r = n[t];
                    r.disable(), Object.defineProperty(r.getTarget(), Sc, {
                        value: !1,
                        configurable: !0
                    })
                }
                this.tn = [], this.Hr.forEach(function(t) {
                    return t.disable()
                }), this.Hr.clear(), this.Dr = new Ne, this.Br = new Ne;
                for (var e = 0, s = this.Et; e < s.length; e++)(0, s[e])();
                if (this.Et = [], this.Zr) {
                    this.zr.stop();
                    try {
                        var o = CSSStyleRule.prototype,
                            u = Object.getOwnPropertyDescriptor(o, "style");
                        if ((null == u ? void 0 : u.get) !== this.te) return;
                        Object.defineProperty(o, "style", i(i({}, u), {
                            get: this.Zr
                        }))
                    } catch (t) {}
                }
            }, t.prototype.ensureHook = function(t) {
                this.ue(t) || t[Sc] || this.cr(t)
            }, t.prototype.removePushHook = function(t) {
                var n = this.Dr.get(t);
                if (n) {
                    for (var i = 0, r = n.hooks; i < r.length; i++) {
                        var e = r[i];
                        e.disable(), this.Hr["delete"](e)
                    }
                    this.Dr["delete"](t)
                }
            }, t.prototype.removeHook = function(t) {
                if (!this.ue(t))
                    for (var n = 0; n < this.tn.length; n++) {
                        var i = this.tn[n],
                            r = i.getTarget();
                        if (t === r) {
                            i.disable(), this.tn.splice(n, 1), Object.defineProperty(r, Sc, {
                                value: !1,
                                configurable: !0
                            });
                            break
                        }
                    }
            }, t.prototype.ue = function(t) {
                return Object.getPrototypeOf(t) === this.C.window.CSSStyleSheet
            }, t
        }(),
        Ic = document.createElement("div");

    function Ac(t, n, i) {
        if (void 0 === i && (i = 0), !ae(i <= 20, "No deep recursion for CSS rules")) return "html { /* Depth limit exceeded! */ }";
        var r = function(t) {
            switch (t.type) {
                case CSSRule.PAGE_RULE:
                    var n = t.selectorText || "";
                    return n && q(n, "@page") ? n : "@page ".concat(n);
                case CSSRule.KEYFRAME_RULE:
                    return t.keyText;
                case CSSRule.STYLE_RULE:
                    return t.selectorText;
                case CSSRule.MEDIA_RULE:
                    return "@media ".concat(t.media.mediaText);
                case CSSRule.KEYFRAMES_RULE:
                    return "@keyframes ".concat(t.name);
                case CSSRule.SUPPORTS_RULE:
                    return "@supports ".concat(t.conditionText);
                default:
                    return null
            }
        }(n);
        if (null == r) return n.cssText;
        var e = function(t, n, i) {
            var r, e, s, o, u = n,
                a = u.style;
            if (a) {
                for (var c = "", h = 0; h < a.length; h++) {
                    var f = a.item(h),
                        v = void 0 !== (o = function(t, n) {
                            var i = t;
                            if ("function" == typeof i.getPropertyCSSValue) {
                                var r = i.getPropertyCSSValue(n);
                                if (null != r) {
                                    var e;
                                    switch (r.cssValueType) {
                                        case 1:
                                            e = r;
                                            break;
                                        case 2:
                                            if (1 !== r.length) return;
                                            var s = r.item(0);
                                            if (null == s) return;
                                            if (1 !== s.cssValueType) return;
                                            e = s;
                                            break;
                                        default:
                                            return
                                    }
                                    if (19 === e.primitiveType) {
                                        var o = _u();
                                        sc || (sc = o.createElement("div"));
                                        var u = e.cssText;
                                        try {
                                            sc.style.cssText = "".concat(n, ": \"").concat(u, "\";");
                                            var a = sc.style.getPropertyCSSValue(n);
                                            if (null == a) return;
                                            if (u !== a.cssText) return
                                        } catch (t) {
                                            return
                                        } finally {
                                            sc.style.cssText = ""
                                        }
                                        return "\"".concat(u, "\"")
                                    }
                                }
                            }
                        }(e = a, s = f)) ? o : e.getPropertyValue(s);
                    ("initial" === v || ("\"" === (r = v)[0] || "'" === r[0]) && r[r.length - 1] === r[0]) && (c += "".concat(f, ": ").concat(v), "important" === a.getPropertyPriority(f) && (c += " !important"), c += "; ")
                }
                return [a.cssText, c].filter(Boolean).join("\n")
            }
            var l = u.cssRules;
            if (!l) return null;
            var d = "";
            for (h = 0; h < l.length; h++) d += Ac(t, l[h], i + 1);
            return d
        }(t, n, i);
        return null == e ? n.cssText : "".concat(r, " { ").concat(e, "} ")
    }

    function Ec(t, n) {
        var i;
        if (n instanceof HTMLLinkElement) {
            try {
                return function(t, n) {
                    var i, r;
                    return null !== (r = null === (i = t.classList) || void 0 === i ? void 0 : i.contains("fs-css-in-js")) && void 0 !== r && r
                }(n)
            } catch (t) {
                ve("shouldSnapshot", {
                    err: t
                })
            }
            return !1
        }
        return (null !== (i = n.textContent) && void 0 !== i ? i : "").length < Cu
    }

    function Cc(t, n, i) {
        var r = function(t, n) {
            var i = Tc(t, n);
            if (i) return [2, i];
            var r = Ps(n.ownerNode);
            return r ? [1, r] : void 0
        }(t, n);
        if (r) {
            var e = r[0],
                s = r[1];
            return e === i ? s : r
        }
    }

    function Tc(t, n) {
        return t.get(n)
    }

    function Pc(t) {
        return t.length <= Cu ? t : (o(function() {
            return "CSSRule too large, inserting dummy instead: ".concat(t.length)
        }), ":root { --fs-dropped-large-rule: 0 }")
    }

    function xc(t, n) {
        for (var i = 0; i < t.length; i++)
            if (t[i] === n) return i;
        return -1
    }

    function Rc(t, n) {
        for (var i = [], r = n, e = "stylesheetwatcher#getPath"; r.parentRule || r.parentStyleSheet;) {
            var s;
            if (!(null == (s = r.parentRule ? r.parentRule : r.parentStyleSheet) ? void 0 : s.cssRules)) return ve(e, {
                pathLength: i.length
            }, "warning"), i;
            var o = xc(s.cssRules, r);
            if (o > -1) {
                if (i.unshift(o), s instanceof CSSStyleSheet) break;
                r = s
            } else ve(e, {
                index: o
            }, "warning")
        }
        return i
    }

    function Mc(t) {
        try {
            return t.adoptedStyleSheets
        } catch (t) {
            return
        }
    }
    Ic.style.width = "initial";
    var Kc, jc, Oc = function() {
            function t(t, n, i) {
                this.C = t, this.ae = n, this.N = i
            }
            return t.prototype.start = function() {
                var t = this,
                    n = this.C.window.document;
                this.N.addCustom(n, this.ce(), !0, function(n) {
                    t.onFullscreenChange(n)
                }), this.N.addCustom(n, this.he(), !0, function(n) {
                    t.onFullscreenError(n)
                })
            }, t.prototype.stop = function() {
                var t;
                null === (t = this.N) || void 0 === t || t.clearAll()
            }, t.prototype.onFullscreenChange = function(t) {
                var n = this.fe();
                if (n) {
                    var i = Ps(n);
                    null == this.ve && o(function() {
                        return "Error: Received fullscreen signal but we think we are already in fullscreen?"
                    }), this.ae.enqueue({
                        Kind: 70,
                        Args: [i, !0]
                    }), this.ve = i
                } else null != this.ve && o(function() {
                    return "Error: Received fullscreen exit signal but have no previous fullscreen event?"
                }), this.ae.enqueue({
                    Kind: 70,
                    Args: [this.ve, !1]
                }), this.ve = void 0
            }, t.prototype.onFullscreenError = function(t) {
                this.ae.enqueue({
                    Kind: 71,
                    Args: []
                })
            }, t.prototype.fe = function() {
                var t = this.C.window.document;
                return t[Ce(t, "fullscreenElement")]
            }, t.prototype.ce = function() {
                return Ce(this.C.window.document, "onfullscreenchange").slice(2)
            }, t.prototype.he = function() {
                return Ce(this.C.window.document, "onfullscreenerror").slice(2)
            }, t
        }(),
        Uc = function() {
            function t(t, n) {
                this.St = n, this.tt = null, this.le = {};
                var i = t.window;
                "customElements" in i && null != i.customElements && "get" in i.customElements && "whenDefined" in i.customElements && (this.tt = i.customElements)
            }
            return t.prototype.start = function() {}, t.prototype.stop = function() {}, t.prototype.onCustomNodeVisited = function(t) {
                return r(this, void 0, void 0, function() {
                    var n;
                    return e(this, function(i) {
                        return this.tt ? (n = t.toLowerCase(), Object.prototype.hasOwnProperty.call(this.le, n) || this.de(n), [2]) : [2]
                    })
                })
            }, t.prototype.de = function(t) {
                return r(this, void 0, void 0, function() {
                    var n;
                    return e(this, function(i) {
                        switch (i.label) {
                            case 0:
                                if (!this.tt) return [2];
                                i.label = 1;
                            case 1:
                                return i.trys.push([1, 3, , 4]), n = !!this.tt.get(t), this.le[t] = n, [4, this.tt.whenDefined(t)];
                            case 2:
                                return i.sent(), this.St.enqueue({
                                    Kind: 73,
                                    Args: [t]
                                }), [3, 4];
                            case 3:
                                return i.sent(), [3, 4];
                            case 4:
                                return [2]
                        }
                    })
                })
            }, t
        }(),
        Nc = function() {
            function t(t, n) {
                this.C = t, this.pe = !1, this.tn = [], this.sn = n, this.rn = t.window, this.pe = Lc(this.rn)
            }
            return t.prototype.start = function() {
                this.sn.enqueue({
                    Kind: 58,
                    Args: [13, this.pe]
                }), this.pe && (this.an("show"), this.an("showModal"), this.an("close"))
            }, t.prototype.stop = function() {
                this.tn.forEach(function(t) {
                    return t.disable()
                }), this.tn = []
            }, t.prototype.an = function(t) {
                var n = this,
                    i = Be(this.C, this.rn.HTMLDialogElement.prototype, t);
                null == i || i.afterSync(function(i) {
                    var r = Ps(i.that);
                    if (r) {
                        var e = "close" !== t,
                            s = "showModal" === t;
                        n.sn.enqueue({
                            Kind: 101,
                            Args: [r, e, s]
                        })
                    }
                }), i && this.tn.push(i)
            }, t
        }(),
        Lc = function(t) {
            return void 0 !== t.HTMLDialogElement
        },
        Fc = function(t, n) {
            try {
                return t.elMatches(n, "dialog:modal")
            } catch (t) {
                return !0
            }
        },
        Hc = function() {
            function t(t, n, i) {
                this.C = t, this.sn = n, this.N = i, this.pe = !1, this.ge = new Set, this.pe = Dc(this.C.window)
            }
            return t.prototype.start = function() {
                var t = this;
                this.sn.enqueue({
                    Kind: 58,
                    Args: [18, this.pe]
                }), this.pe && this.N.addCustom(this.C.window, "toggle", !0, function(n) {
                    var i = n.target;
                    if (i && i.hasAttribute("popover")) {
                        var r = Ps(i);
                        r && ("open" === n.newState ? t.we(r) : t.me(r))
                    }
                })
            }, t.prototype.stop = function() {
                this.ge.clear(), this.N.clearAll()
            }, t.prototype.onNodeRemoved = function(t) {
                this.ge["delete"](t)
            }, t.prototype.onNodeVisited = function(t) {
                if (this.pe && t.nodeType === E) {
                    var n = t,
                        i = Ps(n);
                    i && n.hasAttribute("popover") && Bc(n) && this.we(i)
                }
            }, t.prototype.we = function(t) {
                this.ge.has(t) || (this.ge.add(t), this.sn.enqueue({
                    Kind: 120,
                    Args: [t, !0]
                }))
            }, t.prototype.me = function(t) {
                this.ge["delete"](t), this.sn.enqueue({
                    Kind: 120,
                    Args: [t, !1]
                })
            }, t
        }(),
        Dc = function(t) {
            return void 0 !== t.HTMLElement && "showPopover" in t.HTMLElement.prototype
        },
        Bc = function(t) {
            try {
                return t.matches(":popover-open")
            } catch (t) {
                return !1
            }
        },
        Wc = function() {
            function t() {}
            return t.prototype.now = function() {
                return Date.now()
            }, t
        }(),
        zc = new(function() {
            function t(t, n, i, r) {
                void 0 === i && (i = n), void 0 === r && (r = new Wc), this.ye = t, this.be = n, this.Se = r, this._e = r.now(), this.ke = i
            }
            return t.prototype.hasCapacityFor = function(t) {
                var n = this.Se.now(),
                    i = (n - this._e) * this.ye;
                return this.ke = Math.min(this.be, this.ke + i), this._e = n, this.ke >= t ? (this.ke -= t, [!0, 0]) : [!1, (t - this.ke) / this.ye]
            }, t
        }())(2, 2e5),
        qc = {
            type: "image/webp",
            quality: .8
        },
        Vc = function() {
            function t(t, n, i, r, e) {
                void 0 === e && (e = new Hs(t.wdx, t.window, 1e3)), this.C = t, this.St = n, this.qi = i, this.Ui = r, this.Ie = e, this.Ae = !1, this.Ee = 1, this.Ce = [], this.Te = [], this.Pe = new Ne, this.xe = new Ne, this.Re = new Set, this.Me = new Ne, this.Ke = new Ne, this.je = !1, this.Oe = new Ne, this.Ue = new Set, this.Ne = new Ne, this.Le = new Ne, this.Fe = 1, this.He = new Ne, this.De = 1, this.Be = new Ne, this.We = 0, this.ze = !1, Kc || (Kc = new Set(["measureText", "getImageData", "getError", "getTransform", "isContextLost", "isEnabled", "isFramebuffer", "isProgram", "isRenderbuffer", "isShader", "isTexture"])), jc || (jc = new Set(["fillText"])), this.Ae = !!this.C.options.isWayfinder
            }
            return t.prototype.start = function(t) {
                var n, i = this;
                if (t.CanvasWatcherMode) {
                    if (this.Ee = null !== (n = t.CanvasWatcherMode) && void 0 !== n ? n : 1, this.qe = t.CanvasWebpCompression ? qc : void 0, this.Ae) {
                        if (2 !== this.Ee) return void ve("wf-non-screenshot", void 0, "warning")
                    } else this.cr("2d", window.CanvasRenderingContext2D), this.cr("webgl", window.WebGLRenderingContext), this.cr("webgl2", window.WebGL2RenderingContext);
                    if (2 === this.Ee) {
                        if (!HTMLCanvasElement.prototype.toDataURL) return;
                        this.Ie.start(function() {
                            return i.screenshotConnectedCanvases()
                        })
                    }
                    this.St.enqueue({
                        Kind: 58,
                        Args: [15, !0, 16, 2 === t.CanvasWatcherMode]
                    }), this.je = !0
                }
            }, t.prototype.Ve = function(t, n) {
                return "object" != typeof n ? [void 0, 0] : (this.He.has(n) || this.He.set(n, [t, this.De++]), this.He.get(n))
            }, t.prototype.cr = function(t, n) {
                var i = this;
                if (n)
                    for (var r = n.prototype, e = function(e) {
                            if (Kc.has(e)) return "continue";
                            var o = Object.getOwnPropertyDescriptor(r, e);
                            if ("function" == typeof(null == o ? void 0 : o.value)) {
                                var u = Be(s.C, r, e);
                                u && (u.afterSync(function(n) {
                                    return i.$e(t, e, n.that, n.args, n.result)
                                }), s.Ce.push(u))
                            } else "function" == typeof(null == o ? void 0 : o.set) && s.Te.push(tt(n, e, s.Ge(t, e)))
                        }, s = this, o = 0, u = Object.keys(r); o < u.length; o++) e(u[o])
            }, t.prototype.Qe = function(t, n) {
                var i;
                this.Ue.add(t), this.Ne.has(t) || this.Ne.set(t, ft(this.C.wdx) + 5e3), this.Oe.has(t) || this.Oe.set(t, []), null === (i = this.Oe.get(t)) || void 0 === i || i.push.apply(i, n)
            }, t.prototype.Xe = function(t) {
                var n, i = null !== (n = this.Oe.get(t)) && void 0 !== n ? n : [];
                return this.Ue["delete"](t), this.Ne["delete"](t), i
            }, t.prototype.Je = function(t) {
                var n = t instanceof HTMLCanvasElement ? Ps(t) : 0;
                if (n) return n;
                if (this.Le.has(t)) return {
                    id: this.Le.get(t)
                };
                var i = {
                    id: this.Fe
                };
                return this.Ye(t, i), this.Le.set(t, this.Fe), ++this.Fe, i
            }, t.prototype.Ye = function(t, n) {
                this.St.enqueue({
                    Kind: 104,
                    Args: [n, t.width, t.height]
                })
            }, t.prototype.flush = function(t, n) {
                var i;
                if (this.je) {
                    if (this.Be.has(t)) return this.Be.get(t);
                    2 === this.Ee && t instanceof HTMLCanvasElement && (this.Re.add(t), this.xe.set(t, !0));
                    var r = this.Je(t);
                    this.Be.set(t, r);
                    var e = this.Xe(t);
                    if (e.length > 0) {
                        var s = n;
                        if (!s) {
                            var o = t instanceof HTMLCanvasElement ? Es(t) : void 0,
                                u = t instanceof HTMLCanvasElement && rt(t);
                            s = null !== (i = null == o ? void 0 : o.mask) && void 0 !== i ? i : u
                        }
                        this.Ze(t, r, e, s)
                    }
                    return this.Be["delete"](t), r
                }
            }, t.prototype.ts = function(t, n, i, r, e, s, o) {
                var u, a;
                switch (typeof r) {
                    case "string":
                        return e ? gs(r) : r;
                    case "number":
                    case "boolean":
                    case "bigint":
                        return r;
                    case "undefined":
                        return {
                            undef: !0
                        };
                    case "object":
                        if (!r) return r;
                        try {
                            o.set(r, !0)
                        } catch (t) {}
                        var c = null === (u = Object.getPrototypeOf(r)) || void 0 === u ? void 0 : u.constructor,
                            h = (null == c ? void 0 : c.name) || function(t) {
                                var n;
                                if (t) {
                                    var i = t.toString(),
                                        r = Gc.exec(i);
                                    return r || (r = Qc.exec(i)), null === (n = null == r ? void 0 : r[1]) || void 0 === n ? void 0 : n.trim()
                                }
                            }(c),
                            f = {
                                ctor: h
                            };
                        if (((a = r) instanceof Node || H(a) && "nodeType" in a) && (d = Ps(r))) return f.id = d, f;
                        switch (h) {
                            case "Array":
                                return this.We += r.length, this.ns(t, n, i, r, e, s, o);
                            case "CanvasGradient":
                                return f;
                            case "HTMLImageElement":
                                var v = Ru(r.src, {
                                    source: "dom",
                                    type: "canvas"
                                });
                                return this.Ui.record(v), f.src = v, f;
                            case "HTMLCanvasElement":
                                var l = r,
                                    d = this.flush(l, e);
                                return f.srcId = d, f
                        }
                        if (function(t) {
                                var n;
                                return !!(null === (n = Object.prototype.toString.call(t)) || void 0 === n ? void 0 : n.match($c))
                            }(r)) return this.He.has(r) ? this.rs(r, f, e) : (f.typedArray = "[".concat(r.toString(), "]"), this.We += r.length, f);
                        if ("object" == typeof r && this.He.has(r)) return this.rs(r, f, e);
                        if (r instanceof WebGLBuffer || r instanceof WebGLTexture) {
                            var p = void 0;
                            switch (s) {
                                case "bindTexture":
                                    p = this.es(t, "createTexture", n, i, r);
                                    break;
                                case "bindBuffer":
                                    p = this.es(t, "createBuffer", n, i, r)
                            }
                            if (void 0 !== p) return this.rs(r, f, e)
                        }
                        var g = r;
                        for (var w in f.obj = {}, g) {
                            try {
                                switch (typeof g[w]) {
                                    case "function":
                                        continue;
                                    case "object":
                                        if (g[w] && o.has(g[w])) continue
                                }
                            } catch (t) {
                                continue
                            }++this.We, f.obj[w] = this.ts(t, n, i, g[w], e, s, o)
                        }
                        return f;
                    default:
                        return null
                }
            }, t.prototype.rs = function(t, n, i) {
                var r = this.He.get(t),
                    e = r[0],
                    s = r[1];
                return this.flush(e, i), n.ref = s, delete n.ctor, n
            }, t.prototype.es = function(t, n, i, r, e) {
                var s = this.Ve(i, e),
                    o = (s[0], s[1]);
                return this.ss(r, [
                    [t, 1, n, [], o]
                ]), o
            }, t.prototype.ns = function(t, n, i, r, e, s, o) {
                var u = this;
                return void 0 === o && (o = new Ne), this.We += r.length + 1, r.map(function(r) {
                    return u.ts(t, n, i, r, e, s, o)
                })
            }, t.prototype.Ze = function(t, n, i, r) {
                var e = this;
                if (void 0 === r && (r = !1), !this.ze) {
                    var s = i.map(function(i) {
                        var s = i[0],
                            o = i[1],
                            u = i[2],
                            a = i[3],
                            c = i[4];
                        return [s, o, u, e.ns(s, t, n, a, r && jc.has(u), u), c]
                    });
                    if (!this.Pe.has(t) && (this.Pe.set(t, !0), i.some(function(t) {
                            return "2d" === t[0]
                        }))) {
                        var o = function(t) {
                            var n = t.getContext("2d");
                            if (!n) return [];
                            var i = [];
                            if ((n instanceof CanvasRenderingContext2D || window.OffscreenCanvasRenderingContext2D && n instanceof OffscreenCanvasRenderingContext2D) && "function" == typeof n.getTransform) {
                                var r = n.getTransform();
                                if (!r.isIdentity) {
                                    var e = r.a,
                                        s = r.b,
                                        o = r.c,
                                        u = r.d,
                                        a = r.e,
                                        c = r.f;
                                    i.push(["2d", 1, "transform", [e, s, o, u, a, c], -1])
                                }
                            }
                            return i
                        }(t);
                        if (o.length > 0) return o.push.apply(o, s), void this.ss(n, o)
                    }
                    this.ss(n, s)
                }
            }, t.prototype.ss = function(t, n) {
                if (!this.ze) {
                    var i = zc.hasCapacityFor(this.We),
                        r = i[0];
                    i[1], this.We = 0, r ? this.St.enqueue({
                        Kind: 103,
                        Args: [t, n]
                    }) : this.ze = !0
                }
            }, t.prototype.os = function(t, n) {
                t instanceof HTMLCanvasElement ? 2 === this.Ee ? (this.xe.set(t, !0), this.Re.add(t)) : this.Qe(t, n) : o(function() {
                    return "detected canvas op but target is not canvas element"
                })
            }, t.prototype.$e = function(t, n, i, r, e) {
                for (var s = [], o = 0; o < r.length; o++) s.push(r[o]);
                var u = this.Ve(i.canvas, e),
                    a = (u[0], u[1]);
                this.os(i.canvas, [
                    [t, 1, n, s, a]
                ])
            }, t.prototype.Ge = function(t, n) {
                var i = this;
                return function(r, e) {
                    i.os(r.canvas, [
                        [t, 0, n, [e], 0]
                    ])
                }
            }, t.prototype.stop = function() {
                this.je = !1, this.Ce.forEach(function(t) {
                    return t.disable()
                }), this.Te.forEach(function(t) {
                    return t()
                }), this.Ce = [], this.Te = [], this.Ie.stop()
            }, t.prototype.screenshotConnectedCanvases = function() {
                var t = this,
                    n = [],
                    i = [],
                    r = new Ne;
                return this.Re.forEach(function(e) {
                    var s = Ps(e);
                    if (s && rt(e)) {
                        if (t.xe.has(e) || t.Ae)
                            if (t.Me.has(e)) r.set(e, !0);
                            else {
                                t.Me.set(e, !0);
                                var o = function() {
                                    t.Me["delete"](e)
                                };
                                i.push(bo(t.C.wdx, t.C.window).then(function() {
                                    return t.us(e, s)
                                }).then(o, o))
                            }
                    } else n.push(e)
                }), n.forEach(function(n) {
                    return t.Re["delete"](n)
                }), this.xe = r, Promise.all(i)
            }, t.prototype.us = function(t, n) {
                return r(this, void 0, void 0, function() {
                    var i, r, s;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return e.trys.push([0, 2, , 3]), i = this.Ke.get(t), [4, this.cs(t, function(t) {
                                    var n;
                                    return t.url !== i && !!(null === (n = t.contentType) || void 0 === n ? void 0 : n.match(/^image/i))
                                })];
                            case 1:
                                return (r = e.sent()) ? (s = r.url, this.Ke.set(t, s), r.url === i ? [2] : (this.ss(n, [
                                    ["2d", 1, "drawImage", [{
                                        ctor: "HTMLImageElement",
                                        src: s
                                    }, 0, 0], 0]
                                ]), [3, 3])) : [2];
                            case 2:
                                return he("Canvas screenshot", {
                                    err: e.sent()
                                }), [3, 3];
                            case 3:
                                return [2]
                        }
                    })
                })
            }, t.prototype.cs = function(t, n) {
                var i = this;
                return t.toBlob ? function(t, n) {
                    return new Promise(function(i) {
                        return n ? t.toBlob(i, n.type, n.quality) : t.toBlob(i)
                    })
                }(t, this.qe).then(function(t) {
                    return t ? i.qi.uploadBlobIfNeeded(t, n) : void 0
                }) : this.qi.uploadDataUrlIfNeeded(this.hs(t), n)
            }, t.prototype.hs = function(t) {
                var n = this.qe;
                return n ? t.toDataURL(n.type, n.quality) : t.toDataURL()
            }, t.prototype.vs = function() {
                var t = this,
                    n = [];
                this.Ue.forEach(function(i) {
                    i instanceof HTMLCanvasElement && (Ps(i) || !rt(i)) || (t.Oe["delete"](i), n.push(i))
                });
                for (var i = 0, r = n; i < r.length; i++) {
                    var e = r[i];
                    this.Xe(e)
                }
            }, t.prototype.tick = function() {
                var t = this;
                if (this.je) try {
                    if (this.vs(), 2 === this.Ee) return;
                    this.Ue.forEach(function(n) {
                        var i;
                        n instanceof HTMLCanvasElement && t.ls(n);
                        var r = null !== (i = t.Ne.get(n)) && void 0 !== i ? i : Number.POSITIVE_INFINITY;
                        ft(t.C.wdx) > r && t.Xe(n)
                    })
                } catch (t) {
                    ve("canvaswatcher#tick", {
                        err: t,
                        mode: this.Ee
                    })
                }
            }, t.prototype.ls = function(t) {
                var n = Ps(t);
                if (n) {
                    var i = Es(t),
                        r = this.Oe.get(t);
                    r && 0 !== r.length && (this.Ze(t, n, r, !!(null == i ? void 0 : i.mask)), this.Xe(t))
                }
            }, t
        }(),
        $c = /\[object ((I|Ui)nt(8|16|32)|Float(32|64)|Uint8Clamped|Big(I|Ui)nt64)Array\]/,
        Gc = /^\[object ([^\]]+?)(?:Constructor)?\]/,
        Qc = /^function ([^(]+)/,
        Xc = /^\s*at .*(\S+:\d+|native|(<anonymous>))/m,
        Jc = /^(eval@)?(\[native code\])?$/;

    function Yc(t, n, i, r, e) {
        return [n || "", t(i || ""), parseInt(r || "-1", 10), parseInt(e || "-1", 10)]
    }

    function Zc(t) {
        if (!t || -1 === t.indexOf(":")) return ["", "", ""];
        var n = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(t.replace(/[()]/g, ""));
        return n ? [n[1] || "", n[2] || "", n[3] || ""] : ["", "", ""]
    }
    var th = ["_fs_debug", "assert", "debug", "error", "info", "log", "trace", "warn"],
        nh = th.filter(function(t) {
            return !/debug/.test(t)
        });

    function ih(t, n, i) {
        return Nu(z(n) ? n.slice(0, i) : Us(t)(n, i))
    }

    function rh(t) {
        if (H(t)) {
            try {
                if (L(t.toString)) return t.toString()
            } catch (t) {}
            return t.message
        }
    }

    function eh(t, n, i) {
        var r = i ? "".concat(i, " ") : "";
        return s(["".concat(r).concat(ih(t, rh(n.error) || n.message, 1e3)), ih(t, n.filename, 100), H(n.lineno) ? -1 : n.lineno], function(t, n) {
            if (!H(n) || !z(n.stack)) return [];
            var i = n;
            return i.stack.match(Xc) ? function(t, n) {
                return n.split("\n").filter(function(t) {
                    return !!t.match(Xc)
                }).map(function(n) {
                    var i = n;
                    i.indexOf("(eval ") > -1 && (i = i.replace(/eval code/g, "eval").replace(/(\(eval at [^()]*)|(\),.*$)/g, ""));
                    var r = i.replace(/^\s+/, "").replace(/\(eval code/g, "(").replace(/\(native code\)/, "").split(/\s+/).slice(1),
                        e = Zc(r.pop()),
                        s = r.join(" "),
                        o = ["eval", "<anonymous>"].indexOf(e[0]) > -1 ? "" : e[0];
                    return Yc(t, s, o, e[1], e[2])
                })
            }(t, i.stack) : function(t, n) {
                return n.split("\n").filter(function(t) {
                    return !t.match(Jc)
                }).map(function(n) {
                    var i = n;
                    if (i.indexOf(" > eval") > -1 && (i = i.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g, ":$1")), -1 === i.indexOf("@") && -1 === i.indexOf(":")) return [i, "", -1, -1];
                    var r = i.split("@"),
                        e = Zc(r.pop()),
                        s = r.join("@");
                    return Yc(t, s, e[0], e[1], e[2])
                })
            }(t, i.stack)
        }(function(t) {
            return Nu(t)
        }, n.error), !0)
    }
    var sh = function() {
        function t(t, n, i) {
            this.C = t, this.St = n, this.N = i, this.Jt = !1, this.ds = !1, this.ps = 0, this.tn = [], this.gs = Tn.DefaultOrgSettings.MaxConsoleLogPerPage, this.W = t.window
        }
        return t.prototype.initializeMaxLogsPerPage = function(t) {
            this.gs = t || Tn.DefaultOrgSettings.MaxConsoleLogPerPage
        }, t.prototype.ws = function() {
            return "\"[received more than ".concat(this.gs, " messages]\"")
        }, t.prototype.start = function(t) {
            var n = this;
            if (t.ConsoleWatcher && (this.N.add(this.W, "error", !0, function(t) {
                    return n.ys(t)
                }), this.N.add(this.W, "unhandledrejection", !0, function(t) {
                    var i, r = "";
                    t.reason instanceof Error ? i = t.reason : r = Us(n.C.wdx)(t.reason, 1e3), n.ys({
                        error: i,
                        message: r,
                        filename: "",
                        lineno: 0
                    }, "Uncaught (in promise)")
                }, !0), !this.Jt))
                if (this.Jt = !0, this.St.enqueue({
                        Kind: 58,
                        Args: [3, !0]
                    }), this.W.console)
                    for (var i = function(t) {
                            var i = Be(r.C, r.W.console, t);
                            if (!i) return "continue";
                            "assert" === t ? i.before(function(i) {
                                var r = i.args;
                                r[0] || n.bs(t, Array.prototype.slice.apply(r, [1]))
                            }) : i.before(function(i) {
                                var r = i.args;
                                return n.bs(t, r)
                            }), r.tn.push(i)
                        }, r = this, e = 0, s = nh; e < s.length; e++) i(s[e]);
                else this.bs("log", ["NOTE: Log messages cannot be captured on IE9"])
        }, t.prototype.isEnabled = function() {
            return this.Jt
        }, t.prototype.stop = function() {
            var t, n;
            if (null === (t = this.N) || void 0 === t || t.clearAll(), this.Jt)
                for (this.Jt = !1; n = this.tn.pop();) n.disable()
        }, t.prototype.logEvent = function(t, n, i) {
            if (void 0 === i && (i = "console"), !this.Ss()) return null;
            for (var r = -1 === th.indexOf(t) ? [i, "log", ih(this.C.wdx, t, 1e3)] : [i, t], e = 0; e < n.length; ++e) r.push(ih(this.C.wdx, n[e], 1e3));
            return {
                Kind: 48,
                Args: r
            }
        }, t.prototype.bs = function(t, n) {
            if (0 !== n.length) {
                var i = this.logEvent(t, n);
                i && this.St.enqueue(i)
            }
        }, t.prototype.ys = function(t, n) {
            void 0 === n && (n = "Uncaught"), (void 0 !== t.error || void 0 !== t.message || t.filename || t.lineno) && this.Ss() && this.St.enqueue({
                Kind: 49,
                Args: eh(this.C.wdx, t, n)
            })
        }, t.prototype.Ss = function() {
            return !this.ds && (this.ps == this.gs ? (this.St.enqueue({
                Kind: 48,
                Args: ["console", "warn", this.ws()]
            }), this.ds = !0, !1) : (this.ps++, !0))
        }, t
    }();

    function oh(t) {
        if (t.composed && t.target) {
            var n = t.target;
            if (n.nodeType == E && n.shadowRoot) {
                var i = t.composedPath();
                if (i.length > 0) return i[0]
            }
        }
        return t.target
    }

    function uh(t) {
        var n = oh(t);
        return !!Ps(n) && !Is(n)
    }
    var ah = function() {
        function t(t, n, i, r) {
            this.C = t, this.St = n, this._s = i, this.N = r
        }
        return t.prototype.start = function(t) {
            var n = this;
            this.N.add(this.C.window, "click", !0, function(t) {
                uh(t) && n.ks(t)
            }), this.N.add(this.C.window, "dblclick", !0, function(t) {
                uh(t) && n.Is(t)
            })
        }, t.prototype.stop = function(t) {
            this.N.clearAll()
        }, t.prototype.ks = function(t) {
            var n = ch(this.C, t);
            if (L(n)) {
                var i = Es(oh(t));
                this._s.onClick(i), this.St.enqueue({
                    Kind: 114,
                    Args: [16, n]
                })
            }
        }, t.prototype.Is = function(t) {
            var n = Ps(oh(t));
            n && this.St.enqueue({
                Kind: 50,
                Args: [n]
            })
        }, t
    }();

    function ch(t, n) {
        var i = oh(n),
            r = Ps(i);
        if (r) {
            var e = [r, n.clientX, n.clientY],
                o = t.measurer.enqueue(function() {
                    return {
                        done: !0,
                        result: hh(i)
                    }
                }, !0);
            return function() {
                return s(s([], e, !0), function(t, n) {
                    if (L(n)) {
                        var i = n();
                        if (i && i[0]) return i[0]
                    }
                    return hh(t)
                }(i, o), !0)
            }
        }
    }

    function hh(t) {
        var n = 0,
            i = 0,
            r = 0,
            e = 0;
        if (t && t.getBoundingClientRect) {
            var s = t.getBoundingClientRect();
            n = s.left, i = s.top, r = s.width, e = s.height
        }
        return [n, i, r, e]
    }
    var fh = function() {
            function t(t, n, i, r) {
                this.C = t, this.St = n, this._s = i, this.N = r, this.tn = [], n.registerInterceptor(this)
            }
            return t.prototype.start = function(t) {
                var n, i = this;
                this.N.add(this.C.window, "click", !0, function(t) {
                    uh(t) && i.As(t)
                });
                var r = Be(this.C, null === (n = this.C.window.Event) || void 0 === n ? void 0 : n.prototype, "preventDefault", !0);
                r && (this.tn.push(r), r.afterSync(function(t) {
                    return i.Es(t.that)
                }))
            }, t.prototype.stop = function(t) {
                this.N.clearAll();
                for (var n = 0, i = this.tn; n < i.length; n++) i[n].disable()
            }, t.prototype.intercept = function(t) {
                switch (t.Kind) {
                    case 42:
                    case 19:
                    case 40:
                    case 10:
                    case 64:
                        this.Cs()
                }
            }, t.prototype.As = function(t) {
                var n;
                (null === (n = this.Ts) || void 0 === n ? void 0 : n.target) === oh(t) && this.Cs()
            }, t.prototype.Es = function(t) {
                var n, i = t.type;
                switch (i) {
                    case "touchend":
                        var r = t,
                            e = (null === (n = r.changedTouches) || void 0 === n ? void 0 : n.length) > 0;
                        r.clientX = e ? r.changedTouches[0].clientX : 0, r.clientY = e ? r.changedTouches[0].clientY : 0, this.Ps(i, r);
                        break;
                    case "pointerdown":
                    case "pointerup":
                        this.Ps(i, t);
                        break;
                    default:
                        o(function() {
                            return "Unhandled event type: ".concat(i)
                        })
                }
            }, t.prototype.xs = function(t, n) {
                var i = ch(this.C, n);
                if (L(i)) {
                    var r = Es(oh(n));
                    this._s.onClick(r), this.St.enqueue({
                        Kind: 114,
                        Args: [112, function() {
                            return [t, i()]
                        }]
                    })
                }
            }, t.prototype.Ps = function(t, n) {
                var i = this;
                this.Ts || (this.Ts = {
                    target: oh(n),
                    timer: new Ds(this.C.wdx, this.C.window, function() {
                        i.Ts = void 0, i.xs(t, n)
                    }).start(Tn.SyntheticClickTimeout)
                })
            }, t.prototype.Cs = function() {
                this.Ts && (this.Ts.timer.stop(), this.Ts = void 0)
            }, t
        }(),
        vh = function() {
            function t(t, n, i) {
                this.C = t, this.St = n, this.N = i, this.Rs = [], this.Ms = new Ne, this.W = t.window, this.Mt = this.W.document
            }
            return t.prototype.start = function(t) {
                var n = this;
                this.N.add(this.W, "selectstart", !0, function() {
                    n.Ks()
                }), this.N.add(this.Mt, "selectionchange", !0, function() {
                    n.Ks()
                })
            }, t.prototype.stop = function(t) {
                this.N.clearAll()
            }, t.prototype.addInput = function(t) {
                var n = this,
                    i = this.N.add(t, "select", !1, function() {
                        n.js(t)
                    });
                this.Ms.set(t, i), this.js(t, !0)
            }, t.prototype.removeInput = function(t) {
                var n = this.Ms.get(t);
                n && (this.N.detach(n), this.Ms["delete"](t))
            }, t.prototype.emit = function() {
                this.Ks()
            }, t.prototype.Ks = function() {
                var t = this;
                this.C.measurer.enqueue(function() {
                    var n;
                    try {
                        n = t.Os()
                    } catch (t) {
                        return
                    }
                    t.Us(n)
                })
            }, t.prototype.js = function(t, n) {
                var i = this;
                this.C.measurer.enqueue(function() {
                    var r;
                    try {
                        r = function(t) {
                            var n = Ps(t);
                            if (!n) return [];
                            var i = t.selectionStart,
                                r = t.selectionEnd;
                            return null === i || null === r ? [] : i === r ? [n, i] : [n, i, n, r, "backward" !== t.selectionDirection]
                        }(t)
                    } catch (t) {
                        return
                    }
                    n && r.length < 3 || i.Us(r)
                })
            }, t.prototype.Us = function(t) {
                for (var n = !1, i = 0; i < 4; i++)
                    if (this.Rs[i] !== t[i]) {
                        n = !0;
                        break
                    }
                n && (this.Rs = t, this.St.enqueue({
                    Kind: 59,
                    Args: t
                }))
            }, t.prototype.Os = function() {
                if (!this.W.getSelection) return [];
                var t = this.W.getSelection();
                if (!t) return [];
                if ("None" == t.type) return [];
                if ("Caret" == t.type) {
                    var n = Ps(t.anchorNode);
                    return n ? [n, t.anchorOffset] : []
                }
                if (!t.anchorNode || !t.focusNode) return [];
                var i, r = lh(t.anchorNode, t.anchorOffset),
                    e = r[0],
                    s = r[1],
                    o = lh(t.focusNode, t.focusOffset),
                    u = o[0],
                    a = o[1],
                    c = (i = e === u ? s <= a : Boolean(e.compareDocumentPosition(u) & Node.DOCUMENT_POSITION_FOLLOWING)) ? [e, u] : [u, e],
                    h = c[0],
                    f = c[1],
                    v = i ? [s, a] : [a, s],
                    l = v[0],
                    d = v[1];
                for (Ps(h) || (l = 0); h && !Ps(h) && h != f;) h = R(h) || K(h);
                for (Ps(f) || (d = 0); f && !Ps(f) && f != h;) f = M(f) || K(f);
                if (h == f && l == d) return [];
                var p = Ps(h),
                    g = Ps(f);
                return h && f && p && g ? [p, l, g, d, i] : []
            }, t
        }();

    function lh(t, n) {
        var i = t,
            r = j(i);
        if (!r || 0 === n) return [i, n];
        i = r;
        for (var e = 0; e < n - 1; e++) {
            var s = R(i);
            if (!s) return [i, 0];
            i = s
        }
        return [i, 0]
    }
    var dh = function() {
        function t(t, n, i) {
            this.C = t, this.St = n, this.N = i, this.je = !1, this.Ns = new Set, this.tn = [], this.Mt = t.window.document, this.Yt = gh(this.Mt)
        }
        return t.prototype.start = function(t) {
            var n = this;
            if (this.Yt = gh(this.Mt), this.St.enqueue({
                    Kind: 58,
                    Args: [19, this.Yt]
                }), this.Yt) {
                var i = ph(this.Mt);
                i && (this.je = !0, this.N.addCustom(i, "toolchange", !0, function() {
                    return n.Ls()
                }, !0), this.Fs(i), this.Ls())
            }
        }, t.prototype.stop = function(t) {
            this.je = !1, this.Ns.clear(), this.tn.forEach(function(t) {
                return t.disable()
            }), this.tn = [], this.N.clearAll()
        }, t.prototype.Fs = function(t) {
            var n = this,
                i = Be(this.C, t, "executeTool");
            i && (i.before(function(t) {
                var i, r = (z(i = t.args[0]) ? i : wh(null == i ? void 0 : i.name)) || void 0;
                r && n.St.enqueue({
                    Kind: 122,
                    Args: [r]
                })
            }), this.tn.push(i))
        }, t.prototype.Ls = function() {
            return r(this, void 0, void 0, function() {
                var t, n;
                return e(this, function(i) {
                    switch (i.label) {
                        case 0:
                            if (t = ph(this.Mt), !this.je || !t || "function" != typeof t.getTools) return [2];
                            i.label = 1;
                        case 1:
                            return i.trys.push([1, 3, , 4]), [4, t.getTools()];
                        case 2:
                            return n = i.sent(), this.je ? (this.Hs(n), [3, 4]) : [2];
                        case 3:
                            return i.sent(), [3, 4];
                        case 4:
                            return [2]
                    }
                })
            })
        }, t.prototype.Hs = function(t) {
            if (t && t.length)
                for (var n = 0; n < t.length; n++) this.Ds(t[n])
        }, t.prototype.Ds = function(t) {
            var n = wh(t.name);
            if (n) {
                var i = wh(t.origin),
                    r = "".concat(i, "\0").concat(n);
                this.Ns.has(r) || (this.Ns.add(r), this.St.enqueue({
                    Kind: 121,
                    Args: [n, wh(t.title), wh(t.description), mh(i)]
                }))
            }
        }, t
    }();

    function ph(t) {
        var n = t.modelContext;
        return null != n ? n : void 0
    }

    function gh(t) {
        return null != ph(t)
    }

    function wh(t) {
        return z(t) ? t : ""
    }

    function mh(t) {
        return t ? Ru(t, {
            source: "event",
            type: 121
        }) : ""
    }
    var yh = /^\s*((stylesheet)\s*)+$/i,
        bh = /^\s*((img|picture)\s*)+$/i,
        Sh = function() {
            function t(t, n, i, r, e, s, o, u, a) {
                this.C = t, this.St = n, this._s = i, this.N = e, this.Bs = s, this.Ws = o, this.qi = u, this.Ui = a, this.zs = {}, this.qs = !1, this.tn = [], this.Vs = !1, this.$s = {}, this.Gs = !1, this.Qs = new Ne, this.W = t.window, this.Xs = this.W.location, this.Js = this.W.history, this.Ys = this.Xs.href;
                var c, h, f, v = this.C.options.isWayfinder ? (c = t, h = n, this.N.createChild(), void 0 === f && (f = Ds), new kc(c, h, f)) : new kc(t, n);
                this.Zs = [new uc(t, n), new oo(t, n, this.N.createChild()), new Vc(t, n, u, this.Ui), new sh(t, this.St, this.N.createChild()), new Uc(t, n), new Nc(t, n), new Oc(t, n, this.N.createChild()), new zs(t, n), new xa(t, n, this.N.createChild(), this.Ui), v, new vh(t, n, this.N.createChild()), new Hc(t, n, this.N.createChild()), new ah(t, n, i, this.N.createChild()), new fh(t, n, i, this.N.createChild()), new dh(t, n, this.N.createChild())], this.no = function(t, n) {
                    void 0 === n && (n = .25);
                    var i = t.window.IntersectionObserver;
                    if (i) return new i(function(n) {
                        for (var i, r = 0, e = n; r < e.length; r++) {
                            var s = e[r],
                                o = s.target,
                                u = s.intersectionRatio,
                                a = Ps(o);
                            a && (null === (i = t.queue()) || void 0 === i || i.enqueue({
                                Kind: 83,
                                Args: [a, u]
                            }))
                        }
                    }, {
                        threshold: [n, 1]
                    })
                }(t), this.io = new ca(t, r, this.xn.bind(this), this.no, this.ei.bind(this), function(t) {
                    return v.processWayfinderLog(t)
                }), this.io.acceptVisitor(this)
            }
            return t.prototype.getResourceUploader = function() {
                return this.qi
            }, t.prototype.start = function(t) {
                this.io.start();
                for (var n = 0, i = this.Zs; n < i.length; n++) i[n].start(t);
                this.ro(t)
            }, t.prototype.ro = function(t) {
                var n = this;
                t.DisableCopyPasteListener || (this.N.add(this.W, "copy", !1, this.eo.bind(this)), this.N.add(this.W, "paste", !1, this.so.bind(this))), this.N.add(this.W, "mousemove", !0, function(t) {
                    uh(t) && n.oo(t)
                }), this.N.add(this.W, "mousedown", !0, function(t) {
                    uh(t) && n.uo(t)
                }), this.N.add(this.W, "mouseup", !0, function(t) {
                    uh(t) && n.ao(t)
                }), this.N.add(this.W, "keydown", !0, function(t) {
                    n.Zs[7].onKeyboardChange(Ih(t))
                }), this.N.add(this.W, "keyup", !0, function(t) {
                    n.Zs[7].onKeyboardChange(Ih(t))
                }), this.N.add(this.W, "input", !0, function(t) {
                    n.Zs[7].onInputChange(oh(t))
                }), this.N.add(this.W, "focus", !0, function(t) {
                    n.co(t, Ih(t))
                }, !0), this.N.add(this.W, "blur", !0, function(t) {
                    n.ho(t, Ih(t))
                }, !0), this.N.add(this.W, "change", !0, function(t) {
                    n.fo(t, Ih(t))
                }, !0), this.N.add(this.W, "touchstart", !0, function(t) {
                    uh(t) && (n.vo(t, 32), n.lo())
                }), this.N.add(this.W, "touchend", !0, function(t) {
                    uh(t) && (n.vo(t, 33), n.lo())
                }), this.N.add(this.W, "touchmove", !0, function(t) {
                    uh(t) && (n.vo(t, 35), n.lo())
                }), this.N.add(this.W, "touchcancel", !0, function(t) {
                    uh(t) && n.vo(t, 34)
                }), this.N.add(this.W, "play", !0, function(t) {
                    n["do"](t)
                }), this.N.add(this.W, "pause", !0, function(t) {
                    n.po(t)
                }), this.N.add(this.W, "scroll", !0, function(t) {
                    t.bubbles ? n.lo() : n.wo(oh(t))
                }), this.N.add(this.W, "resize", !1, function() {
                    n.mo()
                }), this.N.add(this.W, "submit", !1, function(t) {
                    n.yo(t)
                }), this.N.add(this.W, "focus", !1, function() {
                    n.bo()
                }), this.N.add(this.W, "blur", !1, function() {
                    n.So()
                }), this.N.add(this.W.document, "mouseenter", !1, function(t) {
                    n._o(117, t)
                }), this.N.add(this.W.document, "mouseleave", !1, function(t) {
                    n._o(118, t)
                }), this.N.add(this.W, "popstate", !1, function() {
                    n.ko()
                }), this.N.add(this.W, "visibilitychange", !1, function(t) {
                    n.addVisibilityChangeEvent()
                });
                var i = this.W.visualViewport;
                i ? (this.N.add(i, "scroll", !0, function() {
                    return n.lo()
                }), this.N.add(i, "resize", !0, function() {
                    return n.mo()
                })) : "onwheel" in this.W ? this.N.add(this.W, "wheel", !0, function() {
                    n.lo()
                }) : "onmousewheel" in this.W && this.N.add(this.W, "mousewheel", !0, function() {
                    n.lo()
                });
                var r = Be(this.C, this.Js, "pushState", !0);
                r && (this.tn.push(r), r.afterSync(function() {
                    return n.ko()
                }), r.afterAsync(function() {
                    return n.ko()
                }));
                var e = Be(this.C, this.Js, "replaceState", !0);
                e && (this.tn.push(e), e.afterSync(function() {
                    return n.ko()
                }), e.afterAsync(function() {
                    return n.ko()
                }));
                for (var s = function(t) {
                        var i = Be(o.C, o.W, t);
                        if (!i) return "continue";
                        o.tn.push(i), i.before(function() {
                            n.St.enqueue({
                                Kind: 74,
                                Args: [t]
                            })
                        }).afterSync(function() {
                            n.St.enqueue({
                                Kind: 75,
                                Args: [t]
                            })
                        })
                    }, o = this, u = 0, a = xn; u < a.length; u++) s(a[u]);
                if ("function" == typeof this.W.document.hasFocus && this.St.enqueue({
                        Kind: this.W.document.hasFocus() ? 52 : 53,
                        Args: []
                    }), this.C.wdx.matchMedia)
                    for (var c = function(t, i, r) {
                            var e = h.C.wdx.matchMedia(h.W, r);
                            if (!e) return "continue";
                            var s = function() {
                                e.matches && n.St.enqueue({
                                    Kind: 66,
                                    Args: [t, i]
                                })
                            };
                            h.N.add(e, "change", !0, s), s()
                        }, h = this, f = 0, v = [
                            ["any-pointer", "coarse", "not screen and (any-pointer: fine)"],
                            ["any-pointer", "fine", "only screen and (any-pointer: fine)"],
                            ["any-hover", "none", "not screen and (any-hover: hover)"],
                            ["any-hover", "hover", "only screen and (any-hover: hover)"],
                            ["pointer", "none", "(pointer: none)"],
                            ["pointer", "coarse", "(pointer: coarse)"],
                            ["pointer", "fine", "(pointer: fine)"],
                            ["prefers-color-scheme", "no-preference", "(prefers-color-scheme: no-preference)"],
                            ["prefers-color-scheme", "light", "(prefers-color-scheme: light)"],
                            ["prefers-color-scheme", "dark", "(prefers-color-scheme: dark)"]
                        ]; f < v.length; f++) {
                        var l = v[f];
                        c(l[0], l[1], l[2])
                    }
                this.Vs = !0
            }, t.prototype.initResourceUploading = function() {
                this.qi.init(), this.qs = !0
            }, t.prototype.onDomLoad = function() {
                this.Io(), this.Ao(!0), this.io.xi(de)
            }, t.prototype.onLoad = function() {
                var t = this,
                    n = !1,
                    i = fe(function() {
                        n || (n = !0, t.Zs[8].onLoad(), t.Eo(), t.Ao())
                    }, "eventWatcher#onLoad");
                new Ds(this.C.wdx, this.C.window, i, 0).start(), So(this.C.wdx, this.C.window).then(i)
            }, t.prototype.onNavigate = function() {
                this.ko()
            }, t.prototype.ajaxWatcher = function() {
                return this.Zs[0]
            }, t.prototype.consoleWatcher = function() {
                return this.Zs[3]
            }, t.prototype.perfWatcher = function() {
                return this.Zs[8]
            }, t.prototype.bundleEvents = function() {
                var t = this;
                return this.St.enqueueSimultaneousEventsIn(function(n) {
                    var i, r = ft(t.C.wdx),
                        e = t.io.processMutations(n);
                    if (e.length > 0) {
                        var s = ft(t.C.wdx) - r;
                        e.push({
                            Kind: 78,
                            Args: [
                                [0, 1, 5, n, s]
                            ],
                            When: n
                        })
                    }
                    for (var o = 0, u = t.Zs; o < u.length; o++) {
                        var a = u[o];
                        null === (i = a.tick) || void 0 === i || i.call(a)
                    }
                    return t.Ao(), e
                })
            }, t.prototype.stop = function(t) {
                var n, i;
                if (this.Vs) {
                    this.Vs = !1, this.Zs[8].onLoad(), this.C.measurer.flush(), this.St.processEvents(), this.C.taskQueue.flush(), this.Ui.flush(), this.io.stop();
                    for (var r = 0, e = this.Zs; r < e.length; r++) e[r].stop(t);
                    null === (n = this.no) || void 0 === n || n.disconnect(), null === (i = this.N) || void 0 === i || i.clearAll(), this.Qs = new Ne;
                    for (var s = 0, o = this.tn; s < o.length; s++) o[s].disable();
                    this.tn = [], this.St.shutdown(t)
                }
            }, t.prototype.recordingIsDetached = function() {
                return this.io.recordingIsDetached()
            }, t.prototype.preVisit = function(t, n) {
                var i = this,
                    r = t.id,
                    e = t.name;
                switch (e) {
                    case "#document":
                    case "#document-fragment":
                        if (this.$s[r] = r, "#document-fragment" === e) {
                            var s = this.N.createChild();
                            s.add(n, "scroll", !0, function(t) {
                                return i.wo(oh(t))
                            }), s.add(n, "change", !0, function(t) {
                                t.composed || i.fo(t, Ih(t))
                            }, !0), this.Qs.set(n, s)
                        }
                        var o = n;
                        this.Zs[9].ensureAdoptedStyleSheetsHooked(n);
                        try {
                            if (!o.adoptedStyleSheets || 0 === o.adoptedStyleSheets.length) break
                        } catch (t) {
                            break
                        }
                        this.Zs[9].onSetAdoptedStyleSheets(n);
                        break;
                    case "INPUT":
                    case "TEXTAREA":
                        this.Zs[7].addInput(n), this.Zs[10].addInput(n);
                        break;
                    case "SELECT":
                        this.Zs[7].addInput(n);
                        break;
                    case "LINK":
                    case "STYLE":
                    case "style":
                        var u = n,
                            a = u.sheet;
                        if (!a) break;
                        var c = this.Zs[9];
                        c.ensureHook(a), a.disabled && c.onDisableSheet(a, !0), "STYLE" === e || "style" === e ? (c.addStyleElement(u), c.snapshotEl(u)) : Ec(this.C.wdx, u) && (c.snapshotEl(u), this.N.add(u, "load", !1, function() {
                            c.snapshotEl(u)
                        }));
                        break;
                    case "BODY":
                        this.Ao(), this.Zs[10].emit();
                        break;
                    case "FRAME":
                    case "IFRAME":
                        this.Bs(n)
                }
            }, t.prototype.visit = function(t) {
                t[0];
                var n = t[1],
                    i = t[2],
                    r = t[3],
                    e = t[4];
                this.Co(n, i, r), this.To(n, i, r, e)
            }, t.prototype.Co = function(t, n, i) {
                var r = this,
                    e = n.name,
                    s = n.type;
                if (0 === t && 10 !== s) {
                    switch (e) {
                        case "VIDEO":
                        case "AUDIO":
                            i.paused || this.St.enqueue({
                                Kind: 38,
                                Args: [Ps(i)]
                            });
                            break;
                        case "DIALOG":
                            var o = i;
                            o.open && this.St.enqueue({
                                Kind: 101,
                                Args: [Ps(o), !0, Fc(this.C.wdx, o)]
                            });
                            break;
                        case "CANVAS":
                            this.Zs[2].flush(i);
                            break;
                        default:
                            e && "#" !== e[0] && e.indexOf("-") > -1 && this.Zs[4].onCustomNodeVisited(e)
                    }
                    this.Zs[11].onNodeVisited(i), "scrollLeft" in i && "scrollTop" in i && this.C.measurer.enqueue(function() {
                        var t = i;
                        0 == t.scrollLeft && 0 == t.scrollTop || r.wo(t)
                    })
                }
            }, t.prototype.To = function(t, n, i, r) {
                var e = this,
                    s = this.C.recording.flags().DisableImgUrlPrivacy;
                if (!s || this.qs) {
                    var o = n.tag;
                    if (n.type === E && r && ! function(t, n) {
                            return void 0 === n && (n = Es(t)), Is(t, n) || As(t, n)
                        }(i)) {
                        var u = "unknown";
                        "link" === o && yh.test(r.rel) ? u = "css" : bh.test(null != o ? o : "") && (u = "img");
                        var a = function(t, n, i) {
                            for (var r, e, s = [], o = 0, u = kh; o < u.length; o++) {
                                var a = u[o];
                                i[a] && _h[a][t] && s.push(i[a])
                            }
                            if ("link" === t && i.href && (r = i.rel) && r.indexOf("stylesheet") > -1 && s.push(i.href), ("img" === t || "source" === t) && (e = i.srcset) && null == e.match(/^\s*$/))
                                for (var c = 0, h = function(t, n) {
                                        void 0 === n && (n = !0);
                                        var i = t,
                                            r = (i = "".concat(i.replace(/\s+/g, " "), ",")).match(n ? ls : vs);
                                        if (!r) return console.warn("Couldn't parse srcset '".concat(i, "'")), [];
                                        for (var e = [], s = 0, o = r; s < o.length; s++) {
                                            var u = o[s];
                                            e.push(u.replace(/^[, ]+|[, ]+$/g, ""))
                                        }
                                        return e
                                    }(e, !0); c < h.length; c++) {
                                    var f = h[c];
                                    s.push(Ru(f.trim().split(/\s+/)[0], {
                                        source: "dom",
                                        type: "srcset"
                                    }))
                                }
                            var v = n;
                            if (i.style && v.style) {
                                var l = v.style.backgroundImage;
                                if (l && l.length <= 300) {
                                    var d = void 0;
                                    for (Ze.lastIndex = 0; d = Ze.exec(l);) {
                                        var p = d[1];
                                        p && s.push(Ru(p.trim(), {
                                            source: "dom",
                                            type: "css"
                                        }))
                                    }
                                }
                            }
                            return s
                        }(o, i, r);
                        if (0 === a.length) {
                            if (s) return;
                            for (var c = 0, h = kh; c < h.length; c++) {
                                var f = r[h[c]];
                                f && a.push(f)
                            }
                            a.length > 0 && this.C.taskQueue.enqueue(function() {
                                return e.Po(a, !1, u)
                            })
                        } else this.C.taskQueue.enqueue(function() {
                            return e.Po(a, !0, u)
                        })
                    }
                }
            }, t.prototype.xn = function(t) {
                var n, i = t.id,
                    r = Ts(i),
                    e = t.name;
                if (this.Zs[11].onNodeRemoved(i), r) {
                    switch (e) {
                        case "#document":
                        case "#document-fragment":
                            delete this.$s[i];
                            var s = this.Qs.get(r);
                            s && (this.N.clearChild(s), this.Qs["delete"](r)), this.Zs[9].removePushHook(r);
                            break;
                        case "IFRAME":
                            this.Ws(r);
                            break;
                        case "LINK":
                        case "STYLE":
                        case "style":
                            this.Zs[9].removeStyleElement(r);
                            var o = r.sheet;
                            o && this.Zs[9].removeHook(o);
                            break;
                        case "INPUT":
                        case "TEXTAREA":
                            var u = r;
                            this.Zs[7].removeInput(u), this.Zs[10].removeInput(u);
                            break;
                        case "SELECT":
                            this.Zs[7].removeInput(r)
                    }
                    if ("function" == typeof r.getElementsByTagName)
                        for (var a = null !== (n = r.getElementsByTagName("iframe")) && void 0 !== n ? n : [], c = 0; c < a.length; c++) {
                            var h = a[c];
                            this.Ws(h)
                        }
                }
            }, t.prototype.ei = function() {
                var t = this;
                this.Gs || (this.Gs = !0, this.C.measurer.enqueue(function() {
                    for (var n in t.Gs = !1, t.$s) {
                        var i = Cs(t.$s[n]);
                        if (i) {
                            var r = Ts(i.id);
                            r && t.Zs[1].snapshot(r)
                        }
                    }
                }))
            }, t.prototype.Po = function(t, n, i) {
                var r;
                void 0 === n && (n = !1), h(window, p);
                for (var e = 0, s = t; e < s.length; e++) {
                    var o = s[e];
                    /^(([a-z\-_]+):|\/\/)/i.test(o) && (this.qs && n && (void 0 === r && (r = Ru(Eu(this.W), {
                        source: "page",
                        type: "base"
                    })), this.qi.uploadIfNeeded(this.W, Au(r, o), i)), this.Ui.record(o))
                }
                f(window, p)
            }, t.prototype.oo = function(t) {
                this.xo(t, 8)
            }, t.prototype.uo = function(t) {
                this.xo(t, 12)
            }, t.prototype.ao = function(t) {
                this.xo(t, 13)
            }, t.prototype.xo = function(t, n) {
                var i = Ps(oh(t)),
                    r = t.clientX,
                    e = t.clientY;
                this.St.enqueue({
                    Kind: n,
                    Args: i ? [r, e, i] : [r, e]
                })
            }, t.prototype.vo = function(t, n) {
                if (void 0 !== t.changedTouches)
                    for (var i = 0; i < t.changedTouches.length; ++i) {
                        var r = t.changedTouches[i];
                        isNaN(parseInt(r.identifier, 10)) && (r.identifier = 0);
                        var e = [r.identifier, r.clientX, r.clientY];
                        this.St.enqueue({
                            Kind: n,
                            Args: e
                        })
                    }
            }, t.prototype["do"] = function(t) {
                var n = Ps(oh(t));
                n && this.St.enqueue({
                    Kind: 38,
                    Args: [n]
                })
            }, t.prototype.po = function(t) {
                var n = Ps(oh(t));
                n && this.St.enqueue({
                    Kind: 39,
                    Args: [n]
                })
            }, t.prototype.bo = function() {
                this.St.enqueue({
                    Kind: 52,
                    Args: []
                })
            }, t.prototype.So = function() {
                this.St.enqueue({
                    Kind: 53,
                    Args: []
                })
            }, t.prototype._o = function(t, n) {
                var i = Ps(this.W.document);
                i && this.St.enqueue({
                    Kind: t,
                    Args: [i, n.clientX, n.clientY]
                })
            }, t.prototype.Ao = function(t) {
                var n = this;
                void 0 === t && (t = !1), this.C.measurer.enqueue(function() {
                    return n.Ro(t)
                })
            }, t.prototype.Ro = function(t) {
                var n = this;
                void 0 === t && (t = !1);
                var i, r = (i = this.W.document).scrollingElement || i.body || i.documentElement,
                    e = Ps(r);
                if (e) {
                    var s = function(t) {
                            n.St.enqueue(t)
                        },
                        o = function(t, n) {
                            var i, r = t.documentElement.getBoundingClientRect(),
                                e = null !== (i = t.body) && void 0 !== i ? i : {
                                    scrollHeight: 0,
                                    scrollWidth: 0
                                };
                            return {
                                width: Math.max(r.width, n.scrollWidth, e.scrollWidth),
                                height: Math.max(r.height, n.scrollHeight, e.scrollHeight)
                            }
                        }(this.W.document, r);
                    Ge(o, this.Mo) || (this.Mo = o, s({
                        Kind: 42,
                        Args: [o.width, o.height]
                    }));
                    var u, a, c, h, f = us(this.C.wdx, this.C.window, t ? void 0 : this.Ko),
                        v = function(t, n, i) {
                            var r = n.visualViewport;
                            if (r) return r;
                            var e = i;
                            return void 0 === e && (e = us(t, n)), new as(n, e)
                        }(this.C.wdx, this.C.window, f);
                    f.hasKnownPosition ? ($e(f, this.Ko) || s({
                            Kind: 10,
                            Args: [e, f.pageLeft, f.pageTop]
                        }), u = v, (a = this.jo) && u.offsetLeft == a.offsetLeft && u.offsetTop == a.offsetTop || s({
                            Kind: 64,
                            Args: [e, v.offsetLeft, v.offsetTop]
                        })) : $e(v, this.jo) || s({
                            Kind: 10,
                            Args: [e, v.pageLeft, v.pageTop]
                        }),
                        function(t, n) {
                            return n && t.width == n.width && t.height == n.height && t.clientWidth == n.clientWidth && t.clientHeight == n.clientHeight
                        }(f, this.Ko) || s({
                            Kind: 19,
                            Args: hs(f)
                        }), Ge(v, this.jo) || s({
                            Kind: 40,
                            Args: [v.width, v.height]
                        }), this.Ko = ((h = Qe(c = f)).clientWidth = c.clientWidth, h.clientHeight = c.clientHeight, h), this.jo = function(t) {
                            var n = Qe(t);
                            return n.offsetLeft = t.offsetLeft, n.offsetTop = t.offsetTop, n
                        }(v)
                }
            }, t.prototype.Oo = function(t, n) {
                var i = this;
                t in this.zs || (this.zs[t] = n, new Ds(this.C.wdx, this.C.window, function() {
                    i.C.measurer.enqueue(function() {
                        if (t in i.zs) {
                            var n = i.zs[t];
                            delete i.zs[t], n()
                        }
                    })
                }, Tn.ScrollSampleInterval).start())
            }, t.prototype.lo = function() {
                var t = this;
                this.Oo(1, function() {
                    return t.Ro(!1)
                })
            }, t.prototype.mo = function() {
                var t = this;
                this.Oo(2, function() {
                    return t.Ro(!0)
                })
            }, t.prototype.wo = function(t) {
                var n = this,
                    i = Ps(t);
                i && this.Oo(i, function() {
                    if (Ps(t) === i) {
                        var r = t;
                        i && "number" == typeof r.scrollLeft && (n.St.enqueue({
                            Kind: 43,
                            Args: [i, r.scrollWidth, r.scrollHeight]
                        }), n.St.enqueue({
                            Kind: 10,
                            Args: [i, r.scrollLeft, r.scrollTop]
                        }), bo(n.C.wdx, n.C.window).then(function() {
                            n.io.resizer().isObserved(i) || n.io.resizer().observe(t)
                        }))
                    }
                })
            }, t.prototype.Io = function() {
                this.St.enqueue({
                    Kind: 20,
                    Args: []
                })
            }, t.prototype.Eo = function() {
                this.St.enqueue({
                    Kind: 21,
                    Args: []
                })
            }, t.prototype.getNavigateEvent = function(t, n) {
                void 0 === n && (n = 37);
                var i = {
                    Kind: n,
                    Args: [Ru(t, {
                        source: "event",
                        type: 37
                    })]
                };
                return 81 === n ? (i.Args.push(this.Uo()), i) : i
            }, t.prototype.ko = function() {
                var t = this.Xs.href;
                this.Ys != t && (this.Ys = t, this._s.onNavigate(t), this.St.enqueue(this.getNavigateEvent(t)))
            }, t.prototype.Uo = function() {
                try {
                    var t = this.W.performance;
                    if (!t || !t.navigation) return "unknown";
                    switch (t.navigation.type) {
                        case PerformanceNavigation.TYPE_NAVIGATE:
                            return "navigate";
                        case PerformanceNavigation.TYPE_RELOAD:
                            return "reload";
                        case PerformanceNavigation.TYPE_BACK_FORWARD:
                            return "back_forward";
                        default:
                            return "unknown"
                    }
                } catch (t) {
                    return "unknown"
                }
            }, t.prototype.yo = function(t) {
                var n = Ps(oh(t));
                n && this.St.enqueue({
                    Kind: 51,
                    Args: Ah(n, t.agentInvoked)
                })
            }, t.prototype.co = function(t, n) {
                var i = Ps(oh(t));
                i && this.St.enqueue({
                    Kind: 17,
                    Args: [i, n]
                })
            }, t.prototype.ho = function(t, n) {
                var i = Ps(oh(t));
                i && this.St.enqueue({
                    Kind: 24,
                    Args: [i, n]
                })
            }, t.prototype.fo = function(t, n) {
                this.Zs[7].onChange(oh(t), n)
            }, t.prototype.eo = function() {
                this.St.enqueue({
                    Kind: 84,
                    Args: []
                })
            }, t.prototype.so = function() {
                this.St.enqueue({
                    Kind: 85,
                    Args: []
                })
            }, t.prototype.addVisibilityChangeEvent = function() {
                this.St.enqueue({
                    Kind: 100,
                    Args: [document.visibilityState]
                }), "hidden" === document.visibilityState && this.St.singSwanSong(8)
            }, t
        }(),
        _h = {
            src: {
                img: !0,
                embed: !0,
                source: !0
            },
            href: {
                use: !0,
                image: !0
            },
            data: {
                object: !0
            }
        },
        kh = ["src", "href", "data"];

    function Ih(t) {
        var n;
        return !!(null !== (n = t[Dn]) && void 0 !== n && n || t.isTrusted)
    }

    function Ah(t, n) {
        return !0 === n ? [t, !0] : [t]
    }

    function Eh(t) {
        return 8 === t.Kind || 35 === t.Kind || 10 === t.Kind || 64 === t.Kind || 40 === t.Kind
    }
    var Ch, Th, Ph = function() {
        function t(t, n) {
            this.ae = t, this.No = n, this.Lo = [], this.Fo = 0
        }
        return t.prototype.add = function(t) {
            this.Lo.length > 0 && this.Lo[this.Lo.length - 1].When === t.When && this.Lo.pop(), 0 === this.Lo.length ? (this.ae.push(t), this.Fo = t.When) : t.When > this.Fo && (this.Fo = t.When), this.Lo.push(t)
        }, t.prototype.finish = function(t, n) {
            void 0 === n && (n = []);
            var i = this.Lo.length;
            if (i <= 1) return !1;
            for (var r = [], e = this.Lo[0].When, o = this.Lo[i - 1].When, u = o - e != 0 ? o - e : 1, a = 0; a < this.No.length; ++a) {
                var c = this.No[a],
                    h = this.Lo[0].Args[c],
                    f = (this.Lo[1].When - e) / u,
                    v = (this.Lo[1].Args[c] - h) / f,
                    l = this.Lo[i - 2].Args[c],
                    d = (o - this.Lo[i - 2].When) / u,
                    p = this.Lo[i - 1].Args[c],
                    g = (p - l) / d;
                r.push(h, p, v, g)
            }
            return this.Lo[0].Kind = t, this.Lo[0].Args = s(s([this.Fo], n, !0), r, !0), !0
        }, t.prototype.evts = function() {
            return this.Lo
        }, t
    }();
    (Th = Ch || (Ch = {})).rageWindowMillis = 2e3, Th.defaultRageThreshold = 5, Th.rageThresholdIfPageChanges = 8, Th.thresholdChangeQuiescenceMillis = 2e3;
    var xh = function() {
            function t(t, n) {
                var i, r;
                void 0 === n && (n = vt), this.C = t, this.Ho = n, this.Do = new Io, this.Bo = Ch.defaultRageThreshold, this.Wo = -1, this.zo = new WeakMap;
                var e = t.recording.pageResponse();
                if (!e) throw new Error("Attempt to construct EasyBake before rec/page response is set.");
                for (var s = [".fs-ignore-rage-clicks", ".fs-ignore-rage-clicks *"], o = 0, u = null !== (r = null === (i = e.BehaviorSignalSettings) || void 0 === i ? void 0 : i.ElementBlocks) && void 0 !== r ? r : []; o < u.length; o++) {
                    var a = u[o];
                    a.Signals.indexOf(2) > -1 && (s.push(a.Selector), s.push("".concat(a.Selector, " *")))
                }
                var c = s.join(", ");
                Do(this.C.wdx, c) ? this.qo = [c] : this.qo = s
            }
            return t.prototype.Vo = function(t) {
                var n = this.zo.get(t);
                if (void 0 !== n) return n;
                for (var i = 0, r = this.qo; i < r.length; i++) {
                    var e = r[i];
                    if (this.C.wdx.elMatches(t, e)) return this.zo.set(t, !0), !0
                }
                return this.zo.set(t, !1), !1
            }, t.prototype.onEvent = function(t) {
                var n = 114 === t.Kind ? t.Args[0] : t.Kind;
                if (function(t) {
                        switch (t) {
                            case 18:
                            case 10:
                            case 11:
                            case 64:
                            case 65:
                            case 2:
                            case 3:
                            case 4:
                            case 68:
                            case 6:
                            case 37:
                            case 21:
                            case 17:
                            case 24:
                            case 59:
                            case 51:
                            case 38:
                            case 39:
                            case 74:
                            case 75:
                                return !0
                        }
                        return !1
                    }(n) && this.Bo !== Ch.rageThresholdIfPageChanges) return this.Bo = Ch.rageThresholdIfPageChanges, void(this.Wo = this.Ho(this.C.wdx));
                if (16 === n) {
                    var i = this.Ho(this.C.wdx),
                        r = Ts(ua(this.C.wdx, [t])[0].Args[0]);
                    if (r && Ps(r)) {
                        var e = r.nodeType === E ? r : K(r);
                        if (e && !this.Vo(e)) {
                            var s = fs(r);
                            if (!s || "textarea" !== s && "select" !== s && ("input" !== s || "submit" === r.type)) {
                                this.Do.push(i);
                                for (var o = i - Ch.rageWindowMillis;;) {
                                    var u = this.Do.first();
                                    if (!(void 0 !== u && u < o)) break;
                                    this.Do.shift()
                                }
                                if (this.Wo < i - Ch.thresholdChangeQuiescenceMillis && (this.Bo = Ch.defaultRageThreshold), this.Do.size() >= this.Bo) {
                                    var a = this.C.recording.getCurrentSessionURL,
                                        c = {
                                            eventStartTimeStamp: this.Do.first(),
                                            eventEndTimeStamp: i,
                                            eventReplayUrlAtStart: a(),
                                            eventReplayUrlAtCurrentTime: a(!0)
                                        };
                                    ! function(t, n, i) {
                                        var r, e = "fullstory/rageclick";
                                        try {
                                            r = new CustomEvent(e, {
                                                detail: i,
                                                bubbles: !0,
                                                cancelable: !0
                                            })
                                        } catch (t) {
                                            (r = document.createEvent("customevent")).initCustomEvent(e, !0, !0, i)
                                        }
                                        t.wdx.setWindowTimeout(t.window, fe(function() {
                                            n.dispatchEvent(r)
                                        }, "dispatchRageClickEvent"), 0)
                                    }(this.C, r, c), this.Bo = Ch.defaultRageThreshold, this.Do = new Io
                                }
                            }
                        }
                    }
                }
            }, t
        }(),
        Rh = "HibernationTimerExceeded",
        Mh = 2 * Tn.PageInactivityTimeout,
        Kh = function() {
            function t(t) {
                this.C = t, this.$o = this.C.time.wallTime(), this.Go = !1
            }
            return t.prototype.getLastUserActivityTS = function() {
                return this.$o
            }, t.prototype.getMsSinceLastUserActivity = function() {
                return this.C.wdx.mathFloor(this.C.time.wallTime() - this.$o)
            }, t.prototype.resetUserActivity = function() {
                this.$o = this.C.time.wallTime()
            }, t.prototype.isHibernating = function() {
                return this.Go
            }, t.prototype.setHibernating = function() {
                this.Go = !0
            }, t
        }(),
        jh = function() {
            function t(t, n, i, r) {
                void 0 === r && (r = Ds), this.C = t, this.Qo = n, this.St = i, this.Xo = !1, this.Jo = !1, this.Yo = !1, this.Zo = !1, this.tu = {}, this.nu = new r(this.C.wdx, this.C.window, this.iu.bind(this), Tn.HeartbeatIntervalMS), this.ru = new r(this.C.wdx, this.C.window, this.eu.bind(this), Tn.PageInactivityTimeout)
            }
            return t.prototype.getUserActivityModel = function() {
                return this.Qo
            }, t.prototype.manualHibernateCheck = function() {
                this.Qo.isHibernating() || this.Qo.getMsSinceLastUserActivity() >= Tn.PageInactivityTimeout + 5e3 && this.eu()
            }, t.prototype.intercept = function(t) {
                var n = function(t) {
                    switch (t) {
                        case 12:
                        case 8:
                        case 9:
                        case 13:
                        case 32:
                        case 33:
                        case 35:
                        case 36:
                        case 34:
                        case 16:
                        case 10:
                        case 11:
                        case 64:
                        case 65:
                        case 37:
                            return !0
                    }
                    return !1
                }(114 === t.Kind ? t.Args[0] : t.Kind);
                this.su(t), !this.Xo && n && (this.Qo.isHibernating() ? this.ou() : this.uu())
            }, t.prototype.shutdown = function() {
                this.nu.stop(), this.ru.stop()
            }, t.prototype.uu = function(t) {
                var n = this;
                void 0 === t && (t = !0), this.Yo || (this.Qo.resetUserActivity(), this.nu.start(), this.ru.start(), t && (this.Yo = !0, So(this.C.wdx, this.C.window).then(function() {
                    n.Yo = !1
                })))
            }, t.prototype.start = function() {
                var t = this.C.recording.heartbeatIntervalMS();
                this.au(t), this.uu(!1)
            }, t.prototype.cu = function() {
                return this.Qo.isHibernating() || this.Xo
            }, t.prototype.au = function(t) {
                var n = this.nu.isRunning();
                this.nu.start(t), n || this.nu.stop()
            }, t.prototype.iu = function() {
                var t = this.Qo.getMsSinceLastUserActivity();
                t <= Tn.PageInactivityTimeout && this.St.enqueue({
                    Kind: 54,
                    Args: [t]
                }), this.nu.start()
            }, t.prototype.eu = function() {
                if (!this.Qo.isHibernating()) {
                    var t = !1;
                    this.Qo.getMsSinceLastUserActivity() <= Mh ? this.St.enqueue({
                        Kind: 23,
                        Args: [3]
                    }) : t = !0;
                    try {
                        this.Xo = !0, this.Qo.setHibernating(), this.shutdown(), this.St.onHibernate(t)
                    } finally {
                        this.Xo = !1
                    }
                }
            }, t.prototype.ou = function() {
                this.Jo || (this.Jo = !0, this.C.recording.splitPage(3))
            }, t.prototype.su = function(t) {
                this.manualHibernateCheck();
                var n = et(t.PIds, t.FId),
                    i = function(t) {
                        var n = t.When;
                        return "number" == typeof n ? n : 0
                    }(t),
                    r = this.tu[n] || 0,
                    e = this.cu(),
                    s = this.hu(i, r);
                s && (this.Zo = !0), !e && s && this.eu(), this.Zo ? function(t, n, i) {
                    var r = n;
                    114 === n.Kind && (r = ua(0, [n])[0]);
                    var e = Gr(t, r, Rh, Rh);
                    n.When = i, n.Kind = e.Kind, n.Args = e.Args
                }(this.C.wdx, t, r) : this.tu[n] = i
            }, t.prototype.hu = function(t, n) {
                if (t - n <= Mh) return !1;
                for (var i in this.tu) {
                    var r = this.tu[i];
                    if (this.C.wdx.mathAbs(t - r) <= Mh) return !1
                }
                return !0
            }, t
        }(),
        Oh = function() {
            function t(t, n, i, r, e) {
                void 0 === r && (r = 100), void 0 === e && (e = 0), this.t = t, this.W = n, this.fu = i, this.vu = r, this.lu = e, this.du = !1, this.pu = !1
            }
            return t.prototype.start = function() {
                var t = this;
                this.du = !0, this.pu = !1, this.lu > 0 && (this.pu = !0, wo(this.t, this.W, this.lu).then(function() {
                    t.pu = !1
                }))
            }, t.prototype.stop = function() {
                this.du = !1, this.pu = !1
            }, t.prototype.intercept = function(t) {
                var n = this;
                this.du && !this.pu && function(t) {
                    switch (t) {
                        case 16:
                        case 12:
                        case 13:
                        case 32:
                        case 33:
                        case 34:
                        case 24:
                        case 37:
                        case 81:
                        case 8197:
                        case 8193:
                        case 56:
                            return !0
                    }
                    return !1
                }(t.Kind) && (this.pu = !0, wo(this.t, this.W, this.vu).then(function() {
                    n.pu = !1, n.du && n.fu()
                }))
            }, t
        }(),
        Uh = function() {
            function t(t, n, i, r, e, s, o) {
                void 0 === r && (r = function() {
                    return []
                }), void 0 === e && (e = Hs), void 0 === s && (s = Ds);
                var u = this;
                this.C = t, this.gu = n, this.wu = r, this.mu = e, this.yu = 0, this.bu = [], this.Su = !1, this._u = !1, this.ku = 0, this.Iu = -1, this.Au = !1, this.sn = [], this.Eu = [], this.Cu = new Nh, this.Tu = new s(t.wdx, t.window, function() {
                    h(window, v), u.processEvents(!0), f(window, v)
                }, 142), this.Pu = new this.mu(t.wdx, t.window, 250), i && (this.xu = new jh(this.C, i, this, s), this.Eu.push(this.xu)), this.Eu.push(this.Cu), o && this.Eu.push(o)
            }
            return t.prototype.startPipeline = function(t) {
                return r(this, void 0, void 0, function() {
                    var n, i, r = this;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return this._u || this.Su ? [2] : (this.Su = !0, t.frameId && (this.yu = t.frameId), t.parentIds && (this.bu = t.parentIds), t.fixWhenValues && 0 === (null !== (n = t.frameId) && void 0 !== n ? n : 0) && this.Cu.startPipeline(), this.C.recording.flags().ImmediateMode && (this.Ru = (s = this.C, o = function() {
                                    return r.Mu()
                                }, new Oh(s.wdx, s.window, o, 100, s.recording.bundleUploadIntervalMS())), this.Eu.push(this.Ru), this.Ru.start()), [4, bo(this.C.wdx, this.C.window)]);
                            case 1:
                                return e.sent(), this.processEvents(), [4, bo(this.C.wdx, this.C.window)];
                            case 2:
                                return e.sent(), h(window, _), this.Pu.start(function() {
                                    h(window, l), r.processEvents(), f(window, l)
                                }), null === (i = this.xu) || void 0 === i || i.start(), this.gu.startPipeline(t), f(window, _), [2]
                        }
                        var s, o
                    })
                })
            }, t.prototype.enableEasyBake = function() {
                this.Ku = new xh(this.C)
            }, t.prototype.enqueueSimultaneousEventsIn = function(t) {
                if (0 === this.ku) {
                    var n = this.C.time.now();
                    this.Iu = n > this.Iu ? n : this.Iu
                }
                try {
                    return this.ku++, t(this.Iu)
                } finally {
                    this.ku--, this.ku < 0 && (this.ku = 0)
                }
            }, t.prototype.enqueue = function(t) {
                var n = this.ku > 0 ? this.Iu : this.C.time.now();
                this.ju(n, t), Fs.checkForBrokenSchedulers(this.C.wdx, this.C.window)
            }, t.prototype.ju = function(t, n) {
                var i;
                if (!this._u) {
                    var r = t;
                    r < this.Iu && (r = this.Iu), this.Iu = r;
                    var e = n;
                    e.When = r, this.sn.push(e);
                    try {
                        null === (i = this.Ku) || void 0 === i || i.onEvent(e)
                    } catch (t) {
                        ve("easyBake", {
                            err: t,
                            kind: e.Kind
                        })
                    }!this.Tu.isRunning() && Eh(e) && this.Tu.start()
                }
            }, t.prototype.enqueueFirst = function(t) {
                if (this.sn.length > 0) {
                    var n = t;
                    n.When = this.sn[0].When, this.sn.unshift(n)
                } else this.enqueue(t)
            }, t.prototype.addUnload = function(t) {
                this.Au || (this.Au = !0, this.enqueue({
                    Kind: 23,
                    Args: [t]
                }), this.singSwanSong(t))
            }, t.prototype.shutdown = function(t) {
                this.addUnload(t), this.Mu(), this._u = !0, this.Ou()
            }, t.prototype.Mu = function() {
                var t, n;
                this.processEvents(), null === (n = (t = this.gu).send) || void 0 === n || n.call(t)
            }, t.prototype.singSwanSong = function(t) {
                var n, i;
                this._u || (h(window, d), this.Mu(), 8 === t && this.Au || null === (i = (n = this.gu).send) || void 0 === i || i.call(n, {
                    mode: "sing",
                    reason: t
                }), f(window, d))
            }, t.prototype.rebaseIframe = function(t, n) {
                for (var i = Math.max(0, n), r = this.C.time.startTime(), e = function(n) {
                        var e = r + n - t;
                        return e >= i ? e : i
                    }, s = 0, o = this.sn; s < o.length; s++) {
                    var u = o[s];
                    u.When = e(u.When)
                } - 1 === this.Iu ? this.Iu = i : this.Iu = e(this.Iu)
            }, t.prototype.processEvents = function(t) {
                if (this.Su) {
                    var n = this.sn;
                    this.sn = [];
                    var i = function(t) {
                        if (0 == t.length) return t;
                        for (var n, i = [], r = new Ph(i, [0, 1]), e = {}, s = {}, o = {}, u = 0, a = t; u < a.length; u++) {
                            var c = a[u];
                            if (Eh(c)) switch (c.Kind) {
                                case 8:
                                    r.add(c);
                                    break;
                                case 35:
                                    (v = c.Args[0]) in e || (e[v] = new Ph(i, [1, 2])), e[v].add(c);
                                    break;
                                case 10:
                                    (v = c.Args[0]) in s || (s[v] = new Ph(i, [1, 2])), s[v].add(c);
                                    break;
                                case 64:
                                    (v = c.Args[0]) in o || (o[v] = new Ph(i, [1, 2])), o[v].add(c);
                                    break;
                                case 40:
                                    n || (n = new Ph(i, [0, 1])), n.add(c);
                                    break;
                                default:
                                    Ho()
                            } else i.push(c)
                        }
                        if (r.finish(9)) {
                            var h = r.evts();
                            if (h.length > 0) {
                                var f = h[h.length - 1].Args[2];
                                f && (h[0].Args[9] = f)
                            }
                        }
                        for (var v in s) s[l = parseInt(v, 10)].finish(11, [l]);
                        for (var v in o) o[l = parseInt(v, 10)].finish(65, [l]);
                        for (var v in e) {
                            var l;
                            e[l = parseInt(v, 10)].finish(36, [l])
                        }
                        return n && n.finish(41), i
                    }(n);
                    t || (i = i.concat(this.wu())), this.Uu(i), this.sendEvents(this.C.recording.pageSignature(), i)
                }
            }, t.prototype.registerInterceptor = function(t) {
                this.Eu.push(t)
            }, t.prototype.sendEvents = function(t, n) {
                if (0 != n.length) {
                    if (this.Eu.length > 0)
                        for (var i = 0, r = n; i < r.length; i++)
                            for (var e = r[i], s = 0, u = this.Eu; s < u.length; s++) u[s].intercept(e);
                    try {
                        this.gu.enqueueEvents(t, n)
                    } catch (t) {
                        o(function() {
                            return "transport.enqueueEvents: caught exception ".concat(t)
                        })
                    }
                }
            }, t.prototype.onHibernate = function(t) {
                var n, i, r;
                t || this.Mu(), null === (i = (n = this.gu).send) || void 0 === i || i.call(n, {
                    mode: "sing"
                }), this.gu.stopPipeline(), null === (r = this.Ru) || void 0 === r || r.stop()
            }, t.prototype.Uu = function(t) {
                if (this.yu)
                    for (var n = this.bu, i = n && n.length > 0, r = 0; r < t.length; ++r) {
                        var e = t[r];
                        e.FId || (e.FId = this.yu), i && !e.PIds && (e.PIds = n)
                    }
            }, t.prototype.Ou = function() {
                var t, n;
                this.Su && (this.Tu.stop(), this.Pu.stop(), this.sn = [], null === (t = this.xu) || void 0 === t || t.shutdown(), this.gu.stopPipeline(), this.Cu.stopPipeline(), null === (n = this.Ru) || void 0 === n || n.stop())
            }, t.prototype.manualHibernateCheck = function() {
                var t;
                null === (t = this.xu) || void 0 === t || t.manualHibernateCheck()
            }, t
        }(),
        Nh = function() {
            function t() {
                this.Jt = !1, this.Nu = {}
            }
            return t.prototype.startPipeline = function() {
                this.Jt = !0
            }, t.prototype.stopPipeline = function() {
                this.Jt = !1, this.Nu = {}
            }, t.prototype.intercept = function(t) {
                var n;
                if (this.Jt) {
                    var i = et(t.PIds, t.FId),
                        r = null !== (n = this.Nu[i]) && void 0 !== n ? n : -1;
                    t.When > r ? this.Nu[i] = t.When : t.When < r && (t.When = r)
                }
            }, t
        }(),
        Lh = function() {
            function t(t) {
                void 0 === t && (t = 4), this.hashCount = t, this.idx = 0, this.hashMask = t - 1, this.reset()
            }
            return t.prototype.reset = function() {
                this.idx = 0, this.hash = [];
                for (var t = 0; t < this.hashCount; ++t) this.hash.push(2166136261)
            }, t.prototype.write = function(t) {
                for (var n = this.hashMask, i = this.idx, r = 0; r < t.length; r++) this.hash[i] = this.hash[i] ^ t[r], this.hash[i] = this.hash[i] + (this.hash[i] << 1) + (this.hash[i] << 4) + (this.hash[i] << 7) + (this.hash[i] << 8) + (this.hash[i] << 24), i = i + 1 & n;
                this.idx = i
            }, t.prototype.writeAscii = function(t) {
                for (var n = this.hashMask, i = this.idx, r = 0; r < t.length; r++) this.hash[i] = this.hash[i] ^ t.charCodeAt(r), this.hash[i] = this.hash[i] + (this.hash[i] << 1) + (this.hash[i] << 4) + (this.hash[i] << 7) + (this.hash[i] << 8) + (this.hash[i] << 24), i = i + 1 & n;
                this.idx = i
            }, t.prototype.sum = function() {
                var t;
                return t = this.sumAsHex().replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ").map(Number), Bh(String.fromCharCode.apply(window, t))
            }, t.prototype.sumAsHex = function() {
                for (var t = "", n = 0; n < this.hashCount; ++n) t += "00000000".concat((this.hash[n] >>> 0).toString(16)).slice(-8);
                return t
            }, t
        }();

    function Fh(t) {
        var n = new Lh(1);
        return n.writeAscii(t), n.sumAsHex()
    }

    function Hh(t) {
        var n = new Uint8Array(t);
        return Bh(String.fromCharCode.apply(null, n))
    }
    var Dh = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

    function Bh(t) {
        var n;
        return (null !== (n = window.btoa) && void 0 !== n ? n : Wh)(t).replace(/\+/g, "-").replace(/\//g, "_")
    }

    function Wh(t) {
        for (var n = String(t), i = [], r = 0, e = 0, s = 0, o = Dh; n.charAt(0 | s) || (o = "=", s % 1); i.push(o.charAt(63 & r >> 8 - s % 1 * 8))) {
            if ((e = n.charCodeAt(s += 3 / 4)) > 255) throw new Error("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
            r = r << 8 | e
        }
        return i.join("")
    }
    var zh = 1e4,
        qh = 25,
        Vh = 100;

    function $h(t, n, i) {
        return r(this, arguments, void 0, function(t, n, i, r) {
            var s, o, u, a;
            return void 0 === r && (r = new Lh), e(this, function(e) {
                switch (e.label) {
                    case 0:
                        s = t.now(), o = i.byteLength, u = 0, e.label = 1;
                    case 1:
                        return u < o ? t.now() - s > qh ? [4, n(Vh)] : [3, 3] : [3, 5];
                    case 2:
                        e.sent(), s = t.now(), e.label = 3;
                    case 3:
                        a = new Uint8Array(i, u, Math.min(o - u, zh)), r.write(a), e.label = 4;
                    case 4:
                        return u += zh, [3, 1];
                    case 5:
                        return [2, {
                            hash: r.sum(),
                            hasher: r
                        }]
                }
            })
        })
    }

    function Gh(t, n, i) {
        return r(this, void 0, void 0, function() {
            var r, s;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (null === (s = null === (r = t.crypto) || void 0 === r ? void 0 : r.subtle) || void 0 === s ? void 0 : s.digest) ? [4, t.crypto.subtle.digest({
                            name: "sha-1"
                        }, i)] : [3, 2];
                    case 1:
                        return [2, {
                            hash: Hh(e.sent()),
                            algorithm: "sha1"
                        }];
                    case 2:
                        return [4, $h(n, Qh, i)];
                    case 3:
                        return [2, {
                            hash: e.sent().hash,
                            algorithm: "fsnv"
                        }]
                }
            })
        })
    }

    function Qh(t) {
        return new Promise(function(n) {
            return setTimeout(function() {
                try {
                    n()
                } catch (t) {}
            }, t)
        })
    }

    function Xh(t) {
        var n, i;
        return !!(null === (i = null === (n = t.Capacitor) || void 0 === n ? void 0 : n.isNativePlatform) || void 0 === i ? void 0 : i.call(n))
    }
    var Jh = 6e6,
        Yh = /^\/?_capacitor_file_/,
        Zh = function() {
            function t(t, n, i, r, e) {
                void 0 === r && (r = window.FormData), void 0 === e && (e = Ds), this.C = t, this.St = n, this.Lu = i, this.Fu = r, this.Hu = e, this.je = {}, this.Du = {}, this.Bu = !1, this.Wu = []
            }
            return t.prototype.init = function() {
                this.Fu && this.zu()["catch"](function(t) {
                    ve("resourceuploader#init", {
                        err: t
                    })
                })
            }, t.prototype.zu = function() {
                return r(this, void 0, void 0, function() {
                    var t, n, i, r, s, u, a, c, h, f, v, l, d, p, g, w, m, y, b, S, _, k, I, A, E;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                t = this.C.options.orgId, e.label = 1;
                            case 1:
                                return [4, this.qu()];
                            case 2:
                                for (n = e.sent(), i = {
                                        fsnv: {},
                                        sha1: {}
                                    }, r = {}, s = 0, u = n; s < u.length; s++) b = u[s], i[b.hashAlgorithm][b.hash] = !0, (l = r[b.hash]) ? l.push(b) : r[b.hash] = [b];
                                a = {
                                    fsnv: Object.keys(i.fsnv),
                                    sha1: Object.keys(i.sha1)
                                }, c = void 0, e.label = 3;
                            case 3:
                                return e.trys.push([3, 5, , 6]), [4, this.Lu.queryResources({
                                    OrgId: t,
                                    HashesByAlgorithm: a
                                })];
                            case 4:
                                return c = e.sent(), [3, 6];
                            case 5:
                                return e.sent(), [3, 1];
                            case 6:
                                h = 0, f = c, e.label = 7;
                            case 7:
                                if (!(h < f.length)) return [3, 18];
                                if (v = f[h], !(null == (l = r[v.QueryHash]) ? void 0 : l.length)) return he("No resource found for hash"), [3, 17];
                                if (d = v.Found && v.CanonicalHash, !v.Found || !v.CanonicalHash) return [3, 8];
                                for (p = 0, g = l; p < g.length; p++)(b = g[p]).blob = b.stringData = null, "fsnv" === (w = v.CanonicalHash.Algorithm) ? this.St.enqueue({
                                    Kind: 8195,
                                    Args: ["url", b.url, v.CanonicalHash.Hash]
                                }) : he("Unrecognized hash", {
                                    hashAlgorithm: w,
                                    reportFound: d
                                });
                                return [3, 17];
                            case 8:
                                m = 0, y = l, e.label = 9;
                            case 9:
                                if (!(m < y.length)) return [3, 17];
                                if (b = y[m], S = b.url, _ = b.contentType, (k = {}).orgId = t, k.baseUrl = S, "fsnv" === v.QueryAlgorithm) k.fsnvHash = v.QueryHash;
                                else {
                                    if ("sha1" !== v.QueryAlgorithm) return he("Unrecognized hash", {
                                        hashAlgorithm: v.QueryAlgorithm,
                                        reportFound: d
                                    }), [3, 16];
                                    k.sha1Hash = v.QueryHash
                                }
                                return b.blob ? [4, Ba(b.blob)] : [3, 11];
                            case 10:
                                return (I = e.sent()) ? (k.contents = {
                                    data: I,
                                    contentType: _,
                                    filename: "blob"
                                }, [3, 12]) : [3, 17];
                            case 11:
                                b.stringData && (k.contents = {
                                    data: b.stringData,
                                    contentType: _,
                                    filename: "blob"
                                }), e.label = 12;
                            case 12:
                                if (!k.contents) return he("Missing resource contents"), [3, 16];
                                b.blob = b.stringData = null, e.label = 13;
                            case 13:
                                return e.trys.push([13, 15, , 16]), [4, this.Lu.uploadResource({
                                    type: "FormData",
                                    data: k
                                })];
                            case 14:
                                return A = e.sent(), "fsnv" != (E = JSON.parse(A)).Algorithm && he("Unrecognized hash", {
                                    hashAlgorithm: E.Algorithm,
                                    from: "response"
                                }), this.St.enqueue({
                                    Kind: 8195,
                                    Args: ["url", S, E.Hash]
                                }), [3, 16];
                            case 15:
                                return e.sent(), o(function() {
                                    return "Server error uploading resource"
                                }), [3, 16];
                            case 16:
                                return m++, [3, 9];
                            case 17:
                                return h++, [3, 7];
                            case 18:
                                return [3, 1];
                            case 19:
                                return [2]
                        }
                    })
                })
            }, t.prototype.qu = function() {
                var t = this,
                    n = go(),
                    i = n.resolve,
                    r = n.promise,
                    e = function() {
                        t.Vu = null, t.Bu = !1;
                        var n = t.Wu;
                        t.Wu = [], i(n)
                    };
                return this.Bu ? e() : this.Vu = e, r
            }, t.prototype.uploadIfNeeded = function(t, n) {
                return r(this, arguments, void 0, function(t, n, i) {
                    var r, s;
                    return void 0 === i && (i = "unknown"), e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return this.Fu ? (r = n.href, this.je[r] ? [2] : "css" === i && this.C.options.forceLocalResources || function(t, n) {
                                    if (Xh(t)) {
                                        var i = function(t) {
                                            var n, i = null === (n = t.Capacitor) || void 0 === n ? void 0 : n.getServerUrl;
                                            return L(i) ? Au(Eu(t), i()) : void 0
                                        }(t);
                                        if (i) return "blob:" === n.protocol || i.protocol === n.protocol && i.hostname === n.hostname && Yh.test(n.pathname)
                                    }
                                    switch (n.protocol) {
                                        case "blob:":
                                            return !0;
                                        case "http:":
                                        case "https:":
                                            switch (n.hostname) {
                                                case "localhost":
                                                case "127.0.0.1":
                                                case "[::1]":
                                                    return t.location.protocol === n.protocol && t.location.host === n.host;
                                                case "::1":
                                                    var r = n.port ? "[::1]:".concat(n.port) : "[::1]";
                                                    return t.location.protocol === n.protocol && t.location.host === r;
                                                default:
                                                    return !1
                                            }
                                        default:
                                            return !1
                                    }
                                }(t, n) ? (this.je[r] = !0, [4, this.$u(r)]) : [2]) : [2];
                            case 1:
                                return (s = e.sent()) ? (this.Gu(s), [2]) : [2]
                        }
                    })
                })
            }, t.prototype.Gu = function(t) {
                var n = this,
                    i = 0 == this.Wu.length;
                this.Wu.push(t), i && new this.Hu(this.C.wdx, this.C.window, function() {
                    n.Bu = !0, n.Vu && n.Vu()
                }, 50).start()
            }, t.prototype.$u = function(t) {
                return r(this, void 0, void 0, function() {
                    var n, i, r, s, o;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return this.Du[t] ? [2, this.Du[t]] : [4, tf(t)];
                            case 1:
                                return (n = e.sent()) && n.buffer.byteLength ? [4, Gh(this.C.window, this.C.time, n.buffer)] : [2, null];
                            case 2:
                                return i = e.sent(), r = i.hash, s = i.algorithm, o = {
                                    hash: r,
                                    hashAlgorithm: s,
                                    url: t,
                                    blob: n.blob,
                                    contentType: n.contentType
                                }, this.Du[o.url] = o, [2, o]
                        }
                    })
                })
            }, t.prototype.uploadDataUrlIfNeeded = function(t) {
                return r(this, arguments, void 0, function(t, n) {
                    var i;
                    return void 0 === n && (n = function() {
                        return !0
                    }), e(this, function(r) {
                        return i = function(t) {
                            var n, i = "Could not parse data url",
                                r = t.indexOf(",");
                            if (-1 !== r) try {
                                var e = t.substring(0, r).match(nf),
                                    s = void 0,
                                    o = void 0;
                                e && (s = e[1], o = null === (n = e[2]) || void 0 === n ? void 0 : n.substring(1));
                                for (var u = atob(t.substring(r + 1)), a = new ArrayBuffer(u.length), c = new Uint8Array(a), h = 0; h < u.length; ++h) c[h] = u.charCodeAt(h);
                                return {
                                    blob: new Blob([a], {
                                        type: s
                                    }),
                                    buffer: a,
                                    contentType: s,
                                    charset: o
                                }
                            } catch (n) {
                                return void ve(i, {
                                    input: t.substring(0, 100),
                                    err: n
                                }, "warning")
                            } else ve(i, {
                                input: t.substring(0, 100)
                            }, "warning")
                        }(t), i ? [2, this.uploadBlobIfNeeded(i.blob, n)] : [2, void 0]
                    })
                })
            }, t.prototype.uploadBlobIfNeeded = function(t) {
                return r(this, arguments, void 0, function(t, n) {
                    var i, r, s, o, u, a;
                    return void 0 === n && (n = function() {
                        return !0
                    }), e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return [4, Ba(t)];
                            case 1:
                                return (i = e.sent()) ? [4, Gh(this.C.window, this.C.time, i)] : [2, void 0];
                            case 2:
                                return r = e.sent(), s = r.hash, o = r.algorithm, u = "https://".concat("data-url.fs.invalid", "/").concat(o, "/").concat(s), a = {
                                    hash: s,
                                    hashAlgorithm: o,
                                    url: u,
                                    blob: t,
                                    contentType: t.type || "application/octet-stream"
                                }, n(a) ? (this.Du[a.url] = a, this.Gu(a), [2, a]) : [2, a]
                        }
                    })
                })
            }, t
        }();

    function tf(t) {
        var n = go(),
            i = n.resolve,
            r = n.promise,
            e = new XMLHttpRequest;
        return "string" != typeof e.responseType ? (i(null), r) : (e.open("GET", t, !0), e.responseType = "blob", e.onerror = function() {
            i(null)
        }, e.onload = function() {
            if (200 != e.status && 0 !== e.status) return o(function() {
                return "Error loading blob resource ".concat(Ru(t, {
                    source: "log",
                    type: "debug"
                }))
            }), void i(null);
            var n = e.response,
                r = n.size || n.length;
            if (r > Jh) return he("Size of blob resource exceeds limit", {
                url: Ru(t, {
                    source: "log",
                    type: "fsbugs"
                }),
                max: Jh,
                blobSize: r
            }), void i(null);
            Ba(n).then(function(t) {
                i(t ? {
                    buffer: t,
                    blob: n,
                    contentType: n.type
                } : null)
            })
        }, e.send(), r)
    }
    var nf = /^data:([^;,]*)(;?charset=[^;]+)?(?:;base64)?$/i,
        rf = function(t, n, i, r) {
            this.name = "ProtocolError", this.message = n, this.status = t, this.data = i, this.metadata = r
        };

    function ef(t) {
        return t >= 400 && 502 !== t || 202 == t || 206 == t
    }
    var sf = function() {
            function t(t) {
                var n = this;
                this.Qu = 0, this.Xu = !1, this.Ju = t.options.scheme, this.Yu = t.options.recSettingsHost, this.C = t, this.Zu = function(t, n) {
                    return r(this, void 0, void 0, function() {
                        return e(this, function(i) {
                            switch (i.label) {
                                case 0:
                                    return i.trys.push([0, 2, , 3]), [4, Promise.race([$a(), wo(t, n, 500).then(function() {
                                        return !1
                                    })])];
                                case 1:
                                    return [2, i.sent()];
                                case 2:
                                    return i.sent(), [2, !1];
                                case 3:
                                    return [2]
                            }
                        })
                    })
                }(t.wdx, t.window).then(function(t) {
                    n.Xu = t
                })
            }
            return t.prototype.page = function(t) {
                return r(this, void 0, void 0, function() {
                    var n;
                    return e(this, function(i) {
                        switch (i.label) {
                            case 0:
                                return [4, af(this.C, this.Ju, pf(this.C), "/rec/page", {
                                    type: "string",
                                    data: Vr(this.C.wdx, t)
                                }, !0)];
                            case 1:
                                return n = i.sent().text, [2, Z(this.C.wdx, n)]
                        }
                    })
                })
            }, t.prototype.settings = function(t) {
                return r(this, void 0, void 0, function() {
                    var n, i, r;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                if (n = this.C.options.settings) return [2, n];
                                e.label = 1;
                            case 1:
                                return e.trys.push([1, 3, , 4]), i = t.previewMode ? pf(this.C) : this.Yu, [4, df(this.C, this.Ju, i, t)];
                            case 2:
                                return [2, e.sent()];
                            case 3:
                                if (r = e.sent(), t.previewMode) throw r;
                                return [3, 4];
                            case 4:
                                return [2, df(this.C, this.Ju, pf(this.C), t)]
                        }
                    })
                })
            }, t.prototype.bundle = function(t) {
                return r(this, void 0, void 0, function() {
                    var n = this;
                    return e(this, function(i) {
                        return [2, this.ta(t, uf, function(t) {
                            return n.Qu += t
                        })]
                    })
                })
            }, t.prototype.ta = function(t, n, s) {
                return r(this, void 0, void 0, function() {
                    var r, o, u, a, c, v, l, d, p, g, w;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return [4, bo(this.C.wdx, this.C.window)];
                            case 1:
                                return e.sent(), r = t.bundle, (o = r[2]) > 2e6 ? [4, bo(this.C.wdx, this.C.window)] : [3, 3];
                            case 2:
                                e.sent(), e.label = 3;
                            case 3:
                                return this.Xu && t.disableCompression && (this.Xu = !1), u = i({}, t), a = u, [4, this.na(t.bundle)];
                            case 4:
                                return a.bundle = e.sent(), c = u.bundle, v = c[1], h(window, y), l = n(this.C.wdx, u), d = function() {
                                    return {
                                        bytes: o
                                    }
                                }, [4, af(this.C, this.Ju, null !== (w = u.recHost) && void 0 !== w ? w : pf(this.C), l, v, !1, d)];
                            case 5:
                                return p = e.sent().text, g = Z(this.C.wdx, p), f(window, y), [2, [s(o), g]]
                        }
                    })
                })
            }, t.prototype.na = function(t) {
                return r(this, void 0, void 0, function() {
                    var n, i, r, s, o;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return n = t[0], "string" === (i = t[1]).type && this.Xu && this.C.recording.flags().UseCompression ? [4, Va(i.data)] : [3, 2];
                            case 1:
                                if (r = e.sent(), s = r[0], o = r[1], null != s) return [2, [n, {
                                    type: "ArrayBuffer",
                                    data: s,
                                    encoding: qn
                                }, s.byteLength]];
                                this.Xu = !1, he("compression failed", {
                                    err: o
                                }), e.label = 2;
                            case 2:
                                return [2, t]
                        }
                    })
                })
            }, t.prototype.bundleBeacon = function(t) {
                var n;
                return vf(this.C, this.Ju, null !== (n = t.recHost) && void 0 !== n ? n : pf(this.C), t)
            }, t.prototype.startBeacon = function(t) {
                return r(this, void 0, void 0, function() {
                    return e(this, function(n) {
                        return [2, lf(this.C, this.Ju, pf(this.C), t)]
                    })
                })
            }, t
        }(),
        of = function() {
            function t(t) {
                this.Ju = t.options.scheme, this.C = t
            }
            return t.prototype.uploadResource = function(t) {
                return r(this, void 0, void 0, function() {
                    return e(this, function(n) {
                        switch (n.label) {
                            case 0:
                                return [4, af(this.C, this.Ju, pf(this.C), "/rec/uploadResource", t)];
                            case 1:
                                return [2, n.sent().text]
                        }
                    })
                })
            }, t.prototype.queryResources = function(t) {
                return r(this, void 0, void 0, function() {
                    var n;
                    return e(this, function(i) {
                        switch (i.label) {
                            case 0:
                                return [4, af(this.C, this.Ju, pf(this.C), "/rec/queryResources", {
                                    type: "string",
                                    data: Vr(this.C.wdx, t)
                                })];
                            case 1:
                                return n = i.sent().text, [2, Z(this.C.wdx, n)]
                        }
                    })
                })
            }, t
        }();

    function uf(t, n, i) {
        return void 0 === i && (i = ft(t)),
            function(t, n, i) {
                var r = n.bundle,
                    e = r[0],
                    s = r[1],
                    o = "encoding" in s ? s.encoding : Vn,
                    u = "".concat(t, "?OrgId=").concat(n.orgId, "&UserId=").concat(n.userId, "&SessionId=").concat(n.sessionId, "&PageId=").concat(n.pageId, "&Seq=").concat(e, "&ClientTime=").concat(i, "&CompiledVersion=").concat(Jr.Ver);
                return null != n.serverPageStart && (u += "&PageStart=".concat(n.serverPageStart)), null != n.serverBundleTime && (u += "&PrevBundleTime=".concat(n.serverBundleTime)), null != n.lastUserActivity && (u += "&LastActivity=".concat(n.lastUserActivity)), n.isNewSession && (u += "&IsNewSession=true"), null != n.deltaT && (u += "&DeltaT=".concat(n.deltaT)), o === qn && (u += "&ContentEncoding=".concat(qn)), u
            }("/rec/bundle".concat("v2" === n.version ? "/v2" : ""), n, i)
    }

    function af(t, n, i, s, o) {
        return r(this, arguments, void 0, function(t, n, i, r, s, o, u) {
            return void 0 === o && (o = !1), e(this, function(e) {
                return [2, hf(t, "POST", n, i, gf(r), s, o, u)]
            })
        })
    }

    function cf(t, n, i, s) {
        return r(this, void 0, void 0, function() {
            return e(this, function(r) {
                return [2, hf(t, "GET", n, i, gf(s), void 0, !1)]
            })
        })
    }

    function hf(t, n, i, s, o, u, a, c) {
        return r(this, void 0, void 0, function() {
            var r, h, f, v, l, d, p;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        switch (r = t.options.request || ff, h = "//".concat(s).concat(o), f = {}, null == u ? void 0 : u.type) {
                            case "string":
                            case "ArrayBuffer":
                                f["Content-Type"] = Tn.TextPlain
                        }
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, r(i, n, h, a, f, u)];
                    case 2:
                        return v = e.sent(), [3, 4];
                    case 3:
                        throw ve("fsRequest", {
                            err: l = e.sent(),
                            method: n,
                            endpoint: o,
                            isCustom: "".concat(r !== ff)
                        }), l;
                    case 4:
                        if (d = {
                                text: v.responseText
                            }, 200 == v.status) return [2, d];
                        try {
                            p = Z(t.wdx, d.text)
                        } catch (t) {}
                        throw new rf(v.status, d.text, p, null == c ? void 0 : c())
                }
            })
        })
    }

    function ff(t, n, i, s, o, u) {
        return r(this, void 0, void 0, function() {
            var r;
            return e(this, function(e) {
                return r = function(t) {
                    switch (null == t ? void 0 : t.type) {
                        case "string":
                        case "ArrayBuffer":
                            return t.data;
                        case "FormData":
                            var n = new FormData;
                            for (var i in t.data) {
                                var r = t.data[i];
                                if (void 0 !== r)
                                    if ("string" == typeof r) n.append(i, r);
                                    else {
                                        var e = new Blob([r.data], {
                                            type: r.contentType
                                        });
                                        n.append(i, e, r.filename)
                                    }
                            }
                            return n;
                        default:
                            return
                    }
                }(u), [2, new Promise(function(e) {
                    var u = !1,
                        a = new XMLHttpRequest;
                    for (var c in a.onreadystatechange = function() {
                            a.readyState !== T || u || (u = !0, e({
                                status: a.status,
                                responseText: a.responseText
                            }))
                        }, a.open(n, "".concat(t).concat(i), !0), a.withCredentials = s, o) a.setRequestHeader(c, o[c]);
                    a.send(r)
                })]
            })
        })
    }

    function vf(t, n, i, r) {
        var e, s = "".concat(n, "//").concat(i).concat(uf(t.wdx, r), "&SkipResponseBody=true"),
            o = r.bundle[1];
        return Br(null !== (e = t.options.beacon) && void 0 !== e ? e : Wr(t.window), s, o)
    }

    function lf(t, n, i, s) {
        return r(this, void 0, void 0, function() {
            var r, u, a, c, h;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        r = t.window.document.referrer, u = r ? Ru(r, {
                            source: "page",
                            type: "referrer"
                        }) : "", a = "orgId=".concat(s.orgId, "&userId=").concat(s.userId, "&sessionId=").concat(s.sessionId), c = {
                            referrer: u
                        }, e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, af(t, n, i, "/rec/beacon?".concat(a), {
                            type: "string",
                            data: Vr(t.wdx, c)
                        })];
                    case 2:
                        return e.sent(), [3, 4];
                    case 3:
                        return h = e.sent(), o(function() {
                            return "failed to send session start beacon ".concat(h)
                        }), [3, 4];
                    case 4:
                        return [2]
                }
            })
        })
    }

    function df(t, n, i, s) {
        return r(this, void 0, void 0, function() {
            var r, o, u, a;
            return e(this, function(e) {
                switch (e.label) {
                    case 0:
                        return r = null !== (a = s.version) && void 0 !== a ? a : "v1", o = s.previewMode ? "?previewMode=true" : "", [4, cf(t, n, i, "/s/settings/".concat(s.orgId, "/").concat(r, "/web").concat(o))];
                    case 1:
                        return u = e.sent().text, [2, Z(t.wdx, u)]
                }
            })
        })
    }

    function pf(t) {
        var n, i = null === (n = t.recording.pageResponse()) || void 0 === n ? void 0 : n.GCLBSubdomain,
            r = t.options.recHost;
        return i && Mr(r) ? r.replace(/^rs\./, "".concat(i, ".")) : r
    }

    function gf(t) {
        if (!window.Zone) return t;
        var n = "?";
        return t.indexOf(n) > -1 && (n = "&"), "".concat(t).concat(n, "ngsw-bypass=true")
    }
    var wf = function() {
            function t(t, n, i) {
                void 0 === i && (i = new mf(t)), this.C = t, this.ae = n, this.ia = i
            }
            return t.prototype.initialize = function(t) {
                var n;
                if (t) {
                    this.ra(t);
                    var i = null === (n = this.C.window.location) || void 0 === n ? void 0 : n.href;
                    this.onNavigate(i)
                }
            }, t.prototype.onNavigate = function(t) {
                return !!this.ia.matches(t) && (this.ae.enqueue({
                    Kind: 2001,
                    Args: [Ru(t, {
                        source: "page",
                        type: "base"
                    })]
                }), !0)
            }, t.prototype.onClick = function(t) {
                var n;
                return !!(null === (n = null == t ? void 0 : t.watchKind) || void 0 === n ? void 0 : n.has(32)) && (this.ae.enqueue({
                    Kind: 2e3,
                    Args: [t.id]
                }), !0)
            }, t.prototype.urlMatches = function(t) {
                return this.ia.matches(t)
            }, t.prototype.ra = function(t) {
                this.ia.setRules(t)
            }, t
        }(),
        mf = function() {
            function t(t) {
                this.C = t, this.ea = null
            }
            return t.prototype.setRules = function(t) {
                var n = t.map(function(t) {
                    return t.Regex
                }).filter(yf.bind(null, this.C.wdx));
                n.length > 0 && (this.ea = function(t, n) {
                    try {
                        return new RegExp("(".concat(n.join(")|("), ")"), "i")
                    } catch (t) {
                        return ve("keep#joinRegexes", {
                            err: t,
                            regexes: n
                        }), null
                    }
                }(this.C.wdx, n))
            }, t.prototype.matches = function(t) {
                return !!this.ea && this.ea.test(t)
            }, t
        }();

    function yf(t, n) {
        try {
            return new RegExp(n), !0
        } catch (t) {
            return ve("keep#isValidRegex", {
                err: t,
                regex: n
            }), !1
        }
    }

    function bf(t, n, i) {
        if (t && "function" == typeof t[n]) {
            i.get(t) || i.set(t, {});
            var r = t[n];
            t[n] = function() {
                var e = i.get(t);
                return e && "function" == typeof e[n] && e[n].apply(this, arguments), r.apply(this, arguments)
            }
        }
    }
    Fn.RequestFrameId, Fn.EvtBundle, "".concat(bf, "\n(").concat(function(t, n) {
        var i = t._fs_prehooks || new WeakMap;
        t._fs_prehooks = i, n.forEach(function(t) {
            var n = t[0];
            t[1].forEach(function(t) {
                bf(n, t, i)
            })
        })
    }, ")(win, [[\n  CSSStyleSheet.prototype,\n  ['insertRule', 'removeRule']\n]]);");
    var Sf = /[^a-zA-Z0-9.\-_]/g;

    function _f(t, n) {
        return "".concat(t, "_").concat(n)
    }

    function kf(t, n, i, r) {
        var e = function(t, n) {
            return n ? function(t, n) {
                var i = n.replace(Sf, "");
                return 0 === i.length ? t : _f(t, i)
            }(t, i) : t
        };
        return [e(t, r), e(n, r), e(t, !r), e(n, !r)]
    }

    function If(t, n, i, r, e, s) {
        var o = n.getValue(i, r),
            u = o.cookieValue,
            a = o.localStorageValue;
        if (!t && !u && !a) {
            var c = n.getValue(e, s);
            u = c.cookieValue, a = c.localStorageValue
        }
        return [u, a]
    }

    function Af(t) {
        return t.options.useNamespace ? _f(Bn, t.options.namespace) : Bn
    }

    function Ef(t, n, i) {
        if (n && n.postMessage) try {
            n.postMessage(function(t, n) {
                var i;
                return Vr(t.wdx, ((i = {})[Af(t)] = n, i))
            }(t, i), "*")
        } catch (t) {
            he("postMessageTo", {
                err: t
            })
        }
    }

    function Cf(t, n) {
        try {
            var i = Z(t.wdx, n),
                r = Af(t);
            if (r in i) return i[r]
        } catch (t) {}
        return [Fn.Unknown]
    }

    function Tf(t, n, i, r) {
        var e = t.options.transport;
        if (!e) return !1;
        try {
            e.send(n, i, r)
        } catch (t) {
            e.send(n, i)
        }
        return !0
    }

    function Pf(t, n, i) {
        var r = t.options.transport;
        if (!r || !r.sendToChild) return !1;
        var e = i[0],
            s = i.slice(1),
            o = Vr(t.wdx, s);
        return r.sendToChild(n, e, o), !0
    }
    var xf = new RegExp(/^\s+$/),
        Rf = /^fb\d{18}$/,
        Mf = function(t, n) {
            var i = n.appHost,
                r = n.desc,
                e = n.frame,
                s = n.host,
                u = n.namespace,
                a = n.orgId,
                c = n.recHost,
                h = n.recSettingsHost,
                f = n.scheme,
                v = n.script,
                l = n.snippetVersion,
                d = n.underTest,
                p = n.useNamespace;
            o(function() {
                return "Injecting into Frame ".concat(r)
            });
            try {
                if (function(t) {
                        return t.id == t.name && Rf.test(t.id)
                    }(e)) return o(function() {
                    return "Blocklisted iframe: ".concat(r)
                }), 2;
                if (function(t) {
                        return !(t.contentDocument && t.contentWindow && t.contentWindow.location) || function(t) {
                            return !!t.src && "about:blank" != t.src && t.src.indexOf("javascript:") < 0
                        }(t) && t.src != t.contentWindow.location.href && "loading" == t.contentDocument.readyState
                    }(e)) return o(function() {
                    return "Frame not yet loaded: ".concat(r)
                }), 3;
                var g = e.contentWindow,
                    w = e.contentDocument;
                if (!g || !w) return o(function() {
                    return "Missing contentWindow or contentDocument: ".concat(r)
                }), 4;
                if (!w.head) return o(function() {
                    return "Missing contentDocument.head: ".concat(r)
                }), 5;
                if (!w.body || !O(w.body)) return 6;
                for (var m = !1, y = j(w.body); y; y = R(y)) {
                    switch (y.nodeType) {
                        case E:
                            if ("SCRIPT" === y.tagName) continue;
                            break;
                        case 3:
                            var b = y.textContent;
                            if (null === b || xf.test(b)) continue;
                            break;
                        case 8:
                            continue
                    }
                    m = !0;
                    break
                }
                if (!m) return 8;
                if (Oi(g, u)) return o(function() {
                    return "FS already defined in Frame contentWindow: ".concat(r, " Ignoring.")
                }), 7;
                d && (g._fs_org = a);
                var S = function(t, n, i) {
                    return {
                        send: function(r, e, s) {
                            if (void 0 !== n.parent) {
                                var u = Oi(n.parent, i);
                                void 0 !== u && "function" == typeof u._withRecorder ? u._withRecorder(s, function(i) {
                                    try {
                                        i.onMessageReceived(n, [r, t.jsonParse(e), s])
                                    } catch (t) {
                                        t instanceof SyntaxError && ve("rec#onMessageReceived", {
                                            err: t,
                                            msg: r,
                                            signature: s
                                        })
                                    }
                                }) : o(function() {
                                    return "stateless transport: missing FS or _withRecorder api"
                                })
                            } else o(function() {
                                return "stateless transport: missing window.parent"
                            })
                        }
                    }
                }(t, g, u);
                return function(t, n, i) {
                    var r;
                    /^2\./.test(i.snippetVersion) && i.script ? function(t) {
                        var n, i, r, e, s, o, u, a, c = t.orgId,
                            h = t.wnd,
                            f = void 0 === h ? window : h,
                            v = t.host,
                            l = void 0 === v ? "fullstory.com" : v,
                            d = t.namespace,
                            p = void 0 === d ? "FS" : d,
                            g = t.script,
                            w = void 0 === g ? "edge.fullstory.com/s/fs.js" : g;
                        n = f, f.document, i = l, r = w, s = c, (e = p) in n && (n.console && n.console.log && n.console.log("FullStory namespace conflict. Please use a different namespace."), 1) || (o = n[e] = function() {
                            var t = function(t, i, r, e) {
                                e = e || 2;
                                var s, o = /Async$/;
                                return o.test(t) && (t = t.replace(o, ""), "function" == typeof Promise) ? new Promise(function(s, o) {
                                    n(t, i, r, s, o, e)
                                }) : n(t, i, r, s, s, e)
                            };

                            function n(n, i, r, e, s, o) {
                                return t._api ? t._api(n, i, r, e, s, o) : (t.q && t.q.push([n, i, r, e, s, o]), null)
                            }
                            return t.q = [], t
                        }(), function() {
                            function t() {}

                            function n(t, n, i) {
                                o(t, n, i, 1)
                            }

                            function i(t, i, r) {
                                n("setProperties", {
                                    type: t,
                                    properties: i
                                }, r)
                            }

                            function r(t, n) {
                                i("user", t, n)
                            }

                            function e(t, n, i) {
                                r({
                                    uid: t
                                }, i), n && r(n, i)
                            }
                            o.identify = e, o.setUserVars = r, o.identifyAccount = t, o.clearUserCookie = t, o.setVars = i, o.event = function(t, i, r) {
                                n("trackEvent", {
                                    name: t,
                                    properties: i
                                }, r)
                            }, o.anonymize = function() {
                                e(!1)
                            }, o.shutdown = function() {
                                n("shutdown")
                            }, o.restart = function() {
                                n("restart")
                            }, o.log = function(t, i) {
                                n("log", {
                                    level: t,
                                    msg: i
                                })
                            }, o.consent = function(t) {
                                n("setIdentity", {
                                    consent: !arguments.length || t
                                })
                            }
                        }(), u = "fetch", a = "XMLHttpRequest", o._w = {}, o._w[a] = n[a], o._w[u] = n[u], n[u] && (n[u] = function() {
                            return o._w[u].apply(this, arguments)
                        }), o("init", {
                            env: {
                                orgId: s,
                                host: i,
                                script: r
                            }
                        }), o._v = "2.1.0")
                    }({
                        wnd: t,
                        orgId: i.orgId,
                        namespace: i.namespace,
                        host: null !== (r = i.host) && void 0 !== r ? r : "",
                        script: i.script
                    }) : function(t) {
                        var n, i, r, e, s, o = void 0 === t ? {} : t,
                            u = o.wnd,
                            a = void 0 === u ? window : u,
                            c = o.injectedNamespace,
                            h = void 0 === c ? a._fs_namespace : c;
                        n = a, a.document, r = "user", (i = h) in n ? n.console && n.console.log && n.console.log("FullStory namespace conflict. Please set window[\"_fs_namespace\"].") : ((e = n[i] = function(t, n, i) {
                            e.q ? e.q.push([t, n, i]) : e._api(t, n, i)
                        }).q = [], e.identify = function(t, n, i) {
                            e(r, {
                                uid: t
                            }, i), n && e(r, n, i)
                        }, e.setUserVars = function(t, n) {
                            e(r, t, n)
                        }, e.event = function(t, n, i) {
                            e("event", {
                                n: t,
                                p: n
                            }, i)
                        }, e.anonymize = function() {
                            e.identify(!1)
                        }, e.shutdown = function() {
                            e("rec", !1)
                        }, e.restart = function() {
                            e("rec", !0)
                        }, e.log = function(t, n) {
                            e("log", [t, n])
                        }, e.consent = function(t) {
                            e("consent", !arguments.length || t)
                        }, e.identifyAccount = function(t, n) {
                            (n = n || {}).acctId = t, e("account", n)
                        }, e.clearUserCookie = function() {}, e.setVars = function(t, n) {
                            e("setVars", [t, n])
                        }, e._w = {}, s = "XMLHttpRequest", e._w[s] = n[s], s = "fetch", e._w[s] = n[s], n[s] && (n[s] = function() {
                            return e._w[s].apply(this, arguments)
                        }), e._v = "1.3.0")
                    }({
                        wnd: t,
                        injectedNamespace: i.namespace
                    });
                    var e = Ui(t, i.namespace);
                    ae(!!e, "snippet api"), null == e || e("init", {
                        env: {
                            appHost: i.appHost,
                            orgId: i.orgId,
                            recHost: i.recHost,
                            recSettingsHost: i.recSettingsHost,
                            runInIframe: i.runInIframe,
                            scheme: i.scheme,
                            script: i.script,
                            transport: i.transport,
                            useNamespace: i.useNamespace
                        }
                    });
                    var s = n.createElement("script");
                    s.setAttribute(zn, i.namespace), s.async = !0, s.crossOrigin = "anonymous", s.src = "".concat(i.scheme, "//").concat(i.script), "testdrive" === i.orgId && (s.src += "?allowMoo=true"), n.head.appendChild(s)
                }(g, w, {
                    appHost: i,
                    host: s,
                    namespace: u,
                    orgId: a,
                    recHost: c,
                    recSettingsHost: h,
                    runInIframe: !0,
                    scheme: f,
                    script: v,
                    snippetVersion: l,
                    transport: S,
                    useNamespace: p
                }), 1
            } catch (t) {
                return o(function() {
                    return "iFrame not injected. Probably not same origin."
                }), 9
            }
        };

    function Kf(t) {
        var n = "".concat(Ps(t));
        t.id && (n += "#".concat(t.id));
        var i = Ru(t.src, {
            source: "log",
            type: "debug"
        });
        return n + "[src=".concat(i, "]")
    }
    var jf = function() {
            function t(t, n) {
                var i;
                this.C = t, this.St = [], this.pu = !1, this.ut = null !== (i = n.interval) && void 0 !== i ? i : 1e3, this.fu = n.onFlush
            }
            return t.prototype.append = function(t) {
                this.schedule(), this.St.push(t)
            }, t.prototype.flush = function() {
                this.pu = !1, this.fu(this.St), this.St = []
            }, t.prototype.schedule = function() {
                this.pu || (this.C.wdx.setWindowTimeout(this.C.window, I(this.flush.bind(this)), this.ut), this.pu = !0)
            }, t
        }(),
        Of = "https://fs-obfuscated.invalid",
        Uf = function() {
            function t(t, n) {
                this.C = t, this.St = n, this.sa = 0, this.oa = {}, this.Jt = !1
            }
            return t.prototype.enable = function() {
                var t = this;
                this.Jt = !0, this.aa = function(t, n) {
                    var i;
                    try {
                        if ("function" == typeof(null === (i = n.crypto) || void 0 === i ? void 0 : i.getRandomValues)) {
                            var r = "",
                                e = new Uint32Array(2);
                            n.crypto.getRandomValues(e);
                            for (var s = 0; s < e.length; s++) r += e[s].toString(16);
                            return r
                        }
                    } catch (t) {}
                    return t.mathFloor(1e20 * (t.mathRandom() + .1)).toString(16)
                }(this.C.wdx, this.C.window), this.St.enqueue({
                    Kind: 86,
                    Args: [this.aa]
                }), this.ca = new jf(this.C, {
                    interval: 500,
                    onFlush: function(n) {
                        return t.fu(n)
                    }
                })
            }, t.prototype.flush = function() {
                var t;
                null === (t = this.ca) || void 0 === t || t.flush()
            }, t.prototype.fu = function(t) {
                0 !== t.length && this.St.enqueue({
                    Kind: 87,
                    Args: t
                })
            }, t.prototype.record = function(t) {
                var n;
                if (this.Jt && /^(file|http)/i.test(t)) {
                    var i = this.ha(t, !0),
                        r = i[0];
                    i[1] && (null === (n = this.ca) || void 0 === n || n.append([t, r]))
                }
            }, t.prototype.fa = function(t) {
                return this.ha(t, !1)[0]
            }, t.prototype.ha = function(t, n) {
                var i = t.substring(0, 5e3);
                if (void 0 === this.oa[i]) {
                    var r = this.sa++;
                    return this.oa[i] = {
                        id: r,
                        record: n
                    }, [r, n]
                }
                var e = !1;
                return n && (e = !1 === this.oa[i].record, this.oa[i].record = !0), [this.oa[i].id, e]
            }, t.prototype.obfuscateUrl = function(t, n) {
                return this.Jt ? "css" === n ? this.va(t) : this.la(t) : t
            }, t.prototype.va = function(t) {
                ae(void 0 !== this.aa, "_hashObfuscatedUrl#salt");
                var n = Fh(t.substring(0, 5e3) + this.aa);
                return "".concat(Of, "?hash=").concat(n, "&algorithm=fnv32")
            }, t.prototype.la = function(t) {
                var n = this.fa(t);
                return "".concat(Of, "?url-id=").concat(n)
            }, t
        }(),
        Nf = function() {
            function t(t) {
                this.C = t, this.da = !!this.C.options.isWayfinder
            }
            return t.prototype.page = function(t) {
                return r(this, void 0, void 0, function() {
                    return e(this, function(t) {
                        switch (t.label) {
                            case 0:
                                return [4, bo(this.C.wdx, this.C.window)];
                            case 1:
                                return t.sent(), [2, i(i({}, Df(this.da)), {
                                    UserIntId: "0",
                                    SessionIntId: "0",
                                    PageIntId: "0",
                                    CookieDomain: Hf(),
                                    EmbedToken: "",
                                    PageStart: ft(this.C.wdx),
                                    IsNewSession: !0,
                                    Flags: {
                                        AjaxWatcher: !0,
                                        ConsoleWatcher: !0,
                                        DisableImgUrlPrivacy: !0,
                                        GetCurrentSession: !0,
                                        UseClientSideId: !0
                                    }
                                })]
                        }
                    })
                })
            }, t.prototype.settings = function(t) {
                return r(this, void 0, void 0, function() {
                    return e(this, function(t) {
                        switch (t.label) {
                            case 0:
                                return [4, bo(this.C.wdx, this.C.window)];
                            case 1:
                                return t.sent(), [2, Df(this.da)]
                        }
                    })
                })
            }, t.prototype.bundle = function(t) {
                return r(this, void 0, void 0, function() {
                    var n, i, r, s, o, u, a;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                n = ft(this.C.wdx), i = 0, e.label = 1;
                            case 1:
                                return e.trys.push([1, 8, , 9]), [4, bo(this.C.wdx, this.C.window)];
                            case 2:
                                return e.sent(), (r = t.bundle)[0], s = r[1], o = r[2], i = o, "string" === s.type ? [3, 3] : [3, 5];
                            case 3:
                                return [4, Va(s.data)];
                            case 4:
                                return u = e.sent()[0], i = null !== (a = null == u ? void 0 : u.byteLength) && void 0 !== a ? a : 0, [3, 5];
                            case 5:
                                return i > 2e6 ? [4, bo(this.C.wdx, this.C.window)] : [3, 7];
                            case 6:
                                e.sent(), e.label = 7;
                            case 7:
                                return [3, 9];
                            case 8:
                                return e.sent(), [3, 9];
                            case 9:
                                return [2, [i, {
                                    BundleTime: n
                                }]]
                        }
                    })
                })
            }, t.prototype.bundleBeacon = function(t) {
                return !0
            }, t.prototype.startBeacon = function(t) {
                return r(this, void 0, void 0, function() {
                    return e(this, function(t) {
                        return [2, Promise.resolve()]
                    })
                })
            }, t
        }(),
        Lf = function() {
            function t(t) {
                this.C = t
            }
            return t.prototype.uploadResource = function(t) {
                return r(this, void 0, void 0, function() {
                    var t;
                    return e(this, function(n) {
                        switch (n.label) {
                            case 0:
                                return [4, bo(this.C.wdx, this.C.window)];
                            case 1:
                                return n.sent(), t = {
                                    Algorithm: "fsnv",
                                    Hash: ""
                                }, [2, Vr(this.C.wdx, t)]
                        }
                    })
                })
            }, t.prototype.queryResources = function(t) {
                return r(this, void 0, void 0, function() {
                    return e(this, function(t) {
                        switch (t.label) {
                            case 0:
                                return [4, bo(this.C.wdx, this.C.window)];
                            case 1:
                                return t.sent(), [2, []]
                        }
                    })
                })
            }, t
        }(),
        Ff = function() {
            function t() {
                this._cookies = {}
            }
            return t.prototype.setDomain = function(t) {}, t.prototype.getValue = function(t, n) {
                return {
                    cookieValue: this._cookies[t],
                    localStorageValue: void 0
                }
            }, t.prototype.setValue = function(t, n, i, r) {
                this.setCookie(t, n, i)
            }, t.prototype.setCookie = function(t, n, i) {
                this._cookies[t] = n
            }, t.prototype.clearCookie = function(t, n) {
                delete this._cookies[t]
            }, Object.defineProperty(t.prototype, "cookies", {
                get: function() {
                    return this._cookies
                },
                enumerable: !1,
                configurable: !0
            }), t
        }();

    function Hf() {
        try {
            return document.domain
        } catch (t) {}
        return ""
    }

    function Df(t) {
        return {
            AjaxWatches: [],
            ElementBlocks: t ? [] : s(s([], [{
                Selector: "input",
                Consent: !1,
                Type: 2
            }, {
                Selector: "textarea",
                Consent: !1,
                Type: 2
            }, {
                Selector: "select",
                Consent: !1,
                Type: 2
            }, {
                Selector: "[contenteditable]",
                Consent: !1,
                Type: 2
            }, {
                Selector: "input[type=radio]",
                Consent: !1,
                Type: 1
            }, {
                Selector: "input[type=checkbox]",
                Consent: !1,
                Type: 1
            }], !0), Oo, !0),
            ElementDeferreds: [],
            ElementKeeps: [],
            ElementWatches: [],
            OrgSettings: Tn.DefaultOrgSettings,
            UrlKeeps: [],
            DwellTime: 0
        }
    }
    var Bf = "data-fs-integrations",
        Wf = function() {
            function t(t, n, i, r, e, s) {
                var o, u = this;
                this.C = t, this.pa = e, this.ga = Tn.DefaultOrgSettings, this.wa = !1, this.ma = !1, this.yu = null, this.bu = [], this.ya = 5e3, this.ba = Tn.HeartbeatIntervalMS, this.Sa = [], this._a = new Ne, this.ka = [], this.N = new Ve, this.Ia = 1, this.Aa = !1, this.Ea = !1, this.Ca = "none", this.Ta = !1, this.Pa = {}, this.St = new Uh(t, r, i, function() {
                    return u.xa.bundleEvents()
                }, n, void 0, s);
                var a, c = new Zh(t, this.St, (a = t).options.useMockProtocol ? new Lf(a) : new of (a));
                this.Ui = new Uf(t, this.St), this.Cn = new Xo(t.wdx), this._s = new wf(t, this.St), this.xa = new Sh(t, this.St, this._s, this.Cn, this.N.createChild(), function(t) {
                    return u.Bs(t)
                }, function(t) {
                    return u.Ws(t)
                }, c, this.Ui), this.Ra = t.options.host, this.Ju = t.options.scheme, this.Ma = t.options.script, this.Ka = t.options.recHost, this.ja = t.options.recSettingsHost, this.Oa = t.options.appHost, this.Ua = t.options.orgId, this.Ea = null !== (o = t.options.skipIframeInjection) && void 0 !== o && o, this.W = t.window, this.Mt = this.W.document
            }
            return t.prototype.getPageResponse = function() {
                return this.Na
            }, t.prototype.bundleUploadIntervalMS = function() {
                return this.ya
            }, t.prototype.heartbeatIntervalMS = function() {
                return this.ba
            }, t.prototype.setInitConfig = function(t) {
                this.La = t
            }, t.prototype.start = function(t, n, i) {
                var r = this;
                this.Fa = n, this.Ha = i, this.ro();
                var e = this.W.Document ? this.W.Document.prototype : this.W.document;
                this.Da = Be(this.C, e, "close"), this.Da && this.Da.afterAsync(function() {
                    r.N.refresh()
                })
            }, t.prototype.ro = function() {
                var t = this;
                "onpageshow" in this.W && this.N.add(this.W, "pageshow", !1, function(n) {
                    t.St.manualHibernateCheck(), (null == n ? void 0 : n.persisted) && t.St.enqueue({
                        Kind: 110,
                        Args: [2]
                    })
                }), "onpagehide" in this.W ? this.N.add(this.W, "pagehide", !1, function(n) {
                    (null == n ? void 0 : n.persisted) ? (t.St.enqueue({
                        Kind: 110,
                        Args: [1]
                    }), t.St.singSwanSong(7)) : t.Ba()
                }) : this.N.add(this.W, "unload", !1, function() {
                    t.Ba()
                }), this.N.add(this.W, "message", !1, function(n) {
                    var i = n.data;
                    if ("string" == typeof i) {
                        var r = n.source;
                        t.onMessageReceived(r, Cf(t.C, i))
                    }
                })
            }, t.prototype.tellAllFramesTo = function(t) {
                for (var n = 0, i = this.Sa; n < i.length; n++) {
                    var r = i[n];
                    r.contentWindow && Ef(this.C, r.contentWindow, t)
                }
            }, t.prototype.queue = function() {
                return this.St
            }, t.prototype.eventWatcher = function() {
                return this.xa
            }, t.prototype.console = function() {
                return this.xa.consoleWatcher()
            }, t.prototype.orgSettings = function() {
                return this.ga
            }, t.prototype.onDomLoad = function() {
                this.xa.onDomLoad()
            }, t.prototype.onLoad = function() {
                this.xa.onLoad()
            }, t.prototype.shutdown = function(t) {
                var n;
                this.Ta = !0, this.tellAllFramesTo([Fn.ShutdownFrame]), this.Sa = [], this.xa.stop(t), null === (n = this.N) || void 0 === n || n.clearAll(), this._a = new Ne, this.Da && this.Da.disable()
            }, t.prototype.getCurrentSessionURL = function(t) {
                var n = this.Ia;
                if (1 == n) return null;
                if (3 == n) return "".concat(this.Ju, "//").concat(this.Oa, "/opt/upgrade");
                var i = this.getCurrentSession();
                return i ? (t && (i += ":".concat(this.C.time.wallTime())), "".concat(this.Ju, "//").concat(this.Oa, "/ui/").concat(this.C.options.orgId, "/").concat(this.ma ? "client-" : "", "session/").concat(encodeURIComponent(i))) : null
            }, t.prototype.getCurrentSession = function() {
                return this.getIsSessionReady() ? "".concat(this.Wa, ":").concat(this.za) : null
            }, t.prototype.getPageArgs = function() {
                return this.Wa && this.za && this.qa ? {
                    userId: this.Wa,
                    sessionId: this.za,
                    pageId: this.qa,
                    orgId: this.Ua
                } : null
            }, t.prototype.getIsSessionReady = function() {
                var t = this.Ia;
                return !(1 == t || 3 == t || !this.Wa || !this.za)
            }, t.prototype.setConsent = function(t) {
                var n, i = this;
                null === (n = this.C.recording.identity) || void 0 === n || n.getConsentStore().setConsentState(t);
                var r = function() {
                        i.Cn.setConsent(t), i.St.processEvents()
                    },
                    e = function() {
                        i.St.enqueue({
                            Kind: 8196,
                            Args: [t, 1]
                        })
                    };
                switch (t) {
                    case Kt.GrantConsent:
                        e(), r();
                        break;
                    case Kt.RevokeConsent:
                        r(), e()
                }
                this.tellAllFramesTo([Fn.SetConsent, t])
            }, t.prototype.pageSignature = function() {
                return "".concat(this.Wa, ":").concat(this.za, ":").concat(this.qa)
            }, t.prototype.getBundleApiVersion = function() {
                return this.ma ? "v2" : "v1"
            }, t.prototype.Va = function(t) {
                void 0 === t && (t = !1);
                var n = this.C.options.ready;
                if (n) try {
                    t ? n(!0) : n()
                } catch (t) {
                    o(function() {
                        return "exception in _fs_ready(): ".concat(t)
                    })
                }
            }, t.prototype.Ba = function() {
                this.St.addUnload(7), Fs.stopAll(this.C.wdx)
            }, t.prototype.$a = function(t, n) {
                var i, r, e, s, u, a = this,
                    c = t.Flags,
                    h = c.AjaxWatcher,
                    f = c.ClientSideRageClick,
                    v = c.DisableImgUrlPrivacy,
                    l = c.GetCurrentSession,
                    d = c.ResourceUploading,
                    p = c.UseClientSideId;
                this.Na = t, this.Wa = t.UserIntId, this.za = t.SessionIntId, this.qa = t.PageIntId, this.Ga = t.PageStart, this.Ia = l ? 2 : 3, u = {
                    orgId: this.Ua,
                    userId: this.Wa,
                    sessionId: this.za
                }, oe().updateCfg(u), this.ga = t.OrgSettings, this.wa = !0 === t.GSEnabled, Ku(null !== (i = this.ga.UrlPrivacyConfig) && void 0 !== i ? i : Tn.DefaultOrgSettings.UrlPrivacyConfig, this.ga.MaxUrlLength);
                var g = null !== (r = this.ga.AttributeBlocklist) && void 0 !== r ? r : [];
                (null === (s = null === (e = this.La) || void 0 === e ? void 0 : e.privacy) || void 0 === s ? void 0 : s.attributeBlocklist) && (o(function() {
                    var t, n, i, r;
                    return "adding ".concat(null !== (r = null === (i = null === (n = null === (t = a.La) || void 0 === t ? void 0 : t.privacy) || void 0 === n ? void 0 : n.attributeBlocklist) || void 0 === i ? void 0 : i.length) && void 0 !== r ? r : 0, " client defined attribute block rules.")
                }), g.push.apply(g, this.La.privacy.attributeBlocklist.map(Vu))), Wu(g), v || this.Ui.enable(), this.xa.consoleWatcher().initializeMaxLogsPerPage(this.ga.MaxConsoleLogPerPage), this.xa.ajaxWatcher().initialize({
                    requests: this.ga.HttpRequestHeadersAllowlist,
                    responses: this.ga.HttpResponseHeadersAllowlist,
                    maxAjaxPayloadLength: this.ga.MaxAjaxPayloadLength
                }), this.xa.perfWatcher().initialize({
                    resourceUploader: this.xa.getResourceUploader(),
                    recTimings: !!this.ga.RecordPerformanceResourceTiming,
                    recImgs: !!this.ga.RecordPerformanceResourceImg,
                    maxPerfMarksPerPage: this.ga.MaxPerfMarksPerPage
                }), this.Cn.initialize({
                    canvasWatcherMode: t.Flags.CanvasWatcherMode,
                    blocks: t.ElementBlocks,
                    deferreds: t.ElementDeferreds,
                    keeps: t.ElementKeeps,
                    watches: t.ElementWatches,
                    noDefaultExclusions: this.C.options.isWayfinder
                }), this._s.initialize(t.UrlKeeps), this.Cn.initializeConsent(n), "number" == typeof t.BundleUploadIntervalMS && (this.ya = t.BundleUploadIntervalMS), "number" == typeof t.HeartbeatIntervalMS && (this.ba = t.HeartbeatIntervalMS);
                var w = this.C.options.forceLocalResources;
                (d || w) && this.Qa(), h && t.AjaxWatches && this.xa.ajaxWatcher().setWatches(t.AjaxWatches), f && this.St.enableEasyBake(), p && (this.ma = !0), this.xa.start(t.Flags)
            }, t.prototype.Xa = function() {
                var t;
                this.Fa && this.Fa({
                    sessionUrl: null !== (t = this.getCurrentSessionURL()) && void 0 !== t ? t : "",
                    settings: this.ga
                })
            }, t.prototype.Ja = function() {
                this.Ha && this.Ha()
            }, t.prototype.Qa = function() {
                this.Aa = !0, this.xa.initResourceUploading()
            }, t.prototype.Ya = function() {
                if (this.ka.length > 0) {
                    for (var t = 0; t < this.ka.length; t++) this.ka[t]();
                    this.ka = []
                }
            }, t.prototype.Za = function(t) {
                var n = this;
                this.C.measurer.enqueue(function() {
                    var i = "none" !== getComputedStyle(t, null).display;
                    if (o(function() {
                            return "Injecting into a ".concat(i ? "hidden" : "visible", " iframe: ").concat(Kf(t))
                        }), n.pa) {
                        var r = Kf(t),
                            e = n.pa(n.C.wdx, {
                                appHost: n.Oa,
                                desc: r,
                                frame: t,
                                host: n.Ra,
                                namespace: n.C.options.namespace,
                                orgId: n.Ua,
                                recHost: n.Ka,
                                recSettingsHost: n.ja,
                                scheme: n.Ju,
                                script: n.Ma,
                                snippetVersion: n.C.options.snippetVersion,
                                underTest: !!n.C.recording.flags().DisableInertBundles,
                                useNamespace: n.C.options.useNamespace
                            });
                        5 !== e && 6 !== e && 8 !== e || !t.contentDocument || new MutationObserver(function(i, r) {
                            n.Za(t), r.disconnect()
                        }).observe(t.contentDocument, {
                            childList: !0,
                            subtree: !0
                        }), n.St.enqueue({
                            Kind: 88,
                            Args: [Ps(t), r, e]
                        })
                    } else o(function() {
                        return "No injector found for frame ".concat(Kf(t))
                    })
                })
            }, t.prototype.tc = function() {
                var t, n, i, r, e, s = this;
                if (this.La) {
                    var o = null !== (i = null === (n = null === (t = this.La) || void 0 === t ? void 0 : t.privacy) || void 0 === n ? void 0 : n.attributeBlocklist) && void 0 !== i ? i : [],
                        u = null !== (e = null === (r = this.La) || void 0 === r ? void 0 : r.env) && void 0 !== e ? e : {};
                    this.St.enqueue({
                        Kind: 105,
                        Args: ["privacy", ["attributeBlocklist", o.map(function(t) {
                            return [t.target, t.tag, t.name, t.action, t.type]
                        })], "env", Object.keys(u).map(function(t) {
                            var n = u[t];
                            return [t, z(n) ? n : Us(s.C.wdx)(n)]
                        })]
                    })
                }
            }, t.prototype.Bs = function(t) {
                var n = Ps(t);
                if (n) {
                    this.Sa.push(t);
                    var i = Kf(t);
                    this.St.enqueue({
                        Kind: 88,
                        Args: [n, i, 10]
                    });
                    var r = !1;
                    if (t.contentWindow) try {
                        r = !!Oi(t.contentWindow, this.C.options.namespace)
                    } catch (t) {
                        r = !0
                    }
                    var e = function(t) {
                            var n = t.src,
                                i = "".concat(location.protocol, "//").concat(location.host);
                            return !n || "about:blank" == n || q(n, "javascript:") || q(n, i)
                        }(t),
                        s = t.contentWindow && t.contentWindow.postMessage;
                    e && !r || !s ? e ? this.nc(t) : o(function() {
                        return "Frame Doesn't need injecting. Probably cross domain ".concat(Kf(t))
                    }) : this.ic(t, n)
                } else o(function() {
                    return "fsid missing or invalid for iFrame ".concat(Kf(t))
                })
            }, t.prototype.ic = function(t, n) {
                var i = this,
                    r = [Fn.GreetFrame, n];
                t.contentWindow && t.contentWindow.postMessage ? (o(function() {
                    return "Cross-origin iframe ".concat(Kf(t))
                }), Pf(this.C, t, r) || Ef(this.C, t.contentWindow, r), this.Pa[n] = !0, setTimeout(function() {
                    i.Pa[n] && o(function() {
                        return "iframe ".concat(t.src, " is unresponsive")
                    })
                }, 5e3)) : o(function() {
                    return "No content window on init of cross-origin iframe ".concat(Kf(t))
                })
            }, t.prototype.nc = function(t) {
                var n = this;
                if (this.Ea) o(function() {
                    return "skipped same-origin iframe injection for ".concat(Kf(t), " because _fs_skip_iframe_injection is set to true")
                });
                else {
                    o(function() {
                        return "Attempting to setup Frame ".concat(Kf(t))
                    }), this.Za(t);
                    var i = this.N.createChild();
                    i.add(t, "load", !1, fe(function() {
                        o(function() {
                            return "onload for frame ".concat(Kf(t))
                        }), n.Za(t)
                    }, "iframe#loadListener")), this._a.set(t, i)
                }
            }, t.prototype.Ws = function(t) {
                if (Ps(t)) {
                    var n = this._a.get(t);
                    n && (this.N.clearChild(n), this._a["delete"](t)), this.Sa = this.Sa.filter(function(n) {
                        return n !== t
                    })
                }
            }, t.prototype.onMessageReceived = function(t, n) {
                var i = this;
                if (!t || t.parent == this.W) switch (n[0]) {
                    case Fn.EvtBundle:
                        var r = n[1],
                            e = n[2],
                            s = this.pageSignature();
                        if (s !== e) return o(function() {
                            return Us(i.C.wdx)({
                                msg: "Page signature mismatch",
                                pageSignature: s,
                                messageSignature: e
                            }, 1024)
                        }), void(t && Ef(this.C, t, [Fn.ShutdownFrame]));
                        r.length > 0 && this.St.sendEvents(s, r);
                        break;
                    case Fn.RequestFrameId:
                        if (!t) return void o(function() {
                            return "No MessageEvent.source, iframe may have unloaded."
                        });
                        var u = this.rc(t);
                        if (void 0 === u) o(function() {
                            return "No FrameId found. Hoping to send one later."
                        });
                        else {
                            var a = Ps(u);
                            o(function() {
                                return "Responding to FID request for frame ".concat(a)
                            }), this.Pa[a] = !1, this.ec(u, a)
                        }
                        break;
                    case Fn.Unknown:
                        o(function() {
                            return "Received unknown message."
                        })
                }
            }, t.prototype.onNavigate = function() {
                this.eventWatcher().onNavigate()
            }, t.prototype.rc = function(t) {
                for (var n = 0, i = this.Sa; n < i.length; n++) {
                    var r = i[n];
                    if (r.contentWindow === t) return r
                }
            }, t.prototype.ec = function(t, n) {
                var i = this,
                    r = function() {
                        var r, e = [];
                        0 != i.yu && null !== i.yu && (e = i.bu ? i.bu.concat(i.yu) : [i.yu]);
                        var s = i.C.time.startTime(),
                            o = [Fn.SetFrameId, n, e, s, i.Ju, i.Ma, i.Oa, i.Ua, i.La, i.Na, null !== (r = i.Cn.getConsent()) && void 0 !== r ? r : Kt.RevokeConsent, i.C.time.now()];
                        Pf(i.C, t, o) || Ef(i.C, t.contentWindow, o)
                    };
                null == this.yu ? this.ka.push(r) : r()
            }, t.prototype.sc = function() {
                if ("none" !== this.Ca) return !1;
                for (var t = this.C.options.namespace, n = this.Mt.querySelectorAll("script[".concat(Bf, "]")), i = 0; i < n.length; i++)
                    if (n[i].getAttribute(zn) === t) return !0;
                return !1
            }, t.prototype.oc = function(t, n, i) {
                void 0 === i && (i = !1), !t || !i && this.sc() || this.uc(!0), n && n()
            }, t.prototype.ac = function(t) {
                var n, i;
                this.sc() ? t && t() : (null === (i = null === (n = this.Na) || void 0 === n ? void 0 : n.Flags) || void 0 === i ? void 0 : i.FetchIntegrations) ? this.uc(!1, t) : this.oc(this.wa, t, !0)
            }, t.prototype.uc = function(t, n) {
                if ("full" !== this.Ca) {
                    if (t && "none" !== this.Ca) n && n();
                    else {
                        var i, r;
                        i = this.C.window, void 0 !== (r = this.C.options.recSettingsHost) && (i._fs_rec_settings_host = r);
                        var e = this.Mt.createElement("script");
                        e.setAttribute(zn, this.C.options.namespace), e.setAttribute(Bf, ""), n && (e.addEventListener("load", n), e.addEventListener("error", n)), e.async = !0;
                        var s = t ? "&captureDisabled=true" : "";
                        e.src = "".concat(this.Ju, "//").concat(this.Ka, "/rec/integrations?OrgId=").concat(this.Ua, "&isInFrame=").concat(this.C.recording.inFrame, "&isNative=").concat(this.C.recording.inWebView).concat(s), this.Mt.head.appendChild(e), this.Ca = t ? "captureDisabled" : "full"
                    }
                } else n && n()
            }, t.prototype.cc = function(t) {
                var n = this;
                this.C.measurer.enqueue(function() {
                    n.St.enqueue({
                        Kind: 80,
                        Args: [Ps(t.scrollingElement), t.compatMode]
                    })
                })
            }, t
        }();

    function zf(t, n) {
        var i, r, e, s, u, a, c, h, f = (null !== (r = null === (i = n.ElementBlocks) || void 0 === i ? void 0 : i.length) && void 0 !== r ? r : 0) > 0 && (null !== (u = null === (s = null === (e = n.OrgSettings) || void 0 === e ? void 0 : e.UrlPrivacyConfig) || void 0 === s ? void 0 : s.length) && void 0 !== u ? u : 0) > 0 && (null !== (h = null === (c = null === (a = n.OrgSettings) || void 0 === a ? void 0 : a.AttributeBlocklist) || void 0 === c ? void 0 : c.length) && void 0 !== h ? h : 0) > 0;
        if (!f) {
            var v = "Invalid page response";
            ve(v, {
                rsp: n
            }), o(function() {
                return v
            })
        }
        return f
    }
    var qf, Vf, $f = "__request_response_channel_exception__",
        Gf = function(t) {
            function i() {
                return null !== t && t.apply(this, arguments) || this
            }
            return n(i, t), i.prototype.readRequest = function(t) {
                var n = t.ports[0];
                if (!n) throw new Error("No response port when handling request/response message");
                return [t.data, n]
            }, i.prototype.sendRequest = function(t, n, i, r) {
                return void 0 === i && (i = []), new Promise(function(e, o) {
                    if (null == r ? void 0 : r.aborted) o(new Error("Aborted"));
                    else {
                        var u = new MessageChannel,
                            a = u.port1,
                            c = u.port2,
                            h = function() {
                                null == r || r.removeEventListener("abort", h), a.close(), o(new Error("Aborted"))
                            };
                        a.addEventListener("message", function(t) {
                            null == r || r.removeEventListener("abort", h), a.close(), e(t.data)
                        }), a.addEventListener("messageerror", function(t) {
                            null == r || r.removeEventListener("abort", h), a.close(), o(t)
                        }), a.start(), null == r || r.addEventListener("abort", h), t.postMessage(n, s([c], i, !0))
                    }
                })
            }, i.prototype.sendResponse = function(t, n, i) {
                void 0 === i && (i = []), t.postMessage(n, i), t.close()
            }, i
        }(function() {
            function t() {}
            return t.prototype.sendMessage = function(t, n, i, s) {
                return r(this, void 0, void 0, function() {
                    var r, o, u;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return [4, this.sendRequest(t, n, i, s)];
                            case 1:
                                if (function(t) {
                                        return "object" == typeof t && null !== t && $f in t
                                    }(r = e.sent())) throw o = r[$f], u = new Error("Message receiver threw exception: ".concat(o)), r.isCancelAsync && (u.isCancelAsync = !0), u;
                                return [2, r]
                        }
                    })
                })
            }, t.prototype.forwardMessage = function(t, n, i) {
                return r(this, void 0, void 0, function() {
                    var s = this;
                    return e(this, function(o) {
                        return [2, this.handleMessage(t, function(t) {
                            return r(s, void 0, void 0, function() {
                                var r;
                                return e(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return [4, n.sendMessage(i, t)];
                                        case 1:
                                            return r = e.sent(), [2, [t, r]]
                                    }
                                })
                            })
                        })]
                    })
                })
            }, t.prototype.handleMessage = function(t, n) {
                return r(this, void 0, void 0, function() {
                    var r, s, o, u, a, c, h, f, v;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                if (!(r = this.readRequest(t))) return [2];
                                s = r[0], o = r[1], e.label = 1;
                            case 1:
                                return e.trys.push([1, 3, , 4]), [4, n(s)];
                            case 2:
                                return u = e.sent(), a = u[1], c = u[2], this.sendResponse(o, a, c), [3, 4];
                            case 3:
                                throw h = e.sent(), f = "object" == typeof h && null !== h && h.isCancelAsync, this.sendResponse(o, i(((v = {})[$f] = h.toString(), v), f ? {
                                    isCancelAsync: !0
                                } : {})), h;
                            case 4:
                                return [2]
                        }
                    })
                })
            }, t
        }()),
        Qf = Tn.DefaultStatsSettings,
        Xf = Qf.MaxEventTypeLength,
        Jf = Qf.MaxPayloadLength,
        Yf = function(t, n, i) {
            return {
                Kind: 82,
                Args: ["string" == typeof n ? n.trim().slice(0, Xf) : "", Nu(Us(t)(i, Jf))]
            }
        },
        Zf = new Gf;

    function tv(t, n) {
        return Zf.sendMessage(t, {
            action: "ping"
        }, void 0, n)
    }

    function nv(t, n, s, o) {
        return r(this, arguments, void 0, function(t, n, r, s, o) {
            var u, a, c, h, f, v, l, d, p, g, w, m, y, b, S, _, k, A;
            return void 0 === o && (o = tv), e(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (a = function(t, n, r, e) {
                                return function(s, o) {
                                    var u, a, c = i(i(i(i({
                                        reason: String(s),
                                        blocked: 1 !== s,
                                        workerUrl: e,
                                        ua: null !== (a = null === (u = r.navigator) || void 0 === u ? void 0 : u.userAgent) && void 0 !== a ? a : ""
                                    }, void 0 !== (null == o ? void 0 : o.loadMs) && {
                                        loadMs: String(o.loadMs)
                                    }), void 0 !== (null == o ? void 0 : o.pingPongMs) && {
                                        pingPongMs: String(o.pingPongMs)
                                    }), void 0 !== (null == o ? void 0 : o.errorMessage) && {
                                        errorMessage: o.errorMessage
                                    }), void 0 !== (null == o ? void 0 : o.filename) && {
                                        filename: o.filename
                                    });
                                    n.enqueue(Yf(t, "WORKER_FEASIBILITY", {
                                        provider_id: "webworker",
                                        event_status: 1 === s ? "SUCCESS" : "FAILURE",
                                        metadata: c
                                    }))
                                }
                            }(t, n, u = r, s), void 0 === (c = u.Worker)) return a(7), [2];
                        v = t.dateNow();
                        try {
                            l = "importScripts(".concat(t.jsonStringify(s), ")"), d = new u.Blob([l], {
                                type: "application/javascript"
                            }), f = u.URL.createObjectURL(d), h = new c(f)
                        } catch (t) {
                            return f && u.URL.revokeObjectURL(f), a(2, {
                                errorMessage: t instanceof Error ? t.message : String(t)
                            }), [2]
                        }
                        p = t.dateNow() - v, g = I(function() {
                            h.onerror = null, h.onmessageerror = null, h.terminate(), f && u.URL.revokeObjectURL(f)
                        }), m = new Promise(function(t, n) {
                            w = n
                        }), h.onerror = function(t) {
                            t.preventDefault(), y = {
                                errorMessage: t.message || "(no message \u2014 likely CSP)",
                                filename: t.filename || ""
                            }, w(new Error("onerror"))
                        }, h.onmessageerror = function() {
                            w(new Error("onmessageerror"))
                        }, b = "function" == typeof AbortController ? new AbortController : void 0, S = t.dateNow(), e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, 4, 5]), [4, mo(t, r, [o(h, null == b ? void 0 : b.signal), m], 5e3)];
                    case 2:
                        return e.sent(), _ = t.dateNow() - S, g(), a(1, {
                            loadMs: p,
                            pingPongMs: _
                        }), [3, 5];
                    case 3:
                        return k = e.sent(), A = k instanceof Error ? k.message : String(k), g(), a(function(t) {
                            switch (t) {
                                case "timeout":
                                    return 5;
                                case "onerror":
                                    return 3;
                                case "onmessageerror":
                                    return 4;
                                default:
                                    return 6
                            }
                        }(A), i({
                            loadMs: p,
                            errorMessage: A
                        }, y)), [3, 5];
                    case 4:
                        return null == b || b.abort(), [7];
                    case 5:
                        return [2]
                }
            })
        })
    }(Vf = qf || (qf = {})).START = "start", Vf.SHUTDOWN = "shutdown", Vf.INTERNAL_BUNDLE = "internal/bundle", Vf.INTERNAL_ERROR = "internal/error", Vf.INTERNAL_FS_INIT = "internal/fs-init", Vf.INTERNAL_USER = "internal/user";
    var iv = [qf.START, qf.SHUTDOWN, qf.INTERNAL_BUNDLE, qf.INTERNAL_ERROR, qf.INTERNAL_FS_INIT, qf.INTERNAL_USER];

    function rv(t, n) {
        var i = n.Seq,
            r = Us(t)(n);
        return [i, {
            data: r,
            type: "string"
        }, r.length]
    }

    function ev(t, n, i, r) {
        var e;
        return new Promise(function(s) {
            var o = la(ba, function(u) {
                for (var a = 0, c = u; a < c.length; a++) c[a].entryType === ba && (e ? (e.stop(), e.start()) : (e = new i(t, n, function() {
                    null == o || o.disconnect(), s()
                }, 1e3).start(), null == r || r(e)))
            });
            ! function(t, n, i, r, e, u) {
                var a = new e(t, n, function() {
                    null == o || o.disconnect(), s()
                }, 4e3).start();
                null == u || u(a)
            }(t, n, 0, 0, i, r)
        })
    }
    var sv = function() {
        function t(t, n, i) {
            this.C = t, this.hc = n, this.fc = i, this.vc = {
                stored: 0,
                inStorage: 0,
                currentSize: 0,
                totalSize: 0,
                key: n,
                nextSeq: 1
            }
        }
        return t.prototype.store = function(t, n) {
            return this.lc(t, n)
        }, t.prototype.retrieve = function(t) {
            var n = void 0 === t ? {} : t,
                i = n.validate,
                r = n.keyMeta,
                e = function(t, n, i) {
                    var r = [];
                    try {
                        for (var e = uv(n, i)[0], s = 0, o = e; s < o.length; s++) {
                            var u = o[s],
                                a = localStorage.getItem(u);
                            if (a) {
                                localStorage.removeItem(u);
                                var c = ov(t, a);
                                c && r.push(c)
                            }
                        }
                    } catch (t) {}
                    return r
                }(this.C.wdx, this.hc, r);
            return i ? e.filter(i) : e
        }, t.prototype.lc = function(t, n) {
            try {
                var r = function(t, n) {
                        var i = uv(t, n),
                            r = i[0],
                            e = i[1],
                            s = r.length ? cv(r[r.length - 1]) + 1 : 1;
                        return [s, hv(t, s, n), r.length, e]
                    }(this.hc, n),
                    e = r[0],
                    s = r[1],
                    o = r[2],
                    u = r[3],
                    a = Vr(this.C.wdx, t),
                    c = a.length;
                return !this.dc(c + u) && (this.vc.stored++, this.vc.inStorage = o + 1, this.vc.nextSeq = e, this.vc.currentSize = c, this.vc.totalSize += c, localStorage.setItem(s, a), !0)
            } catch (t) {
                return function(t, n) {
                    return !! function(t) {
                        return t instanceof DOMException && (22 === t.code || 1014 === t.code || "QuotaExceededError" === t.name || "NS_ERROR_DOM_QUOTA_REACHED" === t.name)
                    }(t) && n.inStorage > 2
                }(t, this.vc) && he("Quota Exceeded", i(i({}, this.vc), {
                    message: rh(t),
                    err: t
                })), !1
            }
        }, t.prototype.dc = function(t) {
            var n;
            return (null !== (n = this.fc) && void 0 !== n ? n : t) < t
        }, t
    }();

    function ov(t, n) {
        try {
            return Z(t, n)
        } catch (t) {
            return
        }
    }

    function uv(t, n) {
        var i, r = [],
            e = 0,
            s = "^".concat(t, ":\\d+$");
        n && (s = "^".concat(t, ":").concat(n, ":\\d+$"));
        var o = new RegExp(s);
        try {
            for (var u = 0; u < localStorage.length; u++) {
                var a = null !== (i = localStorage.key(u)) && void 0 !== i ? i : "";
                o.test(a) && (r.push(a), e += av(a))
            }
        } catch (t) {}
        return [r.sort(function(t, n) {
            return cv(t) - cv(n)
        }), e]
    }

    function av(t) {
        var n, i;
        try {
            return null !== (i = null === (n = localStorage.getItem(t)) || void 0 === n ? void 0 : n.length) && void 0 !== i ? i : 0
        } catch (t) {
            return 0
        }
    }

    function cv(t) {
        var n;
        return null !== (n = F(t.slice(t.lastIndexOf(":") + 1))) && void 0 !== n ? n : 0
    }

    function hv(t, n, i) {
        return i ? "".concat(t, ":").concat(i, ":").concat(n) : "".concat(t, ":").concat(n)
    }

    function fv(t, n, i, s, u, a) {
        void 0 === s && (s = Ds), void 0 === a && (a = 5e3);
        var c = 0,
            h = !1;
        return {
            cancel: function() {
                h = !0
            },
            promise: function f() {
                return r(this, void 0, void 0, function() {
                    var r, v;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                if (h) return [2];
                                e.label = 1;
                            case 1:
                                return e.trys.push([1, 3, , 4]), r = 0, [4, i()];
                            case 2:
                                return r === e.sent() ? [2] : [3, 4];
                            case 3:
                                return v = e.sent(), o(function() {
                                    return "retryWithBackoff caught error: ".concat(v)
                                }), [3, 4];
                            case 4:
                                return h ? [2] : (o(function() {
                                    return "retryWithBackoff retrying ".concat(c + 1)
                                }), [4, lv(t, n, vv(t, c++, a), s, u)]);
                            case 5:
                                return e.sent(), [2, f()]
                        }
                    })
                })
            }()
        }
    }

    function vv(t, n, i) {
        void 0 === i && (i = 5e3);
        var r = t.mathMin(Tn.BackoffMax, t.mathPow(2, n) * i);
        return r + .25 * t.mathRandom() * r
    }

    function lv(t, n, i, r, e) {
        return new Promise(function(s) {
            var o = new r(t, n, function() {
                return s()
            }, i).start();
            null == e || e(o)
        })
    }

    function dv(t, n, i, s) {
        return r(this, arguments, void 0, function(t, n, i, s, u, a) {
            var c, h, f, v, l, d, p = this;
            return void 0 === u && (u = Ds), e(this, function(g) {
                switch (g.label) {
                    case 0:
                        if (!U(t, s) || 0 === s.length) return [2];
                        h = !1, f = function(t) {
                            return r(p, void 0, void 0, function() {
                                var n, r, s, u, a, f;
                                return e(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return e.trys.push([0, 2, , 3]), n = t.bundle, r = n[0], s = n[2], o(function() {
                                                return "Sending ".concat(s, " trailing bytes from last session as Seq ").concat(r)
                                            }), void 0 !== c && (t.serverBundleTime = c), [4, i.bundle(t)];
                                        case 1:
                                            return u = e.sent(), a = u[1], c = a.BundleTime, o(function() {
                                                return "Successfully sent events"
                                            }), [2, 0];
                                        case 2:
                                            return (v = f = e.sent()) instanceof rf && ef(v.status) ? (o(function() {
                                                return "Fatal error while sending events, giving up"
                                            }), h = !0, [2, 0]) : (Xh(window) && 205 === (null == f ? void 0 : f.status) && (t.disableCompression = !0), [3, 3]);
                                        case 3:
                                            return o(function() {
                                                return "Failed to send events, will retry while on this page"
                                            }), [2, 1]
                                    }
                                    var v
                                })
                            })
                        }, v = 0, l = s, g.label = 1;
                    case 1:
                        return v < l.length ? (d = l[v], !h && d && d.bundle ? [4, fv(t, n, f.bind(null, d), u, a).promise] : [2]) : [3, 4];
                    case 2:
                        g.sent(), g.label = 3;
                    case 3:
                        return v++, [3, 1];
                    case 4:
                        return [2]
                }
            })
        })
    }
    var pv = function() {
        function t(t, n, i) {
            void 0 === i && (i = Ds);
            var r = this;
            this.C = t, this.Lu = n, this.gc = i, this.wc = t.options.multiStorage || new sv(this.C, "_fs_songs", 2e6), this.mc = new this.gc(this.C.wdx, this.C.window, function() {
                r.sing()
            }, 2e3), this.yc()
        }
        return t.prototype.yc = function() {
            return r(this, void 0, void 0, function() {
                var t, n = this;
                return e(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return t = function(t) {
                                n.bc = t
                            }, [4, ev(this.C.wdx, this.C.window, this.gc, t)];
                        case 1:
                            return i.sent(), this.sing(), [2]
                    }
                })
            })
        }, t.prototype.store = function(t, n) {
            if (!this.C.options.useMockProtocol) {
                o(function() {
                    return "Saving ".concat(t.bundles.length, " bundles in swan-song.")
                });
                for (var i = 0, r = t.bundles; i < r.length; i++) {
                    var e = r[i];
                    if ("string" !== e[1].type) return void he("song#arrayBuilder", {
                        bundleType: e[1].type
                    })
                }
                var s = {
                    Bundles: t.bundles,
                    IsNewSession: t.isNewSession,
                    LastBundleTime: t.lastBundleTime,
                    OrgId: t.orgId,
                    PageId: t.pageId,
                    PageStartTime: this.C.time.startTime(),
                    RecHost: pf(this.C),
                    ServerBundleTime: t.serverBundleTime,
                    ServerPageStart: t.serverPageStart,
                    SessionId: t.sessionId,
                    UserId: t.userId,
                    Version: t.version
                };
                this.wc.store(s), this.mc.isRunning() || this.mc.start()
            }
        }, t.prototype.stop = function() {
            this.mc.stop()
        }, t.prototype.sing = function() {
            return r(this, void 0, void 0, function() {
                return e(this, function(t) {
                    switch (t.label) {
                        case 0:
                            return this.C.options.useMockProtocol ? [2] : [4, this.Sc(this.wc.retrieve())];
                        case 1:
                            return t.sent(), [4, this._c(gv(this.C.wdx, "_fs_song"))];
                        case 2:
                            return t.sent(), [4, this._c(gv(this.C.wdx, "_fs_swan_song"))];
                        case 3:
                            return t.sent(), [2]
                    }
                })
            })
        }, t.prototype.Sc = function(t) {
            return r(this, void 0, void 0, function() {
                var n, i;
                return e(this, function(r) {
                    switch (r.label) {
                        case 0:
                            if (!t.length) return [2];
                            n = t.length - 1, r.label = 1;
                        case 1:
                            return n >= 0 ? (i = t[n], [4, this._c(i)]) : [3, 4];
                        case 2:
                            r.sent(), r.label = 3;
                        case 3:
                            return n--, [3, 1];
                        case 4:
                            return [2]
                    }
                })
            })
        }, t.prototype._c = function(t) {
            return r(this, void 0, void 0, function() {
                var n, i, r = this;
                return e(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return e.trys.push([0, 2, , 3]), void 0 !== t && t.Bundles && t.UserId && t.SessionId && t.PageId ? (o(function() {
                                return "Sending ".concat(t.Bundles.length, " bundles as prior page swan song")
                            }), n = t.Bundles.reduce(function(n, i, e) {
                                var s = e === t.Bundles.length - 1;
                                return n.push({
                                    bundle: i,
                                    isNewSession: t.IsNewSession,
                                    orgId: t.OrgId,
                                    pageId: t.PageId,
                                    recHost: t.RecHost,
                                    serverBundleTime: t.ServerBundleTime,
                                    serverPageStart: t.ServerPageStart,
                                    sessionId: t.SessionId,
                                    userId: t.UserId,
                                    version: t.Version,
                                    deltaT: s ? r.C.time.wallTime() - (t.LastBundleTime || 0) : null
                                }), n
                            }, []), [4, dv(this.C.wdx, this.C.window, this.Lu, n, this.gc, function(t) {
                                r.kc = t
                            })]) : (o(function() {
                                return "Malformed swan song found. Ignoring it."
                            }), [2]);
                        case 1:
                            return e.sent(), [3, 3];
                        case 2:
                            return i = e.sent(), o(function() {
                                return "Error recovering swan-song: ".concat(i)
                            }), [3, 3];
                        case 3:
                            return [2]
                    }
                })
            })
        }, t
    }();

    function gv(t, n) {
        try {
            if (n in localStorage) {
                var i = localStorage[n];
                return delete localStorage[n],
                    function(t, n) {
                        return n.Bundles = function(t, n) {
                            for (var i = [], r = 0, e = n.Bundles; r < e.length; r++) {
                                var s = e[r];
                                U(t, s) ? i.push(s) : i.push(rv(t, s))
                            }
                            return i
                        }(t, n), n
                    }(t, Z(t, i))
            }
        } catch (t) {
            o(function() {
                return "Error purging swan-song: ".concat(t)
            })
        }
    }
    var wv, mv = function() {
            function t() {}
            return t.prototype.encode = function(t) {
                return t
            }, t
        }(),
        yv = function() {
            function t(t) {
                void 0 === t && (t = 1e4), this.dict = {
                    idx: -1,
                    map: {}
                }, this.nodeCount = 1, this.startIdx = 0, this.maxNodes = t
            }
            return t.prototype.encode = function(t) {
                if (0 == t.length) return [];
                var n, i, r = t[0],
                    e = Object.prototype.hasOwnProperty.call(this.dict.map, r) ? this.dict.map[r] : void 0,
                    s = [],
                    o = 1;

                function u() {
                    e ? o > 1 ? s.push([e.idx, o]) : s.push(e.idx) : s.push(r)
                }
                for (n = 1; n < t.length; n++)
                    if (i = t[n], e && Object.prototype.hasOwnProperty.call(e.map, i)) o++, r = i, e = e.map[i];
                    else {
                        u();
                        var a = this.startIdx + n - o;
                        null == e && this.nodeCount < this.maxNodes && (e = {
                            idx: a,
                            map: {}
                        }, this.dict.map[r] = e, this.nodeCount++), e && this.nodeCount < this.maxNodes && (e.map[i] = {
                            idx: a,
                            map: {}
                        }, this.nodeCount++), o = 1, r = i, e = Object.prototype.hasOwnProperty.call(this.dict.map, i) ? this.dict.map[i] : void 0
                    }
                return u(), this.startIdx += t.length, s
            }, t
        }(),
        bv = function() {
            function t(t) {
                this.Ic = t, this.Ac = 0
            }
            return t.newBudget = function(n) {
                return void 0 === n && (n = 256e3), new t(n)
            }, t.prototype.add = function(t) {
                this.Ac += t
            }, t.prototype.isOver = function() {
                return this.Ac > this.Ic
            }, t.prototype.reset = function() {
                this.Ac = 0
            }, t
        }(),
        Sv = ((wv = {})[63] = !0, wv[57] = !0, wv[67] = !0, wv[115] = !0, wv),
        _v = function() {
            function t(t, n) {
                void 0 === n && (n = bv.newBudget(t.options.networkBudget)), this.C = t, this.Ec = n, this.St = new Io, this.Cc = 1, this.Tc = {}, this.Pc = !1, this.xc = [], this.Rc = !0, this.init()
            }
            return t.prototype.init = function() {
                if (1 === this.Cc) {
                    var t, n = !!this.C.recording.flags().UseCompression && "CompressionStream" in (t = this.C.window) && "TextEncoderStream" in t;
                    this.Rc = !!this.C.recording.flags().UseLZEncoding || !n
                }
            }, t.prototype.size = function() {
                return this.St.size()
            }, t.prototype.add = function(t) {
                var n = !0;
                switch (t.Kind) {
                    case 25:
                    case 2:
                    case 68:
                    case 114:
                        n = !1
                }
                Sv[t.Kind] || (this.Pc = !0), this.St.push([t, n ? Qr(this.C.wdx, t) : void 0])
            }, t.prototype.nextBundle = function(n) {
                if (0 !== this.St.size()) return n.flush || t.forceFlush || this.Pc ? this.Mc(n) : void 0
            }, t.prototype.addEndMarkerEvent = function(t) {
                this.xc.push(t)
            }, t.prototype.persistEndMarkerEventsTo = function(t) {
                for (var n = 0, i = this.xc; n < i.length; n++) {
                    var r = i[n];
                    t.addEndMarkerEvent(r)
                }
            }, t.prototype.Mc = function(t) {
                var n = this.Kc(t);
                if (n) {
                    0 === this.St.size() && (this.Pc = !1);
                    var i = n[0],
                        r = n[1];
                    return function(t, n, i) {
                        var r = "{\"Seq\":".concat(t, ",\"When\":").concat(n, ",\"Evts\":[").concat(i, "]}");
                        return [t, {
                            type: "string",
                            data: r
                        }, r.length]
                    }(this.Cc++, i, r)
                }
            }, t.prototype.Kc = function(t) {
                ae(this.St.size() > 0, "builder#_serializeEvents"), this.Ec.reset();
                var n, i, r = this.St.first()[0],
                    e = Av(r),
                    s = this.jc(t),
                    o = s[0],
                    u = s[1];
                if (this.Oc = (n = u, i = this.Oc, n ? i ? Av(n) >= Av(i) ? n : i : n : i), !this.Uc(t)) return this.Nc(o, this.Oc), this.Oc = void 0, [e, kv(o)];
                this.St.unshift([r, kv(o)])
            }, t.prototype.jc = function(t) {
                for (var n, r = [], e = [], o = this.St.shift(); o; o = this.St.shift()) {
                    var u = o[0],
                        a = o[1];
                    if (n = u, void 0 === a) {
                        var c = ua(this.C.wdx, [u])[0];
                        if (this.Rc) {
                            var h = this.Lc(c),
                                f = h[0],
                                v = h[1];
                            a = Qr(this.C.wdx, f), e.push.apply(e, v)
                        } else {
                            var l = ft(this.C.wdx);
                            a = Qr(this.C.wdx, c), e.push(ft(this.C.wdx) - l)
                        }
                    }
                    if (r.push(a), this.Ec.add(a.length), !t.flush && this.Ec.isOver()) break
                }
                return n && function(t, n, r, e) {
                    r.length <= 0 || n.push(function(t, n, r) {
                        var e = r[0],
                            o = r.slice(1);
                        return Qr(t, i(i({}, Ev(n)), {
                            Kind: 78,
                            Args: [s([0, 1, 3, Av(n), e], o.map(function(t) {
                                return [3, t]
                            }), !0)]
                        }))
                    }(t, e, r))
                }(this.C.wdx, r, e, n), [r, n]
            }, t.prototype.Uc = function(t) {
                return !(!this.C.recording.flags().UseMinNetworkBudget || t.bypassMinBudget || t.flush || this.Ec.isOver())
            }, t.prototype.Nc = function(t, n) {
                ae(!!n, "builder#_finalizeQueue"), n && function(t, n, r, e) {
                    ae(r.length > 0, "builder#addMarkers");
                    for (var s = 0, o = r; s < o.length; s++) {
                        var u = o[s];
                        n.push(Qr(t, i(i({}, Ev(e)), u)))
                    }
                }(this.C.wdx, t, this.xc, n)
            }, t.prototype.Lc = function(t) {
                var n = [];
                switch (t.Kind) {
                    case 25:
                        var i = et(t.PIds, t.FId);
                        delete this.Tc[i];
                        break;
                    case 2:
                        var r = ft(this.C.wdx);
                        t.Args[2] = this.Fc(t.PIds, t.FId, t.Args[2]), n.push(ft(this.C.wdx) - r);
                        break;
                    case 68:
                        r = ft(this.C.wdx), t.Args[1] = this.Fc(t.PIds, t.FId, t.Args[1]), n.push(ft(this.C.wdx) - r)
                }
                return [t, n]
            }, t.prototype.Fc = function(t, n, i) {
                void 0 === t && (t = []), void 0 === n && (n = 0);
                var r = et(t, n);
                return this.Tc[r] || (this.Tc[r] = this.Rc ? new yv : new mv), this.Tc[r].encode(i)
            }, t.forceFlush = !1, t
        }();

    function kv(t) {
        return t.join(",")
    }

    function Iv(t, n, i) {
        var r = new _v(t, i);
        return n && n.persistEndMarkerEventsTo(r), r
    }

    function Av(t) {
        var n = t.When;
        return "number" == typeof n ? n : 0
    }

    function Ev(t) {
        return {
            When: Av(t),
            FId: t.FId,
            PIds: t.PIds
        }
    }
    var Cv = function() {
            function t(t, n) {
                var i;
                this.C = t, this.Lu = n, this.Hc = !1, this.Dc = 0, this.Bc = !1, this.Wc = !1, this.zc = t.time.now(), this.wc = new sv(t, "_fs_bundle"), ae(!!this.C.recording.identity, "dwell#identity"), this.qc = null === (i = this.C.recording.identity) || void 0 === i ? void 0 : i.getClientStore()
            }
            return t.prototype.init = function(t) {
                var n, i, r, e, s;
                this.Vc = t;
                var o = null !== (n = t.minDwellTime) && void 0 !== n ? n : 0;
                if (this.Dc = 1e3 * this.C.wdx.mathMin(o, 10), this.zc = this.C.time.now(), this.Dc && this.Lu.startBeacon({
                        orgId: (null === (i = this.Vc) || void 0 === i ? void 0 : i.orgId) || "",
                        userId: (null === (r = this.Vc) || void 0 === r ? void 0 : r.userId) || "",
                        sessionId: (null === (e = this.Vc) || void 0 === e ? void 0 : e.sessionId) || ""
                    }), t.isNewSession || 0 === this.Dc) return [];
                var u = this.retrieve(t, !0);
                return null === (s = this.qc) || void 0 === s || s.setValue(Si, t.sessionId, ""), u
            }, t.prototype.store = function(t) {
                return this.wc.store(t, t.orgId) ? (this.Hc = !0, !0) : (this.Bc = !0, !1)
            }, t.prototype.retrieve = function(t, n) {
                var i = this;
                void 0 === n && (n = !1);
                var r = this.wc.retrieve({
                    keyMeta: t.orgId,
                    validate: function(t) {
                        return i.$c(t, n)
                    }
                });
                return this.Hc = !1, r
            }, t.prototype.$c = function(t, n) {
                void 0 === n && (n = !1);
                try {
                    if (t && this.Vc && this.Vc.orgId === t.orgId && this.Vc.userId === t.userId && this.Vc.sessionId === t.sessionId && (n || this.Vc.pageId === t.pageId)) return !0
                } catch (t) {}
                return !1
            }, t.prototype.getState = function() {
                return this.Gc() ? this.Hc ? 3 : 1 : 2
            }, t.prototype.Gc = function() {
                var t, n;
                if (this.Wc || !(null === (t = this.Vc) || void 0 === t ? void 0 : t.isNewSession) || 0 === this.Dc || this.Bc) return !0;
                if (this.C.time.now() - this.zc > this.Dc) return !0;
                var i = null === (n = this.qc) || void 0 === n ? void 0 : n.getValue(Si);
                return ((null == i ? void 0 : i.cookieValue) || (null == i ? void 0 : i.localStorageValue)) === this.Vc.sessionId && (this.Wc = !0, !0)
            }, t
        }(),
        Tv = function() {
            function t(t, n, i, r, e, s, o, u) {
                void 0 === r && (r = Hs), void 0 === e && (e = Ds), void 0 === s && (s = new Cv(t, n)), this.C = t, this.Lu = n, this.Qo = i, this.mu = r, this.gc = e, this.Qc = s, this.Xc = o, this.Jc = u, this.Yc = !1, this.Zc = 0, this.th = 0, this.nh = 0, this.ih = !1, this.rh = 0, this.eh = [], this.sh = ft(t.wdx), this.Ju = t.options.scheme, this.oh = t.time.wallTime(), this.uh = new pv(t, this.Lu, e), this.ah = Iv(this.C)
            }
            return t.prototype.addEndMarkerEvent = function(t) {
                this.ah.addEndMarkerEvent(t)
            }, t.prototype.scheme = function() {
                return this.Ju
            }, t.prototype.enqueueEvents = function(t, n) {
                for (var i = 0, r = n; i < r.length; i++) {
                    var e = r[i];
                    this.ah.add(e)
                }
            }, t.prototype.ya = function() {
                return this.C.recording.bundleUploadIntervalMS()
            }, t.prototype.initUploadTicker = function() {
                this.sh = ft(this.C.wdx), this.hh = new this.mu(this.C.wdx, this.C.window, this.ya())
            }, t.prototype.startPipeline = function(t) {
                var n, i = this;
                this.Ua = t.orgId, this.Wa = t.userId, this.za = t.sessionId, this.qa = t.pageId, this.Ga = t.serverPageStart, this.ih = t.isNewSession, this.ah.init(), this.fh(this.Qc.init(t), this.gc), wo(this.C.wdx, this.C.window, this.ya() / 2).then(function() {
                    i.C.recording.flags().UseMinNetworkBudget && i.lh({
                        bypassMinBudget: !0
                    }), i.dh()
                }), this.hh || this.initUploadTicker(), null === (n = this.hh) || void 0 === n || n.start(function() {
                    i.C.recording.flags().UseMinNetworkBudget && ft(i.C.wdx) - i.sh >= 2e4 && (i.sh = ft(i.C.wdx), i.lh({
                        bypassMinBudget: !0
                    })), i.dh()
                })
            }, t.prototype.stopPipeline = function() {
                this.hh && this.hh.stop(), this.ah = Iv(this.C, this.ah), this.eh = [], this.uh.stop(), this.Ua = void 0, this.Wa = void 0, this.za = void 0, this.qa = void 0, this.Ga = void 0, this.ih = !1
            }, t.prototype.send = function(t) {
                return r(this, void 0, void 0, function() {
                    var n, i, r, s;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                switch (n = null !== (r = null == t ? void 0 : t.mode) && void 0 !== r ? r : "flush", i = null !== (s = null == t ? void 0 : t.reason) && void 0 !== s ? s : 0, n) {
                                    case "flush":
                                        return [3, 1];
                                    case "sing":
                                        return [3, 3]
                                }
                                return [3, 4];
                            case 1:
                                return this.lh({
                                    flush: !0
                                }), [4, this.ph()];
                            case 2:
                                return e.sent(), [3, 5];
                            case 3:
                                return this.gh(i), [3, 5];
                            case 4:
                                Ho(), e.label = 5;
                            case 5:
                                return [2]
                        }
                    })
                })
            }, t.prototype.gh = function(t) {
                if (this.lh({
                        flush: !0
                    }), this.wh(this.mh)) ae(!this.mh, "_pendingBundle in dwell period");
                else {
                    var n = [];
                    this.mh && n.push(this.mh);
                    for (var r = 0, e = this.eh; r < e.length; r++) {
                        var s = e[r];
                        n.push(s)
                    }
                    var o = this.yh(n);
                    if (o) {
                        this.uh.store(o, t);
                        for (var u = 0, a = n; u < a.length && (s = a[u], this.Lu.bundleBeacon(i(i({}, o), {
                                bundle: s,
                                deltaT: null
                            }))); u++);
                    }
                }
            }, t.prototype.yh = function(t) {
                var n = this;
                if (t.length) {
                    if (this.Ua && this.Wa && this.za && this.qa && void 0 !== this.Ga) return {
                        bundles: t,
                        isNewSession: this.ih,
                        lastBundleTime: this.oh,
                        orgId: this.Ua,
                        pageId: this.qa,
                        serverBundleTime: this.rh,
                        serverPageStart: this.Ga,
                        sessionId: this.za,
                        userId: this.Wa,
                        version: this.C.recording.bundleApiVersion()
                    };
                    o(function() {
                        return "unable to build stored bundle. one or more of orgId:".concat(n.Ua, " | userId:").concat(n.Wa, " | sessionId:").concat(n.za, " | pageId:").concat(n.qa, " | serverPageStart:").concat(n.Ga, " are undefined")
                    })
                }
            }, t.prototype.bh = function() {
                var t;
                if (this.Ua && this.Wa && this.za) {
                    for (var n = [], i = 0, r = this.Qc.retrieve({
                            orgId: this.Ua
                        }); i < r.length; i++) {
                        var e = r[i];
                        n.push.apply(n, e.bundles)
                    }(t = this.eh).unshift.apply(t, n)
                }
            }, t.prototype.wh = function(t) {
                switch (this.Qc.getState()) {
                    case 2:
                        var n = t ? s([t], this.eh, !0) : this.eh,
                            i = this.yh(n);
                        if (!i) return !1;
                        var r = this.Qc.store(i);
                        return r ? this.eh = [] : this.bh(), r;
                    case 3:
                        return this.bh(), !1;
                    default:
                        return !1
                }
            }, t.prototype.dh = function() {
                return r(this, void 0, void 0, function() {
                    return e(this, function(t) {
                        switch (t.label) {
                            case 0:
                                return this.mh ? (this.Yc && this.Sh(), [2]) : this.Jc ? [4, this.Jc.nextIdleTime()] : [3, 2];
                            case 1:
                                t.sent(), t.label = 2;
                            case 2:
                                return this.lh(), [4, this.ph()];
                            case 3:
                                return t.sent(), [2]
                        }
                    })
                })
            }, t.prototype.lh = function(t) {
                void 0 === t && (t = {});
                var n = this.ah.nextBundle(t);
                n && this.eh.push(n)
            }, t.prototype.ph = function() {
                return r(this, void 0, void 0, function() {
                    return e(this, function(t) {
                        switch (t.label) {
                            case 0:
                                return this.qa && this.Ga && !this.mh && 0 != this.eh.length ? this.wh() ? [2] : (this.mh = this.eh.shift(), [4, this.Sh()]) : [2];
                            case 1:
                                return t.sent(), [2]
                        }
                    })
                })
            }, t.prototype.Sh = function() {
                return r(this, void 0, void 0, function() {
                    var t, n, r, s, u, a;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                if ((t = this.C.time.wallTime()) < this.th) return [2];
                                if (!(n = this.mh)) return [2];
                                this.Yc = !1, this.nh = this.oh = t, e.label = 1;
                            case 1:
                                return e.trys.push([1, 5, , 6]), [4, this._h(n)];
                            case 2:
                                return (r = e.sent()) ? (this.rh = r.BundleTime, this.mh = void 0, this.th = 0, this.Zc = 0, this.C.time.wallTime() - this.nh > this.ya() ? [4, this.ph()] : [3, 4]) : [2];
                            case 3:
                                e.sent(), e.label = 4;
                            case 4:
                                return [3, 6];
                            case 5:
                                if (s = e.sent(), u = "Failed to send bundle", s instanceof rf) {
                                    if (o(function() {
                                            return "Failed to send events."
                                        }), ef(s.status)) return 206 === s.status ? o(function() {
                                        return "Failed to send bundle, probably because of its large size"
                                    }) : s.status >= 500 && ve(u, i({
                                        err: s,
                                        status: s.status
                                    }, s.metadata)), null === (a = this.Xc) || void 0 === a || a.call(this), [2]
                                } else ve(u, {
                                    err: s,
                                    status: 0
                                });
                                return this.Yc = !0, this.th = this.nh + vv(this.C.wdx, this.Zc++), [3, 6];
                            case 6:
                                return [2]
                        }
                    })
                })
            }, t.prototype._h = function(t) {
                return r(this, void 0, void 0, function() {
                    var n, i, r, s, u, a, c = this;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return this.Ua && this.Wa && this.za && this.qa ? (h(window, b), n = this.Qo.getMsSinceLastUserActivity(), [4, this.Lu.bundle({
                                    bundle: t,
                                    deltaT: null,
                                    isNewSession: this.ih,
                                    lastUserActivity: n,
                                    orgId: this.Ua,
                                    pageId: this.qa,
                                    serverBundleTime: this.rh,
                                    serverPageStart: this.Ga,
                                    sessionId: this.za,
                                    userId: this.Wa,
                                    version: this.C.recording.bundleApiVersion()
                                })]) : (o(function() {
                                    return "unable to send bundle. one or more of orgId:".concat(c.Ua, " | userId:").concat(c.Wa, " | sessionId:").concat(c.za, " | pageId:").concat(c.qa, " are undefined")
                                }), [2]);
                            case 1:
                                return i = e.sent(), r = i[0], s = i[1], null === (a = this.C.recording.observer) || void 0 === a || a.addEvent({
                                    type: qf.INTERNAL_BUNDLE,
                                    data: {
                                        clientTime: ft(this.C.wdx),
                                        lastActivity: n,
                                        orgId: this.Ua,
                                        pageId: this.qa,
                                        pageStart: this.Ga,
                                        prevBundleTime: this.rh,
                                        recHost: pf(this.C),
                                        response: s,
                                        seq: t[0],
                                        sessionId: this.za,
                                        size: r,
                                        userId: this.Wa
                                    }
                                }), u = t[0], r > 16e6 && u >= 16 && (o(function() {
                                    return "splitting large page: ".concat(r)
                                }), this.C.recording.splitPage(6)), f(window, b), [2, s]
                        }
                    })
                })
            }, t.prototype.fh = function(t, n) {
                return r(this, void 0, void 0, function() {
                    var i, r = this;
                    return e(this, function(e) {
                        return 0 === t.length ? [2] : (i = t.reduce(function(t, n, i) {
                            return t.push.apply(t, n.bundles.map(function(t) {
                                return {
                                    bundle: t,
                                    isNewSession: n.isNewSession,
                                    orgId: r.Ua,
                                    userId: r.Wa,
                                    sessionId: r.za,
                                    pageId: n.pageId,
                                    version: n.version,
                                    serverBundleTime: n.serverBundleTime,
                                    serverPageStart: n.serverPageStart,
                                    deltaT: null
                                }
                            })), t
                        }, []), [2, dv(this.C.wdx, this.C.window, this.Lu, i, n)])
                    })
                })
            }, t
        }(),
        Pv = "_fs_preview",
        xv = new RegExp("(^\\?|&)".concat(Pv, "=(?:true|false)(&|$)")),
        Rv = function() {
            function t(t, n, i) {
                this.C = t, this.qc = i, this.kh = "fs_preview_".concat(n)
            }
            return t.prototype.isPreviewMode = function() {
                return this.Ih() || this.Ah()
            }, t.prototype.clear = function() {
                this.qc.setValue(this.kh, "", new Date(1970, 1, 1).toUTCString())
            }, t.prototype.write = function() {
                var t = this.Ih(),
                    n = this.Eh();
                (t || n) && (t ? this.qc.setValue(this.kh, "true", new Date(ft(this.C.wdx) + 432e5).toUTCString()) : this.clear(), this.Ch())
            }, t.prototype.inject = function(t, n, i) {
                Lr(function() {
                    var r = "FullStory-preview-script";
                    if (!t.getElementById(r)) {
                        var e = t.createElement("script");
                        e.id = r, e.async = !0, e.src = "".concat(n, "//").concat(i, "/s/fspreview.js"), t.head.appendChild(e)
                    }
                })
            }, t.prototype.Ch = function() {
                if (this.C.window.history) {
                    var t = location.search.replace(xv, function(t, n, i) {
                        return i ? n : ""
                    });
                    this.C.window.history.replaceState({}, "", this.C.window.location.href.replace(location.search, t))
                }
            }, t.prototype.Ih = function() {
                return this.C.window.document.location.search.indexOf("".concat(Pv, "=true")) > -1
            }, t.prototype.Eh = function() {
                return this.C.window.document.location.search.indexOf("".concat(Pv, "=false")) > -1
            }, t.prototype.Ah = function() {
                var t = this.qc.getValue(this.kh),
                    n = t.cookieValue,
                    i = t.localStorageValue;
                return !(!n && !i)
            }, t
        }();

    function Mv(t) {
        var n, i, r;
        return {
            Kind: 98,
            Args: [t.type, t.entrypoint, "dom", null === (i = null === (n = t.source) || void 0 === n ? void 0 : n.integration) || void 0 === i ? void 0 : i.slice(0, 1024), !!(null === (r = t.source) || void 0 === r ? void 0 : r.userInitiated)]
        }
    }

    function Kv(t) {
        var n = function(t) {
            return "msCrypto" in t ? t.msCrypto : t.crypto
        }(t);
        if ("function" == typeof(null == n ? void 0 : n.randomUUID)) return n.randomUUID();
        var i = new Uint8Array(16);
        n.getRandomValues(i), i[6] = 15 & i[6] | 64, i[8] = 63 & i[8] | 128;
        for (var r = [], e = 0; e < i.length; e++) r.push(function(t, n, i) {
            for (var r = t; r.length < 2;) r = "".concat("0").concat(r);
            return r
        }(i[e].toString(16)));
        return ["".concat(r[0]).concat(r[1]).concat(r[2]).concat(r[3]), "".concat(r[4]).concat(r[5]), "".concat(r[6]).concat(r[7]), "".concat(r[8]).concat(r[9]), "".concat(r[10]).concat(r[11]).concat(r[12]).concat(r[13]).concat(r[14]).concat(r[15])].join("-")
    }
    var jv = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

    function Ov(t) {
        return 36 === t.length && jv.test(t)
    }
    var Uv, Nv, Lv = void 0,
        Fv = 864e5,
        Hv = 18e5,
        Dv = function() {
            function t(t, n, i, r) {
                void 0 === r && (r = Ds), this.C = t, this.Qo = n, this.Th = i, this.Ph = 0, this.xh = new r(this.C.wdx, this.C.window, this.Rh.bind(this))
            }
            return t.prototype.createUserSessionPage = function() {
                return e = function(t, n) {
                    var i, r, e, s = n.getUserId();
                    if (!s || !Ov(s)) return [Lv, "uid ".concat(s)];
                    var o = n.getSessionId();
                    if (!o || !Ov(o)) return [Lv, "sid ".concat(o)];
                    var u = t.time.wallTime(),
                        a = null !== (i = n.getSessionStartTimeMS()) && void 0 !== i ? i : 0,
                        c = t.wdx.mathAbs(u - a);
                    if (0 === a || c >= Fv) return [Lv, "exp sid: ".concat(a, "ms ").concat(c, "ms")];
                    var h = null !== (r = n.getLastUserActivityTimeMS()) && void 0 !== r ? r : a,
                        f = t.wdx.mathMax(h, a),
                        v = t.wdx.mathAbs(u - f);
                    if (v >= Hv) return [Lv, "exp lua: ".concat(h, "ms ").concat(v, "ms")];
                    var l = null !== (e = n.getPageCount()) && void 0 !== e ? e : 0;
                    return l >= 250 ? [Lv, "pages: ".concat(l)] : [o]
                }(t = this.C, n = this.Th), s = e[0], o = e[1], u = s === Lv, a = t.time.wallTime(), c = Kv(t.window), h = n.getSessionId(), f = n.getUserId(), v = (null !== (i = n.getPageCount()) && void 0 !== i ? i : 0) + 1, l = null !== (r = n.getSessionStartTimeMS()) && void 0 !== r ? r : a, u && (h = Kv(t.window), f = function(t, n) {
                    var i = n.getUserId();
                    return i && Ov(i) ? i : Kv(t.window)
                }(t, n), v = 1, l = a), {
                    userId: f,
                    sessionId: h,
                    pageId: c,
                    isNewSession: u,
                    lastActivityTime: a,
                    pageCount: v,
                    reason: o,
                    sessionStartTime: l
                };
                var t, n, i, r, e, s, o, u, a, c, h, f, v, l
            }, t.prototype.persist = function(t) {
                this.Th.create({
                    userId: t.userId,
                    sessionId: t.sessionId,
                    sessionStartTime: t.sessionStartTime,
                    lastUserActivityTime: t.lastActivityTime,
                    pageCount: t.pageCount
                })
            }, t.prototype.start = function() {
                this.xh.start(3e5)
            }, t.prototype.stop = function() {
                this.xh.stop()
            }, t.prototype.Rh = function() {
                var t = this.Qo.getLastUserActivityTS();
                t !== this.Ph && (this.Ph = t, this.Th.setLastUserActivityTimeMS(t)), this.start()
            }, t
        }();
    (Nv = Uv || (Uv = {})).TrackEvent = "trackEvent", Nv.GetSession = "getSession", Nv.Init = "init", Nv.Log = "log", Nv.Source = "source", Nv.Observe = "observe", Nv.Restart = "restart", Nv.SetIdentity = "setIdentity", Nv.SetConfig = "setConfig", Nv.SetPage = "setPage", Nv.SetProperties = "setProperties", Nv.Shutdown = "shutdown", Nv.Start = "start", Nv.Stat = "stat", Nv.GetFullstoryId = "getFullstoryId", Nv.GetConfig = "getConfig";
    var Bv = function(t) {
            function s(n, i, r, e, s, o, u, a) {
                void 0 === e && (e = Hs), void 0 === u && (u = new Tv(n, i, r, e, void 0, void 0, function() {
                    return h.shutdown(5)
                }, s)), void 0 === a && (a = Lr(function() {
                    return Mf
                }));
                var c, h = t.call(this, n, e, r, u, a, s) || this;
                h.Lu = i, h.Mh = o, h.gu = u, h.Kh = !1, h._u = !1, h.jh = !1, h.Mt = h.W.document, h.yu = 0, h.Oh = n.recording.identity, h.Uh = new Rv(h.C, h.Ua, h.Oh.getClientStore()), h.Ia = 1, h.Nh = new Dv(n, r, h.Oh), c = function(t) {
                    if (h.xa.stop(1), t) {
                        var n = h.Mt.getElementById(t);
                        n && h.Lh && n.setAttribute("_fs_embed_token", h.Lh)
                    }
                }, h.W._fs_shutdown = c;
                var f = h.Uh.isPreviewMode();
                return h.Fh = h.Lu.settings({
                    orgId: h.Ua,
                    previewMode: f
                })["catch"](function() {}), h
            }
            return n(s, t), s.prototype.onDomLoad = function() {
                t.prototype.onDomLoad.call(this), this.Kh = !0, this.Hh()
            }, s.prototype.Dh = function() {
                var t = this.C.options.replayFlags;
                if (/[?&]_fs_force_session=true(&|#|$)/.test(location.search) && (t = "".concat(t, ",forceSession"), this.W.history)) {
                    var n = location.search.replace(/(^\?|&)_fs_force_session=true(&|$)/, function(t, n, i) {
                        return i ? n : ""
                    });
                    this.W.history.replaceState({}, "", this.W.location.href.replace(location.search, n))
                }
                return t
            }, s.prototype.start = function(n, i, s) {
                return r(this, void 0, void 0, function() {
                    var r, u, a, c, v, l, d, p, w, m, y, b, S, _, k, I, A, E, C, T, P, x, R, M, K, j, O, U, N, L, F, H, D, B, W, z, q, V, $, G, Q;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return t.prototype.start.call(this, n, i, s), [4, this.Fh];
                            case 1:
                                if (!(r = e.sent())) return o(function() {
                                    return "missing static settings"
                                }), this.Bh(), [2];
                                u = !0 === r.GSEnabled, Ku(null !== (z = r.OrgSettings.UrlPrivacyConfig) && void 0 !== z ? z : Tn.DefaultOrgSettings.UrlPrivacyConfig, r.OrgSettings.MaxUrlLength), a = this.Dh(), e.label = 2;
                            case 2:
                                return e.trys.push([2, 4, , 5]), [4, Promise.race([ko(this.C.wdx, this.C.window), wo(this.C.wdx, this.C.window, 250)])];
                            case 3:
                            case 4:
                                return e.sent(), [3, 5];
                            case 5:
                                c = es(this.Mt), v = c[0], l = c[1], X = this.C.window, J = 0, Z = 0, d = null == X.screen ? [J, Z] : (J = parseInt(String(X.screen.width), 10), Z = parseInt(String(X.screen.height), 10), [J = isNaN(J) ? 0 : J, Z = isNaN(Z) ? 0 : Z]), p = d[0], w = d[1], m = this.Nh.createUserSessionPage(), y = this.Oh.finalizeSessionUidForPageStart(m.isNewSession, this.C.options.sessionUid), b = y.activeSessionUid, S = y.discardedSessionUid, _ = "", n || (_ = this.Oh.getUserId()), k = this.Oh.getAppId(), I = this.Oh.getAppKeyHash(), A = this.Uh.isPreviewMode(), E = null !== ($ = null === (V = null === (q = this.C) || void 0 === q ? void 0 : q.recording) || void 0 === V ? void 0 : V.preroll) && void 0 !== $ ? $ : -1, C = Ru(Eu(this.W), {
                                    source: "page",
                                    type: "base"
                                }), T = Ru(this.W.location.href, {
                                    source: "page",
                                    type: "url"
                                }), P = "" === this.Mt.referrer ? "" : Ru(this.Mt.referrer, {
                                    source: "page",
                                    type: "referrer"
                                }), x = Y(this.Mt), R = null !== (G = this.C.options.tabId) && void 0 !== G ? G : function(t) {
                                    var n, i = "_fs_tab_id";
                                    try {
                                        var r = t.sessionStorage.getItem(i);
                                        if (r) return r;
                                        var e = Math.floor(1e17 * Math.random()).toString(16);
                                        return t.sessionStorage.setItem(i, e), null !== (n = t.sessionStorage.getItem(i)) && void 0 !== n ? n : void 0
                                    } catch (t) {
                                        return
                                    }
                                }(this.W), M = {
                                    OrgId: this.Ua,
                                    UserId: _,
                                    SessionId: m.sessionId,
                                    PageId: m.pageId,
                                    Url: T,
                                    Base: C,
                                    Width: v,
                                    Height: l,
                                    SessionUid: b,
                                    ScreenWidth: p,
                                    ScreenHeight: w,
                                    SnippetVersion: this.C.options.snippetVersion,
                                    Referrer: P,
                                    Preroll: E,
                                    Doctype: x,
                                    CompiledVersion: Jr.Ver,
                                    CompiledTimestamp: Jr.TS,
                                    AppId: k,
                                    TabId: R,
                                    PreviewMode: A || void 0,
                                    SessionKeyHash: "",
                                    PageKeyHash: ""
                                }, a && (M.ReplayFlags = a), e.label = 6;
                            case 6:
                                return e.trys.push([6, 12, , 13]), [4, this.Lu.page(M)];
                            case 7:
                                return K = e.sent(), A || !K.PreviewMode ? [3, 9] : [4, this.Lu.settings({
                                    orgId: this.Ua,
                                    previewMode: !0
                                })["catch"](function() {})];
                            case 8:
                                if (!(r = e.sent())) return o(function() {
                                    return "missing static settings"
                                }), this.Bh(u), [2];
                                Ku(null !== (Q = r.OrgSettings.UrlPrivacyConfig) && void 0 !== Q ? Q : Tn.DefaultOrgSettings.UrlPrivacyConfig, r.OrgSettings.MaxUrlLength), e.label = 9;
                            case 9:
                                return [4, this.Wh(m, K, r)];
                            case 10:
                                if (W = e.sent(), !zf(this.C.wdx, W)) return [2, this.Bh(u)];
                                if (this.Ta) return [2];
                                if (this.Oh.setCookieDomain(this.W, W.CookieDomain), h(window, g), j = this.Oh.getConsentStore().getConsentState(), this.$a(W, j), f(window, g), this.zh(W.CookieDomain, W.UserIntId, W.SessionIntId, W.PageIntId, W.EmbedToken), this.qh(), W.PreviewMode && this.Uh.inject(this.Mt, this.Ju, this.Oa), (O = this.C.options.pageStart) && O(), this.St.enqueueFirst(Mv({
                                        type: "default"
                                    })), this.St.enqueueFirst(this.xa.getNavigateEvent(this.W.location.href, 81)), this.St.enqueueFirst({
                                        Kind: 8198,
                                        Args: [j, 1]
                                    }), this.St.enqueueFirst({
                                        Kind: 25,
                                        Args: [Ru(Eu(this.W), {
                                            source: "event",
                                            type: 25
                                        }), x, T, P]
                                    }), S && this.St.enqueue({
                                        Kind: 119,
                                        Args: [S]
                                    }), U = {
                                        Kind: 99,
                                        Args: [T, C, v, l, p, w, this.C.options.snippetVersion, P, x, E, _, W.PageStart, it(this.C.wdx, this.C.window), this.W.navigator.userAgent, R, !!W.IsNewSession, !!W.PreviewMode, k, I, Jr.TS, Jr.Ver, "", "", b]
                                    }, this.gu.addEndMarkerEvent(U), W.Flags.DisableInertBundles && (_v.forceFlush = !0), this.St.enqueue({
                                        Kind: 89,
                                        Args: [Jr.Ver]
                                    }), this.St.enqueue({
                                        Kind: 19,
                                        Args: [v, l]
                                    }), b && this.Mh)
                                    for (N = {
                                            operation: Uv.SetProperties,
                                            option: {
                                                type: Zt.Session,
                                                properties: {
                                                    uid: b
                                                }
                                            },
                                            apiVersion: 2
                                        }, L = this.Mh.api(N).events, F = 0, H = L; F < H.length; F++) D = H[F], this.St.enqueue(D);
                                return this.xa.addVisibilityChangeEvent(), this.tc(), [4, this.St.startPipeline({
                                    isNewSession: !!W.IsNewSession,
                                    orgId: this.Ua,
                                    pageId: W.PageIntId,
                                    serverPageStart: W.PageStart,
                                    sessionId: W.SessionIntId,
                                    userId: W.UserIntId,
                                    minDwellTime: W.Flags.UseDwellTime && W.DwellTime || 0,
                                    fixWhenValues: W.Flags.FixWhenValues
                                })];
                            case 11:
                                return e.sent(), this.cc(this.Mt), this.Vh(W.Flags), this.Xa(), [3, 13];
                            case 12:
                                return (B = e.sent()) instanceof rf && (W = B.data) && W.user_id && W.cookie_domain && 8 === W.reason_code && _ !== W.user_id && this.zh(W.cookie_domain, W.user_id, "", "", ""), this.Bh(u), [3, 13];
                            case 13:
                                return [2]
                        }
                        var X, J, Z
                    })
                })
            }, s.prototype.Vh = function(t) {
                return r(this, void 0, void 0, function() {
                    var n;
                    return e(this, function(i) {
                        switch (i.label) {
                            case 0:
                                if (r = this.C.options.useWebWorker, e = t.UseWebWorker, s = this.C.wdx.mathRandom(), !(void 0 !== r ? r : e && s < .1)) return [2];
                                i.label = 1;
                            case 1:
                                return i.trys.push([1, 3, , 4]), n = "".concat(this.Ju, "//").concat(this.ja, "/s/").concat("fs-worker.".concat("8f13c2d7", ".js")), [4, nv(this.C.wdx, this.St, this.W, n)];
                            case 2:
                            case 3:
                                return i.sent(), [3, 4];
                            case 4:
                                return [2]
                        }
                        var r, e, s
                    })
                })
            }, s.prototype.qh = function() {
                this.jh = !0, this.Hh()
            }, s.prototype.Hh = function() {
                var t = this;
                this.Kh && this.jh && this.ac(function() {
                    t.Va(t._u)
                })
            }, s.prototype.zh = function(t, n, i, r, e) {
                var s = this.Oh;
                s.setIds(this.W, t, n, i), this.Lh = e, this.Uh.write(), o(function() {
                    return "/User,".concat(s.getUserId(), "/Session,").concat(s.getSessionId(), "/Page,").concat(r)
                })
            }, s.prototype.Bh = function(t) {
                void 0 === t && (t = !1), this.Ja(), this.shutdown(5), o(function() {
                    return "Disabling FS."
                }), this._u = !0, this.oc(t), this.Va(this._u)
            }, s.prototype.Wh = function(t, n, s) {
                return r(this, void 0, void 0, function() {
                    var r, o, u, a, c, h, f;
                    return e(this, function(e) {
                        return (r = i(i({}, n), s)).Flags.UseClientSideId && (Ov(o = null !== (c = r.UserUUID) && void 0 !== c ? c : "") && (t.userId = o), Ov(u = null !== (h = r.SessionUUID) && void 0 !== h ? h : "") && (t.sessionId = u), Ov(a = null !== (f = r.PageUUID) && void 0 !== f ? f : "") && (t.pageId = a), this.Oh.setCookieDomain(this.W, r.CookieDomain), this.Nh.persist(t), r = i(i({}, r), {
                            UserIntId: t.userId,
                            SessionIntId: t.sessionId,
                            PageIntId: t.pageId,
                            IsNewSession: t.isNewSession,
                            PageStart: ft(this.C.wdx)
                        }), t.reason && this.St.enqueue({
                            Kind: 111,
                            Args: [t.reason]
                        })), this.Nh.start(), [2, r]
                    })
                })
            }, s.prototype.onMessageReceived = function(n, i) {
                t.prototype.onMessageReceived.call(this, n, i), (null == n ? void 0 : n.parent) == this.W && i[0] === Fn.EndPreviewMode && this.Uh.clear()
            }, s.prototype.onNavigate = function() {
                this.eventWatcher().onNavigate()
            }, s
        }(Wf),
        Wv = function() {
            function t(t, n) {
                void 0 === n && (n = new zv(t)), this.C = t, this.$h = n
            }
            return t.prototype.enqueueEvents = function(t, n) {
                var i = null != t ? t : void 0;
                this.$h.postMessage(this.C.window.parent, [Fn.EvtBundle, ua(this.C.wdx, n), i], i)
            }, t.prototype.startPipeline = function() {}, t.prototype.stopPipeline = function() {}, t.prototype.addEndMarkerEvent = function(t) {}, t
        }(),
        zv = function() {
            function t(t) {
                this.C = t
            }
            return t.prototype.postMessage = function(t, n, i) {
                switch (n[0]) {
                    case Fn.EvtBundle:
                        Tf(this.C, n[0], Vr(this.C.wdx, n[1]), i) || Ef(this.C, t, n);
                        break;
                    case Fn.RequestFrameId:
                        Tf(this.C, n[0], "[]", i) || Ef(this.C, t, n);
                        break;
                    default:
                        o(function() {
                            return "Unknown message type: ".concat(n[0])
                        })
                }
            }, t
        }(),
        qv = function(t) {
            function i(n, i, r, e, s) {
                void 0 === i && (i = new zv(n)), void 0 === r && (r = new Wv(n, i)), void 0 === e && (e = Hs), void 0 === s && (s = Lr(function() {
                    return Mf
                }));
                var o = t.call(this, n, e, void 0, r, s, void 0) || this;
                return o.$h = i, o.Mt = o.W.document, o
            }
            return n(i, t), i.prototype.ac = function(n) {
                var i, r;
                this.C.recording.inWebView && (null === (r = null === (i = this.Na) || void 0 === i ? void 0 : i.Flags) || void 0 === r ? void 0 : r.FetchChildIntegrations) ? t.prototype.ac.call(this, n) : this.oc(this.wa, n)
            }, i.prototype.start = function(n, i, r) {
                var e = this;
                t.prototype.start.call(this, n, i, r), this.Gh(), this.N.add(this.W, "load", !1, function() {
                    e.xa.recordingIsDetached() && (o(function() {
                        return "Recording wrong document. Restarting recording in iframe."
                    }), e.C.recording.splitPage(2))
                }), this.xa.addVisibilityChangeEvent()
            }, i.prototype.onMessageReceived = function(n, i) {
                return r(this, void 0, void 0, function() {
                    var r, s, u, a, c, h, f, v, l = this;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                if (t.prototype.onMessageReceived.call(this, n, i), n !== this.W.parent && n !== this.W) return [2];
                                switch (i[0]) {
                                    case Fn.GreetFrame:
                                        return [3, 1];
                                    case Fn.SetFrameId:
                                        return [3, 2];
                                    case Fn.SetConsent:
                                        return [3, 3];
                                    case Fn.InitFrameMobile:
                                        return [3, 4]
                                }
                                return [3, 7];
                            case 1:
                                return this.Gh(i[1]), [3, 7];
                            case 2:
                                try {
                                    if (!(r = i[1])) return s = Ru(location.href, {
                                        source: "log",
                                        type: "debug"
                                    }), o(function() {
                                        return "Outer page gave us a bogus frame Id! Iframe: ".concat(s)
                                    }), [2];
                                    this.Qh({
                                        frameId: r,
                                        parentIds: i[2],
                                        outerStartTime: i[3],
                                        scheme: i[4],
                                        script: i[5],
                                        appHost: i[6],
                                        orgId: i[7],
                                        initConfig: i[8],
                                        pageRsp: i[9],
                                        consented: i[10],
                                        minimumWhen: i[11]
                                    })
                                } catch (t) {
                                    o(function() {
                                        return "Failed to parse frameId from message: ".concat(Vr(l.C.wdx, i))
                                    })
                                }
                                return [3, 7];
                            case 3:
                                return this.setConsent(i[1]), [3, 7];
                            case 4:
                                return e.trys.push([4, 6, , 7]), u = JSON.parse(i[1]), a = u.StartTime, c = void 0, i.length > 2 && i[2] && (h = i[2], Object.prototype.hasOwnProperty.call(h, "ProtocolVersion") && h.ProtocolVersion >= 20180723 && Object.prototype.hasOwnProperty.call(h, "OuterStartTime") && (a = h.OuterStartTime), Object.prototype.hasOwnProperty.call(h, "MobileScriptPath") && (c = h.MobileScriptPath)), f = Or(u.Host, Ur(u.OrgId)), [4, this.Qh({
                                    frameId: 0,
                                    parentIds: [],
                                    outerStartTime: a,
                                    scheme: "https:",
                                    script: null != c ? c : Fr(f),
                                    appHost: Nr(f) || "",
                                    orgId: u.OrgId,
                                    initConfig: void 0,
                                    pageRsp: u.PageResponse,
                                    consented: null !== (v = this.Cn.getConsent()) && void 0 !== v ? v : Kt.RevokeConsent
                                })];
                            case 5:
                                return e.sent(), [3, 7];
                            case 6:
                                return e.sent(), o(function() {
                                    return "Failed to initialize mobile web recording from message: ".concat(Vr(l.C.wdx, i))
                                }), [3, 7];
                            case 7:
                                return [2]
                        }
                    })
                })
            }, i.prototype.Gh = function(t) {
                this.yu && this.yu === t || (0 != this.yu ? this.W.parent ? (o(function() {
                    return "Asking for a frame ID."
                }), this.$h.postMessage(this.W.parent, [Fn.RequestFrameId])) : o(function() {
                    return "Orphaned window."
                }) : o(function() {
                    return "For some reason the outer window attempted to request a frameId"
                }))
            }, i.prototype.Qh = function(t) {
                return r(this, void 0, void 0, function() {
                    var n, i, r, s, u, a, c, h = this;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                if (this.yu) return this.yu !== t.frameId ? (o(function() {
                                    return "Updating frame id from ".concat(h.yu, " to ").concat(t.frameId)
                                }), this.C.recording.splitPage(2)) : o(function() {
                                    return "frame Id is already set to ".concat(h.yu)
                                }), [2];
                                if (n = Ru(location.href, {
                                        source: "log",
                                        type: "debug"
                                    }), o(function() {
                                        return "FrameId received within frame ".concat(n, ":").concat(t.frameId)
                                    }), this.Ju = t.scheme, this.Ma = t.script, this.Oa = t.appHost, this.Ua = t.orgId, this.La = t.initConfig, this.C.options.orgId = t.orgId, this.C.options.scheme = t.scheme, this.C.options.appHost = t.appHost, this.C.options.script = t.script, this.yu = t.frameId, this.bu = t.parentIds, !t.pageRsp || !zf(this.C.wdx, t.pageRsp)) return this.oc(!0 === (null === (a = t.pageRsp) || void 0 === a ? void 0 : a.GSEnabled)), this.shutdown(2), [2];
                                if (this.Ta) return [2];
                                i = t.consented, this.$a(t.pageRsp, i), this.ac(), this.Va(), this.St.enqueueFirst(Mv({
                                    type: "default"
                                })), r = this.C.recording.inWebView, s = Ru(this.W.location.href, {
                                    source: "page",
                                    type: r ? "url" : "base"
                                }), u = "" === this.Mt.referrer ? "" : Ru(this.Mt.referrer, {
                                    source: "page",
                                    type: r ? "referrer" : "base"
                                }), this.St.enqueueFirst(this.xa.getNavigateEvent(s, 81)), this.St.enqueueFirst({
                                    Kind: 8198,
                                    Args: [i, 1]
                                }), this.St.enqueueFirst({
                                    Kind: 25,
                                    Args: [Ru(Eu(this.W), {
                                        source: "event",
                                        type: 25
                                    }), Y(this.W.document), s, u]
                                }), this.St.enqueue({
                                    Kind: 89,
                                    Args: [Jr.Ver]
                                }), e.label = 1;
                            case 1:
                                return e.trys.push([1, 3, , 4]), [4, Promise.race([ko(this.C.wdx, this.W), wo(this.C.wdx, this.W, 250)])];
                            case 2:
                            case 3:
                                return e.sent(), [3, 4];
                            case 4:
                                return this.St.enqueue({
                                    Kind: 19,
                                    Args: es(this.W.document)
                                }), this.tc(), this.St.rebaseIframe(t.outerStartTime, null !== (c = t.minimumWhen) && void 0 !== c ? c : 0), this.C.time.setStartTime(t.outerStartTime), this.Wa && this.za && this.qa ? (this.St.startPipeline({
                                    frameId: t.frameId,
                                    isNewSession: !!t.pageRsp.IsNewSession,
                                    orgId: this.Ua,
                                    pageId: t.pageRsp.PageIntId,
                                    parentIds: t.parentIds,
                                    serverPageStart: t.pageRsp.PageStart,
                                    sessionId: t.pageRsp.SessionIntId,
                                    userId: t.pageRsp.UserIntId,
                                    minDwellTime: 0
                                }).then(function() {
                                    h.Ya(), h.cc(h.W.document), h.Xa()
                                }), [2]) : (o(function() {
                                    return "one or more of userId:".concat(h.Wa, " | sessionId:").concat(h.za, " | pageId:").concat(h.qa, " are undefined")
                                }), [2])
                        }
                    })
                })
            }, i
        }(Wf),
        Vv = function() {
            function t(t, n, i) {
                void 0 === n && (n = function() {}), void 0 === i && (i = !1), this.Mt = t, this.Xh = n, this.Jh = i, this._cookies = {}, this._cookies = k(this.Mt)
            }
            return t.prototype.setDomain = function(t) {
                this.Yh = t
            }, t.prototype.getValue = function(t, n) {
                return this.Zh(t, n)
            }, t.prototype.setValue = function(t, n, i, r) {
                var e = this;
                if (null != this.Yh && !this.Jh) {
                    var s = [];
                    this.tf(t, r, n, function() {
                        return e.nf(t, r, n, i)
                    }, s), s.length > 0 && this.Xh(s)
                }
            }, t.prototype.setCookie = function(t, n, i) {
                this._setCookie(t, n, i)
            }, Object.defineProperty(t.prototype, "cookies", {
                get: function() {
                    return this._cookies
                },
                enumerable: !1,
                configurable: !0
            }), t.prototype.clearCookie = function(t, n) {
                this._cookies[t] && (this.Mt.cookie = $v(this.Yh, t, "", "Thu, 01 Jan 1970 00:00:01 GMT"), delete this._cookies[t]);
                try {
                    delete localStorage[null != n ? n : t]
                } catch (t) {}
            }, t.prototype._setCookie = function(t, n, i) {
                try {
                    if (this.Mt.cookie = $v(this.Yh, t, n, i), this.Mt.cookie && this.Mt.cookie.indexOf(n) > -1) return;
                    this.Mt.cookie = $v(this.Yh, t, n, i, "None")
                } finally {
                    this._cookies = k(this.Mt)
                }
            }, t.prototype.nf = function(t, n, i, r) {
                this._setCookie(t, i, r),
                    function(t, n) {
                        try {
                            localStorage[t] = n
                        } catch (t) {}
                    }(null != n ? n : t, i)
            }, t.prototype.Zh = function(t, n) {
                var i, r = this._cookies[t];
                try {
                    i = localStorage[null != n ? n : t]
                } catch (t) {}
                return {
                    cookieValue: r,
                    localStorageValue: i
                }
            }, t.prototype.tf = function(t, n, i, r, e, s) {
                void 0 === s && (s = 3), r();
                for (var o = !1, u = !1, a = 1; a < s; a++) {
                    var c = this.Zh(t, n),
                        h = c.cookieValue;
                    if (u = c.localStorageValue === i, (o = h === i) && u) return !0;
                    if (o) break;
                    r()
                }
                return o || e.push([t, "cookie", i]), u || e.push([null != n ? n : t, "localStorage", i]), !1
            }, t
        }();

    function $v(t, n, i, r, e) {
        void 0 === e && (e = "Strict");
        var s = "".concat(n, "=").concat(i),
            o = function(t) {
                if (t) return ".".concat(encodeURIComponent(t))
            }(t);
        return o && (s += "; domain=".concat(o)), r && (s += "; Expires=".concat(r)), s += "; path=/; SameSite=".concat(e), "https:" === location.protocol && (s += "; Secure"), s
    }

    function Gv(t, n, i, r) {
        var e = i(t),
            s = i(n);
        return e ? s ? r(e, s) : e : s
    }
    var Qv = 1,
        Xv = function() {
            function t(t, n, i, r, e) {
                var s;
                this.C = t, this.Th = n, this.Ua = i, this["if"] = r, this.rf = e, s = kf("fs_cid", "_fs_cid", this.Ua, this["if"]), this.ef = s[0], this.sf = s[1], this.uf = s[2], this.af = s[3];
                var o = If(this.rf, this.Th, this.ef, this.sf, this.uf, this.af),
                    u = o[0],
                    a = o[1],
                    c = u || a;
                this.cf = function(t) {
                    var n = {
                        consent: Kt.RevokeConsent
                    };
                    if (!t) return n;
                    var i = t.split(".");
                    return i.length < 1 ? n : (i[0], "1" === i[1] ? {
                        consent: Kt.GrantConsent
                    } : n)
                }(c)
            }
            return t.prototype.getConsentState = function() {
                return this.cf.consent
            }, t.prototype.setConsentState = function(t) {
                var n, i;
                this.rf || this.Th.clearCookie(this.uf, this.af), this.cf.consent = t, t !== Kt.RevokeConsent ? this.Th.setValue(this.ef, (i = this.cf.consent, [Qv, i === Kt.GrantConsent ? 1 : 0].join(".")), (n = this.C.wdx, new Date(1e3 * Et(n)).toUTCString()), this.sf) : this.Th.clearCookie(this.ef, this.sf)
            }, t
        }(),
        Jv = 1,
        Yv = function() {
            function t(t, n, i, r, e) {
                var s;
                this.C = t, this.Ua = i, this["if"] = r, this.rf = e, this.Th = n, s = kf("fs_lua", "_fs_lua", this.Ua, this["if"]), this.ef = s[0], this.sf = s[1], this.uf = s[2], this.af = s[3];
                var o = If(this.rf, this.Th, this.ef, this.sf, this.uf, this.af),
                    u = o[0],
                    a = o[1];
                this.cf = function(t, n) {
                    var i;
                    return null !== (i = Gv(t, n, Zv, function(t, n) {
                        return (n.lastUserActivityTime || 0) > (t.lastUserActivityTime || 0) ? n : t
                    })) && void 0 !== i ? i : {
                        lastUserActivityTime: void 0
                    }
                }(u, a)
            }
            return t.prototype.getLastUserActivityTimeMS = function() {
                return this.cf.lastUserActivityTime
            }, t.prototype.setLastUserActivityTimeMS = function(t) {
                var n;
                this.rf || this.Th.clearCookie(this.uf, this.af), this.cf.lastUserActivityTime = t, this.Th.setValue(this.ef, function(t) {
                    return [Jv, t].join(".")
                }(t), (n = this.C.wdx, new Date(function(t) {
                    return ft(t) + Hv
                }(n)).toUTCString()), this.sf)
            }, t
        }();

    function Zv(t) {
        var n = {
            lastUserActivityTime: void 0
        };
        if (!t) return n;
        var i = t.split(".");
        return i.length < 1 ? n : (i[0], {
            lastUserActivityTime: F(i[1])
        })
    }
    var tl = function() {
            function t(t, n, i, r, e) {
                var s;
                this.C = t, this.Th = n, this.Ua = i, this["if"] = r, this.rf = e, s = kf(nl, "_fs_uid", this.Ua, this["if"]), this.ef = s[0], this.sf = s[1], this.uf = s[2], this.af = s[3], this.cf = this.hf(this.Ua)
            }
            return t.prototype.getIdentity = function() {
                return this.cf
            }, t.prototype.setIdentity = function(t) {
                this.cf = t, this.ff()
            }, t.prototype.hf = function(t) {
                var n = If(this.rf, this.Th, this.ef, this.sf, this.uf, this.af),
                    i = n[0],
                    r = n[1],
                    e = function(t, n, i, r) {
                        return Gv(n, i, ki.bind(null, t), function(t, n) {
                            return t.orgId !== r && n.orgId !== r ? null : t.orgId !== r ? n : n.orgId !== r ? t : n.expirationAbsTimeSeconds > t.expirationAbsTimeSeconds ? n : t
                        })
                    }(this.C.wdx, i, r, t);
                return e || {
                    expirationAbsTimeSeconds: Et(this.C.wdx),
                    orgId: t,
                    userId: "",
                    sessionId: "",
                    appKeyHash: ""
                }
            }, t.prototype.ff = function() {
                this.cf.expirationAbsTimeSeconds++, this.rf || this.Th.clearCookie(this.uf, this.af);
                var t, n = this.Lc(),
                    i = (t = this.cf.expirationAbsTimeSeconds, new Date(1e3 * t).toUTCString());
                this.Th.setValue(this.ef, n, i, this.sf)
            }, t.prototype.Lc = function() {
                var t, n, i, r, e, s, o, u, a = [this.cf.userId, null !== (t = this.cf.sessionId) && void 0 !== t ? t : "", "".concat(null !== (n = this.cf.sessionStartTime) && void 0 !== n ? n : ""), "", "".concat(null !== (i = this.cf.pageCount) && void 0 !== i ? i : "")].join(":"),
                    c = ["", this.cf.orgId, a, encodeURIComponent(null !== (r = this.cf.appKeyHash) && void 0 !== r ? r : ""), encodeURIComponent(null !== (e = this.cf.sessionUid) && void 0 !== e ? e : ""), (s = this.cf, o = s.sessionUidState, u = s.sessionUidActiveTimeMs, 2 === o && void 0 !== u ? "".concat(o, ":").concat(u) : String(null != o ? o : ""))],
                    h = this.cf.discardedSessionUid;
                return h && c.push(encodeURIComponent(h)), c.push("/".concat(this.cf.expirationAbsTimeSeconds)), c.join("#")
            }, t
        }(),
        nl = "fs_uid",
        il = function() {
            function t(t, n, i, r) {
                var e, s;
                void 0 === i && (i = function() {}), void 0 === r && (r = !1), this.C = t, this.Vc = n, this.vf = void 0, n.useMockProtocol ? this.qc = new Ff : this.qc = null !== (e = n.clientStore) && void 0 !== e ? e : new Vv(this.C.window.document, i, r);
                var o = !!n.useNamespace,
                    u = !!n.isolated;
                this.lf = null !== (s = n.identityStore) && void 0 !== s ? s : new tl(this.C, this.qc, n.orgId, o, u), this.df = new Xv(this.C, this.qc, n.orgId, o, u), this.pf = new Yv(this.C, this.qc, n.orgId, o, u)
            }
            return t.prototype.getConsentStore = function() {
                return this.df
            }, t.prototype.clear = function() {
                this.pf.setLastUserActivityTimeMS(void 0);
                var t = this.lf.getIdentity();
                t.sessionStartTime = t.pageCount = void 0, t.userId = t.sessionId = t.appKeyHash = this.vf = "", t.sessionUid = void 0, t.sessionUidState = void 0, t.discardedSessionUid = void 0, t.sessionUidActiveTimeMs = void 0, t.expirationAbsTimeSeconds = Et(this.C.wdx), this.lf.setIdentity(t)
            }, t.prototype.clearUserSession = function() {
                this.pf.setLastUserActivityTimeMS(void 0);
                var t = this.lf.getIdentity();
                t.sessionStartTime = t.pageCount = void 0, t.userId = t.sessionId = "", t.expirationAbsTimeSeconds = Et(this.C.wdx), this.lf.setIdentity(t)
            }, t.prototype.create = function(t) {
                this.pf.setLastUserActivityTimeMS(t.lastUserActivityTime);
                var n = this.lf.getIdentity();
                this.lf.setIdentity(i(i({}, n), t))
            }, t.prototype.getOrgId = function() {
                return this.lf.getIdentity().orgId
            }, t.prototype.getUserId = function() {
                return this.lf.getIdentity().userId
            }, t.prototype.setUserId = function(t) {
                var n = this.lf.getIdentity();
                n.userId = t, this.lf.setIdentity(n)
            }, t.prototype.getSessionId = function() {
                return this.lf.getIdentity().sessionId
            }, t.prototype.getAppKeyHash = function() {
                return this.lf.getIdentity().appKeyHash
            }, t.prototype.getCookies = function() {
                return this.qc.cookies
            }, t.prototype.setAppId = function(t) {
                this.vf = t;
                var n = this.lf.getIdentity();
                n.appKeyHash = Fh(t), this.lf.setIdentity(n)
            }, t.prototype.getAppId = function() {
                return this.vf
            }, t.prototype.setSessionStartTimeMS = function(t) {
                var n = this.lf.getIdentity();
                n.sessionStartTime = t, this.lf.setIdentity(n)
            }, t.prototype.getSessionStartTimeMS = function() {
                return this.lf.getIdentity().sessionStartTime
            }, t.prototype.getExpirationAbsTimeSeconds = function() {
                return this.lf.getIdentity().expirationAbsTimeSeconds
            }, t.prototype.setLastUserActivityTimeMS = function(t) {
                this.pf.setLastUserActivityTimeMS(t)
            }, t.prototype.getLastUserActivityTimeMS = function() {
                return this.pf.getLastUserActivityTimeMS()
            }, t.prototype.setPageCount = function(t) {
                var n = this.lf.getIdentity();
                n.pageCount = t, this.lf.setIdentity(n)
            }, t.prototype.getPageCount = function() {
                return this.lf.getIdentity().pageCount
            }, t.prototype.getSessionUid = function() {
                return this.lf.getIdentity().sessionUid
            }, t.prototype.getDiscardedSessionUid = function() {
                return this.lf.getIdentity().discardedSessionUid
            }, t.prototype.getSessionUidState = function() {
                var t = this.lf.getIdentity();
                if (void 0 !== t.sessionUidState) return t.sessionUidState
            }, t.prototype.setSessionUid = function(t, n) {
                var i = this.lf.getIdentity();
                i.sessionUid = t, i.discardedSessionUid = void 0, i.sessionUidActiveTimeMs = void 0, i.sessionUidState = t ? void 0 !== n ? n : 2 : void 0, this.lf.setIdentity(i)
            }, t.prototype.finalizeSessionUidForPageStart = function(t, n) {
                var i = this.getSessionUid(),
                    r = this.getDiscardedSessionUid(),
                    e = this.getSessionUidState();
                if (!i) return 3 === e && n && r === n ? {
                    discardedSessionUid: r
                } : {};
                if (void 0 === e) return {};
                var s = this.lf.getIdentity(),
                    o = {
                        activeSessionUid: i
                    },
                    u = {
                        discardedSessionUid: i
                    };
                switch (e) {
                    case 1:
                        return s.sessionUidState = 2, s.sessionUidActiveTimeMs = ft(this.C.wdx), this.lf.setIdentity(s), o;
                    case 2:
                        return t || function(t, n) {
                            var i, r, e = null !== (r = null !== (i = n.sessionUidActiveTimeMs) && void 0 !== i ? i : n.sessionStartTime) && void 0 !== r ? r : 0;
                            return 0 !== e && t.mathAbs(ft(t) - e) >= Fv
                        }(this.C.wdx, s) ? (function(t, n) {
                            t.discardedSessionUid = n, t.sessionUid = void 0, t.sessionUidState = 3, t.sessionUidActiveTimeMs = void 0
                        }(s, i), this.lf.setIdentity(s), u) : o;
                    case 3:
                        return n && i === n ? u : {};
                    default:
                        return {}
                }
            }, t.prototype.getClientStore = function() {
                return this.qc
            }, t.prototype.setCookie = function(t, n, i) {
                var r;
                void 0 === i && (r = this.C.wdx, i = new Date(ft(r) + 6048e5).toUTCString()), this.qc.setCookie(t, n, i)
            }, t.prototype.setCookieDomain = function(t, n) {
                var i = n;
                (Cr(i) || i.match(/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/g)) && (i = "");
                var r = this.Vc.cookieDomain;
                z(r) && (i = r), this.qc.setDomain(i)
            }, t.prototype.setIds = function(t, n, i, r) {
                this.setCookieDomain(t, n);
                var e = this.lf.getIdentity();
                e.userId = i, e.sessionId = r, this.lf.setIdentity(e)
            }, t.prototype.setExpirationAbsTimeSeconds = function(t) {
                var n = this.lf.getIdentity();
                n.expirationAbsTimeSeconds = t, this.lf.setIdentity(n)
            }, t.prototype.clearAppId = function() {
                var t = this.lf.getIdentity();
                return !!t.appKeyHash && (this.vf = "", t.appKeyHash = "", this.lf.setIdentity(t), !0)
            }, t
        }();

    function rl(t, n, i, r, e) {
        if (t && "object" == typeof t) {
            var s = 0,
                o = {};
            for (var u in t)
                if (!(u in e)) {
                    var a = t[u];
                    e[u] = {
                        value: a,
                        apiSource: n,
                        apiVersion: i,
                        schema: r
                    }, o[u] = a, s++
                }
            if (0 !== s) return o
        }
    }

    function el(t) {
        return "<cyclic reference to ".concat(t || "(root)", ">")
    }

    function sl(t, n) {
        return t ? "".concat(t, ".").concat(n) : n
    }
    var ol = function() {
        function t() {
            this.gf = new Ne
        }
        return t.prototype.priorPathFor = function(t) {
            return this.gf.get(t)
        }, t.prototype.withEntry = function(t, n, i) {
            this.gf.set(t, n);
            try {
                return i()
            } finally {
                this.gf["delete"](t)
            }
        }, t
    }();

    function ul(t, n, i, r, e) {
        void 0 === r && (r = new ol), void 0 === e && (e = "");
        var s = {},
            o = {};
        return r.withEntry(i, e, function() {
            var u;
            for (var a in i)
                if (t.objectHasOwnProp(i, a)) {
                    if (n() <= 0) break;
                    var c = i[a];
                    if (void 0 !== c) {
                        var h = al(a),
                            f = h[0],
                            v = h[1],
                            l = sl(e, f),
                            d = c,
                            p = v;
                        if (D(t, c)) void 0 !== (w = r.priorPathFor(c)) ? (d = el(w), p = void 0) : (d = (u = ul(t, n, c, r, l))[0], p = u[1]);
                        else if (fl(t, c)) {
                            d = [], p = [];
                            for (var g = 0; g < c.length; g++) {
                                var w, m = c[g];
                                if (void 0 === (w = r.priorPathFor(m))) {
                                    var y = ul(t, n, m, r, "".concat(l, "[").concat(g, "]")),
                                        b = y[0],
                                        S = y[1];
                                    d.push(b), p.push(S)
                                } else d.push(el(w)), p.push(void 0)
                            }
                        } else "date" === v || W(c) ? d = B(c) : U(t, c) && ("dates" === v || c.every(W)) && (d = c.map(B));
                        s[f] = d, p && (o[f] = p)
                    }
                }
        }), [s, o]
    }

    function al(t) {
        var n = function(t) {
                return /^[a-zA-Z_][a-zA-Z0-9_\\-]*$/.test(t) ? t : t.replace(/^[^a-zA-Z_]+|[^a-zA-Z0-9_]/g, "") || t
            }(t),
            i = n.lastIndexOf("_");
        if (-1 === i) return [n, null];
        var r, e = n.substring(0, i),
            s = n.substring(i + 1);
        return r = s, hl.test(r) ? [e, s] : [n, null]
    }
    var cl, hl = /^(?:bool|date|int|obj|real|str)s?$/;

    function fl(t, n) {
        return U(t, n) && n.length > 0 && n.every(function(n) {
            return D(t, n)
        })
    }

    function vl(t, n, i, r, e, s, u) {
        var a, c, h, f, v = 1500,
            l = function() {
                return --v
            };
        return r ? (h = (a = ll(t, l, i, r))[0], f = a[1]) : (h = (c = ul(t, l, i))[0], f = c[1]), v < 0 && o(function() {
            return "Too many properties for [".concat(n, "] API call")
        }), n === Zt.Document ? {
            properties: rl(h, e, s, f, u),
            schema: f
        } : {
            properties: h,
            schema: f
        }
    }

    function ll(t, n, i, r, e, s) {
        void 0 === e && (e = new ol), void 0 === s && (s = "");
        var o = {},
            u = {};

        function a(t, n, i) {
            o[t] = n, i && (u[t] = i)
        }
        return e.withEntry(i, s, function() {
            for (var c in i)
                if (t.objectHasOwnProp(i, c)) {
                    if (n() <= 0) break;
                    var h = i[c],
                        f = r[c];
                    if (D(t, h)) {
                        var v = e.priorPathFor(h);
                        if (void 0 !== v) {
                            o[c] = el(v);
                            continue
                        }
                        var l = ll(t, n, h, f || {}, e, sl(s, c)),
                            d = l[0],
                            p = l[1];
                        o[c] = d, f && (u[c] = p)
                    } else W(h) ? a(c, B(h), f) : U(t, h) && N(h, W) ? a(c, h.map(B), f) : a(c, h, f)
                }
        }), [o, u]
    }

    function dl(t, n, i, r, e, s, o) {
        var u = Vr(t, i),
            a = e ? Vr(t, e) : void 0,
            c = "fs" !== r ? r : void 0;
        switch (n) {
            case Zt.Event:
                return {
                    Kind: 8197,
                    Args: [o, u, c, s, a]
                };
            case Zt.Document:
            case Zt.Page:
            case Zt.Session:
            case Zt.User:
                return {
                    Kind: 8193,
                    Args: [n, u, c, s, a]
                };
            default:
                Ho(0, "Unsupported")
        }
    }
    var pl = function() {
        function t(t) {
            this.wf = {}, this.mf = null, this.t = t
        }
        return t.create = function(n, i) {
            var r = new t(n);
            return i && (r.yf = i.yf, r.wf = i.wf, r.mf = i.mf), r
        }, t.prototype.unloadCrossPageVars = function(t) {
            switch (t) {
                case 3:
                case 6:
                    break;
                default:
                    this.yf = void 0
            }
        }, t.prototype.getCrossPageVars = function() {
            return this.yf
        }, t.prototype.getDocumentVars = function() {
            var t, n = {};
            for (var r in this.wf) {
                var e = this.wf[r],
                    s = e.value,
                    o = e.apiSource,
                    u = e.schema,
                    a = e.apiVersion;
                (l = null !== (t = n[h = "".concat(null != o ? o : "").concat("$$$").concat(null != a ? a : "")]) && void 0 !== t ? t : {
                    properties: {}
                }).properties[r] = s, u && (l.schema = i(i({}, l.schema), u)), n[h] = l
            }
            var c = [];
            for (var h in n) {
                var f = h.split("$$$"),
                    v = (o = f[0], f[1]),
                    l = n[h];
                gl(c, dl(this.t, Zt.Document, l.properties, "" === o ? void 0 : o, l.schema, F(v)))
            }
            return c
        }, t.prototype.getCurrentUser = function() {
            return this.mf ? Z(this.t, this.t.jsonStringify(this.mf)) : null
        }, t.prototype.bf = function(t, n, r) {
            if ("" === n) return null != this.mf && (this.mf = null, !0);
            var e = i({}, t);
            delete e.uid;
            var s = void 0 !== n,
                o = Object.keys(e).length > 0;
            if (!s && !o) return !1;
            var u = r ? void 0 : this.mf;
            return this.mf = {
                uid: null != n ? n : null == u ? void 0 : u.uid,
                properties: i(i({}, null == u ? void 0 : u.properties), e)
            }, this.mf.uid || delete this.mf.uid, !0
        }, t.prototype.api = function(t, n) {
            var i, r = {
                    events: [],
                    reidentify: !1
                },
                e = [];
            try {
                var s = function(t) {
                        switch (t.operation) {
                            case Uv.TrackEvent:
                                return Zt.Event;
                            case Uv.SetPage:
                                return Zt.Page;
                            case Uv.SetProperties:
                                var n = t.option.type;
                                switch (n) {
                                    case Zt.Document:
                                    case Zt.Page:
                                    case Zt.User:
                                        return n;
                                    default:
                                        return n === Zt.Session ? n : Ho(0, "Invalid scope: ".concat(n))
                                }
                            default:
                                Ho(0, "Unsupported")
                        }
                    }(t),
                    u = null === (i = t.source) || void 0 === i ? void 0 : i.integration;
                if (! function(t, n, i) {
                        switch (n) {
                            case Zt.Event:
                                var r = i.option.name;
                                return "string" == typeof r || (o(function() {
                                    return "Custom event name invalid: ".concat(r)
                                }), !1);
                            case Zt.Document:
                            case Zt.Page:
                                return !0;
                            case Zt.Session:
                            case Zt.User:
                                var e = i.option.properties;
                                return "object" == typeof e || (o(function() {
                                    return "Expected argument of type 'object' instead got type: '".concat(typeof e, "', value: ").concat(Vr(t, e))
                                }), !1);
                            default:
                                Ho(0, "Unsupported")
                        }
                    }(this.t, s, t)) return r;
                var a = function(t, n, i, r) {
                    var e = i.option.properties,
                        s = function(t, n) {
                            var i = n.option.schema;
                            if (2 === n.apiVersion) {
                                var r = H(i) && "properties" in i ? i.properties : {};
                                return H(r) ? r : {}
                            }
                        }(0, i);
                    if (n === Zt.Event) return {
                        rawProps: e,
                        eventName: i.option.name,
                        rawSchema: s
                    };
                    if (n !== Zt.User || !("uid" in e)) return {
                        rawProps: e,
                        rawSchema: s
                    };
                    var u = e.uid;
                    if (!1 === u) return delete e.uid, {
                        rawProps: e,
                        rawSchema: s,
                        reidentify: !!r,
                        nextAppId: ""
                    };
                    var a = function(t, n, i) {
                            var r = n;
                            if ("number" == typeof r && t.mathFloor(r) == r && (o(function() {
                                    return "Expected appId of type 'string' instead got value: ".concat(r, " of type: ").concat(typeof r)
                                }), r = "".concat(r)), "string" != typeof r) return o(function() {
                                return "blocking FS.identify API call; uid value (".concat(r, ") must be a string")
                            }), [void 0, nn.FsId];
                            var e = r.trim();
                            if (st.indexOf(e.toLowerCase()) >= 0) return o(function() {
                                return "blocking FS.identify API call; uid value (".concat(e, ") is illegal")
                            }), [void 0, nn.FsId];
                            var s = Fh(e),
                                u = void 0;
                            return i && i !== s && i !== e && (o(function() {
                                return "user re-identified; existing uid hash (".concat(i, ") does not match provided uid (").concat(e, ")")
                            }), u = nn.NewUid), [e, u]
                        }(t, u, r),
                        c = a[0],
                        h = a[1];
                    if (c) return e.uid = c, {
                        rawProps: e,
                        rawSchema: s,
                        nextAppId: c,
                        reidentify: h === nn.NewUid
                    };
                    switch (h) {
                        case nn.FsId:
                        case void 0:
                            break;
                        default:
                            o(function() {
                                return "unexpected failReason returned from setAppId: ".concat(h)
                            })
                    }
                }(this.t, s, t, n);
                if (!a) return r;
                var c = a.rawProps,
                    h = a.rawSchema,
                    f = a.reidentify,
                    v = a.nextAppId,
                    l = a.eventName,
                    d = vl(this.t, s, null != c ? c : {}, h, u, t.apiVersion, this.wf),
                    p = d.properties,
                    g = d.schema;
                if (!p && s === Zt.Document) return r;
                var w = dl(this.t, s, null != p ? p : {}, u, g, t.apiVersion, l);
                return gl(e, function(t, n) {
                    var i = wl[t];
                    if (i) return Mv({
                        source: n,
                        type: "api",
                        entrypoint: i
                    })
                }(s, t.source)), gl(e, w), s === Zt.Page && (this.yf = w), {
                    events: e,
                    reidentify: !!f,
                    appId: v,
                    userChanged: s === Zt.User && this.bf(null != p ? p : {}, v, !!f)
                }
            } catch (n) {
                return o(function() {
                    return "unexpected exception handling ".concat(t.operation, " API call: ").concat(n.message)
                }), r
            }
        }, t
    }();

    function gl(t, n) {
        n && t.push(n)
    }
    var wl = ((cl = {})[Zt.User] = "setVars", cl[Zt.Event] = "event", cl);

    function ml(t, n) {
        var i, r;
        if (t === top || (null == n ? void 0 : n.isOuterScript) || (null == n ? void 0 : n.runInIframe) || (null == n ? void 0 : n.transport)) return !0;
        try {
            t.parent.document;
            var e = void 0;
            try {
                e = null === (r = null === (i = Ui(t.parent)) || void 0 === i ? void 0 : i("getConfig")) || void 0 === r ? void 0 : r.env
            } catch (t) {}
            var s = e ? {
                isOuterScript: e.isOuterScript,
                runInIframe: e.runInIframe
            } : {
                isOuterScript: Xi(t.parent),
                runInIframe: Qi(t.parent)
            };
            return s.transport = Yi(t.parent), ml(t.parent, s)
        } catch (t) {}
        return !1
    }

    function yl(t, n) {
        try {
            if (t) return void 0 !== n ? new t(n) : new t, !0
        } catch (t) {}
        return !1
    }
    var bl = to || no || Se,
        Sl = function() {
            function t(t, n) {
                void 0 === n && (n = function(t) {
                    return new WebSocket(t)
                }), this.Sf = n, this._f = !1, this.kf = !1, this.St = {}, this.Cc = 1, this.C = t, this.Ju = t.options.scheme, this.ja = t.options.recSettingsHost
            }
            return t.isSupported = function() {
                return "WebSocket" in window
            }, t.prototype.page = function(t) {
                var n = this;
                return new Promise(function(i, r) {
                    n.Af({
                        Cmd: 1,
                        Page: t
                    }, pf(n.C), function(t) {
                        4 === t.Cmd ? i(t.Page) : (o(function() {
                            return "socket: unexpected page response: ".concat(t.Cmd)
                        }), r(t.Cmd))
                    }, r)
                })
            }, t.prototype.settings = function(t) {
                var n = this.C.options.settings;
                if (n) return Promise.resolve(n);
                var i = t.previewMode ? pf(this.C) : this.ja;
                return df(this.C, this.Ju, i, t)
            }, t.prototype.bundle = function(t) {
                return this._h({
                    req: 2,
                    rsp: 5
                }, t)
            }, t.prototype._h = function(t, n) {
                return r(this, void 0, void 0, function() {
                    var i, r, s, u = this;
                    return e(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return [4, bo(this.C.wdx, this.C.window)];
                            case 1:
                                return e.sent(), i = n.deltaT, r = n.serverPageStart, s = n.serverBundleTime, [2, new Promise(function(e, a) {
                                    var c = pf(u.C);
                                    _l(u.C.wdx, n.recHost, c);
                                    var h = n.bundle,
                                        f = h[0],
                                        v = {
                                            Bundle: kl(h[1]),
                                            DeltaT: null === i ? void 0 : i,
                                            OrgId: n.orgId,
                                            PageId: n.pageId,
                                            PageStart: null == r ? void 0 : r,
                                            PrevBundleTime: null == s ? void 0 : s,
                                            Seq: f,
                                            SessionId: n.sessionId,
                                            UserId: n.userId
                                        },
                                        l = u.Af({
                                            Cmd: t.req,
                                            Bundle: v
                                        }, c, function(n) {
                                            n.Cmd === t.rsp ? e([null != l ? l : 0, n.Bundle]) : o(function() {
                                                return "socket: unexpected bundle response: ".concat(n.Cmd)
                                            })
                                        }, a)
                                })]
                        }
                    })
                })
            }, t.prototype.bundleBeacon = function(t) {
                var n = pf(this.C);
                return _l(this.C.wdx, t.recHost, n), vf(this.C, this.Ju, n, t)
            }, t.prototype.startBeacon = function(t) {
                return lf(this.C, this.Ju, pf(this.C), t)
            }, t.prototype.Af = function(t, n, i, r) {
                var e = t;
                e.Seq = this.Cc++;
                var s = Vr(this.C.wdx, e);
                return this.St[e.Seq] = {
                    payload: s,
                    win: i,
                    lose: r
                }, this.Ef(n), s.length
            }, t.prototype.Cf = function(t) {
                var n;
                try {
                    n = Z(this.C.wdx, t)
                } catch (t) {
                    return void o(function() {
                        return "socket: error parsing frame: ".concat(t)
                    })
                }
                var i = this.St[n.Seq];
                delete this.St[n.Seq], i ? 3 === n.Cmd ? (o(function() {
                    return 3 === n.Cmd ? "Socket Response Error: ".concat(n.Fail.Error) : "Socket Response Error: Unknown Error"
                }), i.lose(new rf(n.Fail.Status, n.Fail.Error))) : i.win(n) : o(function() {
                    return "socket: mismatched request seq ".concat(n.Seq, "; ignoring")
                })
            }, t.prototype.Tf = function() {
                if (this.kf) {
                    if (this.Pf)
                        for (var t in this.St) {
                            var n = this.St[t];
                            n.sent || (this.Pf.send(n.payload), n.sent = !0)
                        } else o(function() {
                            return "socket: attempt to drain queue when no socket connection."
                        });
                } else o(function() {
                    return "socket: attempt to drain queue when disconnected."
                })
            }, t.prototype.xf = function() {
                for (var t in this.St) {
                    var n = this.St[t];
                    n.sent && (delete this.St[t], n.lose(new rf(0, "Pending request")))
                }
            }, t.prototype.Ef = function(t) {
                var n = this;
                if (this.kf) this.Tf();
                else if (!this._f) {
                    this._f = !0;
                    var i = "".concat("https:" == this.Ju ? "wss:" : "ws:", "//").concat(t, "/rec/sock");
                    this.Pf = this.Sf(i), this.Pf.onopen = function(t) {
                        n._f = !1, n.kf = !0, n.Tf()
                    }, this.Pf.onmessage = function(t) {
                        n.Cf(t.data), n.Tf()
                    }, this.Pf.onclose = function(t) {
                        o(function() {
                            return "socket: closed; reconnecting"
                        }), n._f = n.kf = !1, n.xf()
                    }, this.Pf.onerror = function(t) {
                        o(function() {
                            return "socket: error; reconnecting"
                        }), n._f = n.kf = !1, n.xf()
                    }
                }
            }, t
        }();

    function _l(t, n, i) {
        n && ae(i === n, "sock#recHost")
    }

    function kl(t) {
        if ("string" === t.type) return JSON.parse(t.data);
        throw new Error("Unexpected bundle type: ".concat(t.type))
    }
    var Il = function() {
            function t(t) {
                this.Rf = !1, this.fu = t
            }
            return t.prototype.flush = function() {
                this.fu(), this.Rf = !1
            }, t.prototype.schedule = function() {
                var t = this;
                this.Rf || (this.Rf = !0, Promise.resolve().then(function() {
                    t.flush()
                })["catch"](function(t) {
                    return ve("microtask#flush", {
                        err: t
                    })
                }))
            }, t
        }(),
        Al = function() {
            function t(t) {
                this.C = t, this.Mf = {
                    start: [],
                    shutdown: [],
                    "internal/bundle": [],
                    "internal/error": [],
                    "internal/fs-init": [],
                    "internal/user": []
                }
            }
            return t.prototype.registerListener = function(t, n) {
                var i;
                if (-1 === iv.indexOf(t)) return o(function() {
                    return "FS('observe'): invalid event type."
                }), {
                    disconnect: function() {},
                    failed: !0
                };
                if (!n) return o(function() {
                    return "FS('observe'): missing callback."
                }), {
                    disconnect: function() {},
                    failed: !0
                };
                var r = {
                        disconnected: !1,
                        callback: n,
                        count: 0
                    },
                    e = (null !== (i = this.Mf[t]) && void 0 !== i ? i : []).filter(function(t) {
                        return !t.disconnected
                    });
                return e.push(r), this.Mf[t] = e, {
                    disconnect: function() {
                        r.disconnected = !0
                    }
                }
            }, t.prototype.hasListeners = function(t) {
                var n;
                return (null !== (n = this.Mf[t]) && void 0 !== n ? n : []).length > 0 && this.Mf[t].some(function(t) {
                    return !t.disconnected
                })
            }, t.prototype.takeRecords = function(t) {
                var n, i = this,
                    r = null !== (n = this.Mf[t.type]) && void 0 !== n ? n : [];
                if (0 !== r.length)
                    for (var e = 0, s = r; e < s.length; e++) {
                        var u = s[e];
                        if (!(u.disconnected || u.count > 0 && t.once)) {
                            u.count += 1;
                            try {
                                u.callback(t.data)
                            } catch (t) {
                                o(function() {
                                    return "Recording observer callback error: ".concat(Us(i.C.wdx)(t))
                                })
                            }
                        }
                    }
            }, t
        }(),
        El = function() {
            function t(t) {
                var n = this;
                this.wi = t, this.St = [], this.ca = new Il(function() {
                    n.fu()
                })
            }
            return t.prototype.addEvent = function(t) {
                this.wi.hasListeners(t.type) && (this.St.push(t), this.ca.schedule())
            }, t.prototype.fu = function() {
                for (var t = 0, n = this.St; t < n.length; t++) {
                    var i = n[t];
                    this.wi.takeRecords(i)
                }
                this.St = []
            }, t
        }(),
        Cl = "",
        Tl = "https:";

    function Pl(t, n) {
        var i, r, e;
        switch (n) {
            case "all":
                return t.getPageArgs();
            case "url.now":
                return null !== (i = t.getCurrentSessionURL(!0)) && void 0 !== i ? i : null;
            case "id":
                return null !== (r = t.getCurrentSession()) && void 0 !== r ? r : null;
            default:
                return null !== (e = t.getCurrentSessionURL()) && void 0 !== e ? e : null
        }
    }

    function xl(t, n, i) {
        switch (n) {
            case "getConfig":
            case "getSession":
            case "init":
            case "observe":
            case "restart":
            case "setConfig":
            case "setIdentity":
            case "shutdown":
            case "source":
            case "start":
            case "getFullstoryId":
            case "trackEvent":
                return {
                    operation: n,
                    option: i
                };
            case "setPage":
                var r = (e = i).properties || e;
                return {
                    operation: n,
                    option: {
                        properties: r
                    }
                };
            case "stat":
                return {
                    operation: n,
                    option: {
                        event_type: (e = i).eventType || e.event_type,
                        properties: e.payload || e.properties
                    }
                };
            case "log":
                var e = i;
                return t.arrayIsArray(i) && (e = {
                    level: i[0],
                    msg: i[1]
                }), {
                    operation: n,
                    option: e
                };
            case "setVars":
            case "setProperties":
                var s = Uv.SetProperties;
                if (e = i, t.arrayIsArray(i) && (e = {
                        type: i[0],
                        properties: r = i[1]
                    }), (null == e ? void 0 : e.type) === Zt.Session) return;
                return {
                    operation: s,
                    option: e
                };
            case "event":
                return e = i, i && "object" == typeof i && "n" in i && (e = {
                    name: i.n,
                    properties: i.p
                }), {
                    operation: s = Uv.TrackEvent,
                    option: e
                };
            case "user":
                return r = i, {
                    operation: s = Uv.SetProperties,
                    option: {
                        type: "user",
                        properties: r
                    }
                };
            case "consent":
                var u = i;
                return {
                    operation: s = Uv.SetIdentity,
                    option: {
                        consent: u
                    }
                };
            case "rec":
                return i ? {
                    operation: Uv.Restart
                } : {
                    operation: s = Uv.Shutdown
                };
            default:
                o(function() {
                    return "Unrecognized api: ".concat(n)
                })
        }
    }
    var Rl = "must be an object";

    function Ml(t) {
        return !!t && "object" == typeof t
    }

    function Kl(t, n) {
        return n in t
    }

    function jl(t, n) {
        var r, e = {
            recoverable: [],
            unrecoverable: []
        };
        if (!Ml(n)) return e.unrecoverable.push(Ol("options", Rl)), [e, void 0];
        var s = {};
        if (Kl(n, "privacy")) {
            var u = function(t, n) {
                    var i = "privacy.attributeBlocklist",
                        r = [];
                    if (!Ml(n)) return r.push(Ol("privacy", Rl)), [r, void 0];
                    if (!Kl(n, "attributeBlocklist")) return [r, void 0];
                    if (!U(t, n.attributeBlocklist)) return r.push(Ol(i, "must be an array")), [r, void 0];
                    for (var e = {
                            attributeBlocklist: []
                        }, s = 0, o = n.attributeBlocklist; s < o.length; s++) {
                        var u = o[s];
                        Ul(u) ? e.attributeBlocklist.push(u) : r.push(Ol(i, "invalid rule: ".concat(Us(t)(u))))
                    }
                    return [r, e]
                }(t, n.privacy),
                a = u[0],
                c = u[1];
            (r = e.recoverable).push.apply(r, a), s.privacy = c
        }
        if (Kl(n, "env")) {
            var h = n.env;
            Ml(h) ? (Kl(h, "namespace") && o(function() {
                return "".concat(Ol("env", "namespace is ignored - it is resolved via data-fs-namespace/_fs_namespace before init runs"))
            }), s.env = i({}, h)) : e.recoverable.push(Ol("env", Rl))
        }
        return [e, s]
    }

    function Ol(t, n) {
        return "Init Api - invalid ".concat(t, " config, ").concat(n)
    }

    function Ul(t) {
        var n;
        if (!t || "object" != typeof t) return !1;
        var i = t;
        return Nl(i.target, ["any", "exclude", "mask"]) && Nl(i.tag) && Nl(i.action, ["erase", "maskText", "scrubUrl", "scrubCss"]) && Nl(null !== (n = i.type) && void 0 !== n ? n : "static", ["static", "prefix"])
    }

    function Nl(t, n) {
        return void 0 === n && (n = []), "string" == typeof t && (0 === n.length || -1 !== n.indexOf(t))
    }

    function Ll(t, n) {
        return n ? i(i(i({}, t), n), {
            privacy: (r = t.privacy, e = n.privacy, e ? {
                attributeBlocklist: s(s([], null !== (o = null == r ? void 0 : r.attributeBlocklist) && void 0 !== o ? o : [], !0), null !== (u = null == e ? void 0 : e.attributeBlocklist) && void 0 !== u ? u : [], !0)
            } : r),
            env: i(i({}, t.env), n.env)
        }) : t;
        var r, e, o, u
    }

    function Fl(t, n) {
        return t("function" == typeof n ? n() : n)
    }

    function Hl(t, n, i, r) {
        return void 0 === r && (r = Tn.DefaultRecDisabledMessage), {
            commit: function(n) {
                if (t) return Fl(I(t), null != n ? n : i)
            },
            discard: function(t) {
                if (n) return Dl(I(n), null != t ? t : r)
            }
        }
    }

    function Dl(t, n) {
        if (void 0 === n && (n = Tn.DefaultRecDisabledMessage), t) {
            var i = n;
            try {
                i = new Error(n)
            } catch (t) {}
            Fl(I(t), i)
        }
    }

    function Bl(t, n, i) {
        void 0 === n && (n = !1);
        for (var r = 0, e = t.commit; r < e.length; r++) {
            var s = e[r];
            n ? s.discard(i) : s.commit()
        }
        for (var o = 0, u = t.discard; o < u.length; o++)(s = u[o]).discard(i);
        t.commit = [], t.discard = []
    }
    var Wl = [Uv.GetConfig, Uv.GetFullstoryId, Uv.GetSession, Uv.Init, Uv.Observe, Uv.SetProperties, Uv.Source, Uv.TrackEvent],
        zl = [Uv.Observe, Uv.GetConfig],
        ql = "Invalid event type or missing callback";

    function Vl(t, n) {
        try {
            var i = t[1],
                r = t[3],
                e = void 0 === r ? A : r,
                s = t[4],
                o = i,
                u = o.type,
                a = o.callback,
                c = n.registerListener(u, a);
            (null == c ? void 0 : c.failed) ? Dl(s, ql): e(c)
        } catch (t) {}
    }

    function $l(t, n, i, r, e) {
        void 0 === e && (e = []), o(function() {
            return "Shutting down recorder."
        }), e.push.apply(e, _r(t, n));
        for (var s = 0, u = e; s < u.length; s++) {
            var a = u[s],
                c = a[0],
                h = a[3],
                f = a[4];
            if (-1 !== zl.indexOf(c)) switch (c) {
                case Uv.Observe:
                    Vl(a, i);
                    break;
                case Uv.GetConfig:
                    I(null != h ? h : A)(null);
                    break;
                default:
                    Dl(f)
            } else Dl(f)
        }
        r.addEvent({
            type: qf.SHUTDOWN,
            data: {
                reason: 5
            }
        })
    }
    var Gl = function(t) {
            function i(n, i) {
                void 0 === i && (i = 250);
                var r = t.call(this, n) || this;
                return r.Kf = n.wdx.mathMax(0, i), r
            }
            return n(i, t), i.prototype.En = function() {
                var t = this;
                (function(t, n, i) {
                    return r(this, void 0, void 0, function() {
                        var r;
                        return e(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return (r = t.requestWindowIdleCallback) ? [2, new Promise(function(t) {
                                        r(n, t, {
                                            timeout: i
                                        })
                                    })] : [4, wo(t, n, i)];
                                case 1:
                                    return e.sent(), [2, _o(t, 42)]
                            }
                        })
                    })
                })(this.C.wdx, this.C.window, this.Kf).then(function(n) {
                    n.didTimeout ? bo(t.C.wdx, t.C.window).then(function() {
                        return t.An(_o(t.C.wdx, 36))
                    }) : t.An(n)
                })
            }, i
        }(To),
        Ql = function(t) {
            function i(n) {
                return t.call(this, n) || this
            }
            return n(i, t), i.prototype.En = function() {
                var t = this;
                So(this.C.wdx, this.C.window).then(function() {
                    ko(t.C.wdx, t.C.window).then(function() {
                        return t.An(_o(t.C.wdx, 36))
                    })
                })
            }, i
        }(To),
        Xl = function() {
            function t(t, n) {
                void 0 === n && (n = 1e3), this.C = t, this.jf = new Set, this.Of = new yo(t.wdx, t.window, n);
                for (var i = 0, r = [16, 12, 32, 10, 64]; i < r.length; i++) {
                    var e = r[i];
                    this.jf.add(e)
                }
            }
            return t.prototype.intercept = function(t) {
                this.C.options.delayOnInteraction && this.jf.has(t.Kind) && (this.Uf = this.Of.trigger())
            }, t.prototype.nextIdleTime = function() {
                return r(this, void 0, void 0, function() {
                    var t;
                    return e(this, function(n) {
                        return [2, null !== (t = this.Uf) && void 0 !== t ? t : Promise.resolve()]
                    })
                })
            }, t
        }(),
        Jl = function() {
            function t() {}
            return t.prototype.createTopRecorder = function(t, n) {
                var i;
                i = t.options.useMockProtocol ? new Nf(t) : t.options.useSocket && Sl.isSupported() ? new Sl(t) : new sf(t);
                var r = new Kh(t),
                    e = t.options.delayOnInteraction ? new Xl(t) : void 0;
                return new Bv(t, i, r, Hs, e, n)
            }, t.prototype.createInnerRecorder = function(t) {
                return new qv(t)
            }, t
        }(),
        Yl = function() {
            function t(t, n, i, r) {
                void 0 === t && (t = window), void 0 === n && (n = Ki(t)), void 0 === i && (i = new Jl), void 0 === r && (r = ta.create(t)), this.W = t, this.Nf = n, this.Lf = i, this.t = r, this.Ff = null, this.Hf = !1, this.Df = !1, this.Bf = 1, this.Wf = !1, this.zf = {
                    commit: [],
                    discard: []
                }, this.Mh = new pl(this.t), this.qf = new Al({
                    wdx: this.t,
                    window: this.W
                }), this.Vf = new El(this.qf)
            }
            return t.prototype.init = function() {
                var t = this,
                    n = this.t,
                    r = this.W,
                    e = this.Nf;
                ! function(t) {
                    ht(t)
                }(n), Zu(0, r);
                var s = function() {
                    h(r, w),
                        function(t, n) {
                            n in t || (t[n] = {});
                            try {
                                t[n][Ti] = !0
                            } catch (t) {}
                        }(r, e),
                        function(t, n) {
                            var r = function(t, n) {
                                var r = t.snapshot;
                                try {
                                    if (rr(n)) return i(i({}, r), {
                                        status: 1
                                    });
                                    if (!n.document || 0 !== r.status) return r;
                                    var e = function(t, n) {
                                        if (!yl(t.Set)) return n;
                                        var r = n.functions,
                                            e = new Set,
                                            s = {},
                                            o = i({}, n.helpers);
                                        if (o.functionToString = function(t, n) {
                                                var i, r, e = null === (i = t["__core-js_shared__"]) || void 0 === i ? void 0 : i.inspectSource;
                                                if (e) {
                                                    var s = function() {
                                                        return e(this)
                                                    };
                                                    if (Te(s, 2)) return s
                                                }
                                                var o = null === (r = t["__core-js_shared__"]) || void 0 === r ? void 0 : r["native-function-to-string"];
                                                if (Te(o)) return o;
                                                var u = n[Re];
                                                return Te(u) ? u : Te(n) ? n : void 0
                                            }(t, o.functionToString), !o.functionToString) return n;
                                        var u = !1;
                                        for (var a in r) r[a] ? (s[a] = Ke(o.functionToString, r[a]), s[a] || (s[a] = Oe(o.functionToString, o, a)), s[a] ? s[a] !== r[a] && (u = !0) : (u = !0, e.add(a))) : s[a] = void 0;
                                        return {
                                            status: e.size > 0 ? 2 : 1,
                                            functions: u ? s : r,
                                            helpers: o,
                                            errors: [],
                                            dirty: e
                                        }
                                    }(n, r);
                                    if (1 === e.status) return e;
                                    o(function() {
                                        return "The window is dirty; rebuilding Windex from a fresh global."
                                    });
                                    var s = function(t) {
                                        var n = t.document.createElement("iframe");
                                        return n.id = "FullStory-iframe", n.className = "fs-hide", n.style.display = "none", n
                                    }(n);
                                    try {
                                        (function(t) {
                                            var n = t.document,
                                                i = n.documentElement,
                                                r = n.body || n.head || i || n;
                                            return function(t) {
                                                return !!Li(t, "_fs_windex_iframe", "boolean")
                                            }(t) ? r : i || r
                                        })(n).appendChild(s)
                                    } catch (t) {
                                        return o(function() {
                                            return "windex iframe failed to be added to page, skipping snapshot."
                                        }), i(i({}, r), {
                                            status: 1
                                        })
                                    }
                                    if (!s.contentWindow) return o(function() {
                                        return "windex iframe has no contentWindow, skipping snapshot."
                                    }), i(i({}, r), {
                                        status: 1
                                    });
                                    var u = na(s.contentWindow, 1);
                                    u.dirty = e.dirty;
                                    var a = K(s);
                                    return bl && a && (s.contentWindow.close(), a.removeChild(s)), 3 === u.status ? (o(function() {
                                        return "windex iframe is unrecoverable, using original snapshot."
                                    }), i(i({}, r), {
                                        status: 1
                                    })) : u
                                } catch (t) {
                                    return ve("windex#createClean", {
                                        err: t
                                    }), i(i({}, r), {
                                        status: 1
                                    })
                                }
                            }(t, n);
                            t.rebuildFromSnapshot(r)
                        }(n, r), t.$f(), t.Gf(), f(r, w), t.Vf.addEvent({
                            type: qf.INTERNAL_FS_INIT,
                            data: {}
                        })
                };
                ! function(t, n) {
                    try {
                        return Ti in (t[n] || {})
                    } catch (t) {
                        return !1
                    }
                }(r, e) && function(t, n, i, r) {
                    var e, s, o, u;
                    try {
                        return !(! function(t) {
                            var n;
                            try {
                                return Boolean(null === (n = ji(t)) || void 0 === n ? void 0 : n.hasAttribute("data-fs-is-mobile"))
                            } catch (t) {
                                return !1
                            }
                        }(n) && n.self === n.top && (L(null === (e = n._fs_native_msg_handler) || void 0 === e ? void 0 : e.webShouldCapture) ? (Oi(n, i)._init_callback = I(function() {
                            return r()
                        }), n._fs_native_msg_handler.webShouldCapture(i, n.location.href), 1) : L(null === (u = null === (o = null === (s = n.webkit) || void 0 === s ? void 0 : s.messageHandlers) || void 0 === o ? void 0 : o._fs_native_msg_handler) || void 0 === u ? void 0 : u.postMessage) && (Oi(n, i)._init_callback = I(function() {
                            return r()
                        }), n.webkit.messageHandlers._fs_native_msg_handler.postMessage([4, n.location.href, i]), 1)))
                    } catch (t) {
                        return ve("webviewRecording#shouldInitWebviewRecordingIfWebView", {
                            err: t,
                            namespace: i,
                            location: n.location.href
                        }), !0
                    }
                }(0, r, e, s) && s()
            }, t.prototype.Qf = function(t) {
                var n, r, e, s, u, a, c, h, f, v, l = this;
                this.La = function(t, n, i) {
                    var r = i;
                    try {
                        n.filter(function(t) {
                            return t[0] === Uv.Init
                        }).forEach(function(n) {
                            n[0];
                            var i = n[1];
                            if (i) {
                                var e = jl(t, i),
                                    s = e[0],
                                    o = e[1];
                                0 === s.unrecoverable.length && o && (r = Ll(null != r ? r : {}, o))
                            }
                        })
                    } catch (t) {}
                    return r
                }(this.t, t, this.La), this.Ff = function(t, n, r, e) {
                    var s, u = null !== (s = null == r ? void 0 : r.env) && void 0 !== s ? s : {},
                        a = function(t, n) {
                            var r = Hr(t.orgId, {
                                host: t.host,
                                appHost: t.appHost,
                                recHost: t.recHost,
                                recSettingsHost: t.recSettingsHost,
                                script: t.script
                            });
                            return i(i({}, t), {
                                host: r.host,
                                appHost: r.appHost || Cl,
                                captureOnStartup: 0 != t.captureOnStartup,
                                namespace: n,
                                recHost: r.recHost || Cl,
                                recSettingsHost: r.recSettingsHost || Cl,
                                scheme: t.scheme || Tl,
                                script: r.script,
                                sessionUid: t.sessionUid,
                                tabId: t.tabId
                            })
                        }(u.isolated ? u : i(i({}, function(t, n) {
                            return {
                                appHost: Wi(t) || Cl,
                                assetMapId: Vi(t),
                                beacon: or(t),
                                captureOnStartup: qi(t),
                                cleanValueGetter: mr(t),
                                clientStore: ar(t),
                                cookieDomain: $i(t),
                                delayOnInteraction: Sr(t),
                                enableDataLayer: dr(t),
                                enablePredictions: lr(t),
                                disableResume: vr(t),
                                forceLocalResources: er(t),
                                host: Fi(t),
                                identityStore: cr(t),
                                isOuterScript: Xi(t),
                                isWayfinder: fr(t),
                                multiStorage: hr(t),
                                namespace: n,
                                networkBudget: yr(t),
                                orgId: zi(t) || Cl,
                                pageStart: Zi(t),
                                preHooks: br(t),
                                ready: Gi(t),
                                recHost: Di(t) || Cl,
                                recSettingsHost: Bi(t) || Cl,
                                replayFlags: Ji(t),
                                request: sr(t),
                                runInIframe: Qi(t),
                                scheme: Tl,
                                script: Hi(t),
                                scrubNavLight: gr(t),
                                settings: ur(t),
                                skipIframeInjection: wr(t),
                                snippetVersion: Ir(t, n),
                                transport: Yi(t),
                                useMockProtocol: nr(t),
                                useSocket: tr(t),
                                useWebWorker: ir(t)
                            }
                        }(t, n)), u), n);
                    return e && (a.captureOnStartup = !0), a.orgId && -1 === a.orgId.indexOf("FULLSTORY_KEY") ? a.script || a.skipIframeInjection ? a.recHost ? a.recSettingsHost ? a.appHost ? ("localhost:8080" === a.recHost && (a.scheme = "http:"), o(function() {
                        var t, n;
                        return "\n    captureOnStartup: ".concat(a.captureOnStartup, "\n    cdn host: ").concat(a.recSettingsHost, "\n    disableResume: ").concat(a.disableResume, "\n    orgId: ").concat(a.orgId, "\n    recording host: ").concat(a.recHost, "\n    script: ").concat(null !== (t = a.script) && void 0 !== t ? t : "", "\n    sessionUid: ").concat(null !== (n = a.sessionUid) && void 0 !== n ? n : "", "\n  ")
                    }), a) : (o(function() {
                        return "Missing global _fs_host or _fs_app_host. Recording disabled."
                    }), null) : (o(function() {
                        return "Missing global _fs_host or _fs_rec_settings_host. Recording disabled."
                    }), null) : (o(function() {
                        return "Missing global _fs_host or _fs_rec_host. Recording disabled."
                    }), null) : (o(function() {
                        return "Missing global _fs_host or _fs_script. Recording disabled."
                    }), null) : (o(function() {
                        return "Missing global _fs_org. Recording disabled."
                    }), null)
                }(this.W, this.Nf, this.La, this.Wf), this.Ff && (this.Xf = (u = this.Ff, a = this.W, h = u.transport, u.isOuterScript ? (u.runInIframe && console.error("Both _fs_is_outer_script and _fs_run_in_iframe are set to true; this indicates a configuration error"), c = !1) : a !== top ? c = !0 : h ? u.orgId && h.init && h.init(u.orgId) && (c = !0) : c = !1, c), this.Df = Er(this.W, this.Nf), f = this.t, v = {
                    beaconFn: null !== (n = this.Ff.beacon) && void 0 !== n ? n : Wr(this.W),
                    getPathname: function() {
                        return l.W.location.pathname
                    },
                    inFrame: null !== (r = this.Xf) && void 0 !== r && r,
                    getLanguage: function() {
                        return it(l.t, l.W) || "en"
                    },
                    orgId: this.Ff.orgId,
                    origin: (null === (e = this.W.location) || void 0 === e ? void 0 : e.origin) || "",
                    recHost: this.Ff.recHost,
                    useMockProtocol: null !== (s = this.Ff.useMockProtocol) && void 0 !== s && s
                }, ee = new ie(f, v), void 0 === this.Xf && o(function() {
                    return "Iframe Status could not be determined. Recording disabled."
                }), Lr(function() {
                    var t = l.Ff;
                    t && !t.isolated && function(t) {
                        var n = t.split("."),
                            i = n[0],
                            r = n[1],
                            e = Number(i),
                            s = Number(r);
                        return !isNaN(e) && !isNaN(s) && (e > 2 || 2 === e && s >= 1)
                    }(t.snippetVersion) && function(t, n) {
                        Ar(t, "_fs_host", n.host), Ar(t, "_fs_script", n.script), Ar(t, "_fs_org", n.orgId), Ar(t, "_fs_namespace", n.namespace)
                    }(l.W, {
                        host: t.host,
                        script: t.script,
                        orgId: t.orgId,
                        namespace: t.namespace
                    })
                }))
            }, t.prototype.getCurrentSessionURL = function(t) {
                return this.Jf(t ? "url.now" : "url")
            }, t.prototype.getCurrentSession = function() {
                return this.Jf("id")
            }, t.prototype.getFullstoryId = function(t) {
                return Ps(t)
            }, t.prototype.Jf = function(t) {
                return this.Yf ? Pl(this.Yf, t) : null
            }, t.prototype.Zf = function() {
                var t = this.Ff;
                if (!t) return null;
                var n = {
                    appHost: t.appHost,
                    namespace: t.namespace,
                    orgId: t.orgId,
                    recHost: t.recHost,
                    recSettingsHost: t.recSettingsHost,
                    scheme: t.scheme,
                    snippetVersion: t.snippetVersion
                };
                ["assetMapId", "captureOnStartup", "cookieDomain", "delayOnInteraction", "enableDataLayer", "enablePredictions", "disableResume", "forceLocalResources", "isolated", "isOuterScript", "isWayfinder", "networkBudget", "replayFlags", "runInIframe", "script", "scrubNavLight", "sessionUid", "skipIframeInjection", "tabId", "useMockProtocol", "useNamespace", "useSocket", "useWebWorker"].forEach(function(i) {
                    return function(t, n, i) {
                        void 0 !== n[i] && (t[i] = n[i])
                    }(n, t, i)
                });
                var i = {
                        env: n
                    },
                    r = this.Mh.getCurrentUser();
                return r && (i.user = r), i
            }, t.prototype.enableConsole = function() {
                this._api(Uv.SetConfig, {
                    console: !0
                })
            }, t.prototype.disableConsole = function() {
                this._api(Uv.SetConfig, {
                    console: !1
                })
            }, t.prototype.restart = function() {
                this._api(Uv.Restart)
            }, t.prototype.shutdown = function() {
                this._api(Uv.Shutdown)
            }, t.prototype.log = function() {
                for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                this._api(Uv.Log, t)
            }, t.prototype.tv = function(t) {
                void 0 === t && (t = 1), this.Bf = 1, this.Yf && !this.nv ? (this.Yf.shutdown(t), this.Yf = null, this.Xf || this.Mh.unloadCrossPageVars(t), this.Vf.addEvent({
                    type: qf.SHUTDOWN,
                    data: {
                        reason: t
                    }
                })) : o(function() {
                    return "Recording already shut down."
                })
            }, t.prototype.iv = function(t) {
                if (void 0 === t && (t = !1), 4 !== this.Bf) {
                    if (this.nv) return this.nv(), void(this.nv = null);
                    if (this.Yf) {
                        if (!t) return void o(function() {
                            return "Recording already started."
                        });
                        this.tv(2)
                    }
                    this.rv(!0)
                } else o(function() {
                    return "Recording is not supported."
                })
            }, t.prototype.ou = function(t, n) {
                return r(this, void 0, void 0, function() {
                    var i;
                    return e(this, function(r) {
                        switch (r.label) {
                            case 0:
                                return n && null == this.Oh ? (o(function() {
                                    return "Can't re-identify from an iframe"
                                }), [2]) : 2 === this.Bf ? (this.ev = [t, n], [2]) : (this.tv(t), [4, wo(this.t, this.W, 0)]);
                            case 1:
                                return r.sent(), [4, wo(this.t, this.W, 0)];
                            case 2:
                                return r.sent(), n && this.Oh && td(this.Oh), 3 === t && (null === (i = this.Ff) || void 0 === i ? void 0 : i.disableResume) || this.iv(), [2]
                        }
                    })
                })
            }, t.prototype._api = function(t, n, i, r, e, s) {
                var o, u = "start" === t || "restart" === t,
                    a = null != r ? r : function(t) {
                        o = t
                    },
                    c = [t, n, i, a, e, s];
                if (t === Uv.GetConfig) return a(this.Zf()), o;
                if (4 !== this.Bf) {
                    if (!e || 1 !== this.Bf || u) return !this.Yf || this.ev ? (kr(this.W, c, this.Nf), void(u && this.iv())) : (this.sv(c), o);
                    Dl(e, this.Ff ? Tn.ShutdownMessage : Tn.DefaultRecDisabledMessage)
                } else Dl(e)
            }, t.prototype.sv = function(t) {
                var n;
                if (this.Yf) {
                    var i = null !== (n = this.ov(this.Yf, [t])) && void 0 !== n ? n : {
                            reidentified: !1,
                            applyApi: function() {}
                        },
                        r = i.applyApi,
                        e = i.sideEffects,
                        s = i.initConfig,
                        o = i.observingStart,
                        u = i.recordingShouldBeEnabled,
                        a = i.reidentified,
                        c = i.nextAppId,
                        h = i.userChange;
                    Zl(this.Oh, a, c), a ? (kr(this.W, t, this.Nf), this.ou(4, !0)) : (this.uv(this.Yf, {
                        applyApi: r,
                        sideEffects: e,
                        initConfig: s,
                        observingStart: o,
                        recordingShouldBeEnabled: u
                    }), this.av(h)), void 0 !== u && (u ? this.iv() : this.tv(1))
                }
            }, t.prototype.ov = function(t, n) {
                var i, r = this;
                return function(t, n) {
                    for (var i, r, e, s, u, a, c, h, f, v, l, d, p = n.appHashKey, g = n.inFrame, w = n.initConfig, m = n.inWebView, y = n.getConfig, b = n.recorder, S = n.recordingObserver, _ = n.state, k = n.vars, A = n.windex, E = function(t, n) {
                            for (var i = [], r = 0, e = n; r < e.length; r++) {
                                var s = e[r],
                                    o = s[0],
                                    u = s[1],
                                    a = s[2],
                                    c = s[3],
                                    h = s[4],
                                    f = s[5],
                                    v = xl(t, o, u);
                                v && (v.source = "string" == typeof a ? {
                                    integration: a
                                } : a, v.resolve = c, v.reject = h, v.apiVersion = 2 === f ? 2 : 1, i.push(v))
                            }
                            return i
                        }(A, t), C = [], T = !1, P = !1, x = [], R = [], M = function(t) {
                            if (k) {
                                var n = function(t, n) {
                                        switch (n) {
                                            case "":
                                                return "";
                                            case void 0:
                                                return t;
                                            default:
                                                return Fh(n)
                                        }
                                    }(p, v),
                                    i = k.api(t, n),
                                    r = i.events,
                                    e = i.reidentify,
                                    s = i.appId;
                                i.userChanged && (l = {
                                    user: k.getCurrentUser()
                                }), e && (C = [], T = !0, R.push.apply(R, x), x = []), void 0 !== s && (v = s), C.push.apply(C, r)
                            }
                        }, K = function(t, n) {
                            !1 !== a || -1 !== zl.indexOf(t.operation) ? x.push(Hl(t.resolve, t.reject, n)) : R.push(Hl(t.resolve, t.reject, n))
                        }, j = function(t, n) {
                            R.push(Hl(t.resolve, t.reject, void 0, n))
                        }, O = function(t) {
                            try {
                                if (o(function() {
                                        return "Processing api: ".concat(t.operation)
                                    }), g && ! function(t, n) {
                                        if (-1 === Wl.indexOf(t.operation)) return !1;
                                        if (t.operation === Uv.SetProperties) switch (t.option.type) {
                                            case Zt.Document:
                                                return !0;
                                            case Zt.User:
                                                return n && ! function(t) {
                                                    try {
                                                        var n = t.option.properties;
                                                        if (H(n) && ("uid" in n)) return !0
                                                    } catch (t) {}
                                                    return !1
                                                }(t);
                                            case Zt.Page:
                                                return n;
                                            default:
                                                return !0
                                        }
                                        return !0
                                    }(t, m)) {
                                    var n = "FS.".concat(t.operation, "() is not available in an inner frame");
                                    return P || (P = !0, o(function() {
                                        return n
                                    })), j(t, n), "continue"
                                }
                                switch (t.operation) {
                                    case Uv.Restart:
                                    case Uv.Start:
                                        a = !0, K(t);
                                        break;
                                    case Uv.Shutdown:
                                        K(t), a = !1;
                                        break;
                                    case Uv.Log:
                                        var v = t.option,
                                            l = v.level,
                                            p = v.msg,
                                            k = b.console().logEvent(null != l ? l : "log", p ? [p] : [], "fs");
                                        k && C.push(k), K(t);
                                        break;
                                    case Uv.SetIdentity:
                                        var E = function(n) {
                                            M({
                                                operation: Uv.SetProperties,
                                                option: n,
                                                source: t.source,
                                                resolve: t.resolve,
                                                reject: t.reject,
                                                apiVersion: t.apiVersion
                                            })
                                        };
                                        t.option && "object" == typeof t.option ? (Object.prototype.hasOwnProperty.call(t.option, "consent") && (f = null !== (i = t.option.consent) && void 0 !== i && i), Object.prototype.hasOwnProperty.call(t.option, "uid") && E({
                                            type: "user",
                                            properties: {
                                                uid: t.option.uid
                                            }
                                        }), Object.prototype.hasOwnProperty.call(t.option, "properties") && E({
                                            type: "user",
                                            properties: null !== (r = t.option.properties) && void 0 !== r ? r : {},
                                            schema: null !== (e = t.option.schema) && void 0 !== e ? e : {}
                                        }), (null === (s = t.option) || void 0 === s ? void 0 : s.anonymous) && E({
                                            type: "user",
                                            properties: {
                                                uid: !1
                                            }
                                        })) : E({
                                            type: "user",
                                            properties: {
                                                uid: t.option
                                            }
                                        }), K(t);
                                        break;
                                    case Uv.TrackEvent:
                                    case Uv.SetPage:
                                    case Uv.SetProperties:
                                        M(t), K(t);
                                        break;
                                    case Uv.GetSession:
                                        K(t, function() {
                                            var n;
                                            return Pl(b, null === (n = t.option) || void 0 === n ? void 0 : n.format)
                                        });
                                        break;
                                    case Uv.GetConfig:
                                        t.resolve && I(t.resolve)(y());
                                        break;
                                    case Uv.SetConfig:
                                        var T = t.option.console;
                                        c = T, K(t);
                                        break;
                                    case Uv.Stat:
                                        var x = t.option,
                                            R = x.event_type,
                                            O = x.properties;
                                        C.push(Yf(A, R, O)), K(t);
                                        break;
                                    case Uv.Observe:
                                        var U = t.option,
                                            N = U.type,
                                            L = U.callback,
                                            F = null == S ? void 0 : S.registerListener(N, L);
                                        if (null == F ? void 0 : F.failed) {
                                            j(t, ql);
                                            break
                                        }
                                        N === qf.START && (h = !0), K(t, F);
                                        break;
                                    case Uv.Source:
                                        var D = Mv({
                                            source: t.option.source,
                                            type: "default",
                                            entrypoint: "source"
                                        });
                                        C.push(D), K(t);
                                        break;
                                    case Uv.Init:
                                        if (1 !== _) {
                                            var B = "Capture already started - init rejected.";
                                            o(function() {
                                                return B
                                            }), j(t, B);
                                            break
                                        }
                                        var W = jl(A, t.option),
                                            z = W[0],
                                            q = W[1];
                                        if (z.unrecoverable.length > 0 || !q) {
                                            var V = "Init config rejected: ".concat(z.unrecoverable.join(",\n"));
                                            o(function() {
                                                return V
                                            }), j(t, V);
                                            break
                                        }
                                        if (z.recoverable.length > 0) {
                                            var $ = "Init config partially rejected: ".concat(z.recoverable.join(",\n"));
                                            o(function() {
                                                return $
                                            })
                                        }
                                        d = Ll(null !== (u = null != d ? d : w) && void 0 !== u ? u : {}, q), K(t);
                                        break;
                                    case Uv.GetFullstoryId:
                                        var G = t.option;
                                        K(t, function() {
                                            return Ps(G)
                                        });
                                        break;
                                    default:
                                        Ho(0, "invalid operation")
                                }
                            } catch (n) {
                                var Q = "unknown error evaluating API";
                                ve(Q, {
                                    err: n,
                                    op: t.operation
                                }), o(function() {
                                    return "".concat(Q, " ").concat(n)
                                }), j(t, Q)
                            }
                        }, U = 0, N = E; U < N.length; U++) O(N[U]);
                    return {
                        applyApi: function() {
                            for (var t = b.queue(), n = 0, i = C; n < i.length; n++) {
                                var r = i[n];
                                t.enqueue(r)
                            }
                            void 0 !== f && b.setConsent(f), void 0 !== d && b.setInitConfig(d), "boolean" == typeof c && (c ? b.console().start({
                                ConsoleWatcher: !0
                            }) : b.console().stop())
                        },
                        initConfig: d,
                        recordingShouldBeEnabled: a,
                        reidentified: T,
                        nextAppId: v,
                        observingStart: h,
                        userChange: l,
                        sideEffects: {
                            commit: x,
                            discard: R
                        }
                    }
                }(n, {
                    appHashKey: null === (i = this.Oh) || void 0 === i ? void 0 : i.getAppKeyHash(),
                    inFrame: this.Xf,
                    inWebView: this.Df,
                    initConfig: this.La,
                    getConfig: function() {
                        return r.Zf()
                    },
                    recorder: t,
                    recordingObserver: this.qf,
                    state: this.Bf,
                    vars: this.Mh,
                    windex: this.t
                })
            }, t.prototype.av = function(t) {
                t && this.Vf.addEvent({
                    type: qf.INTERNAL_USER,
                    data: t
                })
            }, t.prototype.uv = function(t, n) {
                var i, r, e, s = n.applyApi,
                    o = n.sideEffects,
                    u = n.initConfig,
                    a = n.observingStart,
                    c = n.recordingShouldBeEnabled;
                s();
                var h = !1 === c,
                    f = t.getIsSessionReady();
                if (h) Bl(o, !1, Tn.ShutdownMessage);
                else if (f) {
                    Bl(o);
                    var v = t.getCurrentSessionURL();
                    if (a && v) {
                        var l = t.orgSettings();
                        this.Vf.addEvent({
                            type: qf.START,
                            data: {
                                sessionUrl: v,
                                settings: l,
                                env: null === (e = this.Zf()) || void 0 === e ? void 0 : e.env
                            },
                            once: !0
                        })
                    }
                } else(i = this.zf.commit).push.apply(i, o.commit), (r = this.zf.discard).push.apply(r, o.discard);
                void 0 !== u && (this.La = u)
            }, t.prototype._cookies = function() {
                return this.Oh ? this.Oh.getCookies() : (o(function() {
                    return "Error in FS integration: Can't get cookies from inside an iframe"
                }), null)
            }, t.prototype._setCookie = function(t, n) {
                this.Oh ? this.Oh.setCookie(t, n) : o(function() {
                    return "Error in FS integration: Can't set cookies from inside an iframe"
                })
            }, t.prototype._withEventQueue = function(t, n) {
                var i = this;
                if (this.Yf) {
                    var r = this.Yf.queue(),
                        e = this.Yf.pageSignature();
                    null != r && null != e ? t === e ? n(r) : o(function() {
                        return Us(i.t)({
                            msg: "Error in _withEventQueue: Page Signature mismatch",
                            pageSignature: e,
                            callerSignature: t
                        }, 1024)
                    }) : o(function() {
                        return "Error getting event queue or page signature: Recorder not initialized"
                    })
                } else o(function() {
                    return "Error in FS integration: Recorder not initialized"
                })
            }, t.prototype._withRecorder = function(t, n) {
                var i = this;
                if (this.Yf) {
                    var r = this.Yf.pageSignature();
                    null !== r ? void 0 === t || t === r ? n(this.Yf) : o(function() {
                        return Us(i.t)({
                            msg: "Error in _withRecorder: Page Signature mismatch",
                            pageSignature: r,
                            callerSignature: t
                        }, 1024)
                    }) : o(function() {
                        return "Error getting page signature: Recorder not initialized"
                    })
                } else o(function() {
                    return "Error in FS integration: Recorder not initialized"
                })
            }, t.prototype.$f = function() {
                var t = Oi(this.W, this.Nf);
                if (t)
                    for (var n = 0, i = ["disableConsole", "enableConsole", "getCurrentSession", "getCurrentSessionURL", "getFullstoryId", "log", "restart", "shutdown", "_api", "_withEventQueue", "_withRecorder", "_cookies", "_setCookie"]; n < i.length; n++) {
                        var r = i[n];
                        t[r] = J(this[r], this, X)
                    } else o(function() {
                        return "Missing browser API namespace; couldn't initialize API."
                    })
            }, t.prototype.Gf = function() {
                var t, n, i, r, e = this;
                if (o(function() {
                        return "script version ".concat(Jr.Ver, " (compiled at ").concat(Jr.TS, ")")
                    }), t = this.t, n = this.W, i = this.Nf, r = Zu(0, n), !((Er(n, i) || !Ee) && n.postMessage && n.MutationObserver && yl(r, function(t, n) {
                        n.disconnect()
                    }) && yl(n.Map) && yl(n.Set) && yl(n.WeakMap) && 3 !== t.snapshot.status || (function(t) {
                        try {
                            if (3 === t.snapshot.status) {
                                for (var n = {}, i = 0; i < t.snapshot.errors.length; i++) n["error".concat(i + 1)] = t.snapshot.errors[i];
                                we || ve("windexFailure", n), t.snapshot.errors.forEach(function(t) {
                                    return o(function() {
                                        return t
                                    })
                                })
                            }
                        } catch (t) {}
                    }(t), o(function() {
                        return "missing required browser features"
                    }), 0))) return this.Bf = 4, void $l(this.W, this.Nf, this.qf, this.Vf);
                var s = [];
                if (s.push.apply(s, _r(this.W, this.Nf)), this.Qf(s), !ml(this.W, this.Ff)) return o(function() {
                    return "Fullstory recording for this page is NOT allowed within an iFrame."
                }), this.Bf = 4, void $l(this.W, this.Nf, this.qf, this.Vf, s);
                this.cv(s, !1), this.hv(), this.W.addEventListener("message", fe(function(t) {
                    return e.fv(t)
                }, "wnd#messageListener"))
            }, t.prototype.vv = function() {
                var t, n = this;
                (null === (t = this.Ff) || void 0 === t ? void 0 : t.orgId) && (this.Oh = new il({
                    wdx: this.t,
                    window: this.W
                }, this.Ff, function(t) {
                    for (var i, r = 0, e = t; r < e.length; r++) {
                        var s = e[r];
                        null === (i = n.Yf) || void 0 === i || i.queue().enqueue({
                            Kind: 79,
                            Args: s
                        })
                    }
                }, this.Xf))
            }, t.prototype.fv = function(t) {
                if (z(t.data)) {
                    var n = this.Ff;
                    if (n && (t.source === this.W.parent || t.source === this.W)) {
                        var i = Cf({
                            wdx: this.t,
                            window: this.W,
                            options: n
                        }, t.data);
                        switch (i[0]) {
                            case Fn.ShutdownFrame:
                                this.tv(2);
                                break;
                            case Fn.RestartFrame:
                                this.iv(i[1])
                        }
                    }
                }
            }, t.prototype.lv = function(t, n) {
                var r, e = this,
                    s = this.t,
                    o = {
                        wdx: s,
                        window: this.W
                    },
                    u = s.mathRound(null !== (r = I(function() {
                        var t;
                        return null === (t = e.W.performance) || void 0 === t ? void 0 : t.now()
                    })()) && void 0 !== r ? r : -1);
                return {
                    window: this.W,
                    wdx: s,
                    time: new Ws(s),
                    measurer: new Ql(o),
                    taskQueue: new Gl(o, 2e3),
                    options: i({}, this.Ff),
                    recording: {
                        bundleApiVersion: function() {
                            var n, i;
                            return null !== (i = null === (n = t()) || void 0 === n ? void 0 : n.getBundleApiVersion()) && void 0 !== i ? i : "v1"
                        },
                        bundleUploadIntervalMS: function() {
                            var n;
                            return s.mathMax(100, (null === (n = t()) || void 0 === n ? void 0 : n.bundleUploadIntervalMS()) || 5e3)
                        },
                        heartbeatIntervalMS: function() {
                            var n;
                            return s.mathMax(1e3, (null === (n = t()) || void 0 === n ? void 0 : n.heartbeatIntervalMS()) || Tn.HeartbeatIntervalMS)
                        },
                        flags: function() {
                            var n, i;
                            return (null === (i = null === (n = t()) || void 0 === n ? void 0 : n.getPageResponse()) || void 0 === i ? void 0 : i.Flags) || {}
                        },
                        getCurrentSessionURL: function(n) {
                            var i, r;
                            return null !== (r = null === (i = t()) || void 0 === i ? void 0 : i.getCurrentSessionURL(n)) && void 0 !== r ? r : null
                        },
                        identity: this.Oh,
                        inFrame: n,
                        inWebView: this.Df,
                        observer: this.Vf,
                        pageResponse: function() {
                            var n;
                            return null === (n = t()) || void 0 === n ? void 0 : n.getPageResponse()
                        },
                        pageSignature: function() {
                            var n, i;
                            return null !== (i = null === (n = t()) || void 0 === n ? void 0 : n.pageSignature()) && void 0 !== i ? i : null
                        },
                        preroll: u,
                        splitPage: function(t) {
                            return e.ou(t, !1)
                        }
                    },
                    queue: function() {
                        var n;
                        return null === (n = t()) || void 0 === n ? void 0 : n.queue()
                    }
                }
            }, t.prototype.dv = function(t, n) {
                if (n) {
                    for (var i = 0, r = this.Mh.getDocumentVars(); i < r.length; i++) {
                        var e = r[i];
                        t.enqueue(e)
                    }
                    var s = this.Mh.getCrossPageVars();
                    void 0 !== s && t.enqueue(s)
                }
            }, t.prototype.Fa = function(t, n) {
                var i = this;
                return function(r) {
                    var e, s = r.sessionUrl,
                        o = r.settings;
                    i.Wf = !0, i.Bf = 3, n && t.tellAllFramesTo([Fn.RestartFrame]), i.ev && (i.ou(i.ev[0], i.ev[1]), i.ev = null), i.Vf.addEvent({
                        type: qf.START,
                        data: {
                            sessionUrl: s,
                            settings: o,
                            env: null === (e = i.Zf()) || void 0 === e ? void 0 : e.env
                        }
                    }), Bl(i.zf)
                }
            }, t.prototype.Ha = function() {
                var t = this;
                return function() {
                    t.Bf = 4, t.Vf.addEvent({
                        type: qf.SHUTDOWN,
                        data: {
                            reason: 5
                        }
                    }), Bl(t.zf, !0)
                }
            }, t.prototype.pv = function(t, n, i) {
                void 0 === i && (i = !1), this.Bf = 2, t.start(i, this.Fa(t, n), this.Ha()), n && this.Hf && t.onDomLoad()
            }, t.prototype.rv = function(t) {
                var n = [];
                n.push.apply(n, _r(this.W, this.Nf)), this.Qf(n), this.cv(n, t)
            }, t.prototype.cv = function(t, n) {
                if (this.Ff) {
                    var i;
                    this.vv();
                    var r = this.Xf,
                        e = this.lv(function() {
                            return i
                        }, !!r);
                    i = r ? this.Lf.createInnerRecorder(e) : this.Lf.createTopRecorder(e, this.Mh), this.gv(e, i, t, n), this.Yf = i
                } else $l(this.W, this.Nf, this.qf, this.Vf, t)
            }, t.prototype.gv = function(t, n, i, r) {
                var e, s, u, a = this;
                void 0 === r && (r = !1);
                var c, h = !1,
                    f = t.options.assetMapId;
                f && i.unshift([Ei.Vars, [Zt.Document, {
                    assetMapId: f
                }]]), this.Xf || (this.dv(n.queue(), r), n.queue().enqueue({
                    Kind: 58,
                    Args: [14, !1 === (null === (e = this.Ff) || void 0 === e ? void 0 : e.captureOnStartup)]
                }));
                var v = null !== (s = this.ov(n, i)) && void 0 !== s ? s : {
                        applyApi: function() {}
                    },
                    l = v.applyApi,
                    d = v.sideEffects,
                    p = v.initConfig,
                    g = v.recordingShouldBeEnabled,
                    w = v.reidentified,
                    m = v.nextAppId,
                    y = v.observingStart,
                    b = v.userChange;
                this.Xf ? (h = !1, c = !1) : (void 0 !== g ? h = !g : !1 === (null === (u = this.Ff) || void 0 === u ? void 0 : u.captureOnStartup) && (h = !0), c = !!w), Zl(this.Oh, c, m), this.Df || function(t, n) {
                    var i;
                    if (t && ("string" == typeof n && n && n.length < 256 ? i = n : "string" == typeof n && n.length >= 256 && o(function() {
                            return "sessionUid exceeds 256 character limit, ignoring"
                        }), i)) {
                        var r = t.getSessionUid(),
                            e = t.getDiscardedSessionUid();
                        i !== r && i !== e ? (t.setSessionUid(i, 1), t.clearUserSession()) : 3 !== t.getSessionUidState() && i !== e || o(function() {
                            return "FS sessionUid matches cookie but state is discarded; ignoring init until a different sessionUid is provided."
                        })
                    }
                }(this.Oh, t.options.sessionUid), this.uv(n, {
                    applyApi: l,
                    sideEffects: d,
                    initConfig: p,
                    observingStart: y,
                    recordingShouldBeEnabled: g
                }), this.av(b), h ? this.nv = function() {
                    return a.pv(n, r, c)
                } : this.pv(n, r, c)
            }, t.prototype.hv = function() {
                var t = this,
                    n = function() {
                        t.Hf || (t.Hf = !0, t.Yf && t.Yf.onDomLoad())
                    },
                    i = !1,
                    r = function() {
                        i || (i = !0, t.Yf && t.Yf.onLoad())
                    };
                switch (document.readyState) {
                    case "interactive":
                        n();
                        break;
                    case "complete":
                        n(), r()
                }
                this.Hf || document.addEventListener("DOMContentLoaded", fe(n, "doc#domLoadedListener")), i || this.W.addEventListener("load", fe(function(t) {
                    n(), r()
                }, "wnd#loadListener"))
            }, t
        }();

    function Zl(t, n, i) {
        t && (n ? td(t, i) : "" === i ? t.clearAppId() : void 0 !== i && t.setAppId(i))
    }

    function td(t, n) {
        t.clear(), n && t.setAppId(n)
    }! function() {
        try {
            new Yl().init()
        } catch (t) {
            try {
                ve("Conductor#init", {
                    err: t
                })
            } catch (t) {}
            o(function() {
                return "Failed to initialize Fullstory. ".concat(t)
            })
        }
    }()
}();