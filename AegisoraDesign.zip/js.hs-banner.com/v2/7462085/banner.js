var _hsp = window['_hsp'] = window['_hsp'] || [];
_hsp.push(['setBannerSettings', {}]);
_hsp.push(['setCustomizationSettings', {}]);
_hsp.push(['addCookieDomain', '.hs-sites.com']);
_hsp.push(['addCookieDomain', '.hubspotpagebuilder.com']);
_hsp.push(['addCookieDomain', '.zapier.com']);
_hsp.push(['addCookieDomain', '.hubspot.com']);
_hsp.push(['addCookieDomain', '.hsforms.com']);
_hsp.push(['addCookieDomain', '.11x.ai']);
_hsp.push(['addCookieDomain', '.witty-grocery-078812.framer.app']);
_hsp.push(['addCookieDomain', '.zapier-deployment.com']);
_hsp.push(['addCookieDomain', '.zapier-staging.com']);
_hsp.push(['addCookieDomain', '.zapier.framer.website']);
_hsp.push(['setApiBaseUrl', 'https://js.hs-banner.com/v2']);
/**
 * HubSpot Cookie Banner Code Copyright 2026 HubSpot, Inc.  http://www.hubspot.com
 */
! function() {
    var e = [, function(e) {
            e.exports = '#hs-banner-parent *{font-size:inherit;font-family:inherit;background:none;border:none;box-shadow:none;box-sizing:border-box;margin:0;padding:0;display:revert;line-height:1.75em}#hs-banner-parent div,#hs-banner-parent p,#hs-banner-parent span{color:inherit}#hs-banner-parent li{list-style-position:inside}#hs-banner-parent li *{display:inline}#hs-banner-parent .hs-hidden{display:none!important}#hs-banner-parent #hs-banner-gpc{font-size:var(--hs-banner-font-size,14px);font-family:var(--hs-banner-font-family,"Lato"),sans-serif;font-weight:400;color:var(--hs-banner-text-color,#15295a);background:var(--hs-banner-color,#fff);border-radius:var(--hs-banner-corners,12px);box-shadow:0 8px 28px rgba(0,0,0,.28);position:fixed;margin:auto;width:var(--hs-banner-width,67em);max-width:calc(100% - 64px);max-height:calc(100% - 64px);overflow:auto;inset:var(--hs-banner-inset,32px 0 auto 0);z-index:3000000000;transform:translateY(200vh);-webkit-transform:translateY(200vh) translateZ(3000000000px);animation:none;opacity:0}#hs-banner-parent #hs-banner-gpc.hs-banner-optimization-animation{animation:banner_animation .5s forwards}#hs-banner-parent #hs-banner-gpc:focus-visible{outline:none}#hs-banner-gpc #hs-banner-gpc-inner{display:flex;gap:1em;flex-direction:column;padding:var(--hs-banner-padding,2.2em)}#hs-banner-gpc #hs-banner-gpc-header{display:flex;flex-direction:row;justify-content:flex-end}#hs-banner-gpc #hs-banner-gpc-close-button{cursor:pointer;display:block}#hs-banner-gpc #hs-banner-gpc-close-button svg{width:var(--hs-banner-font-size,14px);height:var(--hs-banner-font-size,14px);color:var(--hs-banner-text-color,#15295a)}#hs-banner-parent #hs-eu-cookie-confirmation{font-size:var(--hs-banner-font-size,14px);font-family:var(--hs-banner-font-family,"Lato"),sans-serif;font-weight:400;color:var(--hs-banner-text-color,#15295a);background:var(--hs-banner-color,#fff);border-radius:var(--hs-banner-corners,12px);box-shadow:0 8px 28px rgba(0,0,0,.28);position:fixed;margin:auto;width:var(--hs-banner-width,67em);max-width:calc(100% - 64px);max-height:calc(100% - 64px);overflow:auto;inset:var(--hs-banner-inset,32px 0 auto 0);z-index:3000000000;transform:translateY(200vh);-webkit-transform:translateY(200vh) translateZ(3000000000px);animation:none;opacity:0}@keyframes banner_animation{0%{transform:translateY(200vh);-webkit-transform:translateY(200vh) translateZ(3000000000px);opacity:0}99%{opacity:0}to{transform:translateY(var(--hs-banner-translate-y,0));-webkit-transform:translateY(var(--hs-banner-translate-y,0)) translateZ(3000000000px);opacity:1}}#hs-banner-parent #hs-eu-cookie-confirmation.hs-banner-optimization-animation{animation:banner_animation .5s forwards}#hs-banner-parent #hs-eu-cookie-confirmation:focus-visible{outline:none}#hs-eu-cookie-confirmation #hs-eu-cookie-confirmation-inner{display:flex;gap:1em;flex-direction:column;padding:var(--hs-banner-padding,2.2em)}#hs-eu-cookie-confirmation #hs-eu-header-container{display:var(--hs-banner-close-button-display,none);flex-direction:row;justify-content:flex-end}#hs-eu-cookie-confirmation #hs-eu-close-button{cursor:pointer;display:block}#hs-eu-cookie-confirmation #hs-eu-close-button svg{width:var(--hs-banner-font-size,14px);height:var(--hs-banner-font-size,14px);color:var(--hs-banner-text-color,#15295a)}#hs-eu-cookie-confirmation #hs-eu-cookie-confirmation-buttons-area{display:flex;flex-flow:row wrap;justify-content:flex-end;align-items:baseline}#hs-eu-cookie-confirmation #hs-eu-confirmation-button-group,#hs-eu-cookie-confirmation #hs-eu-opt-in-buttons{display:flex;justify-content:center;flex-flow:row wrap;gap:.5em}#hs-eu-cookie-confirmation #hs-eu-opt-in-buttons{flex-grow:1}#hs-eu-cookie-confirmation #hs-eu-confirmation-button,#hs-eu-cookie-confirmation #hs-eu-cookie-settings-button,#hs-eu-cookie-confirmation #hs-eu-decline-button{flex:1;display:flex;align-items:center;justify-content:center;cursor:pointer;border-radius:var(--hs-banner-button-corners,3em);min-width:11em;height:3.3em}#hs-eu-cookie-confirmation #hs-eu-confirmation-button{color:var(--hs-banner-accept-text-color,#fff);background:var(--hs-banner-accept-color,var(--hs-banner-accentColor,#425b76));border:1px solid var(--hs-banner-accept-border-color,var(--hs-banner-accentColor,#425b76))}#hs-eu-cookie-confirmation #hs-eu-decline-button{color:var(--hs-banner-decline-text-color,var(--hs-banner-accentColor,#425b76));background:var(--hs-banner-decline-color,#fff);border:1px solid var(--hs-banner-decline-border-color,var(--hs-banner-accentColor,#425b76))}#hs-eu-cookie-confirmation #hs-eu-cookie-settings-button{text-decoration:underline;font-weight:800;color:var(--hs-banner-settings-text-color,var(--hs-banner-accentColor,#425b76))}@media print{#hs-banner-gpc,#hs-eu-cookie-confirmation{display:none!important}}'
        }, function(e) {
            e.exports = '#hs-banner-parent #hs-modal{position:fixed;left:0;top:0;width:100%;height:100%;background-color:rgba(0,0,0,.28);display:flex;justify-content:center;align-items:center;z-index:3000000001;-webkit-transform:translateZ(3000000001px)}@media print{#hs-banner-parent #hs-modal{display:none!important}}#hs-banner-parent #hs-modal-content{position:absolute;display:flex;flex-direction:column;gap:1.1em;padding:var(--hs-banner-modal-padding,2.2em);width:min(var(--hs-banner-modal-width,50.3em),100%);max-height:80%;background-color:var(--hs-banner-modal-color,#fafbff);border-radius:var(--hs-banner-modal-corners,12px);box-shadow:0 8px 28px rgba(0,0,0,.28);font-size:var(--hs-banner-modal-font-size,14px);font-family:var(--hs-banner-font-family,"Lato"),sans-serif;font-weight:400;line-height:1.75em;color:var(--hs-banner-modal-text-color,#15295a)}#hs-banner-parent #hs-modal-content:focus-visible{outline:none}#hs-modal-content #hs-modal-header-container{display:flex;flex-direction:row;justify-content:flex-end}#hs-modal-content #hs-modal-close-button{cursor:pointer;display:block}#hs-modal-content #hs-modal-close-button svg{width:var(--hs-banner-modal-font-size,14px);height:var(--hs-banner-modal-font-size,14px);color:var(--hs-banner-modal-text-color,#15295a)}#hs-modal-content #hs-modal-body{overflow:auto}#hs-modal-content #hs-modal-body-container{position:relative;display:flex;flex-flow:column;gap:1.1em;height:100%;width:100%}#hs-modal-content #hs-modal-introduction{display:inline-block}#hs-modal-content #hs-modal-introduction span{font-weight:800;font-size:1.3em;color:inherit}#hs-modal-content #hs-categories-container{display:flex;flex-direction:column;gap:1.1em}#hs-modal-content #hs-categories-container .hs-category-row{display:flex;flex-direction:column;background:var(--hs-banner-modal-cateogry-color,#fff);border-radius:var(--hs-banner-modal-category-corners,var(--hs-banner-modal-corners,12px));padding:2em}#hs-modal-content #hs-categories-container .hs-category-row .hs-toggle-switch-input{appearance:none;position:absolute;top:0;left:0;width:100%!important;height:100%;cursor:pointer}#hs-modal-content #hs-categories-container .hs-category-row .hs-toggle-switch{width:calc(1.7em * 2 + 6px);height:calc(1.7em + 6px);position:relative;background-color:var(--hs-banner-modal-toggle-off-color,#f1f1f1);border:3px solid var(--hs-banner-modal-toggle-off-color,#f1f1f1);border-radius:1.7em;transition:background-color .2s ease,border-color .2s ease}#hs-modal-content #hs-categories-container .hs-category-row .hs-toggle-switch-nob{position:absolute;height:1.7em;width:1.7em;left:0;border-radius:inherit;box-shadow:0 2px 5px rgba(0,0,0,.3);background:var(--hs-banner-modal-cateogry-color,#fff);transition:left .5s ease}#hs-modal-content #hs-categories-container .hs-category-row .hs-toggle-switch.hs-toggle-selected-flag{background-color:var(--hs-banner-modal-toggle-on-color,var(--hs-banner-accentColor,#425b76));border-color:var(--hs-banner-modal-toggle-on-color,var(--hs-banner-accentColor,#425b76))}#hs-modal-content #hs-categories-container .hs-category-row .hs-toggle-switch.hs-toggle-selected-flag .hs-toggle-switch-nob{left:50%}#hs-modal-content #hs-categories-container .description-accordion-arrow{transition:transform .2s;width:var(--hs-banner-modal-font-size,14px);height:var(--hs-banner-modal-font-size,14px);color:var(--hs-banner-modal-category-text-color,#15295a)}#hs-modal-content #hs-categories-container .description-accordion-arrow.rotated{transform:rotate(90deg)}#hs-modal-content #hs-categories-container .hs-category-description{transition:max-height .2s;box-sizing:border-box;overflow:hidden;visibility:hidden}#hs-modal-content #hs-categories-container .hs-category-description.visible{visibility:visible;color:var(--hs-banner-modal-category-text-color,#15295a)}#hs-modal-content #hs-categories-container .hs-category-row-header{display:flex;justify-content:space-between;align-items:center}#hs-modal-content #hs-categories-container .hs-category-label{display:flex;flex-grow:1;gap:1.1em;align-items:center;justify-content:left;font-weight:800;color:var(--hs-banner-modal-category-text-color,#15295a);cursor:pointer}#hs-modal-content #hs-categories-container .hs-always-active-label{color:var(--hs-banner-modal-category-text-color,#15295a)}#hs-modal-content #hs-modal-footer{display:flex;justify-content:flex-end}#hs-modal-content #hs-modal-footer-container{display:flex;justify-content:center;flex-flow:row wrap;gap:.5em}#hs-modal-content #hs-modal-accept-all,#hs-modal-content #hs-modal-decline-all,#hs-modal-content #hs-modal-save-settings{flex:1;display:flex;align-items:center;justify-content:center;border-radius:var(--hs-banner-modal-button-corners,3em);min-width:11em;height:3.3em;cursor:pointer}#hs-modal-content #hs-modal-accept-all{color:var(--hs-banner-modal-accept-text-color,#fafbff);background:var(--hs-banner-modal-accept-color,var(--hs-banner-accentColor,#425b76));border:1px solid var(--hs-banner-modal-accept-border-color,var(--hs-banner-accentColor,#425b76))}#hs-modal-content #hs-modal-decline-all{color:var(--hs-banner-modal-decline-text-color,var(--hs-banner-modal-accept-text-color,#fafbff));background:var(--hs-banner-modal-decline-color,var(--hs-banner-modal-accept-color,var(--hs-banner-accentColor,#425b76)));border:1px solid var(--hs-banner-modal-decline-border-color,var(--hs-banner-modal-accept-border-color,var(--hs-banner-accentColor,#425b76)))}#hs-modal-content #hs-modal-save-settings{color:var(--hs-banner-modal-save-text-color,var(--hs-banner-accentColor,#425b76));background:var(--hs-banner-modal-save-color,#fafbff);border:1px solid var(--hs-banner-modal-save-border-color,var(--hs-banner-accentColor,#425b76))}'
        }],
        t = {};

    function n(o) {
        var i = t[o];
        if (void 0 !== i) return i.exports;
        var s = t[o] = {
            exports: {}
        };
        e[o](s, s.exports, n);
        return s.exports
    }
    n.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        n.d(t, {
            a: t
        });
        return t
    };
    n.d = function(e, t) {
        for (var o in t) n.o(t, o) && !n.o(e, o) && Object.defineProperty(e, o, {
            enumerable: !0,
            get: t[o]
        })
    };
    n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    };
    ! function() {
        "use strict";
        const e = "_hspb_loaded",
            t = "_hsp",
            o = "_hsq",
            i = "_hsGeoTargetingTest",
            s = "_hsGpcSignal",
            r = "_hsScanningMode",
            a = "_hspb_ran",
            c = "hsdbg",
            l = "_hsPrivacyTest",
            d = "hs-eu-cookie-confirmation",
            h = "hs-banner-gpc",
            u = "hs-banner-parent",
            g = "hs-modal",
            _ = "hs-modal-content",
            p = {
                NECESSARY: "necessary",
                ANALYTICS: "analytics",
                ADVERTISEMENT: "advertisement",
                FUNCTIONALITY: "functionality"
            },
            m = "hs-hidden",
            f = "hs-banner-optimization-animation",
            b = "hs-banner-style",
            y = "hs-banner-modal-style",
            v = "disabledHsPopups",
            C = "PRIVACY",
            x = "disableHubSpotCookieBanner",
            k = "hsCookieBannerLoaded",
            S = [...["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE"], ...["IS", "LI", "NO"], "GB"],
            w = "hs-banner-google-font",
            E = "google-font-injected",
            T = [
                [0, 400],
                [0, 700],
                [1, 400]
            ],
            O = "https://fonts.googleapis.com/css2";
        class I {
            constructor(e, t) {
                this.win = e;
                this.doc = t;
                this.hasLoadedBaseStyle = !1;
                this.hasLoadedCbcStyle = !1
            }
            setHasLoadedBaseStyle(e) {
                this.hasLoadedBaseStyle = e
            }
            setHasLoadedCbcStyle(e) {
                this.hasLoadedCbcStyle = e
            }
            getWindow() {
                return this.win
            }
            getDocument() {
                return this.doc
            }
            getNavigator() {
                return this.getWindow().navigator
            }
            getLocation() {
                return this.getWindow().location
            }
            getPathname() {
                return this.getLocation().pathname
            }
            getHostname() {
                try {
                    return this.getLocation().hostname
                } catch (e) {
                    return this.getDocument().domain
                }
            }
            getHasLoadedBaseStyle() {
                return this.hasLoadedBaseStyle
            }
            getHasLoadedCbcStyle() {
                return this.hasLoadedCbcStyle
            }
        }
        const A = new I(window, document);

        function L() {
            return A
        }
        class N {
            constructor(e) {
                this.logPrepend = "[HubSpot cookie banner]";
                this.context = e
            }
            info(e) {
                this.isDebugEnabled() && this.context.getWindow().console.log(`${this.logPrepend} ${e}`)
            }
            debug(e) {
                this.isDebugEnabled() && this.context.getWindow().console.debug(`${this.logPrepend} ${e}`)
            }
            error(e) {
                this.isDebugEnabled() && this.context.getWindow().console.error(`${this.logPrepend} ${e}`)
            }
            isDebugEnabled() {
                return this.context.getDocument().location.search.includes(c)
            }
        }
        var B = new N(L());
        const R = [0, 0, 0, 0],
            P = e => e.some((e => e > 0)),
            D = (e, t) => (e.map(((e, n) => e - t[n])).find((e => 0 !== e)) || 0) >= 0,
            G = e => {
                const {
                    allUrlsAndLocations: t,
                    path: n,
                    targetedCountries: o,
                    targetedRegions: i
                } = e;
                return t ? {
                    targetedPathPrefix: "",
                    targetedCountries: [],
                    targetedRegions: [],
                    wildcard: !1
                } : {
                    targetedPathPrefix: n || "",
                    targetedCountries: o || [],
                    targetedRegions: i || [],
                    wildcard: !1
                }
            },
            M = (e, t, n, o) => {
                const i = e.targetedPathPrefix.length + 1;
                if (!t.startsWith(e.targetedPathPrefix)) return R;
                const s = e.targetedCountries.length > 0 || e.targetedRegions.length > 0,
                    r = void 0 !== n && e.targetedCountries.includes(n),
                    a = n && o ? `${n}-${o}` : void 0,
                    c = void 0 !== a && e.targetedRegions.includes(a);
                return !s || r || c ? [e.wildcard ? 0 : 1, c ? 1 : 0, r ? 1 : 0, i] : R
            },
            U = {
                TOP: 0,
                BOTTOM: 1,
                BOTTOM_LEFT: 2,
                BOTTOM_RIGHT: 3,
                CENTER: 4
            },
            F = new Set(Object.values(U));

        function $(e) {
            return null != e && F.has(e) ? e : U.TOP
        }

        function Y(e) {
            return {
                position: $(e.position),
                accentColor: e.accentColor,
                showCloseButton: e.showCloseButton || !1
            }
        }
        const H = Symbol("__RELATIVE__"),
            V = e => e ? Array.isArray(e) ? {
                remove_element_contents: Object.fromEntries(e.map((e => [e, !0]))),
                remove_all_contents: !1
            } : {
                remove_element_contents: {},
                remove_all_contents: !0
            } : {
                remove_element_contents: {},
                remove_all_contents: !1
            };
        class W {
            constructor(e = {}) {
                const {
                    elements: t = [],
                    attributes: n = {},
                    allow_comments: o = !1,
                    protocols: i = {},
                    add_attributes: s = {},
                    remove_contents: r
                } = e, {
                    remove_element_contents: a,
                    remove_all_contents: c
                } = V(r);
                this.config = {
                    elements: t,
                    attributes: n,
                    allow_comments: o,
                    protocols: i,
                    add_attributes: s,
                    remove_element_contents: a,
                    remove_all_contents: c
                };
                this.allowed_elements = Object.fromEntries(t.map((e => [e, !0])))
            }
            cleanNode(e) {
                const t = document.createDocumentFragment();
                this.current_element = t;
                e.childNodes.forEach((e => this._cleanNode(e)));
                t.normalize();
                return t
            }
            _cleanNode(e) {
                switch (e.nodeType) {
                    case Node.ELEMENT_NODE:
                        this.cleanElement(e);
                        break;
                    case Node.TEXT_NODE:
                    case Node.ENTITY_REFERENCE_NODE:
                        this.current_element.appendChild(e.cloneNode(!1));
                        break;
                    case Node.COMMENT_NODE:
                        this.config.allow_comments && this.current_element.appendChild(e.cloneNode(!1));
                        break;
                    default:
                        console.warn("unknown node type", e.nodeType)
                }
            }
            cleanElement(e) {
                const t = this.current_element,
                    n = e.nodeName.toLowerCase();
                if (this.allowed_elements[n]) {
                    const o = document.createElement(e.nodeName);
                    this.current_element = o;
                    t.appendChild(o);
                    this.processAttributes(e, n, o);
                    this.addConfiguredAttributes(n, o)
                }
                this.config.remove_all_contents || this.config.remove_element_contents[n] || e.childNodes.forEach((e => this._cleanNode(e)));
                this.current_element = t
            }
            processAttributes(e, t, n) {
                const o = this.config.attributes[t];
                o && o.forEach((o => {
                    const i = e.attributes.getNamedItem(o);
                    if (!i) return;
                    if (!this.isAttributeProtocolAllowed(t, o, i.value)) return;
                    const s = document.createAttribute(o);
                    s.value = i.value;
                    n.setAttributeNode(s)
                }))
            }
            isAttributeProtocolAllowed(e, t, n) {
                var o;
                const i = null === (o = this.config.protocols[e]) || void 0 === o ? void 0 : o[t];
                if (!i) return !0;
                const s = n.toLowerCase().match(W.REGEX_PROTOCOL);
                return s ? i.includes(s[1]) : i.includes(H)
            }
            addConfiguredAttributes(e, t) {
                const n = this.config.add_attributes[e];
                n && Object.entries(n).forEach((([e, n]) => {
                    const o = document.createAttribute(e);
                    o.value = n;
                    t.setAttributeNode(o)
                }))
            }
        }
        W.REGEX_PROTOCOL = /^([A-Za-z0-9+\-.&;*\s]*?)(?::|&*0*58|&*x0*3a)/i;
        const q = new W({
                attributes: {
                    a: ["href", "title", "target"],
                    blockquote: ["cite"],
                    ol: ["start", "type"],
                    q: ["cite"],
                    ul: ["type"],
                    span: ["class"]
                },
                elements: ["a", "b", "blockquote", "br", "caption", "cite", "code", "dd", "dl", "dt", "em", "h1", "h2", "h3", "h4", "h5", "h6", "i", "li", "ol", "p", "pre", "q", "small", "strike", "strong", "sub", "sup", "u", "ul", "font", "div", "span"],
                protocols: {
                    a: {
                        href: ["http", "https", "mailto", H]
                    },
                    blockquote: {
                        cite: ["http", "https", H]
                    },
                    q: {
                        cite: ["http", "https", H]
                    }
                },
                remove_contents: ["style", "script"],
                add_attributes: {
                    a: {
                        rel: "noopener"
                    }
                }
            }),
            z = e => {
                if (!e) return e;
                const t = document.createElement("div");
                try {
                    const n = document.createRange().createContextualFragment(e),
                        o = q.cleanNode(n);
                    t.appendChild(o.cloneNode(!0))
                } catch (t) {
                    B.error(`we had an error sanitizing an html string: ${e}`)
                }
                return t.innerHTML
            },
            K = e => ({
                __html: e || ""
            });

        function j(e) {
            return {
                enabled: e.enabled,
                notificationText: z(e.notificationText || "")
            }
        }

        function Q(e) {
            return {
                description: z(e.description),
                label: z(e.label),
                toggleLabel: z(e.toggleLabel)
            }
        }

        function Z(e) {
            return {
                acceptAllLabel: z(e.acceptAllLabel),
                saveSettingsLabel: z(e.saveSettingsLabel),
                declineAllLabel: z(e.declineAllLabel),
                cookieSettingsLabel: z(e.cookieSettingsLabel),
                introduction: Q(e.introduction),
                necessary: Q(e.categories.necessary),
                analytics: Q(e.categories.analytics),
                advertisement: Q(e.categories.advertisement),
                functionality: Q(e.categories.functionality)
            }
        }

        function X(e) {
            return {
                notification: z(e.notification),
                acceptLabel: z(e.acceptLabel),
                declineLabel: z(e.declineLabel),
                disclaimer: z(e.disclaimer),
                modalText: e.modalText && Z(e.modalText)
            }
        }
        const J = {
                COOKIES_WITHOUT_BANNER: 0,
                NO_COOKIES: 1,
                NOTIFY: 2,
                OPT_IN: 3,
                COOKIES_BY_CATEGORY: 4,
                OPT_OUT: 5,
                OPT_OUT_BY_CATEGORY: 6
            },
            ee = Object.fromEntries(Object.entries(J).map((([e, t]) => [t, e])));

        function te(e) {
            return ee[e]
        }
        const ne = new Set(Object.values(J));

        function oe(e) {
            return ne.has(e) ? e : J.COOKIES_BY_CATEGORY
        }

        function ie(e) {
            return e === J.OPT_IN || e === J.COOKIES_BY_CATEGORY
        }

        function se(e) {
            return {
                type: oe(e.type),
                text: X(e.text)
            }
        }
        const re = "not used",
            ae = "OPT_IN",
            ce = "NO_COOKIES";

        function le(e) {
            return {
                id: e.id,
                portalId: e.portalId,
                label: e.label,
                enabled: e.enabled,
                configuration: G(e.configuration),
                policy: se(e.policy),
                customizationSettings: Y(e.legacyCustomization),
                gpcSettings: j(e.gpcSettings)
            }
        }

        function de(e) {
            let t, n;
            switch (e.policy.type) {
                case J.COOKIES_WITHOUT_BANNER:
                case J.NOTIFY:
                    t = ae;
                    n = !0;
                    break;
                case J.NO_COOKIES:
                    t = ce;
                    n = !1;
                    break;
                default:
                    t = ae;
                    n = !1
            }
            return {
                active: e.enabled,
                testing: !1,
                mode: t,
                policyWording: re,
                acceptWording: re,
                cancelWording: re,
                disclaimerWording: re,
                hideDecline: n,
                accentColor: e.customizationSettings.accentColor,
                bannerType: re,
                label: e.label,
                privacyDefault: !1,
                cookiesByCategory: {},
                id: e.id,
                portalId: e.portalId
            }
        }
        const he = 1,
            ue = 2,
            ge = 3,
            _e = {
                [he]: "analytics",
                [ue]: "advertisement",
                [ge]: "functionality"
            };
        class pe {
            constructor(e, t, n) {
                this.allowed = e;
                this.previousCategories = n || {
                    necessary: !0,
                    analytics: !1,
                    advertisement: !1,
                    functionality: !1
                };
                this.categories = t || {
                    necessary: !0,
                    analytics: e,
                    advertisement: e,
                    functionality: e
                }
            }
            hasAnalyticsConsent() {
                return this.allowed || !0 === this.categories.analytics
            }
            adsHasChangedToFalse() {
                return !0 === this.previousCategories.advertisement && !1 === this.categories.advertisement
            }
            update(e) {
                this.previousCategories = this.categories;
                this.categories = Object.assign({}, this.categories, {
                    analytics: e,
                    advertisement: e,
                    functionality: e
                });
                this.allowed = e;
                return this
            }
            updateCategories({
                analytics: e,
                advertisement: t,
                functionality: n
            }) {
                this.previousCategories = this.categories;
                this.categories = {
                    necessary: !0,
                    analytics: e,
                    advertisement: t,
                    functionality: n
                };
                this.allowed = e && t && n;
                return this
            }
            allCategoriesSelected() {
                return this.categories.necessary && this.categories.analytics && this.categories.advertisement && this.categories.functionality
            }
            getSafeCopy() {
                return new pe(this.allowed, {
                    necessary: this.categories.necessary,
                    analytics: this.categories.analytics,
                    advertisement: this.categories.advertisement,
                    functionality: this.categories.functionality
                }, {
                    necessary: this.previousCategories.necessary,
                    analytics: this.previousCategories.analytics,
                    advertisement: this.previousCategories.advertisement,
                    functionality: this.previousCategories.functionality
                })
            }
            toCookieString() {
                return `${he}:${this.categories.analytics}_${ue}:${this.categories.advertisement}_${ge}:${this.categories.functionality}`
            }
            static fromCategories(e) {
                const t = e.analytics && e.advertisement && e.functionality;
                return new pe(t, Object.assign({}, e, {
                    necessary: !0
                }))
            }
            static buildFromCookieString(e) {
                const t = e.includes(",") ? e.split(",") : e.split("_"),
                    n = {
                        necessary: !0,
                        analytics: !1,
                        advertisement: !1,
                        functionality: !1
                    };
                t.forEach((e => {
                    const t = e.split(":");
                    if (2 !== t.length) return;
                    const o = t[0],
                        i = _e[o];
                    i && (n[i] = "true" === t[1])
                }));
                const o = n.necessary && n.advertisement && n.analytics && n.functionality;
                return new pe(o, n)
            }
            static buildInitialConsent() {
                return new pe(!1, {
                    necessary: !0,
                    analytics: !1,
                    advertisement: !1,
                    functionality: !1
                })
            }
        }
        const me = e => encodeURI(e),
            fe = e => decodeURI(e),
            be = "_fbp",
            ye = "1970-01-01T00:00:01-00:00";
        class ve {
            constructor(e) {
                this.context = e;
                this.cookiesToSubdomain = !1;
                this.useSecureCookies = !1;
                this.currentDomain = ""
            }
            isEnabled() {
                return this.context.getNavigator().cookieEnabled || "cookie" in this.context.getDocument() && this.context.getDocument().cookie.length > 0
            }
            addDomain(e) {
                `.${this.context.getHostname()}`.endsWith(e.startsWith(".") ? e : `.${e}`) && (!this.currentDomain || e.length < this.currentDomain.length) && (this.currentDomain = e)
            }
            get(e) {
                const t = new RegExp(`(^|;)[ ]*${e}=([^;]*)`).exec(this.context.getDocument().cookie);
                return t ? fe(t[2]) : ""
            }
            set(e, t, n) {
                let o, i, s = !1;
                if ((n = n || {}).minsToExpire) {
                    o = new Date;
                    o.setTime(o.getTime() + 1e3 * n.minsToExpire * 60)
                } else if (n.daysToExpire) {
                    o = new Date;
                    o.setTime(o.getTime() + 1e3 * n.daysToExpire * 60 * 60 * 24)
                } else n.expiryDate && n.expiryDate.toGMTString ? o = n.expiryDate : n.expiryDate && (o = new Date(n.expiryDate));
                if (void 0 !== o) {
                    i = o.toGMTString();
                    s = !0
                }
                this.setCookie(e, me(t), {
                    expires: s ? `;expires=${i}` : "",
                    expiresTime: s ? o : null,
                    path: `;path=${n.path?n.path:"/"}`,
                    domain: !this.cookiesToSubdomain && this.currentDomain ? `;domain=${this.currentDomain}` : "",
                    secure: this.useSecureCookies ? ";secure" : "",
                    sameSite: this.useSecureCookies ? ";SameSite=None" : ";SameSite=Lax"
                })
            }
            getDomainAncestry(e) {
                if ("" === e || !e) return [];
                const t = e.split(".");
                if (2 === t.length) return [e];
                if ("" === t[t.length - 1] || t.length < 2) {
                    console.error(`Invalid Domain: ${e}, Parsed As: [${t}]`);
                    return []
                }
                const n = [];
                let o, i = `${t[t.length-1]}`;
                for (o = t.length - 2; o >= 0; o--) {
                    if ("" === t[o]) {
                        if (0 !== o) {
                            console.error(`Invalid Domain: ${e}, Parsed As: [${t}]`);
                            return []
                        }
                        continue
                    }
                    const s = `${t[o]}.${i}`;
                    n.push(s);
                    i = s
                }
                return n
            }
            removeFBPCookie() {
                const e = new Date(ye),
                    t = e.toUTCString();
                this.getDomainAncestry(this.context.getDocument().domain).forEach((n => {
                    this.setCookie(be, "", {
                        expires: `;expires=${t}`,
                        expiresTime: e,
                        path: ";path=/",
                        domain: `;domain=.${n}`,
                        secure: "",
                        sameSite: ";SameSite=Lax"
                    })
                }))
            }
            getGACookieNames() {
                const e = this.context.getDocument().cookie;
                if (!e) return [];
                const t = e.split(";"),
                    n = new RegExp("^(_ga_[a-zA-Z0-9]+)=[^;]+$"),
                    o = [];
                t.forEach((e => {
                    const t = e.trim().match(n);
                    t && o.push(t[1])
                }));
                return o
            }
            removeGACookie() {
                this.getGACookieNames().forEach((e => this.remove(e)))
            }
            remove(e) {
                this.set(e, "", {
                    expiryDate: ye
                })
            }
            setCookie(e, t, n) {
                const o = n.expires + n.path + n.domain + n.sameSite + n.secure;
                this.writeCookie(`${e}=${t}${o}`)
            }
            writeCookie(e) {
                this.context.getDocument().cookie = e
            }
            setCookiesToSubdomain(e) {
                this.cookiesToSubdomain = e
            }
            setUseSecureCookies(e) {
                this.useSecureCookies = e
            }
        }
        class Ce {
            constructor(e, t) {
                this.name = e;
                this.expirationDays = t
            }
            getName() {
                return this.name
            }
            getExpirationDays() {
                return this.expirationDays
            }
        }
        Ce.CATEGORY_PREFERENCE_COOKIE = new Ce("__hs_cookie_cat_pref", 180);
        Ce.GPC_BANNER_DISMISS_COOKIE = new Ce("__hs_gpc_banner_dismiss", 180);
        Ce.NOTIFY_BANNER_DIMISS_COOKIE = new Ce("__hs_notify_banner_dismiss", 180);
        Ce.OPT_OUT_COOKIE = new Ce("__hs_opt_out", 180);
        Ce.INITIAL_OPT_IN = new Ce("__hs_initial_opt_in", 7);
        var xe, ke, Se, we, Ee, Te, Oe = {},
            Ie = [],
            Ae = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;

        function Le(e, t) {
            for (var n in t) e[n] = t[n];
            return e
        }

        function Ne(e) {
            var t = e.parentNode;
            t && t.removeChild(e)
        }

        function Be(e, t, n) {
            var o, i, s, r = {};
            for (s in t) "key" == s ? o = t[s] : "ref" == s ? i = t[s] : r[s] = t[s];
            if (arguments.length > 2 && (r.children = arguments.length > 3 ? xe.call(arguments, 2) : n), "function" == typeof e && null != e.defaultProps)
                for (s in e.defaultProps) void 0 === r[s] && (r[s] = e.defaultProps[s]);
            return Re(e, r, o, i, null)
        }

        function Re(e, t, n, o, i) {
            var s = {
                type: e,
                props: t,
                key: n,
                ref: o,
                __k: null,
                __: null,
                __b: 0,
                __e: null,
                __d: void 0,
                __c: null,
                __h: null,
                constructor: void 0,
                __v: null == i ? ++Se : i
            };
            return null == i && null != ke.vnode && ke.vnode(s), s
        }

        function Pe(e) {
            return e.children
        }

        function De(e, t) {
            this.props = e, this.context = t
        }

        function Ge(e, t) {
            if (null == t) return e.__ ? Ge(e.__, e.__.__k.indexOf(e) + 1) : null;
            for (var n; t < e.__k.length; t++)
                if (null != (n = e.__k[t]) && null != n.__e) return n.__e;
            return "function" == typeof e.type ? Ge(e) : null
        }

        function Me(e) {
            var t, n;
            if (null != (e = e.__) && null != e.__c) {
                for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
                    if (null != (n = e.__k[t]) && null != n.__e) {
                        e.__e = e.__c.base = n.__e;
                        break
                    }
                return Me(e)
            }
        }

        function Ue(e) {
            (!e.__d && (e.__d = !0) && we.push(e) && !Fe.__r++ || Te !== ke.debounceRendering) && ((Te = ke.debounceRendering) || Ee)(Fe)
        }

        function Fe() {
            for (var e; Fe.__r = we.length;) e = we.sort((function(e, t) {
                return e.__v.__b - t.__v.__b
            })), we = [], e.some((function(e) {
                var t, n, o, i, s, r;
                e.__d && (s = (i = (t = e).__v).__e, (r = t.__P) && (n = [], (o = Le({}, i)).__v = i.__v + 1, je(r, i, o, t.__n, void 0 !== r.ownerSVGElement, null != i.__h ? [s] : null, n, null == s ? Ge(i) : s, i.__h), Qe(n, i), i.__e != s && Me(i)))
            }))
        }

        function $e(e, t, n, o, i, s, r, a, c, l) {
            var d, h, u, g, _, p, m, f = o && o.__k || Ie,
                b = f.length;
            for (n.__k = [], d = 0; d < t.length; d++)
                if (null != (g = n.__k[d] = null == (g = t[d]) || "boolean" == typeof g ? null : "string" == typeof g || "number" == typeof g || "bigint" == typeof g ? Re(null, g, null, null, g) : Array.isArray(g) ? Re(Pe, {
                        children: g
                    }, null, null, null) : g.__b > 0 ? Re(g.type, g.props, g.key, null, g.__v) : g)) {
                    if (g.__ = n, g.__b = n.__b + 1, null === (u = f[d]) || u && g.key == u.key && g.type === u.type) f[d] = void 0;
                    else
                        for (h = 0; h < b; h++) {
                            if ((u = f[h]) && g.key == u.key && g.type === u.type) {
                                f[h] = void 0;
                                break
                            }
                            u = null
                        }
                    je(e, g, u = u || Oe, i, s, r, a, c, l), _ = g.__e, (h = g.ref) && u.ref != h && (m || (m = []), u.ref && m.push(u.ref, null, g), m.push(h, g.__c || _, g)), null != _ ? (null == p && (p = _), "function" == typeof g.type && g.__k === u.__k ? g.__d = c = Ye(g, c, e) : c = He(e, g, u, f, _, c), "function" == typeof n.type && (n.__d = c)) : c && u.__e == c && c.parentNode != e && (c = Ge(u))
                }
            for (n.__e = p, d = b; d--;) null != f[d] && ("function" == typeof n.type && null != f[d].__e && f[d].__e == n.__d && (n.__d = Ge(o, d + 1)), Je(f[d], f[d]));
            if (m)
                for (d = 0; d < m.length; d++) Xe(m[d], m[++d], m[++d])
        }

        function Ye(e, t, n) {
            for (var o, i = e.__k, s = 0; i && s < i.length; s++)(o = i[s]) && (o.__ = e, t = "function" == typeof o.type ? Ye(o, t, n) : He(n, o, o, i, o.__e, t));
            return t
        }

        function He(e, t, n, o, i, s) {
            var r, a, c;
            if (void 0 !== t.__d) r = t.__d, t.__d = void 0;
            else if (null == n || i != s || null == i.parentNode) e: if (null == s || s.parentNode !== e) e.appendChild(i), r = null;
                else {
                    for (a = s, c = 0;
                        (a = a.nextSibling) && c < o.length; c += 2)
                        if (a == i) break e;
                    e.insertBefore(i, s), r = s
                }
            return void 0 !== r ? r : i.nextSibling
        }

        function Ve(e, t, n, o, i) {
            var s;
            for (s in n) "children" === s || "key" === s || s in t || qe(e, s, null, n[s], o);
            for (s in t) i && "function" != typeof t[s] || "children" === s || "key" === s || "value" === s || "checked" === s || n[s] === t[s] || qe(e, s, t[s], n[s], o)
        }

        function We(e, t, n) {
            "-" === t[0] ? e.setProperty(t, n) : e[t] = null == n ? "" : "number" != typeof n || Ae.test(t) ? n : n + "px"
        }

        function qe(e, t, n, o, i) {
            var s;
            e: if ("style" === t)
                if ("string" == typeof n) e.style.cssText = n;
                else {
                    if ("string" == typeof o && (e.style.cssText = o = ""), o)
                        for (t in o) n && t in n || We(e.style, t, "");
                    if (n)
                        for (t in n) o && n[t] === o[t] || We(e.style, t, n[t])
                }
            else if ("o" === t[0] && "n" === t[1]) s = t !== (t = t.replace(/Capture$/, "")), t = t.toLowerCase() in e ? t.toLowerCase().slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + s] = n, n ? o || e.addEventListener(t, s ? Ke : ze, s) : e.removeEventListener(t, s ? Ke : ze, s);
            else if ("dangerouslySetInnerHTML" !== t) {
                if (i) t = t.replace(/xlink[H:h]/, "h").replace(/sName$/, "s");
                else if ("href" !== t && "list" !== t && "form" !== t && "tabIndex" !== t && "download" !== t && t in e) try {
                    e[t] = null == n ? "" : n;
                    break e
                } catch (e) {}
                "function" == typeof n || (null != n && (!1 !== n || "a" === t[0] && "r" === t[1]) ? e.setAttribute(t, n) : e.removeAttribute(t))
            }
        }

        function ze(e) {
            this.l[e.type + !1](ke.event ? ke.event(e) : e)
        }

        function Ke(e) {
            this.l[e.type + !0](ke.event ? ke.event(e) : e)
        }

        function je(e, t, n, o, i, s, r, a, c) {
            var l, d, h, u, g, _, p, m, f, b, y, v = t.type;
            if (void 0 !== t.constructor) return null;
            null != n.__h && (c = n.__h, a = t.__e = n.__e, t.__h = null, s = [a]), (l = ke.__b) && l(t);
            try {
                e: if ("function" == typeof v) {
                    if (m = t.props, f = (l = v.contextType) && o[l.__c], b = l ? f ? f.props.value : l.__ : o, n.__c ? p = (d = t.__c = n.__c).__ = d.__E : ("prototype" in v && v.prototype.render ? t.__c = d = new v(m, b) : (t.__c = d = new De(m, b), d.constructor = v, d.render = et), f && f.sub(d), d.props = m, d.state || (d.state = {}), d.context = b, d.__n = o, h = d.__d = !0, d.__h = []), null == d.__s && (d.__s = d.state), null != v.getDerivedStateFromProps && (d.__s == d.state && (d.__s = Le({}, d.__s)), Le(d.__s, v.getDerivedStateFromProps(m, d.__s))), u = d.props, g = d.state, h) null == v.getDerivedStateFromProps && null != d.componentWillMount && d.componentWillMount(), null != d.componentDidMount && d.__h.push(d.componentDidMount);
                    else {
                        if (null == v.getDerivedStateFromProps && m !== u && null != d.componentWillReceiveProps && d.componentWillReceiveProps(m, b), !d.__e && null != d.shouldComponentUpdate && !1 === d.shouldComponentUpdate(m, d.__s, b) || t.__v === n.__v) {
                            d.props = m, d.state = d.__s, t.__v !== n.__v && (d.__d = !1), d.__v = t, t.__e = n.__e, t.__k = n.__k, t.__k.forEach((function(e) {
                                e && (e.__ = t)
                            })), d.__h.length && r.push(d);
                            break e
                        }
                        null != d.componentWillUpdate && d.componentWillUpdate(m, d.__s, b), null != d.componentDidUpdate && d.__h.push((function() {
                            d.componentDidUpdate(u, g, _)
                        }))
                    }
                    d.context = b, d.props = m, d.state = d.__s, (l = ke.__r) && l(t), d.__d = !1, d.__v = t, d.__P = e, l = d.render(d.props, d.state, d.context), d.state = d.__s, null != d.getChildContext && (o = Le(Le({}, o), d.getChildContext())), h || null == d.getSnapshotBeforeUpdate || (_ = d.getSnapshotBeforeUpdate(u, g)), y = null != l && l.type === Pe && null == l.key ? l.props.children : l, $e(e, Array.isArray(y) ? y : [y], t, n, o, i, s, r, a, c), d.base = t.__e, t.__h = null, d.__h.length && r.push(d), p && (d.__E = d.__ = null), d.__e = !1
                } else null == s && t.__v === n.__v ? (t.__k = n.__k, t.__e = n.__e) : t.__e = Ze(n.__e, t, n, o, i, s, r, c);
                (l = ke.diffed) && l(t)
            }
            catch (e) {
                t.__v = null, (c || null != s) && (t.__e = a, t.__h = !!c, s[s.indexOf(a)] = null), ke.__e(e, t, n)
            }
        }

        function Qe(e, t) {
            ke.__c && ke.__c(t, e), e.some((function(t) {
                try {
                    e = t.__h, t.__h = [], e.some((function(e) {
                        e.call(t)
                    }))
                } catch (e) {
                    ke.__e(e, t.__v)
                }
            }))
        }

        function Ze(e, t, n, o, i, s, r, a) {
            var c, l, d, h = n.props,
                u = t.props,
                g = t.type,
                _ = 0;
            if ("svg" === g && (i = !0), null != s)
                for (; _ < s.length; _++)
                    if ((c = s[_]) && "setAttribute" in c == !!g && (g ? c.localName === g : 3 === c.nodeType)) {
                        e = c, s[_] = null;
                        break
                    }
            if (null == e) {
                if (null === g) return document.createTextNode(u);
                e = i ? document.createElementNS("http://www.w3.org/2000/svg", g) : document.createElement(g, u.is && u), s = null, a = !1
            }
            if (null === g) h === u || a && e.data === u || (e.data = u);
            else {
                if (s = s && xe.call(e.childNodes), l = (h = n.props || Oe).dangerouslySetInnerHTML, d = u.dangerouslySetInnerHTML, !a) {
                    if (null != s)
                        for (h = {}, _ = 0; _ < e.attributes.length; _++) h[e.attributes[_].name] = e.attributes[_].value;
                    (d || l) && (d && (l && d.__html == l.__html || d.__html === e.innerHTML) || (e.innerHTML = d && d.__html || ""))
                }
                if (Ve(e, u, h, i, a), d) t.__k = [];
                else if (_ = t.props.children, $e(e, Array.isArray(_) ? _ : [_], t, n, o, i && "foreignObject" !== g, s, r, s ? s[0] : n.__k && Ge(n, 0), a), null != s)
                    for (_ = s.length; _--;) null != s[_] && Ne(s[_]);
                a || ("value" in u && void 0 !== (_ = u.value) && (_ !== e.value || "progress" === g && !_ || "option" === g && _ !== h.value) && qe(e, "value", _, h.value, !1), "checked" in u && void 0 !== (_ = u.checked) && _ !== e.checked && qe(e, "checked", _, h.checked, !1))
            }
            return e
        }

        function Xe(e, t, n) {
            try {
                "function" == typeof e ? e(t) : e.current = t
            } catch (e) {
                ke.__e(e, n)
            }
        }

        function Je(e, t, n) {
            var o, i;
            if (ke.unmount && ke.unmount(e), (o = e.ref) && (o.current && o.current !== e.__e || Xe(o, null, t)), null != (o = e.__c)) {
                if (o.componentWillUnmount) try {
                    o.componentWillUnmount()
                } catch (e) {
                    ke.__e(e, t)
                }
                o.base = o.__P = null
            }
            if (o = e.__k)
                for (i = 0; i < o.length; i++) o[i] && Je(o[i], t, "function" != typeof e.type);
            n || null == e.__e || Ne(e.__e), e.__e = e.__d = void 0
        }

        function et(e, t, n) {
            return this.constructor(e, n)
        }

        function tt(e, t, n) {
            var o, i, s;
            ke.__ && ke.__(e, t), i = (o = "function" == typeof n) ? null : n && n.__k || t.__k, s = [], je(t, e = (!o && n || t).__k = Be(Pe, null, [e]), i || Oe, Oe, void 0 !== t.ownerSVGElement, !o && n ? [n] : i ? null : t.firstChild ? xe.call(t.childNodes) : null, s, !o && n ? n : i ? i.__e : t.firstChild, o), Qe(s, e)
        }
        xe = Ie.slice, ke = {
                __e: function(e, t) {
                    for (var n, o, i; t = t.__;)
                        if ((n = t.__c) && !n.__) try {
                            if ((o = n.constructor) && null != o.getDerivedStateFromError && (n.setState(o.getDerivedStateFromError(e)), i = n.__d), null != n.componentDidCatch && (n.componentDidCatch(e), i = n.__d), i) return n.__E = n
                        } catch (t) {
                            e = t
                        }
                    throw e
                }
            }, Se = 0,
            function(e) {
                return null != e && void 0 === e.constructor
            }, De.prototype.setState = function(e, t) {
                var n;
                n = null != this.__s && this.__s !== this.state ? this.__s : this.__s = Le({}, this.state), "function" == typeof e && (e = e(Le({}, n), this.props)), e && Le(n, e), null != e && this.__v && (t && this.__h.push(t), Ue(this))
            }, De.prototype.forceUpdate = function(e) {
                this.__v && (this.__e = !0, e && this.__h.push(e), Ue(this))
            }, De.prototype.render = Pe, we = [], Ee = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, Fe.__r = 0, 0;
        var nt, ot, it, st = 0,
            rt = [],
            at = ke.__b,
            ct = ke.__r,
            lt = ke.diffed,
            dt = ke.__c,
            ht = ke.unmount;

        function ut(e, t) {
            ke.__h && ke.__h(ot, e, st || t), st = 0;
            var n = ot.__H || (ot.__H = {
                __: [],
                __h: []
            });
            return e >= n.__.length && n.__.push({}), n.__[e]
        }

        function gt(e) {
            return st = 1, _t(St, e)
        }

        function _t(e, t, n) {
            var o = ut(nt++, 2);
            return o.t = e, o.__c || (o.__ = [n ? n(t) : St(void 0, t), function(e) {
                var t = o.t(o.__[0], e);
                o.__[0] !== t && (o.__ = [t, o.__[1]], o.__c.setState({}))
            }], o.__c = ot), o.__
        }

        function pt(e, t) {
            var n = ut(nt++, 3);
            !ke.__s && kt(n.__H, t) && (n.__ = e, n.__H = t, ot.__H.__h.push(n))
        }

        function mt(e, t) {
            var n = ut(nt++, 4);
            !ke.__s && kt(n.__H, t) && (n.__ = e, n.__H = t, ot.__h.push(n))
        }

        function ft(e) {
            return st = 5, bt((function() {
                return {
                    current: e
                }
            }), [])
        }

        function bt(e, t) {
            var n = ut(nt++, 7);
            return kt(n.__H, t) && (n.__ = e(), n.__H = t, n.__h = e), n.__
        }

        function yt() {
            for (var e; e = rt.shift();)
                if (e.__P) try {
                    e.__H.__h.forEach(Ct), e.__H.__h.forEach(xt), e.__H.__h = []
                } catch (t) {
                    e.__H.__h = [], ke.__e(t, e.__v)
                }
        }
        ke.__b = function(e) {
            ot = null, at && at(e)
        }, ke.__r = function(e) {
            ct && ct(e), nt = 0;
            var t = (ot = e.__c).__H;
            t && (t.__h.forEach(Ct), t.__h.forEach(xt), t.__h = [])
        }, ke.diffed = function(e) {
            lt && lt(e);
            var t = e.__c;
            t && t.__H && t.__H.__h.length && (1 !== rt.push(t) && it === ke.requestAnimationFrame || ((it = ke.requestAnimationFrame) || function(e) {
                var t, n = function() {
                        clearTimeout(o), vt && cancelAnimationFrame(t), setTimeout(e)
                    },
                    o = setTimeout(n, 100);
                vt && (t = requestAnimationFrame(n))
            })(yt)), ot = null
        }, ke.__c = function(e, t) {
            t.some((function(e) {
                try {
                    e.__h.forEach(Ct), e.__h = e.__h.filter((function(e) {
                        return !e.__ || xt(e)
                    }))
                } catch (n) {
                    t.some((function(e) {
                        e.__h && (e.__h = [])
                    })), t = [], ke.__e(n, e.__v)
                }
            })), dt && dt(e, t)
        }, ke.unmount = function(e) {
            ht && ht(e);
            var t, n = e.__c;
            n && n.__H && (n.__H.__.forEach((function(e) {
                try {
                    Ct(e)
                } catch (e) {
                    t = e
                }
            })), t && ke.__e(t, n.__v))
        };
        var vt = "function" == typeof requestAnimationFrame;

        function Ct(e) {
            var t = ot,
                n = e.__c;
            "function" == typeof n && (e.__c = void 0, n()), ot = t
        }

        function xt(e) {
            var t = ot;
            e.__c = e.__(), ot = t
        }

        function kt(e, t) {
            return !e || e.length !== t.length || t.some((function(t, n) {
                return t !== e[n]
            }))
        }

        function St(e, t) {
            return "function" == typeof t ? t(e) : t
        }
        var wt = 0;

        function Et(e, t, n, o, i) {
            var s, r, a = {};
            for (r in t) "ref" == r ? s = t[r] : a[r] = t[r];
            var c = {
                type: e,
                props: a,
                key: n,
                ref: s,
                __k: null,
                __: null,
                __b: 0,
                __e: null,
                __d: void 0,
                __c: null,
                __h: null,
                constructor: void 0,
                __v: --wt,
                __source: o,
                __self: i
            };
            if ("function" == typeof e && (s = e.defaultProps))
                for (r in s) void 0 === a[r] && (a[r] = s[r]);
            return ke.vnode && ke.vnode(c), c
        }

        function Tt() {
            return Et("svg", {
                version: "1.1",
                id: "Layer_1",
                xmlns: "http://www.w3.org/2000/svg",
                x: "0px",
                y: "0px",
                viewBox: "0 0 32 32",
                children: Et("path", {
                    fill: "currentColor",
                    d: "M4.3,27.7c0.2,0.2,0.6,0.5,1,0.5c0.4,0,0.8-0.2,1-0.5l9.6-9.5l9.6,9.5c0.2,0.2,0.6,0.5,1,0.5 c0.8,0,1.5-0.6,1.5-1.5c0-0.4-0.2-0.8-0.5-1L18.2,16l9.5-9.5c0.2-0.2,0.4-0.6,0.4-1c0-0.8-0.6-1.5-1.5-1.5c-0.4,0-0.7,0.2-1,0.4l0,0 L16,13.8L6.5,4.3C6.2,4,5.8,3.8,5.4,3.8c-0.8,0-1.5,0.6-1.5,1.5c0,0.5,0.2,0.8,0.5,1.1l0,0l9.5,9.5l-9.5,9.6c-0.2,0.2-0.5,0.6-0.5,1 S4.1,27.4,4.3,27.7L4.3,27.7z"
                })
            })
        }
        const Ot = "Tab",
            It = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"]):not([disabled])';

        function At(e) {
            return Array.from(e.querySelectorAll(It)).filter((e => {
                if (e.checkVisibility) return e.checkVisibility({
                    visibilityProperty: !0
                });
                const t = getComputedStyle(e);
                return "none" !== t.display && "hidden" !== t.visibility
            }))
        }

        function Lt(e) {
            e.focus();
            const t = t => {
                if (t.key !== Ot && t.code !== Ot) return;
                const n = At(e);
                if (0 === n.length) return;
                const o = n[0],
                    i = n[n.length - 1],
                    s = e.ownerDocument.activeElement;
                if (t.shiftKey) {
                    if (s === o || s === e) {
                        i.focus();
                        t.preventDefault()
                    }
                } else if (s === i || s === e) {
                    o.focus();
                    t.preventDefault()
                }
            };
            e.addEventListener("keydown", t);
            return () => e.removeEventListener("keydown", t)
        }

        function Nt({
            onAcceptAll: e,
            onCookieSettingsClick: t,
            onDeclineAll: n,
            setting: o,
            onCloseBannerButtonClick: i,
            isModalDisplayed: s
        }) {
            var r, a;
            const c = ft(null);
            mt((() => {
                if (c.current && !s) return Lt(c.current)
            }), [s]);
            const l = s ? -1 : 0,
                h = o.policy,
                u = o.policy.type,
                g = u === J.OPT_OUT_BY_CATEGORY || u === J.COOKIES_BY_CATEGORY,
                _ = u === J.OPT_IN || u === J.OPT_OUT || u === J.OPT_OUT_BY_CATEGORY || u === J.COOKIES_BY_CATEGORY;
            return Et("div", {
                id: d,
                className: o.customizationSettings.position === U.BOTTOM ? "hs-cookie-notification-position-bottom" : "",
                "data-nosnippet": "true",
                role: "dialog",
                "aria-describedby": "hs-eu-policy-wording",
                "aria-label": "Cookie banner",
                ref: c,
                tabIndex: -1,
                children: Et("div", {
                    id: "hs-eu-cookie-confirmation-inner",
                    children: [Et("div", {
                        id: "hs-eu-header-container",
                        children: Et("button", {
                            id: "hs-eu-close-button",
                            className: "hs-close-button",
                            onClick: () => i(u),
                            "aria-label": "Dismiss cookie banner",
                            tabIndex: l,
                            children: Et(Tt, {})
                        })
                    }), Et("div", {
                        id: "hs-eu-policy-wording",
                        dangerouslySetInnerHTML: K(h.text.notification)
                    }), h.text.disclaimer && _ && Et("p", {
                        id: "hs-eu-cookie-disclaimer",
                        dangerouslySetInnerHTML: K(h.text.disclaimer)
                    }), Et("div", {
                        id: "hs-eu-cookie-confirmation-buttons-area",
                        children: Et("div", {
                            id: "hs-eu-confirmation-button-group",
                            children: [g && Et("button", {
                                onClick: () => t(),
                                id: "hs-eu-cookie-settings-button",
                                dangerouslySetInnerHTML: K(null === (r = h.text.modalText) || void 0 === r ? void 0 : r.cookieSettingsLabel),
                                "aria-label": null === (a = h.text.modalText) || void 0 === a ? void 0 : a.cookieSettingsLabel,
                                tabIndex: l
                            }), Et("div", {
                                id: "hs-eu-opt-in-buttons",
                                children: [Et("button", {
                                    id: "hs-eu-confirmation-button",
                                    onClick: () => e(u),
                                    dangerouslySetInnerHTML: K(h.text.acceptLabel),
                                    "aria-label": h.text.acceptLabel,
                                    tabIndex: l
                                }), _ && Et("button", {
                                    id: "hs-eu-decline-button",
                                    onClick: () => n(),
                                    dangerouslySetInnerHTML: K(h.text.declineLabel),
                                    "aria-label": h.text.declineLabel,
                                    tabIndex: l
                                })]
                            })]
                        })
                    })]
                })
            })
        }

        function Bt({
            category: e,
            disabled: t,
            onToggleChange: n,
            toggleValue: o
        }) {
            const i = `hs-category-toggle-${e}`,
                s = `${i}-help-text`;
            return Et("div", {
                className: `hs-toggle-switch ${o?"hs-toggle-selected-flag":""}`,
                children: [Et("div", {
                    className: "hs-toggle-switch-nob"
                }), Et("label", {
                    htmlFor: i,
                    children: Et("span", {
                        className: "hs-hidden",
                        id: s,
                        children: `${e} cookies ${o?"allowed":"disallowed"}`
                    })
                }), Et("input", {
                    id: i,
                    className: "hs-toggle-switch-input",
                    type: "checkbox",
                    onChange: e => n(e.currentTarget.checked),
                    checked: o,
                    disabled: t,
                    "aria-pressed": o,
                    tabIndex: 0,
                    "aria-describedby": s,
                    "data-test-id": i
                })]
            })
        }

        function Rt({
            className: e
        }) {
            return Et("svg", {
                version: "1.1",
                id: "plus-icon-svg",
                xmlns: "http://www.w3.org/2000/svg",
                x: "0px",
                y: "0px",
                viewBox: "0 0 32 32",
                className: e,
                children: Et("path", {
                    fill: "currentColor",
                    d: "M22.6,15.3c-0.1-0.1-0.1-0.2-0.2-0.2l0,0l-0.1-0.2l0,0l0,0l0,0L12.1,4.2c-0.2-0.2-0.6-0.5-1.1-0.5 c-0.9,0-1.5,0.7-1.5,1.5c0,0.4,0.2,0.7,0.4,1l0,0l9.3,9.7l-9.3,9.7c-0.3,0.3-0.6,0.7-0.6,1.1c0,0.9,0.7,1.5,1.5,1.5 c0.5,0,1-0.2,1.2-0.6l0,0l10.2-10.7l0,0l0,0l0,0l0.2-0.2c0.1-0.1,0.1-0.2,0.2-0.2l0,0c0-0.1,0.1-0.2,0.1-0.2l0,0 c0-0.1,0.1-0.2,0.1-0.3l0,0c0-0.1,0-0.2-0.1-0.3l0,0v-0.1C22.6,15.5,22.6,15.4,22.6,15.3L22.6,15.3L22.6,15.3z"
                })
            })
        }

        function Pt(e, t) {
            if (!t) return !1;
            const n = e.getBoundingClientRect(),
                o = t.getBoundingClientRect();
            return n.top >= o.top && n.left >= o.left && n.bottom <= o.bottom && n.right <= o.right
        }

        function Dt({
            category: e,
            onToggleChange: t,
            sectionText: n,
            toggleValue: o,
            modalBodyRef: i
        }) {
            const [s, r] = gt(!1), a = e === p.NECESSARY, c = ft(null), l = ft(null), d = () => {
                r(!s)
            };
            pt((() => {
                if (s) {
                    const e = c.current;
                    e && e.scrollIntoView && !Pt(e, i.current) && e.scrollIntoView({
                        behavior: "smooth"
                    })
                }
            }), [s, i, c]);
            return Et("div", {
                className: "hs-category-row",
                ref: c,
                children: [Et("div", {
                    className: "hs-category-row-header",
                    children: [Et("button", {
                        id: `hs-category-${e}`,
                        className: "hs-category-label",
                        onClick: d,
                        "aria-expanded": s,
                        "aria-controls": `hs-category-description-${e}`,
                        tabIndex: 0,
                        children: [Et(Rt, {
                            className: "description-accordion-arrow " + (s ? "rotated" : "")
                        }), Et("span", {
                            dangerouslySetInnerHTML: K(n.label)
                        })]
                    }), !a && Et(Bt, {
                        category: e,
                        disabled: e === p.NECESSARY,
                        onToggleChange: e => t(e),
                        toggleValue: o
                    }), n.toggleLabel && Et("span", {
                        className: "hs-always-active-label",
                        dangerouslySetInnerHTML: K(n.toggleLabel),
                        "aria-label": n.toggleLabel
                    })]
                }), Et("div", {
                    className: "hs-category-description " + (s ? "visible" : ""),
                    ref: l,
                    style: {
                        maxHeight: s && l.current ? 2 * l.current.scrollHeight : 0
                    },
                    id: `hs-category-description-${e}`,
                    dangerouslySetInnerHTML: K(n.description)
                })]
            })
        }
        var Gt = n(1),
            Mt = n.n(Gt),
            Ut = n(2),
            Ft = n.n(Ut);
        const $t = (e, t, n, o) => {
            const i = e.getDocument(),
                s = i.createElement("style");
            s.setAttribute("type", "text/css");
            s.setAttribute("id", n);
            const r = new RegExp("https://api_base_url", "g"),
                a = o ? t.replace(r, o) : t,
                c = i.createTextNode(a);
            s.appendChild(c);
            i.head.appendChild(s)
        };

        function Yt(e, t) {
            if (!e.getHasLoadedBaseStyle()) {
                $t(e, Mt(), b, t);
                e.setHasLoadedBaseStyle(!0)
            }
        }

        function Ht(e) {
            if (!e.getHasLoadedCbcStyle()) {
                $t(e, Ft(), y);
                e.setHasLoadedCbcStyle(!0)
            }
        }

        function Vt({
            consent: e,
            context: t,
            modalText: n,
            onAcceptCategories: o,
            onCloseModal: i,
            onDeclineAll: s
        }) {
            const r = ft(null),
                a = ft(null);
            mt((() => {
                if (r.current) return Lt(r.current)
            }), []);
            const [c, l] = gt(e.categories.analytics), [d, h] = gt(e.categories.advertisement), [u, m] = gt(e.categories.functionality), f = () => {
                o({
                    [p.ANALYTICS]: c,
                    [p.ADVERTISEMENT]: d,
                    [p.FUNCTIONALITY]: u
                })
            }, b = () => {
                l(!0);
                h(!0);
                m(!0);
                o({
                    [p.ANALYTICS]: !0,
                    [p.ADVERTISEMENT]: !0,
                    [p.FUNCTIONALITY]: !0
                })
            }, y = () => {
                s()
            };
            Ht(t);
            return Et("div", {
                id: g,
                "data-nosnippet": "true",
                children: Et("div", {
                    id: _,
                    ref: r,
                    role: "alertdialog",
                    "aria-modal": "true",
                    "aria-labelledby": "hs-modal-introduction",
                    "aria-describedby": "hs-modal-introduction-description",
                    tabIndex: -1,
                    children: [Et("div", {
                        id: "hs-modal-header",
                        children: Et("div", {
                            id: "hs-modal-header-container",
                            children: Et("button", {
                                id: "hs-modal-close-button",
                                className: "hs-close-button",
                                onClick: () => i(),
                                tabIndex: 0,
                                "aria-label": "Close modal",
                                children: Et(Tt, {})
                            })
                        })
                    }), Et("div", {
                        id: "hs-modal-body",
                        ref: a,
                        children: Et("div", {
                            id: "hs-modal-body-container",
                            children: [Et("div", {
                                id: "hs-modal-introduction",
                                children: Et("span", {
                                    dangerouslySetInnerHTML: K(n.introduction.label)
                                })
                            }), Et("div", {
                                id: "hs-modal-introduction-description",
                                children: Et("p", {
                                    dangerouslySetInnerHTML: K(n.introduction.description)
                                })
                            }), Et("div", {
                                id: "hs-categories-container",
                                children: [Et(Dt, {
                                    category: p.NECESSARY,
                                    onToggleChange: () => {},
                                    sectionText: n.necessary,
                                    toggleValue: !0,
                                    modalBodyRef: a
                                }), Et(Dt, {
                                    category: p.ANALYTICS,
                                    onToggleChange: e => l(e),
                                    sectionText: n.analytics,
                                    toggleValue: c,
                                    modalBodyRef: a
                                }), Et(Dt, {
                                    category: p.ADVERTISEMENT,
                                    onToggleChange: e => h(e),
                                    sectionText: n.advertisement,
                                    toggleValue: d,
                                    modalBodyRef: a
                                }), Et(Dt, {
                                    category: p.FUNCTIONALITY,
                                    onToggleChange: e => m(e),
                                    sectionText: n.functionality,
                                    toggleValue: u,
                                    modalBodyRef: a
                                })]
                            })]
                        })
                    }), Et("div", {
                        id: "hs-modal-footer",
                        children: Et("div", {
                            id: "hs-modal-footer-container",
                            children: [Et("button", {
                                id: "hs-modal-accept-all",
                                onClick: () => b(),
                                tabIndex: 0,
                                children: n.acceptAllLabel
                            }), n.declineAllLabel && Et("button", {
                                id: "hs-modal-decline-all",
                                onClick: y,
                                tabIndex: 0,
                                children: n.declineAllLabel
                            }), Et("button", {
                                id: "hs-modal-save-settings",
                                onClick: f,
                                tabIndex: 0,
                                children: n.saveSettingsLabel
                            })]
                        })
                    })]
                })
            })
        }

        function Wt({
            apiBaseUrl: e,
            consent: t,
            setting: n,
            context: o,
            onConsentChange: i,
            onCloseBannerWithoutConsent: s,
            dismissNotifyBanner: r
        }) {
            const [a, c] = gt(!1), l = e => {
                if (e !== J.NOTIFY) {
                    t.update(!0);
                    i(t)
                } else r()
            }, h = () => {
                t.update(!1);
                i(t)
            }, u = ({
                analytics: e,
                advertisement: n,
                functionality: o
            }) => {
                t.updateCategories({
                    analytics: e,
                    advertisement: n,
                    functionality: o
                });
                i(t)
            }, g = e => {
                if (e !== J.OPT_IN && e !== J.COOKIES_BY_CATEGORY)
                    if (e !== J.NOTIFY) {
                        t.update(!0);
                        i(t)
                    } else r();
                else s()
            }, _ = () => {
                c(!0)
            }, p = () => {
                c(!1);
                const e = o.getDocument().getElementById(d);
                e && e.focus()
            };
            Yt(o, e);
            return Et(Pe, {
                children: [Et(Nt, {
                    setting: n,
                    onAcceptAll: l,
                    onDeclineAll: h,
                    onCookieSettingsClick: _,
                    onCloseBannerButtonClick: g,
                    isModalDisplayed: a
                }), a && n.policy.text.modalText && Et(Vt, {
                    consent: t,
                    context: o,
                    modalText: n.policy.text.modalText,
                    onAcceptCategories: u,
                    onCloseModal: p,
                    onDeclineAll: h
                })]
            })
        }

        function qt({
            apiBaseUrl: e,
            context: t,
            setting: n,
            onCloseBanner: o
        }) {
            Yt(t, e);
            return Et("div", {
                id: h,
                "data-nosnippet": "true",
                role: "dialog",
                "aria-describedby": "hs-banner-gpc-wording",
                children: Et("div", {
                    id: "hs-banner-gpc-inner",
                    children: [Et("div", {
                        id: "hs-banner-gpc-header",
                        children: Et("button", {
                            id: "hs-banner-gpc-close-button",
                            className: "hs-close-button",
                            onClick: o,
                            "aria-label": "Dismiss banner",
                            children: Et(Tt, {})
                        })
                    }), Et("div", {
                        id: "hs-banner-gpc-wording",
                        dangerouslySetInnerHTML: K(n.gpcSettings.notificationText)
                    })]
                })
            })
        }
        var zt = ["helvetica", "arial", "arial-black", "verdana", "tahoma", "trebuchet ms", "impact", "times new roman", "georgia", "palatino", "courier", "comic sans ms", "courier new", "sans-serif", "system-ui"];

        function Kt(e) {
            return `${O}?family=${e}:ital,wght@${T.join(";")}&display=swap`
        }

        function jt(e, t) {
            const n = t || "Lato",
                o = e.getDocument(),
                i = e.getWindow();
            if (zt.indexOf(n.toLowerCase()) > -1) return;
            if (i[E]) return;
            const s = o.createElement("link");
            s.setAttribute("href", Kt(n));
            s.setAttribute("rel", "stylesheet");
            s.setAttribute("class", w);
            o.head.appendChild(s);
            i[E] = !0
        }
        const Qt = (e, t) => {
            const n = e.getDocument().createElement("div");
            n.setAttribute("id", u);
            n.setAttribute("style", t);
            const o = e.getDocument().body;
            o.insertBefore(n, o.firstChild);
            return n
        };

        function Zt(e, t, n, o, i, s, r, a, c) {
            const l = Qt(i, o);
            jt(i, c);
            tt(Et(Wt, {
                apiBaseUrl: e,
                consent: t,
                setting: n,
                context: i,
                onConsentChange: e => s(e),
                onCloseBannerWithoutConsent: r,
                dismissNotifyBanner: a
            }), l);
            return l
        }

        function Xt(e, t, n, o, i, s) {
            const r = Qt(t, o);
            jt(t, s);
            tt(Et(qt, {
                apiBaseUrl: e,
                context: t,
                setting: n,
                onCloseBanner: i
            }), r);
            return r
        }
        class Jt {
            static postActivity(e, t, n) {
                fetch(e, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(n)
                }).then((() => B.info(`Sent a banner ${t} event.`))).catch((() => B.error(`There was an issue sending a banner ${t} event.`)))
            }
            static sendView(e, t) {
                Jt.postActivity(`${e}/activity/view`, "VIEW", t)
            }
            static sendClick(e, t) {
                Jt.postActivity(`${e}/activity/click`, "CLICK", t)
            }
        }
        let en;
        ! function(e) {
            e[e.ROUND = 0] = "ROUND";
            e[e.SQUARE = 1] = "SQUARE";
            e[e.PILL = 2] = "PILL"
        }(en || (en = {}));
        const tn = {
                [en.ROUND]: "0.5em",
                [en.SQUARE]: "0",
                [en.PILL]: "3em"
            },
            nn = {
                [en.ROUND]: "12px",
                [en.SQUARE]: "0",
                [en.PILL]: "0"
            },
            on = e => null == e,
            sn = (e, t) => t ? [{
                cssVar: e,
                value: t
            }] : [],
            rn = (e, t) => t ? [{
                cssVar: e,
                value: t
            }] : [],
            an = (e, t) => t ? [{
                cssVar: e,
                value: `${t.number}${t.units}`
            }] : [],
            cn = (e, t) => on(t) ? [] : [{
                cssVar: e,
                value: tn[t]
            }],
            ln = (e, t) => on(t) ? [] : [{
                cssVar: e,
                value: nn[t]
            }],
            dn = (e, t) => on(t) ? [] : [...rn(`--hs-banner-${e}-color`, t.color), ...rn(`--hs-banner-${e}-text-color`, t.textColor), ...rn(`--hs-banner-${e}-border-color`, t.borderColor)],
            hn = e => on(e) ? [] : [{
                cssVar: "--hs-banner-close-button-display",
                value: e ? "flex" : "none"
            }],
            un = e => {
                switch (e) {
                    case U.BOTTOM:
                        return [{
                            cssVar: "--hs-banner-inset",
                            value: "auto 0 32px 0"
                        }, {
                            cssVar: "--hs-banner-translate-y",
                            value: "0"
                        }];
                    case U.BOTTOM_LEFT:
                        return [{
                            cssVar: "--hs-banner-inset",
                            value: "auto auto 32px 32px"
                        }, {
                            cssVar: "--hs-banner-translate-y",
                            value: "0"
                        }];
                    case U.BOTTOM_RIGHT:
                        return [{
                            cssVar: "--hs-banner-inset",
                            value: "auto 32px 32px auto"
                        }, {
                            cssVar: "--hs-banner-translate-y",
                            value: "0"
                        }];
                    case U.CENTER:
                        return [{
                            cssVar: "--hs-banner-inset",
                            value: "50% 0 auto 0"
                        }, {
                            cssVar: "--hs-banner-translate-y",
                            value: "-50%"
                        }];
                    default:
                        return [{
                            cssVar: "--hs-banner-inset",
                            value: "32px 0 auto 0"
                        }, {
                            cssVar: "--hs-banner-translate-y",
                            value: "0"
                        }]
                }
            },
            gn = e => e.map((e => `${e.cssVar}:${e.value}`)).join(";"),
            _n = e => [...rn("--hs-banner-color", e.bannerColor), ...rn("--hs-banner-text-color", e.bannerTextColor), ...rn("--hs-banner-settings-text-color", e.bannerSettingsButtonTextColor), ...an("--hs-banner-width", e.bannerWidth), ...an("--hs-banner-padding", e.bannerPadding), ...ln("--hs-banner-corners", e.bannerCorners), ...cn("--hs-banner-button-corners", e.bannerButtonCorners), ...dn("accept", e.bannerAcceptButtonStyle), ...dn("decline", e.bannerDeclineButtonStyle), ...hn(e.showCloseButton), ...on(e.position) ? [] : un($(e.position)), ...rn("--hs-banner-modal-color", e.modalColor), ...rn("--hs-banner-modal-text-color", e.modalTextColor), ...an("--hs-banner-modal-padding", e.modalContainerPadding), ...an("--hs-banner-modal-width", e.modalWidth), ...ln("--hs-banner-modal-corners", e.modalCorners), ...cn("--hs-banner-modal-button-corners", e.modalButtonCorners), ...dn("modal-accept", e.modalAcceptButtonStyle), ...dn("modal-decline", e.modalDeclineButtonStyle), ...dn("modal-save", e.modalSaveSettingsButtonStyle), ...ln("--hs-banner-modal-category-corners", e.modalCategoryCorners), ...rn("--hs-banner-modal-cateogry-color", e.modalCategoryColor), ...rn("--hs-banner-modal-category-text-color", e.modalCategoryTextColor), ...rn("--hs-banner-modal-toggle-on-color", e.modalCategoryToggleOnColor), ...rn("--hs-banner-modal-toggle-off-color", e.modalCategoryToggleOffColor), ...sn("--hs-banner-font-family", e.fontFamily), ...an("--hs-banner-font-size", e.fontSize)],
            pn = e => [...rn("--hs-banner-accentColor", e.accentColor), ...un(e.position), ...hn(e.showCloseButton)],
            mn = e => {
                const t = {};
                if (!e) return t;
                const n = e.indexOf("-"),
                    [o, i] = -1 === n ? [e, void 0] : [e.substring(0, n), e.substring(n + 1)];
                o && (t.countryCode = o);
                i && (t.regionCode = i);
                return t
            },
            fn = (e, t) => {},
            bn = (e, t) => {
                try {
                    e()
                } catch (e) {
                    console.error(e);
                    t && t(e)
                }
            },
            yn = e => {
                if (!e.hsCookieBanner) return;
                const t = e.hsCookieBanner.rawPerfMetrics;
                if (!t) return;
                const n = ["numSettings", "bannerInitAt", "bannerStartAt", "bannerReadyAt"];
                for (const e of n)
                    if (null == t[e]) return;
                const o = null == t.geolocationReceivedAt || null == t.geolocationRequestedAt;
                return t.usesGeolocation && o ? void 0 : {
                    numSettings: t.numSettings,
                    bannerInitAt: t.bannerInitAt,
                    bannerStartAt: t.bannerStartAt,
                    bannerReadyAt: t.bannerReadyAt,
                    matchedBannerType: t.matchedBannerType,
                    usesGpc: t.usesGpc,
                    geolocationRequestInCriticalPath: t.geolocationRequestInCriticalPath,
                    geolocationRequestDuration: t.usesGeolocation ? t.geolocationReceivedAt - t.geolocationRequestedAt : void 0,
                    bannerRendered: t.bannerRendered
                }
            },
            vn = () => ({
                numSettings: void 0,
                bannerInitAt: void 0,
                bannerStartAt: void 0,
                bannerReadyAt: void 0,
                matchedBannerType: void 0,
                usesGpc: !1,
                usesGeolocation: !1,
                geolocationRequestInCriticalPath: !1,
                geolocationReceivedAt: void 0,
                geolocationRequestedAt: void 0,
                bannerRendered: !1
            }),
            Cn = () => window.performance.now ? Math.round(window.performance.now()) : void 0,
            xn = (e, t, n) => {
                try {
                    if (!e.hsCookieBanner || !e.hsCookieBanner.rawPerfMetrics) return;
                    e.hsCookieBanner.rawPerfMetrics[t] = n
                } catch (e) {
                    fn(e)
                }
            };

        function kn(...e) {
            (window.dataLayer = window.dataLayer || []).push(arguments)
        }
        const Sn = (e, t) => !!(e && !S.includes(e) || null != t && ie(t)),
            wn = (e, t, n) => {
                const o = mn(t).countryCode;
                if (!Sn(o, n)) return;
                const i = e.categories.advertisement ? "granted" : "denied";
                kn("consent", "update", {
                    ad_storage: i,
                    analytics_storage: e.categories.analytics ? "granted" : "denied",
                    ad_user_data: i,
                    ad_personalization: i
                })
            },
            En = e => fetch(e).then((t => {
                if (!t.ok) throw new Error(`Non-2XX status: ${t.status}, url: ${e}`);
                return t.text()
            })),
            Tn = async e => {
                const t = `${e}/cf-location`,
                    n = await En(t).catch((e => {
                        fn(e, {
                            failingComponent: "cfGeolocationWorkerRequest"
                        });
                        return null
                    }));
                if (n) return n;
                const o = `https://${new URL(e).hostname}/cookie-banner-public/v2/cf-location`;
                return En(o)
            },
            On = "wildcard.hs-banner.com",
            In = e => Object.assign({}, e, {
                configuration: Object.assign({}, e.configuration, {
                    wildcard: !0
                })
            });
        class An {
            constructor(e) {
                this.publicMethods = ["showBanner", "hideBanner", "addPrivacyConsentListener", "setApiBaseUrl", "setCookiesToSubdomain", "setUseSecureCookies", "addCookieDomain", "addEnabledFeatureGates", "setBannerSettings", "setCustomizationSettings", "setUseGeoLocation", "setGeoLocation", "setHubSpotConsent", "addPrivacySettingsListener", "revokeCookieConsent", "useGoogleConsentModeV2", "setBusinessUnitId"];
                this.enabledFeatureGates = [];
                this.businessUnitId = 0;
                this.scriptVersion = "v2";
                this.context = e;
                this.bannerSettings = [];
                this.privacyConsentListeners = [];
                this.privacySettingsListeners = [];
                this.useGeoLocation = !1;
                this.useGCMV2 = !1;
                this.reportedMissingGeolocation = !1;
                this.cookie = new ve(e);
                this.isRunningInTestMode = e.getLocation().search.includes(l);
                this.removeDeprecatedBannerCookies()
            }
            removeDeprecatedBannerCookies() {
                this.cookie.get(Ce.OPT_OUT_COOKIE.getName()) && this.cookie.remove(Ce.OPT_OUT_COOKIE.getName());
                this.cookie.get(Ce.INITIAL_OPT_IN.getName()) && this.cookie.remove(Ce.INITIAL_OPT_IN.getName())
            }
            run() {
                const e = this.context.getWindow();
                if (this.disableBannerFlagSet()) {
                    B.info('"PRIVACY" flag found in disabledHsPopups window queue. Banner script will not run.');
                    return !0
                }
                xn(e, "numSettings", this.bannerSettings.length);
                this.findMatchingSetting();
                this.logGpcSignal();
                if (!this.matchedSetting) {
                    B.debug("we were unable to find the matching settings for this webpages. The banner will not run.");
                    this.setConsent(new pe(!0), {
                        reportClick: !1
                    });
                    return !1
                }
                xn(e, "matchedBannerType", this.matchedSetting.policy.type);
                if (this.shouldScanningOverride()) {
                    this.setConsent(new pe(!0), {
                        reportClick: !1,
                        persist: !0,
                        treatAsConsentEvent: !0
                    });
                    return !0
                }
                const t = !!this.shouldGpcOverride();
                xn(e, "usesGpc", t);
                if (t) {
                    this.setConsent(new pe(!1), {
                        persist: !1,
                        reportClick: !1
                    });
                    this.isGpcBannerDismissCookiePresent() || this.renderGpcBanner();
                    return !0
                }
                switch (this.matchedSetting.policy.type) {
                    case J.NO_COOKIES:
                        this.setConsent(new pe(!1), {
                            reportClick: !1
                        });
                        break;
                    case J.OPT_IN:
                    case J.COOKIES_BY_CATEGORY:
                        if (this.useConsentFromExistingCookie()) break;
                        this.cookie.removeGACookie();
                        this.setConsent(pe.buildInitialConsent(), {
                            persist: !1,
                            reportClick: !1,
                            allowGCMV2Forwarding: !1
                        });
                        this.renderBanner();
                        break;
                    case J.OPT_OUT_BY_CATEGORY:
                    case J.OPT_OUT:
                        if (this.useConsentFromExistingCookie()) break;
                        this.setConsent(new pe(!0), {
                            persist: !1,
                            reportClick: !1
                        });
                        this.renderBanner();
                        break;
                    case J.NOTIFY:
                        this.setConsent(new pe(!0), {
                            persist: !1,
                            reportClick: !1
                        });
                        if (this.isNotifyBannerDismissCookiePresent()) break;
                        this.renderBanner();
                        break;
                    case J.COOKIES_WITHOUT_BANNER:
                    default:
                        this.setConsent(new pe(!0), {
                            reportClick: !1
                        })
                }
                return !0
            }
            useConsentFromExistingCookie() {
                const e = this.readConsentCookie();
                if (e) {
                    this.setConsent(e, {
                        persist: !1,
                        reportClick: !1
                    });
                    e.hasAnalyticsConsent() || this.cookie.removeGACookie();
                    return !0
                }
                return !1
            }
            shouldScanningOverride() {
                return [J.OPT_OUT, J.OPT_OUT_BY_CATEGORY, J.COOKIES_BY_CATEGORY, J.OPT_IN, J.NOTIFY].includes(this.matchedSetting.policy.type) && this.context.getWindow()[r]
            }
            shouldGpcOverride() {
                return this.matchedSetting.gpcSettings.enabled && this.getGpcSignal()
            }
            getGpcSignal() {
                const e = this.context.getLocation().search;
                if (e.includes(s)) {
                    return {
                        TRUE: !0,
                        FALSE: !1
                    }[(new URLSearchParams(e).get(s) || "").toUpperCase()]
                }
                return this.context.getNavigator().globalPrivacyControl
            }
            logGpcSignal() {
                B.debug(`GPC signal: ${this.getGpcSignal()}`)
            }
            findMatchingSetting() {
                const e = this.context.getPathname(),
                    {
                        countryCode: t,
                        regionCode: n
                    } = mn(this.geoLocation),
                    o = this.bannerSettings.filter((e => e.enabled)).map((o => ({
                        setting: o,
                        matchResult: M(o.configuration, e, t, n)
                    }))).reduce(((e, t) => D(e.matchResult, t.matchResult) ? e : t), {
                        setting: null,
                        matchResult: R
                    });
                P(o.matchResult) && o.setting && this.setMatchingSetting(o.setting)
            }
            setMatchingSetting(e) {
                this.matchedSetting = e;
                if (0 === this.privacySettingsListeners.length) return;
                const t = de(e);
                this.privacySettingsListeners.forEach((e => this.safeCallListener(e, t)))
            }
            getMatchingSetting() {
                return this.matchedSetting
            }
            hasEnabledFeatureGate(e) {
                return this.enabledFeatureGates && this.enabledFeatureGates.includes(e)
            }
            setApiBaseUrl(e) {
                /^https:\/\/js-?.{0,3}\.hs-banner(qa)?\.com.*/.test(e) ? this.apiBaseUrl = e : B.error("unsupported base Api url provided.")
            }
            setBannerSettings(e) {
                (e[this.getCurrentDomain()] || []).forEach((e => this.bannerSettings.push(le(e))));
                (e[this.getWildcardDomain()] || []).forEach((e => this.bannerSettings.push(In(le(e)))))
            }
            setCustomizationSettings(e) {
                this.styleOverrides = e[this.getCurrentDomain()];
                this.wildcardStyleOverrides = e[this.getWildcardDomain()];
                this.bannerParentElement && this.bannerParentElement.setAttribute("style", this.getRenderStyles())
            }
            getCurrentDomain() {
                return this.context.getLocation().hostname
            }
            getWildcardDomain() {
                return 0 === this.businessUnitId ? On : `${this.businessUnitId}.${On}`
            }
            getCurrentGeoLocation() {
                const e = this.context.getWindow();
                xn(e, "usesGeolocation", !0);
                xn(e, "geolocationRequestedAt", Cn());
                const t = this.context.getLocation().search;
                if (t.includes(i)) {
                    const e = new URLSearchParams(t).get(i);
                    return Promise.resolve(e || "")
                }
                return Tn(this.apiBaseUrl).then((t => {
                    xn(e, "geolocationReceivedAt", Cn());
                    return t
                })).catch((e => {
                    B.error("We could not fetch the geolocation.");
                    fn(e);
                    return ""
                }))
            }
            setGeoLocation(e) {
                this.geoLocation = e;
                const {
                    countryCode: t,
                    regionCode: n
                } = mn(this.geoLocation);
                try {
                    null == t && this.reportEmptyGeolocation(!1);
                    "US" === t && null == n && this.reportEmptyGeolocation(!0)
                } catch (e) {
                    console.error("Failed to report missing geolocation data", e)
                }
            }
            addEnabledFeatureGates(e) {
                e.forEach((e => this.enabledFeatureGates.push(e)))
            }
            addCookieDomain(e) {
                this.cookie.addDomain(e)
            }
            setCookiesToSubdomain(e) {
                this.cookie.setCookiesToSubdomain(e)
            }
            setUseSecureCookies(e) {
                this.cookie.setUseSecureCookies(e)
            }
            setUseGeoLocation() {
                this.useGeoLocation = !0
            }
            useGoogleConsentModeV2() {
                if (!this.useGCMV2) {
                    this.useGCMV2 = !0;
                    this.consent && this.sendConsentToGCMV2(this.consent.getSafeCopy())
                }
            }
            sendConsentToGCMV2(e) {
                const t = this.matchedSetting && this.matchedSetting.policy && this.matchedSetting.policy.type;
                if (this.geoLocation) wn(e, this.geoLocation, t);
                else {
                    null == this.gcmGeoLocationFetchPromise && (this.gcmGeoLocationFetchPromise = this.getCurrentGeoLocation().then((e => {
                        this.setGeoLocation(e);
                        return e
                    })));
                    this.gcmGeoLocationFetchPromise.then((n => {
                        wn(e, n, t)
                    })).catch((e => {
                        fn(e)
                    }))
                }
            }
            addPrivacyConsentListener(e) {
                this.consent && this.safeCallListener(e, this.consent.getSafeCopy());
                this.privacyConsentListeners.push(e)
            }
            setConsent(e, t) {
                const n = {
                        persist: !0,
                        treatAsConsentEvent: !0,
                        reportClick: !0,
                        allowGCMV2Forwarding: !0
                    },
                    {
                        persist: o,
                        treatAsConsentEvent: i,
                        reportClick: s,
                        allowGCMV2Forwarding: r
                    } = Object.assign({}, n, t);
                this.consent = e;
                i && this.hideBanner();
                o && this.setConsentCookie();
                if (!this.isRunningInTestMode) {
                    s && (this.consent.hasAnalyticsConsent() ? this.trackAction("trackApproveCookieConsent") : this.trackAction("trackDeclineCookieConsent"));
                    if (i) {
                        this.privacyConsentListeners.forEach((t => this.safeCallListener(t, e.getSafeCopy())));
                        this.useGCMV2 && r && this.sendConsentToGCMV2(e.getSafeCopy());
                        this.consent.adsHasChangedToFalse() && this.cookie.removeFBPCookie()
                    }
                    s && this.sendClickActivity()
                }
            }
            getConsent() {
                return this.consent.getSafeCopy()
            }
            setConsentCookie() {
                if (!this.matchedSetting || this.isRunningInTestMode) return;
                const e = this.matchedSetting.policy.type;
                e !== J.NO_COOKIES && e !== J.COOKIES_WITHOUT_BANNER && e !== J.NOTIFY && this.cookie.set(Ce.CATEGORY_PREFERENCE_COOKIE.getName(), this.consent.toCookieString(), {
                    daysToExpire: Ce.CATEGORY_PREFERENCE_COOKIE.getExpirationDays(),
                    path: "/"
                })
            }
            readConsentCookie() {
                const e = this.cookie.get(Ce.CATEGORY_PREFERENCE_COOKIE.getName());
                return e ? pe.buildFromCookieString(e) : null
            }
            safeCallListener(e, t) {
                try {
                    e(t, this.scriptVersion)
                } catch (e) {
                    B.error("error calling listener.")
                }
            }
            isGpcBannerDismissCookiePresent() {
                return !!this.cookie.get(Ce.GPC_BANNER_DISMISS_COOKIE.getName())
            }
            setGpcBannerDismissCookie() {
                this.cookie.set(Ce.GPC_BANNER_DISMISS_COOKIE.getName(), "true", {
                    daysToExpire: Ce.GPC_BANNER_DISMISS_COOKIE.getExpirationDays(),
                    path: "/"
                })
            }
            isNotifyBannerDismissCookiePresent() {
                return !!this.cookie.get(Ce.NOTIFY_BANNER_DIMISS_COOKIE.getName())
            }
            setNotifyBannerDismissCookie() {
                this.cookie.set(Ce.NOTIFY_BANNER_DIMISS_COOKIE.getName(), "true", {
                    daysToExpire: Ce.NOTIFY_BANNER_DIMISS_COOKIE.getExpirationDays(),
                    path: "/"
                })
            }
            dismissNotifyBanner() {
                this.hideBanner();
                this.setNotifyBannerDismissCookie()
            }
            dismissGpcBanner() {
                this.hideBanner();
                this.setGpcBannerDismissCookie()
            }
            getRenderStyles() {
                try {
                    if (!this.matchedSetting) return "";
                    if (this.styleOverrides && !this.matchedSetting.configuration.wildcard) {
                        B.debug("using style overrides");
                        return gn(_n(this.styleOverrides))
                    }
                    if (this.wildcardStyleOverrides && this.matchedSetting.configuration.wildcard) {
                        B.debug("using wildcard style overrides");
                        return gn(_n(this.wildcardStyleOverrides))
                    }
                    B.debug("using legacy customization render styles");
                    return gn(pn(this.matchedSetting.customizationSettings))
                } catch (e) {
                    console.error("unable to utilize style overrides", e);
                    return ""
                }
            }
            renderGpcBanner() {
                this.bannerParentElement = Xt(this.apiBaseUrl, this.context, this.matchedSetting, this.getRenderStyles(), this.dismissGpcBanner.bind(this), this.styleOverrides && this.styleOverrides.fontFamily);
                if ("complete" === document.readyState) {
                    var e;
                    null === (e = document.getElementById(h)) || void 0 === e || e.classList.add(f)
                } else window.addEventListener("load", (() => {
                    var e;
                    null === (e = document.getElementById(h)) || void 0 === e || e.classList.add(f)
                }), {
                    once: !0
                });
                xn(this.context.getWindow(), "bannerRendered", !0);
                this.sendViewActivity()
            }
            renderBanner() {
                this.bannerParentElement = Zt(this.apiBaseUrl, this.consent, this.matchedSetting, this.getRenderStyles(), this.context, this.setConsent.bind(this), this.hideBanner.bind(this), this.dismissNotifyBanner.bind(this), this.styleOverrides && this.styleOverrides.fontFamily);
                if ("complete" === document.readyState) {
                    var e;
                    null === (e = document.getElementById(d)) || void 0 === e || e.classList.add(f)
                } else window.addEventListener("load", (() => {
                    var e;
                    null === (e = document.getElementById(d)) || void 0 === e || e.classList.add(f)
                }), {
                    once: !0
                });
                xn(this.context.getWindow(), "bannerRendered", !0);
                this.sendViewActivity()
            }
            hideBanner() {
                if (this.bannerParentElement) {
                    const e = this.bannerParentElement.children;
                    for (let t = 0; t < e.length; t++) e[t].classList.add(m)
                }
            }
            showBanner() {
                if (this.matchedSetting.policy.type === J.NO_COOKIES || this.matchedSetting.policy.type === J.COOKIES_WITHOUT_BANNER) return;
                this.bannerParentElement || (this.shouldGpcOverride() ? this.renderGpcBanner() : this.renderBanner());
                const e = this.bannerParentElement.children;
                if (e.length > 1) {
                    e[1].classList.remove(m)
                } else e[0].classList.remove(m)
            }
            invoke(e, t) {
                if (!this.publicMethods.includes(e) || !Reflect.has(this, e)) {
                    B.debug(`failed to invoke method ${e} of the banner.`);
                    throw new Error("Could not invoke banner method.")
                }
                Reflect.get(this, e).apply(this, t)
            }
            getBaseActivityPayload() {
                const e = this.context.getWindow().hsVars,
                    t = e && e.page_id;
                return {
                    bannerGeoLocation: this.geoLocation || "",
                    bannerPolicyId: this.matchedSetting.id,
                    bannerType: te(this.matchedSetting.policy.type),
                    domain: this.context.getHostname(),
                    portalId: this.matchedSetting.portalId,
                    contentId: t || ""
                }
            }
            sendClickActivity() {
                if (!this.consent || !this.matchedSetting || this.isRunningInTestMode) return;
                const e = {
                        consentAllowed: this.consent.allowed,
                        consentAnalytics: this.consent.categories.analytics,
                        consentAdvertisement: this.consent.categories.advertisement,
                        consentFunctionality: this.consent.categories.functionality
                    },
                    t = Object.assign({}, this.getBaseActivityPayload(), e);
                Jt.sendClick(this.apiBaseUrl, t)
            }
            sendViewActivity() {
                if (!this.matchedSetting || this.isRunningInTestMode) return;
                const e = this.getBaseActivityPayload();
                Jt.sendView(this.apiBaseUrl, e)
            }
            getAnalyticsQueue() {
                return this.context.getWindow()[o] = this.context.getWindow()[o] || []
            }
            trackAction(e) {
                try {
                    this.getAnalyticsQueue().push([e])
                } catch (e) {
                    B.error(`Unable to send analytics tracking event: ${e}`)
                }
            }
            disableBannerFlagSet() {
                if (!0 === this.context.getWindow()[x]) return !0;
                const e = this.context.getWindow()[v] || [];
                return Array.isArray(e) && e.includes(C)
            }
            setBusinessUnitId(e) {
                this.businessUnitId = e
            }
            revokeCookieConsent() {
                [Ce.INITIAL_OPT_IN.getName(), Ce.OPT_OUT_COOKIE.getName(), Ce.CATEGORY_PREFERENCE_COOKIE.getName(), Ce.GPC_BANNER_DISMISS_COOKIE.getName(), Ce.NOTIFY_BANNER_DIMISS_COOKIE.getName(), "__hssc", "__hssrc", "__hstc", "__hs_do_not_track", "hubspotutk", "messagesUtk"].forEach((e => this.cookie.remove(e)));
                this.trackAction("trackRevokeCookieConsent");
                this.setConsent(new pe(!1), {
                    reportClick: !1
                })
            }
            addPrivacySettingsListener(e) {
                this.matchedSetting && this.safeCallListener(e, de(this.matchedSetting));
                this.privacySettingsListeners.push(e)
            }
            reportEmptyGeolocation(e) {
                if (this.reportedMissingGeolocation) return;
                this.reportedMissingGeolocation = !0;
                const t = `${this.apiBaseUrl}/geolocation-reporting`;
                navigator && navigator.sendBeacon ? navigator.sendBeacon(t, JSON.stringify(e)) : fetch(`${t}${e?"?missingRegionInUS=true":""}`, {
                    keepalive: !0
                }).catch((() => {
                    fn("unable to report missing geolocation data")
                }))
            }
            setHubSpotConsent(e) {
                const t = pe.fromCategories(e);
                this.consent = t;
                this.privacyConsentListeners.forEach((e => this.safeCallListener(e, t.getSafeCopy())))
            }
        }
        const Ln = new CustomEvent(k);
        class Nn {
            constructor(e) {
                this.priorityFunctions = ["setApiBaseUrl", "setCookiesToSubdomain", "setUseSecureCookies", "addCookieDomain", "addEnabledFeatureGates", "setBusinessUnitId", "setBannerSettings"];
                const n = e.getWindow();
                if (Array.isArray(n[t])) this.queue = n[t];
                else {
                    this.queue = [];
                    n[t] = this.queue
                }
                this.banner = new An(e);
                this.context = e
            }
            queuePushFn(e) {
                try {
                    if (!(e && Array.isArray(e) && e.length > 0)) {
                        B.debug("invalid arguments passed to the banner queue.");
                        return !1
                    }
                    const t = e[0],
                        n = e.slice(1);
                    this.banner.invoke(t, n);
                    return !0
                } catch (e) {
                    B.error("There was an error running banner method.")
                }
                return !1
            }
            overrideQueuePush() {
                this.queue.push = this.queuePushFn.bind(this)
            }
            dequeueEntries(e) {
                for (let t = 0; t < this.queue.length; t++) {
                    const n = this.queue[t];
                    if (!Array.isArray(n) || 0 === n.length) continue;
                    const o = n[0];
                    if (e.includes(o)) {
                        this.queuePushFn(n);
                        this.queue.splice(t--, 1)
                    }
                }
            }
            dequeueAllEntries() {
                for (let e = 0; e < this.queue.length; e++) {
                    const t = this.queue[e];
                    if (Array.isArray(t) && 0 !== t.length) {
                        this.queuePushFn(t);
                        this.queue.splice(e--, 1)
                    }
                }
            }
            run() {
                const e = this.context.getWindow(),
                    t = this.context.getDocument();
                if (!e[a]) {
                    e[a] = !0;
                    this.dequeueEntries(["setUseGeoLocation"]);
                    this.dequeueEntries(this.priorityFunctions);
                    this.dequeueAllEntries();
                    this.overrideQueuePush();
                    if (this.banner.useGeoLocation) {
                        xn(e, "geolocationRequestInCriticalPath", !0);
                        this.banner.getCurrentGeoLocation().then((e => {
                            this.banner.setGeoLocation(e);
                            this.banner.run();
                            t.dispatchEvent(Ln)
                        }))
                    } else {
                        this.banner.run();
                        t.dispatchEvent(Ln)
                    }
                }
            }
        }

        function Bn(t) {
            const n = t.getWindow(),
                o = t.getDocument();
            if (n[e]) {
                B.info("the cookie banner has already been loaded via another script.");
                return
            }
            n[e] = !0;
            xn(n, "bannerStartAt", Cn());
            o.addEventListener(k, (() => {
                xn(n, "bannerReadyAt", Cn())
            }));
            new Nn(t).run()
        }

        function Rn(e, t) {
            bn((() => {
                Bn(e)
            }), t)
        }

        function Pn(e, t) {
            const n = e.getWindow(),
                o = e.getDocument();
            n.hsCookieBanner = {
                rawPerfMetrics: vn(),
                getPerfMetrics: () => yn(n)
            };
            xn(n, "bannerInitAt", Cn());

            function i() {
                Rn(e, t);
                o.removeEventListener("DOMContentLoaded", i)
            }
            "loading" === o.readyState ? o.addEventListener("DOMContentLoaded", i) : Rn(e, t)
        }
        const Dn = L();
        bn((() => {
            Pn(Dn, fn)
        }), fn)
    }()
}();