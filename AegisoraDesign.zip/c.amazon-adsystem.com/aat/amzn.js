/* Use of this pixel is subject to the Amazon ad specs and policies at http://www.amazon.com/b/?&node=7253015011. Version number: 6, Changeset: Adding in phone number support for setUserData */ ! function() {
    "use strict";
    const e = 1e3,
        t = 86400 * e;
    var n = {
        NAME_MAX_LENGTH: 256,
        EVENT_PARAMETER_MAX_VALUE_LENGTH: 1e3,
        EVENT_NAME_EXCEEDED_MAX_LENGTH_WARNING: "Length of event's name is longer than 256 characters.",
        EVENT_PARAMETER_NAME_EXCEEDED_MAX_LENGTH_WARNING: "Length of event's parameter name exceeds 256 characters.",
        EVENT_PARAMETER_VALUE_EXCEEDED_MAX_LENGTH_WARNING: "Length of event's parameter value exceeds 1000 characters.",
        EVENT_PARAMETER_KEY_EXCEEDED_MAX_LENGTH_WARNING: "Length of event's parameter key exceeds 256 characters.",
        AMZN_TOKEN_COOKIE_NAME: "aatToken",
        AMZN_TOKEN_URL_QUERY_PARAM_NAME: "amznToken",
        NO_CONSENT_COOKIE_NAME: "AMZN-NoCookieConsent",
        MEASUREMENT_TOKEN_SOURCE_QUERY_PARAM_NAME: "arefsSource",
        MT_LP_QUERY_PARAM: "aref",
        MTS_EVENT_ATTRIBUTE: "arefs",
        MEASUREMENT_TOKEN_COOKIE_NAME: "amznAref",
        MEASUREMENT_TOKEN_EVENT_FIRE_URL_QUERY_PARAM_NAME: "arefs",
        MEASUREMENT_TOKEN_FETCH_COUNTRY_HEADER: "https://c.amazon-adsystem.com/aat/amzn.js",
        MS_IN_SEC: e,
        MS_IN_HOUR: 3600 * e,
        MS_IN_DAY: t,
        MEASUREMENT_TOKEN_TTL_IN_MS: 30 * t,
        NUM_MAX_MEASUREMENT_TOKENS: 147,
        MEASUREMENT_TOKEN_TIMESTAMP_PAIR_DELIMITER: "|",
        MEASUREMENT_TIMESTAMP_SEPARATOR: ".",
        MT_TS_PAIR_TS_INDEX: 1,
        NEWEST_MEASUREMENT_TOKEN_INDEX: 0,
        MEASUREMENT_TOKEN_FULLY_ENABLED_REGIONS: ["NA", "FE"],
        ARBITRARY_PAST_UNIX_TIMESTAMP: 1,
        AMAZON_CONSENT_AIPES_ENABLED: !1,
        AIPES_AMAZON_CONSENT_STRING_FIELD_NAME: "amazonConsentString",
        AIPES_AMAZON_CONSENT_GEO_FIELD_NAME: "geo",
        AIPES_AMAZON_CONSENT_CONSENT_FIELD_NAME: "consent",
        AIPES_AMAZON_CONSENT_AMAZON_CONSENT_FIELD_NAME: "amazonConsentFormat",
        AIPES_AMAZON_CONSENT_AD_STORAGE_FIELD_NAME: "amzn_ad_storage",
        AIPES_AMAZON_CONSENT_USER_DATA_FIELD_NAME: "amzn_user_data",
        AIPES_AMAZON_CONSENT_GPP_FIELD_NAME: "gpp",
        AIPES_AMAZON_CONSENT_TCF_FIELD_NAME: "tcf",
        AIPES_AMAZON_CONSENT_COUNTRY_CODE_FIELD_NAME: "countryCode",
        AIPES_AMAZON_CONSENT_IP_ADDRESS_FIELD_NAME: "ipAddress",
        REPORTING_ATTRIBUTES: ["brand", "category", "productid", "attr1", "attr2", "attr3", "attr4", "attr5", "attr6", "attr7", "attr8", "attr9", "attr10"],
        REPORTING_ATTRIBUTE_MAX_LENGTH: 256,
        REPORTING_ATTRIBUTE_NOT_ALLOWED_CHARACTERS_REGEX: /[^a-zA-Z0-9_]/,
        REPORTING_ATTRIBUTE_SPACE_REPLACEMENT_REGEX: /[^a-zA-Z0-9]+/g,
        REPORTING_ATTRIBUTE_MAX_LENGTH_WARNING: "Length of attribute must be between 1 and 256 characters.",
        REPORTING_ATTRIBUTE_PROHIBITED_CHARACTERS_WARNING: "Attribute may only contain letters, numbers, and the underscore character.",
        REPORTING_ATTRIBUTE_VALUE_NOT_STRING_WARNING: "Attribute must be a string and cannot be an object or array.",
        CHROME_EXTENSION_ID: "lfljgabnenicfhcbbfflijkeoebncchk",
        GDPR_VALUES: ["gdpr", "gdpr_pd", "gdpr_consent"],
        CONSENT_COOKIE_NAME: "amzn_consent",
        CONSENT_COOKIE_TTL_IN_MS: 24192e5,
        CONFIG_CDN_BASE: "https://c.amazon-adsystem.com/aat/config",
        ALLOWLIST_URL: "https://c.amazon-adsystem.com/aat/allowlist/allowlist.json",
        PAGE_VIEW_EVENT: "PageView",
        TRIGGER_TYPE_CLICK: "CLICK",
        TRIGGER_TYPE_URL_VISIT: "URL_VISIT"
    };
    const o = n,
        r = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;
    const s = ["AD", "AL", "AT", "BA", "BE", "BG", "BY", "CH", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "GR", "HR", "HU", "IE", "IS", "IT", "LI", "LT", "LU", "LV", "MC", "MD", "ME", "MK", "MT", "NL", "NO", "PL", "PT", "RO", "RS", "RU", "SE", "SI", "SK", "SM", "UA", "UK", "VA"];

    function a(e) {
        return !(!e || "string" != typeof e) && s.includes(e.toUpperCase())
    }
    var i = {
        isEmpty: function(e) {
            return null == e || "" === e || 0 === Object.keys(e).length || 0 === e.length
        },
        isValidAdTag: function(e) {
            return e && r.test(e)
        },
        measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie: function(e) {
            return e.map((e => e.join(o.MEASUREMENT_TIMESTAMP_SEPARATOR))).join(o.MEASUREMENT_TOKEN_TIMESTAMP_PAIR_DELIMITER)
        },
        measurementTokenCookieToMeasurementTokenTimestampPairsNestedArr: function(e) {
            return e ? e.split(o.MEASUREMENT_TOKEN_TIMESTAMP_PAIR_DELIMITER).map((e => {
                const [t, n] = e.split(o.MEASUREMENT_TIMESTAMP_SEPARATOR);
                return [t, Number(n)]
            })) : []
        },
        getMeasurementTokenTimestamp: function() {
            return window.performance && window.performance.timeOrigin ? Math.ceil(window.performance.timeOrigin) : Date.now()
        },
        isEUCountry: a,
        getRegionFromCountryCode: function(e, t = "NA") {
            return a(e) ? "EU" : t
        }
    };
    const c = n;

    function E() {}
    E.prototype.isCookiePresent = function(e) {
        return document.cookie.split(";").some((t => t.trim().startsWith(`${e}=`))) && !E.prototype.isCookieMarkedForDeletion(e)
    }, E.prototype.isCookieMarkedForDeletion = function(e) {
        return "0" === E.prototype.getCookieValue(e)
    }, E.prototype.getCookieValue = function(e) {
        return document.cookie.split(";").find((t => t.trim().startsWith(`${e}=`))) ? .split("=")[1]
    }, E.prototype.writeCookie = function(e, t, n) {
        const o = new Date(n).toUTCString();
        document.cookie = `${e}=${t}; expires=${o}; SameSite=Strict; secure=true;`
    }, E.prototype.deleteCookie = function(e) {
        E.prototype.writeCookie(e, "0", c.ARBITRARY_PAST_UNIX_TIMESTAMP)
    };
    var l = E;
    const u = n,
        d = l,
        _ = i;

    function A(e, t, n) {
        e.searchParams.set(t, n);
        const o = Array.from(e.searchParams.entries());
        e.search = "", o.forEach((n => {
            n[0] !== t && e.searchParams.set(n[0], n[1])
        })), e.search += `&${t}=${n}`
    }

    function T(e, t, n) {
        const o = !t || "" === t.trim() || "UNKNOWN" === t,
            r = new URLSearchParams(window.location.search).get(u.MT_LP_QUERY_PARAM),
            s = new d;
        if (n || "EU" === t || o) return function(e, t) {
            if (!t) return;
            const n = _.getMeasurementTokenTimestamp(),
                o = _.measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie([
                    [t, n]
                ]);
            e.searchParams.set(u.MEASUREMENT_TOKEN_SOURCE_QUERY_PARAM_NAME, "url"), e.searchParams.set(u.MEASUREMENT_TOKEN_EVENT_FIRE_URL_QUERY_PARAM_NAME, o)
        }(e, r), null;
        u.MEASUREMENT_TOKEN_FULLY_ENABLED_REGIONS.includes(t) && function(e, t, n) {
            let o, r = n.getCookieValue(u.MEASUREMENT_TOKEN_COOKIE_NAME);
            if (r = function(e) {
                    if (!e) return;
                    const t = _.getMeasurementTokenTimestamp() - u.MEASUREMENT_TOKEN_TTL_IN_MS,
                        n = _.measurementTokenCookieToMeasurementTokenTimestampPairsNestedArr(e).filter((([, e]) => e > t));
                    return n.length > 0 ? _.measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie(n) : void 0
                }(r), t) {
                const e = [t, _.getMeasurementTokenTimestamp()];
                if (r) {
                    const n = _.measurementTokenCookieToMeasurementTokenTimestampPairsNestedArr(r).filter((([e]) => e !== t));
                    r = _.measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie([e, ...n]), o = n.length ? "urlAndCookie" : "url"
                } else r = _.measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie([e]), o = "url"
            } else r && (o = "cookie");
            r && o && (e.searchParams.set(u.MEASUREMENT_TOKEN_SOURCE_QUERY_PARAM_NAME, o), e.searchParams.set(u.MEASUREMENT_TOKEN_EVENT_FIRE_URL_QUERY_PARAM_NAME, r))
        }(e, r, s)
    }
    var h = {
        createQueryParams: function(e, {
            tagId: t,
            eventName: n,
            eventAttributes: o,
            consent: r,
            uuid: s,
            amazonConsent: a,
            region: i
        }) {
            const c = "string" == typeof e ? new URL(e) : e;
            if (_.isEmpty(t)) throw new Error("Tag ID is a required parameter.");
            if (!_.isValidAdTag(t)) throw new Error("Invalid ad tag provided.");
            if (c.searchParams.set("pid", t), _.isEmpty(n)) throw new Error("Event name is a required parameter.");
            if (c.searchParams.set("event", n), Array.isArray(o) && A(c, "items", encodeURI(JSON.stringify(o))), o && Object.entries(o).forEach((([e, t]) => {
                    u.GDPR_VALUES.includes(e) || (t || "" === t) && ("object" == typeof t ? c.searchParams.set(e, JSON.stringify(t)) : c.searchParams.set(e, String(t)))
                })), !Array.isArray(o)) {
                const e = o ? .clientDedupeId,
                    t = o ? .eventId,
                    n = "string" == typeof e && e ? e : t;
                "string" == typeof n && n && (c.searchParams.set("clientDedupeId", n), c.searchParams.set("eventId", n))
            }
            r && u.GDPR_VALUES.forEach((e => {
                r[e] && c.searchParams.set(e, r[e])
            }));
            let E = "EU" === i || "UK" === i,
                l = null;
            a && (l = JSON.stringify(a), c.searchParams.set(u.AIPES_AMAZON_CONSENT_STRING_FIELD_NAME, l), "{}" !== l && '"null"' !== l && "undefined" !== l && (E = !0));
            const h = new d;
            if (h.isCookiePresent(u.AMZN_TOKEN_COOKIE_NAME)) {
                const e = h.getCookieValue(u.AMZN_TOKEN_COOKIE_NAME);
                e && A(c, u.AMZN_TOKEN_URL_QUERY_PARAM_NAME, e)
            }
            return T(c, i, E ? l : null), c.searchParams.set("eventSource", "amzn.js"), s && c.searchParams.set("uuid", s), c
        }
    };
    const {
        createQueryParams: p
    } = h, m = {
        "Google Chrome": 106,
        Chromium: 106
    }, N = "paa-reporting-advertising.amazon";

    function f(e) {
        const t = "/assets/conversion_module.js";
        switch (e.toLowerCase()) {
            case "beta":
            case "test":
                return `https://beta-ara.${N}${t}`;
            case "gamma":
                return `https://gamma-ara.${N}${t}`;
            default:
                return `https://ara.${N}${t}`
        }
    }

    function g() {
        const {
            userAgentData: e
        } = navigator;
        return null != e && function(e) {
            return e.some((({
                brand: e,
                version: t
            }) => m[e] <= t))
        }(e.brands)
    }
    async function y(e, t) {
        try {
            const n = f(t);
            if (e && n) {
                const t = await e.json();
                return t && 0 !== Object.keys(t).length && "healthy" !== t ? (await (sharedStorage ? .createWorklet(n, {
                    dataOrigin: "script-origin"
                }))).run("conversion-module", {
                    data: t,
                    privateAggregationConfig: {
                        contextId: t ? .debugKey
                    }
                }) : Promise.resolve(!1)
            }
        } catch {}
        return Promise.resolve(!1)
    }
    var I = {
        performTriggerRegistration: async function(e) {
            const {
                stage: t
            } = e;
            if (!g() || !(document ? .featurePolicy ? .allowsFeature ? .("attribution-reporting") && document ? .featurePolicy ? .allowsFeature ? .("private-aggregation") && document ? .featurePolicy ? .allowsFeature ? .("shared-storage"))) return Promise.resolve(!1);
            const n = function(e) {
                    let t;
                    switch (e.toLowerCase()) {
                        case "beta":
                        case "test":
                            t = `https://beta-ara.${N}/aat`;
                            break;
                        case "gamma":
                            t = `https://gamma-ara.${N}/aat`;
                            break;
                        default:
                            t = `https://ara.${N}/aat`
                    }
                    return new URL(t)
                }(t),
                o = p(n, e),
                r = await async function(e) {
                    const t = {
                        credentials: "same-origin",
                        keepalive: !0,
                        attributionReporting: {
                            eventSourceEligible: !1,
                            triggerEligible: !0
                        }
                    };
                    let n;
                    try {
                        n = await (window ? .fetch(e, t))
                    } catch {}
                    return n
                }(o.href);
            return y(r, t), r
        },
        generateUUID: function() {
            return typeof crypto < "u" && "function" == typeof crypto.randomUUID ? crypto.randomUUID() : ""
        },
        generateWorkletUrl: f,
        runSharedStorageWorklet: y
    };
    const R = n;

    function M(e, t, n) {
        e.length > R.NAME_MAX_LENGTH && t.push(`${n}, ${e}`)
    }
    var C = {
        validateLength: M,
        validateEventAttributesAsArray: function(e, t) {
            e.forEach((function(e) {
                M(Object.keys(e)[0], t, R.EVENT_PARAMETER_NAME_EXCEEDED_MAX_LENGTH_WARNING), M(e[Object.keys(e)[0]], t, R.EVENT_PARAMETER_VALUE_EXCEEDED_MAX_LENGTH_WARNING)
            }))
        },
        filterGdprValuesOut: function(e) {
            return !R.GDPR_VALUES.includes(e)
        },
        validateCustomAttributesForReporting: function(e, t) {
            let n;
            const o = t[e];
            let r = o;
            const s = e.toLowerCase();
            return R.REPORTING_ATTRIBUTES.includes(s) && (n = {}, n[s] = {
                messages: []
            }, (o.length > R.REPORTING_ATTRIBUTE_MAX_LENGTH || o.length < 1) && n[s].messages.push(R.REPORTING_ATTRIBUTE_MAX_LENGTH_WARNING), "string" == typeof o ? (r = r.trim(), r = o.replaceAll(R.REPORTING_ATTRIBUTE_SPACE_REPLACEMENT_REGEX, "_").trim(), R.REPORTING_ATTRIBUTE_NOT_ALLOWED_CHARACTERS_REGEX.test(r) && n[s].messages.push(R.REPORTING_ATTRIBUTE_PROHIBITED_CHARACTERS_WARNING)) : n[s].messages.push(R.REPORTING_ATTRIBUTE_VALUE_NOT_STRING_WARNING), 0 === n[s].messages.length ? n = void 0 : (n[s].value = r, r = void 0)), {
                eventReportingAttributeWarnings: n,
                newAttributeValue: r
            }
        },
        validateAttributeValueAsObject: function(e, t) {
            if ("object" == typeof e && Object.keys(e) && Object.keys(e)[0]) return Object.keys(e).forEach((function(n) {
                n.length > R.NAME_MAX_LENGTH && t.push(`${R.EVENT_PARAMETER_KEY_EXCEEDED_MAX_LENGTH_WARNING}, ${n}`), e[n].length > R.EVENT_PARAMETER_MAX_VALUE_LENGTH && t.push(`${R.EVENT_PARAMETER_VALUE_EXCEEDED_MAX_LENGTH_WARNING}, ${e[n]}`)
            })), encodeURI(JSON.stringify(e))
        },
        validateAttributeValueAsString: function(e, t) {
            "string" == typeof e && e.length > R.EVENT_PARAMETER_MAX_VALUE_LENGTH && t.push(`${R.EVENT_PARAMETER_VALUE_EXCEEDED_MAX_LENGTH_WARNING}, ${e}`)
        }
    };
    const S = n,
        {
            isEmpty: O,
            isValidAdTag: v
        } = i,
        {
            createQueryParams: k
        } = h,
        {
            generateUUID: P
        } = I,
        {
            validateLength: w,
            validateEventAttributesAsArray: U,
            filterGdprValuesOut: L,
            validateCustomAttributesForReporting: D,
            validateAttributeValueAsString: b,
            validateAttributeValueAsObject: G
        } = C,
        H = l,
        K = /^[A-Za-z0-9]{1,100}$/;

    function z(e, t) {
        this.endpoints = e, this.region = "NA", this.stage = "PROD", this.countryCode = null, this.tagIdsByLabels = {}, this.TCFv2 = {}, this.consentHandler = t, this.matchId = null, this.matchIdCookieName = null
    }

    function V(e, t, n) {
        const o = document.createElement("iframe");
        o.style.display = "none", o.setAttribute("src", e), o.setAttribute("id", `tag_fire_${t}_${n}_${Date.now()}`), document.body.appendChild(o)
    }
    z.prototype.addTag = function({
        tagId: e,
        tagLabel: t
    }) {
        if (O(e)) return void console.warn("Tag id is required for addTag command");
        if (!v(e)) return void console.warn(`Invalid tag id provided: ${e}`);
        const n = O(t) ? e : t;
        this.tagIdsByLabels[n] = e
    }, z.prototype.getTagIds = function(e) {
        const {
            tagIdsByLabels: t
        } = this;
        return e.map((function(e) {
            return t[e] || e
        }))
    }, z.prototype.getAllTagIds = function() {
        return Object.values(this.tagIdsByLabels)
    }, z.prototype.trackEvent = async function(e, t, n) {
        return this.trackEventWithTags(e, t, n, Object.keys(this.tagIdsByLabels))
    }, z.prototype.trackRequest = async function(e, t, n, o) {
        const r = P(),
            s = this.matchIdCookieName ? H.prototype.getCookieValue(this.matchIdCookieName) : this.matchId;
        let a = { ...this.TCFv2[e]
        };
        const i = this.consentHandler.getTcfString();
        this.consentHandler.isConsentSet() && i && (void 0 === a.gdpr_consent || "" === a.gdpr_consent) && (a = {
            gdpr: 1,
            gdpr_pd: 1,
            gdpr_consent: i
        });
        try {
            await async function({
                eventIngestionEndpoint: e,
                consent: t,
                eventAttributes: n,
                eventName: o,
                tagId: r,
                uuid: s,
                consentHandler: a,
                region: i,
                countryCode: c,
                matchId: E
            }) {
                const l = [],
                    u = {},
                    d = n ? JSON.parse(JSON.stringify(n)) : {};
                if (w(o, l, S.EVENT_NAME_EXCEEDED_MAX_LENGTH_WARNING), Array.isArray(n) ? U(n, l) : n && Object.keys(n).filter(L).forEach((function(e) {
                        w(e, l, S.EVENT_PARAMETER_NAME_EXCEEDED_MAX_LENGTH_WARNING);
                        const t = n[e];
                        if ("clientDedupeId" === e || "eventId" === e) return void(("string" != typeof t || !t || t[256]) && delete d[e]);
                        const {
                            newAttributeValue: o,
                            eventReportingAttributeWarnings: r
                        } = D(e, d);
                        r && (u[e] = r[e.toLowerCase()]), void 0 === o ? delete d[e] : d[e] = o, t ? (b(t, l), G(t, l)) : console.warn(`Key ${e} has no value`)
                    })), l.length) {
                    const e = `Event has ${l.length} validation errors.`;
                    return console.warn(e), console.warn(l), Promise.reject(e)
                }
                let _;
                E && !Object.prototype.hasOwnProperty.call(d, "MATCH_ID") && (d.MATCH_ID = E);
                try {
                    const e = a.getFormattedAmazonConsent(!1);
                    e && e.geo && e.geo.countryCode && (_ = e.geo.countryCode)
                } catch (e) {
                    console.warn("Error extracting consent country code:", e)
                }
                const A = k(new URL(e), {
                    tagId: r,
                    eventName: o,
                    eventAttributes: d,
                    consent: t,
                    uuid: s,
                    region: i,
                    amazonConsent: a.getFormattedAmazonConsent(!1),
                    countryCode: c,
                    consentCountryCode: _
                }).href;
                if (Object.keys(u).length && window.chrome ? .runtime) try {
                    window.chrome.runtime.sendMessage(S.CHROME_EXTENSION_ID, {
                        adTagEventWarnings: !0,
                        eventUrl: A,
                        attributeWarnings: u
                    })
                } catch {}
                if (!window.fetch) return V(A, r, o);
                try {
                    return await fetch(A, {
                        method: "get",
                        credentials: "include",
                        mode: "no-cors",
                        keepalive: !0
                    })
                } catch {
                    return console.warn("Event request via fetch failed, reverting to iframe"), V(A, r, o)
                }
            }({
                eventIngestionEndpoint: t,
                consent: a,
                eventAttributes: o,
                eventName: n,
                tagId: e,
                uuid: r,
                consentHandler: this.consentHandler,
                region: this.region,
                countryCode: this.countryCode,
                matchId: "string" == typeof s && K.test(s) ? s : null
            })
        } catch (e) {
            return console.warn("Event request failed.", e), Promise.reject(e)
        }
        try {
            const {
                performTriggerRegistration: t
            } = I;
            await t({
                stage: this.stage,
                consent: a,
                tagId: e,
                eventName: n,
                eventAttributes: o,
                uuid: r,
                region: this.region
            })
        } catch (e) {
            console.warn("ARA trigger registration failed", e)
        }
        return Promise.resolve()
    }, z.prototype.trackEventWithTags = async function(e, t, n, o) {
        const r = this.getPixelEndpoint(this.region),
            s = t || {},
            a = "No eventName name specified.",
            i = "No valid endpoint.";
        if (!e) return console.warn(a), Promise.reject(a);
        if (!r) return console.warn(i), Promise.reject(i);
        n && (s.ts = n);
        const c = this.getTagIds(o).map((t => this.trackRequest(t, r, e, s)));
        return Promise.all(c)
    }, z.prototype.trackPixel = function(e, t, n) {
        let o;
        const r = {};
        let s = t || "";
        s = s.split("?"), o = s.length > 1 ? s[1] : s[0], o = o.split("&"), o.forEach((e => {
            const t = e.split("=");
            let n, o;
            t.length <= 1 || ("ex-fargs" === t[0] ? (n = this.parsePixelArgs(t[1], "&"), r.fargs_id = n.id, r.fargs_type = n.type) : "ex-hargs" === t[0] && (o = this.parsePixelArgs(t[1], ";"), r.hargs_c = o.c, r.hargs_p = o.p))
        })), this.validatePixelData(r), Object.keys(r).forEach((function(e) {
            r[e] || delete r[e]
        })), this.trackEvent(e, r, n)
    }, z.prototype.addTCFv2 = function(e) {
        this.addTCFv2WithTags(e, Object.keys(this.tagIdsByLabels))
    }, z.prototype.addTCFv2WithTags = function(e, t) {
        const {
            TCFv2: n
        } = this;
        this.getTagIds(t).forEach((function(t) {
            n[t] = e
        }))
    }, z.prototype.getPixelEndpoint = function(e) {
        const t = this.endpoints[e.toUpperCase()];
        return "" === t || null == t ? (console.warn("Endpoint does not exist, please check your region configuration!"), null) : t
    }, z.prototype.parsePixelArgs = function(e, t) {
        let n = decodeURIComponent(e);
        const o = {};
        return n = n.replace(/\?/g, ""), n.split(t).forEach((function(e) {
            const t = e.split("=");
            if (t.length > 1) {
                const [e, n] = t;
                o[e] = n
            }
        })), o
    }, z.prototype.validatePixelData = function(e) {
        const t = e.hargs_c && e.hargs_p,
            n = e.fargs_id && e.fargs_type;
        !t && !n && console.warn("Invalid arguments for a trackPixel event, please check your implementation!")
    }, z.prototype.setRegion = function(e) {
        this.region = e
    }, z.prototype.setStage = function(e) {
        this.stage = e
    }, z.prototype.setMatchId = function(e) {
        null !== e ? "string" == typeof e && K.test(e) ? this.matchId = e : console.warn("Invalid Match ID. Expected 1-100 alphanumeric characters or null to clear.") : this.matchId = null
    }, z.prototype.setMatchIdCookieName = function(e) {
        this.matchIdCookieName = "string" == typeof e && e ? e : null
    }, z.prototype.setCountryCode = function(e) {
        e && "string" == typeof e ? this.countryCode = e.toUpperCase() : console.warn("Invalid country code provided")
    }, z.prototype.getCountryCode = function() {
        return this.countryCode
    };
    var F = z;
    const $ = n,
        {
            measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie: j,
            measurementTokenCookieToMeasurementTokenTimestampPairsNestedArr: X,
            getMeasurementTokenTimestamp: x
        } = i,
        W = "AIPToken",
        B = "cookieExpiry",
        Z = {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "omit",
            headers: {
                "Content-Type": "application/json"
            },
            redirect: "follow",
            referrerPolicy: "no-referrer-when-downgrade"
        };

    function Y(e) {
        this.cookieHandler = e, this.alreadySavedMeasurementToken = !1, window.addEventListener("load", (() => {
            this.alreadySavedMeasurementToken = !1
        }))
    }
    Y.prototype.saveMeasurementTokenInURLToCookieIfPresent = function(e, t) {
        try {
            if (t || -1 === $.MEASUREMENT_TOKEN_FULLY_ENABLED_REGIONS.indexOf(e) || this.alreadySavedMeasurementToken) return;
            const n = new URLSearchParams(window.location.search).get($.MT_LP_QUERY_PARAM);
            if (!n) return;
            let o = this.cookieHandler.getCookieValue($.MEASUREMENT_TOKEN_COOKIE_NAME);
            o && o ? .split($.MEASUREMENT_TOKEN_TIMESTAMP_PAIR_DELIMITER).length >= $.NUM_MAX_MEASUREMENT_TOKENS && (o = j(X(o).slice(0, -1)));
            const r = performance && performance.timeOrigin ? Math.ceil(performance.timeOrigin) : Date.now(),
                s = X(o || ""),
                a = j([
                    [n, r]
                ].concat(s)),
                i = r + $.MEASUREMENT_TOKEN_TTL_IN_MS;
            this.cookieHandler.writeCookie($.MEASUREMENT_TOKEN_COOKIE_NAME, a, i), this.alreadySavedMeasurementToken = !0
        } catch (e) {
            console.error("[AAT] Error saving measurement token from URL to cookie:", e)
        }
    }, Y.prototype.removeAnyExpiredMeasurementTokens = function() {
        try {
            const e = this.cookieHandler.getCookieValue($.MEASUREMENT_TOKEN_COOKIE_NAME);
            if (!e) return;
            const t = x() - $.MEASUREMENT_TOKEN_TTL_IN_MS,
                n = X(e).filter((([, e]) => e > t));
            if (0 === n.length) return this.cookieHandler.deleteCookie($.MEASUREMENT_TOKEN_COOKIE_NAME), void(this.alreadySavedMeasurementToken = !1);
            const o = j(n),
                r = n[$.NEWEST_MEASUREMENT_TOKEN_INDEX][$.MT_TS_PAIR_TS_INDEX] + $.MEASUREMENT_TOKEN_TTL_IN_MS;
            this.cookieHandler.writeCookie($.MEASUREMENT_TOKEN_COOKIE_NAME, o, r)
        } catch {}
    }, Y.prototype.formatRequestBody = function(e) {
        const t = {};
        if (null !== e.gdpr && (t.gdpr = e.gdpr.enabled ? 1 : 0, null !== e.gdpr.consent && (t.gdprConsent = e.gdpr.consent)), null === e.hashedRecords) throw Error("hashedRecords array is null");
        if (0 === e.hashedRecords.length) throw Error("hashedRecords array is empty");
        return t.hashedRecords = e.hashedRecords, null !== e.ttl && (t.ttl = e.ttl), void 0 !== e.consentString && (t[$.AIPES_AMAZON_CONSENT_STRING_FIELD_NAME] = e.consentString), t
    }, Y.prototype.requestAmznToken = async function(e) {
        const t = { ...Z,
                body: JSON.stringify(e)
            },
            n = await fetch("https://tk.amazon-adsystem.com/envelope", t);
        if (n.ok) return await n.json();
        const o = await n.text();
        throw Error(o)
    }, Y.prototype.renewAmznToken = async function(e) {
        if (!this.cookieHandler.isCookiePresent($.AMZN_TOKEN_COOKIE_NAME) && !this.cookieHandler.isCookiePresent($.NO_CONSENT_COOKIE_NAME)) try {
            const t = this.formatRequestBody(e),
                n = await this.requestAmznToken(t);
            return "" === n[W] ? this.cookieHandler.writeCookie($.NO_CONSENT_COOKIE_NAME, n[W], n[B]) : this.cookieHandler.writeCookie($.AMZN_TOKEN_COOKIE_NAME, n[W], n[B]), n
        } catch (e) {
            console.error(e)
        }
        return "no-op"
    }, Y.prototype.deleteAmznToken = async function() {
        this.cookieHandler.isCookiePresent($.AMZN_TOKEN_COOKIE_NAME) && this.cookieHandler.deleteCookie($.AMZN_TOKEN_COOKIE_NAME), this.cookieHandler.isCookiePresent($.NO_CONSENT_COOKIE_NAME) && this.cookieHandler.deleteCookie($.NO_CONSENT_COOKIE_NAME)
    }, Y.prototype.updateAmznToken = async function(e) {
        return await this.deleteAmznToken(), this.renewAmznToken(e)
    };
    var Q = Y;

    function q(e, t) {
        this.tokensHandler = e, this.consentHandler = t
    }
    async function J(e) {
        const t = (new TextEncoder).encode(e),
            n = await crypto.subtle.digest("SHA-256", t);
        return Array.from(new Uint8Array(n)).map((e => e.toString(16).padStart(2, "0"))).join("")
    }

    function ee(e) {
        return null != e && "string" == typeof e && e.length > 0
    }
    q.prototype.setUserData = async function(e) {
        const t = {
                gdpr: {
                    enabled: !1,
                    consent: ""
                },
                hashedRecords: [],
                ttl: 9600
            },
            n = e[1];
        n.gdpr && (t.gdpr = n.gdpr), n.ttl && (t.ttl = n.ttl);
        const o = /[A-Fa-f0-9]{64}/;
        if (ee(n.email)) {
            const e = {
                type: "email",
                record: ""
            };
            n.email = n.email.trim().toLowerCase(), o.test(n.email) ? e.record = n.email : e.record = await J(n.email), t.hashedRecords.push(e)
        }
        if (ee(n.phonenumber)) {
            const e = {
                type: "phonenumber",
                record: ""
            };
            o.test(n.phonenumber) ? e.record = n.phonenumber : e.record = await J(function(e) {
                let t = e.replace(/[^\d+]+/g, "");
                return t = t.replace(/^00/, "+"), t.match(/^1/) && (t = `+${t}`), t.match(/^\+/) || (t = `+1${t}`), t = t.replace(/^\+/, ""), t
            }(n.phonenumber)), t.hashedRecords.push(e)
        }
        if (this.consentHandler.isConsentSet() && this.consentHandler.isAipesEgressEnabled()) {
            t.consentString = this.consentHandler.getFormattedAmazonConsent(!1);
            const e = this.consentHandler.getTcfString();
            void 0 !== e && "" !== e && "" === t.gdpr.consent && (t.gdpr.enabled = !0, t.gdpr.consent = e)
        }
        return t.hashedRecords.length > 0 ? this.tokensHandler.updateAmznToken(t) : Promise.resolve()
    };
    var te = q;
    const {
        isEUCountry: ne
    } = i, oe = n;

    function re(e, t, n, o, r) {
        this.eventTracker = e, this.setUserDataHandler = t, this.tokensHandler = n, this.aatEventsQueue = [], this.isSetUserDataInProcess = !1, this.consentHandler = r
    }
    re.prototype.processCommandQueue = async function(e) {
        return Promise.all((e || []).map((e => this.processCommand(e[0], e[1]))))
    }, re.prototype.processCommand = async function(e, t = Date.now()) {
        const n = Array.prototype.slice.call(e),
            o = e[0],
            r = `Unsupported tag command "${o}"`,
            s = {
                trackevent: (e, t) => this.trackEvent(e, t),
                trackpixel: (e, t) => this.trackPixel(e, t),
                pixel: (e, t) => this.withTag(e, t),
                withtag: (e, t) => this.withTag(e, t),
                addpixel: e => this.addTag(e),
                addtag: e => this.addTag(e),
                addtcfv2: e => this.addTCFv2(e),
                setregion: e => this.setRegion(e),
                setstage: e => this.setStage(e),
                setmatchid: e => this.setMatchId(e),
                setuserdata: e => this.setUserData(e)
            },
            a = o.toLowerCase();
        return s[a] ? s[a](n, t) : (console.warn(r), Promise.reject(r))
    }, re.prototype.setUserData = async function(e) {
        this.isSetUserDataInProcess = !0;
        try {
            await this.setUserDataHandler.setUserData(e), this.isSetUserDataInProcess = !1, this.processAatEventsQueue()
        } catch (e) {
            return console.warn(e), Promise.reject(e)
        }
        return Promise.resolve()
    }, re.prototype.processAatEventsQueue = function() {
        if (this.aatEventsQueue.length)
            for (; this.aatEventsQueue.length;) {
                const {
                    argumentArray: e,
                    timestamp: t,
                    tagLabel: n
                } = this.aatEventsQueue.pop();
                this.trackEvent(e, t, n).catch((e => {
                    console.warn(e)
                }))
            }
    }, re.prototype.trackEvent = async function(e, t, n) {
        if (this.isSetUserDataInProcess) return this.aatEventsQueue.unshift({
            argumentArray: e,
            timestamp: t,
            tagLabel: n
        }), Promise.resolve();
        this.tokensHandler.removeAnyExpiredMeasurementTokens();
        const o = e[1],
            r = e[2];
        return void 0 !== n ? this.eventTracker.trackEventWithTags(o, r, t, [n]) : this.eventTracker.trackEvent(o, r, t)
    }, re.prototype.trackPixel = function(e, t) {
        this.eventTracker.trackPixel("__pixel__", e[1], t)
    }, re.prototype.withTag = async function(e, t) {
        const n = e[1],
            o = e[2] || "",
            r = `Unsupported command "${o}" used after "withTag" command`;
        switch (o.toUpperCase()) {
            case "TRACKEVENT":
                return this.trackEvent(e.slice(2), t, n);
            case "ADDTCFV2":
                this.addTCFv2(e.slice(2), n);
                break;
            default:
                return console.warn(r), Promise.reject(r)
        }
        return Promise.resolve()
    }, re.prototype.addTag = function(e) {
        const t = e[2],
            n = e[1];
        this.eventTracker.addTag({
            tagId: n,
            tagLabel: t
        })
    }, re.prototype.addTCFv2 = function(e, t) {
        const n = e[1];
        void 0 !== t ? this.eventTracker.addTCFv2WithTags(n, [t]) : this.eventTracker.addTCFv2(n)
    }, re.prototype.setRegion = async function(e) {
        const t = (e[1] || "").toUpperCase();
        if ("EU" === t) try {
            this.eventTracker.setRegion("EU"), console.log("[AAT] Region explicitly set to EU");
            try {
                this.tokensHandler.saveMeasurementTokenInURLToCookieIfPresent("EU", !0)
            } catch (e) {
                console.warn("Error saving measurement token in URL to cookie:", e)
            }
            return
        } catch (e) {
            console.warn("[AAT] Error setting region in event tracker:", e)
        }
        let n = null,
            o = !1;
        try {
            n = (await fetch(oe.MEASUREMENT_TOKEN_FETCH_COUNTRY_HEADER, {
                method: "get",
                mode: "cors",
                keepalive: !0
            })).headers.get("x-viewer-country")
        } catch {
            console.log("[AAT] CSP blocked fetch → setting region to UNKNOWN for GDPR safety"), o = !0
        }
        let r = null,
            s = !1;
        try {
            if (this.consentHandler && this.consentHandler.isConsentSet()) {
                s = !0;
                const e = this.consentHandler.getFormattedAmazonConsent(!1);
                e && e.geo && e.geo.countryCode && (r = e.geo.countryCode)
            }
        } catch (e) {
            console.warn("[AAT] Error checking Amazon consent or getting country code:", e)
        }
        let a = t;
        n && ne(n) && (a = "EU"), r && ne(r) && (a = "EU"), o && "EU" !== a && (a = "EU");
        try {
            this.eventTracker.setRegion(a)
        } catch (e) {
            console.warn("[AAT] Error setting region in event tracker:", e)
        }
        try {
            this.tokensHandler.saveMeasurementTokenInURLToCookieIfPresent(a, s)
        } catch (e) {
            console.warn("Error saving measurement token in URL to cookie:", e)
        }
    }, re.prototype.setStage = function(e) {
        const t = e[1].toUpperCase();
        this.eventTracker.setStage(t)
    }, re.prototype.setMatchId = function(e) {
        this.eventTracker.setMatchId(e[1])
    }, re.prototype.listen = function() {
        this.eventListener.init()
    }, re.prototype.setAmazonConsent = function(e) {
        this.consentHandler.setAmazonConsent(e[1])
    };
    var se = re;
    const ae = n;

    function ie(e) {
        this.amazonConsent = void 0, this.cookieHandler = e
    }
    var ce, Ee, le, ue, de, _e;

    function Ae() {
        if (Ee) return ce;
        Ee = 1;
        const e = "textContent";

        function t(t, n) {
            return n && n !== e ? t.getAttribute(n) : t.textContent && t.textContent.trim() || null
        }

        function n(e, n) {
            switch (e.strategy) {
                case "dataLayer":
                    return function(e, t) {
                        if (!Array.isArray(e) || !t) return null;
                        const n = String(t).split(".").reduce(((e, t) => e && "object" == typeof e ? e[t] : void 0), Object.assign({}, ...e.filter((e => e && "object" == typeof e && !Array.isArray(e)))));
                        return null == n || "object" == typeof n ? null : String(n) || null
                    }(window.dataLayer, e.path);
                case "literal":
                    return e.value || null;
                case "self":
                    return e.attribute ? n.getAttribute(e.attribute) : null;
                case "nearest":
                    {
                        if (!e.selector) return null;
                        let o = n;
                        for (; o;) {
                            const n = o.querySelector(e.selector);
                            if (n) return t(n, e.read);
                            o = o.parentElement
                        }
                        return null
                    }
                case "global":
                    {
                        if (!e.selector) return null;
                        const n = document.querySelector(e.selector);
                        return n ? t(n, e.read) : null
                    }
                default:
                    return null
            }
        }
        return ce = {
            resolveParam: n,
            resolveParams: function(e, t) {
                const o = {};
                return Array.isArray(e) && e.forEach((e => {
                    const r = n(e, t);
                    null != r && (o[e.key] = r)
                })), o
            }
        }
    }

    function Te() {
        if (_e) return de;
        _e = 1;
        const e = n,
            t = Ae(),
            o = function() {
                if (ue) return le;

                function e(e, t) {
                    this.config = e, this.setUserData = t
                }
                return ue = 1, e.prototype.detectAndSend = async function() {
                    try {
                        if (!this.config.enabled) return;
                        const e = this.collectFieldValues();
                        if (!e.email && !e.phonenumber) return;
                        await this.setUserData(e)
                    } catch (e) {
                        console.warn("[AAT-PII] PII detection failed (non-fatal):", e)
                    }
                }, e.prototype.collectFieldValues = function() {
                    const e = {};
                    for (const [t, n] of Object.entries(this.config.fields))
                        if (Array.isArray(n))
                            for (const o of n) {
                                const n = this.readFirstValue(o);
                                if (n) {
                                    "email" === t ? e.email = n : "phone" === t && (e.phonenumber = n);
                                    break
                                }
                            }
                    return e
                }, e.prototype.readFirstValue = function(e) {
                    try {
                        const t = document.querySelectorAll(e);
                        for (const e of t)
                            if (e instanceof HTMLInputElement || e instanceof HTMLSelectElement || e instanceof HTMLTextAreaElement) {
                                const t = e.value.trim();
                                if (t) return t
                            } else {
                                const t = e.textContent ? e.textContent.trim() : "";
                                if (t) return t
                            }
                    } catch (t) {
                        console.warn(`[AAT-PII] Invalid selector: ${e}`, t)
                    }
                    return null
                }, le = e
            }();

        function r(e, t) {
            this.eventTracker = e, this.setUserData = t, this.rules = [], this.clickRules = [], this.urlVisitRules = [], this.listenerAttached = !1, this.piiDetector = null, this.handleClick = this.handleClick.bind(this)
        }
        return r.prototype.fetchAndActivate = async function(t) {
            const n = t[0];
            if (!n) return;
            const o = await this.fetchConfig(n);
            if (!o) return;
            if (o.domain && this.sanitizeDomain(o.domain) !== this.sanitizeDomain(window.location.hostname)) return void console.warn(`[AAT] Domain mismatch: config has "${o.domain}" but page is "${window.location.hostname}". Skipping.`);
            this.eventTracker.setMatchIdCookieName("cookie" === o.matchId ? .source ? o.matchId.key : null);
            const r = Array.isArray(o.rules) ? o.rules : [],
                s = r.map((function(t) {
                    return null != t.triggerType ? t : { ...t,
                        triggerType: t.event === e.PAGE_VIEW_EVENT ? e.TRIGGER_TYPE_URL_VISIT : e.TRIGGER_TYPE_CLICK
                    }
                }));
            this.rules = this.filterValidSelectors(s), this.urlVisitRules = this.rules.filter((t => t.triggerType === e.TRIGGER_TYPE_URL_VISIT)), this.clickRules = this.rules.filter((t => t.triggerType === e.TRIGGER_TYPE_CLICK)), this.initPiiDetector(o.piiDetection), console.log(`[AAT] Fetched config for tagId=${n}, domain=${o.domain}`), console.log(`[AAT] Total rules in config: ${r.length}, valid rules loaded: ${this.rules.length}`), console.log("[AAT] Loaded rules:", this.rules.map((function(e) {
                return {
                    id: e.id,
                    event: e.event,
                    triggerType: e.triggerType,
                    page: e.page,
                    selector: e.selector
                }
            }))), this.fireUrlVisitRules(), this.attachClickListener()
        }, r.prototype.initPiiDetector = function(e) {
            if (this.piiDetector = null, e && !0 === e.enabled) {
                if ("function" != typeof this.setUserData) return void console.warn("[AAT-PII] piiDetection present but no setUserData path wired; detection disabled");
                if (!e.fields || "object" != typeof e.fields) return void console.warn("[AAT-PII] piiDetection.enabled but fields missing/invalid; detection disabled");
                this.piiDetector = new o(e, this.setUserData), console.log("[AAT-PII] PII detection initialized")
            }
        }, r.prototype.maybeDetectPiiOnce = function() {
            this.piiDetector && this.piiDetector.detectAndSend().catch((e => {
                console.warn("[AAT-PII] detectAndSend failed (non-fatal):", e)
            }))
        }, r.prototype.fireUrlVisitRules = function() {
            const e = window.location.pathname;
            let n = !1;
            this.urlVisitRules.forEach((o => {
                if (!this.pageMatches(o, e)) return;
                const r = t.resolveParams(o.params, document.body),
                    s = o.conversionType ? { ...r,
                        conversionType: o.conversionType
                    } : r;
                console.log(`[AAT] URL_VISIT rule fired: id=${o.id}, page=${o.page}`, r), this.eventTracker.trackEvent(o.event, s).catch((e => {
                    console.warn("[AAT] trackEvent failed", e)
                })), n = !0
            })), n && this.maybeDetectPiiOnce()
        }, r.prototype.attachClickListener = function() {
            this.listenerAttached || (document.body.addEventListener("click", this.handleClick), this.listenerAttached = !0, console.log("[AAT] Click listener attached"))
        }, r.prototype.handleClick = function(e) {
            const n = e.target;
            if (!(n instanceof Element)) return;
            const o = window.location.pathname;
            let r = !1;
            this.clickRules.forEach((e => {
                if (!this.pageMatches(e, o)) return;
                const s = e.selector ? n.closest(e.selector) : null;
                if (s) {
                    const n = () => {
                        const n = t.resolveParams(e.params, s),
                            o = e.conversionType ? { ...n,
                                conversionType: e.conversionType
                            } : n;
                        console.log(`[AAT] Rule matched: id=${e.id}, event=${e.event}, selector=${e.selector}`, n), this.eventTracker.trackEvent(e.event, o).catch((e => {
                            console.warn("[AAT] trackEvent failed", e)
                        }))
                    };
                    (e.params || []).some((e => "dataLayer" === e.strategy)) ? setTimeout(n, 0) : n(), r = !0
                }
            })), r && this.maybeDetectPiiOnce()
        }, r.prototype.pageMatches = function(e, t) {
            return !e.page || "*" === e.page || t.includes(e.page)
        }, r.prototype.filterValidSelectors = function(t) {
            return t.filter((function(t) {
                if (t.triggerType !== e.TRIGGER_TYPE_CLICK && t.triggerType !== e.TRIGGER_TYPE_URL_VISIT) return console.warn(`[AAT] Rule with unsupported triggerType dropped: id=${t.id}, triggerType=${t.triggerType}`), !1;
                if (t.triggerType === e.TRIGGER_TYPE_URL_VISIT) return !0;
                if (!t.selector) return console.warn(`[AAT] CLICK rule without selector dropped: id=${t.id}`), !1;
                try {
                    return document.querySelector(t.selector), !0
                } catch {
                    return console.warn(`[AAT] Invalid selector dropped: id=${t.id}, selector=${t.selector}`), !1
                }
            }))
        }, r.prototype.sanitizeDomain = function(e) {
            return e.replace(/^www\./, "").replace(/\./g, "_")
        }, r.prototype.fetchConfig = async function(t) {
            const n = this.sanitizeDomain(window.location.hostname);
            try {
                const o = await fetch(`${e.CONFIG_CDN_BASE}/${t}/${n}/rules.json`, {
                    method: "GET",
                    credentials: "omit",
                    cache: "default"
                });
                return 204 !== o.status && o.ok ? await o.json() : null
            } catch {
                return console.warn(`[AAT] Config fetch failed for tagId: ${t}, domain: ${n}`), null
            }
        }, de = r
    }
    ie.prototype.init = function() {
        try {
            const e = this.cookieHandler.getCookieValue(ae.CONSENT_COOKIE_NAME);
            if (e) {
                const t = JSON.parse(decodeURIComponent(e));
                this.setAmazonConsent({ ...t,
                    AMAZON_CONSENT_AIPES_ENABLED: !0
                })
            }
        } catch (e) {
            console.warn("Error reading consent cookie:", e)
        }
        window.addEventListener("amznConsentChange", (e => {
            this.setAmazonConsent({ ...e ? .detail ? .consent,
                AMAZON_CONSENT_AIPES_ENABLED : !0
            })
        }))
    }, ie.prototype.setAmazonConsent = function(e) {
        this.amazonConsent = e
    }, ie.prototype.isConsentSet = function() {
        return void 0 !== this.amazonConsent
    }, ie.prototype.isAipesEgressEnabled = function() {
        return this.amazonConsent.AMAZON_CONSENT_AIPES_ENABLED
    }, ie.prototype.getFormattedAmazonConsent = function(e) {
        if (void 0 === this.amazonConsent) return;
        const t = {},
            n = {};
        return void 0 !== this.amazonConsent.geo && (t[ae.AIPES_AMAZON_CONSENT_GEO_FIELD_NAME] = function(e) {
            const t = {};
            return void 0 !== e.countryCode && (t[ae.AIPES_AMAZON_CONSENT_COUNTRY_CODE_FIELD_NAME] = e.countryCode), void 0 !== e.ipAddress && (t[ae.AIPES_AMAZON_CONSENT_IP_ADDRESS_FIELD_NAME] = e.ipAddress), t
        }(this.amazonConsent.geo)), void 0 !== this.amazonConsent.amazonConsentFormat && (n[ae.AIPES_AMAZON_CONSENT_AMAZON_CONSENT_FIELD_NAME] = function(e) {
            const t = {};
            return void 0 !== e.amznAdStorage && (t[ae.AIPES_AMAZON_CONSENT_AD_STORAGE_FIELD_NAME] = e.amznAdStorage), void 0 !== e.amznUserData && (t[ae.AIPES_AMAZON_CONSENT_USER_DATA_FIELD_NAME] = e.amznUserData), t
        }(this.amazonConsent.amazonConsentFormat)), void 0 !== this.amazonConsent.gpp && (n[ae.AIPES_AMAZON_CONSENT_GPP_FIELD_NAME] = this.amazonConsent.gpp), e && void 0 !== this.amazonConsent.tcf && (n[ae.AIPES_AMAZON_CONSENT_TCF_FIELD_NAME] = this.amazonConsent.tcf), t[ae.AIPES_AMAZON_CONSENT_CONSENT_FIELD_NAME] = n, t
    }, ie.prototype.getTcfString = function() {
        if (void 0 !== this.amazonConsent) return this.amazonConsent.tcf
    };
    const he = {
            NA: "https://s.amazon-adsystem.com/iu3",
            EU: "https://aax-eu.amazon-adsystem.com/s/iu3",
            FE: "https://aax-fe.amazon-adsystem.com/s/iu3"
        },
        pe = F,
        me = l,
        Ne = Q,
        fe = te,
        ge = se,
        ye = ie,
        Ie = i,
        {
            MEASUREMENT_TOKEN_FETCH_COUNTRY_HEADER: Re,
            ALLOWLIST_URL: Me
        } = n;
    !async function() {
        const e = new me,
            t = new ye(e);
        t.init();
        const n = new pe(he, t),
            o = new Ne(e),
            r = new fe(o, t);
        let s = new ge(n, r, o, void 0, t);
        if (void 0 !== window.__tcfapi) {
            const e = (e, n) => {
                n && "tcloaded" === e.eventStatus && t.setAmazonConsent({
                    tcf: e.tcString
                })
            };
            window.__tcfapi("addEventListener", 2, e)
        }
        if (void 0 !== window.__gpp) {
            const e = () => {
                const e = window.__gpp("getGPPString");
                void 0 !== e && t.setAmazonConsent({
                    gpp: e
                })
            };
            window.__gpp("addEventListener", e, "tcfeuv2")
        }
        o.removeAnyExpiredMeasurementTokens();
        try {
            const e = (await fetch(Re, {
                method: "get",
                mode: "cors",
                keepalive: !0
            })).headers.get("x-viewer-country");
            e && (n.setCountryCode(e), Ie.isEUCountry(e) && (n.setRegion("EU"), console.log("[AAT] Setting region to EU based on country code")))
        } catch (e) {
            console.warn("Error fetching country code from headers:", e)
        }
        window.amzn && window.amzn.q && s.processCommandQueue(window.amzn.q).catch((e => {
            console.error("Error processing event queue", e)
        })), window.amzn = async function(...e) {
            return s.processCommand(e).catch((e => {
                console.error("Error processing command", e)
            }))
        };
        const a = n.getAllTagIds(),
            i = a[0];
        i && async function(e) {
            try {
                const t = await fetch(Me, {
                    method: "GET",
                    credentials: "omit",
                    cache: "default"
                });
                if (!t.ok) return !1;
                const n = await t.json();
                return Array.isArray(n.allowlisted) && n.allowlisted.includes(e)
            } catch {
                return !1
            }
        }(i).then((e => {
            if (e) {
                new(Te())(n, (e => r.setUserData([null, e]))).fetchAndActivate(a).catch((() => {}))
            }
        })).catch((() => {})), window.renewToken = async function(e) {
            return o.renewAmznToken(e)
        }, window.updateToken = async function(e) {
            return o.updateAmznToken(e)
        }, window.deleteToken = async function() {
            return o.deleteAmznToken()
        }
    }()
}();