var TTDConversionEvents;
(() => {
    "use strict";
    var e = {
            d: (n, t) => {
                for (var r in t) e.o(t, r) && !e.o(n, r) && Object.defineProperty(n, r, {
                    enumerable: !0,
                    get: t[r]
                })
            },
            o: (e, n) => Object.prototype.hasOwnProperty.call(e, n),
            r: e => {
                "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(e, "__esModule", {
                    value: !0
                })
            }
        },
        n = {};
    e.r(n), e.d(n, {
        argsToSdkFunction: () => ze,
        clearAllConfigs: () => Qe,
        dumpConfigs: () => He,
        event: () => Ze
    });
    var t = {
            tcfV2ConsentVersion: 2,
            consentRequestHasTimedOut: !1,
            waitForConsentTimeout: null,
            consentCheckExists: !1,
            isGdprApplicable: !1,
            gdprConsentString: null
        },
        r = function(e, n, t) {
            if (t || 2 === arguments.length)
                for (var r, i = 0, o = n.length; i < o; i++) !r && i in n || (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
            return e.concat(r || Array.prototype.slice.call(n))
        };

    function i() {
        return new URL(window.location.href).searchParams.has("upjs_debug")
    }

    function o() {
        return i() || null != localStorage.getItem("enable-ttd-pixel-debugging")
    }

    function a(e) {
        if (!e) return "";
        var n = void 0 !== e.advertiserId && null !== e.advertiserId ? "adv_".concat(e.advertiserId) : "merchant_".concat(e.merchantId),
            t = e.pixelIds && e.pixelIds.length > 0 ? "|".concat(e.pixelIds.join(",")) : "";
        return "".concat(n).concat(t, " ")
    }

    function c(e, n) {
        for (var t = [], i = 2; i < arguments.length; i++) t[i - 2] = arguments[i];
        var c = o(),
            l = (null == n ? void 0 : n.enableDebug) || !1;
        if (c || l) {
            var u = a(n);
            console.info.apply(console, r(["TTD Pixel v3: ".concat(u).concat(e)], t, !1))
        }
    }

    function l(e, n) {
        var t = o(),
            r = (null == n ? void 0 : n.enableDebug) || !1;
        if (t || r) {
            var i = a(n);
            console.error("TTD Pixel v3: ".concat(i).concat(e))
        }
    }

    function u(e, n) {
        for (var t = [], r = 2; r < arguments.length; r++) t[r - 2] = arguments[r];
        var i = o(),
            c = (null == n ? void 0 : n.enableDebug) || !1;
        if (i || c) {
            var l = a(n);
            console.warn("TTD Pixel v3: ".concat(l).concat(e), t)
        }
    }
    var d = function() {
            return d = Object.assign || function(e) {
                for (var n, t = 1, r = arguments.length; t < r; t++)
                    for (var i in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
                return e
            }, d.apply(this, arguments)
        },
        s = {
            merchantId: null,
            advertiserId: null,
            enableDebug: !1,
            enableCookieSyncing: !0,
            get rootUrl() {
                return "https://insight.adsrvr.org"
            },
            dataProcessingOption: null,
            pixelVersion: "3.0.0",
            eventDataSourceVersion: "3.0.8"
        };

    function v(e) {
        return !(null == e || "string" == typeof e && "" === e.trim() || "number" == typeof e && (isNaN(e) || !isFinite(e)))
    }

    function f(e) {
        if (null != e) {
            if ("string" == typeof e) {
                var n = e.split(",").map((function(e) {
                    return e.trim()
                })).filter(Boolean);
                return n.length > 0 ? n : void 0
            }
            return Array.isArray(e) ? e : void 0
        }
    }

    function p(e, n, t) {
        var r;
        return r = null != e ? "adv_".concat(e) : null != n ? "merchant_".concat(n) : "nokey", t ? "".concat(r, "|").concat(t) : r
    }

    function g(e, n, t, r, i) {
        r = f(r);
        for (var o = v(n), a = v(t), d = r && r.length > 0, s = o || a, g = Array.from(new Set(e.values())), m = 0, h = d ? r.map((function(e) {
                return p(n, t, e)
            })) : [p(n, t)]; m < h.length; m++) {
            var y = h[m],
                b = e.get(y);
            if (b) return c("Exact config match found", b), b
        }
        if (s && !d || d && !s) {
            var w = g.filter((function(e) {
                return !!(o && e.advertiserId === n || a && e.merchantId === t) || !(!d || !r.some((function(n) {
                    var t;
                    return null === (t = e.pixelIds) || void 0 === t ? void 0 : t.includes(n)
                })))
            }));
            if (w.length > 0) return c("Partial config match found", w[0]), w.length > 1 && u("Multiple partial config matches found, using first one", w[0], w.slice(1)), w[0];
            if (s) return void l("No matching config found for adv/merchant '" + n + "/" + t + "', event will not fire")
        }
        if (s && d) l("Event sent ids (advId: " + n + ", merchantId: " + t + ", pixelIds: " + (null == r ? void 0 : r.join(",")) + ") but no exact config match found, event will not fire");
        else {
            if (1 === g.length) return c("Single config found, using it for event", g[0]), g[0];
            if (!d) return u("Event ids not sent, will use mostRecentInitConfig", i), i;
            l("No matching config found for pixel_ids '" + r.join(",") + "', event will queue and fire with default config after timeout")
        }
    }
    var m = function() {
            return m = Object.assign || function(e) {
                for (var n, t = 1, r = arguments.length; t < r; t++)
                    for (var i in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
                return e
            }, m.apply(this, arguments)
        },
        h = m({}, t),
        y = m({}, s);

    function b(e) {
        if (h = m({}, t), y = e, "function" == typeof window.__tcfapi) {
            h.consentCheckExists = !0, h.waitForConsentTimeout = setTimeout(_, 1e3), window.__tcfapi("addEventListener", h.tcfV2ConsentVersion, w), I("parse tcf response");
            var n = "&gdpr=".concat(h.isGdprApplicable ? 1 : 0),
                r = null === h.gdprConsentString || void 0 === h.gdprConsentString ? "" : "&gdpr_consent=".concat(h.gdprConsentString);
            return "".concat(n).concat(r)
        }
        I("tcfapi not a function")
    }

    function w(e, n) {
        if (h.consentRequestHasTimedOut) return I("tcfapi consent request timed out"), void(h.isGdprApplicable = !0);
        n && (clearTimeout(h.waitForConsentTimeout), h.isGdprApplicable = e.gdprApplies, h.gdprConsentString = e.tcString)
    }

    function _() {
        h.consentRequestHasTimedOut = !0
    }

    function I(e) {
        (o() || y.enableDebug) && console.info("TTD Pixel v3: " + e)
    }
    var x, S = function() {
            return S = Object.assign || function(e) {
                for (var n, t = 1, r = arguments.length; t < r; t++)
                    for (var i in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
                return e
            }, S.apply(this, arguments)
        },
        k = null,
        D = {
            gppString: ""
        },
        E = S({}, s);

    function T() {
        x = !0
    }

    function C(e) {
        var n;
        return x ? (O("gpp request timed out"), void window.__gpp("removeEventListener", null, e.listenerId)) : "signalStatus" === e.eventName && "ready" === e.data ? (D.gppString = null === (n = null == e ? void 0 : e.pingData) || void 0 === n ? void 0 : n.gppString, clearTimeout(k), window.__gpp("removeEventListener", null, e.listenerId), P(D)) : void O("gpp event invalid")
    }

    function P(e) {
        var n = "&gpp_consent=" + e.gppString;
        return "".concat(n)
    }

    function O(e) {
        (o() || E.enableDebug) && console.info("TTD Pixel v3: " + e)
    }

    function L(e, n, t) {
        var r = document.getElementById(n);
        if (r instanceof HTMLIFrameElement && r.src === e) return r;
        ! function(e) {
            var n = document.getElementById(e);
            do {
                n && n.parentElement.removeChild(n), n = document.getElementById(e)
            } while (n)
        }(n);
        var i = document.createElement("iframe");

        function o() {
            document.body.appendChild(i)
        }
        return i.setAttribute("id", n), i.setAttribute("height", "0"), i.setAttribute("width", "0"), i.setAttribute("hidden", ""), i.setAttribute("src", e), i.setAttribute("title", t), "complete" === document.readyState ? setTimeout(o, 0) : window.addEventListener ? window.addEventListener("load", o) : window.attachEvent ? window.attachEvent("onload", o) : o(), i
    }

    function U(e) {
        var n;
        try {
            if (window.self === window.top) return F(e, "strategy 1: found top level"), window.location.href
        } catch (n) {
            F(e, "strategy 1: cross origin top, continue")
        }
        try {
            var t = null === (n = null === top || void 0 === top ? void 0 : top.location) || void 0 === n ? void 0 : n.href;
            if (t) return F(e, "strategy 2: top href found"), t
        } catch (n) {
            F(e, "strategy 2: cross origin top, continue")
        }
        for (var r = "", i = window;;) {
            try {
                var o = i.parent.location.href;
                o && (r = o)
            } catch (n) {
                try {
                    var a = i.document.referrer;
                    a && R(a, r, e) && (r = a)
                } catch (e) {
                    break
                }
            }
            try {
                if (i.parent === i) break;
                i = i.parent
            } catch (e) {
                break
            }
        }
        if (!r || A(r)) try {
            var c = window.location.ancestorOrigins;
            if (c && c.length > 0) {
                var l = c[c.length - 1];
                l && R(l, r, e) && (r = l, F(e, "strategy 4: found toporigin: " + l + " from origins: " + c))
            }
        } catch (n) {
            F(e, "strategy 4: ancestorOrigins unsupported, continue")
        }
        if (!r || A(r)) {
            var u = function(e) {
                try {
                    if ((t = document.querySelector("link[rel='canonical']")) && (r = t.href)) return r
                } catch (n) {
                    F(e, "strategy 5: canonical link not accessible in current document")
                }
                for (var n = window;;) try {
                    if (n.parent === n) break;
                    var t, r;
                    if ((t = (n = n.parent).document.querySelector("link[rel='canonical']")) && (r = t.href)) return r
                } catch (n) {
                    F(e, "strategy 5: cross-origin parent, cannot read canonical link");
                    break
                }
                return ""
            }(e);
            u && R(u, r, e) && (r = u, F(e, "strategy 5: canonical url found"))
        }
        if (!r || A(r)) {
            var d = function(e, n) {
                try {
                    var t = window.dataLayer;
                    if (!t || !Array.isArray(t)) return F(n, "strategy 6: dataLayer not present or not an array"), "";
                    var r = "";
                    try {
                        r = e ? new URL(e).origin : ""
                    } catch (t) {
                        F(n, "strategy 6: could not parse known origin: " + e)
                    }
                    for (var i = t.length - 1; i >= 0; i--) {
                        var o = t[i];
                        if (o && "object" == typeof o && !Array.isArray(o))
                            for (var a = 0, c = N; a < c.length; a++) {
                                var l = c[a],
                                    u = o[l];
                                if ("string" == typeof u && u) try {
                                    var d = new URL(u);
                                    if ("/" === d.pathname && "" === d.search) continue;
                                    if (!r || d.origin === r || u.startsWith("http")) return u
                                } catch (e) {
                                    if (r && u.startsWith("/") && u.length > 1) return r + u;
                                    F(n, "strategy 6: dataLayer[" + i + "]." + l + " is not a valid URL: " + u)
                                }
                            }
                    }
                } catch (e) {
                    F(n, "strategy 6: error reading dataLayer, continue")
                }
                return ""
            }(r, e);
            d && R(d, r, e) && (r = d, F(e, "strategy 6: dataLayer url found: " + d))
        }
        var s = function(e, n, t) {
            var r = [];
            n && n.includes("?") && r.push(n), e && e.includes("?") && function(e) {
                try {
                    return "/" === new URL(e).pathname || -1 !== e.indexOf("cloudfront.net")
                } catch (e) {
                    return !1
                }
            }(e) && r.push(e);
            for (var i = 0, o = r; i < o.length; i++)
                for (var a = o[i], c = 0, l = V; c < l.length; c++) {
                    var u = l[c],
                        d = j(a, u);
                    if (d && d.startsWith("http")) try {
                        return new URL(d), F(t, "strategy 7: found url in param '" + u + "' of " + a.substring(0, 80)), d
                    } catch (e) {
                        F(t, "strategy 7: param '" + u + "' value is not a valid URL: " + d.substring(0, 80))
                    }
                }
            return ""
        }(r, window.location.href, e);
        return s && R(s, r, e) && (r = s), r
    }

    function j(e, n) {
        n = n.replace(/\[/, "\\[").replace(/]/, "\\]");
        var t = new RegExp("[\\?&]" + n + "=([^&#]*)").exec(e);
        return null === t ? "" : decodeURIComponent(t[1].replace(/\+/g, " "))
    }

    function A(e) {
        try {
            var n = new URL(e);
            return "/" === n.pathname && "" === n.search
        } catch (e) {
            return !1
        }
    }

    function R(e, n, t) {
        if (!n) return !0;
        try {
            var r = new URL(e),
                i = new URL(n),
                o = "/" !== r.pathname || "" !== r.search,
                a = "/" !== i.pathname || "" !== i.search;
            if (o && !a) return !0;
            if (!o && a) return !1
        } catch (r) {
            F(t, "isBetterUrl: url was malformed. Candidate: " + e + ", current: " + n)
        }
        return !0
    }
    var N = ["page_location", "page_url", "page", "dl", "page_path"],
        V = ["url", "referrer", "page_url", "ref_url"];

    function F(e, n) {
        (o() || e) && console.warn("TTD Pixel v3 - Referrer: " + n)
    }
    var q = function() {
            var e, n, t = {
                    "[object Boolean]": "boolean",
                    "[object Number]": "number",
                    "[object String]": "string",
                    "[object Function]": "function",
                    "[object Array]": "array",
                    "[object Date]": "date",
                    "[object RegExp]": "regexp",
                    "[object Object]": "object"
                },
                r = {
                    isReady: !1,
                    readyWait: 1,
                    holdReady: function(e) {
                        e ? r.readyWait++ : r.ready(!0)
                    },
                    ready: function(n) {
                        if (!0 === n && 0 == --r.readyWait || !0 !== n && !r.isReady) {
                            if (!document.body) return setTimeout((function() {
                                return r.ready()
                            }), 1);
                            if (r.isReady = !0, !0 !== n && --r.readyWait > 0) return;
                            null == e || e.resolveWith(document, [r])
                        }
                    },
                    bindReady: function() {
                        if (!e) {
                            if (e = r._Deferred(), "complete" === document.readyState) return setTimeout((function() {
                                return r.ready()
                            }), 1);
                            if (document.addEventListener) document.addEventListener("DOMContentLoaded", n, !1), window.addEventListener("load", (function() {
                                return r.ready()
                            }), !1);
                            else if (document.attachEvent) {
                                document.attachEvent("onreadystatechange", n), window.attachEvent("onload", r.ready);
                                var t = !1;
                                try {
                                    t = null == window.frameElement
                                } catch (e) {
                                    console.log(e)
                                }
                                document.documentElement.doScroll && t && i()
                            }
                        }
                    },
                    _Deferred: function() {
                        var e, n = [],
                            t = !1,
                            i = !1,
                            o = {
                                done: function() {
                                    for (var t = [], a = 0; a < arguments.length; a++) t[a] = arguments[a];
                                    if (!i) {
                                        var c = void 0;
                                        e && (c = e, e = void 0);
                                        for (var l = 0, u = t; l < u.length; l++) {
                                            var d = u[l],
                                                s = r.type(d);
                                            "array" === s ? o.done.apply(o, d) : "function" === s && n.push(d)
                                        }
                                        c && o.resolveWith(c[0], c[1])
                                    }
                                    return o
                                },
                                resolveWith: function(r, a) {
                                    if (void 0 === a && (a = []), !i && !e && !t) {
                                        t = !0;
                                        try {
                                            for (; n.length;) {
                                                var c = n.shift();
                                                null == c || c.apply(r, a)
                                            }
                                        } finally {
                                            e = [r, a], t = !1
                                        }
                                    }
                                    return o
                                },
                                resolve: function() {
                                    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                                    return o.resolveWith(this, e)
                                },
                                isResolved: function() {
                                    return !(!t && !e)
                                },
                                cancel: function() {
                                    return i = !0, n = [], o
                                }
                            };
                        return o
                    },
                    type: function(e) {
                        return null == e ? String(e) : t[Object.prototype.toString.call(e)] || "object"
                    }
                };

            function i() {
                if (!r.isReady) {
                    try {
                        document.documentElement.doScroll("left")
                    } catch (e) {
                        return void setTimeout(i, 1)
                    }
                    r.ready()
                }
            }
            return document.addEventListener ? n = function() {
                    document.removeEventListener("DOMContentLoaded", n, !1), r.ready()
                } : document.attachEvent && (n = function() {
                    "complete" === document.readyState && (document.detachEvent("onreadystatechange", n), r.ready())
                }),
                function(n) {
                    r.bindReady(), null == e || e.done(n)
                }
        }(),
        $ = function() {
            return $ = Object.assign || function(e) {
                for (var n, t = 1, r = arguments.length; t < r; t++)
                    for (var i in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
                return e
            }, $.apply(this, arguments)
        },
        M = $({}, s);

    function G(e, n) {
        if (M = e, ee("Detection started! Library is configured to detect: ", n.detectionSubject), ee("Detection event type is ", n.detectionEventType), ee("Full config: ", n), "onclick" === n.detectionEventType && (n.detectionEventType = "click"), "onsubmit" === n.detectionEventType || "click" === n.detectionEventType) {
            var t = document.querySelector("body");
            t && (W(t, "document", n), n.detectDynamicNodes && Z(t, "document", n))
        } else ee("Detection type not supported! We will not start auto detection.")
    }

    function W(e, n, t) {
        var r, i, o;
        t.scopedTriggers = null !== (r = t.scopedTriggers) && void 0 !== r ? r : {}, t.scopedValidInputs = null !== (i = t.scopedValidInputs) && void 0 !== i ? i : {}, t.scopedEventListeners = null !== (o = t.scopedEventListeners) && void 0 !== o ? o : {}, J(n, t), H(e, n, t)
    }

    function H(e, n, t) {
        var r, i, o, a = B(e, n, t),
            c = B(e, n, t);
        t.scopedTriggers[n] = null !== (r = t.scopedTriggers[n]) && void 0 !== r ? r : [], t.scopedValidInputs[n] = null !== (i = t.scopedValidInputs[n]) && void 0 !== i ? i : [], t.scopedEventListeners[n] = null !== (o = t.scopedEventListeners[n]) && void 0 !== o ? o : [];
        for (var l = 0, u = c; l < u.length; l++) {
            var d = u[l];
            d && d.tagName && "INPUT" === d.tagName && t.scopedValidInputs[n].push(d)
        }
        ee('triggers ["'.concat(n, '"] '), a), ee('validInputs ["'.concat(n, '"] '), c), a.forEach((function(e) {
            t.scopedTriggers[n].push(e)
        }));
        for (var s = function(e) {
                var r = function() {
                    try {
                        ee("Detect event: ", t.detectionEventType, "on element, ", e);
                        for (var n = Object.entries(t.scopedValidInputs).map((function(e) {
                                return e[1]
                            })).flatMap((function(e) {
                                return e
                            })), r = 0, i = n; r < i.length; r++) {
                            var o = i[r].value.trim();
                            if (Y(o, t)) {
                                ee("We detected: ", o), z(t);
                                break
                            }
                        }
                    } catch (e) {
                        ee(e)
                    }
                };
                t.scopedEventListeners[n].push(r), e.addEventListener(t.detectionEventType, r, {
                    once: !0,
                    capture: !0
                })
            }, v = 0, f = a; v < f.length; v++) s(f[v]);
        for (var p, g = (p = e, Array.from(p.querySelectorAll("*")).filter((function(e) {
                return !!e.shadowRoot
            })).map((function(e) {
                return e.shadowRoot
            }))), m = 0; m < g.length; m++) {
            var h = g[m],
                y = n + "/shadow_root_" + m;
            H(h, y, t), Z(h, y, t)
        }
    }

    function z(e) {
        ee("Detection stopped."),
            function(e) {
                if (e.detectDynamicNodes) {
                    ee("Checking for dynamically added elements is turned off.");
                    for (var n = 0, t = Object.entries(e.scopedDynamicObservers); n < t.length; n++) {
                        var r = t[n][1];
                        r && r.disconnect(), e.scopedDynamicObservers = {}
                    }
                }
            }(e), J("all", e)
    }

    function J(e, n) {
        if (ee("clearing detection hooks (".concat(e, ")")), "all" === e) {
            for (var t = 0, r = Object.entries(n.scopedTriggers); t < r.length; t++) {
                var i = r[t],
                    o = i[0];
                if (s = i[1])
                    for (var a = 0; a < s.length; a++) s[a].removeEventListener(n.detectionEventType, n.scopedEventListeners[o][a], {
                        capture: !0
                    })
            }
            n.scopedTriggers = {}, n.scopedEventListeners = {}
        } else if (n.scopedTriggers) {
            for (var c = [], l = 0, u = Object.entries(n.scopedTriggers); l < u.length; l++) {
                var d = u[l],
                    s = (o = d[0], d[1]);
                if (o.startsWith(e)) {
                    if (s)
                        for (a = 0; a < s.length; a++) s[a].removeEventListener(n.detectionEventType, n.scopedEventListeners[o][a], {
                            capture: !0
                        });
                    c.push(o)
                }
            }
            for (var v = 0; v < c.length; v++) o = c[v], n.scopedTriggers[o] = [], n.scopedEventListeners[o] = []
        }
    }

    function Z(e, n, t) {
        var r;
        t.detectDynamicNodes && (t.scopedDynamicObservers = null !== (r = t.scopedDynamicObservers) && void 0 !== r ? r : {}, t.scopedDynamicObservers[n] = K((function() {
            ee("Detected dynamically added nodes."), W(e, n, t)
        }), 500), t.scopedDynamicObservers[n].observe(e, {
            childList: !0,
            subtree: !0,
            attributes: !0
        }))
    }

    function B(e, n, t) {
        ee('collectElements("'.concat(n, '", ').concat(t.cssSelectors, ")"));
        for (var r = [], i = 0, o = t.cssSelectors; i < o.length; i++)
            if ((p = o[i]).length > 0) {
                var a = e.querySelectorAll(p);
                a && a.forEach((function(e) {
                    r.includes(e) || r.push(e)
                }))
            }
        for (var c = window.location.hostname, l = document.getElementsByTagName("iframe"), u = 0, d = Array.from(l); u < d.length; u++) {
            var s = d[u];
            if (X(c, s) && (s.__upixel_detection = {
                    root: e,
                    scopeName: n + "/iframe",
                    config: t
                }, s.removeEventListener("load", Q), s.addEventListener("load", Q), s.contentDocument))
                for (var v = 0, f = t.cssSelectors; v < f.length; v++) {
                    var p;
                    (p = f[v]).length > 0 && s.contentDocument.querySelectorAll(p).forEach((function(e) {
                        r.includes(e) || r.push(e)
                    }))
                }
        }
        return r
    }

    function K(e, n) {
        var t = 0,
            r = null;
        return new MutationObserver((function(i, o) {
            var a = Date.now(),
                c = a - t;
            c >= n ? (t = a, e(i, o)) : (r && clearTimeout(r), r = setTimeout((function() {
                t = Date.now(), e(i, o)
            }), n - c))
        }))
    }

    function X(e, n) {
        if (!n.src) return !1;
        try {
            var t = e === new URL(n.src).hostname;
            return t && ee("Iframe " + n.src + " can be accessed"), t
        } catch (e) {
            return ee("error: ", e), !1
        }
    }

    function Q(e) {
        var n = e.currentTarget;
        if (n && n.__upixel_detection) try {
            W(n.__upixel_detection.root, n.__upixel_detection.scopeName, n.__upixel_detection.config)
        } catch (e) {
            ee(e)
        }
    }

    function Y(e, n) {
        return function(e, n) {
            var t = /((([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,}))/i;
            if (n.detectionSubject.includes("email") && t.test(e)) {
                var r = function(e) {
                    return e.toLowerCase().trim()
                }(e.match(t)[0]);
                return ee("We detected email: " + r),
                    function(e, n) {
                        if (e && n) {
                            var t = new CustomEvent("detected-identifier", {
                                detail: {
                                    identifier: e,
                                    type: n
                                }
                            });
                            ee("Dispatched event with identifier: ", e, " and type: ", n), window.dispatchEvent(t)
                        }
                    }(r, "email"), !0
            }
            return !1
        }(e, n)
    }

    function ee(e) {
        for (var n = [], t = 1; t < arguments.length; t++) n[t - 1] = arguments[t];
        (o() || M.enableDebug) && console.info("TTD Pixel v3 - Detection: " + e, n)
    }
    K.prototype.observe = function(e, n) {
        this.mutationObserver.observe(e, n)
    }, K.prototype.disconnect = function() {
        null != this.nextTimeoutHandle && clearTimeout(this.nextTimeoutHandle), this.mutationObserver.disconnect()
    }, K.prototype.takeRecords = function() {
        return this.mutationObserver.takeRecords()
    }, K.prototype.throttledCallback = function() {
        for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
        var t = Date.now();
        null != this.args ? this.args = e : this.lastInvocationTime + this.minDelayMs < t ? (this.lastInvocationTime = t, this.callback(this.args)) : (this.args = e, this.nextTimeoutHandle = setTimeout(function() {
            this.lastInvocationTime = Date.now(), this.nextTimeoutHandle = null, this.callback.apply(null, this.args), this.args = null
        }.bind(this), this.minDelayMs))
    };
    var ne = function() {
            return ne = Object.assign || function(e) {
                for (var n, t = 1, r = arguments.length; t < r; t++)
                    for (var i in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
                return e
            }, ne.apply(this, arguments)
        },
        te = function(e, n, t, r) {
            return new(t || (t = Promise))((function(i, o) {
                function a(e) {
                    try {
                        l(r.next(e))
                    } catch (e) {
                        o(e)
                    }
                }

                function c(e) {
                    try {
                        l(r.throw(e))
                    } catch (e) {
                        o(e)
                    }
                }

                function l(e) {
                    var n;
                    e.done ? i(e.value) : (n = e.value, n instanceof t ? n : new t((function(e) {
                        e(n)
                    }))).then(a, c)
                }
                l((r = r.apply(e, n || [])).next())
            }))
        },
        re = function(e, n) {
            var t, r, i, o, a = {
                label: 0,
                sent: function() {
                    if (1 & i[0]) throw i[1];
                    return i[1]
                },
                trys: [],
                ops: []
            };
            return o = {
                next: c(0),
                throw: c(1),
                return: c(2)
            }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                return this
            }), o;

            function c(o) {
                return function(c) {
                    return function(o) {
                        if (t) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (t = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                            switch (r = 0, i && (o = [2 & o[0], i.value]), o[0]) {
                                case 0:
                                case 1:
                                    i = o;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: o[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = o[1], o = [0];
                                    continue;
                                case 7:
                                    o = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!((i = (i = a.trys).length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                        a.label = o[1];
                                        break
                                    }
                                    if (6 === o[0] && a.label < i[1]) {
                                        a.label = i[1], i = o;
                                        break
                                    }
                                    if (i && a.label < i[2]) {
                                        a.label = i[2], a.ops.push(o);
                                        break
                                    }
                                    i[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            o = n.call(e, a)
                        } catch (e) {
                            o = [6, e], r = 0
                        } finally {
                            t = i = 0
                        }
                        if (5 & o[0]) throw o[1];
                        return {
                            value: o[0] ? o[1] : void 0,
                            done: !0
                        }
                    }([o, c])
                }
            }
        },
        ie = ne({}, s),
        oe = {},
        ae = null;

    function ce(e, n) {
        var t = this;
        ie = e, ve(n, oe), se(n) ? oe.sdkObj = window.__uid2 : de(n) && (oe.sdkObj = window.__euid);
        try {
            oe.sdkObj.callbacks.push((function(r, i) {
                return te(t, void 0, void 0, (function() {
                    var t, o, a;
                    return re(this, (function(c) {
                        switch (c.label) {
                            case 0:
                                switch (r) {
                                    case "SdkLoaded":
                                        return [3, 1];
                                    case "InitCompleted":
                                        return [3, 2];
                                    case "IdentityUpdated":
                                        return [3, 4]
                                }
                                return [3, 5];
                            case 1:
                                try {
                                    window.__ttd_m_invoke_once = null !== (t = window.__ttd_m_invoke_once) && void 0 !== t ? t : {}, window.__ttd_m_invoke_once._uid_init || (window.__ttd_m_invoke_once._uid_init = 1, null !== (o = n.baseUrl) && void 0 !== o || (n.baseUrl = oe.uidBaseUrl), oe.sdkObj.init({
                                        baseUrl: n.baseUrl
                                    }))
                                } catch (e) {
                                    fe("Non-TTD actor initialized UID SDK, mind the consistency of UID baseUrl.", e)
                                }
                                return [3, 5];
                            case 2:
                                return [4, ue((function() {
                                    return i.identity
                                }), e, n)];
                            case 3:
                                return c.sent(), [3, 5];
                            case 4:
                                return (null === (a = i.identity) || void 0 === a ? void 0 : a.advertising_token) && (n.uid_token = i.identity.advertising_token, fe("UID token updated for advertiser ".concat(null == ae ? void 0 : ae.advertiserId, ", pixel ").concat(null == ae ? void 0 : ae.pixelId))), [3, 5];
                            case 5:
                                return [2]
                        }
                    }))
                }))
            }))
        } catch (n) {
            pe("Did not setup uid hooks: ", e, n)
        }
    }

    function le(e, n, t, r, i) {
        var o, a;
        null === ae ? void 0 === window._uidSdkListenerLock[e] && (window._uidSdkListenerLock[e] = 1, 1 === (null !== (a = null === (o = i.pixelIds) || void 0 === o ? void 0 : o.length) && void 0 !== a ? a : 0) ? (ae = {
            advertiserId: i.advertiserId,
            pixelId: i.pixelIds[0]
        }, fe("UID config claimed by advertiser ".concat(ae.advertiserId, ", pixel ").concat(ae.pixelId)), ve(n, oe), void 0 === oe.sdkObj && void 0 === window.uidSdkLoaderPromise ? window.uidSdkLoaderPromise = new Promise((function(e, n) {
            var i = document.createElement("script");
            i.setAttribute("defer", "true"), i.setAttribute("src", oe.uidSdkUrl), i.addEventListener("load", (function() {
                e(), t()
            })), i.addEventListener("error", (function(e) {
                n(e), r(e)
            })), document.body.appendChild(i)
        })) : te(this, void 0, void 0, (function() {
            return re(this, (function(e) {
                switch (e.label) {
                    case 0:
                        return e.trys.push([0, 2, , 3]), [4, window.uidSdkLoaderPromise];
                    case 1:
                        return e.sent(), t(), [3, 3];
                    case 2:
                        return pe("Failed to load uid sdk: ", e.sent()), [3, 3];
                    case 3:
                        return [2]
                }
            }))
        }))) : l("UID configuration currently only supports a single pixel ID, but zero or multiple pixel ids were provided.", i)) : pe("UID already configured by advertiser ".concat(ae.advertiserId, ", pixel ").concat(ae.pixelId, ". Only one UID configuration per page is currently allowed."))
    }

    function ue(e, n, t) {
        return te(this, void 0, void 0, (function() {
            var r, i, o;
            return re(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 8, , 9]), (r = e()) ? [3, 3] : t.email ? [4, oe.sdkObj.setIdentityFromEmail(t.email, t)] : [3, 2];
                    case 1:
                        return a.sent(), [3, 3];
                    case 2:
                        t.emailHash ? oe.sdkObj.setIdentityFromEmailHash(t.emailHash, t) : t.phone ? oe.sdkObj.setIdentityFromPhone(t.phone, t) : t.phoneHash && oe.sdkObj.setIdentityFromPhoneHash(t.phoneHash, t), a.label = 3;
                    case 3:
                        return r ? (t.uid_token = r.advertising_token, fe("UID token set from existing identity for advertiser ".concat(n.advertiserId), n), [3, 7]) : [3, 4];
                    case 4:
                        return window.ttdConversionEvents.activeDetection ? [3, 7] : (fe("in fire or detect no identity"), i = new Promise((function(e) {
                            window.addEventListener("detected-identifier", (function(n) {
                                e(n.detail.identifier), window.ttdConversionEvents.activeDetection = null
                            })), window.ttdConversionEvents.startDetection = G, window.ttdConversionEvents.startDetection(n, t)
                        })), window.ttdConversionEvents.activeDetection = i, [4, i]);
                    case 5:
                        return o = a.sent(), [4, oe.sdkObj.setIdentityFromEmail(o, t)];
                    case 6:
                        return a.sent(), [3, 7];
                    case 7:
                        return [3, 9];
                    case 8:
                        return pe("error setting up cstgOrDetect: ", a.sent()), [3, 9];
                    case 9:
                        return [2]
                }
            }))
        }))
    }

    function de(e) {
        return "EUID" === (null == e ? void 0 : e.type) || e.serverPublicKey.includes("EUID")
    }

    function se(e) {
        return "UID2" === (null == e ? void 0 : e.type) || e.serverPublicKey.includes("UID2")
    }

    function ve(e, n) {
        se(e) ? (n.uidSdkUrl = "https://js.adsrvr.org/uid2-sdk-4.0.1.js", n.uidBaseUrl = "https://global.prod.uidapi.com", n.rtUidTokenName = "uid2_token") : de(e) && (n.uidSdkUrl = "https://js.adsrvr.org/euid-sdk-4.0.1.js", n.uidBaseUrl = "https://prod.euid.eu", n.rtUidTokenName = "euid_token")
    }

    function fe(e) {
        for (var n = [], t = 1; t < arguments.length; t++) n[t - 1] = arguments[t];
        (o() || ie.enableDebug) && console.info("TTD Pixel v3 - UnifiedId: " + e, n)
    }

    function pe(e) {
        for (var n = [], t = 1; t < arguments.length; t++) n[t - 1] = arguments[t];
        (o() || ie.enableDebug) && console.warn("TTD Pixel v3 - UnifiedId: " + e, n)
    }

    function ge() {
        var e = {};
        return document.cookie.split(";").forEach((function(n) {
            if (n) {
                var t = n.split("="),
                    r = t[0].trim(),
                    i = t[1].trim();
                e[r] = i
            }
        })), e
    }

    function me(e, n) {
        (o() || e) && console.warn("TTD Pixel v3 - GA4: " + n)
    }
    var he = function() {
            return he = Object.assign || function(e) {
                for (var n, t = 1, r = arguments.length; t < r; t++)
                    for (var i in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
                return e
            }, he.apply(this, arguments)
        },
        ye = function(e, n, t) {
            if (t || 2 === arguments.length)
                for (var r, i = 0, o = n.length; i < o; i++) !r && i in n || (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
            return e.concat(r || Array.prototype.slice.call(n))
        };

    function be(e) {
        var n = window.ttdConversionEventsLayer.indexOf(e); - 1 !== n && window.ttdConversionEventsLayer.splice(n, 1)
    }

    function we(e) {
        var n = e.config;
        if (!n) throw "Cannot execute event without config";
        switch (e.method) {
            case "event":
                c("event fire triggered", n), Ze(e.params, n, !0), e.hasFired = !0;
                break;
            case "optout":
                c("optout triggered", n), e.params.isoptout = "1", Ze(e.params, n, !1), e.hasFired = !0;
                break;
            default:
                throw c("unexpected event triggered: " + e.method, n), "method not implemented"
        }
    }
    var _e = /^[a-zA-Z_$][a-zA-Z0-9_$]*(\.[a-zA-Z_$][a-zA-Z0-9_$]*)*$/,
        Ie = /^([a-zA-Z_$][a-zA-Z0-9_$]*(?:\.[a-zA-Z_$][a-zA-Z0-9_$]*)*)\(\)$/,
        xe = [/^\{\{[\s\S]+\}\}$/, /^\{[\s\S]+\}$/, /^<%=?[\s\S]+%>$/, /^%%[\s\S]+%%$/, /^%p\w+\s*[=!0-9]+\s*;?$/, /^%[^%\s]+%$/, /^\[+[\s\S]+\]+$/, /^\([\s\S]+\)$/, /^["'][\s\S]+["']$/];

    function Se(e) {
        var n = window[e];
        if (void 0 !== n) return n;
        if (_e.test(e)) try {
            return new Function("return (".concat(e, ");"))()
        } catch (e) {
            return
        }
    }

    function ke(e) {
        var n, t;
        return {
            evaluatedParameter: De(String(null !== (n = null == e ? void 0 : e.evaluatedParameter) && void 0 !== n ? n : "").trim()),
            parameterValue: De(String(null !== (t = null == e ? void 0 : e.parameterValue) && void 0 !== t ? t : "").trim())
        }
    }

    function De(e) {
        return e.replace(/&(?:#(\d+)|#x([0-9a-fA-F]+)|([a-zA-Z]+));/g, (function(e, n, t, r) {
            if (void 0 !== n) return String.fromCharCode(parseInt(n, 10));
            if (void 0 !== t) return String.fromCharCode(parseInt(t, 16));
            switch (r) {
                case "amp":
                    return "&";
                case "quot":
                    return '"';
                case "apos":
                    return "'";
                case "lt":
                    return "<";
                case "gt":
                    return ">";
                case "nbsp":
                    return " ";
                default:
                    return e
            }
        }))
    }

    function Ee(e, n, t, r) {
        var i = e.parameterValue,
            o = i.match(Ie);
        if (o) return Te(o[1], i, e, n, t);
        var a = _e.test(i);
        if (a) {
            var c = Se(i);
            if ("function" == typeof c) return Te(i, i, e, n, t, c);
            if (null != c) return String(c)
        }
        var l = function(e) {
            try {
                var n = e.replace(/\\/g, "\\\\").replace(/"/g, '\\"'),
                    t = document.querySelector('[name="'.concat(n, '"]'));
                if (!t) return;
                var r = t.value;
                return "string" == typeof r ? r : void 0
            } catch (e) {
                return
            }
        }(i);
        if (void 0 !== l && "" !== l) return l;
        if (a) u("DynamicParams: could not resolve '".concat(i, "' for ").concat(e.evaluatedParameter, " on pixel ").concat(n, " (tried variable, function, and form field name)"), t);
        else {
            if (function(e) {
                    return xe.some((function(n) {
                        return n.test(e)
                    }))
                }(i)) return u("DynamicParams: '".concat(i, "' for ").concat(e.evaluatedParameter, " on pixel ").concat(n, " looks like an unfilled template placeholder and no matching form field exists"), t), void r.add("".concat(e.evaluatedParameter, "t"));
            u("DynamicParams: '".concat(i, "' for ").concat(e.evaluatedParameter, " on pixel ").concat(n, " is not a safe identifier path and no matching form field exists"), t), r.add("".concat(e.evaluatedParameter, "u"))
        }
    }

    function Te(e, n, t, r, i, o) {
        var a = void 0 !== o ? o : Se(e);
        if ("function" == typeof a) {
            var c;
            try {
                c = a()
            } catch (e) {
                return void u("DynamicParams: '".concat(n, "' for ").concat(t.evaluatedParameter, " on pixel ").concat(r, " threw when called: ").concat(e), i)
            }
            if (null != c) return String(c);
            u("DynamicParams: '".concat(n, "' for ").concat(t.evaluatedParameter, " on pixel ").concat(r, " returned ").concat(null === c ? "null" : "undefined"), i)
        } else u("DynamicParams: '".concat(n, "' for ").concat(t.evaluatedParameter, " on pixel ").concat(r, " is not a function"), i)
    }
    var Ce = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/,
        Pe = new Set(["window", "document", "location", "navigator", "localStorage", "sessionStorage", "history", "screen", "self", "top", "parent", "frames", "performance", "crypto"]),
        Oe = 200;

    function Le() {
        for (var e = document.querySelectorAll("input[name], select[name], textarea[name]"), n = [], t = 0, r = Array.from(e); t < r.length; t++) {
            var i = r[t],
                o = i.getAttribute("name");
            if (o) {
                var a = "value" in i && "string" == typeof i.value ? i.value : "";
                n.push({
                    name: o,
                    tagName: i.tagName,
                    value: a
                })
            }
        }
        return n
    }

    function Ue() {
        for (var e = [], n = 0, t = Object.getOwnPropertyNames(window); n < t.length; n++) {
            var r = t[n];
            if (Ce.test(r) && !Pe.has(r)) {
                var i = Ae(r);
                void 0 !== i && "function" != typeof i && e.push({
                    name: r,
                    type: typeof i,
                    value: Re(i)
                })
            }
        }
        return e.sort((function(e, n) {
            return e.name.localeCompare(n.name)
        })), e
    }

    function je() {
        for (var e = [], n = 0, t = Object.getOwnPropertyNames(window); n < t.length; n++) {
            var r = t[n];
            Ce.test(r) && !Pe.has(r) && "function" == typeof Ae(r) && e.push({
                name: r
            })
        }
        return e.sort((function(e, n) {
            return e.name.localeCompare(n.name)
        })), e
    }

    function Ae(e) {
        try {
            return window[e]
        } catch (e) {
            return
        }
    }

    function Re(e) {
        var n, t;
        if (null === e) return "null";
        if (void 0 === e) return "undefined";
        var r = typeof e;
        if ("string" === r) return Ne(String(e));
        if ("number" === r || "boolean" === r || "bigint" === r) return String(e);
        if ("symbol" === r) return e.toString();
        if (e instanceof Node) return "[".concat(e.constructor.name, "]");
        if (Array.isArray(e)) try {
            return Ne(JSON.stringify(e))
        } catch (n) {
            return "[Array(".concat(e.length, ")]")
        }
        if ("object" === r) try {
            return Ne(JSON.stringify(e))
        } catch (r) {
            return "[".concat(null !== (t = null === (n = null == e ? void 0 : e.constructor) || void 0 === n ? void 0 : n.name) && void 0 !== t ? t : "Object", "]")
        }
        return "[".concat(r, "]")
    }

    function Ne(e) {
        return e.length <= Oe ? e : "".concat(e.slice(0, Oe), "…")
    }
    var Ve, Fe, qe = function() {
            return qe = Object.assign || function(e) {
                for (var n, t = 1, r = arguments.length; t < r; t++)
                    for (var i in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
                return e
            }, qe.apply(this, arguments)
        },
        $e = function(e, n, t, r) {
            return new(t || (t = Promise))((function(i, o) {
                function a(e) {
                    try {
                        l(r.next(e))
                    } catch (e) {
                        o(e)
                    }
                }

                function c(e) {
                    try {
                        l(r.throw(e))
                    } catch (e) {
                        o(e)
                    }
                }

                function l(e) {
                    var n;
                    e.done ? i(e.value) : (n = e.value, n instanceof t ? n : new t((function(e) {
                        e(n)
                    }))).then(a, c)
                }
                l((r = r.apply(e, n || [])).next())
            }))
        },
        Me = function(e, n) {
            var t, r, i, o, a = {
                label: 0,
                sent: function() {
                    if (1 & i[0]) throw i[1];
                    return i[1]
                },
                trys: [],
                ops: []
            };
            return o = {
                next: c(0),
                throw: c(1),
                return: c(2)
            }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                return this
            }), o;

            function c(o) {
                return function(c) {
                    return function(o) {
                        if (t) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (t = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                            switch (r = 0, i && (o = [2 & o[0], i.value]), o[0]) {
                                case 0:
                                case 1:
                                    i = o;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: o[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = o[1], o = [0];
                                    continue;
                                case 7:
                                    o = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!((i = (i = a.trys).length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                        a.label = o[1];
                                        break
                                    }
                                    if (6 === o[0] && a.label < i[1]) {
                                        a.label = i[1], i = o;
                                        break
                                    }
                                    if (i && a.label < i[2]) {
                                        a.label = i[2], a.ops.push(o);
                                        break
                                    }
                                    i[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            o = n.call(e, a)
                        } catch (e) {
                            o = [6, e], r = 0
                        } finally {
                            t = i = 0
                        }
                        if (5 & o[0]) throw o[1];
                        return {
                            value: o[0] ? o[1] : void 0,
                            done: !0
                        }
                    }([o, c])
                }
            }
        },
        Ge = new Map,
        We = [];

    function He() {
        var e = Array.from(new Set(Ge.values())),
            n = e.some((function(e) {
                return e.enableDebug
            }));
        if (o() || n) {
            var t = e.map((function(e) {
                return JSON.parse(JSON.stringify(e))
            }));
            return console.info("TTD Pixel v3: dumpConfigs (".concat(t.length, " config").concat(1 === t.length ? "" : "s", "):"), t), t
        }
        console.info("TTD Pixel v3: dumpConfigs requires debug mode. Enable via `?upjs_debug` query param, `localStorage.setItem('enable-ttd-pixel-debugging', '1')`, or `enableDebug: true` on init.")
    }

    function ze(e) {
        var n, t, r, o, a, u, m = e[0],
            h = e[1];
        if ("init" === m) {
            c("init triggered");
            try {
                ! function(e) {
                    var n, t, r, o, a, c, u, m, h, y, b, w, _ = e.merchantId,
                        I = e.advertiserId,
                        x = e.enableCookieSyncing,
                        S = e.enableDebug,
                        k = e.rootUrl,
                        D = e.dataProcessingOption,
                        E = e.uidConfig,
                        T = e.pixelIds,
                        C = e.referrerUrl,
                        P = e.ga4MeasurementId,
                        O = e.eventDataSource,
                        L = e.eventDataSourceVersion;
                    $e(this, void 0, void 0, (function() {
                        var e, U;
                        return Me(this, (function(j) {
                            switch (j.label) {
                                case 0:
                                    if (e = function(e, n, t, r) {
                                            for (var i, o = (null == (r = f(r)) ? void 0 : r.length) > 0 ? r.map((function(e) {
                                                    return p(n, t, e)
                                                })) : [p(n, t)], a = 0, c = o; a < c.length; a++) {
                                                var l = c[a];
                                                if (i = e.get(l)) break
                                            }
                                            i || (i = d({}, s));
                                            for (var u = 0, v = o; u < v.length; u++) l = v[u], e.set(l, i);
                                            return i
                                        }(Ge, I, _, T), e.merchantId = null != _ ? _ : e.merchantId, e.advertiserId = null != I ? I : e.advertiserId, ! function(e, n) {
                                            return v(e) || v(n)
                                        }(e.advertiserId, e.merchantId)) return l("Init failed: At least one valid identifier (advertiserId or merchantId) is required."), [2];
                                    if (void 0 !== O && "JsSdkGtm" !== O) return l('Init failed: eventDataSource "'.concat(O, '" is not supported. Allowed values: "JsSdkGtm".')), [2];
                                    e.enableCookieSyncing = null !== (n = null != x ? x : e.enableCookieSyncing) && void 0 !== n ? n : s.enableCookieSyncing, e.enableDebug = null !== (r = null !== (t = null != S ? S : e.enableDebug || void 0) && void 0 !== t ? t : i()) && void 0 !== r ? r : null != localStorage.getItem("enable-ttd-pixel-debugging") || s.enableDebug, e.rootUrl = null !== (o = null != k ? k : e.rootUrl) && void 0 !== o ? o : s.rootUrl, e.dataProcessingOption = null !== (a = null != D ? D : e.dataProcessingOption) && void 0 !== a ? a : s.dataProcessingOption, e.uidConfig = null !== (c = null != E ? E : e.uidConfig) && void 0 !== c ? c : void 0, e.pixelIds = null !== (m = null !== (u = f(T)) && void 0 !== u ? u : e.pixelIds) && void 0 !== m ? m : void 0, e.ga4MeasurementId = null !== (h = null != P ? P : e.ga4MeasurementId) && void 0 !== h ? h : void 0, e.referrerUrl = null !== (y = null != C ? C : e.referrerUrl) && void 0 !== y ? y : void 0, e.eventDataSource = null !== (b = null != O ? O : e.eventDataSource) && void 0 !== b ? b : void 0, e.eventDataSourceVersion = null !== (w = null != L ? L : e.eventDataSourceVersion) && void 0 !== w ? w : void 0, Ve = e, U = new Promise((function(e) {
                                        return setTimeout(e, 2e3)
                                    })), j.label = 1;
                                case 1:
                                    return j.trys.push([1, 3, 4, 5]), [4, Promise.race([Je(e), U])];
                                case 2:
                                    return j.sent(), [3, 5];
                                case 3:
                                    return l(j.sent(), e), [3, 5];
                                case 4:
                                    return e.initComplete = !0,
                                        function(e, n, t) {
                                            for (var r, i, o, a, c, l, u, d, s = [], v = 0, p = e; v < p.length; v++) {
                                                var m = p[v];
                                                null !== (r = m.config) && void 0 !== r || (m.config = g(n, null !== (i = m.params.advertiserId) && void 0 !== i ? i : m.params.adv, null !== (o = m.params.merchantId) && void 0 !== o ? o : m.params.merchant_id, null !== (c = f(null !== (a = m.params.pixelIds) && void 0 !== a ? a : m.params.pixel_ids)) && void 0 !== c ? c : f(null !== (u = null !== (l = m.params.pixel_id) && void 0 !== l ? l : m.params.tracker_id) && void 0 !== u ? u : m.params.upixel_id), t)), (null === (d = m.config) || void 0 === d ? void 0 : d.initComplete) ? (we(m), be(m.args)) : s.push(m)
                                            }
                                            e.splice.apply(e, ye([0, e.length], s, !1))
                                        }(We, Ge, Ve), [7];
                                case 5:
                                    return [2]
                            }
                        }))
                    }))
                }(h)
            } catch (e) {
                l("Init failed: ".concat(e instanceof Error ? e.message : String(e)))
            }
        } else {
            var y = g(Ge, null !== (n = h.advertiserId) && void 0 !== n ? n : h.adv, null !== (t = h.merchantId) && void 0 !== t ? t : h.merchant_id, null !== (o = f(null !== (r = h.pixelIds) && void 0 !== r ? r : h.pixel_ids)) && void 0 !== o ? o : f(null !== (u = null !== (a = h.pixel_id) && void 0 !== a ? a : h.tracker_id) && void 0 !== u ? u : h.upixel_id), Ve),
                b = {
                    method: m,
                    params: h,
                    args: e,
                    config: y
                };
            (null == y ? void 0 : y.initComplete) ? (we(b), be(e)) : function(e, n) {
                var t = n.params;
                n.config || c("No matching config found for event, queuing until init completes"), e.push(n), setTimeout((function() {
                    if (e.includes(n) && !n.hasFired && !n.config) {
                        var r = t.adv ? "adv: ".concat(t.adv) : t.merchant_id ? "merchant_id: ".concat(t.merchant_id) : "unknown",
                            i = f(t.pixel_ids),
                            o = (null == i ? void 0 : i.join(",")) || "none";
                        l("No matching config for ".concat(r, ", pixel_ids: [").concat(o, "], pixel_id: [").concat(t.pixel_id, "]. ") + "Ensure init is called with matching advertiserId/merchantId and pixelIds. Auto-firing event with default config."), n.hasFired = !0, Ze(t, he({}, s), !0),
                            function(e, n) {
                                var t = e.indexOf(n); - 1 !== t && e.splice(t, 1)
                            }(e, n), be(n.args)
                    }
                }), 5e3)
            }(We, b)
        }
    }

    function Je(e) {
        return new Promise((function(n) {
            var t, r, i, o, a = "".concat(e.rootUrl, "/track/cei"),
                d = void 0 !== e.merchantId && null !== e.merchantId ? "merchant_id=".concat(e.merchantId) : "advertiser_id=".concat(e.advertiserId),
                s = "&cookie_sync=".concat(e.enableCookieSyncing ? 1 : 0),
                v = "".concat(a, "?").concat(d).concat(s, "&upv=").concat(e.pixelVersion);
            null != e.dataProcessingOption && (v += "&dpop=".concat(e.dataProcessingOption.policies, "&dpor=").concat(e.dataProcessingOption.region)), e.pixelIds && (v += "&upid=".concat(e.pixelIds.join(",")));
            var f = (null !== (t = e.advertiserId) && void 0 !== t ? t : e.merchantId) + ":" + (null !== (i = null === (r = e.pixelIds) || void 0 === r ? void 0 : r.join(",")) && void 0 !== i ? i : "");
            e.uidConfig && (v += "&uidc_present=1", window._uidSdkListenerLock = null !== (o = window._uidSdkListenerLock) && void 0 !== o ? o : {}, c("setting up uid config", e), le(f, e.uidConfig, (function() {
                return ce(e, e.uidConfig)
            }), (function(n) {
                return u("UID enabled but failed to register hooks: ", e, n)
            }), e));
            var p = b(e);
            if (null != p) v += "".concat(p);
            else {
                var g = function(e) {
                    if (E = e, "function" == typeof window.__gpp) return void 0 !== (D = function() {
                        var e = window.__gpp("ping");
                        if ("1.0" == e.gppVersion) {
                            var n = window.__gpp("getGPPData");
                            D.gppString = null == n ? void 0 : n.gppString
                        } else D.gppString = null == e ? void 0 : e.gppString;
                        return D
                    }()).gppString ? (O("gpp response already loaded, parse response"), P(D)) : (k = setTimeout(T, 1e3), x = !1, window.__gpp("addEventListener", C), void 0 !== D.gppString ? (O("gpp response received, parse response"), P(D)) : void 0);
                    O("gpp not a function")
                }(e);
                v += "".concat(null != g ? g : "")
            }
            e.enableDebug && (v += "&debug=1"), window.addEventListener && window.addEventListener("message", (function(n) {
                ! function(e, n) {
                    try {
                        if (null === e.origin || "null" === e.origin) return;
                        var t = new URL(e.origin);
                        if (!Be.some((function(e) {
                                return t.hostname.endsWith(e)
                            }))) return;
                        if ("string" != typeof e.data) return;
                        var r = JSON.parse(e.data);
                        "UID2" === r.type || "EUID" === r.type ? function(e, n) {
                            var t;
                            null === ae ? e.advertiserId && "string" == typeof e.advertiserId && e.advertiserId === n.advertiserId && (window._uidSdkListenerLock = null !== (t = window._uidSdkListenerLock) && void 0 !== t ? t : {}, n.uidConfig = e, le(e.advertiserId + ":" + e.pixelId, n.uidConfig, (function() {
                                return ce(n, n.uidConfig)
                            }), (function(e) {
                                pe("UID enabled but failed to register hooks: ", e)
                            }), n)) : pe("UID already configured by advertiser ".concat(ae.advertiserId, ", pixel ").concat(ae.pixelId, ". Only one UID configuration per page is currently allowed."))
                        }(r, n) : "DynamicParams" === r.type && function(e, n) {
                            var t;
                            if ("DynamicParams" === (null == e ? void 0 : e.type) && e.pixelId && "string" == typeof e.pixelId && Array.isArray(e.params) && n.pixelIds && n.pixelIds.includes(e.pixelId)) {
                                var r = e.params.map(ke);
                                n.dynamicParamsConfig = null !== (t = n.dynamicParamsConfig) && void 0 !== t ? t : {}, n.dynamicParamsConfig[e.pixelId] = r
                            }
                        }(r, n)
                    } catch (e) {
                        l("Error handling postMessage: ", e)
                    }
                }(n, e)
            }));
            var m = e.referrerUrl || U(e.enableDebug);
            v += "&ref=".concat(encodeURIComponent(m));
            var h = "universal_pixel";
            e.pixelIds && (h += "_" + e.pixelIds.join("_")), c("trigger GET conversion init call", e), L(v, h, "TTD Universal Pixel").onload = function() {
                return n()
            }
        }))
    }

    function Ze(e, n, t) {
        var r, i, o, a, d, s, v, p, g, m, y, b = null !== (r = e.privacy_settings) && void 0 !== r ? r : [],
            w = function() {
                var e;
                if (h.consentCheckExists) return {
                    privacy_type: "GDPR",
                    is_applicable: h.isGdprApplicable,
                    consent_string: null !== (e = h.gdprConsentString) && void 0 !== e ? e : ""
                };
                I("tcfapi consent status check failed")
            }(),
            _ = function() {
                if ("" != D.gppString && null != D.gppString) return {
                    privacy_type: "GPP",
                    is_applicable: !0,
                    consent_string: D.gppString
                }
            }();
        if (t && (w ? (b = b.filter((function(e) {
                return e.privacy_type !== w.privacy_type
            })), e.gdpr = w.is_applicable, e.gdpr_consent = w.consent_string) : _ && (b = b.filter((function(e) {
                return e.privacy_type !== _.privacy_type
            })), e.gpp_consent = _.consent_string)), null !== (i = e.adv) && void 0 !== i || (e.adv = e.advertiserId), e.advertiserId = void 0, null !== (o = e.merchant_id) && void 0 !== o || (e.merchant_id = e.merchantId), e.merchantId = void 0, void 0 === n.merchantId || null === n.merchantId || e.merchant_id ? void 0 === n.advertiserId || null === n.advertiserId || e.adv || (e.adv = n.advertiserId) : e.merchant_id = n.merchantId, void 0 !== n.ga4MeasurementId) {
            var x = function(e) {
                    var n = ge()._ga;
                    if (!n || !n.startsWith("GA")) return me(e, "_ga cookie not found or malformed"), null;
                    var t = n.split(".");
                    return 4 === t.length ? t[2] + "." + t[3] : (me(e, "Unexpected _ga cookie format:" + n), null)
                }(n.enableDebug),
                S = function(e, n) {
                    var t = ge()["_ga_" + (n = n.startsWith("G-") ? n.split("-")[1] : n)];
                    if (!t || !t.startsWith("GS")) return me(e, "_ga_" + n + " cookie not found or malformed"), null;
                    var r = t.split("."),
                        i = r[0].includes("2"),
                        o = r[2];
                    return i ? o.split("$")[0].slice(1) : o
                }(n.enableDebug, n.ga4MeasurementId);
            x && S && (e.ga_client_id = x, e.ga_session_id = S)
        }
        n.enableDebug && (e.debug = "1"), null !== (a = e.data_processing_option) && void 0 !== a || (e.data_processing_option = n.dataProcessingOption), e.pixel_ids = f(e.pixel_ids), e.pixelIds = f(e.pixelIds), null !== (d = e.pixel_id) && void 0 !== d || (e.pixel_id = null !== (s = e.tracker_id) && void 0 !== s ? s : e.upixel_id), e.tracker_id = void 0, e.upixel_id = void 0, e.pixel_id && (null !== (v = e.pixel_ids) && void 0 !== v || (e.pixel_ids = f(e.pixel_id))), e.pixel_id = void 0, null !== (p = e.pixel_ids) && void 0 !== p || (e.pixel_ids = null !== (g = e.pixelIds) && void 0 !== g ? g : n.pixelIds), e.pixelIds = void 0, null !== (m = e.referrer_url) && void 0 !== m || (e.referrer_url = U(n.enableDebug)), (null === (y = n.uidConfig) || void 0 === y ? void 0 : y.uid_token) && function(e, n) {
                if (!ae || e !== ae.advertiserId) return !1;
                var t = f(n);
                return !(t && t.length > 0) || t.includes(ae.pixelId)
            }(e.adv, e.pixel_ids) && (se(n.uidConfig) ? e.uid2_token = n.uidConfig.uid_token : de(n.uidConfig) && (e.euid_token = n.uidConfig.uid_token)), null != localStorage.getItem("enable-ttd-pixel-available-param-analysis") && function(e, n) {
                var t, r = {
                        formFields: Le(),
                        variables: Ue(),
                        functions: je()
                    },
                    i = r.formFields,
                    o = r.variables,
                    a = r.functions,
                    l = null !== (t = n.event_name) && void 0 !== t ? t : "unknown";
                c("AvailableParamAnalysis (event: ".concat(l, ") — ") + "formFields: ".concat(i.length, ", variables: ").concat(o.length, ", functions: ").concat(a.length), e, {
                    formFields: i,
                    variables: o,
                    functions: a
                })
            }(n, e),
            function(e, n) {
                var t;
                if (n.dynamicParamsConfig) {
                    var r = null !== (t = e.pixel_ids) && void 0 !== t ? t : n.pixelIds;
                    if (r && 0 !== r.length) {
                        for (var i = new Set, o = 0, a = r; o < a.length; o++) {
                            var l = a[o],
                                d = n.dynamicParamsConfig[l];
                            if (d && 0 !== d.length)
                                for (var s = 0, v = d; s < v.length; s++) {
                                    var f = v[s];
                                    if (f.parameterValue && "" !== f.parameterValue) {
                                        var p = Ee(f, l, n, i);
                                        if (void 0 !== p && "" !== p && "undefined" !== p && "null" !== p) {
                                            var g = f.evaluatedParameter,
                                                m = e[g];
                                            if (void 0 !== m) {
                                                var h = String(m);
                                                h === p ? c("DynamicParams: ".concat(f.evaluatedParameter, " on pixel ").concat(l, " client value matches resolved value ('").concat(p, "')"), n) : (u("DynamicParams: ".concat(f.evaluatedParameter, " on pixel ").concat(l, " client value '").concat(h, "' does NOT match resolved value '").concat(p, "'"), n), i.add("".concat(f.evaluatedParameter, "m")))
                                            } else e[g] = p
                                        }
                                    }
                                }
                        }
                        i.size > 0 && (e.rt_dpme = Array.from(i).join(","))
                    }
                }
            }(e, n);
        var k = {
            data: [qe(qe({}, e), {
                privacy_settings: b
            })]
        };
        (n.enableDebug || e.debug) && (k.debug = "1"),
        function(e, n, t) {
            var r = this,
                i = "".concat(e.rootUrl, "/track/realtimeconversion");
            return c("trigger POST realtime conversion event", e), new Promise((function(o, a) {
                var l = new XMLHttpRequest;
                l.withCredentials = !0, l.open("POST", i), l.setRequestHeader("Content-type", "application/json"), l.setRequestHeader("eventDataSource", e.eventDataSource || "JsSdk"), l.setRequestHeader("eventDataSourceVersion", e.eventDataSourceVersion || e.pixelVersion), l.onload = function() {
                    l.status >= 200 && l.status < 300 ? o(l.response) : a(l.response)
                }, l.onerror = function() {
                    return $e(r, void 0, void 0, (function() {
                        var r;
                        return Me(this, (function(i) {
                            return r = function(e) {
                                    var n, t = null !== (n = e.responseText) && void 0 !== n ? n : JSON.parse(e.responseText);
                                    return (null == t ? void 0 : t.Message) ? t.Message : 0 !== e.status || e.responseText ? "Status Code ".concat(e.status) : "Request never hit server. Possible CSP violation."
                                }(l), a(l.statusText),
                                function(e, n, t, r) {
                                    var i, o, a, l;
                                    $e(this, void 0, void 0, (function() {
                                        var u, d, s, v;
                                        return Me(this, (function(f) {
                                            var p, g, m;
                                            return u = "universal_pixel_realtime_fallback_" + (null !== (l = null !== (o = null === (i = t.pixel_ids) || void 0 === i ? void 0 : i.join("_")) && void 0 !== o ? o : null === (a = e.pixelIds) || void 0 === a ? void 0 : a.join("_")) && void 0 !== l ? l : ""), c("trigger GET realtime conversion event fallback", e), p = n.data[0], g = Object.entries(p).filter((function(e) {
                                                var n = e[0],
                                                    t = e[1];
                                                return ("string" == typeof t || "number" == typeof t || "boolean" == typeof t || "pixel_ids" === n) && null != t && "" !== t
                                            })), m = new URLSearchParams, g.forEach((function(e) {
                                                var n = e[0],
                                                    t = e[1];
                                                m.append(n, String(t))
                                            })), d = m, s = (e.eventDataSource || "JsSdk") + "Get", v = e.eventDataSourceVersion || e.pixelVersion, d.set("eds", s), d.set("edsv", v), d.set("rt_fallback", "1"), "" !== r && d.set("rt_fbErr", r), L("".concat(e.rootUrl, "/track/rt?").concat(d.toString()), u, "TTD Universal Pixel Realtime Fallback"), [2]
                                        }))
                                    }))
                                }(e, n, t, r), [2]
                        }))
                    }))
                }, l.send(JSON.stringify(n))
            }))
        }(n, k, e).catch((function(e) {
            return l(e, n)
        }))
    }
    window.ttdConversionEventsLayer = window.ttdConversionEventsLayer || [], window.ttdConversionEvents = null !== (Fe = window.ttdConversionEvents) && void 0 !== Fe ? Fe : {
            activeDetection: null,
            startDetection: null,
            dumpConfigs: null
        }, window.ttdConversionEvents.dumpConfigs = He,
        function(e, n, t) {
            if (t || 2 === arguments.length)
                for (var r, i = 0, o = n.length; i < o; i++) !r && i in n || (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
            return e.concat(r || Array.prototype.slice.call(n))
        }([], window.ttdConversionEventsLayer, !0).forEach(ze), window.ttdConversionEventsLayer.push = function(e) {
            return Array.prototype.push.call(window.ttdConversionEventsLayer, e), ze(e), this.length
        }, window.ttd_dom_ready = q, window.TTDUniversalPixelApi = function(e) {
            this.init = function(n, t, r, i, o) {
                Ke(null != n ? n : void 0, null != t ? t : void 0, null != r ? r : void 0, null != i ? i : void 0, null != o ? o : void 0, null != e ? e : void 0)
            }
        };
    var Be = [".adsrvr.org", ".adsrvr.cn"];

    function Ke(e, n, t, r, i, o) {
        return $e(this, void 0, void 0, (function() {
            var a, l, u, d, s;
            return Me(this, (function(v) {
                if (c("Legacy pixel route triggered with advertiserId: " + e + ", pixelIds: " + n), n = f(n), !e || "" == e || !n || n.length <= 0) return c("no advertiser id or pixel id given"), [2];
                if (a = "https://" + new URL(t).hostname, l = {
                        advertiserId: e,
                        pixelIds: n,
                        rootUrl: a,
                        uidConfig: i,
                        referrerUrl: o
                    }, u = {
                        adv: e,
                        pixel_ids: n,
                        referrer_url: o
                    }, r)
                    for (d in r) s = r[d], "cookie_sync" === d ? l.enableCookieSyncing = "1" === s : void 0 !== s && (u[d] = "fmt" === d && "number" == typeof s ? s.toString() : s), "fmt" !== d || "4" !== s && 4 !== s || (l.enableCookieSyncing = !1);
                return window.ttdConversionEventsLayer.push(["init", l]), setTimeout((function() {
                    var t, r = g(Ge, e, null, n);
                    !window._uidSdkListenerLock || (null === (t = null == r ? void 0 : r.uidConfig) || void 0 === t ? void 0 : t.uid_token) ? window.ttdConversionEventsLayer.push(["event", u]) : document.addEventListener("visibilitychange", (function() {
                        return Xe(u, e, n)
                    }))
                }), 1e3), [2]
            }))
        }))
    }

    function Xe(e, n, t) {
        return $e(this, void 0, void 0, (function() {
            var r;
            return Me(this, (function(i) {
                return "hidden" === document.visibilityState && ((r = g(Ge, n, null, t)) && Ze(e, r, !0), document.removeEventListener("visibilitychange", Xe)), [2]
            }))
        }))
    }

    function Qe() {
        Ge.clear(), We.length = 0, Ve = void 0, oe = {}, ae = null
    }
    window.ttd_up_api = {
        topLevelUrl: "",
        set_top_level_url: function(e) {
            this.topLevelUrl = e
        },
        init: function(e, n, t, r, i) {
            Ke(e, n, t, r, i, this.topLevelUrl)
        }
    }, TTDConversionEvents = n
})();