"use strict";
(() => {
    var At = Object.defineProperty,
        ht = Object.defineProperties;
    var bt = Object.getOwnPropertyDescriptors;
    var y = Object.getOwnPropertySymbols;
    var Ae = Object.prototype.hasOwnProperty,
        he = Object.prototype.propertyIsEnumerable;
    var we = (e, t, n) => t in e ? At(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: n
        }) : e[t] = n,
        p = (e, t) => {
            for (var n in t || (t = {})) Ae.call(t, n) && we(e, n, t[n]);
            if (y)
                for (var n of y(t)) he.call(t, n) && we(e, n, t[n]);
            return e
        },
        C = (e, t) => ht(e, bt(t));
    var be = (e, t) => {
        var n = {};
        for (var o in e) Ae.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
        if (e != null && y)
            for (var o of y(e)) t.indexOf(o) < 0 && he.call(e, o) && (n[o] = e[o]);
        return n
    };
    var m = (e, t) => () => (e && (t = e(e = 0)), t);
    var St = (e, t) => () => (t || e((t = {
        exports: {}
    }).exports, t), t.exports);
    var d = (e, t, n) => new Promise((o, i) => {
        var a = r => {
                try {
                    s(n.next(r))
                } catch (g) {
                    i(g)
                }
            },
            c = r => {
                try {
                    s(n.throw(r))
                } catch (g) {
                    i(g)
                }
            },
            s = r => r.done ? o(r.value) : Promise.resolve(r.value).then(a, c);
        s((n = n.apply(e, t)).next())
    });

    function Tt(e, t, n) {
        return e.includes("/developer-platform") || t.startsWith(`${n}`)
    }

    function Ot(e, t) {
        return t ? j.DEV_PLATFORM_PROD : e ? j.ZAPIER_PROD : j.ZAPIER_STAGING
    }
    var _, T, u, Se, G, Ie, Te, It, E, j, v, Oe, Ce, Pe, x, V, P, K, Ne, Z, Re, De, Le, ye, Ct, Ge, ve, xe, Me, Fe, ke, He, Ue, Y, M, ze, We, F, f = m(() => {
        "use strict";
        _ = document.location.hostname.includes("zapier.com"), T = document.location.hostname.includes("zapier-staging.com"), u = _ ? "https://zapier.com" : T ? "https://zapier-staging.com" : "", Se = "https://static.ada.support/embed2.js", G = _ ? "https://cdn.zapier.com/packages/chat-widget/support-copilot/v1/index.js" : "https://cdn.zapier-staging.com/packages/chat-widget/support-copilot/v1/index.js", Ie = _ ? "https://cdn.zapier.com/packages/chat-widget/developer-platform-copilot/v1/index.js" : "https://cdn.zapier-staging.com/packages/chat-widget/developer-platform-copilot/v1/index.js", Te = _ ? "https://cdn.zapier.com/packages/chat-widget/faux-pilot/v1/index.js" : "https://cdn.zapier-staging.com/packages/chat-widget/faux-pilot/v1/index.js", It = _ ? "https://developer.zapier.com" : "https://developer.zapier-staging.com";
        E = Tt(window.location.pathname, window.location.href, It), j = {
            ZAPIER_PROD: "su0xp8g6",
            ZAPIER_STAGING: "yi7ip89a",
            DEV_PLATFORM_PROD: "eg4np976"
        };
        v = Ot(_, E), Oe = "zapier-developer-generative", Ce = "zapier-sales-generative", Pe = "zapier-sales-generative-staging", x = "zapier-support-generative", V = ["/blog/zapier-enterprise-business-plan", "/customer-stories", "/resources", "/solutions", "/apps/salesforce/integrations", "/hubspot/integrations", "/app/settings", "/pricing", "/app/pricing", "/app/planbuilder/plans", "/app/planbuilder/add-ons", "/app/planbuilder/pricing", "/app/planbuilder/checkout", "/zapconnect/confirmation", "/enterprise", "/ticket-incident-management", "/gtm-ops", "/gtm-ops-guide", "/app/chatbots/pricing", "/ai/claude-for-smb", "/claude-smb-zapier-with-anthropic", "/fr", "/fr/ai", "/fr/agents", "/fr/tables", "/fr/interfaces", "/fr/canvas", "/fr/l/home", "/fr/blog/best-ai-website-builder", "/fr/blog/best-ai-meeting-assistant", "/fr/blog/best-time-tracking-apps", "/fr/blog/best-social-media-management-tools", "/fr/blog/best-ai-scheduling", "/fr/blog/best-sms-app", "/fr/blog/free-email-marketing-software", "/fr/pricing", "/fr/sign-up", "/de", "/de/ai", "/de/agents", "/de/tables", "/de/interfaces", "/de/canvas", "/de/l/home", "/de/blog/best-ai-website-builder", "/de/blog/best-ai-meeting-assistant", "/de/blog/best-time-tracking-apps", "/de/blog/best-social-media-management-tools", "/de/blog/best-ai-scheduling", "/de/blog/best-sms-app", "/de/blog/free-email-marketing-software", "/de/pricing", "/de/sign-up", "/es", "/es/ai", "/es/agents", "/es/tables", "/es/interfaces", "/es/canvas", "/es/l/home", "/es/blog/best-ai-website-builder", "/es/blog/best-ai-meeting-assistant", "/es/blog/best-time-tracking-apps", "/es/blog/best-social-media-management-tools", "/es/blog/best-ai-scheduling", "/es/blog/best-sms-app", "/es/blog/free-email-marketing-software", "/es/pricing", "/es/sign-up", "/ja", "/ja/ai", "/ja/agents", "/ja/tables", "/ja/interfaces", "/ja/canvas", "/ja/l/home", "/ja/blog/best-ai-website-builder", "/ja/blog/best-ai-meeting-assistant", "/ja/blog/best-time-tracking-apps", "/ja/blog/best-social-media-management-tools", "/ja/blog/best-ai-scheduling", "/ja/blog/best-sms-app", "/ja/blog/free-email-marketing-software", "/ja/pricing", "/ja/sign-up", "/pt-br", "/pt-br/ai", "/pt-br/agents", "/pt-br/tables", "/pt-br/interfaces", "/pt-br/canvas", "/pt-br/l/home", "/pt-br/blog/best-ai-website-builder", "/pt-br/blog/best-ai-meeting-assistant", "/pt-br/blog/best-time-tracking-apps", "/pt-br/blog/best-social-media-management-tools", "/pt-br/blog/best-ai-scheduling", "/pt-br/blog/best-sms-app", "/pt-br/blog/free-email-marketing-software", "/pt-br/pricing", "/pt-br/sign-up"], P = "/app/get-help", K = ["/workflows", "/how-it-works", "/apps/"], Ne = "/l/home", Z = "/app/home", Re = ["/app/admin/audit-log/", "/app/canvas", "/app/inbox/", "/canvas", "/app/tables", "/tables", "/interfaces", "/magic", "/wild-kiwi-workflow", "/chatty-cherry-blast", "/tangy-task-assistants", "/very-berry-visualizer", "/function", "/app/planbuilder/review-changes", "/ai", "/agents"], De = ["https://interfaces.zapier.com", "https://learn.zapier.com", "https://zapier.com/zap", "https://agents.zapier.com", "https://agents.zapier-staging.com", "https://agents-admin.zapier.com/", "https://agents-admin.zapier-staging.com/", "https://tables.zapier.com", "https://tables.zapier-staging.com"], Le = ["meta-externalagent", "meta-webindexer"], ye = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE"], Ct = {
            Africa: ["DZ", "AO", "BJ", "BW", "BF", "BI", "CV", "CM", "CF", "TD", "KM", "CG", "CD", "CI", "DJ", "EG", "GQ", "ER", "SZ", "ET", "GA", "GM", "GH", "GN", "GW", "KE", "LS", "LR", "LY", "MG", "MW", "ML", "MR", "MU", "YT", "MA", "MZ", "NA", "NE", "NG", "RE", "RW", "SH", "ST", "SN", "SC", "SL", "SO", "ZA", "SS", "SD", "TZ", "TG", "TN", "UG", "EH", "ZM", "ZW"],
            Asia: ["AF", "AM", "AZ", "BH", "BD", "BT", "BN", "KH", "CN", "GE", "HK", "IN", "ID", "IR", "IQ", "IL", "JP", "JO", "KZ", "KW", "KG", "LA", "LB", "MO", "MY", "MV", "MN", "MM", "NP", "KP", "OM", "PK", "PS", "PH", "QA", "SA", "SG", "KR", "LK", "SY", "TW", "TJ", "TH", "TL", "TR", "TM", "AE", "UZ", "VN", "YE"],
            Europe: ["AL", "AD", "AT", "BY", "BE", "BA", "BG", "HR", "CY", "CZ", "DK", "EE", "FO", "FI", "FR", "DE", "GI", "GR", "GG", "HU", "IS", "IE", "IM", "IT", "JE", "XK", "LV", "LI", "LT", "LU", "MT", "MD", "MC", "ME", "NL", "MK", "NO", "PL", "PT", "RO", "RU", "SM", "RS", "SK", "SI", "ES", "SJ", "SE", "CH", "UA", "GB", "VA"],
            "North America": ["AI", "AG", "AW", "BS", "BB", "BZ", "BM", "CA", "KY", "CR", "CU", "CW", "DM", "DO", "SV", "GL", "GD", "GP", "GT", "HT", "HN", "JM", "MQ", "MX", "MS", "NI", "PA", "PR", "BL", "KN", "LC", "MF", "PM", "VC", "SX", "TT", "TC", "US", "VG", "VI"],
            "South America": ["AR", "BO", "BR", "CL", "CO", "EC", "FK", "GF", "GY", "PY", "PE", "SR", "UY", "VE"],
            Oceania: ["AS", "AU", "CK", "FJ", "PF", "GU", "KI", "MH", "FM", "NR", "NC", "NZ", "NU", "NF", "MP", "PW", "PG", "PN", "WS", "SB", "TK", "TO", "TV", "VU", "WF"],
            Antarctica: ["AQ", "BV", "GS", "HM", "TF"]
        }, Ge = Object.entries(Ct).reduce((e, [t, n]) => (n.forEach(o => {
            e[o] = t
        }), e), {}), ve = ["/l/chat-confirmation", "/l/contact-sales-confirmation-chat"], xe = ["/l/chat-confirmation", "/l/contact-sales-confirmation-chat"], Me = "/l/chat-with-sales", Fe = ["app_id", "user_hash"], ke = ["first_name", "last_name", "hubspot_company_size", "hubspot_enriched_company_size", "hubspot_csm_owner", "hubspot_csom_owner", "hubspot_owner_id", "hubspot_owner_name", "hubspot_job_level", "hubspot_job_role", "hubspot_qualified_signup_score", "hubspot_who_will_be_using_zapier"], He = ["Free"], Ue = ["Director", "VP / Exec", "VP/ Exec"], Y = ["250-999", "1,000+", "1,000-4,999", "5,000+"], M = "67cb51bf502e900d140e5295", ze = "6a4677a641928f54ada27a4d", We = "6a6bd3d26e103528c9bc5d9f", F = "sse_enable-support-copilot-chat-widget"
    });

    function Pt(e, t) {
        let n = t.endsWith("/"),
            o = n ? t.slice(0, -1) : t;
        return e === o || n && e.startsWith(t)
    }

    function Nt(e) {
        return Re.some(t => Pt(e, t))
    }

    function Rt(e) {
        return De.some(t => e.startsWith(t))
    }

    function k(e, t) {
        return Nt(e) || Rt(t)
    }
    var $ = m(() => {
        "use strict";
        f()
    });

    function Dt() {
        return d(this, null, function*() {
            let e = `${u}/api/in-product-messaging/features/`;
            try {
                let t = yield fetch(e, {
                    credentials: "include"
                });
                if (!(t != null && t.ok)) return {};
                let n = yield t.json();
                return n != null ? n : {}
            } catch (t) {
                return console.error("Error fetching split flags:", t), {}
            }
        })
    }
    var H, J = m(() => {
        "use strict";
        f();
        H = () => d(void 0, null, function*() {
            let e = yield Dt();
            return e != null ? e : {}
        })
    });

    function je(e) {
        return document.cookie.split(";").find(t => {
            let [n] = t.split("=");
            return n.trim() === e
        })
    }

    function O(e) {
        var t, n, o;
        return (o = (n = (t = document.cookie.split(";").find(i => {
            let [a] = i.split("=");
            return a.trim() === e
        })) == null ? void 0 : t.split("=")) == null ? void 0 : n[1]) == null ? void 0 : o.trim()
    }

    function Ve(e = "") {
        let o = decodeURIComponent(e).split("&").find(s => s.includes("groups"));
        return o ? o.split("=")[1].split(",").filter(s => s.split(":")[1] === "1").map(s => s.split(":")[0]) : []
    }

    function U() {
        var t, n;
        let e = JSON.parse((t = sessionStorage.getItem("page_view_id")) != null ? t : "[]");
        return (n = e == null ? void 0 : e[1]) != null ? n : ""
    }

    function Q(e = "") {
        var t;
        return e ? (Number(e) ^ ((t = window.crypto) == null ? void 0 : t.getRandomValues(new Uint8Array(1))[0]) & 15 >> Number(e) / 4).toString(16) : `10000000-1000-4000-8000-${1e11}`.replace(/[018]/g, Q)
    }

    function Ke(e) {
        let t = [
                [0, 500, "arr-0-500"],
                [500, 2e3, "arr-500-2000"],
                [2e3, 1e4, "arr-2000-10000"],
                [1e4, 2e4, "arr-10000-20000"],
                [2e4, 5e4, "arr-20000-50000"],
                [5e4, 1e5, "arr-50000-100000"],
                [1e5, 1 / 0, "arr-100000_plus"]
            ],
            n = "arr-unknown";
        if (e == null) return n;
        let o = Math.floor(e * 12 / 100);
        for (let [i, a, c] of t)
            if (i <= o && o < a) return c;
        return n
    }

    function Ze(e, t = "", n = null, o = "", i = "", a = "") {
        let c = Ue.includes(o),
            s = Y.includes(i) || Y.includes(a);
        if (c && s) return !1;
        let g = Math.floor(Date.now() / 1e3) - 60 * 60 * 24 * 7,
            A = e < g,
            B = He.includes(t);
        return !!(B && A || B && !n)
    }

    function Ye(e, t) {
        return Object.keys(e).reduce((n, o) => (t.includes(o) || (n[o] = e[o]), n), {})
    }

    function X(e) {
        return Ye(e, Fe)
    }

    function q(e) {
        return Ye(e, ke)
    }

    function N(e) {
        return e.length > 1 && e.endsWith("/") ? e.slice(0, -1) : e
    }

    function $e() {
        if (typeof window == "undefined") return !1;
        let e = window.navigator.userAgent.toLowerCase();
        return Le.some(t => e.includes(t))
    }

    function Lt() {
        return window.innerWidth < 768
    }

    function S(e = !1) {
        let t = N(window.location.pathname);
        return !(t.includes("/l/") && t !== "/l/support" || V.some(function(n) {
            return t === n
        }) || K.some(n => t.startsWith(n)) && !e)
    }

    function w(e = !1) {
        let t = S(e),
            n = E ? Oe : t ? x : Ce;
        return T && !E ? t ? `${n}-sandbox` : Pe : n
    }

    function te(i) {
        return d(this, arguments, function*({
            functional_cookies_enabled: e,
            user_is_logged_in: t,
            pathname: n,
            is_copilot_enabled: o
        }) {
            var A;
            if ($e()) return !1;
            let a = N(n != null ? n : window.location.pathname),
                c = window.location.href,
                s = S(t);
            return E || Lt() && a.includes(Z) ? !1 : s && !t ? a === "/app/get-help" : !(_ && !e && !s || ((A = (yield H())[F]) != null ? A : !1) && o !== !1 && (a.includes("/editor") || a.includes(Z)) || a.includes(Ne) || k(a, c))
        })
    }

    function Je() {
        return ve.some(e => window.location.pathname.includes(e))
    }

    function Qe() {
        return !S(!1)
    }

    function yt() {
        let e = N(window.location.pathname);
        return e.includes("/l/") && e !== "/l/support" || V.some(t => e === t) || K.some(t => e.startsWith(t))
    }

    function Gt(e) {
        var o;
        let t = e == null ? void 0 : e.trim().toUpperCase();
        if (!t || !/^[A-Z]{2}$/.test(t)) return null;
        let n;
        try {
            n = new Intl.DisplayNames(["en"], {
                type: "region"
            }).of(t)
        } catch (i) {
            return null
        }
        return !n || n === t ? null : {
            country: n,
            region: null,
            continent: (o = Ge[t]) != null ? o : null,
            is_eu: ye.includes(t)
        }
    }

    function vt() {
        var e, t;
        try {
            let n = (t = (e = window.OneTrust) == null ? void 0 : e.getGeolocationData) == null ? void 0 : t.call(e),
                o = Gt(n == null ? void 0 : n.country);
            return o ? C(p({}, o), {
                region: typeof n.stateName == "string" ? n.stateName : null
            }) : null
        } catch (n) {
            return null
        }
    }

    function xt() {
        return new Promise(e => {
            let {
                retries: t
            } = Be, n = () => {
                let o = vt();
                if (o) return e(o);
                if (t-- <= 0) return e(null);
                setTimeout(n, Be.intervalMs)
            };
            n()
        })
    }

    function ne() {
        return d(this, null, function*() {
            var e, t, n, o;
            try {
                if (T || ee() || $e() || window.navigator.webdriver || !yt()) return b;
                let i = yield xt();
                if (i) return i;
                let a = `${u}/api/supportbff/v1/proactive_campaigns/geo/`,
                    c = yield Promise.race([fetch(a).catch(() => null), new Promise(r => setTimeout(() => r(null), 1e4))]);
                if (!(c != null && c.ok)) return b;
                let s = yield c.json().catch(() => null);
                return s ? {
                    country: (e = s.country) != null ? e : null,
                    region: (t = s.region) != null ? t : null,
                    continent: (n = s.continent) != null ? n : null,
                    is_eu: (o = s.is_eu) != null ? o : null
                } : b
            } catch (i) {
                return b
            }
        })
    }

    function Xe() {
        return xe.some(e => window.location.pathname.includes(e))
    }

    function qe(e) {
        if (!window.location.pathname.includes("/planbuilder")) return;
        let t = window.location.pathname,
            n = setInterval(() => d(this, null, function*() {
                let o = window.location.pathname;
                if (!o.includes("/planbuilder")) {
                    clearInterval(n);
                    return
                }
                if (o === t) return;
                t = o;
                let i = yield te(C(p({}, e), {
                    pathname: o
                }));
                if (window.adaEmbed) try {
                    i ? window.adaEmbed.start(p({
                        handle: w(e.user_is_logged_in)
                    }, window.adaSettings)) : window.adaEmbed.stop()
                } catch (a) {}
            }), 2e3)
    }
    var ee, b, Be, R = m(() => {
        "use strict";
        f();
        $();
        J();
        ee = () => {
            let e = new RegExp(["googlebot", "bingbot", "slurp", "duckduckbot", "baiduspider", "yandexbot", "facebot", "ia_archiver", "oncrawl", "yeti", "headless", "phantomjs", "lighthouse", "pagespeed", "gtmetrix", "speedcurve", "ptst", "prerender", "rendertron", "bingpreview", "facebookexternalhit", "inspectiontool", "mediapartners", "bot", "crawler", "spider", "crawling", "fetcher", "scrape"].join("|"), "i");
            return typeof window != "undefined" && e.test(window.navigator.userAgent.toLowerCase())
        };
        b = {
            country: null,
            region: null,
            continent: null,
            is_eu: null
        };
        Be = {
            retries: 12,
            intervalMs: 250
        }
    });

    function oe(e) {
        let t = N(window.location.pathname),
            n = window.location.href;
        return k(t, n) || (t === "/editor" || t.startsWith("/editor/")) && e.user_is_staff === !0 ? !1 : S(e.user_is_logged_in)
    }

    function z(e, t) {
        try {
            let n = document.createElement("script");
            n.id = "__copilotWidget", n.src = e, n.async = !0, window.zapierCopilotWidgetConfig = t, document.head.appendChild(n)
        } catch (n) {
            console.error("Error injecting copilotWidget script:", n)
        }
    }

    function et(e) {
        return new Promise((t, n) => {
            window.ZapierChat || (window.zapierCopilotWidget = {
                config: e
            }, z(G, e));
            let o = 100,
                i = 5e3,
                a = 0,
                c = () => {
                    var s;
                    typeof((s = window.ZapierChat) == null ? void 0 : s.openFromSalesHandoff) == "function" ? (window.ZapierChat.openFromSalesHandoff(), t()) : a >= i ? n(new Error("Copilot widget did not become ready for handoff")) : (a += o, setTimeout(c, o))
                };
            c()
        })
    }
    var ie = m(() => {
        "use strict";
        $();
        f();
        R()
    });
    var D, tt = m(() => {
        "use strict";
        D = {
            OPEN: "open",
            CLOSE: "close",
            LOAD: "load",
            SHOWN: "shown",
            CAMPAIGN_SHOWN: "campaign_shown",
            CAMPAIGN_OPENED: "campaign_opened",
            CAMPAIGN_ENGAGED: "campaign_engaged"
        }
    });

    function nt() {
        let e = 0,
            t = window.setInterval(() => {
                if (e > 80) return clearInterval(t);
                e += 1, document.getElementById("ada-button-frame") && (clearInterval(t), window.dispatchEvent(new CustomEvent("zapier.onShowAdaWidget")))
            }, 250);
        window.addEventListener("beforeunload", () => {
            t && clearInterval(t)
        })
    }

    function ot(e) {
        let {
            OPEN: t,
            CLOSE: n,
            LOAD: o,
            SHOWN: i
        } = D, a = w(e.user_is_logged_in);
        window.addEventListener("zapier.onOpenAdaMessenger", () => {
            I({
                interaction_name: t,
                customuser_id: e.user_id,
                account_id: e.current_account_id,
                ada_bot_handle: a
            })
        }), window.addEventListener("zapier.onCloseAdaMessenger", () => {
            I({
                interaction_name: n,
                customuser_id: e.user_id,
                account_id: e.current_account_id,
                ada_bot_handle: a
            })
        }), window.addEventListener("zapier.onAdaEmbedLoaded", () => {
            I({
                interaction_name: o,
                customuser_id: e.user_id,
                account_id: e.current_account_id,
                ada_bot_handle: a
            })
        }), window.addEventListener("zapier.onShowAdaWidget", () => {
            I({
                interaction_name: i,
                content_type: "widget",
                customuser_id: e.user_id,
                account_id: e.current_account_id,
                ada_bot_handle: a
            })
        })
    }

    function ae(e, t) {
        I({
            interaction_name: D.CAMPAIGN_SHOWN,
            customuser_id: e.user_id,
            account_id: e.current_account_id,
            ada_campaign_key: t,
            ada_bot_handle: w(e.user_is_logged_in)
        })
    }

    function re(e, t) {
        I({
            interaction_name: D.CAMPAIGN_OPENED,
            customuser_id: e.user_id,
            account_id: e.current_account_id,
            ada_campaign_key: t,
            ada_bot_handle: w(e.user_is_logged_in)
        })
    }

    function se(e, t) {
        I({
            interaction_name: D.CAMPAIGN_ENGAGED,
            customuser_id: e.user_id,
            account_id: e.current_account_id,
            ada_campaign_key: t,
            ada_bot_handle: w(e.user_is_logged_in)
        })
    }
    var I, ce = m(() => {
        "use strict";
        f();
        R();
        tt();
        I = (e = {}) => {
            var t, n, o;
            ee() || fetch(`${u}/api/v4/tracking/event/`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    subject: "web_analytics.tracking.product.InProductMessageInteractionEvent",
                    properties: p({
                        fully_qualified_domain_name: window.location.host,
                        path: window.location.pathname,
                        url_address: window.location.href,
                        visitor_id: (t = O("visitor_id")) != null ? t : null,
                        page_view_id: (n = U()) != null ? n : null,
                        session_id: (o = O("session_id")) != null ? o : null,
                        event_id: Q()
                    }, e)
                })
            })
        }
    });

    function kt(e) {
        var t;
        return (t = Ft[e]) != null ? t : e
    }

    function Ht(e) {
        let t = {
            url_path: e.pathname,
            user_state: e.user_is_logged_in ? "logged_in" : "logged_out"
        };
        return e.support_eligibility_plan_family && (t.plan = e.support_eligibility_plan_family), e.country && (t.country = e.country), e.hubspot_company_size && (t.company_size = e.hubspot_company_size), e.hubspot_enriched_company_size && (t.enriched_company_size = e.hubspot_enriched_company_size), e.hubspot_job_seniority && (t.job_seniority = kt(e.hubspot_job_seniority)), e.hubspot_role_form && (t.job_role = e.hubspot_role_form), e.created_at && (t.account_age_days = Math.floor((Date.now() / 1e3 - e.created_at) / 86400)), t
    }

    function Ut(e) {
        let t = new URLSearchParams;
        return Object.entries(e).forEach(([n, o]) => {
            o != null && o !== "" && t.set(n, String(o))
        }), t
    }

    function zt(e) {
        return d(this, null, function*() {
            var t;
            try {
                let n = `${u}/api/in-product-messaging/campaign-evaluate/?${Ut(e).toString()}`,
                    o = yield fetch(n, {
                        credentials: "include"
                    });
                if (!(o != null && o.ok)) return null;
                let i = yield o.json();
                return (t = i == null ? void 0 : i.campaign) != null ? t : null
            } catch (n) {
                return console.error("Error evaluating proactive campaign:", n), null
            }
        })
    }

    function rt(e, t) {
        fetch(`${u}/api/in-product-messaging/campaign-impression/`, {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                campaign_key: e,
                event: t,
                page_url: window.location.href
            })
        }).catch(n => {
            console.error("Error tracking campaign impression:", n)
        })
    }

    function Bt(e, t, n) {
        l = {
            campaignKey: e.campaign_key,
            messageKey: e.message_key,
            config: t,
            opened: n,
            engaged: !1
        }
    }

    function st(e, t) {
        Object.assign(e, t), Promise.resolve(window.adaEmbed.setMetaFields(t)).catch(() => {})
    }

    function le(e) {
        !l || l[e] || (l[e] = !0, rt(l.campaignKey, e), Wt[e](l.config, l.campaignKey), e === "opened" && st(l.config, {
            proactive_clicked: !0
        }))
    }

    function ct(e) {
        var n;
        if (!l) return !1;
        let t = (n = e == null ? void 0 : e.messageKey) != null ? n : e == null ? void 0 : e.campaignKey;
        return t ? t === l.messageKey || t === l.campaignKey : !0
    }

    function pe(e) {
        return !(e != null && e.campaignKey) || ct(e)
    }

    function Vt() {
        try {
            ["ada:minimize_chat", "ada:close_chat"].forEach(e => {
                window.adaEmbed.subscribeEvent(e, t => {
                    t != null && t.is_engaged && le("engaged")
                })
            }), Object.entries(jt).forEach(([e, t]) => {
                window.adaEmbed.subscribeEvent(e, n => {
                    ct(n) && le(t)
                })
            })
        } catch (e) {
            console.error("Error subscribing to Ada campaign events:", e)
        }
    }

    function Kt() {
        return d(this, null, function*() {
            try {
                let e = yield window.adaEmbed.getInfo();
                return !!(e != null && e.isDrawerOpen)
            } catch (e) {
                return !1
            }
        })
    }

    function Zt(e) {
        return d(this, null, function*() {
            let t = window.adaEmbed;
            if (!t) return !1;
            try {
                if (typeof t.triggerProactive == "function") yield t.triggerProactive({
                    messageKey: e.message_key,
                    params: {
                        message: e.message
                    }
                });
                else if (typeof t.triggerCampaign == "function") yield t.triggerCampaign(e.message_key);
                else return !1;
                return !0
            } catch (n) {
                return console.error("Error triggering proactive campaign in Ada:", n), !1
            }
        })
    }

    function qt() {
        try {
            if (document.getElementById(at)) return;
            let e = document.createElement("style");
            e.id = at, e.textContent = Xt, document.head.appendChild(e)
        } catch (e) {
            console.error("Error injecting Ada launcher z-index fix:", e)
        }
    }
    var Mt, de, it, Ft, l, Wt, jt, Yt, $t, Jt, Qt, dt, at, Xt, en, pt, lt, ut = m(() => {
        "use strict";
        R();
        ie();
        f();
        ce();
        Mt = e => {
            window.dispatchEvent(new CustomEvent(`${e?"zapier.onOpenAdaMessenger":"zapier.onCloseAdaMessenger"}`)), e && le("opened")
        }, de = e => e.pathname.includes(Me), it = () => T ? We : ze, Ft = {
            "VP / Exec": "VP/Executive",
            "VP/ Exec": "VP/Executive"
        };
        l = null, Wt = {
            opened: re,
            engaged: se
        };
        jt = {
            "ada:campaigns:opened": "opened",
            "ada:campaigns:engaged": "engaged"
        };
        Yt = e => d(void 0, null, function*() {
            let t = yield zt(Ht(e));
            if (!t) return;
            let n = yield Kt();
            if (Bt(t, e, n), !(yield Zt(t))) {
                l = null;
                return
            }
            st(e, {
                proactive_shown: !0
            }), rt(t.campaign_key, "shown"), ae(e, t.campaign_key)
        }), $t = () => {
            let e = _ ? "zapier-support-generative" : "zapier-support-generative-sandbox";
            setTimeout(() => {
                window.adaEmbed.stop(), window.adaEmbed.start(p({
                    handle: e
                }, window.adaSettings)), window.adaEmbed.toggle()
            }, 3e3)
        }, Jt = (e, t) => {
            let n = () => window.location.assign(P);
            if (!e.user_is_logged_in) {
                n();
                return
            }
            if (!t) {
                $t();
                return
            }
            setTimeout(() => {
                try {
                    window.adaEmbed.stop()
                } catch (o) {}
                et(e).catch(n)
            }, 3e3)
        }, Qt = (e, t) => {
            var n, o;
            e.proactive_shown = (n = e.proactive_shown) != null ? n : !1, e.proactive_clicked = (o = e.proactive_clicked) != null ? o : !1, window.adaSettings = p({
                metaFields: e,
                adaReadyCallback: () => {
                    window.dispatchEvent(new CustomEvent("zapier.onAdaEmbedLoaded")), de(e) && window.adaEmbed.reset({
                        greeting: it(),
                        metaFields: e
                    }), !S(e.user_is_logged_in) && !de(e) && (Vt(), Yt(e))
                },
                onAdaEmbedLoaded: () => {
                    window.adaEmbed.subscribeEvent("ada:campaigns:shown", i => {
                        pe(i) || ae(e, i.campaignKey)
                    }), window.adaEmbed.subscribeEvent("ada:campaigns:opened", i => {
                        pe(i) || re(e, i.campaignKey)
                    }), window.adaEmbed.subscribeEvent("ada:campaigns:engaged", i => {
                        pe(i) || se(e, i.campaignKey)
                    })
                },
                eventCallbacks: {
                    generativeHandoff: () => Jt(e, t)
                },
                toggleCallback: i => Mt(i)
            }, de(e) && {
                parentElement: "ada-frame",
                greeting: it()
            })
        }, dt = (e = 12) => {
            setTimeout(() => {
                try {
                    window.adaEmbed.stop()
                } catch (t) {
                    e > 0 && dt(e - 1)
                }
            }, 250)
        }, at = "zapier-ada-launcher-zindex-fix", Xt = "#ada-button-frame { z-index: 2147483647 !important; }";
        en = ({
            pathname: e,
            user_is_logged_in: t
        }) => {
            try {
                let n = document.createElement("script");
                n.id = "__ada", n.setAttribute("data-handle", w(t)), n.src = Se, n.async = !0, document.head.appendChild(n)
            } catch (n) {
                console.error("Error injecting Ada chatbot script:", n)
            }
            qt(), e.includes(P) && !t && dt()
        }, pt = (e, t) => d(void 0, null, function*() {
            Qt(e, t), (yield te(e)) && en(e)
        }), lt = e => {
            window.addEventListener("LinkClick.ContactForm.ChatWithSales", () => d(void 0, null, function*() {
                let t = p({
                    greeting: M,
                    handle: x
                }, window.adaSettings);
                try {
                    yield window.adaEmbed.reset({
                        greeting: M,
                        metaFields: e
                    }), (yield window.adaEmbed.getInfo()).isDrawerOpen || window.adaEmbed.toggle()
                } catch (n) {
                    yield window.adaEmbed.start(t), yield window.adaEmbed.reset({
                        greeting: M,
                        metaFields: e
                    }), window.adaEmbed.toggle()
                }
            }))
        }
    });

    function ue() {
        var e = window,
            t = e.Intercom;
        if (typeof t == "function") t("reattach_activator"), t("update", e.intercomSettings);
        else {
            var n = document,
                o = function() {
                    o.c(arguments)
                };
            o.q = [], o.c = function(a) {
                o.q.push(a)
            }, e.Intercom = o;
            var i = function() {
                var a = n.createElement("script");
                a.type = "text/javascript", a.async = !0, a.src = "https://widget.intercom.io/widget/" + v;
                var c = n.getElementsByTagName("script")[0];
                c.parentNode.insertBefore(a, c)
            };
            document.readyState === "complete" ? i() : e.attachEvent ? e.attachEvent("onload", i) : e.addEventListener("load", i, !1)
        }
    }
    var _t = m(() => {
        "use strict";
        f()
    });
    var sn = St(_e => {
        ut();
        ie();
        f();
        _t();
        J();
        ce();
        R();
        var L = "C0003",
            W = "C0004";

        function tn() {
            return d(this, null, function*() {
                let e = Je(),
                    t = Xe(),
                    n = Qe(),
                    o = E,
                    i = new URLSearchParams({
                        bust_cache: e,
                        sales_confirmation_page: t,
                        sales_page: n,
                        is_dev_platform_page: o
                    }),
                    a = `${u}/api/in-product-messaging/user/?${i.toString()}`,
                    c = yield fetch(a, {
                        credentials: "include"
                    }).catch();
                if (!(c != null && c.ok)) return {};
                let s = yield c.json().catch();
                return s != null ? s : {}
            })
        }

        function nn() {
            return new Promise(e => {
                let t = 0,
                    n = setInterval(() => {
                        let o, i = je("OptanonConsent"),
                            a = Ve(i);
                        window.OnetrustActiveGroups && window.OnetrustActiveGroups !== ",," ? o = {
                            functional: window.OnetrustActiveGroups.includes(L),
                            marketing: window.OnetrustActiveGroups.includes(W)
                        } : i && (o = {
                            functional: a.includes(L) || a.includes(W),
                            marketing: a.includes(W)
                        }), (o || t++ > 100) && (clearInterval(n), e(o != null ? o : {
                            functional: !1,
                            marketing: !1
                        }))
                    }, 250)
            })
        }

        function on(e) {
            let t = 0,
                n = setInterval(() => {
                    var o;
                    (o = window.OneTrust) != null && o.OnConsentChanged ? (window.OneTrust.OnConsentChanged(({
                        detail: i = []
                    }) => e(i)), clearInterval(n)) : t++ > 100 && clearInterval(n)
                }, 250)
        }

        function gt(e) {
            let t = q(e);
            window.Intercom && (window.Intercom("boot", t), window.zapierIntercom = {
                ready: window.Intercom.booted && !e.disabled,
                data: t,
                update(n) {
                    window.Intercom("update", p({
                        user_hash: e.user_hash
                    }, n)), window.zapierIntercom.data = p(p({}, window.zapierIntercom.data), n)
                }
            }, window.zapierIntercom.ready && window.dispatchEvent(new CustomEvent("zapier.intercomReady", t)))
        }

        function an(e, t) {
            let n = X(e);
            window.zapierAda = {
                config: n
            }, nt(), pt(n, t)
        }

        function mt(e, t) {
            window.zapierCopilotWidget = {
                config: t
            }, z(e, t)
        }

        function rn(e) {
            window.zapierFauxPilotWidget = {
                config: e
            }, z(Te, e)
        }

        function ft(e, t) {
            var i;
            let n = e.is_copilot_enabled !== !1;
            if (E) {
                e.user_is_logged_in && n && mt(Ie, e);
                return
            }
            let o = (i = t[F]) != null ? i : !1;
            if (o && n && oe(e)) {
                mt(G, e);
                return
            }
            if (!n && e.user_is_logged_in && oe(e)) {
                rn(e);
                return
            }
            an(e, o && n)
        }
        d(_e, null, function*() {
            var A, me;
            if ((A = window.zapierIntercom) != null && A.ready && (window.adaEmbed || window.zapierCopilotWidget || window.zapierFauxPilotWidget)) return;
            let [B, ...Et] = yield Promise.all([tn(), nn(), H()]), ge = B, {
                intercom_app_id: e = v,
                intercom_user_hash: t,
                is_masquerade: n
            } = ge, o = be(ge, ["intercom_app_id", "intercom_user_hash", "is_masquerade"]), [i, a] = Et;
            if (n || (me = o.email) != null && me.endsWith("@zapier.rodeo")) return;
            let c = o.user_is_logged_in || i.functional ? yield ne(): b, s = !1;
            o.user_is_logged_in && (s = Ze(o.created_at, o.support_eligibility_plan_family, o.hubspot_qualified_signup_score, o.hubspot_job_seniority, o.huspot_company_size, o.hubspot_enriched_company_size));
            let r = C(p(p({
                    app_id: e,
                    user_hash: t,
                    user_is_logged_in: !1,
                    user_has_signed_up: !1,
                    functional_cookies_enabled: i.functional,
                    marketing_consent: i.marketing,
                    page_view_id: U(),
                    pathname: window.location.pathname,
                    session_id: O("session_id"),
                    url_address: window.location.href,
                    visitor_id: O("visitor_id"),
                    disabled: !o.user_is_logged_in && !i.functional,
                    support_to_sales_suppressed: s
                }, o), c), {
                    highest_account_arr_bucket: Ke(o.highest_account_mrr)
                }),
                g = new URLSearchParams(window.location.search);
            if (!r.user_id && g.has("intercom_anonymous_id")) {
                let h = g.get("intercom_anonymous_id");
                r.anonymous_id = h, document.cookie = `intercom-id-${r.app_id}=${h};domain=${window.location.hostname};path=/;samesite=lax`
            }
            on(h => d(_e, null, function*() {
                var Ee;
                r.functional_cookies_enabled = h.includes(L), r.marketing_consent = h.includes(W), r.disabled = !r.user_is_logged_in && !h.includes(L), !r.country && (r.user_is_logged_in || r.functional_cookies_enabled) && Object.assign(r, yield ne());
                let fe = X(r),
                    wt = q(r);
                (Ee = window.zapierIntercom) != null && Ee.ready ? window.Intercom("update", wt) : (h.includes(L) && (window.intercomSettings = {
                    app_id: r.app_id
                }, ue()), gt(r)), window.zapierCopilotWidget ? window.zapierCopilotWidget.config = r : window.zapierFauxPilotWidget ? window.zapierFauxPilotWidget.config = r : window.adaEmbed ? (window.adaEmbed.setMetaFields(fe), window.zapierAda = {
                    config: fe
                }) : ft(r, a)
            })), ot(r), lt(r), qe(r), i.functional && (window.intercomSettings = {
                app_id: e
            }, ue()), gt(r), ft(r, a)
        })
    });
    sn();
})();