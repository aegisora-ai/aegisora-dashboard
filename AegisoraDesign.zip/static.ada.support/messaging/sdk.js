// Preprod CDN, used only when this bootstrap's own origin can't be resolved.
const FALLBACK_CDN_BASE_URL = "https://messaging-assets.ada-dev2.support/";

// Resolve the CDN root from where this bootstrap is served, so one sdk.js works
// at every root: messaging-assets.ada-dev2.support/, messaging-assets.ada.support/,
// and static.ada.support/messaging/. Exported for unit testing.
export function resolveCdnBaseUrl(metaUrl) {
    try {
        const base = new URL(".", metaUrl);
        if (base.protocol === "https:" || base.protocol === "http:") {
            return base.toString();
        }
    } catch {
        // Fall through to the preprod default.
    }
    return FALLBACK_CDN_BASE_URL;
}

// Build the versioned SDK entry URL relative to a resolved CDN base. Exported
// for unit testing.
export function buildVersionedModuleUrl(baseUrl, version) {
    return new URL(`${version}/sdk/index.js`, baseUrl).toString();
}

const CDN_BASE_URL = resolveCdnBaseUrl(
    import.meta.url);
const MANIFEST_URL = new URL(
    "messaging-manifest.json",
    CDN_BASE_URL,
).toString();
const STABLE_VERSION_URL = new URL(
    "messaging-stable-version.txt",
    CDN_BASE_URL,
).toString();
const STORAGE_PREFIX = "ada-messaging-sdk-rollout";
const VERSION_SHA_PATTERN = /^[0-9a-f]{7,40}$/i;
const MANIFEST_FETCH_TIMEOUT_MS = 5000;

// Host-page query param that pins a specific deployed version, bypassing the
// rollout manifest — e.g. `https://customer.example/?ada-messaging-version=pr-123`
// to preview a PR build, or `…?ada-messaging-version=<git-sha>` for a specific
// main build. The value is interpolated into a CDN path (`<base>/<version>/sdk/…`),
// so the pattern is intentionally strict — a git SHA (main builds) or `pr-<N>`
// (PR previews) ONLY. No `:`, `/`, or `.` is allowed, so the override can never
// resolve to anything but a path on the same trusted CDN host (no
// arbitrary-script injection / path traversal).
const VERSION_OVERRIDE_PARAM = "ada-messaging-version";
const VERSION_OVERRIDE_PATTERN = /^(?:[0-9a-f]{7,40}|pr-\d+)$/i;

function safeConsole(level, ...args) {
    try {
        console[level](...args);
    } catch {
        // A host may replace console methods. Diagnostics must not change resolution.
    }
}

// DevSpace provisions one bot per PR at `devspace-pr-<N>.…ada-dev2.support`
// (the `devspace-pr-<N>` namespace). On those hosts we optimistically try the
// matching preprod PR build (`pr-<N>`) so reviewers automatically exercise the
// branch's SDK without pinning `?ada-messaging-version` by hand.
const DEVSPACE_PR_HOST_PATTERN = /^devspace-pr-(\d+)\./;
const DEVSPACE_PR_HOST_SUFFIX = ".ada-dev2.support";

function clampRollout(value) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) {
        return 0;
    }
    if (parsed < 0) {
        return 0;
    }
    if (parsed > 1) {
        return 1;
    }
    return parsed;
}

function getStorage() {
    try {
        if (typeof window !== "undefined" && window.localStorage) {
            return window.localStorage;
        }
    } catch {
        // Ignore localStorage access failures and fall back to in-memory behavior.
    }
    return null;
}

function safeStorageGet(storage, key) {
    if (!storage) {
        return null;
    }
    try {
        return storage.getItem(key);
    } catch {
        return null;
    }
}

function safeStorageSet(storage, key, value) {
    if (!storage) {
        return;
    }
    try {
        storage.setItem(key, value);
    } catch {
        // Ignore storage write failures so SDK loading never depends on storage.
    }
}

function getDomainKey() {
    try {
        if (typeof window !== "undefined" && window.location ? .hostname) {
            return window.location.hostname.toLowerCase();
        }
    } catch {
        // Ignore window access failures and use fallback below.
    }
    return "unknown-domain";
}

function getStorageKeys(domain) {
    return {
        random: `${STORAGE_PREFIX}:${domain}:random`,
        version: `${STORAGE_PREFIX}:${domain}:version`,
    };
}

function isValidVersionSha(version) {
    return (
        typeof version === "string" && VERSION_SHA_PATTERN.test(version.trim())
    );
}

function parseManifest(input) {
    if (!input || typeof input !== "object" || Array.isArray(input)) {
        return null;
    }

    const stableVersionRaw = input ? .stable ? .version;
    if (!isValidVersionSha(stableVersionRaw)) {
        return null;
    }

    const manifest = {
        stable: {
            version: stableVersionRaw.trim().toLowerCase(),
        },
    };

    const canaryVersionRaw = input ? .canary ? .version;
    if (isValidVersionSha(canaryVersionRaw)) {
        manifest.canary = {
            version: canaryVersionRaw.trim().toLowerCase(),
            rollout: clampRollout(input ? .canary ? .rollout),
        };
    }

    return manifest;
}

function resolveVersionForRandom(manifest, randomValue) {
    const stableVersion = manifest ? .stable ? .version;
    if (!stableVersion) {
        throw new Error("Manifest is missing stable.version.");
    }

    const canaryVersion = manifest ? .canary ? .version;
    const rollout = clampRollout(manifest ? .canary ? .rollout);
    if (canaryVersion && randomValue < rollout) {
        return canaryVersion;
    }

    return stableVersion;
}

function readStoredAssignment(storage, keys) {
    if (!storage) {
        return null;
    }

    const randomRaw = safeStorageGet(storage, keys.random);
    if (!randomRaw) {
        return null;
    }

    const randomValue = Number(randomRaw);
    if (!Number.isFinite(randomValue) || randomValue < 0 || randomValue >= 1) {
        return null;
    }

    return {
        randomValue,
    };
}

function writeStoredAssignment(storage, keys, assignment) {
    if (!storage) {
        return;
    }
    safeStorageSet(storage, keys.random, String(assignment.randomValue));
    // The version is diagnostic write-back; selection only reads the random draw.
    safeStorageSet(storage, keys.version, assignment.version);
}

function selectAssignment(manifest, storage, keys) {
    const stored = readStoredAssignment(storage, keys);
    const randomValue = stored ? .randomValue ? ? Math.random();
    return {
        randomValue,
        version: resolveVersionForRandom(manifest, randomValue),
    };
}

async function fetchManifest() {
    const controller =
        typeof AbortController === "function" ? new AbortController() : null;
    const timeoutId = setTimeout(() => {
        controller ? .abort();
    }, MANIFEST_FETCH_TIMEOUT_MS);

    try {
        const response = await fetch(MANIFEST_URL, {
            cache: "no-store",
            signal: controller ? .signal,
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        return response.json();
    } finally {
        clearTimeout(timeoutId);
    }
}

async function loadVersionedModule(importModule) {
    const manifestRaw = await fetchManifest();
    const manifest = parseManifest(manifestRaw);
    if (!manifest) {
        throw new Error("Manifest has invalid structure.");
    }

    const storage = getStorage();
    const domain = getDomainKey();
    const keys = getStorageKeys(domain);
    const assignment = selectAssignment(manifest, storage, keys);
    writeStoredAssignment(storage, keys, assignment);

    const sdkUrl = buildVersionedModuleUrl(CDN_BASE_URL, assignment.version);
    return importModule(sdkUrl);
}

// Fallback when the manifest can't be loaded/parsed: read the published stable
// SHA and import that version. (There is no unversioned sdk/index.js on the CDN
// — assets only live under a <sha>/ prefix — so the fallback must resolve a SHA.)
async function loadStableModule(importModule) {
    const response = await fetch(STABLE_VERSION_URL, {
        cache: "no-store"
    });
    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }
    const sha = (await response.text()).trim().toLowerCase();
    if (!isValidVersionSha(sha)) {
        throw new Error("Stable version file did not contain a valid SHA.");
    }
    return importModule(buildVersionedModuleUrl(CDN_BASE_URL, sha));
}

// Read the pinned-version override from a location.search string. Returns the
// validated version (a git SHA or `pr-<N>`), or null when absent/invalid.
// Exported for unit testing. Strict validation is a security boundary — see
// VERSION_OVERRIDE_PATTERN — so a malformed or hostile value is ignored (the
// normal rollout flow runs) rather than interpolated into the import URL.
export function parseVersionOverride(search) {
    try {
        const raw = new URLSearchParams(search ? ? "").get(VERSION_OVERRIDE_PARAM);
        if (!raw) {
            return null;
        }
        const version = raw.trim().toLowerCase();
        return VERSION_OVERRIDE_PATTERN.test(version) ? version : null;
    } catch {
        return null;
    }
}

// Derive the optimistic preprod PR version from a DevSpace host. Returns the
// validated `pr-<N>` version on a `devspace-pr-<N>.….ada-dev2.support` host, or
// null otherwise. Exported for unit testing. The extracted number is run back
// through VERSION_OVERRIDE_PATTERN so only a strict `pr-<N>` is ever returned —
// the same path-injection security boundary as parseVersionOverride.
export function parsePreprodPrVersion(hostname) {
    if (typeof hostname !== "string") {
        return null;
    }
    const host = hostname.trim().toLowerCase();
    if (!host.endsWith(DEVSPACE_PR_HOST_SUFFIX)) {
        return null;
    }
    const match = DEVSPACE_PR_HOST_PATTERN.exec(host);
    if (!match) {
        return null;
    }
    const version = `pr-${match[1]}`;
    return VERSION_OVERRIDE_PATTERN.test(version) ? version : null;
}

// Resolve and import the SDK module for a given host context. The version
// resolution order is: (1) explicit `?ada-messaging-version` pin, (2) optimistic
// DevSpace preprod PR build, (3) rollout manifest, (4) stable fallback.
// `importModule` is the dynamic-import seam (defaults to native `import`) — it's
// injectable so this whole sequence can be unit-tested without resolving real
// `https:` CDN specifiers through the ESM loader. Exported for unit testing.
export async function resolveSdkModule({
    hostname,
    search,
    importModule = (url) =>
    import (url),
}) {
    const overrideVersion = parseVersionOverride(search);

    // Optimistic DevSpace preprod path: on a `devspace-pr-<N>.…ada-dev2.support`
    // host, try the matching `pr-<N>` build from the dev2 assets CDN first. If
    // that build isn't published yet (404 / parse error / any failure) we fall
    // through silently to the normal resolution below — production hosts never
    // match this branch. An explicit `?ada-messaging-version` pin takes
    // precedence over the optimistic host match.
    const preprodPrVersion = overrideVersion ?
        null :
        parsePreprodPrVersion(hostname);
    if (preprodPrVersion) {
        try {
            return await importModule(
                buildVersionedModuleUrl(FALLBACK_CDN_BASE_URL, preprodPrVersion),
            );
        } catch {
            // Preprod PR build not available — fall through to normal resolution.
        }
    }

    try {
        if (overrideVersion) {
            // Pinned version (e.g. ?ada-messaging-version=pr-123) — bypass the rollout
            // manifest entirely and load that exact build from the same CDN.
            safeConsole(
                "info",
                `[AdaMessaging] Loading pinned version override: ${overrideVersion}`,
            );
            return await importModule(
                buildVersionedModuleUrl(CDN_BASE_URL, overrideVersion),
            );
        }
        return await loadVersionedModule(importModule);
    } catch (error) {
        safeConsole(
            "warn",
            overrideVersion ?
            `[AdaMessaging] Pinned version "${overrideVersion}" failed to load; falling back to the stable version.` :
            "[AdaMessaging] Manifest resolution failed; falling back to the stable version.",
            error,
        );
        return loadStableModule(importModule);
    }
}

// One page can carry two copies of this bootstrap — a tag-manager tag plus a
// hard-coded one, or embed-loader importing static.ada.support/messaging/sdk.js
// while the host imports messaging-assets.ada.support/sdk.js. Those are distinct
// module specifiers, so the ESM loader instantiates two independent copies that
// cannot see each other's module scope; this host-page global is the only
// rendezvous between them. It is deliberately NOT embed-loader's
// `__AdaEmbedLoaderScriptLoaded`, which guards a second *loader* — sharing that
// key would make the loader's own first import of this file look like a
// duplicate and leave the page with no widget at all.
const SDK_BOOTSTRAP_GLOBAL = "__AdaMessagingSdkBootstrap";

// Share pending and successful resolution across bootstrap copies so the page
// mounts only one SDK. `globalScope` is the shared rendezvous object
// (the host page's `window`) and `resolve` is the resolution seam; both are
// parameters so this is unit-testable. Exported for unit testing.
//
// The global holds the in-flight *promise*, not a boolean and not the settled
// module. Evaluation of the second copy typically begins while the first is
// still suspended on its own top-level await, so a value published only after
// resolution would not be there yet and the page would mount twice. A bare
// boolean is worse: the second copy would skip resolution and export
// `undefined` for every symbol, breaking `import { AdaMessagingClient }` from
// that URL.
export async function bootstrapSdkModule(
    globalScope,
    resolve = resolveSdkModule,
) {
    if (!globalScope) {
        return resolve({
            hostname: undefined,
            search: undefined
        });
    }

    const inFlight = globalScope[SDK_BOOTSTRAP_GLOBAL];
    if (inFlight) {
        safeConsole(
            "warn",
            "[AdaMessaging] The Ada Messaging SDK script is included more than once; reusing the copy that loaded first.",
        );
        return inFlight;
    }

    // Publish before the first await so a concurrently-evaluating copy sees it.
    const pending = resolve({
        hostname: globalScope.location ? .hostname,
        search: globalScope.location ? .search,
    });
    globalScope[SDK_BOOTSTRAP_GLOBAL] = pending;
    pending.catch(() => {
        if (globalScope[SDK_BOOTSTRAP_GLOBAL] === pending) {
            delete globalScope[SDK_BOOTSTRAP_GLOBAL];
        }
    });
    return pending;
}

let sdkModule;
// Browser bootstrap only. Skipped under Node (e.g. unit tests) so importing this
// module exercises the exported pure helpers without performing the manifest
// fetch / dynamic import. Guard on the Node-specific `process.versions.node`
// rather than a bare `process` global: customer pages (and browser extensions)
// commonly define a `process` polyfill, and treating that as "Node" would skip
// the bootstrap and leave `AdaMessagingClient` undefined on the host page.
const isNodeRuntime =
    typeof process !== "undefined" && Boolean(process.versions ? .node);
if (!isNodeRuntime) {
    sdkModule = await bootstrapSdkModule(
        typeof window !== "undefined" ? window : undefined,
    );
}

export const AdaMessagingClient = sdkModule ? .AdaMessagingClient;
export const FrameChannel = sdkModule ? .FrameChannel;
export const FrameChild = sdkModule ? .FrameChild;
export const createAdaEmbedInterface = sdkModule ? .createAdaEmbedInterface;
export const dispatchEmbedLoaderInitialActionQueue =
    sdkModule ? .dispatchEmbedLoaderInitialActionQueue;
export const dispatchEmbedLoaderInitialActionQueueForAtomicHandoff =
    sdkModule ? .dispatchEmbedLoaderInitialActionQueueForAtomicHandoff;
export const mountAdaWebViewRuntime = sdkModule ? .mountAdaWebViewRuntime;
export const resolveAdaWebViewRuntimeAssets =
    sdkModule ? .resolveAdaWebViewRuntimeAssets;
export default sdkModule;