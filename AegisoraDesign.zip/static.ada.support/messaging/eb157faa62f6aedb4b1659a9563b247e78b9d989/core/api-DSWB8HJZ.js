import {
    n as e
} from "./chunk-DeC0fbbY.js";
import {
    $ as t,
    B as n,
    Cn as r,
    Ct as i,
    Dn as a,
    Dt as o,
    En as s,
    Et as c,
    F as l,
    Ft as u,
    G as d,
    H as f,
    Ht as p,
    I as m,
    It as h,
    J as g,
    Jt as _,
    Kt as v,
    L as y,
    Lt as b,
    M as x,
    Mt as S,
    N as C,
    Nt as w,
    On as T,
    Ot as ee,
    P as E,
    Pt as D,
    Q as te,
    Qt as ne,
    R as re,
    Rt as ie,
    Sn as ae,
    St as O,
    T as oe,
    Tn as k,
    Tt as se,
    U as ce,
    Ut as le,
    V as ue,
    W as de,
    Wt as fe,
    X as pe,
    Xt as me,
    Y as he,
    Yt as ge,
    Z as _e,
    Zt as ve,
    _n as ye,
    _t as be,
    at as xe,
    bn as Se,
    bt as Ce,
    cn as we,
    ct as Te,
    dn as Ee,
    dt as De,
    en as Oe,
    fn as ke,
    ft as Ae,
    gn as je,
    gt as Me,
    in as Ne,
    it as Pe,
    j as Fe,
    jt as Ie,
    k as Le,
    kn as Re,
    kt as ze,
    lt as Be,
    mn as Ve,
    mt as He,
    n as Ue,
    nt as We,
    on as Ge,
    ot as Ke,
    pn as qe,
    pt as Je,
    q as Ye,
    r as Xe,
    rn as Ze,
    rt as Qe,
    st as $e,
    tt as et,
    ut as tt,
    vn as nt,
    vt as rt,
    wn as it,
    wt as at,
    xn as ot,
    xt as st,
    yn as ct,
    yt as lt,
    z as ut,
    zt as dt
} from "./esm-4T8k2PPA.js";
import {
    i as ft
} from "./replayStats-BN_uKRUf.js";
//#region ../../node_modules/@datadog/browser-logs/esm/domain/logger/isAuthorized.js
function pt(e, t, n) {
    let r = n.getHandler(),
        i = Array.isArray(r) ? r : [r];
    return mt[e] >= mt[n.getLevel()] && i.includes(t);
}
var A = {
        ok: "ok",
        debug: "debug",
        info: "info",
        notice: "notice",
        warn: "warn",
        error: "error",
        critical: "critical",
        alert: "alert",
        emerg: "emerg"
    },
    mt = {
        [A.ok]: 0,
        [A.debug]: 1,
        [A.info]: 2,
        [A.notice]: 4,
        [A.warn]: 5,
        [A.error]: 6,
        [A.critical]: 7,
        [A.alert]: 8,
        [A.emerg]: 9
    };
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/createErrorFieldFromRawError.js
function ht(e, {
    includeMessage: t = !1
} = {}) {
    return {
        stack: e.stack,
        kind: e.type,
        message: t ? e.message : void 0,
        causes: e.causes,
        fingerprint: e.fingerprint,
        handling: e.handling
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/logger.js
var gt = function(e, t, n, r) {
        var i = arguments.length,
            a = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, n) : r,
            o;
        if (typeof Reflect == "object" && typeof Reflect.decorate == "function") a = Reflect.decorate(e, t, n, r);
        else
            for (var s = e.length - 1; s >= 0; s--)(o = e[s]) && (a = (i < 3 ? o(a) : i > 3 ? o(t, n, a) : o(t, n)) || a);
        return i > 3 && a && Object.defineProperty(t, n, a), a;
    },
    _t = {
        console: "console",
        http: "http",
        silent: "silent"
    },
    vt = Object.keys(A),
    yt = class {
        constructor(e, t, n = _t.http, r = A.debug, i = {}) {
            this.handleLogStrategy = e, this.handlerType = n, this.level = r, this.contextManager = ce("logger"), this.tags = [], this.contextManager.setContext(i), t && this.contextManager.setContextProperty("logger", {
                name: t
            });
        }
        logImplementation(e, t, n = A.info, r, i) {
            let a = b(t),
                o;
            if (r != null) {
                let e = u({
                    originalError: r,
                    nonErrorPrefix: "Provided",
                    source: D.LOGGER,
                    handling: "handled",
                    startClocks: we()
                });
                o = st({
                    error: ht(e, {
                        includeMessage: !0
                    })
                }, e.context, a);
            } else o = a;
            this.handleLogStrategy({
                message: b(e),
                context: o,
                status: n
            }, this, i);
        }
        log(e, t, n = A.info, r) {
            let i;
            pt(n, _t.http, this) && (i = p("log")), this.logImplementation(e, t, n, r, i);
        }
        setContext(e) {
            this.contextManager.setContext(e);
        }
        getContext() {
            return this.contextManager.getContext();
        }
        setContextProperty(e, t) {
            this.contextManager.setContextProperty(e, t);
        }
        removeContextProperty(e) {
            this.contextManager.removeContextProperty(e);
        }
        clearContext() {
            this.contextManager.clearContext();
        }
        addTag(e, t) {
            this.tags.push(at(e, t));
        }
        removeTagsWithKey(e) {
            let t = c(e);
            this.tags = this.tags.filter((e) => e !== t && !e.startsWith(`${t}:`));
        }
        getTags() {
            return this.tags.slice();
        }
        setHandler(e) {
            this.handlerType = e;
        }
        getHandler() {
            return this.handlerType;
        }
        setLevel(e) {
            this.level = e;
        }
        getLevel() {
            return this.level;
        }
    };
gt([Se], yt.prototype, "logImplementation", null), yt.prototype.ok = bt(A.ok), yt.prototype.debug = bt(A.debug), yt.prototype.info = bt(A.info), yt.prototype.notice = bt(A.notice), yt.prototype.warn = bt(A.warn), yt.prototype.error = bt(A.error), yt.prototype.critical = bt(A.critical), yt.prototype.alert = bt(A.alert), yt.prototype.emerg = bt(A.emerg);

function bt(e) {
    return function(t, n, r) {
        let i;
        pt(e, _t.http, this) && (i = p("log")), this.logImplementation(t, n, e, r, i);
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/contexts/commonContext.js
function xt() {
    return r ? {} : {
        view: {
            referrer: document.referrer,
            url: window.location.href
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/logsSessionManager.js
var St = "logs";

function Ct(e, t) {
    let n = te(e, St, (t) => Tt(e, t), t);
    return {
        findTrackedSession: (e, t = {
            returnInactive: !1
        }) => {
            let r = n.findSession(e, t);
            return r && r.trackingType === "1" ? {
                id: r.id,
                anonymousId: r.anonymousId
            } : void 0;
        },
        expireObservable: n.expireObservable
    };
}

function wt(e) {
    let t = Tt(e) === "1" ? {} : void 0;
    return {
        findTrackedSession: () => t,
        expireObservable: new Ve()
    };
}

function Tt(e, t) {
    return Et(t) ? t : it(e.sessionSampleRate) ? "1" : "0";
}

function Et(e) {
    return e === "0" || e === "1";
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/assembly.js
function Dt(e, t, n, r, i, a) {
    let o = vt.concat(["custom"]),
        s = {};
    o.forEach((e) => {
        s[e] = pe(e, i, a);
    }), t.subscribe(0, ({
        rawLogsEvent: i,
        messageContext: a = void 0,
        savedCommonContext: o = void 0,
        domainContext: c,
        ddtags: l = []
    }) => {
        let u = ke(i.date),
            d = o || r(),
            f = n.triggerHook(0, {
                startTime: u
            });
        if (f === "DISCARDED") return;
        let p = se(e),
            m = st({
                view: d.view
            }, f, i, a, {
                ddtags: p.concat(l).join(",")
            });
        e.beforeSend ? .call(e, m, c) === !1 || m.origin !== D.AGENT && (s[m.status] ? ? s.custom).isLimitReached() || t.notify(1, m);
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/console/consoleCollection.js
var Ot = {
    [k.log]: A.info,
    [k.debug]: A.debug,
    [k.info]: A.info,
    [k.warn]: A.warn,
    [k.error]: A.error
};

function kt(e, t) {
    let n = d(e.forwardConsoleLogs).subscribe((e) => {
        let n = {
            rawLogsEvent: {
                date: qe(),
                message: e.message,
                origin: D.CONSOLE,
                error: e.error && ht(e.error),
                status: Ot[e.api]
            },
            messageContext: e.error ? .context,
            domainContext: {
                handlingStack: e.handlingStack
            }
        };
        t.notify(0, n);
    });
    return {
        stop: () => {
            n.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/report/reportCollection.js
function At(e, t) {
    let n = ee(e, e.forwardReports).subscribe((e) => {
        let n = e.message,
            r, i = e.originalError.type === "deprecation" ? A.warn : A.error;
        i === A.error ? r = ht(e) : e.stack && (n += ` Found in ${h(e.stack)}`), t.notify(0, {
            rawLogsEvent: {
                date: qe(),
                message: n,
                origin: D.REPORT,
                error: r,
                status: i
            }
        });
    });
    return {
        stop: () => {
            n.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/networkError/networkErrorCollection.js
function jt(e, t) {
    if (!e.forwardErrorsToLogs) return {
        stop: Ne
    };
    let n = (r ? new Ve() : g(e)).subscribe((e) => {
            e.state === "complete" && o(x.XHR, e);
        }),
        i = Ye({
            responseBodyAction: (e) => a(e) ? 2 : 0
        }).subscribe((e) => {
            e.state === "resolve" && o(x.FETCH, e);
        });

    function a(e) {
        return !me(e.url) && (Mt(e) || Ce(e.status));
    }

    function o(n, r) {
        if (!a(r)) return;
        let i = "error" in r && r.error ? le(fe(r.error)) : r.responseBody || "Failed to load",
            o = {
                isAborted: r.isAborted,
                handlingStack: r.handlingStack
            };
        t.notify(0, {
            rawLogsEvent: {
                message: `${Nt(n)} error ${r.method} ${r.url}`,
                date: r.startClocks.timeStamp,
                error: {
                    stack: Ze(i, e.requestErrorResponseLengthLimit, "..."),
                    handling: void 0
                },
                http: {
                    method: r.method,
                    status_code: r.status,
                    url: r.url
                },
                status: A.error,
                origin: D.NETWORK
            },
            domainContext: o
        });
    }
    return {
        stop: () => {
            n.unsubscribe(), i.unsubscribe();
        }
    };
}

function Mt(e) {
    return e.status === 0 && e.responseType !== "opaque";
}

function Nt(e) {
    return x.XHR === e ? "XHR" : "Fetch";
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/runtimeError/runtimeErrorCollection.js
function Pt(e, t, n) {
    if (!e.forwardErrorsToLogs) return {
        stop: Ne
    };
    let r = n.subscribe((e) => {
        if (e.type === 0) {
            let n = e.error;
            t.notify(0, {
                rawLogsEvent: {
                    message: n.message,
                    date: n.startClocks.timeStamp,
                    error: ht(n),
                    origin: D.SOURCE,
                    status: A.error
                },
                messageContext: n.context
            });
        }
    });
    return {
        stop: () => {
            r.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/lifeCycle.js
var Ft = _e;
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/logger/loggerCollection.js
function It(e) {
    function t(t, n, r, i, a) {
        let o = st(n.getContext(), t.context);
        if (pt(t.status, _t.console, n) && Rt(t, o), pt(t.status, _t.http, n)) {
            let s = {
                rawLogsEvent: {
                    date: a || qe(),
                    message: t.message,
                    status: t.status,
                    origin: D.LOGGER
                },
                messageContext: o,
                savedCommonContext: i,
                ddtags: n.getTags()
            };
            r && (s.domainContext = {
                handlingStack: r
            }), e.notify(0, s);
        }
    }
    return {
        handleLog: t
    };
}
var Lt = {
    [A.ok]: k.debug,
    [A.debug]: k.debug,
    [A.info]: k.info,
    [A.notice]: k.info,
    [A.warn]: k.warn,
    [A.error]: k.error,
    [A.critical]: k.error,
    [A.alert]: k.error,
    [A.emerg]: k.error
};

function Rt({
    status: e,
    message: t
}, n) {
    Re[Lt[e]].call(T, t, n);
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/transport/startLogsBatch.js
function zt(e, t, n, r, i) {
    let a = [e.logsEndpointBuilder];
    e.replica && a.push(e.replica.logsEndpointBuilder);
    let o = Je({
        encoder: De(),
        request: lt(a, n),
        flushController: Ae({
            pageMayExitObservable: r,
            sessionExpireObservable: i.expireObservable
        })
    });
    return t.subscribe(1, (e) => {
        o.add(e);
    }), o;
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/transport/startLogsBridge.js
function Bt(e) {
    let t = rt();
    e.subscribe(1, (e) => {
        t.send("log", e);
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/contexts/internalContext.js
function Vt(e) {
    return {
        get: (t) => {
            let n = e.findTrackedSession(t);
            if (n) return {
                session_id: n.id
            };
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/reportError.js
function Ht(e) {
    return (t) => {
        e.notify(0, {
            rawLogsEvent: {
                message: t.message,
                date: t.startClocks.timeStamp,
                origin: D.AGENT,
                status: A.error
            }
        }), Qe("Error reported to customer", {
            "error.message": t.message
        });
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/contexts/rumInternalContext.js
function Ut(e) {
    let n = ae;
    e.register(0, ({
        startTime: e
    }) => r(e) || Be), e.register(1, ({
        startTime: e
    }) => {
        let t = r(e);
        return t ? {
            application: {
                id: t.application_id
            },
            view: {
                id: t.view ? .id
            },
            action: {
                id: t.user_action ? .id
            }
        } : Be;
    });

    function r(e) {
        let r = i(e, t() ? n.DD_RUM_SYNTHETICS : n.DD_RUM);
        if (r) return r;
    }

    function i(e, t) {
        if (t && t.getInternalContext) return t.getInternalContext(e);
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/contexts/sessionContext.js
function Wt(e, t, n) {
    e.register(0, ({
        startTime: e
    }) => {
        let r = n.findTrackedSession(e);
        return n.findTrackedSession(e, {
            returnInactive: !0
        }) ? {
            service: t.service,
            session_id: r ? r.id : void 0,
            session: r ? {
                id: r.id
            } : void 0
        } : Te;
    }), e.register(1, ({
        startTime: e
    }) => {
        let t = n.findTrackedSession(e);
        return !t || !t.id ? Be : {
            session: {
                id: t.id
            }
        };
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/contexts/trackingConsentContext.js
function Gt(e, t) {
    function n() {
        return t.isGranted() ? Be : Te;
    }
    e.register(0, n), e.register(1, n);
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/boot/startLogs.js
var Kt = "logs";

function qt(e, r, a, o, s) {
    let c = new Ft(),
        l = [];
    c.subscribe(1, (e) => i("logs", e));
    let u = Ht(c),
        d = He(e),
        f = e.sessionStoreStrategyType && !be() && !t() ? Ct(e, a) : wt(e);
    Gt(s, a), Wt(s, e, f);
    let p = n(s, e, Kt),
        h = m(s, e, f, Kt),
        g = re(s, e, Kt, !1);
    Ut(s), jt(e, c), Pt(e, c, o), o.unbuffer(), kt(e, c), At(e, c);
    let {
        handleLog: _
    } = It(c);
    if (Dt(e, c, s, r, u), be()) Bt(c);
    else {
        let {
            stop: t
        } = zt(e, c, u, d, f);
        l.push(() => t());
    }
    return {
        handleLog: _,
        getInternalContext: Vt(f).get,
        accountContext: p,
        globalContext: g,
        userContext: h,
        stop: () => {
            l.forEach((e) => e());
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/domain/hooks.js
var Jt = tt,
    Yt = 32 * ie;

function Xt(e, t) {
    e.usePciIntake === !0 && e.site && e.site !== "datadoghq.com" && a.warn("PCI compliance for Logs is only available for Datadog organizations in the US1 site. Default intake will be used.");
    let n = ge(e, t),
        r = Zt(e.forwardConsoleLogs, Oe(k), "Forward Console Logs"),
        i = Zt(e.forwardReports, Oe(o), "Forward Reports");
    if (!(!n || !r || !i)) return e.forwardErrorsToLogs && !r.includes(k.error) && r.push(k.error), {
        forwardErrorsToLogs: e.forwardErrorsToLogs !== !1,
        forwardConsoleLogs: r,
        forwardReports: i,
        requestErrorResponseLengthLimit: Yt,
        ...n
    };
}

function Zt(e, t, n) {
    if (e === void 0) return [];
    if (!(e === "all" || Array.isArray(e) && e.every((e) => t.includes(e)))) {
        a.error(`${n} should be "all" or an array with allowed values "${t.join("\", \"")}"`);
        return;
    }
    return e === "all" ? t : et(e);
}

function Qt(e) {
    let t = _(e);
    return {
        forward_errors_to_logs: e.forwardErrorsToLogs,
        forward_console_logs: e.forwardConsoleLogs,
        forward_reports: e.forwardReports,
        use_pci_intake: e.usePciIntake,
        ...t
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/boot/preStartLogs.js
function $t(e, t, n) {
    let r = de(),
        i = y();
    ue(i, E.globalContext, r);
    let o = ut();
    ue(o, E.accountContext, r);
    let s = l();
    ue(s, E.userContext, r);
    let c, u, d = Jt(),
        f = t.observable.subscribe(p);

    function p() {
        if (!u || !c || !t.isGranted()) return;
        ve($e)("browser-logs-sdk", u, d), f.unsubscribe();
        let e = n(c, u, d);
        r.drain(e);
    }
    return {
        init(e, n) {
            if (!e) {
                a.error("Missing configuration");
                return;
            }
            if (v(e.enableExperimentalFeatures), be() && (e = en(e)), c = e, We(Qt(e)), u) {
                Ie("DD_LOGS", e);
                return;
            }
            let r = Xt(e, n);
            r && (u = r, Ye().subscribe(Ne), t.tryToInit(r.trackingConsent), p());
        },
        get initConfiguration() {
            return c;
        },
        globalContext: i,
        accountContext: o,
        userContext: s,
        getInternalContext: Ne,
        handleLog(t, n, i, a = e(), o = qe()) {
            r.add((e) => e.handleLog(t, n, i, a, o));
        }
    };
}

function en(e) {
    return {
        ...e,
        clientToken: "empty"
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/boot/logsPublicApi.js
function tn() {
    let e = ne(),
        t = Fe().observable,
        n = $t(xt, e, (r, i, a) => {
            let o = ve(qt)(i, xt, e, t, a);
            return n = nn(r, o), o;
        }),
        r = () => n,
        i = {};
    return w({
        logger: new yt((...e) => n.handleLog(...e)),
        init: (e) => {
            let t = ( /* @__PURE__ */ Error()).stack;
            ye(() => n.init(e, t));
        },
        setTrackingConsent: nt((t) => {
            e.update(t), Ke({
                feature: "set-tracking-consent",
                tracking_consent: t
            });
        }),
        getGlobalContext: f(r, E.globalContext, C.getContext),
        setGlobalContext: f(r, E.globalContext, C.setContext),
        setGlobalContextProperty: f(r, E.globalContext, C.setContextProperty),
        removeGlobalContextProperty: f(r, E.globalContext, C.removeContextProperty),
        clearGlobalContext: f(r, E.globalContext, C.clearContext),
        createLogger: nt((e, t = {}) => (i[e] = new yt((...e) => n.handleLog(...e), b(e), t.handler, t.level, b(t.context)), i[e])),
        getLogger: nt((e) => i[e]),
        getInitConfiguration: nt(() => O(n.initConfiguration)),
        getInternalContext: nt((e) => n.getInternalContext(e)),
        setUser: f(r, E.userContext, C.setContext),
        getUser: f(r, E.userContext, C.getContext),
        setUserProperty: f(r, E.userContext, C.setContextProperty),
        removeUserProperty: f(r, E.userContext, C.removeContextProperty),
        clearUser: f(r, E.userContext, C.clearContext),
        setAccount: f(r, E.accountContext, C.setContext),
        getAccount: f(r, E.accountContext, C.getContext),
        setAccountProperty: f(r, E.accountContext, C.setContextProperty),
        removeAccountProperty: f(r, E.accountContext, C.removeContextProperty),
        clearAccount: f(r, E.accountContext, C.clearContext)
    });
}

function nn(e, t) {
    return {
        init: (e) => {
            Ie("DD_LOGS", e);
        },
        initConfiguration: e,
        ...t
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-logs/esm/entries/main.js
var rn = tn();
S(ot(), "DD_LOGS", rn);
//#endregion
//#region ../../node_modules/tslog/esm/urlToObj.js
function an(e) {
    return {
        href: e.href,
        protocol: e.protocol,
        username: e.username,
        password: e.password,
        host: e.host,
        hostname: e.hostname,
        port: e.port,
        pathname: e.pathname,
        search: e.search,
        searchParams: [...e.searchParams].map(([e, t]) => ({
            key: e,
            value: t
        })),
        hash: e.hash,
        origin: e.origin
    };
}
//#endregion
//#region ../../node_modules/tslog/esm/prettyLogStyles.js
var on = {
    reset: [0, 0],
    bold: [1, 22],
    dim: [2, 22],
    italic: [3, 23],
    underline: [4, 24],
    overline: [53, 55],
    inverse: [7, 27],
    hidden: [8, 28],
    strikethrough: [9, 29],
    black: [30, 39],
    red: [31, 39],
    green: [32, 39],
    yellow: [33, 39],
    blue: [34, 39],
    magenta: [35, 39],
    cyan: [36, 39],
    white: [37, 39],
    blackBright: [90, 39],
    redBright: [91, 39],
    greenBright: [92, 39],
    yellowBright: [93, 39],
    blueBright: [94, 39],
    magentaBright: [95, 39],
    cyanBright: [96, 39],
    whiteBright: [97, 39],
    bgBlack: [40, 49],
    bgRed: [41, 49],
    bgGreen: [42, 49],
    bgYellow: [43, 49],
    bgBlue: [44, 49],
    bgMagenta: [45, 49],
    bgCyan: [46, 49],
    bgWhite: [47, 49],
    bgBlackBright: [100, 49],
    bgRedBright: [101, 49],
    bgGreenBright: [102, 49],
    bgYellowBright: [103, 49],
    bgBlueBright: [104, 49],
    bgMagentaBright: [105, 49],
    bgCyanBright: [106, 49],
    bgWhiteBright: [107, 49]
};
//#endregion
//#region ../../node_modules/tslog/esm/formatTemplate.js
function sn(e, t, n, r = !1) {
    let i = String(t),
        a = (e, t) => `\u001b[${t[0]}m${e}\u001b[${t[1]}m`,
        o = (e, t) => t != null && typeof t == "string" ? a(e, on[t]) : t != null && Array.isArray(t) ? t.reduce((e, t) => o(e, t), e) : t != null && t[e.trim()] != null ? o(e, t[e.trim()]) : t != null && t["*"] != null ? o(e, t["*"]) : e;
    return i.replace(/{{(.+?)}}/g, (t, i) => {
        let s = n[i] == null ? r ? "" : t : String(n[i]);
        return e.stylePrettyLogs ? o(s, e ? .prettyLogStyles ? .[i] ? ? null) + a("", on.reset) : s;
    });
}
//#endregion
//#region ../../node_modules/tslog/esm/formatNumberAddZeros.js
function cn(e, t = 2, n = 0) {
    return e != null && isNaN(e) ? "" : (e = e == null ? e : e + n, t === 2 ? e == null ? "--" : e < 10 ? "0" + e : e.toString() : e == null ? "---" : e < 10 ? "00" + e : e < 100 ? "0" + e : e.toString());
}
//#endregion
//#region ../../node_modules/tslog/esm/internal/metaFormatting.js
function ln(e, t) {
    if (t == null) return {
        text: "",
        template: e.prettyLogTemplate,
        placeholders: {}
    };
    let n = e.prettyLogTemplate,
        r = {};
    n.includes("{{yyyy}}.{{mm}}.{{dd}} {{hh}}:{{MM}}:{{ss}}:{{ms}}") ? n = n.replace("{{yyyy}}.{{mm}}.{{dd}} {{hh}}:{{MM}}:{{ss}}:{{ms}}", "{{dateIsoStr}}") : e.prettyLogTimeZone === "UTC" ? (r.yyyy = t.date ? .getUTCFullYear() ? ? "----", r.mm = cn(t.date ? .getUTCMonth(), 2, 1), r.dd = cn(t.date ? .getUTCDate(), 2), r.hh = cn(t.date ? .getUTCHours(), 2), r.MM = cn(t.date ? .getUTCMinutes(), 2), r.ss = cn(t.date ? .getUTCSeconds(), 2), r.ms = cn(t.date ? .getUTCMilliseconds(), 3)) : (r.yyyy = t.date ? .getFullYear() ? ? "----", r.mm = cn(t.date ? .getMonth(), 2, 1), r.dd = cn(t.date ? .getDate(), 2), r.hh = cn(t.date ? .getHours(), 2), r.MM = cn(t.date ? .getMinutes(), 2), r.ss = cn(t.date ? .getSeconds(), 2), r.ms = cn(t.date ? .getMilliseconds(), 3));
    let i = e.prettyLogTimeZone === "UTC" ? t.date : t.date == null ? void 0 : /* @__PURE__ */ new Date(t.date.getTime() - t.date.getTimezoneOffset() * 6e4);
    r.rawIsoStr = i ? .toISOString() ? ? "", r.dateIsoStr = i ? .toISOString().replace("T", " ").replace("Z", "") ? ? "", r.logLevelName = t.logLevelName, r.fileNameWithLine = t.path ? .fileNameWithLine ? ? "", r.filePathWithLine = t.path ? .filePathWithLine ? ? "", r.fullFilePath = t.path ? .fullFilePath ? ? "";
    let a = e.parentNames ? .join(e.prettyErrorParentNamesSeparator);
    a = a != null && t.name != null ? a + e.prettyErrorParentNamesSeparator : void 0;
    let o = t.name != null || a != null ? `${a ?? ""}${t.name ?? ""}` : "";
    return r.name = o, r.nameWithDelimiterPrefix = o.length > 0 ? e.prettyErrorLoggerNameDelimiter + o : "", r.nameWithDelimiterSuffix = o.length > 0 ? o + e.prettyErrorLoggerNameDelimiter : "", e.overwrite ? .addPlaceholders != null && e.overwrite.addPlaceholders(t, r), {
        text: sn(e, n, r),
        template: n,
        placeholders: r
    };
}
//#endregion
//#region ../../node_modules/tslog/esm/internal/stackTrace.js
var un = [
    /(?:^|[\\/])node_modules[\\/].*tslog/i,
    /(?:^|[\\/])deps[\\/].*tslog/i,
    /tslog[\\/]+src[\\/]+internal[\\/]/i,
    /tslog[\\/]+src[\\/]BaseLogger/i,
    /tslog[\\/]+src[\\/]index/i
];

function dn(e) {
    let t = typeof e ? .stack == "string" ? e.stack : void 0;
    return t == null || t.length === 0 ? [] : t.split("\n").map((e) => e.trimEnd());
}

function fn(e) {
    return e.filter((e) => e.length > 0 && !/^\s*Error\b/.test(e));
}

function pn(e, t) {
    let n = [];
    for (let r of e) {
        let e = t(r);
        e != null && n.push(e);
    }
    return n;
}

function mn(e, t = un) {
    for (let n = 0; n < e.length; n += 1) {
        let r = e[n],
            i = r.filePath ? ? "",
            a = r.fullFilePath ? ? "";
        if (!t.some((e) => e.test(i) || e.test(a))) return n;
    }
    return 0;
}

function hn(e) {
    return fn(dn(e));
}

function gn(e, t) {
    return pn(hn(e), t);
}

function _n(e, t) {
    return e < 0 ? 0 : e >= t ? Math.max(0, t - 1) : e;
}

function vn() {
    return [...un];
}
//#endregion
//#region ../../node_modules/tslog/esm/internal/errorUtils.js
var yn = 5;

function bn(e, t = {}) {
    let n = t.maxDepth ? ? yn,
        r = [],
        i = /* @__PURE__ */ new Set(),
        a = e,
        o = 0;
    for (; a != null && o < n;) {
        let e = a ? .cause;
        if (e == null || i.has(e)) break;
        i.add(e), r.push(xn(e)), a = e, o += 1;
    }
    return r;
}

function xn(e) {
    if (e instanceof Error) return e;
    let t = Error(typeof e == "string" ? e : JSON.stringify(e));
    return typeof e == "object" && e && Object.assign(t, e), t;
}
//#endregion
//#region ../../node_modules/tslog/esm/internal/jsonStringifyRecursive.js
function Sn(e) {
    let t = /* @__PURE__ */ new Set();
    return JSON.stringify(e, (e, n) => {
        if (typeof n == "object" && n) {
            if (t.has(n)) return "[Circular]";
            t.add(n);
        }
        return typeof n == "bigint" ? `${n}` : n === void 0 ? "[undefined]" : n;
    });
}
//#endregion
//#region ../../node_modules/tslog/esm/internal/util.inspect.polyfill.js
function Cn(e, t) {
    let n = {
        seen: [],
        stylize: En
    };
    return t != null && Gn(n, t), Tn(n.showHidden) && (n.showHidden = !1), Tn(n.depth) && (n.depth = 2), Tn(n.colors) && (n.colors = !0), Tn(n.customInspect) && (n.customInspect = !0), n.colors && (n.stylize = Dn), Vn(n, e, n.depth);
}
Cn.colors = on, Cn.styles = {
    special: "cyan",
    number: "yellow",
    boolean: "yellow",
    undefined: "grey",
    null: "bold",
    string: "green",
    date: "magenta",
    regexp: "red"
};

function wn(e) {
    return typeof e == "boolean";
}

function Tn(e) {
    return e === void 0;
}

function En(e) {
    return e;
}

function Dn(e, t) {
    let n = Cn.styles[t];
    return n != null && Cn ? .colors ? .[n] ? .[0] != null && Cn ? .colors ? .[n] ? .[1] != null ? "\x1B[" + Cn.colors[n][0] + "m" + e + "\x1B[" + Cn.colors[n][1] + "m" : e;
}

function On(e) {
    return typeof e == "function";
}

function kn(e) {
    return typeof e == "string";
}

function An(e) {
    return typeof e == "number";
}

function jn(e) {
    return e === null;
}

function Mn(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t);
}

function Nn(e) {
    return Pn(e) && Ln(e) === "[object RegExp]";
}

function Pn(e) {
    return typeof e == "object" && !!e;
}

function Fn(e) {
    return Pn(e) && (Ln(e) === "[object Error]" || e instanceof Error);
}

function In(e) {
    return Pn(e) && Ln(e) === "[object Date]";
}

function Ln(e) {
    return Object.prototype.toString.call(e);
}

function Rn(e) {
    let t = {};
    return e.forEach((e) => {
        t[e] = !0;
    }), t;
}

function zn(e, t, n, r, i) {
    let a = [];
    for (let i = 0, o = t.length; i < o; ++i) Mn(t, String(i)) ? a.push(Hn(e, t, n, r, String(i), !0)) : a.push("");
    return i.forEach((i) => {
        i.match(/^\d+$/) || a.push(Hn(e, t, n, r, i, !0));
    }), a;
}

function Bn(e) {
    return "[" + Error.prototype.toString.call(e) + "]";
}

function Vn(e, t, n = 0) {
    if (e.customInspect && t != null && On(t) && t ? .inspect !== Cn && !(t ? .constructor && t ? .constructor.prototype === t)) {
        if (typeof t.inspect != "function" && t.toString != null) return t.toString();
        let r = t ? .inspect(n, e);
        return kn(r) || (r = Vn(e, r, n)), r;
    }
    let r = Un(e, t);
    if (r) return r;
    let i = Object.keys(t),
        a = Rn(i);
    try {
        e.showHidden && Object.getOwnPropertyNames && (i = Object.getOwnPropertyNames(t));
    } catch {}
    if (Fn(t) && (i.indexOf("message") >= 0 || i.indexOf("description") >= 0)) return Bn(t);
    if (i.length === 0)
        if (On(e.stylize)) {
            if (On(t)) {
                let n = t.name ? ": " + t.name : "";
                return e.stylize("[Function" + n + "]", "special");
            }
            if (Nn(t)) return e.stylize(RegExp.prototype.toString.call(t), "regexp");
            if (In(t)) return e.stylize(Date.prototype.toISOString.call(t), "date");
            if (Fn(t)) return Bn(t);
        } else return t;
    let o = "",
        s = !1,
        c = ["{\n", "\n}"];
    if (Array.isArray(t) && (s = !0, c = ["[\n", "\n]"]), On(t) && (o = " [Function" + (t.name ? ": " + t.name : "") + "]"), Nn(t) && (o = " " + RegExp.prototype.toString.call(t)), In(t) && (o = " " + Date.prototype.toUTCString.call(t)), Fn(t) && (o = " " + Bn(t)), i.length === 0 && (!s || t.length == 0)) return c[0] + o + c[1];
    if (n < 0) return Nn(t) ? e.stylize(RegExp.prototype.toString.call(t), "regexp") : e.stylize("[Object]", "special");
    e.seen.push(t);
    let l;
    return l = s ? zn(e, t, n, a, i) : i.map((r) => Hn(e, t, n, a, r, s)), e.seen.pop(), Wn(l, o, c);
}

function Hn(e, t, n, r, i, a) {
    let o, s, c = {
        value: void 0
    };
    try {
        c.value = t[i];
    } catch {}
    try {
        Object.getOwnPropertyDescriptor && (c = Object.getOwnPropertyDescriptor(t, i) || c);
    } catch {}
    if (c.get ? s = c.set ? e.stylize("[Getter/Setter]", "special") : e.stylize("[Getter]", "special") : c.set && (s = e.stylize("[Setter]", "special")), Mn(r, i) || (o = "[" + i + "]"), s || (e.seen.indexOf(c.value) < 0 ? (s = jn(n) ? Vn(e, c.value, void 0) : Vn(e, c.value, n - 1), s.indexOf("\n") > -1 && (s = a ? s.split("\n").map((e) => "  " + e).join("\n").substr(2) : "\n" + s.split("\n").map((e) => "   " + e).join("\n"))) : s = e.stylize("[Circular]", "special")), Tn(o)) {
        if (a && i.match(/^\d+$/)) return s;
        o = JSON.stringify("" + i), o.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/) ? (o = o.substr(1, o.length - 2), o = e.stylize(o, "name")) : (o = o.replace(/'/g, "\\'").replace(/\\"/g, "\\'").replace(/(^"|"$)/g, "'"), o = e.stylize(o, "string"));
    }
    return o + ": " + s;
}

function Un(e, t) {
    if (Tn(t)) return e.stylize("undefined", "undefined");
    if (kn(t)) {
        let n = "'" + JSON.stringify(t).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, "\\'") + "'";
        return e.stylize(n, "string");
    }
    if (An(t)) return e.stylize("" + t, "number");
    if (wn(t)) return e.stylize("" + t, "boolean");
    if (jn(t)) return e.stylize("null", "null");
}

function Wn(e, t, n) {
    return n[0] + (t === "" ? "" : t + "\n") + "  " + e.join(",\n  ") + " " + n[1];
}

function Gn(e, t) {
    let n = { ...e
    };
    if (!t || !Pn(t)) return e;
    let r = { ...t
        },
        i = Object.keys(t),
        a = i.length;
    for (; a--;) n[i[a]] = r[i[a]];
    return n;
}

function Kn(e, ...t) {
    let n = {
        seen: [],
        stylize: En
    };
    e != null && Gn(n, e);
    let r = t[0],
        i = 0,
        a = "",
        o = "";
    if (typeof r == "string") {
        if (t.length === 1) return r;
        let s, c = 0;
        for (let o = 0; o < r.length - 1; o++)
            if (r.charCodeAt(o) === 37) {
                let l = r.charCodeAt(++o);
                if (i + 1 !== t.length) {
                    switch (l) {
                        case 115:
                            {
                                let r = t[++i];
                                s = typeof r == "number" || typeof r == "bigint" ? Un(n, r) : typeof r != "object" || !r ? String(r) : Cn(r, {
                                    ...e,
                                    compact: 3,
                                    colors: !1,
                                    depth: 0
                                });
                                break;
                            }
                        case 106:
                            s = Sn(t[++i]);
                            break;
                        case 100:
                            {
                                let e = t[++i];
                                s = typeof e == "bigint" ? Un(n, e) : typeof e == "symbol" ? "NaN" : Un(n, e);
                                break;
                            }
                        case 79:
                            s = Cn(t[++i], e);
                            break;
                        case 111:
                            s = Cn(t[++i], {
                                ...e,
                                showHidden: !0,
                                showProxy: !0,
                                depth: 4
                            });
                            break;
                        case 105:
                            {
                                let e = t[++i];
                                s = typeof e == "bigint" ? Un(n, e) : typeof e == "symbol" ? "NaN" : Un(n, parseInt(s));
                                break;
                            }
                        case 102:
                            {
                                let e = t[++i];
                                s = typeof e == "symbol" ? "NaN" : Un(n, parseInt(e));
                                break;
                            }
                        case 99:
                            i += 1, s = "";
                            break;
                        case 37:
                            a += r.slice(c, o), c = o + 1;
                            continue;
                        default:
                            continue;
                    }
                    c !== o - 1 && (a += r.slice(c, o - 1)), a += s, c = o + 1;
                } else l === 37 && (a += r.slice(c, o), c = o + 1);
            }
        c !== 0 && (i++, o = " ", c < r.length && (a += r.slice(c)));
    }
    for (; i < t.length;) {
        let n = t[i];
        a += o, a += typeof n == "string" ? n : Cn(n, e), o = " ", i++;
    }
    return a;
}
//#endregion
//#region ../../node_modules/tslog/esm/internal/environment.js
function qn() {
    try {
        let e = globalThis ? .process;
        if (typeof e ? .cwd == "function") return e.cwd();
    } catch {}
    try {
        let e = globalThis ? .Deno;
        if (typeof e ? .cwd == "function") return e.cwd();
    } catch {}
}

function Jn() {
    return typeof window < "u" && typeof document < "u";
}

function Yn() {
    if (!Jn()) return !1;
    let e = globalThis ? .navigator ? .userAgent ? ? "";
    return /firefox/i.test(e) || globalThis ? .CSS ? .supports ? .("color", "#000") ? !0 : /safari/i.test(e) && !/chrome/i.test(e);
}
//#endregion
//#region ../../node_modules/tslog/esm/BaseLogger.js
function Xn() {
    let e = w(),
        t = b(e),
        n = e.name === "browser" || e.name === "worker",
        r = n ? [...vn(), /node_modules[\\/].*tslog/i] : [
            ...vn(),
            /node:(?:internal|vm)/i,
            /\binternal[\\/]/i
        ],
        i, a = {
            getMeta(e, n, r, i, o, s) {
                return Object.assign({}, t, {
                    name: o,
                    parentNames: s,
                    date: /* @__PURE__ */ new Date(),
                    logLevelId: e,
                    logLevelName: n,
                    path: i ? void 0 : a.getCallerStackFrame(r)
                });
            },
            getCallerStackFrame(e, t = /* @__PURE__ */ Error()) {
                let n = gn(t, (e) => o(e));
                if (n.length === 0) return {};
                let i = mn(n, r);
                return n[_n(Number.isFinite(e) && e >= 0 ? e : i, n.length)] ? ? {};
            },
            getErrorTrace(e) {
                return gn(e, (e) => o(e));
            },
            isError(e) {
                return D(e);
            },
            isBuffer(e) {
                return typeof Buffer < "u" && typeof Buffer.isBuffer == "function" ? Buffer.isBuffer(e) : !1;
            },
            prettyFormatLogObj(e, t) {
                return e.reduce((e, n) => (a.isError(n) ? e.errors.push(a.prettyFormatErrorObj(n, t)) : e.args.push(n), e), {
                    args: [],
                    errors: []
                });
            },
            prettyFormatErrorObj(e, t) {
                let n = l(a.getErrorTrace(e), t),
                    r = bn(e).map((e, n) => [`Caused by (${n + 1}): ${e.name ?? "Error"}${e.message ? `: ${e.message}` : ""}`, ...l(gn(e, (e) => o(e)), t)].join("\n")),
                    i = {
                        errorName: ` ${e.name} `,
                        errorMessage: u(e),
                        errorStack: [...n, ...r].join("\n")
                    };
                return sn(t, t.prettyErrorTemplate, i);
            },
            transportFormatted(e, t, n, r, i) {
                let a = i.stylePrettyLogs !== !1,
                    o = (n.length > 0 && t.length > 0 ? "\n" : "") + n.join("\n"),
                    s = f(e),
                    c = a ? e : s;
                if (d(a)) {
                    i.prettyInspectOptions.colors = !1;
                    let e = x(i.prettyInspectOptions, t),
                        n = r == null ? {
                            text: s,
                            styles: []
                        } : p(i, r),
                        a = n.text.length > 0 && n.styles.length > 0,
                        c = (a ? n.text : s) + e + o;
                    a ? console.log(c, ...n.styles) : console.log(c);
                    return;
                }
                i.prettyInspectOptions.colors = a;
                let l = x(i.prettyInspectOptions, t);
                console.log(c + l + o);
            },
            transportJSON(e) {
                console.log(Sn(e));
            }
        };
    return E() === "test" && (a.__resetWorkingDirectoryCacheForTests = () => {
        i = void 0;
    }), a;

    function o(e) {
        return n ? c(e) : s(e);
    }

    function s(e) {
        if (typeof e != "string" || e.length === 0) return;
        let t = e.trim();
        if (!t.includes(" at ") && !t.startsWith("at ")) return;
        let n = t.replace(/^at\s+/, ""),
            r, i = n,
            a = n.match(/^(.*?)\s+\((.*)\)$/);
        a && (r = a[1], i = a[2]);
        let o = i.replace(/^\(/, "").replace(/\)$/, ""),
            s = o.replace(/\?.*$/, ""),
            c, l, u = s,
            d = s.split(":");
        d.length >= 3 && /^\d+$/.test(d[d.length - 1] ? ? "") ? (l = d.pop(), c = d.pop(), u = d.join(":")) : d.length >= 2 && /^\d+$/.test(d[d.length - 1] ? ? "") && (c = d.pop(), u = d.join(":"));
        let f = u.replace(/^file:\/\//, ""),
            p = _();
        p != null && f.startsWith(p) && (f = f.slice(p.length), f = f.replace(/^[\\/]/, "")), f.length === 0 && (f = u);
        let m = C(f),
            h = m.length > 0 ? m : f,
            g = h.split(/\\|\//),
            v = g[g.length - 1],
            y = v && c ? `${v}:${c}` : void 0,
            b = h && c ? `${h}:${c}` : void 0;
        return {
            fullFilePath: o,
            fileName: v,
            fileNameWithLine: y,
            fileColumn: l,
            fileLine: c,
            filePath: h,
            filePathWithLine: b,
            method: r
        };
    }

    function c(e) {
        let t = globalThis.location ? .origin;
        if (e == null) return;
        let n = e.match(er);
        if (!n) return;
        let r = n[1] ? .replace(/\?.*$/, "");
        if (r == null) return;
        let i = r.split("/"),
            a = n[2],
            o = n[3],
            s = i[i.length - 1];
        return {
            fullFilePath: t ? `${t}${r}` : r,
            fileName: s,
            fileNameWithLine: s && a ? `${s}:${a}` : void 0,
            fileColumn: o,
            fileLine: a,
            filePath: r,
            filePathWithLine: a ? `${r}:${a}` : void 0,
            method: void 0
        };
    }

    function l(e, t) {
        return e.map((e) => sn(t, t.prettyErrorStackTemplate, { ...e
        }, !0));
    }

    function u(e) {
        return Object.getOwnPropertyNames(e).filter((e) => e !== "stack" && e !== "cause").reduce((t, n) => {
            let r = e[n];
            return typeof r == "function" || t.push(String(r)), t;
        }, []).join(", ");
    }

    function d(t) {
        return t && (e.name === "browser" || e.name === "worker") && Yn();
    }

    function f(e) {
        return e.replace(Zn, "");
    }

    function p(e, t) {
        if (t == null) return {
            text: "",
            styles: []
        };
        let {
            template: n,
            placeholders: r
        } = ln(e, t), i = [], a = [], o = 0, s = /{{(.+?)}}/g, c;
        for (;
            (c = s.exec(n)) != null;) {
            c.index > o && i.push(n.slice(o, c.index));
            let t = c[1],
                l = r[t] == null ? "" : String(r[t]),
                u = h(m(e.prettyLogStyles ? .[t], l));
            u.length > 0 ? (i.push(`%c${l}%c`), a.push(u, "")) : i.push(l), o = s.lastIndex;
        }
        return o < n.length && i.push(n.slice(o)), {
            text: i.join(""),
            styles: a
        };
    }

    function m(e, t) {
        if (e == null) return [];
        if (typeof e == "string") return [e];
        if (Array.isArray(e)) return e.flatMap((e) => m(e, t));
        if (typeof e == "object") {
            let n = e[t.trim()] ? ? e["*"];
            return n == null ? [] : m(n, t);
        }
        return [];
    }

    function h(e) {
        let t = /* @__PURE__ */ new Set(),
            n = [];
        for (let r of e) {
            let e = g(r);
            e != null && e.length > 0 && !t.has(e) && (t.add(e), n.push(e));
        }
        return n.join("; ");
    }

    function g(e) {
        let t = Qn[e];
        if (t != null) return `color: ${t}`;
        let n = $n[e];
        if (n != null) return `background-color: ${n}`;
        switch (e) {
            case "bold":
                return "font-weight: bold";
            case "dim":
                return "opacity: 0.75";
            case "italic":
                return "font-style: italic";
            case "underline":
                return "text-decoration: underline";
            case "overline":
                return "text-decoration: overline";
            case "inverse":
                return "filter: invert(1)";
            case "hidden":
                return "visibility: hidden";
            case "strikethrough":
                return "text-decoration: line-through";
            default:
                return;
        }
    }

    function _() {
        return i === void 0 && (i = qn() ? ? null), i ? ? void 0;
    }

    function v() {
        return e.name === "node" || e.name === "deno" || e.name === "bun";
    }

    function y() {
        return e.name === "node" || e.name === "deno" || e.name === "bun";
    }

    function b(e) {
        if (e.name === "browser" || e.name === "worker") return {
            runtime: e.name,
            browser: e.userAgent
        };
        let t = {
            runtime: e.name
        };
        return y() && (t.runtimeVersion = e.version ? ? "unknown"), v() && (t.hostname = e.hostname ? ? "unknown"), t;
    }

    function x(e, t) {
        try {
            return Kn(e, ...t);
        } catch {
            return t.map(S).join(" ");
        }
    }

    function S(e) {
        if (typeof e == "string") return e;
        try {
            return JSON.stringify(e);
        } catch {
            return String(e);
        }
    }

    function C(e) {
        if (typeof e != "string" || e.length === 0) return e;
        let t = e.replace(/\\+/g, "\\").replace(/\\/g, "/"),
            n = t.startsWith("//"),
            r = t.startsWith("/") && !n,
            i = t.match(/^[A-Za-z]:/),
            a = i ? i[0] : "",
            o = (a ? t.slice(a.length) : t).split("/"),
            s = [];
        for (let e of o)
            if (!(e === "" || e === ".")) {
                if (e === "..") {
                    s.length > 0 && s.pop();
                    continue;
                }
                s.push(e);
            }
        let c = s.join("/");
        return n ? c = `//${c}` : r ? c = `/${c}` : a !== "" && (c = `${a}${c.length > 0 ? `/${c}` : ""}`), c.length === 0 ? e : c;
    }

    function w() {
        if (Jn()) return {
            name: "browser",
            userAgent: globalThis.navigator ? .userAgent
        };
        let e = globalThis;
        if (typeof e.importScripts == "function") return {
            name: "worker",
            userAgent: e.navigator ? .userAgent
        };
        let t = globalThis;
        if (t.Bun != null) {
            let e = t.Bun.version;
            return {
                name: "bun",
                version: e == null ? void 0 : `bun/${e}`,
                hostname: T(t.process, t.Deno, t.Bun, t.location)
            };
        }
        if (t.Deno != null) {
            let e = ee(t.Deno),
                n = t.Deno ? .version ? .deno;
            return {
                name: "deno",
                version: n == null ? void 0 : `deno/${n}`,
                hostname: e ? ? T(t.process, t.Deno, t.Bun, t.location)
            };
        }
        return t.process ? .versions ? .node != null || t.process ? .version != null ? {
            name: "node",
            version: t.process ? .versions ? .node ? ? t.process ? .version,
            hostname: T(t.process, t.Deno, t.Bun, t.location)
        } : t.process == null ? {
            name: "unknown"
        } : {
            name: "node",
            version: "unknown",
            hostname: T(t.process, t.Deno, t.Bun, t.location)
        };
    }

    function T(e, t, n, r) {
        let i = e ? .env ? .HOSTNAME ? ? e ? .env ? .HOST ? ? e ? .env ? .COMPUTERNAME;
        if (i != null && i.length > 0) return i;
        let a = n ? .env ? .HOSTNAME ? ? n ? .env ? .HOST ? ? n ? .env ? .COMPUTERNAME;
        if (a != null && a.length > 0) return a;
        try {
            let e = t ? .env ? .get;
            if (typeof e == "function") {
                let t = e("HOSTNAME");
                if (t != null && t.length > 0) return t;
            }
        } catch {}
        if (r ? .hostname != null && r.hostname.length > 0) return r.hostname;
    }

    function ee(e) {
        try {
            if (typeof e ? .hostname == "function") {
                let t = e.hostname();
                if (t != null && t.length > 0) return t;
            }
        } catch {}
        let t = globalThis.location ? .hostname;
        if (t != null && t.length > 0) return t;
    }

    function E() {
        return (globalThis ? .process) ? .env ? .NODE_ENV;
    }

    function D(e) {
        if (e instanceof Error) return !0;
        if (typeof e == "object" && e) {
            let t = Object.prototype.toString.call(e);
            if (/\[object .*Error\]/.test(t)) return !0;
            let n = e.name;
            if (typeof n == "string" && n.endsWith("Error")) return !0;
        }
        return !1;
    }
}
var Zn = /\u001b\[[0-9;]*m/g,
    Qn = {
        black: "#000000",
        red: "#ef5350",
        green: "#66bb6a",
        yellow: "#fdd835",
        blue: "#42a5f5",
        magenta: "#ab47bc",
        cyan: "#26c6da",
        white: "#fafafa",
        blackBright: "#424242",
        redBright: "#ff7043",
        greenBright: "#81c784",
        yellowBright: "#ffe082",
        blueBright: "#64b5f6",
        magentaBright: "#ce93d8",
        cyanBright: "#4dd0e1",
        whiteBright: "#ffffff"
    },
    $n = {
        bgBlack: "#000000",
        bgRed: "#ef5350",
        bgGreen: "#66bb6a",
        bgYellow: "#fdd835",
        bgBlue: "#42a5f5",
        bgMagenta: "#ab47bc",
        bgCyan: "#26c6da",
        bgWhite: "#fafafa",
        bgBlackBright: "#424242",
        bgRedBright: "#ff7043",
        bgGreenBright: "#81c784",
        bgYellowBright: "#ffe082",
        bgBlueBright: "#64b5f6",
        bgMagentaBright: "#ce93d8",
        bgCyanBright: "#4dd0e1",
        bgWhiteBright: "#ffffff"
    },
    er = /(?:(?:file|https?|global code|[^@]+)@)?(?:file:)?((?:\/[^:/]+){2,})(?::(\d+))?(?::(\d+))?/,
    tr = Xn(),
    nr = class {
        constructor(e, t, n = NaN) {
            this.logObj = t, this.stackDepthLevel = n, this.runtime = tr, this.maxErrorCauseDepth = 5, this.settings = {
                type: e ? .type ? ? "pretty",
                name: e ? .name,
                parentNames: e ? .parentNames,
                minLevel: e ? .minLevel ? ? 0,
                argumentsArrayName: e ? .argumentsArrayName,
                hideLogPositionForProduction: e ? .hideLogPositionForProduction ? ? !1,
                prettyLogTemplate: e ? .prettyLogTemplate ? ? "{{yyyy}}.{{mm}}.{{dd}} {{hh}}:{{MM}}:{{ss}}:{{ms}}	{{logLevelName}}	{{filePathWithLine}}{{nameWithDelimiterPrefix}}	",
                prettyErrorTemplate: e ? .prettyErrorTemplate ? ? "\n{{errorName}} {{errorMessage}}\nerror stack:\n{{errorStack}}",
                prettyErrorStackTemplate: e ? .prettyErrorStackTemplate ? ? "  • {{fileName}}	{{method}}\n	{{filePathWithLine}}",
                prettyErrorParentNamesSeparator: e ? .prettyErrorParentNamesSeparator ? ? ":",
                prettyErrorLoggerNameDelimiter: e ? .prettyErrorLoggerNameDelimiter ? ? "	",
                stylePrettyLogs: e ? .stylePrettyLogs ? ? !0,
                prettyLogTimeZone: e ? .prettyLogTimeZone ? ? "UTC",
                prettyLogStyles: e ? .prettyLogStyles ? ? {
                    logLevelName: {
                        "*": [
                            "bold",
                            "black",
                            "bgWhiteBright",
                            "dim"
                        ],
                        SILLY: ["bold", "white"],
                        TRACE: ["bold", "whiteBright"],
                        DEBUG: ["bold", "green"],
                        INFO: ["bold", "blue"],
                        WARN: ["bold", "yellow"],
                        ERROR: ["bold", "red"],
                        FATAL: ["bold", "redBright"]
                    },
                    dateIsoStr: "white",
                    filePathWithLine: "white",
                    name: ["white", "bold"],
                    nameWithDelimiterPrefix: ["white", "bold"],
                    nameWithDelimiterSuffix: ["white", "bold"],
                    errorName: [
                        "bold",
                        "bgRedBright",
                        "whiteBright"
                    ],
                    fileName: ["yellow"],
                    fileNameWithLine: "white"
                },
                prettyInspectOptions: e ? .prettyInspectOptions ? ? {
                    colors: !0,
                    compact: !1,
                    depth: Infinity
                },
                metaProperty: e ? .metaProperty ? ? "_meta",
                maskPlaceholder: e ? .maskPlaceholder ? ? "[***]",
                maskValuesOfKeys: e ? .maskValuesOfKeys ? ? ["password"],
                maskValuesOfKeysCaseInsensitive: e ? .maskValuesOfKeysCaseInsensitive ? ? !1,
                maskValuesRegEx: e ? .maskValuesRegEx,
                prefix: [...e ? .prefix ? ? []],
                attachedTransports: [...e ? .attachedTransports ? ? []],
                overwrite: {
                    mask: e ? .overwrite ? .mask,
                    toLogObj: e ? .overwrite ? .toLogObj,
                    addMeta: e ? .overwrite ? .addMeta,
                    addPlaceholders: e ? .overwrite ? .addPlaceholders,
                    formatMeta: e ? .overwrite ? .formatMeta,
                    formatLogObj: e ? .overwrite ? .formatLogObj,
                    transportFormatted: e ? .overwrite ? .transportFormatted,
                    transportJSON: e ? .overwrite ? .transportJSON
                }
            }, this.captureStackForMeta = this._shouldCaptureStack();
        }
        log(e, t, ...n) {
            if (e < this.settings.minLevel) return;
            let r = this._resolveLogArguments(n),
                i = [...this.settings.prefix, ...r],
                a = this.settings.overwrite ? .mask == null ? this.settings.maskValuesOfKeys != null && this.settings.maskValuesOfKeys.length > 0 ? this._mask(i) : i : this.settings.overwrite ? .mask(i),
                o = this.logObj == null ? void 0 : this._recursiveCloneAndExecuteFunctions(this.logObj),
                s = this.settings.overwrite ? .toLogObj == null ? this._toLogObj(a, o) : this.settings.overwrite ? .toLogObj(a, o),
                c = this.settings.overwrite ? .addMeta == null ? this._addMetaToLogObj(s, e, t) : this.settings.overwrite ? .addMeta(s, e, t),
                l = c ? .[this.settings.metaProperty],
                u, d;
            if (this.settings.overwrite ? .formatMeta != null && (u = this.settings.overwrite ? .formatMeta(c ? .[this.settings.metaProperty])), this.settings.overwrite ? .formatLogObj != null && (d = this.settings.overwrite ? .formatLogObj(a, this.settings)), this.settings.type === "pretty" && (u ? ? = this._prettyFormatLogObjMeta(c ? .[this.settings.metaProperty]), d ? ? = tr.prettyFormatLogObj(a, this.settings)), u != null && d != null)
                if (this.settings.overwrite ? .transportFormatted != null) {
                    let e = this.settings.overwrite.transportFormatted,
                        t = e.length;
                    t < 4 ? e(u, d.args, d.errors) : t === 4 ? e(u, d.args, d.errors, l) : e(u, d.args, d.errors, l, this.settings);
                } else tr.transportFormatted(u, d.args, d.errors, l, this.settings);
            else this.settings.overwrite ? .transportJSON == null ? this.settings.type !== "hidden" && tr.transportJSON(c) : this.settings.overwrite.transportJSON(c);
            return this.settings.attachedTransports != null && this.settings.attachedTransports.length > 0 && this.settings.attachedTransports.forEach((e) => {
                e(c);
            }), c;
        }
        attachTransport(e) {
            this.settings.attachedTransports.push(e);
        }
        getSubLogger(e, t) {
            let n = {
                ...this.settings,
                ...e,
                parentNames: this.settings ? .parentNames != null && this.settings ? .name != null ? [...this.settings.parentNames, this.settings.name] : this.settings ? .name == null ? void 0 : [this.settings.name],
                prefix: [...this.settings.prefix, ...e ? .prefix ? ? []]
            };
            return new this.constructor(n, t ? ? this.logObj, this.stackDepthLevel);
        }
        _mask(e) {
            let t = this._getMaskKeys();
            return e ? .map((e) => this._recursiveCloneAndMaskValuesOfKeys(e, t));
        }
        _getMaskKeys() {
            let e = this.settings.maskValuesOfKeys ? ? [],
                t = e.map(String).join("|");
            if (this.settings.maskValuesOfKeysCaseInsensitive === !0) {
                if (this.maskKeysCache ? .source === e && this.maskKeysCache.caseInsensitive === !0 && this.maskKeysCache.signature === t) return this.maskKeysCache.normalized;
                let n = e.map((e) => typeof e == "string" ? e.toLowerCase() : String(e).toLowerCase());
                return this.maskKeysCache = {
                    source: e,
                    caseInsensitive: !0,
                    normalized: n,
                    signature: t
                }, n;
            }
            return this.maskKeysCache = {
                source: e,
                caseInsensitive: !1,
                normalized: e,
                signature: t
            }, e;
        }
        _resolveLogArguments(e) {
            if (e.length === 1 && typeof e[0] == "function") {
                let t = e[0];
                if (t.length === 0) {
                    let e = t();
                    return Array.isArray(e) ? e : [e];
                }
            }
            return e;
        }
        _recursiveCloneAndMaskValuesOfKeys(e, t, n = []) {
            if (n.includes(e)) return { ...e
            };
            if (typeof e == "object" && e && n.push(e), tr.isError(e) || tr.isBuffer(e)) return e;
            if (e instanceof Map) return new Map(e);
            if (e instanceof Set) return new Set(e);
            if (Array.isArray(e)) return e.map((e) => this._recursiveCloneAndMaskValuesOfKeys(e, t, n));
            if (e instanceof Date) return new Date(e.getTime());
            if (e instanceof URL) return an(e);
            if (typeof e == "object" && e) {
                let r = tr.isError(e) ? this._cloneError(e) : Object.create(Object.getPrototypeOf(e));
                return Object.getOwnPropertyNames(e).reduce((r, i) => {
                    let a = this.settings ? .maskValuesOfKeysCaseInsensitive === !0 ? typeof i == "string" ? i.toLowerCase() : String(i).toLowerCase() : i;
                    return r[i] = t.includes(a) ? this.settings.maskPlaceholder : (() => {
                        try {
                            return this._recursiveCloneAndMaskValuesOfKeys(e[i], t, n);
                        } catch {
                            return null;
                        }
                    })(), r;
                }, r);
            } else {
                if (typeof e == "string") {
                    let t = e;
                    for (let e of this.settings ? .maskValuesRegEx || []) t = t.replace(e, this.settings ? .maskPlaceholder || "");
                    return t;
                }
                return e;
            }
        }
        _recursiveCloneAndExecuteFunctions(e, t = []) {
            return this.isObjectOrArray(e) && t.includes(e) ? this.shallowCopy(e) : (this.isObjectOrArray(e) && t.push(e), Array.isArray(e) ? e.map((e) => this._recursiveCloneAndExecuteFunctions(e, t)) : e instanceof Date ? new Date(e.getTime()) : this.isObject(e) ? Object.getOwnPropertyNames(e).reduce((n, r) => {
                let i = Object.getOwnPropertyDescriptor(e, r);
                if (i) {
                    Object.defineProperty(n, r, i);
                    let a = e[r];
                    n[r] = typeof a == "function" ? a() : this._recursiveCloneAndExecuteFunctions(a, t);
                }
                return n;
            }, Object.create(Object.getPrototypeOf(e))) : e);
        }
        isObjectOrArray(e) {
            return typeof e == "object" && !!e;
        }
        isObject(e) {
            return typeof e == "object" && !Array.isArray(e) && e !== null;
        }
        shallowCopy(e) {
            return Array.isArray(e) ? [...e] : { ...e
            };
        }
        _toLogObj(e, t = {}) {
            return e = e ? .map((e) => tr.isError(e) ? this._toErrorObject(e) : e), t = this.settings.argumentsArrayName == null ? e.length === 1 && !Array.isArray(e[0]) && tr.isBuffer(e[0]) !== !0 && !(e[0] instanceof Date) ? typeof e[0] == "object" && e[0] != null ? {
                ...e[0],
                ...t
            } : {
                0: e[0],
                ...t
            } : {
                ...t,
                ...e
            } : {
                ...t,
                [this.settings.argumentsArrayName]: e
            }, t;
        }
        _cloneError(e) {
            let t = new e.constructor();
            return Object.getOwnPropertyNames(e).forEach((n) => {
                t[n] = e[n];
            }), t;
        }
        _toErrorObject(e, t = 0, n = /* @__PURE__ */ new Set()) {
            n.has(e) || n.add(e);
            let r = {
                nativeError: e,
                name: e.name ? ? "Error",
                message: e.message,
                stack: tr.getErrorTrace(e)
            };
            if (t >= this.maxErrorCauseDepth) return r;
            let i = e.cause;
            if (i != null) {
                let e = xn(i);
                n.has(e) || (r.cause = this._toErrorObject(e, t + 1, n));
            }
            return r;
        }
        _addMetaToLogObj(e, t, n) {
            return {
                ...e,
                [this.settings.metaProperty]: tr.getMeta(t, n, this.stackDepthLevel, !this.captureStackForMeta, this.settings.name, this.settings.parentNames)
            };
        }
        _shouldCaptureStack() {
            if (this.settings.hideLogPositionForProduction) return !1;
            if (this.settings.type === "json") return !0;
            let e = this.settings.prettyLogTemplate ? ? "";
            return !!/{{\s*(file(Name|Path|Line|PathWithLine|NameWithLine)|fullFilePath)\s*}}/.test(e);
        }
        _prettyFormatLogObjMeta(e) {
            return ln(this.settings, e).text;
        }
    },
    rr = class extends nr {
        constructor(e, t) {
            let n = typeof window < "u" && typeof document < "u",
                r = { ...e ? ? {}
                };
            n && (r.stylePrettyLogs = e ? .stylePrettyLogs ? ? !0), super(r, t, NaN);
        }
        log(e, t, ...n) {
            return super.log(e, t, ...n);
        }
        silly(...e) {
            return super.log(0, "SILLY", ...e);
        }
        trace(...e) {
            return super.log(1, "TRACE", ...e);
        }
        debug(...e) {
            return super.log(2, "DEBUG", ...e);
        }
        info(...e) {
            return super.log(3, "INFO", ...e);
        }
        warn(...e) {
            return super.log(4, "WARN", ...e);
        }
        error(...e) {
            return super.log(5, "ERROR", ...e);
        }
        fatal(...e) {
            return super.log(6, "FATAL", ...e);
        }
        getSubLogger(e, t) {
            return super.getSubLogger(e, t);
        }
    },
    ir = "prod";

function ar(e) {
    let t = e._meta,
        n = t ? .logLevelId ? ? 3,
        r = t ? .name ? ? "core",
        i = [],
        a = 0;
    for (; a in e;) i.push(e[a]), a++;
    let o = i.find(or),
        s = o ? sr(o) : void 0,
        c = `[${r}] ${i.map(cr).join(" ")}`;
    try {
        n >= 5 ? rn.logger.error(c, void 0, s) : n === 4 ? rn.logger.warn(c, void 0, s) : n <= 1 ? rn.logger.debug(c) : rn.logger.info(c);
    } catch {}
}

function or(e) {
    return e instanceof Error ? !0 : e ? .nativeError instanceof Error;
}

function sr(e) {
    return e instanceof Error ? e : e.nativeError;
}

function cr(e) {
    if (typeof e == "string") return e;
    if (or(e)) {
        let t = sr(e);
        return `${t.name}: ${t.message}`;
    }
    if (typeof e != "object" || !e) return String(e);
    try {
        return JSON.stringify(e) ? ? String(e);
    } catch {
        return `[${Object.prototype.toString.call(e)}]`;
    }
}

function lr(e) {
    return ur(e);
}

function ur(e) {
    let t = ir === "prod",
        n = new rr({
            name: e,
            type: t ? "hidden" : "pretty",
            minLevel: 0,
            hideLogPositionForProduction: t
        });
    return t && n.attachTransport(ar), n;
}
//#endregion
//#region \0@oxc-project+runtime@0.122.0/helpers/typeof.js
function dr(e) {
    "@babel/helpers - typeof";
    return dr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e;
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
    }, dr(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.122.0/helpers/toPrimitive.js
function fr(e, t) {
    if (dr(e) != "object" || !e) return e;
    var n = e[Symbol.toPrimitive];
    if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (dr(r) != "object") return r;
        throw TypeError("@@toPrimitive must return a primitive value.");
    }
    return (t === "string" ? String : Number)(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.122.0/helpers/toPropertyKey.js
function pr(e) {
    var t = fr(e, "string");
    return dr(t) == "symbol" ? t : t + "";
}
//#endregion
//#region \0@oxc-project+runtime@0.122.0/helpers/defineProperty.js
function j(e, t, n) {
    return (t = pr(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}
//#endregion
//#region src/lifecycle.ts
var mr = null,
    hr = null;

function gr(e) {
    mr = e;
}

function _r() {
    return mr;
}

function vr() {
    return hr;
}

function yr(e) {
    hr = e;
}
var br = class extends Error {
        constructor() {
            super("Lifecycle superseded by a reset/identity-change"), this.name = "LifecycleSupersededError";
        }
    },
    xr = class {
        constructor() {
            j(this, "controller", new AbortController()), j(this, "teardownController", new AbortController()), gr(this.controller.signal), yr(this.teardownController.signal);
        }
        get signal() {
            return this.controller.signal;
        }
        get teardownSignal() {
            return this.teardownController.signal;
        }
        supersede() {
            this.teardownSignal.aborted || (this.controller.abort(), this.controller = new AbortController(), gr(this.controller.signal));
        }
        destroy() {
            this.teardownController.abort(), this.controller.abort();
        }
    };

function Sr(e) {
    if (e.aborted) throw new br();
}

function Cr(e) {
    return e instanceof br;
}
//#endregion
//#region ../../node_modules/redux/dist/redux.mjs
function wr(e) {
    return `Minified Redux error #${e}; visit https://redux.js.org/Errors?code=${e} for the full message or use the non-minified dev environment for full errors. `;
}
var Tr = typeof Symbol == "function" && Symbol.observable || "@@observable",
    Er = () => Math.random().toString(36).substring(7).split("").join("."),
    Dr = {
        INIT: `@@redux/INIT${/* @__PURE__ */ Er()}`,
        REPLACE: `@@redux/REPLACE${/* @__PURE__ */ Er()}`,
        PROBE_UNKNOWN_ACTION: () => `@@redux/PROBE_UNKNOWN_ACTION${Er()}`
    };

function Or(e) {
    if (typeof e != "object" || !e) return !1;
    let t = e;
    for (; Object.getPrototypeOf(t) !== null;) t = Object.getPrototypeOf(t);
    return Object.getPrototypeOf(e) === t || Object.getPrototypeOf(e) === null;
}

function kr(e, t, n) {
    if (typeof e != "function") throw Error(wr(2));
    if (typeof t == "function" && typeof n == "function" || typeof n == "function" && typeof arguments[3] == "function") throw Error(wr(0));
    if (typeof t == "function" && n === void 0 && (n = t, t = void 0), n !== void 0) {
        if (typeof n != "function") throw Error(wr(1));
        return n(kr)(e, t);
    }
    let r = e,
        i = t,
        a = /* @__PURE__ */ new Map(),
        o = a,
        s = 0,
        c = !1;

    function l() {
        o === a && (o = /* @__PURE__ */ new Map(), a.forEach((e, t) => {
            o.set(t, e);
        }));
    }

    function u() {
        if (c) throw Error(wr(3));
        return i;
    }

    function d(e) {
        if (typeof e != "function") throw Error(wr(4));
        if (c) throw Error(wr(5));
        let t = !0;
        l();
        let n = s++;
        return o.set(n, e),
            function() {
                if (t) {
                    if (c) throw Error(wr(6));
                    t = !1, l(), o.delete(n), a = null;
                }
            };
    }

    function f(e) {
        if (!Or(e)) throw Error(wr(7));
        if (e.type === void 0) throw Error(wr(8));
        if (typeof e.type != "string") throw Error(wr(17));
        if (c) throw Error(wr(9));
        try {
            c = !0, i = r(i, e);
        } finally {
            c = !1;
        }
        return (a = o).forEach((e) => {
            e();
        }), e;
    }

    function p(e) {
        if (typeof e != "function") throw Error(wr(10));
        r = e, f({
            type: Dr.REPLACE
        });
    }

    function m() {
        let e = d;
        return {
            subscribe(t) {
                if (typeof t != "object" || !t) throw Error(wr(11));

                function n() {
                    let e = t;
                    e.next && e.next(u());
                }
                return n(), {
                    unsubscribe: e(n)
                };
            },
            [Tr]() {
                return this;
            }
        };
    }
    return f({
        type: Dr.INIT
    }), {
        dispatch: f,
        subscribe: d,
        getState: u,
        replaceReducer: p,
        [Tr]: m
    };
}

function Ar(e) {
    Object.keys(e).forEach((t) => {
        let n = e[t];
        if (n(void 0, {
                type: Dr.INIT
            }) === void 0) throw Error(wr(12));
        if (n(void 0, {
                type: Dr.PROBE_UNKNOWN_ACTION()
            }) === void 0) throw Error(wr(13));
    });
}

function jr(e) {
    let t = Object.keys(e),
        n = {};
    for (let r = 0; r < t.length; r++) {
        let i = t[r];
        typeof e[i] == "function" && (n[i] = e[i]);
    }
    let r = Object.keys(n),
        i;
    try {
        Ar(n);
    } catch (e) {
        i = e;
    }
    return function(e = {}, t) {
        if (i) throw i;
        let a = !1,
            o = {};
        for (let i = 0; i < r.length; i++) {
            let s = r[i],
                c = n[s],
                l = e[s],
                u = c(l, t);
            if (u === void 0) throw t && t.type, Error(wr(14));
            o[s] = u, a || = u !== l;
        }
        return a || = r.length !== Object.keys(e).length, a ? o : e;
    };
}

function Mr(...e) {
    return e.length === 0 ? (e) => e : e.length === 1 ? e[0] : e.reduce((e, t) => (...n) => e(t(...n)));
}

function Nr(...e) {
    return (t) => (n, r) => {
        let i = t(n, r),
            a = () => {
                throw Error(wr(15));
            },
            o = {
                getState: i.getState,
                dispatch: (e, ...t) => a(e, ...t)
            };
        return a = Mr(...e.map((e) => e(o)))(i.dispatch), {
            ...i,
            dispatch: a
        };
    };
}

function Pr(e) {
    return Or(e) && "type" in e && typeof e.type == "string";
}
//#endregion
//#region ../../node_modules/immer/dist/immer.mjs
var Fr = Symbol.for("immer-nothing"),
    Ir = Symbol.for("immer-draftable"),
    M = Symbol.for("immer-state");

function Lr(e, ...t) {
    throw Error(`[Immer] minified error nr: ${e}. Full error at: https://bit.ly/3cXEKWf`);
}
var Rr = Object,
    zr = Rr.getPrototypeOf,
    Br = "constructor",
    Vr = "prototype",
    Hr = "configurable",
    Ur = "enumerable",
    Wr = "writable",
    Gr = "value",
    Kr = (e) => !!e && !!e[M];

function qr(e) {
    return e ? Xr(e) || ii(e) || !!e[Ir] || !!e[Br] ? .[Ir] || ai(e) || oi(e) : !1;
}
var Jr = Rr[Vr][Br].toString(),
    Yr = /* @__PURE__ */ new WeakMap();

function Xr(e) {
    if (!e || !si(e)) return !1;
    let t = zr(e);
    if (t === null || t === Rr[Vr]) return !0;
    let n = Rr.hasOwnProperty.call(t, Br) && t[Br];
    if (n === Object) return !0;
    if (!ci(n)) return !1;
    let r = Yr.get(n);
    return r === void 0 && (r = Function.toString.call(n), Yr.set(n, r)), r === Jr;
}

function Zr(e) {
    return Kr(e) || Lr(15, e), e[M].base_;
}

function Qr(e, t, n = !0) {
    $r(e) === 0 ? (n ? Reflect.ownKeys(e) : Rr.keys(e)).forEach((n) => {
        t(n, e[n], e);
    }) : e.forEach((n, r) => t(r, n, e));
}

function $r(e) {
    let t = e[M];
    return t ? t.type_ : ii(e) ? 1 : ai(e) ? 2 : oi(e) ? 3 : 0;
}
var ei = (e, t, n = $r(e)) => n === 2 ? e.has(t) : Rr[Vr].hasOwnProperty.call(e, t),
    ti = (e, t, n = $r(e)) => n === 2 ? e.get(t) : e[t],
    ni = (e, t, n, r = $r(e)) => {
        r === 2 ? e.set(t, n) : r === 3 ? e.add(n) : e[t] = n;
    };

function ri(e, t) {
    return e === t ? e !== 0 || 1 / e == 1 / t : e !== e && t !== t;
}
var ii = Array.isArray,
    ai = (e) => e instanceof Map,
    oi = (e) => e instanceof Set,
    si = (e) => typeof e == "object",
    ci = (e) => typeof e == "function",
    li = (e) => typeof e == "boolean";

function ui(e) {
    let t = +e;
    return Number.isInteger(t) && String(t) === e;
}
var di = (e) => si(e) ? e ? .[M] : null,
    fi = (e) => e.copy_ || e.base_,
    pi = (e) => e.modified_ ? e.copy_ : e.base_;

function mi(e, t) {
    if (ai(e)) return new Map(e);
    if (oi(e)) return new Set(e);
    if (ii(e)) return Array[Vr].slice.call(e);
    let n = Xr(e);
    if (t === !0 || t === "class_only" && !n) {
        let t = Rr.getOwnPropertyDescriptors(e);
        delete t[M];
        let n = Reflect.ownKeys(t);
        for (let r = 0; r < n.length; r++) {
            let i = n[r],
                a = t[i];
            a[Wr] === !1 && (a[Wr] = !0, a[Hr] = !0), (a.get || a.set) && (t[i] = {
                [Hr]: !0,
                [Wr]: !0,
                [Ur]: a[Ur],
                [Gr]: e[i]
            });
        }
        return Rr.create(zr(e), t);
    } else {
        let t = zr(e);
        if (t !== null && n) return { ...e
        };
        let r = Rr.create(t);
        return Rr.assign(r, e);
    }
}

function hi(e, t = !1) {
    return vi(e) || Kr(e) || !qr(e) ? e : ($r(e) > 1 && Rr.defineProperties(e, {
        set: _i,
        add: _i,
        clear: _i,
        delete: _i
    }), Rr.freeze(e), t && Qr(e, (e, t) => {
        hi(t, !0);
    }, !1), e);
}

function gi() {
    Lr(2);
}
var _i = {
    [Gr]: gi
};

function vi(e) {
    return e === null || !si(e) ? !0 : Rr.isFrozen(e);
}
var yi = "MapSet",
    bi = "Patches",
    xi = "ArrayMethods",
    Si = {};

function Ci(e) {
    let t = Si[e];
    return t || Lr(0, e), t;
}
var wi = (e) => !!Si[e];

function Ti(e, t) {
    Si[e] || (Si[e] = t);
}
var Ei, Di = () => Ei,
    Oi = (e, t) => ({
        drafts_: [],
        parent_: e,
        immer_: t,
        canAutoFreeze_: !0,
        unfinalizedDrafts_: 0,
        handledSet_: /* @__PURE__ */ new Set(),
        processedForPatches_: /* @__PURE__ */ new Set(),
        mapSetPlugin_: wi(yi) ? Ci(yi) : void 0,
        arrayMethodsPlugin_: wi(xi) ? Ci(xi) : void 0
    });

function ki(e, t) {
    t && (e.patchPlugin_ = Ci(bi), e.patches_ = [], e.inversePatches_ = [], e.patchListener_ = t);
}

function Ai(e) {
    ji(e), e.drafts_.forEach(Ni), e.drafts_ = null;
}

function ji(e) {
    e === Ei && (Ei = e.parent_);
}
var Mi = (e) => Ei = Oi(Ei, e);

function Ni(e) {
    let t = e[M];
    t.type_ === 0 || t.type_ === 1 ? t.revoke_() : t.revoked_ = !0;
}

function Pi(e, t) {
    t.unfinalizedDrafts_ = t.drafts_.length;
    let n = t.drafts_[0];
    if (e !== void 0 && e !== n) {
        n[M].modified_ && (Ai(t), Lr(4)), qr(e) && (e = Fi(t, e));
        let {
            patchPlugin_: r
        } = t;
        r && r.generateReplacementPatches_(n[M].base_, e, t);
    } else e = Fi(t, n);
    return Ii(t, e, !0), Ai(t), t.patches_ && t.patchListener_(t.patches_, t.inversePatches_), e === Fr ? void 0 : e;
}

function Fi(e, t) {
    if (vi(t)) return t;
    let n = t[M];
    if (!n) return Wi(t, e.handledSet_, e);
    if (!Ri(n, e)) return t;
    if (!n.modified_) return n.base_;
    if (!n.finalized_) {
        let {
            callbacks_: t
        } = n;
        if (t)
            for (; t.length > 0;) t.pop()(e);
        Hi(n, e);
    }
    return n.copy_;
}

function Ii(e, t, n = !1) {
    !e.parent_ && e.immer_.autoFreeze_ && e.canAutoFreeze_ && hi(t, n);
}

function Li(e) {
    e.finalized_ = !0, e.scope_.unfinalizedDrafts_--;
}
var Ri = (e, t) => e.scope_ === t,
    zi = [];

function Bi(e, t, n, r) {
    let i = fi(e),
        a = e.type_;
    if (r !== void 0 && ti(i, r, a) === t) {
        ni(i, r, n, a);
        return;
    }
    if (!e.draftLocations_) {
        let t = e.draftLocations_ = /* @__PURE__ */ new Map();
        Qr(i, (e, n) => {
            if (Kr(n)) {
                let r = t.get(n) || [];
                r.push(e), t.set(n, r);
            }
        });
    }
    let o = e.draftLocations_.get(t) ? ? zi;
    for (let e of o) ni(i, e, n, a);
}

function Vi(e, t, n) {
    e.callbacks_.push(function(r) {
        let i = t;
        if (!i || !Ri(i, r)) return;
        r.mapSetPlugin_ ? .fixSetContents(i);
        let a = pi(i);
        Bi(e, i.draft_ ? ? i, a, n), Hi(i, r);
    });
}

function Hi(e, t) {
    if (e.modified_ && !e.finalized_ && (e.type_ === 3 || e.type_ === 1 && e.allIndicesReassigned_ || (e.assigned_ ? .size ? ? 0) > 0)) {
        let {
            patchPlugin_: n
        } = t;
        if (n) {
            let r = n.getPath(e);
            r && n.generatePatches_(e, r, t);
        }
        Li(e);
    }
}

function Ui(e, t, n) {
    let {
        scope_: r
    } = e;
    if (Kr(n)) {
        let i = n[M];
        Ri(i, r) && i.callbacks_.push(function() {
            Qi(e), Bi(e, n, pi(i), t);
        });
    } else qr(n) && e.callbacks_.push(function() {
        let i = fi(e);
        e.type_ === 3 ? i.has(n) && Wi(n, r.handledSet_, r) : ti(i, t, e.type_) === n && r.drafts_.length > 1 && (e.assigned_.get(t) ? ? !1) === !0 && e.copy_ && Wi(ti(e.copy_, t, e.type_), r.handledSet_, r);
    });
}

function Wi(e, t, n) {
    return !n.immer_.autoFreeze_ && n.unfinalizedDrafts_ < 1 || Kr(e) || t.has(e) || !qr(e) || vi(e) ? e : (t.add(e), Qr(e, (r, i) => {
        if (Kr(i)) {
            let t = i[M];
            Ri(t, n) && (ni(e, r, pi(t), e.type_), Li(t));
        } else qr(i) && Wi(i, t, n);
    }), e);
}

function Gi(e, t) {
    let n = ii(e),
        r = {
            type_: n ? 1 : 0,
            scope_: t ? t.scope_ : Di(),
            modified_: !1,
            finalized_: !1,
            assigned_: void 0,
            parent_: t,
            base_: e,
            draft_: null,
            copy_: null,
            revoke_: null,
            isManual_: !1,
            callbacks_: void 0
        },
        i = r,
        a = Ki;
    n && (i = [r], a = qi);
    let {
        revoke: o,
        proxy: s
    } = Proxy.revocable(i, a);
    return r.draft_ = s, r.revoke_ = o, [s, r];
}
var Ki = {
        get(e, t) {
            if (t === M) return e;
            let n = e.scope_.arrayMethodsPlugin_,
                r = e.type_ === 1 && typeof t == "string";
            if (r && n ? .isArrayOperationMethod(t)) return n.createMethodInterceptor(e, t);
            let i = fi(e);
            if (!ei(i, t, e.type_)) return Yi(e, i, t);
            let a = i[t];
            if (e.finalized_ || !qr(a) || r && e.operationMethod && n ? .isMutatingArrayMethod(e.operationMethod) && ui(t)) return a;
            if (a === Ji(e.base_, t)) {
                Qi(e);
                let n = e.type_ === 1 ? +t : t,
                    r = ea(e.scope_, a, e, n);
                return e.copy_[n] = r;
            }
            return a;
        },
        has(e, t) {
            return t in fi(e);
        },
        ownKeys(e) {
            return Reflect.ownKeys(fi(e));
        },
        set(e, t, n) {
            let r = Xi(fi(e), t);
            if (r ? .set) return r.set.call(e.draft_, n), !0;
            if (!e.modified_) {
                let r = Ji(fi(e), t),
                    i = r ? .[M];
                if (i && i.base_ === n) return e.copy_[t] = n, e.assigned_.set(t, !1), !0;
                if (ri(n, r) && (n !== void 0 || ei(e.base_, t, e.type_))) return !0;
                Qi(e), Zi(e);
            }
            return e.copy_[t] === n && (n !== void 0 || t in e.copy_) || Number.isNaN(n) && Number.isNaN(e.copy_[t]) ? !0 : (e.copy_[t] = n, e.assigned_.set(t, !0), Ui(e, t, n), !0);
        },
        deleteProperty(e, t) {
            return Qi(e), Ji(e.base_, t) !== void 0 || t in e.base_ ? (e.assigned_.set(t, !1), Zi(e)) : e.assigned_.delete(t), e.copy_ && delete e.copy_[t], !0;
        },
        getOwnPropertyDescriptor(e, t) {
            let n = fi(e),
                r = Reflect.getOwnPropertyDescriptor(n, t);
            return r && {
                [Wr]: !0,
                [Hr]: e.type_ !== 1 || t !== "length",
                [Ur]: r[Ur],
                [Gr]: n[t]
            };
        },
        defineProperty() {
            Lr(11);
        },
        getPrototypeOf(e) {
            return zr(e.base_);
        },
        setPrototypeOf() {
            Lr(12);
        }
    },
    qi = {};
for (let e in Ki) {
    let t = Ki[e];
    qi[e] = function() {
        let e = arguments;
        return e[0] = e[0][0], t.apply(this, e);
    };
}
qi.deleteProperty = function(e, t) {
    return qi.set.call(this, e, t, void 0);
}, qi.set = function(e, t, n) {
    return Ki.set.call(this, e[0], t, n, e[0]);
};

function Ji(e, t) {
    let n = e[M];
    return (n ? fi(n) : e)[t];
}

function Yi(e, t, n) {
    let r = Xi(t, n);
    return r ? Gr in r ? r[Gr] : r.get ? .call(e.draft_) : void 0;
}

function Xi(e, t) {
    if (!(t in e)) return;
    let n = zr(e);
    for (; n;) {
        let e = Object.getOwnPropertyDescriptor(n, t);
        if (e) return e;
        n = zr(n);
    }
}

function Zi(e) {
    e.modified_ || (e.modified_ = !0, e.parent_ && Zi(e.parent_));
}

function Qi(e) {
    e.copy_ || = (e.assigned_ = /* @__PURE__ */ new Map(), mi(e.base_, e.scope_.immer_.useStrictShallowCopy_));
}
var $i = class {
    constructor(e) {
        this.autoFreeze_ = !0, this.useStrictShallowCopy_ = !1, this.useStrictIteration_ = !1, this.produce = (e, t, n) => {
            if (ci(e) && !ci(t)) {
                let n = t;
                t = e;
                let r = this;
                return function(e = n, ...i) {
                    return r.produce(e, (e) => t.call(this, e, ...i));
                };
            }
            ci(t) || Lr(6), n !== void 0 && !ci(n) && Lr(7);
            let r;
            if (qr(e)) {
                let i = Mi(this),
                    a = ea(i, e, void 0),
                    o = !0;
                try {
                    r = t(a), o = !1;
                } finally {
                    o ? Ai(i) : ji(i);
                }
                return ki(i, n), Pi(r, i);
            } else if (!e || !si(e)) {
                if (r = t(e), r === void 0 && (r = e), r === Fr && (r = void 0), this.autoFreeze_ && hi(r, !0), n) {
                    let t = [],
                        i = [];
                    Ci(bi).generateReplacementPatches_(e, r, {
                        patches_: t,
                        inversePatches_: i
                    }), n(t, i);
                }
                return r;
            } else Lr(1, e);
        }, this.produceWithPatches = (e, t) => {
            if (ci(e)) return (t, ...n) => this.produceWithPatches(t, (t) => e(t, ...n));
            let n, r;
            return [
                this.produce(e, t, (e, t) => {
                    n = e, r = t;
                }),
                n,
                r
            ];
        }, li(e ? .autoFreeze) && this.setAutoFreeze(e.autoFreeze), li(e ? .useStrictShallowCopy) && this.setUseStrictShallowCopy(e.useStrictShallowCopy), li(e ? .useStrictIteration) && this.setUseStrictIteration(e.useStrictIteration);
    }
    createDraft(e) {
        qr(e) || Lr(8), Kr(e) && (e = ta(e));
        let t = Mi(this),
            n = ea(t, e, void 0);
        return n[M].isManual_ = !0, ji(t), n;
    }
    finishDraft(e, t) {
        let n = e && e[M];
        (!n || !n.isManual_) && Lr(9);
        let {
            scope_: r
        } = n;
        return ki(r, t), Pi(void 0, r);
    }
    setAutoFreeze(e) {
        this.autoFreeze_ = e;
    }
    setUseStrictShallowCopy(e) {
        this.useStrictShallowCopy_ = e;
    }
    setUseStrictIteration(e) {
        this.useStrictIteration_ = e;
    }
    shouldUseStrictIteration() {
        return this.useStrictIteration_;
    }
    applyPatches(e, t) {
        let n;
        for (n = t.length - 1; n >= 0; n--) {
            let r = t[n];
            if (r.path.length === 0 && r.op === "replace") {
                e = r.value;
                break;
            }
        }
        n > -1 && (t = t.slice(n + 1));
        let r = Ci(bi).applyPatches_;
        return Kr(e) ? r(e, t) : this.produce(e, (e) => r(e, t));
    }
};

function ea(e, t, n, r) {
    let [i, a] = ai(t) ? Ci(yi).proxyMap_(t, n) : oi(t) ? Ci(yi).proxySet_(t, n) : Gi(t, n);
    return (n ? .scope_ ? ? Di()).drafts_.push(i), a.callbacks_ = n ? .callbacks_ ? ? [], a.key_ = r, n && r !== void 0 ? Vi(n, a, r) : a.callbacks_.push(function(e) {
        e.mapSetPlugin_ ? .fixSetContents(a);
        let {
            patchPlugin_: t
        } = e;
        a.modified_ && t && t.generatePatches_(a, [], e);
    }), i;
}

function ta(e) {
    return Kr(e) || Lr(10, e), na(e);
}

function na(e) {
    if (!qr(e) || vi(e)) return e;
    let t = e[M],
        n, r = !0;
    if (t) {
        if (!t.modified_) return t.base_;
        t.finalized_ = !0, n = mi(e, t.scope_.immer_.useStrictShallowCopy_), r = t.scope_.immer_.shouldUseStrictIteration();
    } else n = mi(e, !0);
    return Qr(n, (e, t) => {
        ni(n, e, na(t));
    }, r), t && (t.finalized_ = !1), n;
}

function ra() {
    function e(n, r = []) {
        if (n.key_ !== void 0) {
            let e = n.parent_.copy_ ? ? n.parent_.base_,
                t = di(ti(e, n.key_)),
                i = ti(e, n.key_);
            if (i === void 0 || i !== n.draft_ && i !== n.base_ && i !== n.copy_ || t != null && t.base_ !== n.base_) return null;
            let a = n.parent_.type_ === 3,
                o;
            if (a) {
                let e = n.parent_;
                o = Array.from(e.drafts_.keys()).indexOf(n.key_);
            } else o = n.key_;
            if (!(a && e.size > o || ei(e, o))) return null;
            r.push(o);
        }
        if (n.parent_) return e(n.parent_, r);
        r.reverse();
        try {
            t(n.copy_, r);
        } catch {
            return null;
        }
        return r;
    }

    function t(e, t) {
        let n = e;
        for (let e = 0; e < t.length - 1; e++) {
            let r = t[e];
            if (n = ti(n, r), !si(n) || n === null) throw Error(`Cannot resolve path at '${t.join("/")}'`);
        }
        return n;
    }
    let n = "replace",
        r = "remove";

    function i(e, t, n) {
        if (e.scope_.processedForPatches_.has(e)) return;
        e.scope_.processedForPatches_.add(e);
        let {
            patches_: r,
            inversePatches_: i
        } = n;
        switch (e.type_) {
            case 0:
            case 2:
                return o(e, t, r, i);
            case 1:
                return a(e, t, r, i);
            case 3:
                return s(e, t, r, i);
        }
    }

    function a(e, t, i, a) {
        let {
            base_: o,
            assigned_: s
        } = e, c = e.copy_;
        c.length < o.length && ([o, c] = [c, o], [i, a] = [a, i]);
        let l = e.allIndicesReassigned_ === !0;
        for (let e = 0; e < o.length; e++) {
            let r = c[e],
                u = o[e];
            if ((l || s ? .get(e.toString())) && r !== u) {
                let o = r ? .[M];
                if (o && o.modified_) continue;
                let s = t.concat([e]);
                i.push({
                    op: n,
                    path: s,
                    value: d(r)
                }), a.push({
                    op: n,
                    path: s,
                    value: d(u)
                });
            }
        }
        for (let e = o.length; e < c.length; e++) {
            let n = t.concat([e]);
            i.push({
                op: "add",
                path: n,
                value: d(c[e])
            });
        }
        for (let e = c.length - 1; o.length <= e; --e) {
            let n = t.concat([e]);
            a.push({
                op: r,
                path: n
            });
        }
    }

    function o(e, t, i, a) {
        let {
            base_: o,
            copy_: s,
            type_: c
        } = e;
        Qr(e.assigned_, (e, l) => {
            let u = ti(o, e, c),
                f = ti(s, e, c),
                p = l ? ei(o, e) ? n : "add" : r;
            if (u === f && p === n) return;
            let m = t.concat(e);
            i.push(p === r ? {
                op: p,
                path: m
            } : {
                op: p,
                path: m,
                value: d(f)
            }), a.push(p === "add" ? {
                op: r,
                path: m
            } : p === r ? {
                op: "add",
                path: m,
                value: d(u)
            } : {
                op: n,
                path: m,
                value: d(u)
            });
        });
    }

    function s(e, t, n, i) {
        let {
            base_: a,
            copy_: o
        } = e, s = 0;
        a.forEach((e) => {
            if (!o.has(e)) {
                let a = t.concat([s]);
                n.push({
                    op: r,
                    path: a,
                    value: e
                }), i.unshift({
                    op: "add",
                    path: a,
                    value: e
                });
            }
            s++;
        }), s = 0, o.forEach((e) => {
            if (!a.has(e)) {
                let a = t.concat([s]);
                n.push({
                    op: "add",
                    path: a,
                    value: e
                }), i.unshift({
                    op: r,
                    path: a,
                    value: e
                });
            }
            s++;
        });
    }

    function c(e, t, r) {
        let {
            patches_: i,
            inversePatches_: a
        } = r;
        i.push({
            op: n,
            path: [],
            value: t === Fr ? void 0 : t
        }), a.push({
            op: n,
            path: [],
            value: e
        });
    }

    function l(e, t) {
        return t.forEach((t) => {
            let {
                path: i,
                op: a
            } = t, o = e;
            for (let e = 0; e < i.length - 1; e++) {
                let t = $r(o),
                    n = i[e];
                typeof n != "string" && typeof n != "number" && (n = "" + n), (t === 0 || t === 1) && (n === "__proto__" || n === Br) && Lr(19), ci(o) && n === Vr && Lr(19), o = ti(o, n), si(o) || Lr(18, i.join("/"));
            }
            let s = $r(o),
                c = u(t.value),
                l = i[i.length - 1];
            switch (a) {
                case n:
                    switch (s) {
                        case 2:
                            return o.set(l, c);
                        case 3:
                            Lr(16);
                        default:
                            return o[l] = c;
                    }
                case "add":
                    switch (s) {
                        case 1:
                            return l === "-" ? o.push(c) : o.splice(l, 0, c);
                        case 2:
                            return o.set(l, c);
                        case 3:
                            return o.add(c);
                        default:
                            return o[l] = c;
                    }
                case r:
                    switch (s) {
                        case 1:
                            return o.splice(l, 1);
                        case 2:
                            return o.delete(l);
                        case 3:
                            return o.delete(t.value);
                        default:
                            return delete o[l];
                    }
                default:
                    Lr(17, a);
            }
        }), e;
    }

    function u(e) {
        if (!qr(e)) return e;
        if (ii(e)) return e.map(u);
        if (ai(e)) return new Map(Array.from(e.entries()).map(([e, t]) => [e, u(t)]));
        if (oi(e)) return new Set(Array.from(e).map(u));
        let t = Object.create(zr(e));
        for (let n in e) t[n] = u(e[n]);
        return ei(e, Ir) && (t[Ir] = e[Ir]), t;
    }

    function d(e) {
        return Kr(e) ? u(e) : e;
    }
    Ti(bi, {
        applyPatches_: l,
        generatePatches_: i,
        generateReplacementPatches_: c,
        getPath: e
    });
}
var ia = new $i(),
    aa = ia.produce,
    oa = /* @__PURE__ */ ia.produceWithPatches.bind(ia),
    sa = /* @__PURE__ */ ia.applyPatches.bind(ia);
//#endregion
//#region ../../node_modules/reselect/dist/reselect.mjs
function ca(e, t = `expected a function, instead received ${typeof e}`) {
    if (typeof e != "function") throw TypeError(t);
}

function la(e, t = "expected all items to be functions, instead received the following types: ") {
    if (!e.every((e) => typeof e == "function")) {
        let n = e.map((e) => typeof e == "function" ? `function ${e.name || "unnamed"}()` : typeof e).join(", ");
        throw TypeError(`${t}[${n}]`);
    }
}
var ua = (e) => Array.isArray(e) ? e : [e];

function da(e) {
    let t = Array.isArray(e[0]) ? e[0] : e;
    return la(t, "createSelector expects all input-selectors to be functions, but received the following types: "), t;
}

function fa(e, t) {
    let n = [],
        {
            length: r
        } = e;
    for (let i = 0; i < r; i++) n.push(e[i].apply(null, t));
    return n;
}
var pa = class {
        constructor(e) {
            this.value = e;
        }
        deref() {
            return this.value;
        }
    },
    ma = typeof WeakRef > "u" ? pa : WeakRef,
    ha = 0,
    ga = 1;

function _a() {
    return {
        s: ha,
        v: void 0,
        o: null,
        p: null
    };
}

function va(e) {
    return e instanceof ma ? e.deref() : e;
}

function ya(e, t = {}) {
    let n = _a(),
        {
            resultEqualityCheck: r
        } = t,
        i, a = 0;

    function o() {
        let t = n,
            {
                length: o
            } = arguments;
        for (let e = 0, n = o; e < n; e++) {
            let n = arguments[e];
            if (typeof n == "function" || typeof n == "object" && n) {
                let e = t.o;
                e === null && (t.o = e = /* @__PURE__ */ new WeakMap());
                let r = e.get(n);
                r === void 0 ? (t = _a(), e.set(n, t)) : t = r;
            } else {
                let e = t.p;
                e === null && (t.p = e = /* @__PURE__ */ new Map());
                let r = e.get(n);
                r === void 0 ? (t = _a(), e.set(n, t)) : t = r;
            }
        }
        let s = t,
            c;
        if (t.s === ga) c = t.v;
        else if (c = e.apply(null, arguments), a++, r) {
            let e = va(i);
            e != null && r(e, c) && (c = e, a !== 0 && a--), i = typeof c == "object" && c || typeof c == "function" ? /* @__PURE__ */ new ma(c) : c;
        }
        return s.s = ga, s.v = c, c;
    }
    return o.clearCache = () => {
        n = _a(), o.resetResultsCount();
    }, o.resultsCount = () => a, o.resetResultsCount = () => {
        a = 0;
    }, o;
}

function ba(e, ...t) {
    let n = typeof e == "function" ? {
            memoize: e,
            memoizeOptions: t
        } : e,
        r = (...e) => {
            let t = 0,
                r = 0,
                i, a = {},
                o = e.pop();
            typeof o == "object" && (a = o, o = e.pop()), ca(o, `createSelector expects an output function after the inputs, but received: [${typeof o}]`);
            let {
                memoize: s,
                memoizeOptions: c = [],
                argsMemoize: l = ya,
                argsMemoizeOptions: u = []
            } = {
                ...n,
                ...a
            }, d = ua(c), f = ua(u), p = da(e), m = s(function() {
                return t++, o.apply(null, arguments);
            }, ...d), h = l(function() {
                r++;
                let e = fa(p, arguments);
                return i = m.apply(null, e), i;
            }, ...f);
            return Object.assign(h, {
                resultFunc: o,
                memoizedResultFunc: m,
                dependencies: p,
                dependencyRecomputations: () => r,
                resetDependencyRecomputations: () => {
                    r = 0;
                },
                lastResult: () => i,
                recomputations: () => t,
                resetRecomputations: () => {
                    t = 0;
                },
                memoize: s,
                argsMemoize: l
            });
        };
    return Object.assign(r, {
        withTypes: () => r
    }), r;
}
var xa = /* @__PURE__ */ ba(ya);
//#endregion
//#region ../../node_modules/redux-thunk/dist/redux-thunk.mjs
function Sa(e) {
    return ({
        dispatch: t,
        getState: n
    }) => (r) => (i) => typeof i == "function" ? i(t, n, e) : r(i);
}
var Ca = Sa(),
    wa = Sa,
    Ta = typeof window < "u" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : function() {
        if (arguments.length !== 0) return typeof arguments[0] == "object" ? Mr : Mr.apply(null, arguments);
    };
typeof window < "u" && window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__;
var Ea = (e) => e && typeof e.match == "function";

function Da(e, t) {
    function n(...n) {
        if (t) {
            let r = t(...n);
            if (!r) throw Error(Eo(0));
            return {
                type: e,
                payload: r.payload,
                ..."meta" in r && {
                    meta: r.meta
                },
                ..."error" in r && {
                    error: r.error
                }
            };
        }
        return {
            type: e,
            payload: n[0]
        };
    }
    return n.toString = () => `${e}`, n.type = e, n.match = (t) => Pr(t) && t.type === e, n;
}
var Oa = class e extends Array {
    constructor(...t) {
        super(...t), Object.setPrototypeOf(this, e.prototype);
    }
    static get[Symbol.species]() {
        return e;
    }
    concat(...e) {
        return super.concat.apply(this, e);
    }
    prepend(...t) {
        return t.length === 1 && Array.isArray(t[0]) ? new e(...t[0].concat(this)) : new e(...t.concat(this));
    }
};

function ka(e) {
    return qr(e) ? aa(e, () => {}) : e;
}

function Aa(e, t, n) {
    return e.has(t) ? e.get(t) : e.set(t, n(t)).get(t);
}

function ja(e) {
    return typeof e == "boolean";
}
var Ma = () => function(e) {
        let {
            thunk: t = !0,
            immutableCheck: n = !0,
            serializableCheck: r = !0,
            actionCreatorCheck: i = !0
        } = e ? ? {}, a = new Oa();
        return t && (ja(t) ? a.push(Ca) : a.push(wa(t.extraArgument))), a;
    },
    Na = "RTK_autoBatch",
    Pa = () => (e) => ({
        payload: e,
        meta: {
            [Na]: !0
        }
    }),
    Fa = (e) => (t) => {
        setTimeout(t, e);
    },
    Ia = (e = {
        type: "raf"
    }) => (t) => (...n) => {
        let r = t(...n),
            i = !0,
            a = !1,
            o = !1,
            s = /* @__PURE__ */ new Set(),
            c = e.type === "tick" ? queueMicrotask : e.type === "raf" ? typeof window < "u" && window.requestAnimationFrame ? window.requestAnimationFrame : Fa(10) : e.type === "callback" ? e.queueNotification : Fa(e.timeout),
            l = () => {
                o = !1, a && (a = !1, s.forEach((e) => e()));
            };
        return Object.assign({}, r, {
            subscribe(e) {
                let t = r.subscribe(() => i && e());
                return s.add(e), () => {
                    t(), s.delete(e);
                };
            },
            dispatch(e) {
                try {
                    return i = !e ? .meta ? .[Na], a = !i, a && (o || (o = !0, c(l))), r.dispatch(e);
                } finally {
                    i = !0;
                }
            }
        });
    },
    La = (e) => function(t) {
        let {
            autoBatch: n = !0
        } = t ? ? {}, r = new Oa(e);
        return n && r.push(Ia(typeof n == "object" ? n : void 0)), r;
    };

function Ra(e) {
    let t = Ma(),
        {
            reducer: n = void 0,
            middleware: r,
            devTools: i = !0,
            duplicateMiddlewareCheck: a = !0,
            preloadedState: o = void 0,
            enhancers: s = void 0
        } = e || {},
        c;
    if (typeof n == "function") c = n;
    else if (Or(n)) c = jr(n);
    else throw Error(Eo(1));
    let l;
    l = typeof r == "function" ? r(t) : t();
    let u = Mr;
    i && (u = Ta({
        trace: !1,
        ...typeof i == "object" && i
    }));
    let d = La(Nr(...l)),
        f = typeof s == "function" ? s(d) : d(),
        p = u(...f);
    return kr(c, o, p);
}

function za(e) {
    let t = {},
        n = [],
        r, i = {
            addCase(e, n) {
                let r = typeof e == "string" ? e : e.type;
                if (!r) throw Error(Eo(28));
                if (r in t) throw Error(Eo(29));
                return t[r] = n, i;
            },
            addAsyncThunk(e, r) {
                return r.pending && (t[e.pending.type] = r.pending), r.rejected && (t[e.rejected.type] = r.rejected), r.fulfilled && (t[e.fulfilled.type] = r.fulfilled), r.settled && n.push({
                    matcher: e.settled,
                    reducer: r.settled
                }), i;
            },
            addMatcher(e, t) {
                return n.push({
                    matcher: e,
                    reducer: t
                }), i;
            },
            addDefaultCase(e) {
                return r = e, i;
            }
        };
    return e(i), [
        t,
        n,
        r
    ];
}

function Ba(e) {
    return typeof e == "function";
}

function Va(e, t) {
    let [n, r, i] = za(t), a;
    if (Ba(e)) a = () => ka(e());
    else {
        let t = ka(e);
        a = () => t;
    }

    function o(e = a(), t) {
        let o = [n[t.type], ...r.filter(({
            matcher: e
        }) => e(t)).map(({
            reducer: e
        }) => e)];
        return o.filter((e) => !!e).length === 0 && (o = [i]), o.reduce((e, n) => {
            if (n)
                if (Kr(e)) {
                    let r = n(e, t);
                    return r === void 0 ? e : r;
                } else if (qr(e)) return aa(e, (e) => n(e, t));
            else {
                let r = n(e, t);
                if (r === void 0) {
                    if (e === null) return e;
                    throw Error("A case reducer on a non-draftable value must not return undefined");
                }
                return r;
            }
            return e;
        }, e);
    }
    return o.getInitialState = a, o;
}
var Ha = (e, t) => Ea(e) ? e.match(t) : e(t);

function Ua(...e) {
    return (t) => e.some((e) => Ha(e, t));
}

function Wa(...e) {
    return (t) => e.every((e) => Ha(e, t));
}

function Ga(e, t) {
    if (!e || !e.meta) return !1;
    let n = typeof e.meta.requestId == "string",
        r = t.indexOf(e.meta.requestStatus) > -1;
    return n && r;
}

function Ka(e) {
    return typeof e[0] == "function" && "pending" in e[0] && "fulfilled" in e[0] && "rejected" in e[0];
}

function qa(...e) {
    return e.length === 0 ? (e) => Ga(e, ["pending"]) : Ka(e) ? Ua(...e.map((e) => e.pending)) : qa()(e[0]);
}

function Ja(...e) {
    return e.length === 0 ? (e) => Ga(e, ["rejected"]) : Ka(e) ? Ua(...e.map((e) => e.rejected)) : Ja()(e[0]);
}

function Ya(...e) {
    let t = (e) => e && e.meta && e.meta.rejectedWithValue;
    return e.length === 0 || Ka(e) ? Wa(Ja(...e), t) : Ya()(e[0]);
}

function Xa(...e) {
    return e.length === 0 ? (e) => Ga(e, ["fulfilled"]) : Ka(e) ? Ua(...e.map((e) => e.fulfilled)) : Xa()(e[0]);
}

function Za(...e) {
    return e.length === 0 ? (e) => Ga(e, [
        "pending",
        "fulfilled",
        "rejected"
    ]) : Ka(e) ? Ua(...e.flatMap((e) => [
        e.pending,
        e.rejected,
        e.fulfilled
    ])) : Za()(e[0]);
}
var Qa = "ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW",
    $a = (e = 21) => {
        let t = "",
            n = e;
        for (; n--;) t += Qa[Math.random() * 64 | 0];
        return t;
    },
    eo = [
        "name",
        "message",
        "stack",
        "code"
    ],
    to = class {
        constructor(e, t) {
            j(this, "_type", void 0), this.payload = e, this.meta = t;
        }
    },
    no = class {
        constructor(e, t) {
            j(this, "_type", void 0), this.payload = e, this.meta = t;
        }
    },
    ro = (e) => {
        if (typeof e == "object" && e) {
            let t = {};
            for (let n of eo) typeof e[n] == "string" && (t[n] = e[n]);
            return t;
        }
        return {
            message: String(e)
        };
    },
    io = "External signal was aborted",
    ao = /* @__PURE__ */ (() => {
        function e(e, t, n) {
            let r = Da(e + "/fulfilled", (e, t, n, r) => ({
                    payload: e,
                    meta: {
                        ...r || {},
                        arg: n,
                        requestId: t,
                        requestStatus: "fulfilled"
                    }
                })),
                i = Da(e + "/pending", (e, t, n) => ({
                    payload: void 0,
                    meta: {
                        ...n || {},
                        arg: t,
                        requestId: e,
                        requestStatus: "pending"
                    }
                })),
                a = Da(e + "/rejected", (e, t, r, i, a) => ({
                    payload: i,
                    error: (n && n.serializeError || ro)(e || "Rejected"),
                    meta: {
                        ...a || {},
                        arg: r,
                        requestId: t,
                        rejectedWithValue: !!i,
                        requestStatus: "rejected",
                        aborted: e ? .name === "AbortError",
                        condition: e ? .name === "ConditionError"
                    }
                }));

            function o(e, {
                signal: o
            } = {}) {
                return (s, c, l) => {
                    let u = n ? .idGenerator ? n.idGenerator(e) : $a(),
                        d = new AbortController(),
                        f, p;

                    function m(e) {
                        p = e, d.abort();
                    }
                    o && (o.aborted ? m(io) : o.addEventListener("abort", () => m(io), {
                        once: !0
                    }));
                    let h = async function() {
                        let o;
                        try {
                            let a = n ? .condition ? .(e, {
                                getState: c,
                                extra: l
                            });
                            if (so(a) && (a = await a), a === !1 || d.signal.aborted) throw {
                                name: "ConditionError",
                                message: "Aborted due to condition callback returning false."
                            };
                            let h = new Promise((e, t) => {
                                f = () => {
                                    t({
                                        name: "AbortError",
                                        message: p || "Aborted"
                                    });
                                }, d.signal.addEventListener("abort", f, {
                                    once: !0
                                });
                            });
                            s(i(u, e, n ? .getPendingMeta ? .({
                                requestId: u,
                                arg: e
                            }, {
                                getState: c,
                                extra: l
                            }))), o = await Promise.race([h, Promise.resolve(t(e, {
                                dispatch: s,
                                getState: c,
                                extra: l,
                                requestId: u,
                                signal: d.signal,
                                abort: m,
                                rejectWithValue: (e, t) => new to(e, t),
                                fulfillWithValue: (e, t) => new no(e, t)
                            })).then((t) => {
                                if (t instanceof to) throw t;
                                return t instanceof no ? r(t.payload, u, e, t.meta) : r(t, u, e);
                            })]);
                        } catch (t) {
                            o = t instanceof to ? a(null, u, e, t.payload, t.meta) : a(t, u, e);
                        } finally {
                            f && d.signal.removeEventListener("abort", f);
                        }
                        return n && !n.dispatchConditionRejection && a.match(o) && o.meta.condition || s(o), o;
                    }();
                    return Object.assign(h, {
                        abort: m,
                        requestId: u,
                        arg: e,
                        unwrap() {
                            return h.then(oo);
                        }
                    });
                };
            }
            return Object.assign(o, {
                pending: i,
                rejected: a,
                fulfilled: r,
                settled: Ua(a, r),
                typePrefix: e
            });
        }
        return e.withTypes = () => e, e;
    })();

function oo(e) {
    if (e.meta && e.meta.rejectedWithValue) throw e.payload;
    if (e.error) throw e.error;
    return e.payload;
}

function so(e) {
    return typeof e == "object" && !!e && typeof e.then == "function";
}
var co = /* @__PURE__ */ Symbol.for("rtk-slice-createasyncthunk");

function lo(e, t) {
    return `${e}/${t}`;
}

function uo({
    creators: e
} = {}) {
    let t = e ? .asyncThunk ? .[co];
    return function(e) {
        let {
            name: n,
            reducerPath: r = n
        } = e;
        if (!n) throw Error(Eo(11));
        let i = (typeof e.reducers == "function" ? e.reducers(po()) : e.reducers) || {},
            a = Object.keys(i),
            o = {
                sliceCaseReducersByName: {},
                sliceCaseReducersByType: {},
                actionCreators: {},
                sliceMatchers: []
            },
            s = {
                addCase(e, t) {
                    let n = typeof e == "string" ? e : e.type;
                    if (!n) throw Error(Eo(12));
                    if (n in o.sliceCaseReducersByType) throw Error(Eo(13));
                    return o.sliceCaseReducersByType[n] = t, s;
                },
                addMatcher(e, t) {
                    return o.sliceMatchers.push({
                        matcher: e,
                        reducer: t
                    }), s;
                },
                exposeAction(e, t) {
                    return o.actionCreators[e] = t, s;
                },
                exposeCaseReducer(e, t) {
                    return o.sliceCaseReducersByName[e] = t, s;
                }
            };
        a.forEach((r) => {
            let a = i[r],
                o = {
                    reducerName: r,
                    type: lo(n, r),
                    createNotation: typeof e.reducers == "function"
                };
            ho(a) ? _o(o, a, s, t) : mo(o, a, s);
        });

        function c() {
            let [t = {}, n = [], r = void 0] = typeof e.extraReducers == "function" ? za(e.extraReducers) : [e.extraReducers], i = {
                ...t,
                ...o.sliceCaseReducersByType
            };
            return Va(e.initialState, (e) => {
                for (let t in i) e.addCase(t, i[t]);
                for (let t of o.sliceMatchers) e.addMatcher(t.matcher, t.reducer);
                for (let t of n) e.addMatcher(t.matcher, t.reducer);
                r && e.addDefaultCase(r);
            });
        }
        let l = (e) => e,
            u = /* @__PURE__ */ new Map(),
            d = /* @__PURE__ */ new WeakMap(),
            f;

        function p(e, t) {
            return f || = c(), f(e, t);
        }

        function m() {
            return f || = c(), f.getInitialState();
        }

        function h(t, n = !1) {
            function r(e) {
                let i = e[t];
                return i === void 0 && n && (i = Aa(d, r, m)), i;
            }

            function i(t = l) {
                return Aa(Aa(u, n, () => /* @__PURE__ */ new WeakMap()), t, () => {
                    let r = {};
                    for (let [i, a] of Object.entries(e.selectors ? ? {})) r[i] = fo(a, t, () => Aa(d, t, m), n);
                    return r;
                });
            }
            return {
                reducerPath: t,
                getSelectors: i,
                get selectors() {
                    return i(r);
                },
                selectSlice: r
            };
        }
        let g = {
            name: n,
            reducer: p,
            actions: o.actionCreators,
            caseReducers: o.sliceCaseReducersByName,
            getInitialState: m,
            ...h(r),
            injectInto(e, {
                reducerPath: t,
                ...n
            } = {}) {
                let i = t ? ? r;
                return e.inject({
                    reducerPath: i,
                    reducer: p
                }, n), {
                    ...g,
                    ...h(i, !0)
                };
            }
        };
        return g;
    };
}

function fo(e, t, n, r) {
    function i(i, ...a) {
        let o = t(i);
        return o === void 0 && r && (o = n()), e(o, ...a);
    }
    return i.unwrapped = e, i;
}
var N = /* @__PURE__ */ uo();

function po() {
    function e(e, t) {
        return {
            _reducerDefinitionType: "asyncThunk",
            payloadCreator: e,
            ...t
        };
    }
    return e.withTypes = () => e, {
        reducer(e) {
            return Object.assign({
                [e.name](...t) {
                    return e(...t);
                }
            }[e.name], {
                _reducerDefinitionType: "reducer"
            });
        },
        preparedReducer(e, t) {
            return {
                _reducerDefinitionType: "reducerWithPrepare",
                prepare: e,
                reducer: t
            };
        },
        asyncThunk: e
    };
}

function mo({
    type: e,
    reducerName: t,
    createNotation: n
}, r, i) {
    let a, o;
    if ("reducer" in r) {
        if (n && !go(r)) throw Error(Eo(17));
        a = r.reducer, o = r.prepare;
    } else a = r;
    i.addCase(e, a).exposeCaseReducer(t, a).exposeAction(t, o ? Da(e, o) : Da(e));
}

function ho(e) {
    return e._reducerDefinitionType === "asyncThunk";
}

function go(e) {
    return e._reducerDefinitionType === "reducerWithPrepare";
}

function _o({
    type: e,
    reducerName: t
}, n, r, i) {
    if (!i) throw Error(Eo(18));
    let {
        payloadCreator: a,
        fulfilled: o,
        pending: s,
        rejected: c,
        settled: l,
        options: u
    } = n, d = i(e, a, u);
    r.exposeAction(t, d), o && r.addCase(d.fulfilled, o), s && r.addCase(d.pending, s), c && r.addCase(d.rejected, c), l && r.addMatcher(d.settled, l), r.exposeCaseReducer(t, {
        fulfilled: o || vo,
        pending: s || vo,
        rejected: c || vo,
        settled: l || vo
    });
}

function vo() {}
var yo = "listener",
    bo = "completed",
    xo = "cancelled";
`${xo}`, `${bo}`, `${yo}${xo}`, `${yo}${bo}`;
var {
    assign: So
} = Object, Co = "listenerMiddleware", wo = /* @__PURE__ */ So( /* @__PURE__ */ Da(`${Co}/add`), {
    withTypes: () => wo
});
`${Co}`;
var To = /* @__PURE__ */ So( /* @__PURE__ */ Da(`${Co}/remove`), {
    withTypes: () => To
});

function Eo(e) {
    return `Minified Redux Toolkit error #${e}; visit https://redux-toolkit.js.org/Errors?code=${e} for the full message or use the non-minified dev environment for full errors. `;
}
//#endregion
//#region src/store/security-slice.ts
var Do = 300 * 1e3,
    Oo = {
        turnstileSiteKey: null,
        turnstileToken: null,
        tokenReceivedAt: null,
        challengeError: null
    },
    ko = N({
        name: "security",
        initialState: Oo,
        extraReducers: (e) => {
            e.addCase("chat/chatCleared", (e) => {
                e.turnstileToken = null, e.tokenReceivedAt = null, e.challengeError = null;
            });
        },
        reducers: {
            turnstileSiteKeySet(e, t) {
                e.turnstileSiteKey = t.payload;
            },
            turnstileTokenSet(e, t) {
                e.turnstileToken = t.payload, e.tokenReceivedAt = Date.now(), e.challengeError = null;
            },
            turnstileTokenCleared(e) {
                e.turnstileToken = null, e.tokenReceivedAt = null;
            },
            challengeErrorSet(e, t) {
                e.challengeError = t.payload, e.turnstileToken = null, e.tokenReceivedAt = null;
            },
            securityReset() {
                return Oo;
            }
        }
    }),
    {
        turnstileSiteKeySet: Ao,
        turnstileTokenSet: jo,
        turnstileTokenCleared: Mo,
        challengeErrorSet: No,
        securityReset: Po
    } = ko.actions,
    Fo = (e) => e.security.turnstileToken,
    Io = (e) => {
        let {
            tokenReceivedAt: t
        } = e.security;
        return t ? Date.now() - t > Do : !0;
    },
    Lo = (e) => e.security.turnstileToken ? !Io(e) : !1,
    Ro = "messagingAuthState";

function zo(e) {
    let {
        messagingToken: t,
        messagingTokenExpiresAt: n,
        sessionRefreshToken: r,
        refreshGeneration: i
    } = e;
    return typeof t != "string" || !t || typeof n != "number" || !Number.isFinite(n) || n <= 0 || typeof r != "string" || !r || typeof i != "number" || !Number.isInteger(i) || i < 1 ? null : {
        messagingToken: t,
        messagingTokenExpiresAt: n,
        sessionRefreshToken: r,
        refreshGeneration: i,
        ...typeof e.sessionCookieIssued == "boolean" ? {
            sessionCookieIssued: e.sessionCookieIssued
        } : {}
    };
}

function Bo(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e),
            n = t.ownerChatterToken,
            r = zo(t);
        return typeof n == "string" && n && r ? {
            ownerChatterToken: n,
            ...r
        } : null;
    } catch {
        return null;
    }
}

function Vo(e) {
    let t = e.split(".")[1];
    if (!t || typeof globalThis.atob != "function") return null;
    try {
        let e = t.replace(/-/g, "+").replace(/_/g, "/"),
            n = e.padEnd(e.length + (4 - e.length % 4) % 4, "="),
            r = JSON.parse(globalThis.atob(n));
        return typeof r == "object" && r && !Array.isArray(r) ? r : null;
    } catch {
        return null;
    }
}

function Ho(e) {
    let t = Vo(e);
    return typeof t ? .sub == "string" && t.sub ? t.sub : null;
}

function Uo(e) {
    let t = Vo(e);
    return typeof t ? .sid == "string" && t.sid ? t.sid : null;
}

function Wo(e, t) {
    return !!t && Ho(e) === t;
}

function Go(e, t) {
    let n = Vo(e) ? .exp;
    return typeof n == "number" && Number.isFinite(n) && n * 1e3 <= t;
}

function Ko(e, t) {
    if (!e) return null;
    try {
        let n = JSON.parse(e);
        if (n.ownerChatterToken !== void 0) return null;
        let r = zo(n);
        return !r || !Wo(r.messagingToken, t) ? null : {
            ownerChatterToken: t,
            ...r
        };
    } catch {
        return null;
    }
}

function qo(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e);
        if (t.ownerChatterToken !== void 0) return null;
        let n = zo(t);
        return n ? Ho(n.messagingToken) : null;
    } catch {
        return null;
    }
}

function Jo(e, t) {
    let n = Bo(e);
    return n ? n.ownerChatterToken === t && Wo(n.messagingToken, t) ? n : null : Ko(e, t);
}
var P = "chatter",
    F = "sessionToken";

function Yo(e) {
    if (!e) return !1;
    try {
        return JSON.parse(e) === !0;
    } catch {
        return !1;
    }
}

function I(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e);
        return typeof t == "string" && t ? t : null;
    } catch {
        return null;
    }
}

function Xo(e, t) {
    if (typeof e == "string" && e.trim() !== "") try {
        return `origin:${new URL(e).origin}`;
    } catch {}
    return typeof t == "string" && t.trim() !== "" ? `cluster:${t.trim().toLowerCase()}` : "default";
}

function Zo(e, t, n) {
    return `ada:${e}:${Xo(t, n)}:session`;
}
var Qo = "ada:shared-session-write",
    L = "inLiveChat",
    R = "liveChatPending";

function $o(e) {
    return `ada:${e}:session`;
}

function es(e, t, n) {
    return `ada:${e}:${Xo(t, n)}:handoff`;
}
//#endregion
//#region src/store/session-slice.ts
var ts = 10080 * 60 * 1e3;

function ns(e) {
    return e.replace(/_+([a-z0-9])/g, (e, t) => t.toUpperCase());
}

function rs(e) {
    return e.replace(/([a-z0-9])([A-Z])/g, "$1_$2").toLowerCase();
}

function is(e) {
    if (!e) return {};
    let t = {};
    for (let [n, r] of Object.entries(e)) t[n] = r;
    for (let [n, r] of Object.entries(e)) {
        let e = ns(n);
        e in t || (t[e] = r);
        let i = rs(n);
        i in t || (t[i] = r);
    }
    return t;
}

function as(e, t, n) {
    let r = t ? Uo(t) : null;
    return n === !0 && e.messagingSessionCookieEnabled !== !1 && e._sessionCookieRejectedFor !== e.sessionToken && !!e.sessionToken && (r === null || r === e.sessionToken);
}

function os(e, t, n) {
    typeof n == "boolean" && (e.sessionCookieIssued = as(e, t, n));
}
var ss = {
        handle: null,
        cluster: null,
        endpoint: null,
        chatterToken: null,
        chatterId: null,
        _chatterAnnouncementSuppressed: !1,
        _chatterPersistenceAnnouncementPending: !1,
        _appInteractionReady: !1,
        _appConversationStartPending: !1,
        conversationId: null,
        clearedConversationId: null,
        language: "en",
        languageFromHost: !1,
        hostLanguage: null,
        clientDefaultLanguage: "en",
        translatedLanguages: [],
        features: {},
        messagingSessionCookieEnabled: null,
        zendeskMessagingChatterAuth: !1,
        emailTranscriptEnabled: !0,
        downloadTranscriptEnabled: !1,
        fileUploadEnabled: !0,
        imageUploadEnabled: !0,
        showBranding: !1,
        adaPartnerName: null,
        botName: null,
        botNameTranslations: null,
        botDescription: null,
        botDescriptionEnabled: !0,
        botAvatarUrl: null,
        tintColor: null,
        hostBranding: null,
        style: "round",
        textSize: "default",
        headerColorEnabled: !1,
        headerColor: null,
        headerTextColor: null,
        chatEnabled: !0,
        privacyLink: null,
        privacy: !1,
        theme: "auto",
        _themeSetBySdk: !1,
        advancedColorsEnabled: !1,
        textOverAccentColor: null,
        buttonLayoutMobile: "stacked",
        buttonLayoutDesktop: "stacked",
        showAllQuickReplies: !1,
        fallbackUi: null,
        buttonSize: 64,
        buttonBackgroundColor: null,
        avatar: {
            letter: "",
            image: null,
            useLetter: !1
        },
        agentAvatar: {
            isDefault: !0,
            image: null
        },
        allowedProtocols: [],
        customRedactions: [],
        secretMessageIsOpen: !1,
        alertSoundEnabled: !0,
        deviceNotificationsEnabled: !1,
        notificationPermission: "default",
        notificationsSupported: !1,
        smsNotificationsEnabled: !1,
        sessionId: null,
        greeting: null,
        configuredGreetingResponseId: null,
        identityToken: null,
        identityTokenConsumedChatterId: null,
        _pendingIdentityTokenConsumedChatterId: null,
        identityTokenFailureSeq: 0,
        identityTokenFailureReason: null,
        identitySession: !1,
        metaFields: {},
        sensitiveMetaFields: {},
        allowMetaFieldsInReset: !0,
        _allowMetaFieldsInResetLocked: !1,
        metaFieldsBaseline: {},
        _metaFieldsBaselineLocked: !1,
        nativeSessionMirror: !1,
        androidHostNavigation: !1,
        enableProgrammaticControl: !1,
        _enableProgrammaticControlLocked: !1,
        appUrl: null,
        appUrlFallback: !0,
        _appUrlLocked: !1,
        allowedWebsites: [],
        deviceToken: null,
        deviceOs: null,
        isConfigured: !1,
        hasHydratedClientConfig: !1,
        persistence: "normal",
        timeToExpiryMs: null,
        rollout: null,
        sessionToken: null,
        sessionTokenExpiresAt: null,
        messagingToken: null,
        messagingTokenIssuedAt: null,
        messagingTokenExpiresAt: null,
        sessionCookieIssued: !1,
        _sessionCookieRejectedFor: null,
        sessionRefreshToken: null,
        refreshGeneration: null,
        conversationGeneration: 0,
        mode: null,
        testModeBannerLabel: null,
        transcriptEmailRequestStatus: "idle",
        transcriptEmailRequestSeq: 0,
        transcriptEmailPendingEmail: null,
        transcriptEmailConflictEmail: null,
        transcriptEmailConflictSeq: 0,
        transcriptDownloadRequestStatus: "idle",
        transcriptDownloadRequestSeq: 0,
        _appFrameIsCustom: !1,
        isParentElementMode: !1,
        isMobileViewport: !1,
        hideDefaultHeader: !1,
        clearPersistenceOnPrepare: !1,
        clearPersistenceAckRequestId: null,
        clearPersistenceAckResponseType: null,
        clearPersistenceStorageModes: [],
        clearPersistenceOutgoingStorageMode: null,
        userTheme: null,
        hostViewport: null,
        userTextSize: null
    },
    cs = N({
        name: "session",
        initialState: ss,
        reducers: {
            configReceived(e, t) {
                e.handle = t.payload.handle, e.cluster = t.payload.cluster ? ? null, e.endpoint = t.payload.endpoint, e.language = t.payload.language ? ? "en", e.languageFromHost = t.payload.languageFromHost ? ? !1, t.payload.hostLanguage === void 0 ? e.languageFromHost && t.payload.language ? e.hostLanguage = t.payload.language : e.hostLanguage = null : e.hostLanguage = t.payload.hostLanguage, e.greeting = t.payload.greeting ? ? null, e.configuredGreetingResponseId = t.payload.configuredGreetingResponseId ? ? null, e.identityToken = t.payload.identityToken ? ? null, e.identityToken && (e.identityTokenFailureReason = null), e.metaFields = t.payload.metaFields ? ? {}, t.payload.theme && (e.theme = t.payload.theme, e._themeSetBySdk = !0), e.hostBranding = t.payload.hostBranding ? ? null, e.mode = t.payload.mode ? ? null, e.isParentElementMode = t.payload.isParentElementMode ? ? !1, e.isMobileViewport = t.payload.isMobileViewport ? ? !1, e.hideDefaultHeader = t.payload.hideDefaultHeader ? ? !1, e.clearPersistenceOnPrepare = t.payload.clearPersistenceOnPrepare ? ? !1, e.clearPersistenceAckRequestId = t.payload.clearPersistenceAckRequestId ? ? null, e.clearPersistenceAckResponseType = t.payload.clearPersistenceAckResponseType ? ? null, e.clearPersistenceStorageModes = [...new Set(t.payload.clearPersistenceStorageModes ? ? [])], e.clearPersistenceOutgoingStorageMode = t.payload.clearPersistenceOutgoingStorageMode ? ? null, e._allowMetaFieldsInResetLocked || = (e.allowMetaFieldsInReset = t.payload.allowMetaFieldsInReset ? ? !0, !0), e._metaFieldsBaselineLocked || = (e.metaFieldsBaseline = t.payload.metaFieldsBaseline ? ? {}, !0), t.payload.nativeSessionMirror === !0 && (e.nativeSessionMirror = !0), t.payload.androidHostNavigation === !0 && (e.androidHostNavigation = !0), e._enableProgrammaticControlLocked || = (e.enableProgrammaticControl = t.payload.enableProgrammaticControl ? ? !1, !0), e._appUrlLocked || = (e.appUrl = t.payload.appUrl ? ? null, e.appUrlFallback = t.payload.appUrlFallback !== !1, !0), e.isConfigured = !0;
            },
            clearPersistenceOnPrepareConsumed(e) {
                e.clearPersistenceOnPrepare = !1, e.clearPersistenceAckRequestId = null, e.clearPersistenceAckResponseType = null, e.clearPersistenceStorageModes = [], e.clearPersistenceOutgoingStorageMode = null;
            },
            messagingSessionCookieEnabledSet(e, t) {
                e.messagingSessionCookieEnabled = t.payload, t.payload || (e.sessionCookieIssued = !1);
            },
            zendeskMessagingChatterAuthSet(e, t) {
                e.zendeskMessagingChatterAuth = t.payload;
            },
            clientConfigHydrated(e, t) {
                e.hasHydratedClientConfig = !0, e.clientDefaultLanguage = t.payload.clientDefaultLanguage ? ? "en", e.translatedLanguages = t.payload.translatedLanguages ? ? [], e.features = is(t.payload.features), e.emailTranscriptEnabled = t.payload.emailTranscriptEnabled ? ? !0, e.downloadTranscriptEnabled = t.payload.downloadTranscriptEnabled ? ? !1, e.fileUploadEnabled = t.payload.fileUploadEnabled ? ? !0, e.imageUploadEnabled = t.payload.imageUploadEnabled ? ? !0, e.showBranding = t.payload.showBranding ? ? !1, e.adaPartnerName = t.payload.adaPartnerName ? ? null, e.botName = t.payload.botName ? ? null, e.botNameTranslations = t.payload.botNameTranslations ? ? null, e.botDescription = t.payload.botDescription ? ? null, e.botDescriptionEnabled = t.payload.botDescriptionEnabled ? ? !0, e.botAvatarUrl = t.payload.botAvatarUrl ? ? null, e.tintColor = t.payload.tintColor ? ? null, e.style = t.payload.style ? ? "round", e.textSize = t.payload.textSize ? ? "default", e.headerColorEnabled = t.payload.headerColorEnabled ? ? !1, e.headerColor = t.payload.headerColor ? ? null, e.headerTextColor = t.payload.headerTextColor ? ? null, e.chatEnabled = t.payload.chatEnabled ? ? !0, e.privacyLink = t.payload.privacyLink ? ? null, e.privacy = t.payload.privacy ? ? !1, e._themeSetBySdk || (e.theme = t.payload.theme ? ? "auto"), e.advancedColorsEnabled = t.payload.advancedColorsEnabled ? ? !1, e.textOverAccentColor = t.payload.textOverAccentColor ? ? null, e.buttonLayoutMobile = t.payload.buttonLayoutMobile ? ? "stacked", e.buttonLayoutDesktop = t.payload.buttonLayoutDesktop ? ? "stacked", e.showAllQuickReplies = t.payload.showAllQuickReplies ? ? !1, e.fallbackUi = t.payload.fallbackUi ? ? null, e.buttonSize = t.payload.buttonSize ? ? 64, e.buttonBackgroundColor = t.payload.buttonBackgroundColor ? ? null, t.payload.avatar && (e.avatar = t.payload.avatar), t.payload.agentAvatar && (e.agentAvatar = t.payload.agentAvatar), e.allowedProtocols = t.payload.allowedProtocols ? ? [], e.allowedWebsites = t.payload.allowedWebsites ? ? [], e.customRedactions = t.payload.customRedactions ? ? [], e.persistence = t.payload.persistence ? ? "normal", e.timeToExpiryMs = t.payload.timeToExpiryMs ? ? null, e.rollout = t.payload.rollout ? ? null;
            },
            chatterCreated(e, t) {
                e.chatterToken = t.payload.token, e.chatterId = t.payload.id, e._chatterAnnouncementSuppressed = t.payload.suppressAnnouncement === !0, e._chatterPersistenceAnnouncementPending = t.payload.suppressAnnouncement === !0, e._appInteractionReady = !1, e.sessionToken !== (t.payload.sessionToken ? ? null) && (e.sessionCookieIssued = !1), e.sessionToken = t.payload.sessionToken ? ? null, t.payload.sessionToken && (e.sessionTokenExpiresAt = Date.now() + ts), os(e, t.payload.messagingToken, t.payload.sessionCookieIssued), e.sessionRefreshToken = t.payload.sessionRefreshToken ? ? null, e.refreshGeneration = t.payload.refreshGeneration ? ? null, e.identityToken = null;
                let n = t.payload.identityTokenConsumed === !0;
                if (e.identityTokenConsumedChatterId = n && !t.payload.suppressAnnouncement ? t.payload.id : null, e._pendingIdentityTokenConsumedChatterId = n && t.payload.suppressAnnouncement ? t.payload.id : null, e.identitySession = !!t.payload.identityTokenConsumed, t.payload.identityTokenConsumed && (e.identityTokenFailureReason = null), t.payload.messagingToken && t.payload.messagingTokenExpiresIn) {
                    let n = Date.now();
                    e.messagingToken = t.payload.messagingToken, e.messagingTokenIssuedAt = n, e.messagingTokenExpiresAt = n + t.payload.messagingTokenExpiresIn * 1e3;
                }
                typeof t.payload.playAlertChime == "boolean" && (e.alertSoundEnabled = t.payload.playAlertChime), typeof t.payload.deviceNotificationsEnabled == "boolean" && (e.deviceNotificationsEnabled = t.payload.deviceNotificationsEnabled), typeof t.payload.smsNotificationsEnabled == "boolean" && (e.smsNotificationsEnabled = t.payload.smsNotificationsEnabled);
            },
            identityTokenExchangeFailed(e, t) {
                e.identityToken = null, e.identityTokenConsumedChatterId = null, e._pendingIdentityTokenConsumedChatterId = null, e.identityTokenFailureSeq += 1, e.identityTokenFailureReason = t.payload.reason;
            },
            sessionActivityRefreshed(e) {
                e.sessionTokenExpiresAt !== null && (e.sessionTokenExpiresAt = Date.now() + ts);
            },
            recoveredSessionTokenAdopted(e, t) {
                e.sessionToken === null && (e.sessionToken = t.payload.sessionToken);
            },
            hydrateSessionFromPersistence(e, t) {
                e.chatterToken = t.payload.token, e.chatterId = t.payload.id, e._chatterAnnouncementSuppressed = t.payload.suppressChatterAnnouncement === !0, e._chatterPersistenceAnnouncementPending = !1, e._pendingIdentityTokenConsumedChatterId = null, e._appInteractionReady = !1, e.sessionToken !== (t.payload.sessionToken ? ? null) && (e.sessionCookieIssued = !1), e.sessionToken = t.payload.sessionToken ? ? null, e.sessionTokenExpiresAt = t.payload.sessionTokenExpiresAt ? ? null, os(e, t.payload.messagingToken, t.payload.sessionCookieIssued), e.sessionRefreshToken = t.payload.sessionRefreshToken ? ? null, e.refreshGeneration = t.payload.refreshGeneration ? ? null, e.identitySession = t.payload.identitySession ? ? !0, t.payload.language && !e.languageFromHost && (e.language = t.payload.language), t.payload.messagingToken && t.payload.messagingTokenExpiresAt && (e.messagingToken = t.payload.messagingToken, e.messagingTokenExpiresAt = t.payload.messagingTokenExpiresAt, e.messagingTokenIssuedAt = null);
            },
            chatterAnnouncementReleased(e, t) {
                e.chatterToken === t.payload.chatterToken && !e._chatterPersistenceAnnouncementPending && (e._chatterAnnouncementSuppressed = !1, e._appInteractionReady = !0);
            },
            chatterPersistenceAnnouncementReleased(e, t) {
                e.chatterToken === t.payload.chatterToken && e._chatterPersistenceAnnouncementPending && (e._pendingIdentityTokenConsumedChatterId && = (e.identityTokenConsumedChatterId = e._pendingIdentityTokenConsumedChatterId, null), e._chatterPersistenceAnnouncementPending = !1, e._chatterAnnouncementSuppressed = !1);
            },
            identityTokenConsumptionAnnouncementReleased(e, t) {
                e.chatterToken === t.payload.chatterToken && e._chatterPersistenceAnnouncementPending && e._pendingIdentityTokenConsumedChatterId && (e.identityTokenConsumedChatterId = e._pendingIdentityTokenConsumedChatterId, e._pendingIdentityTokenConsumedChatterId = null);
            },
            appInteractionReadySet(e, t) {
                e._appInteractionReady = t.payload;
            },
            appConversationStartPendingSet(e, t) {
                e._appConversationStartPending = t.payload;
            },
            provisionalChatterCleared(e, t) {
                e.chatterToken !== t.payload.chatterToken || !e._chatterAnnouncementSuppressed || (e.chatterToken = null, e.chatterId = null, e._chatterAnnouncementSuppressed = !1, e._chatterPersistenceAnnouncementPending = !1, e._pendingIdentityTokenConsumedChatterId = null, e._appInteractionReady = !1, e.sessionToken = null, e.sessionTokenExpiresAt = null, e.messagingToken = null, e.messagingTokenIssuedAt = null, e.messagingTokenExpiresAt = null, e.sessionCookieIssued = !1, e.sessionRefreshToken = null, e.refreshGeneration = null, e.identitySession = !1);
            },
            conversationStarted(e, t) {
                e.conversationId = t.payload, e.clearedConversationId = null;
            },
            conversationIdCleared(e) {
                e.clearedConversationId = e.conversationId, e.conversationId = null, e.conversationGeneration += 1;
            },
            sessionIdSet(e, t) {
                e.sessionId = t.payload;
            },
            languageChanged(e, t) {
                e.language = t.payload;
            },
            themeChanged(e, t) {
                e.theme = t.payload, e._themeSetBySdk = !0;
            },
            hostViewportSet(e, t) {
                e.hostViewport = t.payload;
            },
            userThemePreferenceSet(e, t) {
                e.userTheme = t.payload;
            },
            userTextSizePreferenceSet(e, t) {
                e.userTextSize = t.payload;
            },
            userAppearancePreferencesHydrated(e, t) {
                e.userTheme = t.payload.userTheme, e.userTextSize = t.payload.userTextSize;
            },
            alertSoundChanged(e, t) {
                e.alertSoundEnabled = t.payload;
            },
            deviceNotificationsChanged(e, t) {
                e.deviceNotificationsEnabled = t.payload;
            },
            notificationPermissionReported(e, t) {
                e.notificationPermission = t.payload.permission, e.notificationsSupported = t.payload.supported;
            },
            smsNotificationsChanged(e, t) {
                e.smsNotificationsEnabled = t.payload;
            },
            metaFieldsUpdated(e, t) {
                e.metaFields = {
                    ...e.metaFields,
                    ...t.payload
                };
            },
            sensitiveMetaFieldsUpdated(e, t) {
                e.sensitiveMetaFields = {
                    ...e.sensitiveMetaFields,
                    ...t.payload
                };
            },
            deviceTokenSet(e, t) {
                e.deviceToken = t.payload.token, e.deviceOs = t.payload.deviceOs;
            },
            transcriptEmailRequestStarted(e, t) {
                e.transcriptEmailRequestStatus = "pending", e.transcriptEmailRequestSeq += 1, e.transcriptEmailPendingEmail = t.payload ? ? null;
            },
            transcriptEmailRequestSucceeded(e) {
                e.transcriptEmailRequestStatus = "success", e.transcriptEmailRequestSeq += 1, e.transcriptEmailPendingEmail = null;
            },
            transcriptEmailRequestFailed(e) {
                e.transcriptEmailRequestStatus = "error", e.transcriptEmailRequestSeq += 1, e.transcriptEmailPendingEmail = null;
            },
            transcriptEmailConflictRejected(e, t) {
                e.transcriptEmailConflictEmail = t.payload, e.transcriptEmailConflictSeq += 1;
            },
            transcriptDownloadRequestStarted(e) {
                e.transcriptDownloadRequestStatus = "pending", e.transcriptDownloadRequestSeq += 1;
            },
            transcriptDownloadRequestSucceeded(e) {
                e.transcriptDownloadRequestStatus = "success", e.transcriptDownloadRequestSeq += 1;
            },
            transcriptDownloadRequestFailed(e) {
                e.transcriptDownloadRequestStatus = "error", e.transcriptDownloadRequestSeq += 1;
            },
            messagingTokenReceived(e, t) {
                os(e, t.payload.token, t.payload.sessionCookieIssued);
                let n = Date.now();
                e.messagingToken = t.payload.token, e.messagingTokenIssuedAt = n, e.messagingTokenExpiresAt = n + t.payload.expiresIn * 1e3;
            },
            messagingTokenRefreshed(e, t) {
                if (typeof t.payload.refreshGeneration == "number") {
                    let n = e.refreshGeneration ? ? -1,
                        r = t.payload.refreshGeneration === n;
                    if (r && !e.sessionRefreshToken && t.payload.sessionRefreshToken && (e.sessionRefreshToken = t.payload.sessionRefreshToken), t.payload.refreshGeneration < n) return;
                    if (r && e.messagingToken) {
                        os(e, t.payload.token, t.payload.sessionCookieIssued);
                        return;
                    }
                    e.refreshGeneration = t.payload.refreshGeneration;
                } else t.payload.refreshGeneration === null && (e.refreshGeneration = null);
                os(e, t.payload.token, t.payload.sessionCookieIssued);
                let n = Date.now();
                e.messagingToken = t.payload.token, e.messagingTokenIssuedAt = n, e.messagingTokenExpiresAt = n + t.payload.expiresIn * 1e3, t.payload.sessionRefreshToken !== void 0 && (e.sessionRefreshToken = t.payload.sessionRefreshToken);
            },
            messagingJwtExchanged(e, t) {
                let {
                    sessionRefreshToken: n,
                    refreshGeneration: r
                } = t.payload;
                n && typeof r == "number" && r > (e.refreshGeneration ? ? 0) && (e.sessionRefreshToken = n, e.refreshGeneration = r), (t.payload.refreshGeneration === void 0 || (t.payload.refreshGeneration ? ? 0) >= (e.refreshGeneration ? ? 0)) && os(e, t.payload.token, t.payload.sessionCookieIssued);
                let i = Date.now();
                e.messagingToken = t.payload.token, e.messagingTokenIssuedAt = i, e.messagingTokenExpiresAt = i + t.payload.expiresIn * 1e3;
            },
            sessionCookieRejected(e, t) {
                t.payload.sessionToken !== null && (e.sessionToken === t.payload.sessionToken || t.payload.allowNullStore && e.sessionToken === null) && (e.refreshGeneration ? ? 0) <= (t.payload.refreshGeneration ? ? 0) && (t.payload.reason === "missing_credentials" || t.payload.reason === "invalid_session_cookie") && (e._sessionCookieRejectedFor = t.payload.sessionToken, e.sessionCookieIssued = !1), t.payload.sessionToken !== null && e.sessionToken === t.payload.sessionToken && (e.refreshGeneration ? ? 0) <= (t.payload.refreshGeneration ? ? 0) && (e.sessionCookieIssued = !1);
            },
            messagingTokenCleared(e) {
                e.messagingToken = null, e.messagingTokenIssuedAt = null, e.messagingTokenExpiresAt = null, e.sessionRefreshToken = null, e.refreshGeneration = null;
            },
            messagingTokenExpired(e) {
                e.messagingToken = null, e.messagingTokenIssuedAt = null, e.messagingTokenExpiresAt = null;
            },
            deadSessionCleared(e) {
                e.chatterToken = null, e.chatterId = null, e._chatterAnnouncementSuppressed = !1, e._chatterPersistenceAnnouncementPending = !1, e._pendingIdentityTokenConsumedChatterId = null, e._appInteractionReady = !1, e.sessionToken = null, e.sessionTokenExpiresAt = null, e.messagingToken = null, e.messagingTokenIssuedAt = null, e.messagingTokenExpiresAt = null, e.sessionCookieIssued = !1, e.sessionRefreshToken = null, e.refreshGeneration = null, e.identitySession = !1;
            },
            secretMessageToggled(e, t) {
                e.secretMessageIsOpen = t.payload;
            },
            appFrameModeSet(e, t) {
                e._appFrameIsCustom = t.payload.isCustomApp;
            },
            testModeBannerSet(e, t) {
                e.testModeBannerLabel = t.payload;
            },
            sessionReset(e) {
                return {
                    ...ss,
                    _sessionCookieRejectedFor: e._sessionCookieRejectedFor,
                    conversationGeneration: e.conversationGeneration + 1,
                    notificationPermission: e.notificationPermission,
                    notificationsSupported: e.notificationsSupported,
                    isMobileViewport: e.isMobileViewport,
                    hostViewport: e.hostViewport,
                    hostBranding: e.hostBranding,
                    languageFromHost: e.languageFromHost,
                    hostLanguage: e.hostLanguage,
                    ...e.languageFromHost ? {
                        language: e.hostLanguage ? ? e.language
                    } : {},
                    appUrl: e.appUrl,
                    appUrlFallback: e.appUrlFallback,
                    _appUrlLocked: e._appUrlLocked,
                    _appFrameIsCustom: e._appFrameIsCustom,
                    metaFieldsBaseline: e.metaFieldsBaseline,
                    _metaFieldsBaselineLocked: e._metaFieldsBaselineLocked,
                    allowMetaFieldsInReset: e.allowMetaFieldsInReset,
                    _allowMetaFieldsInResetLocked: e._allowMetaFieldsInResetLocked,
                    enableProgrammaticControl: e.enableProgrammaticControl,
                    _enableProgrammaticControlLocked: e._enableProgrammaticControlLocked,
                    nativeSessionMirror: e.nativeSessionMirror,
                    androidHostNavigation: e.androidHostNavigation
                };
            }
        }
    }),
    {
        appConversationStartPendingSet: ls,
        configReceived: us,
        clientConfigHydrated: ds,
        messagingSessionCookieEnabledSet: fs,
        zendeskMessagingChatterAuthSet: ps,
        chatterCreated: ms,
        chatterAnnouncementReleased: hs,
        chatterPersistenceAnnouncementReleased: gs,
        identityTokenConsumptionAnnouncementReleased: _s,
        appInteractionReadySet: vs,
        provisionalChatterCleared: ys,
        identityTokenExchangeFailed: bs,
        sessionActivityRefreshed: xs,
        recoveredSessionTokenAdopted: Ss,
        clearPersistenceOnPrepareConsumed: Cs,
        hydrateSessionFromPersistence: ws,
        conversationStarted: Ts,
        conversationIdCleared: Es,
        sessionIdSet: Ds,
        languageChanged: Os,
        themeChanged: ks,
        hostViewportSet: As,
        userThemePreferenceSet: js,
        userTextSizePreferenceSet: Ms,
        userAppearancePreferencesHydrated: Ns,
        alertSoundChanged: Ps,
        deviceNotificationsChanged: Fs,
        notificationPermissionReported: Is,
        smsNotificationsChanged: Ls,
        metaFieldsUpdated: Rs,
        sensitiveMetaFieldsUpdated: zs,
        deviceTokenSet: Bs,
        appFrameModeSet: Vs,
        transcriptEmailRequestStarted: Hs,
        transcriptEmailRequestSucceeded: Us,
        transcriptEmailRequestFailed: Ws,
        transcriptEmailConflictRejected: Gs,
        transcriptDownloadRequestStarted: Ks,
        transcriptDownloadRequestSucceeded: qs,
        transcriptDownloadRequestFailed: Js,
        messagingTokenReceived: Ys,
        messagingTokenRefreshed: Xs,
        messagingJwtExchanged: Zs,
        sessionCookieRejected: Qs,
        messagingTokenCleared: $s,
        messagingTokenExpired: ec,
        deadSessionCleared: tc,
        secretMessageToggled: nc,
        testModeBannerSet: rc,
        sessionReset: ic
    } = cs.actions,
    ac = (e) => {
        let {
            sessionTokenExpiresAt: t
        } = e.session;
        return t ? Date.now() >= t : !1;
    },
    oc = 2e4,
    sc = "Request timed out after",
    cc = "Request cancelled because the active session changed before it could be sent.",
    lc = [
        "http://localhost:8000",
        "https://localhost:8000",
        "http://127.0.0.1:8000",
        "https://127.0.0.1:8000"
    ];

function uc() {
    let e = ( /* @__PURE__ */ new Date()).getTimezoneOffset(),
        t = e > 0 ? "-" : "+",
        n = Math.floor(Math.abs(e) / 60),
        r = Math.abs(e) % 60;
    return `${t}${String(n).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

function dc(e, t) {
    let n = new AbortController(),
        r = !1,
        i = () => {
            n.abort();
        };
    for (let t of e)
        if (t) {
            if (t.aborted) {
                i();
                break;
            }
            t.addEventListener("abort", i, {
                once: !0
            });
        }
    let a = null,
        o = new Promise((e, i) => {
            a = globalThis.setTimeout(() => {
                r = !0, n.abort(), i( /* @__PURE__ */ Error(`${sc} ${t}ms`));
            }, t);
        });
    return {
        signal: n.signal,
        cleanup: () => {
            a !== null && globalThis.clearTimeout(a);
            for (let t of e) t ? .removeEventListener("abort", i);
        },
        didTimeout: () => r,
        timeoutPromise: o
    };
}

function fc(e) {
    for (let t of lc) {
        if (e === t) return "/";
        if (e.startsWith(`${t}/`)) return e.slice(t.length);
    }
    return e;
}

function pc({
    body: e,
    headers: t,
    simpleGet: n
}) {
    return n ? {} : {
        ...!(e instanceof FormData) && {
            "Content-Type": "application/json"
        },
        Pragma: "no-cache",
        "X-Ada-Request-Origin": "chat",
        "X-Client-GMT-Offset": uc(),
        ...t
    };
}
//#endregion
//#region ../../../chat/src/shared/services/messaging-auth-telemetry.js
var mc = typeof globalThis.crypto ? .randomUUID == "function" ? globalThis.crypto.randomUUID() : `${Date.now().toString(36)}.${Math.random().toString(36).slice(2)}`;

function hc(e, t, n, r) {
    return {
        client_build: e,
        runtime_id: mc,
        credential_source: t,
        ...typeof n == "number" && Number.isSafeInteger(n) && n > 0 ? {
            attempted_generation: n
        } : {},
        ...r ? {
            exchange_reason: r
        } : {}
    };
}
//#endregion
//#region ../../../chat/src/shared/services/rejected-refresh-credentials.js
function gc() {
    let e = /* @__PURE__ */ new Set(),
        t = /* @__PURE__ */ new Map(),
        n = (e, t) => JSON.stringify([e, t]),
        r = (e, t, n) => {
            if (!e || !t ? .sessionRefreshToken) return null;
            let r = 2166136261,
                i = 5381;
            for (let e of JSON.stringify([n, t.sessionRefreshToken])) r = Math.imul(r ^ e.charCodeAt(0), 16777619), i = Math.imul(i, 33) ^ e.charCodeAt(0);
            return JSON.stringify([
                e,
                r >>> 0,
                i >>> 0
            ]);
        };
    return {
        add(i, a, o) {
            let s = r(i, a, o);
            if (s && (e.add(s), Number.isInteger(a.refreshGeneration))) {
                let e = n(i, o);
                t.set(e, Math.max(t.get(e) ? ? a.refreshGeneration, a.refreshGeneration));
            }
        },
        hasGeneration(e, r, i) {
            let a = t.get(n(e, i));
            return Number.isInteger(r) && r <= a;
        },
        has(t, n, i) {
            let a = r(t, n, i);
            return a !== null && e.has(a);
        }
    };
}
//#endregion
//#region ../../../chat/src/shared/services/rejected-session-pairs.js
function _c() {
    let e = /* @__PURE__ */ new Map(),
        t = (e, t) => {
            if (!e || !t) return null;
            let n = 2166136261,
                r = 5381;
            for (let i of JSON.stringify([e, t])) n = Math.imul(n ^ i.charCodeAt(0), 16777619), r = Math.imul(r, 33) ^ i.charCodeAt(0);
            return JSON.stringify([n >>> 0, r >>> 0]);
        };
    return {
        add(n, r, i = 0) {
            let a = t(n, r);
            if (a) {
                let t = e.get(a);
                (t === void 0 || i > t) && e.set(a, i);
            }
        },
        getRefreshGeneration(n, r) {
            return e.get(t(n, r));
        },
        has(n, r, i) {
            let a = t(n, r);
            return a !== null && e.has(a) && (i === void 0 || i <= e.get(a));
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/domain/deflate/deflateEncoder.js
function vc(e, t, n) {
    let r = 0,
        i = [],
        a, o = !0,
        s = 0,
        c = [],
        {
            stop: l
        } = ze(e, t, "message", ({
            data: e
        }) => {
            if (e.type !== "wrote" || e.streamId !== n) return;
            let t = c[0];
            t && (t.id === e.id ? (c.shift(), r += e.additionalBytesCount, i.push(e.result), a = e.trailer, t.writeCallback ? t.writeCallback(e.result.byteLength) : t.finishCallback && t.finishCallback()) : t.id < e.id && l());
        });

    function u() {
        let e = i.length === 0 ? new Uint8Array() : dt(i.concat(a)),
            t = {
                rawBytesCount: r,
                output: e,
                outputBytesCount: e.byteLength,
                encoding: "deflate"
            };
        return r = 0, i = [], t;
    }

    function d() {
        o || = (t.postMessage({
            action: "reset",
            streamId: n
        }), !0);
    }
    return {
        isAsync: !0,
        get isEmpty() {
            return o;
        },
        write(e, r) {
            t.postMessage({
                action: "write",
                id: s,
                data: e,
                streamId: n
            }), c.push({
                id: s,
                writeCallback: r,
                data: e
            }), o = !1, s += 1;
        },
        finish(e) {
            d(), c.length ? (c.forEach((e) => {
                delete e.writeCallback;
            }), c[c.length - 1].finishCallback = () => e(u())) : e(u());
        },
        finishSync() {
            d();
            let e = c.map((e) => e.data).join("");
            return c.length = 0, {
                ...u(),
                pendingData: e
            };
        },
        estimateEncodedBytesCount(e) {
            return e.length / 8;
        },
        stop() {
            l();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/domain/scriptLoadingError.js
function yc({
    configuredUrl: e,
    error: t,
    source: n,
    scriptType: r
}) {
    if (a.error(`${n} failed to start: an error occurred while initializing the ${r}:`, t), t instanceof Event || t instanceof Error && bc(t.message)) {
        let t;
        t = e ? `Please make sure the ${r} URL ${e} is correct and CSP is correctly configured.` : "Please make sure CSP is correctly configured.", a.error(`${t} See documentation at ${s}/integrations/content_security_policy_logs/#use-csp-with-real-user-monitoring-and-session-replay`);
    } else r === "worker" && Pe(t);
}

function bc(e) {
    return e.includes("Content Security Policy") || e.includes("requires 'TrustedScriptURL'");
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/domain/deflate/deflateWorker.js
var xc = 30 * Ge;

function Sc(e) {
    return new Worker(e.workerUrl || URL.createObjectURL(new Blob(["(()=>{function t(t){if(1===t.length)return t[0];const e=t.reduce((t,e)=>t+e.length,0),a=new Uint8Array(e);let n=0;for(const e of t)a.set(e,n),n+=e.length;return a}function e(t){for(var e=t.length;--e>=0;)t[e]=0}var a=new Uint8Array([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0]),n=new Uint8Array([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13]),r=new Uint8Array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7]),i=new Uint8Array([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),s=Array(576);e(s);var h=Array(60);e(h);var l=Array(512);e(l);var _=Array(256);e(_);var o=Array(29);e(o);var d,u,f,c=Array(30);function p(t,e,a,n,r){this.static_tree=t,this.extra_bits=e,this.extra_base=a,this.elems=n,this.max_length=r,this.has_stree=t&&t.length}function g(t,e){this.dyn_tree=t,this.max_code=0,this.stat_desc=e}e(c);var v=function(t){return t<256?l[t]:l[256+(t>>>7)]},w=function(t,e){t.pending_buf[t.pending++]=255&e,t.pending_buf[t.pending++]=e>>>8&255},m=function(t,e,a){t.bi_valid>16-a?(t.bi_buf|=e<<t.bi_valid&65535,w(t,t.bi_buf),t.bi_buf=e>>16-t.bi_valid,t.bi_valid+=a-16):(t.bi_buf|=e<<t.bi_valid&65535,t.bi_valid+=a)},b=function(t,e,a){m(t,a[2*e],a[2*e+1])},y=function(t,e){var a=0;do{a|=1&t,t>>>=1,a<<=1}while(--e>0);return a>>>1},z=function(t,e,a){var n,r,i=Array(16),s=0;for(n=1;n<=15;n++)i[n]=s=s+a[n-1]<<1;for(r=0;r<=e;r++){var h=t[2*r+1];0!==h&&(t[2*r]=y(i[h]++,h))}},k=function(t){var e;for(e=0;e<286;e++)t.dyn_ltree[2*e]=0;for(e=0;e<30;e++)t.dyn_dtree[2*e]=0;for(e=0;e<19;e++)t.bl_tree[2*e]=0;t.dyn_ltree[512]=1,t.opt_len=t.static_len=0,t.last_lit=t.matches=0},x=function(t){t.bi_valid>8?w(t,t.bi_buf):t.bi_valid>0&&(t.pending_buf[t.pending++]=t.bi_buf),t.bi_buf=0,t.bi_valid=0},A=function(t,e,a,n){var r=2*e,i=2*a;return t[r]<t[i]||t[r]===t[i]&&n[e]<=n[a]},U=function(t,e,a){for(var n=t.heap[a],r=a<<1;r<=t.heap_len&&(r<t.heap_len&&A(e,t.heap[r+1],t.heap[r],t.depth)&&r++,!A(e,n,t.heap[r],t.depth));)t.heap[a]=t.heap[r],a=r,r<<=1;t.heap[a]=n},B=function(t,e,r){var i,s,h,l,d=0;if(0!==t.last_lit)do{i=t.pending_buf[t.d_buf+2*d]<<8|t.pending_buf[t.d_buf+2*d+1],s=t.pending_buf[t.l_buf+d],d++,0===i?b(t,s,e):(h=_[s],b(t,h+256+1,e),0!==(l=a[h])&&(s-=o[h],m(t,s,l)),i--,h=v(i),b(t,h,r),0!==(l=n[h])&&(i-=c[h],m(t,i,l)))}while(d<t.last_lit);b(t,256,e)},I=function(t,e){var a,n,r,i=e.dyn_tree,s=e.stat_desc.static_tree,h=e.stat_desc.has_stree,l=e.stat_desc.elems,_=-1;for(t.heap_len=0,t.heap_max=573,a=0;a<l;a++)0!==i[2*a]?(t.heap[++t.heap_len]=_=a,t.depth[a]=0):i[2*a+1]=0;for(;t.heap_len<2;)i[2*(r=t.heap[++t.heap_len]=_<2?++_:0)]=1,t.depth[r]=0,t.opt_len--,h&&(t.static_len-=s[2*r+1]);for(e.max_code=_,a=t.heap_len>>1;a>=1;a--)U(t,i,a);r=l;do{a=t.heap[1],t.heap[1]=t.heap[t.heap_len--],U(t,i,1),n=t.heap[1],t.heap[--t.heap_max]=a,t.heap[--t.heap_max]=n,i[2*r]=i[2*a]+i[2*n],t.depth[r]=(t.depth[a]>=t.depth[n]?t.depth[a]:t.depth[n])+1,i[2*a+1]=i[2*n+1]=r,t.heap[1]=r++,U(t,i,1)}while(t.heap_len>=2);t.heap[--t.heap_max]=t.heap[1],function(t,e){var a,n,r,i,s,h,l=e.dyn_tree,_=e.max_code,o=e.stat_desc.static_tree,d=e.stat_desc.has_stree,u=e.stat_desc.extra_bits,f=e.stat_desc.extra_base,c=e.stat_desc.max_length,p=0;for(i=0;i<=15;i++)t.bl_count[i]=0;for(l[2*t.heap[t.heap_max]+1]=0,a=t.heap_max+1;a<573;a++)(i=l[2*l[2*(n=t.heap[a])+1]+1]+1)>c&&(i=c,p++),l[2*n+1]=i,n>_||(t.bl_count[i]++,s=0,n>=f&&(s=u[n-f]),h=l[2*n],t.opt_len+=h*(i+s),d&&(t.static_len+=h*(o[2*n+1]+s)));if(0!==p){do{for(i=c-1;0===t.bl_count[i];)i--;t.bl_count[i]--,t.bl_count[i+1]+=2,t.bl_count[c]--,p-=2}while(p>0);for(i=c;0!==i;i--)for(n=t.bl_count[i];0!==n;)(r=t.heap[--a])>_||(l[2*r+1]!==i&&(t.opt_len+=(i-l[2*r+1])*l[2*r],l[2*r+1]=i),n--)}}(t,e),z(i,_,t.bl_count)},E=function(t,e,a){var n,r,i=-1,s=e[1],h=0,l=7,_=4;for(0===s&&(l=138,_=3),e[2*(a+1)+1]=65535,n=0;n<=a;n++)r=s,s=e[2*(n+1)+1],++h<l&&r===s||(h<_?t.bl_tree[2*r]+=h:0!==r?(r!==i&&t.bl_tree[2*r]++,t.bl_tree[32]++):h<=10?t.bl_tree[34]++:t.bl_tree[36]++,h=0,i=r,0===s?(l=138,_=3):r===s?(l=6,_=3):(l=7,_=4))},C=function(t,e,a){var n,r,i=-1,s=e[1],h=0,l=7,_=4;for(0===s&&(l=138,_=3),n=0;n<=a;n++)if(r=s,s=e[2*(n+1)+1],!(++h<l&&r===s)){if(h<_)do{b(t,r,t.bl_tree)}while(0!==--h);else 0!==r?(r!==i&&(b(t,r,t.bl_tree),h--),b(t,16,t.bl_tree),m(t,h-3,2)):h<=10?(b(t,17,t.bl_tree),m(t,h-3,3)):(b(t,18,t.bl_tree),m(t,h-11,7));h=0,i=r,0===s?(l=138,_=3):r===s?(l=6,_=3):(l=7,_=4)}},D=!1,M=function(t,e,a,n){m(t,0+(n?1:0),3),function(t,e,a){x(t),w(t,a),w(t,~a),t.pending_buf.set(t.window.subarray(e,e+a),t.pending),t.pending+=a}(t,e,a)},j=M,L=function(t,e,a,n){for(var r=65535&t,i=t>>>16&65535,s=0;0!==a;){a-=s=a>2e3?2e3:a;do{i=i+(r=r+e[n++]|0)|0}while(--s);r%=65521,i%=65521}return r|i<<16},S=new Uint32Array(function(){for(var t,e=[],a=0;a<256;a++){t=a;for(var n=0;n<8;n++)t=1&t?3988292384^t>>>1:t>>>1;e[a]=t}return e}()),T=function(t,e,a,n){var r=S,i=n+a;t^=-1;for(var s=n;s<i;s++)t=t>>>8^r[255&(t^e[s])];return-1^t},O={2:\"need dictionary\",1:\"stream end\",0:\"\",\"-1\":\"file error\",\"-2\":\"stream error\",\"-3\":\"data error\",\"-4\":\"insufficient memory\",\"-5\":\"buffer error\",\"-6\":\"incompatible version\"},q=j,F=function(t,e,a){return t.pending_buf[t.d_buf+2*t.last_lit]=e>>>8&255,t.pending_buf[t.d_buf+2*t.last_lit+1]=255&e,t.pending_buf[t.l_buf+t.last_lit]=255&a,t.last_lit++,0===e?t.dyn_ltree[2*a]++:(t.matches++,e--,t.dyn_ltree[2*(_[a]+256+1)]++,t.dyn_dtree[2*v(e)]++),t.last_lit===t.lit_bufsize-1},G=-2,H=258,J=262,K=103,N=113,P=666,Q=function(t,e){return t.msg=O[e],e},R=function(t){return(t<<1)-(t>4?9:0)},V=function(t){for(var e=t.length;--e>=0;)t[e]=0},W=function(t,e,a){return(e<<t.hash_shift^a)&t.hash_mask},X=function(t){var e=t.state,a=e.pending;a>t.avail_out&&(a=t.avail_out),0!==a&&(t.output.set(e.pending_buf.subarray(e.pending_out,e.pending_out+a),t.next_out),t.next_out+=a,e.pending_out+=a,t.total_out+=a,t.avail_out-=a,e.pending-=a,0===e.pending&&(e.pending_out=0))},Y=function(t,e){(function(t,e,a,n){var r,l,_=0;t.level>0?(2===t.strm.data_type&&(t.strm.data_type=function(t){var e,a=4093624447;for(e=0;e<=31;e++,a>>>=1)if(1&a&&0!==t.dyn_ltree[2*e])return 0;if(0!==t.dyn_ltree[18]||0!==t.dyn_ltree[20]||0!==t.dyn_ltree[26])return 1;for(e=32;e<256;e++)if(0!==t.dyn_ltree[2*e])return 1;return 0}(t)),I(t,t.l_desc),I(t,t.d_desc),_=function(t){var e;for(E(t,t.dyn_ltree,t.l_desc.max_code),E(t,t.dyn_dtree,t.d_desc.max_code),I(t,t.bl_desc),e=18;e>=3&&0===t.bl_tree[2*i[e]+1];e--);return t.opt_len+=3*(e+1)+5+5+4,e}(t),r=t.opt_len+3+7>>>3,(l=t.static_len+3+7>>>3)<=r&&(r=l)):r=l=a+5,a+4<=r&&-1!==e?M(t,e,a,n):4===t.strategy||l===r?(m(t,2+(n?1:0),3),B(t,s,h)):(m(t,4+(n?1:0),3),function(t,e,a,n){var r;for(m(t,e-257,5),m(t,a-1,5),m(t,n-4,4),r=0;r<n;r++)m(t,t.bl_tree[2*i[r]+1],3);C(t,t.dyn_ltree,e-1),C(t,t.dyn_dtree,a-1)}(t,t.l_desc.max_code+1,t.d_desc.max_code+1,_+1),B(t,t.dyn_ltree,t.dyn_dtree)),k(t),n&&x(t)})(t,t.block_start>=0?t.block_start:-1,t.strstart-t.block_start,e),t.block_start=t.strstart,X(t.strm)},Z=function(t,e){t.pending_buf[t.pending++]=e},$=function(t,e){t.pending_buf[t.pending++]=e>>>8&255,t.pending_buf[t.pending++]=255&e},tt=function(t,e,a,n){var r=t.avail_in;return r>n&&(r=n),0===r?0:(t.avail_in-=r,e.set(t.input.subarray(t.next_in,t.next_in+r),a),1===t.state.wrap?t.adler=L(t.adler,e,r,a):2===t.state.wrap&&(t.adler=T(t.adler,e,r,a)),t.next_in+=r,t.total_in+=r,r)},et=function(t,e){var a,n,r=t.max_chain_length,i=t.strstart,s=t.prev_length,h=t.nice_match,l=t.strstart>t.w_size-J?t.strstart-(t.w_size-J):0,_=t.window,o=t.w_mask,d=t.prev,u=t.strstart+H,f=_[i+s-1],c=_[i+s];t.prev_length>=t.good_match&&(r>>=2),h>t.lookahead&&(h=t.lookahead);do{if(_[(a=e)+s]===c&&_[a+s-1]===f&&_[a]===_[i]&&_[++a]===_[i+1]){i+=2,a++;do{}while(_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&i<u);if(n=H-(u-i),i=u-H,n>s){if(t.match_start=e,s=n,n>=h)break;f=_[i+s-1],c=_[i+s]}}}while((e=d[e&o])>l&&0!==--r);return s<=t.lookahead?s:t.lookahead},at=function(t){var e,a,n,r,i,s=t.w_size;do{if(r=t.window_size-t.lookahead-t.strstart,t.strstart>=s+(s-J)){t.window.set(t.window.subarray(s,s+s),0),t.match_start-=s,t.strstart-=s,t.block_start-=s,e=a=t.hash_size;do{n=t.head[--e],t.head[e]=n>=s?n-s:0}while(--a);e=a=s;do{n=t.prev[--e],t.prev[e]=n>=s?n-s:0}while(--a);r+=s}if(0===t.strm.avail_in)break;if(a=tt(t.strm,t.window,t.strstart+t.lookahead,r),t.lookahead+=a,t.lookahead+t.insert>=3)for(i=t.strstart-t.insert,t.ins_h=t.window[i],t.ins_h=W(t,t.ins_h,t.window[i+1]);t.insert&&(t.ins_h=W(t,t.ins_h,t.window[i+3-1]),t.prev[i&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=i,i++,t.insert--,!(t.lookahead+t.insert<3)););}while(t.lookahead<J&&0!==t.strm.avail_in)},nt=function(t,e){for(var a,n;;){if(t.lookahead<J){if(at(t),t.lookahead<J&&0===e)return 1;if(0===t.lookahead)break}if(a=0,t.lookahead>=3&&(t.ins_h=W(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart),0!==a&&t.strstart-a<=t.w_size-J&&(t.match_length=et(t,a)),t.match_length>=3)if(n=F(t,t.strstart-t.match_start,t.match_length-3),t.lookahead-=t.match_length,t.match_length<=t.max_lazy_match&&t.lookahead>=3){t.match_length--;do{t.strstart++,t.ins_h=W(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart}while(0!==--t.match_length);t.strstart++}else t.strstart+=t.match_length,t.match_length=0,t.ins_h=t.window[t.strstart],t.ins_h=W(t,t.ins_h,t.window[t.strstart+1]);else n=F(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++;if(n&&(Y(t,!1),0===t.strm.avail_out))return 1}return t.insert=t.strstart<2?t.strstart:2,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):t.last_lit&&(Y(t,!1),0===t.strm.avail_out)?1:2},rt=function(t,e){for(var a,n,r;;){if(t.lookahead<J){if(at(t),t.lookahead<J&&0===e)return 1;if(0===t.lookahead)break}if(a=0,t.lookahead>=3&&(t.ins_h=W(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart),t.prev_length=t.match_length,t.prev_match=t.match_start,t.match_length=2,0!==a&&t.prev_length<t.max_lazy_match&&t.strstart-a<=t.w_size-J&&(t.match_length=et(t,a),t.match_length<=5&&(1===t.strategy||3===t.match_length&&t.strstart-t.match_start>4096)&&(t.match_length=2)),t.prev_length>=3&&t.match_length<=t.prev_length){r=t.strstart+t.lookahead-3,n=F(t,t.strstart-1-t.prev_match,t.prev_length-3),t.lookahead-=t.prev_length-1,t.prev_length-=2;do{++t.strstart<=r&&(t.ins_h=W(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart)}while(0!==--t.prev_length);if(t.match_available=0,t.match_length=2,t.strstart++,n&&(Y(t,!1),0===t.strm.avail_out))return 1}else if(t.match_available){if((n=F(t,0,t.window[t.strstart-1]))&&Y(t,!1),t.strstart++,t.lookahead--,0===t.strm.avail_out)return 1}else t.match_available=1,t.strstart++,t.lookahead--}return t.match_available&&(n=F(t,0,t.window[t.strstart-1]),t.match_available=0),t.insert=t.strstart<2?t.strstart:2,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):t.last_lit&&(Y(t,!1),0===t.strm.avail_out)?1:2};function it(t,e,a,n,r){this.good_length=t,this.max_lazy=e,this.nice_length=a,this.max_chain=n,this.func=r}var st=[new it(0,0,0,0,function(t,e){var a=65535;for(a>t.pending_buf_size-5&&(a=t.pending_buf_size-5);;){if(t.lookahead<=1){if(at(t),0===t.lookahead&&0===e)return 1;if(0===t.lookahead)break}t.strstart+=t.lookahead,t.lookahead=0;var n=t.block_start+a;if((0===t.strstart||t.strstart>=n)&&(t.lookahead=t.strstart-n,t.strstart=n,Y(t,!1),0===t.strm.avail_out))return 1;if(t.strstart-t.block_start>=t.w_size-J&&(Y(t,!1),0===t.strm.avail_out))return 1}return t.insert=0,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):(t.strstart>t.block_start&&(Y(t,!1),t.strm.avail_out),1)}),new it(4,4,8,4,nt),new it(4,5,16,8,nt),new it(4,6,32,32,nt),new it(4,4,16,16,rt),new it(8,16,32,32,rt),new it(8,16,128,128,rt),new it(8,32,128,256,rt),new it(32,128,258,1024,rt),new it(32,258,258,4096,rt)];function ht(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=8,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new Uint16Array(1146),this.dyn_dtree=new Uint16Array(122),this.bl_tree=new Uint16Array(78),V(this.dyn_ltree),V(this.dyn_dtree),V(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new Uint16Array(16),this.heap=new Uint16Array(573),V(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new Uint16Array(573),V(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}for(var lt=function(t){var e,i=function(t){if(!t||!t.state)return Q(t,G);t.total_in=t.total_out=0,t.data_type=2;var e=t.state;return e.pending=0,e.pending_out=0,e.wrap<0&&(e.wrap=-e.wrap),e.status=e.wrap?42:N,t.adler=2===e.wrap?0:1,e.last_flush=0,function(t){D||(function(){var t,e,i,g,v,w=Array(16);for(i=0,g=0;g<28;g++)for(o[g]=i,t=0;t<1<<a[g];t++)_[i++]=g;for(_[i-1]=g,v=0,g=0;g<16;g++)for(c[g]=v,t=0;t<1<<n[g];t++)l[v++]=g;for(v>>=7;g<30;g++)for(c[g]=v<<7,t=0;t<1<<n[g]-7;t++)l[256+v++]=g;for(e=0;e<=15;e++)w[e]=0;for(t=0;t<=143;)s[2*t+1]=8,t++,w[8]++;for(;t<=255;)s[2*t+1]=9,t++,w[9]++;for(;t<=279;)s[2*t+1]=7,t++,w[7]++;for(;t<=287;)s[2*t+1]=8,t++,w[8]++;for(z(s,287,w),t=0;t<30;t++)h[2*t+1]=5,h[2*t]=y(t,5);d=new p(s,a,257,286,15),u=new p(h,n,0,30,15),f=new p([],r,0,19,7)}(),D=!0),t.l_desc=new g(t.dyn_ltree,d),t.d_desc=new g(t.dyn_dtree,u),t.bl_desc=new g(t.bl_tree,f),t.bi_buf=0,t.bi_valid=0,k(t)}(e),0}(t);return 0===i&&((e=t.state).window_size=2*e.w_size,V(e.head),e.max_lazy_match=st[e.level].max_lazy,e.good_match=st[e.level].good_length,e.nice_match=st[e.level].nice_length,e.max_chain_length=st[e.level].max_chain,e.strstart=0,e.block_start=0,e.lookahead=0,e.insert=0,e.match_length=e.prev_length=2,e.match_available=0,e.ins_h=0),i},_t=function(t,e){var a,n;if(!t||!t.state||e>5||e<0)return t?Q(t,G):G;var r=t.state;if(!t.output||!t.input&&0!==t.avail_in||r.status===P&&4!==e)return Q(t,0===t.avail_out?-5:G);r.strm=t;var i=r.last_flush;if(r.last_flush=e,42===r.status)if(2===r.wrap)t.adler=0,Z(r,31),Z(r,139),Z(r,8),r.gzhead?(Z(r,(r.gzhead.text?1:0)+(r.gzhead.hcrc?2:0)+(r.gzhead.extra?4:0)+(r.gzhead.name?8:0)+(r.gzhead.comment?16:0)),Z(r,255&r.gzhead.time),Z(r,r.gzhead.time>>8&255),Z(r,r.gzhead.time>>16&255),Z(r,r.gzhead.time>>24&255),Z(r,9===r.level?2:r.strategy>=2||r.level<2?4:0),Z(r,255&r.gzhead.os),r.gzhead.extra&&r.gzhead.extra.length&&(Z(r,255&r.gzhead.extra.length),Z(r,r.gzhead.extra.length>>8&255)),r.gzhead.hcrc&&(t.adler=T(t.adler,r.pending_buf,r.pending,0)),r.gzindex=0,r.status=69):(Z(r,0),Z(r,0),Z(r,0),Z(r,0),Z(r,0),Z(r,9===r.level?2:r.strategy>=2||r.level<2?4:0),Z(r,3),r.status=N);else{var h=8+(r.w_bits-8<<4)<<8;h|=(r.strategy>=2||r.level<2?0:r.level<6?1:6===r.level?2:3)<<6,0!==r.strstart&&(h|=32),h+=31-h%31,r.status=N,$(r,h),0!==r.strstart&&($(r,t.adler>>>16),$(r,65535&t.adler)),t.adler=1}if(69===r.status)if(r.gzhead.extra){for(a=r.pending;r.gzindex<(65535&r.gzhead.extra.length)&&(r.pending!==r.pending_buf_size||(r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),X(t),a=r.pending,r.pending!==r.pending_buf_size));)Z(r,255&r.gzhead.extra[r.gzindex]),r.gzindex++;r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),r.gzindex===r.gzhead.extra.length&&(r.gzindex=0,r.status=73)}else r.status=73;if(73===r.status)if(r.gzhead.name){a=r.pending;do{if(r.pending===r.pending_buf_size&&(r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),X(t),a=r.pending,r.pending===r.pending_buf_size)){n=1;break}n=r.gzindex<r.gzhead.name.length?255&r.gzhead.name.charCodeAt(r.gzindex++):0,Z(r,n)}while(0!==n);r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),0===n&&(r.gzindex=0,r.status=91)}else r.status=91;if(91===r.status)if(r.gzhead.comment){a=r.pending;do{if(r.pending===r.pending_buf_size&&(r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),X(t),a=r.pending,r.pending===r.pending_buf_size)){n=1;break}n=r.gzindex<r.gzhead.comment.length?255&r.gzhead.comment.charCodeAt(r.gzindex++):0,Z(r,n)}while(0!==n);r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),0===n&&(r.status=K)}else r.status=K;if(r.status===K&&(r.gzhead.hcrc?(r.pending+2>r.pending_buf_size&&X(t),r.pending+2<=r.pending_buf_size&&(Z(r,255&t.adler),Z(r,t.adler>>8&255),t.adler=0,r.status=N)):r.status=N),0!==r.pending){if(X(t),0===t.avail_out)return r.last_flush=-1,0}else if(0===t.avail_in&&R(e)<=R(i)&&4!==e)return Q(t,-5);if(r.status===P&&0!==t.avail_in)return Q(t,-5);if(0!==t.avail_in||0!==r.lookahead||0!==e&&r.status!==P){var l=2===r.strategy?function(t,e){for(var a;;){if(0===t.lookahead&&(at(t),0===t.lookahead)){if(0===e)return 1;break}if(t.match_length=0,a=F(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++,a&&(Y(t,!1),0===t.strm.avail_out))return 1}return t.insert=0,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):t.last_lit&&(Y(t,!1),0===t.strm.avail_out)?1:2}(r,e):3===r.strategy?function(t,e){for(var a,n,r,i,s=t.window;;){if(t.lookahead<=H){if(at(t),t.lookahead<=H&&0===e)return 1;if(0===t.lookahead)break}if(t.match_length=0,t.lookahead>=3&&t.strstart>0&&(n=s[r=t.strstart-1])===s[++r]&&n===s[++r]&&n===s[++r]){i=t.strstart+H;do{}while(n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&r<i);t.match_length=H-(i-r),t.match_length>t.lookahead&&(t.match_length=t.lookahead)}if(t.match_length>=3?(a=F(t,1,t.match_length-3),t.lookahead-=t.match_length,t.strstart+=t.match_length,t.match_length=0):(a=F(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++),a&&(Y(t,!1),0===t.strm.avail_out))return 1}return t.insert=0,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):t.last_lit&&(Y(t,!1),0===t.strm.avail_out)?1:2}(r,e):st[r.level].func(r,e);if(3!==l&&4!==l||(r.status=P),1===l||3===l)return 0===t.avail_out&&(r.last_flush=-1),0;if(2===l&&(1===e?function(t){m(t,2,3),b(t,256,s),function(t){16===t.bi_valid?(w(t,t.bi_buf),t.bi_buf=0,t.bi_valid=0):t.bi_valid>=8&&(t.pending_buf[t.pending++]=255&t.bi_buf,t.bi_buf>>=8,t.bi_valid-=8)}(t)}(r):5!==e&&(q(r,0,0,!1),3===e&&(V(r.head),0===r.lookahead&&(r.strstart=0,r.block_start=0,r.insert=0))),X(t),0===t.avail_out))return r.last_flush=-1,0}return 4!==e?0:r.wrap<=0?1:(2===r.wrap?(Z(r,255&t.adler),Z(r,t.adler>>8&255),Z(r,t.adler>>16&255),Z(r,t.adler>>24&255),Z(r,255&t.total_in),Z(r,t.total_in>>8&255),Z(r,t.total_in>>16&255),Z(r,t.total_in>>24&255)):($(r,t.adler>>>16),$(r,65535&t.adler)),X(t),r.wrap>0&&(r.wrap=-r.wrap),0!==r.pending?0:1)},ot=function(t){if(!t||!t.state)return G;var e=t.state.status;return 42!==e&&69!==e&&73!==e&&91!==e&&e!==K&&e!==N&&e!==P?Q(t,G):(t.state=null,e===N?Q(t,-3):0)},dt=new Uint8Array(256),ut=0;ut<256;ut++)dt[ut]=ut>=252?6:ut>=248?5:ut>=240?4:ut>=224?3:ut>=192?2:1;dt[254]=dt[254]=1;var ft=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg=\"\",this.state=null,this.data_type=2,this.adler=0},ct=Object.prototype.toString;function pt(){this.options={level:-1,method:8,chunkSize:16384,windowBits:15,memLevel:8,strategy:0};var t=this.options;t.raw&&t.windowBits>0?t.windowBits=-t.windowBits:t.gzip&&t.windowBits>0&&t.windowBits<16&&(t.windowBits+=16),this.err=0,this.msg=\"\",this.ended=!1,this.chunks=[],this.strm=new ft,this.strm.avail_out=0;var e,a,n=function(t,e,a,n,r,i){if(!t)return G;var s=1;if(-1===e&&(e=6),n<0?(s=0,n=-n):n>15&&(s=2,n-=16),r<1||r>9||8!==a||n<8||n>15||e<0||e>9||i<0||i>4)return Q(t,G);8===n&&(n=9);var h=new ht;return t.state=h,h.strm=t,h.wrap=s,h.gzhead=null,h.w_bits=n,h.w_size=1<<h.w_bits,h.w_mask=h.w_size-1,h.hash_bits=r+7,h.hash_size=1<<h.hash_bits,h.hash_mask=h.hash_size-1,h.hash_shift=~~((h.hash_bits+3-1)/3),h.window=new Uint8Array(2*h.w_size),h.head=new Uint16Array(h.hash_size),h.prev=new Uint16Array(h.w_size),h.lit_bufsize=1<<r+6,h.pending_buf_size=4*h.lit_bufsize,h.pending_buf=new Uint8Array(h.pending_buf_size),h.d_buf=1*h.lit_bufsize,h.l_buf=3*h.lit_bufsize,h.level=e,h.strategy=i,h.method=a,lt(t)}(this.strm,t.level,t.method,t.windowBits,t.memLevel,t.strategy);if(0!==n)throw Error(O[n]);if(t.header&&(e=this.strm,a=t.header,e&&e.state&&(2!==e.state.wrap||(e.state.gzhead=a))),t.dictionary){var r;if(r=\"[object ArrayBuffer]\"===ct.call(t.dictionary)?new Uint8Array(t.dictionary):t.dictionary,0!==(n=function(t,e){var a=e.length;if(!t||!t.state)return G;var n=t.state,r=n.wrap;if(2===r||1===r&&42!==n.status||n.lookahead)return G;if(1===r&&(t.adler=L(t.adler,e,a,0)),n.wrap=0,a>=n.w_size){0===r&&(V(n.head),n.strstart=0,n.block_start=0,n.insert=0);var i=new Uint8Array(n.w_size);i.set(e.subarray(a-n.w_size,a),0),e=i,a=n.w_size}var s=t.avail_in,h=t.next_in,l=t.input;for(t.avail_in=a,t.next_in=0,t.input=e,at(n);n.lookahead>=3;){var _=n.strstart,o=n.lookahead-2;do{n.ins_h=W(n,n.ins_h,n.window[_+3-1]),n.prev[_&n.w_mask]=n.head[n.ins_h],n.head[n.ins_h]=_,_++}while(--o);n.strstart=_,n.lookahead=2,at(n)}return n.strstart+=n.lookahead,n.block_start=n.strstart,n.insert=n.lookahead,n.lookahead=0,n.match_length=n.prev_length=2,n.match_available=0,t.next_in=h,t.input=l,t.avail_in=s,n.wrap=r,0}(this.strm,r)))throw Error(O[n]);this._dict_set=!0}}function gt(t,e,a){try{t.postMessage({type:\"errored\",error:e,streamId:a})}catch(n){t.postMessage({type:\"errored\",error:e+\"\",streamId:a})}}function vt(t){const e=t.strm.adler;return new Uint8Array([3,0,e>>>24&255,e>>>16&255,e>>>8&255,255&e])}pt.prototype.push=function(t,e){var a,n,r=this.strm,i=this.options.chunkSize;if(this.ended)return!1;for(n=e===~~e?e:!0===e?4:0,\"[object ArrayBuffer]\"===ct.call(t)?r.input=new Uint8Array(t):r.input=t,r.next_in=0,r.avail_in=r.input.length;;)if(0===r.avail_out&&(r.output=new Uint8Array(i),r.next_out=0,r.avail_out=i),(2===n||3===n)&&r.avail_out<=6)this.onData(r.output.subarray(0,r.next_out)),r.avail_out=0;else{if(1===(a=_t(r,n)))return r.next_out>0&&this.onData(r.output.subarray(0,r.next_out)),a=ot(this.strm),this.onEnd(a),this.ended=!0,0===a;if(0!==r.avail_out){if(n>0&&r.next_out>0)this.onData(r.output.subarray(0,r.next_out)),r.avail_out=0;else if(0===r.avail_in)break}else this.onData(r.output)}return!0},pt.prototype.onData=function(t){this.chunks.push(t)},pt.prototype.onEnd=function(t){0===t&&(this.result=function(t){for(var e=0,a=0,n=t.length;a<n;a++)e+=t[a].length;for(var r=new Uint8Array(e),i=0,s=0,h=t.length;i<h;i++){var l=t[i];r.set(l,s),s+=l.length}return r}(this.chunks)),this.chunks=[],this.err=t,this.msg=this.strm.msg},function(e=self){try{const a=new Map;e.addEventListener(\"message\",n=>{try{const r=function(e,a){switch(a.action){case\"init\":return{type:\"initialized\",version:\"6.31.0\"};case\"write\":{let n=e.get(a.streamId);n||(n=new pt,e.set(a.streamId,n));const r=n.chunks.length,i=function(t){if(\"function\"==typeof TextEncoder&&TextEncoder.prototype.encode)return(new TextEncoder).encode(t);let e,a,n,r,i,s=t.length,h=0;for(r=0;r<s;r++)a=t.charCodeAt(r),55296==(64512&a)&&r+1<s&&(n=t.charCodeAt(r+1),56320==(64512&n)&&(a=65536+(a-55296<<10)+(n-56320),r++)),h+=a<128?1:a<2048?2:a<65536?3:4;for(e=new Uint8Array(h),i=0,r=0;i<h;r++)a=t.charCodeAt(r),55296==(64512&a)&&r+1<s&&(n=t.charCodeAt(r+1),56320==(64512&n)&&(a=65536+(a-55296<<10)+(n-56320),r++)),a<128?e[i++]=a:a<2048?(e[i++]=192|a>>>6,e[i++]=128|63&a):a<65536?(e[i++]=224|a>>>12,e[i++]=128|a>>>6&63,e[i++]=128|63&a):(e[i++]=240|a>>>18,e[i++]=128|a>>>12&63,e[i++]=128|a>>>6&63,e[i++]=128|63&a);return e}(a.data);return n.push(i,2),{type:\"wrote\",id:a.id,streamId:a.streamId,result:t(n.chunks.slice(r)),trailer:vt(n),additionalBytesCount:i.length}}case\"reset\":e.delete(a.streamId)}}(a,n.data);r&&e.postMessage(r)}catch(t){gt(e,t,n.data&&\"streamId\"in n.data?n.data.streamId:void 0)}})}catch(t){gt(e,t)}}()})();"])));
}
var z = {
    status: 0
};

function Cc(e, t, n) {
    switch (z.status === 0 && Tc(e, t), z.status) {
        case 1:
            return z.initializationFailureCallbacks.push(n), z.worker;
        case 3:
            return z.worker;
    }
}

function wc() {
    return z.status;
}

function Tc(e, t) {
    try {
        let n = ve(Sc)(e),
            {
                stop: r
            } = ze(e, n, "error", (n) => {
                Oc(e, t, n);
            }),
            {
                stop: i
            } = ze(e, n, "message", ({
                data: n
            }) => {
                n.type === "errored" ? Oc(e, t, n.error, n.streamId) : n.type === "initialized" && Dc(n.version);
            });
        n.postMessage({
            action: "init"
        }), je(() => Ec(t), xc), z = {
            status: 1,
            worker: n,
            stop: () => {
                r(), i();
            },
            initializationFailureCallbacks: []
        };
    } catch (n) {
        Oc(e, t, n);
    }
}

function Ec(e) {
    z.status === 1 && (a.error(`${e} failed to start: a timeout occurred while initializing the Worker`), z.initializationFailureCallbacks.forEach((e) => e()), z = {
        status: 2
    });
}

function Dc(e) {
    z.status === 1 && (z = {
        status: 3,
        worker: z.worker,
        stop: z.stop,
        version: e
    });
}

function Oc(e, t, n, r) {
    z.status === 1 || z.status === 0 ? (yc({
        configuredUrl: e.workerUrl,
        error: n,
        source: t,
        scriptType: "worker"
    }), z.status === 1 && z.initializationFailureCallbacks.forEach((e) => e()), z = {
        status: 2
    }) : Pe(n, {
        worker_version: z.status === 3 && z.version,
        stream_id: r
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/boot/isBrowserSupported.js
function kc() {
    return typeof Array.from == "function" && typeof CSSSupportsRule == "function" && typeof URL.createObjectURL == "function" && "forEach" in NodeList.prototype;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/domain/getSessionReplayLink.js
function Ac(e, t, n, r) {
    let i = t.findTrackedSession(),
        a = jc(i, r);
    return Ue(e, {
        viewContext: n.findView(),
        errorType: a,
        session: i
    });
}

function jc(e, t) {
    if (!kc()) return "browser-not-supported";
    if (!e) return "rum-not-tracked";
    if (e.sessionReplay === 0) return "incorrect-session-plan";
    if (!t) return "replay-not-started";
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/domain/startRecorderInitTelemetry.js
function Mc(e, t) {
    if (!e.metricsEnabled) return {
        stop: Ne
    };
    let n, r, i, {
        unsubscribe: a
    } = t.subscribe((e) => {
        switch (e.type) {
            case "start":
                n = {
                    forced: e.forced,
                    timestamp: qe()
                }, r = void 0, i = void 0;
                break;
            case "document-ready":
                n && (r = Ee(n.timestamp, qe()));
                break;
            case "recorder-settled":
                n && (i = Ee(n.timestamp, qe()));
                break;
            case "aborted":
            case "deflate-encoder-load-failed":
            case "recorder-load-failed":
            case "succeeded":
                a(), n && xe("Recorder init metrics", {
                    metrics: Nc(n.forced, i, Ee(n.timestamp, qe()), e.type, r)
                });
                break;
        }
    });
    return {
        stop: a
    };
}

function Nc(e, t, n, r, i) {
    return {
        forced: e,
        loadRecorderModuleDuration: t,
        recorderInitDuration: n,
        result: r,
        waitForDocReadyDuration: i
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/boot/postStartStrategy.js
function Pc(e, t, n, r, i, a, o) {
    let s = 0,
        c;
    t.subscribe(9, () => {
        (s === 2 || s === 3) && (f(), s = 1);
    }), t.subscribe(10, () => {
        s === 1 && d();
    });
    let l = new Ve();
    Mc(o, l);
    let u = async (u) => {
        l.notify({
            type: "start",
            forced: u
        });
        let [d] = await Promise.all([Rc(l, {
            type: "recorder-settled"
        }, i()), Rc(l, {
            type: "document-ready"
        }, he(e, "interactive"))]);
        if (s !== 2) {
            l.notify({
                type: "aborted"
            });
            return;
        }
        if (!d) {
            s = 0, l.notify({
                type: "recorder-load-failed"
            });
            return;
        }
        let f = a();
        if (!f) {
            s = 0, l.notify({
                type: "deflate-encoder-load-failed"
            });
            return;
        }
        ({
            stop: c
        } = d(t, e, n, r, f, o)), s = 3, l.notify({
            type: "succeeded"
        });
    };

    function d(e) {
        let t = n.findTrackedSession();
        if (Fc(t, e)) {
            s = 1;
            return;
        }
        if (Ic(s)) return;
        s = 2;
        let r = Lc(t, e) || !1;
        u(r).catch(ct), r && n.setForcedReplay();
    }

    function f() {
        s === 3 && c ? .(), s = 0;
    }
    return {
        start: d,
        stop: f,
        getSessionReplayLink() {
            return Ac(e, n, r, s !== 0);
        },
        isRecording: () => s === 3
    };
}

function Fc(e, t) {
    return !e || e.sessionReplay === 0 && (!t || !t.force);
}

function Ic(e) {
    return e === 2 || e === 3;
}

function Lc(e, t) {
    return t && t.force && e.sessionReplay === 0;
}
async function Rc(e, t, n) {
    try {
        return await n;
    } finally {
        e.notify(t);
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/boot/preStartStrategy.js
function zc() {
    let e = 0;
    return {
        strategy: {
            start() {
                e = 1;
            },
            stop() {
                e = 2;
            },
            isRecording: () => !1,
            getSessionReplayLink: Ne
        },
        shouldStartImmediately(t) {
            return e === 1 || e === 0 && !t.startSessionReplayRecordingManually;
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/boot/recorderApi.js
function Bc(e) {
    if (be() && !Me("records") || !kc()) return {
        start: Ne,
        stop: Ne,
        getReplayStats: () => void 0,
        onRumStart: Ne,
        isRecording: () => !1,
        getSessionReplayLink: () => void 0
    };
    let {
        strategy: t,
        shouldStartImmediately: n
    } = zc();
    return {
        start: (e) => t.start(e),
        stop: () => t.stop(),
        getSessionReplayLink: () => t.getSessionReplayLink(),
        onRumStart: r,
        isRecording: () => wc() === 3 && t.isRecording(),
        getReplayStats: (e) => wc() === 3 ? ft(e) : void 0
    };

    function r(r, i, a, o, s, c) {
        let l;

        function u() {
            return l || (s ? ? = Cc(i, "Datadog Session Replay", () => t.stop()), s && (l = vc(i, s, 1))), l;
        }
        t = Pc(i, r, a, o, e, u, c), n(i) && t.start();
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/boot/lazyLoadRecorder.js
async function Vc() {
    try {
        return await ve(Hc)();
    } catch (e) {
        yc({
            error: e,
            source: "Recorder",
            scriptType: "module"
        });
    }
}
async function Hc() {
    return (await
        import (
            /* webpackChunkName: "recorder" */
            "./startRecording-COoumJjR.js"
        )).startRecording;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/domain/profiling/profilingSupported.js
function Uc() {
    return ot().Profiler !== void 0;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/domain/profiling/profilingContext.js
function Wc(e) {
    let t = {
        status: "starting"
    };
    return e.register(0, ({
        eventType: e
    }) => e !== Le.VIEW && e !== Le.LONG_TASK && e !== Le.ACTION && e !== Le.VITAL ? Be : {
        type: e,
        _dd: {
            profiling: t
        }
    }), {
        get: () => t,
        set: (e) => {
            t = e;
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/boot/lazyLoadProfiler.js
async function Gc() {
    try {
        return await ve(Kc)();
    } catch (e) {
        yc({
            error: e,
            source: "Profiler",
            scriptType: "module"
        });
    }
}
async function Kc() {
    return (await
        import (
            /* webpackChunkName: "profiler" */
            "./profiler-BRJEKBgJ.js"
        )).createRumProfiler;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum/esm/boot/profilerApi.js
function qc() {
    let e;

    function t(t, n, r, i, a, o) {
        let s = i.findTrackedSession();
        if (!s || !oe(s.id, r.profilingSampleRate)) return;
        let c = Wc(n);
        if (!Uc()) {
            c.set({
                status: "error",
                error_reason: "not-supported-by-browser"
            });
            return;
        }
        Gc().then((n) => {
            if (!n) {
                c.set({
                    status: "error",
                    error_reason: "failed-to-lazy-load"
                });
                return;
            }
            e = n(r, t, i, c, o, a, void 0), e.start();
        }).catch(ct);
    }
    return {
        onRumStart: t,
        stop: () => {
            e ? .stop();
        }
    };
}
var Jc = Xe(Bc(Vc), qc(), {
    startDeflateWorker: Cc,
    createDeflateEncoder: vc,
    sdkName: "rum"
});
S(ot(), "DD_RUM", Jc);
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/debug-build.js
var B = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__,
    V = globalThis,
    Yc = "10.38.0";
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/carrier.js
function Xc() {
    return Zc(V), V;
}

function Zc(e) {
    let t = e.__SENTRY__ = e.__SENTRY__ || {};
    return t.version = t.version || "10.38.0", t[Yc] = t["10.38.0"] || {};
}

function Qc(e, t, n = V) {
    let r = n.__SENTRY__ = n.__SENTRY__ || {},
        i = r[Yc] = r["10.38.0"] || {};
    return i[e] || (i[e] = t());
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/debug-logger.js
var $c = [
        "debug",
        "info",
        "warn",
        "error",
        "log",
        "assert",
        "trace"
    ],
    el = "Sentry Logger ",
    tl = {};

function nl(e) {
    if (!("console" in V)) return e();
    let t = V.console,
        n = {},
        r = Object.keys(tl);
    r.forEach((e) => {
        let r = tl[e];
        n[e] = t[e], t[e] = r;
    });
    try {
        return e();
    } finally {
        r.forEach((e) => {
            t[e] = n[e];
        });
    }
}

function rl() {
    ul().enabled = !0;
}

function il() {
    ul().enabled = !1;
}

function al() {
    return ul().enabled;
}

function ol(...e) {
    ll("log", ...e);
}

function sl(...e) {
    ll("warn", ...e);
}

function cl(...e) {
    ll("error", ...e);
}

function ll(e, ...t) {
    B && al() && nl(() => {
        V.console[e](`${el}[${e}]:`, ...t);
    });
}

function ul() {
    return B ? Qc("loggerSettings", () => ({
        enabled: !1
    })) : {
        enabled: !1
    };
}
var H = {
        enable: rl,
        disable: il,
        isEnabled: al,
        log: ol,
        warn: sl,
        error: cl
    },
    dl = 50,
    fl = /\(error: (.*)\)/,
    pl = /captureMessage|captureException/;

function ml(...e) {
    let t = e.sort((e, t) => e[0] - t[0]).map((e) => e[1]);
    return (e, n = 0, r = 0) => {
        let i = [],
            a = e.split("\n");
        for (let e = n; e < a.length; e++) {
            let n = a[e];
            n.length > 1024 && (n = n.slice(0, 1024));
            let o = fl.test(n) ? n.replace(fl, "$1") : n;
            if (!o.match(/\S*Error: /)) {
                for (let e of t) {
                    let t = e(o);
                    if (t) {
                        i.push(t);
                        break;
                    }
                }
                if (i.length >= dl + r) break;
            }
        }
        return gl(i.slice(r));
    };
}

function hl(e) {
    return Array.isArray(e) ? ml(...e) : e;
}

function gl(e) {
    if (!e.length) return [];
    let t = Array.from(e);
    return /sentryWrapped/.test(_l(t).function || "") && t.pop(), t.reverse(), pl.test(_l(t).function || "") && (t.pop(), pl.test(_l(t).function || "") && t.pop()), t.slice(0, dl).map((e) => ({
        ...e,
        filename: e.filename || _l(t).filename,
        function: e.function || "?"
    }));
}

function _l(e) {
    return e[e.length - 1] || {};
}
var vl = "<anonymous>";

function yl(e) {
    try {
        return !e || typeof e != "function" ? vl : e.name || vl;
    } catch {
        return vl;
    }
}

function bl(e) {
    let t = e.exception;
    if (t) {
        let e = [];
        try {
            return t.values.forEach((t) => {
                t.stacktrace.frames && e.push(...t.stacktrace.frames);
            }), e;
        } catch {
            return;
        }
    }
}

function xl(e) {
    return "__v_isVNode" in e && e.__v_isVNode ? "[VueVNode]" : "[VueViewModel]";
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/instrument/handlers.js
var Sl = {},
    Cl = {};

function wl(e, t) {
    Sl[e] = Sl[e] || [], Sl[e].push(t);
}

function Tl(e, t) {
    if (!Cl[e]) {
        Cl[e] = !0;
        try {
            t();
        } catch (t) {
            B && H.error(`Error while instrumenting ${e}`, t);
        }
    }
}

function El(e, t) {
    let n = e && Sl[e];
    if (n)
        for (let r of n) try {
            r(t);
        } catch (t) {
            B && H.error(`Error while triggering instrumentation handler.\nType: ${e}\nName: ${yl(r)}\nError:`, t);
        }
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/instrument/globalError.js
var Dl = null;

function Ol(e) {
    let t = "error";
    wl(t, e), Tl(t, kl);
}

function kl() {
    Dl = V.onerror, V.onerror = function(e, t, n, r, i) {
        return El("error", {
            column: r,
            error: i,
            line: n,
            msg: e,
            url: t
        }), Dl ? Dl.apply(this, arguments) : !1;
    }, V.onerror.__SENTRY_INSTRUMENTED__ = !0;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/instrument/globalUnhandledRejection.js
var Al = null;

function jl(e) {
    let t = "unhandledrejection";
    wl(t, e), Tl(t, Ml);
}

function Ml() {
    Al = V.onunhandledrejection, V.onunhandledrejection = function(e) {
        return El("unhandledrejection", e), Al ? Al.apply(this, arguments) : !0;
    }, V.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/is.js
var Nl = Object.prototype.toString;

function Pl(e) {
    switch (Nl.call(e)) {
        case "[object Error]":
        case "[object Exception]":
        case "[object DOMException]":
        case "[object WebAssembly.Exception]":
            return !0;
        default:
            return Jl(e, Error);
    }
}

function Fl(e, t) {
    return Nl.call(e) === `[object ${t}]`;
}

function Il(e) {
    return Fl(e, "ErrorEvent");
}

function Ll(e) {
    return Fl(e, "DOMError");
}

function Rl(e) {
    return Fl(e, "DOMException");
}

function zl(e) {
    return Fl(e, "String");
}

function Bl(e) {
    return typeof e == "object" && !!e && "__sentry_template_string__" in e && "__sentry_template_values__" in e;
}

function Vl(e) {
    return e === null || Bl(e) || typeof e != "object" && typeof e != "function";
}

function Hl(e) {
    return Fl(e, "Object");
}

function Ul(e) {
    return typeof Event < "u" && Jl(e, Event);
}

function Wl(e) {
    return typeof Element < "u" && Jl(e, Element);
}

function Gl(e) {
    return Fl(e, "RegExp");
}

function Kl(e) {
    return !!(e ? .then && typeof e.then == "function");
}

function ql(e) {
    return Hl(e) && "nativeEvent" in e && "preventDefault" in e && "stopPropagation" in e;
}

function Jl(e, t) {
    try {
        return e instanceof t;
    } catch {
        return !1;
    }
}

function Yl(e) {
    return !!(typeof e == "object" && e && (e.__isVue || e._isVue || e.__v_isVNode));
}

function Xl(e) {
    return typeof Request < "u" && Jl(e, Request);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/browser.js
var Zl = V,
    Ql = 80;

function $l(e, t = {}) {
    if (!e) return "<unknown>";
    try {
        let n = e,
            r = [],
            i = 0,
            a = 0,
            o, s = Array.isArray(t) ? t : t.keyAttrs,
            c = !Array.isArray(t) && t.maxStringLength || Ql;
        for (; n && i++ < 5 && (o = eu(n, s), !(o === "html" || i > 1 && a + r.length * 3 + o.length >= c));) r.push(o), a += o.length, n = n.parentNode;
        return r.reverse().join(" > ");
    } catch {
        return "<unknown>";
    }
}

function eu(e, t) {
    let n = e,
        r = [];
    if (!n ? .tagName) return "";
    if (Zl.HTMLElement && n instanceof HTMLElement && n.dataset) {
        if (n.dataset.sentryComponent) return n.dataset.sentryComponent;
        if (n.dataset.sentryElement) return n.dataset.sentryElement;
    }
    r.push(n.tagName.toLowerCase());
    let i = t ? .length ? t.filter((e) => n.getAttribute(e)).map((e) => [e, n.getAttribute(e)]) : null;
    if (i ? .length) i.forEach((e) => {
        r.push(`[${e[0]}="${e[1]}"]`);
    });
    else {
        n.id && r.push(`#${n.id}`);
        let e = n.className;
        if (e && zl(e)) {
            let t = e.split(/\s+/);
            for (let e of t) r.push(`.${e}`);
        }
    }
    for (let e of [
            "aria-label",
            "type",
            "name",
            "title",
            "alt"
        ]) {
        let t = n.getAttribute(e);
        t && r.push(`[${e}="${t}"]`);
    }
    return r.join("");
}

function tu() {
    try {
        return Zl.document.location.href;
    } catch {
        return "";
    }
}

function nu(e) {
    if (!Zl.HTMLElement) return null;
    let t = e;
    for (let e = 0; e < 5; e++) {
        if (!t) return null;
        if (t instanceof HTMLElement) {
            if (t.dataset.sentryComponent) return t.dataset.sentryComponent;
            if (t.dataset.sentryElement) return t.dataset.sentryElement;
        }
        t = t.parentNode;
    }
    return null;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/object.js
function ru(e, t, n) {
    if (!(t in e)) return;
    let r = e[t];
    if (typeof r != "function") return;
    let i = n(r);
    typeof i == "function" && au(i, r);
    try {
        e[t] = i;
    } catch {
        B && H.log(`Failed to replace method "${t}" in object`, e);
    }
}

function iu(e, t, n) {
    try {
        Object.defineProperty(e, t, {
            value: n,
            writable: !0,
            configurable: !0
        });
    } catch {
        B && H.log(`Failed to add non-enumerable property "${t}" to object`, e);
    }
}

function au(e, t) {
    try {
        e.prototype = t.prototype = t.prototype || {}, iu(e, "__sentry_original__", t);
    } catch {}
}

function ou(e) {
    return e.__sentry_original__;
}

function su(e) {
    if (Pl(e)) return {
        message: e.message,
        name: e.name,
        stack: e.stack,
        ...lu(e)
    };
    if (Ul(e)) {
        let t = {
            type: e.type,
            target: cu(e.target),
            currentTarget: cu(e.currentTarget),
            ...lu(e)
        };
        return typeof CustomEvent < "u" && Jl(e, CustomEvent) && (t.detail = e.detail), t;
    } else return e;
}

function cu(e) {
    try {
        return Wl(e) ? $l(e) : Object.prototype.toString.call(e);
    } catch {
        return "<unknown>";
    }
}

function lu(e) {
    if (typeof e == "object" && e) {
        let t = {};
        for (let n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        return t;
    } else return {};
}

function uu(e) {
    let t = Object.keys(su(e));
    return t.sort(), t[0] ? t.join(", ") : "[object has no keys]";
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/randomSafeContext.js
var du;

function fu(e) {
    if (du !== void 0) return du ? du(e) : e();
    let t = Symbol.for("__SENTRY_SAFE_RANDOM_ID_WRAPPER__"),
        n = V;
    return t in n && typeof n[t] == "function" ? (du = n[t], du(e)) : (du = null, e());
}

function pu() {
    return fu(() => Math.random());
}

function mu() {
    return fu(() => Date.now());
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/string.js
function hu(e, t = 0) {
    return typeof e != "string" || t === 0 || e.length <= t ? e : `${e.slice(0, t)}...`;
}

function gu(e, t) {
    if (!Array.isArray(e)) return "";
    let n = [];
    for (let t = 0; t < e.length; t++) {
        let r = e[t];
        try {
            Yl(r) ? n.push(xl(r)) : n.push(String(r));
        } catch {
            n.push("[value cannot be serialized]");
        }
    }
    return n.join(t);
}

function _u(e, t, n = !1) {
    return zl(e) ? Gl(t) ? t.test(e) : zl(t) ? n ? e === t : e.includes(t) : !1 : !1;
}

function vu(e, t = [], n = !1) {
    return t.some((t) => _u(e, t, n));
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/misc.js
function yu() {
    let e = V;
    return e.crypto || e.msCrypto;
}
var bu;

function xu() {
    return pu() * 16;
}

function Su(e = yu()) {
    try {
        if (e ? .randomUUID) return fu(() => e.randomUUID()).replace(/-/g, "");
    } catch {}
    return bu || = "10000000100040008000100000000000", bu.replace(/[018]/g, (e) => (e ^ (xu() & 15) >> e / 4).toString(16));
}

function Cu(e) {
    return e.exception ? .values ? .[0];
}

function wu(e) {
    let {
        message: t,
        event_id: n
    } = e;
    if (t) return t;
    let r = Cu(e);
    return r ? r.type && r.value ? `${r.type}: ${r.value}` : r.type || r.value || n || "<unknown>" : n || "<unknown>";
}

function Tu(e, t, n) {
    let r = e.exception = e.exception || {},
        i = r.values = r.values || [],
        a = i[0] = i[0] || {};
    a.value || = t || "", a.type || = n || "Error";
}

function Eu(e, t) {
    let n = Cu(e);
    if (!n) return;
    let r = {
            type: "generic",
            handled: !0
        },
        i = n.mechanism;
    if (n.mechanism = {
            ...r,
            ...i,
            ...t
        }, t && "data" in t) {
        let e = {
            ...i ? .data,
            ...t.data
        };
        n.mechanism.data = e;
    }
}

function Du(e) {
    if (Ou(e)) return !0;
    try {
        iu(e, "__sentry_captured__", !0);
    } catch {}
    return !1;
}

function Ou(e) {
    try {
        return e.__sentry_captured__;
    } catch {}
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/time.js
var ku = 1e3;

function Au() {
    return mu() / ku;
}

function ju() {
    let {
        performance: e
    } = V;
    if (!e ? .now || !e.timeOrigin) return Au;
    let t = e.timeOrigin;
    return () => (t + fu(() => e.now())) / ku;
}
var Mu;

function Nu() {
    return (Mu ? ? = ju())();
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/session.js
function Pu(e) {
    let t = Nu(),
        n = {
            sid: Su(),
            init: !0,
            timestamp: t,
            started: t,
            duration: 0,
            status: "ok",
            errors: 0,
            ignoreDuration: !1,
            toJSON: () => Lu(n)
        };
    return e && Fu(n, e), n;
}

function Fu(e, t = {}) {
    if (t.user && (!e.ipAddress && t.user.ip_address && (e.ipAddress = t.user.ip_address), !e.did && !t.did && (e.did = t.user.id || t.user.email || t.user.username)), e.timestamp = t.timestamp || Nu(), t.abnormal_mechanism && (e.abnormal_mechanism = t.abnormal_mechanism), t.ignoreDuration && (e.ignoreDuration = t.ignoreDuration), t.sid && (e.sid = t.sid.length === 32 ? t.sid : Su()), t.init !== void 0 && (e.init = t.init), !e.did && t.did && (e.did = `${t.did}`), typeof t.started == "number" && (e.started = t.started), e.ignoreDuration) e.duration = void 0;
    else if (typeof t.duration == "number") e.duration = t.duration;
    else {
        let t = e.timestamp - e.started;
        e.duration = t >= 0 ? t : 0;
    }
    t.release && (e.release = t.release), t.environment && (e.environment = t.environment), !e.ipAddress && t.ipAddress && (e.ipAddress = t.ipAddress), !e.userAgent && t.userAgent && (e.userAgent = t.userAgent), typeof t.errors == "number" && (e.errors = t.errors), t.status && (e.status = t.status);
}

function Iu(e, t) {
    let n = {};
    t ? n = {
        status: t
    } : e.status === "ok" && (n = {
        status: "exited"
    }), Fu(e, n);
}

function Lu(e) {
    return {
        sid: `${e.sid}`,
        init: e.init,
        started: ( /* @__PURE__ */ new Date(e.started * 1e3)).toISOString(),
        timestamp: ( /* @__PURE__ */ new Date(e.timestamp * 1e3)).toISOString(),
        status: e.status,
        errors: e.errors,
        did: typeof e.did == "number" || typeof e.did == "string" ? `${e.did}` : void 0,
        duration: e.duration,
        abnormal_mechanism: e.abnormal_mechanism,
        attrs: {
            release: e.release,
            environment: e.environment,
            ip_address: e.ipAddress,
            user_agent: e.userAgent
        }
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/merge.js
function Ru(e, t, n = 2) {
    if (!t || typeof t != "object" || n <= 0) return t;
    if (e && Object.keys(t).length === 0) return e;
    let r = { ...e
    };
    for (let e in t) Object.prototype.hasOwnProperty.call(t, e) && (r[e] = Ru(r[e], t[e], n - 1));
    return r;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/propagationContext.js
function zu() {
    return Su();
}

function Bu() {
    return Su().substring(16);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/spanOnScope.js
var Vu = "_sentrySpan";

function Hu(e, t) {
    t ? iu(e, Vu, t) : delete e[Vu];
}

function Uu(e) {
    return e[Vu];
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/scope.js
var Wu = 100,
    Gu = class e {
        constructor() {
            this._notifyingListeners = !1, this._scopeListeners = [], this._eventProcessors = [], this._breadcrumbs = [], this._attachments = [], this._user = {}, this._tags = {}, this._attributes = {}, this._extra = {}, this._contexts = {}, this._sdkProcessingMetadata = {}, this._propagationContext = {
                traceId: zu(),
                sampleRand: pu()
            };
        }
        clone() {
            let t = new e();
            return t._breadcrumbs = [...this._breadcrumbs], t._tags = { ...this._tags
            }, t._attributes = { ...this._attributes
            }, t._extra = { ...this._extra
            }, t._contexts = { ...this._contexts
            }, this._contexts.flags && (t._contexts.flags = {
                values: [...this._contexts.flags.values]
            }), t._user = this._user, t._level = this._level, t._session = this._session, t._transactionName = this._transactionName, t._fingerprint = this._fingerprint, t._eventProcessors = [...this._eventProcessors], t._attachments = [...this._attachments], t._sdkProcessingMetadata = { ...this._sdkProcessingMetadata
            }, t._propagationContext = { ...this._propagationContext
            }, t._client = this._client, t._lastEventId = this._lastEventId, t._conversationId = this._conversationId, Hu(t, Uu(this)), t;
        }
        setClient(e) {
            this._client = e;
        }
        setLastEventId(e) {
            this._lastEventId = e;
        }
        getClient() {
            return this._client;
        }
        lastEventId() {
            return this._lastEventId;
        }
        addScopeListener(e) {
            this._scopeListeners.push(e);
        }
        addEventProcessor(e) {
            return this._eventProcessors.push(e), this;
        }
        setUser(e) {
            return this._user = e || {
                email: void 0,
                id: void 0,
                ip_address: void 0,
                username: void 0
            }, this._session && Fu(this._session, {
                user: e
            }), this._notifyScopeListeners(), this;
        }
        getUser() {
            return this._user;
        }
        setConversationId(e) {
            return this._conversationId = e || void 0, this._notifyScopeListeners(), this;
        }
        setTags(e) {
            return this._tags = {
                ...this._tags,
                ...e
            }, this._notifyScopeListeners(), this;
        }
        setTag(e, t) {
            return this.setTags({
                [e]: t
            });
        }
        setAttributes(e) {
            return this._attributes = {
                ...this._attributes,
                ...e
            }, this._notifyScopeListeners(), this;
        }
        setAttribute(e, t) {
            return this.setAttributes({
                [e]: t
            });
        }
        removeAttribute(e) {
            return e in this._attributes && (delete this._attributes[e], this._notifyScopeListeners()), this;
        }
        setExtras(e) {
            return this._extra = {
                ...this._extra,
                ...e
            }, this._notifyScopeListeners(), this;
        }
        setExtra(e, t) {
            return this._extra = {
                ...this._extra,
                [e]: t
            }, this._notifyScopeListeners(), this;
        }
        setFingerprint(e) {
            return this._fingerprint = e, this._notifyScopeListeners(), this;
        }
        setLevel(e) {
            return this._level = e, this._notifyScopeListeners(), this;
        }
        setTransactionName(e) {
            return this._transactionName = e, this._notifyScopeListeners(), this;
        }
        setContext(e, t) {
            return t === null ? delete this._contexts[e] : this._contexts[e] = t, this._notifyScopeListeners(), this;
        }
        setSession(e) {
            return e ? this._session = e : delete this._session, this._notifyScopeListeners(), this;
        }
        getSession() {
            return this._session;
        }
        update(t) {
            if (!t) return this;
            let n = typeof t == "function" ? t(this) : t,
                {
                    tags: r,
                    attributes: i,
                    extra: a,
                    user: o,
                    contexts: s,
                    level: c,
                    fingerprint: l = [],
                    propagationContext: u,
                    conversationId: d
                } = (n instanceof e ? n.getScopeData() : Hl(n) ? t : void 0) || {};
            return this._tags = {
                ...this._tags,
                ...r
            }, this._attributes = {
                ...this._attributes,
                ...i
            }, this._extra = {
                ...this._extra,
                ...a
            }, this._contexts = {
                ...this._contexts,
                ...s
            }, o && Object.keys(o).length && (this._user = o), c && (this._level = c), l.length && (this._fingerprint = l), u && (this._propagationContext = u), d && (this._conversationId = d), this;
        }
        clear() {
            return this._breadcrumbs = [], this._tags = {}, this._attributes = {}, this._extra = {}, this._user = {}, this._contexts = {}, this._level = void 0, this._transactionName = void 0, this._fingerprint = void 0, this._session = void 0, this._conversationId = void 0, Hu(this, void 0), this._attachments = [], this.setPropagationContext({
                traceId: zu(),
                sampleRand: pu()
            }), this._notifyScopeListeners(), this;
        }
        addBreadcrumb(e, t) {
            let n = typeof t == "number" ? t : Wu;
            if (n <= 0) return this;
            let r = {
                timestamp: Au(),
                ...e,
                message: e.message ? hu(e.message, 2048) : e.message
            };
            return this._breadcrumbs.push(r), this._breadcrumbs.length > n && (this._breadcrumbs = this._breadcrumbs.slice(-n), this._client ? .recordDroppedEvent("buffer_overflow", "log_item")), this._notifyScopeListeners(), this;
        }
        getLastBreadcrumb() {
            return this._breadcrumbs[this._breadcrumbs.length - 1];
        }
        clearBreadcrumbs() {
            return this._breadcrumbs = [], this._notifyScopeListeners(), this;
        }
        addAttachment(e) {
            return this._attachments.push(e), this;
        }
        clearAttachments() {
            return this._attachments = [], this;
        }
        getScopeData() {
            return {
                breadcrumbs: this._breadcrumbs,
                attachments: this._attachments,
                contexts: this._contexts,
                tags: this._tags,
                attributes: this._attributes,
                extra: this._extra,
                user: this._user,
                level: this._level,
                fingerprint: this._fingerprint || [],
                eventProcessors: this._eventProcessors,
                propagationContext: this._propagationContext,
                sdkProcessingMetadata: this._sdkProcessingMetadata,
                transactionName: this._transactionName,
                span: Uu(this),
                conversationId: this._conversationId
            };
        }
        setSDKProcessingMetadata(e) {
            return this._sdkProcessingMetadata = Ru(this._sdkProcessingMetadata, e, 2), this;
        }
        setPropagationContext(e) {
            return this._propagationContext = e, this;
        }
        getPropagationContext() {
            return this._propagationContext;
        }
        captureException(e, t) {
            let n = t ? .event_id || Su();
            if (!this._client) return B && H.warn("No client configured on scope - will not capture exception!"), n;
            let r = /* @__PURE__ */ Error("Sentry syntheticException");
            return this._client.captureException(e, {
                originalException: e,
                syntheticException: r,
                ...t,
                event_id: n
            }, this), n;
        }
        captureMessage(e, t, n) {
            let r = n ? .event_id || Su();
            if (!this._client) return B && H.warn("No client configured on scope - will not capture message!"), r;
            let i = n ? .syntheticException ? ? Error(e);
            return this._client.captureMessage(e, t, {
                originalException: e,
                syntheticException: i,
                ...n,
                event_id: r
            }, this), r;
        }
        captureEvent(e, t) {
            let n = t ? .event_id || Su();
            return this._client ? (this._client.captureEvent(e, {
                ...t,
                event_id: n
            }, this), n) : (B && H.warn("No client configured on scope - will not capture event!"), n);
        }
        _notifyScopeListeners() {
            this._notifyingListeners || = (this._notifyingListeners = !0, this._scopeListeners.forEach((e) => {
                e(this);
            }), !1);
        }
    };
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/defaultScopes.js
function Ku() {
    return Qc("defaultCurrentScope", () => new Gu());
}

function qu() {
    return Qc("defaultIsolationScope", () => new Gu());
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/asyncContext/stackStrategy.js
var Ju = class {
    constructor(e, t) {
        let n;
        n = e || new Gu();
        let r;
        r = t || new Gu(), this._stack = [{
            scope: n
        }], this._isolationScope = r;
    }
    withScope(e) {
        let t = this._pushScope(),
            n;
        try {
            n = e(t);
        } catch (e) {
            throw this._popScope(), e;
        }
        return Kl(n) ? n.then((e) => (this._popScope(), e), (e) => {
            throw this._popScope(), e;
        }) : (this._popScope(), n);
    }
    getClient() {
        return this.getStackTop().client;
    }
    getScope() {
        return this.getStackTop().scope;
    }
    getIsolationScope() {
        return this._isolationScope;
    }
    getStackTop() {
        return this._stack[this._stack.length - 1];
    }
    _pushScope() {
        let e = this.getScope().clone();
        return this._stack.push({
            client: this.getClient(),
            scope: e
        }), e;
    }
    _popScope() {
        return this._stack.length <= 1 ? !1 : !!this._stack.pop();
    }
};

function Yu() {
    let e = Zc(Xc());
    return e.stack = e.stack || new Ju(Ku(), qu());
}

function Xu(e) {
    return Yu().withScope(e);
}

function Zu(e, t) {
    let n = Yu();
    return n.withScope(() => (n.getStackTop().scope = e, t(e)));
}

function Qu(e) {
    return Yu().withScope(() => e(Yu().getIsolationScope()));
}

function $u() {
    return {
        withIsolationScope: Qu,
        withScope: Xu,
        withSetScope: Zu,
        withSetIsolationScope: (e, t) => Qu(t),
        getCurrentScope: () => Yu().getScope(),
        getIsolationScope: () => Yu().getIsolationScope()
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/asyncContext/index.js
function ed(e) {
    let t = Zc(e);
    return t.acs ? t.acs : $u();
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/currentScopes.js
function td() {
    return ed(Xc()).getCurrentScope();
}

function nd() {
    return ed(Xc()).getIsolationScope();
}

function rd() {
    return Qc("globalScope", () => new Gu());
}

function id(...e) {
    let t = ed(Xc());
    if (e.length === 2) {
        let [n, r] = e;
        return n ? t.withSetScope(n, r) : t.withScope(r);
    }
    return t.withScope(e[0]);
}

function ad() {
    return td().getClient();
}

function od(e) {
    let {
        traceId: t,
        parentSpanId: n,
        propagationSpanId: r
    } = e.getPropagationContext(), i = {
        trace_id: t,
        span_id: r || Bu()
    };
    return n && (i.parent_span_id = n), i;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/semanticAttributes.js
var sd = "sentry.source",
    cd = "sentry.op",
    ld = "sentry.origin",
    ud = "sentry.profile_id",
    dd = "sentry.exclusive_time",
    fd = "gen_ai.conversation.id",
    pd = "_sentryScope",
    md = "_sentryIsolationScope";

function hd(e) {
    if (e) {
        if (typeof e == "object" && "deref" in e && typeof e.deref == "function") try {
            return e.deref();
        } catch {
            return;
        }
        return e;
    }
}

function gd(e) {
    let t = e;
    return {
        scope: t[pd],
        isolationScope: hd(t[md])
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/baggage.js
var _d = /^sentry-/;

function vd(e) {
    let t = yd(e);
    if (!t) return;
    let n = Object.entries(t).reduce((e, [t, n]) => {
        if (t.match(_d)) {
            let r = t.slice(7);
            e[r] = n;
        }
        return e;
    }, {});
    if (Object.keys(n).length > 0) return n;
}

function yd(e) {
    if (!(!e || !zl(e) && !Array.isArray(e))) return Array.isArray(e) ? e.reduce((e, t) => {
        let n = bd(t);
        return Object.entries(n).forEach(([t, n]) => {
            e[t] = n;
        }), e;
    }, {}) : bd(e);
}

function bd(e) {
    return e.split(",").map((e) => {
        let t = e.indexOf("=");
        return t === -1 ? [] : [e.slice(0, t), e.slice(t + 1)].map((e) => {
            try {
                return decodeURIComponent(e.trim());
            } catch {
                return;
            }
        });
    }).reduce((e, [t, n]) => (t && n && (e[t] = n), e), {});
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/dsn.js
var xd = /^o(\d+)\./,
    Sd = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)((?:\[[:.%\w]+\]|[\w.-]+))(?::(\d+))?\/(.+)/;

function Cd(e) {
    return e === "http" || e === "https";
}

function wd(e, t = !1) {
    let {
        host: n,
        path: r,
        pass: i,
        port: a,
        projectId: o,
        protocol: s,
        publicKey: c
    } = e;
    return `${s}://${c}${t && i ? `:${i}` : ""}@${n}${a ? `:${a}` : ""}/${r && `${r}/`}${o}`;
}

function Td(e) {
    let t = Sd.exec(e);
    if (!t) {
        nl(() => {
            console.error(`Invalid Sentry Dsn: ${e}`);
        });
        return;
    }
    let [n, r, i = "", a = "", o = "", s = ""] = t.slice(1), c = "", l = s, u = l.split("/");
    if (u.length > 1 && (c = u.slice(0, -1).join("/"), l = u.pop()), l) {
        let e = l.match(/^\d+/);
        e && (l = e[0]);
    }
    return Ed({
        host: a,
        pass: i,
        path: c,
        projectId: l,
        port: o,
        protocol: n,
        publicKey: r
    });
}

function Ed(e) {
    return {
        protocol: e.protocol,
        publicKey: e.publicKey || "",
        pass: e.pass || "",
        host: e.host,
        port: e.port || "",
        path: e.path || "",
        projectId: e.projectId
    };
}

function Dd(e) {
    if (!B) return !0;
    let {
        port: t,
        projectId: n,
        protocol: r
    } = e;
    return [
        "protocol",
        "publicKey",
        "host",
        "projectId"
    ].find((t) => e[t] ? !1 : (H.error(`Invalid Sentry Dsn: ${t} missing`), !0)) ? !1 : n.match(/^\d+$/) ? Cd(r) ? t && isNaN(parseInt(t, 10)) ? (H.error(`Invalid Sentry Dsn: Invalid port ${t}`), !1) : !0 : (H.error(`Invalid Sentry Dsn: Invalid protocol ${r}`), !1) : (H.error(`Invalid Sentry Dsn: Invalid projectId ${n}`), !1);
}

function Od(e) {
    return e.match(xd) ? .[1];
}

function kd(e) {
    let t = e.getOptions(),
        {
            host: n
        } = e.getDsn() || {},
        r;
    return t.orgId ? r = String(t.orgId) : n && (r = Od(n)), r;
}

function Ad(e) {
    let t = typeof e == "string" ? Td(e) : Ed(e);
    if (!(!t || !Dd(t))) return t;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/parseSampleRate.js
function jd(e) {
    if (typeof e == "boolean") return Number(e);
    let t = typeof e == "string" ? parseFloat(e) : e;
    if (!(typeof t != "number" || isNaN(t) || t < 0 || t > 1)) return t;
}
var Md = !1;

function Nd(e) {
    let {
        spanId: t,
        traceId: n,
        isRemote: r
    } = e.spanContext(), i = r ? t : Ld(e).parent_span_id, a = gd(e).scope;
    return {
        parent_span_id: i,
        span_id: r ? a ? .getPropagationContext().propagationSpanId || Bu() : t,
        trace_id: n
    };
}

function Pd(e) {
    if (e && e.length > 0) return e.map(({
        context: {
            spanId: e,
            traceId: t,
            traceFlags: n,
            ...r
        },
        attributes: i
    }) => ({
        span_id: e,
        trace_id: t,
        sampled: n === 1,
        attributes: i,
        ...r
    }));
}

function Fd(e) {
    return typeof e == "number" ? Id(e) : Array.isArray(e) ? e[0] + e[1] / 1e9 : e instanceof Date ? Id(e.getTime()) : Nu();
}

function Id(e) {
    return e > 9999999999 ? e / 1e3 : e;
}

function Ld(e) {
    if (zd(e)) return e.getSpanJSON();
    let {
        spanId: t,
        traceId: n
    } = e.spanContext();
    if (Rd(e)) {
        let {
            attributes: r,
            startTime: i,
            name: a,
            endTime: o,
            status: s,
            links: c
        } = e;
        return {
            span_id: t,
            trace_id: n,
            data: r,
            description: a,
            parent_span_id: "parentSpanId" in e ? e.parentSpanId : "parentSpanContext" in e ? e.parentSpanContext ? .spanId : void 0,
            start_timestamp: Fd(i),
            timestamp: Fd(o) || void 0,
            status: Vd(s),
            op: r[cd],
            origin: r[ld],
            links: Pd(c)
        };
    }
    return {
        span_id: t,
        trace_id: n,
        start_timestamp: 0,
        data: {}
    };
}

function Rd(e) {
    let t = e;
    return !!t.attributes && !!t.startTime && !!t.name && !!t.endTime && !!t.status;
}

function zd(e) {
    return typeof e.getSpanJSON == "function";
}

function Bd(e) {
    let {
        traceFlags: t
    } = e.spanContext();
    return t === 1;
}

function Vd(e) {
    if (!(!e || e.code === 0)) return e.code === 1 ? "ok" : e.message || "internal_error";
}
var Hd = "_sentryRootSpan";

function Ud(e) {
    return e[Hd] || e;
}

function Wd() {
    Md || = (nl(() => {
        console.warn("[Sentry] Returning null from `beforeSendSpan` is disallowed. To drop certain spans, configure the respective integrations directly or use `ignoreSpans`.");
    }), !0);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/hasSpansEnabled.js
function Gd(e) {
    if (typeof __SENTRY_TRACING__ == "boolean" && !__SENTRY_TRACING__) return !1;
    let t = e || ad() ? .getOptions();
    return !!t && (t.tracesSampleRate != null || !!t.tracesSampler);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/should-ignore-span.js
function Kd(e) {
    H.log(`Ignoring span ${e.op} - ${e.description} because it matches \`ignoreSpans\`.`);
}

function qd(e, t) {
    if (!t ? .length || !e.description) return !1;
    for (let n of t) {
        if (Yd(n)) {
            if (_u(e.description, n)) return B && Kd(e), !0;
            continue;
        }
        if (!n.name && !n.op) continue;
        let t = n.name ? _u(e.description, n.name) : !0,
            r = n.op ? e.op && _u(e.op, n.op) : !0;
        if (t && r) return B && Kd(e), !0;
    }
    return !1;
}

function Jd(e, t) {
    let n = t.parent_span_id,
        r = t.span_id;
    if (n)
        for (let t of e) t.parent_span_id === r && (t.parent_span_id = n);
}

function Yd(e) {
    return typeof e == "string" || e instanceof RegExp;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/constants.js
var Xd = "production",
    Zd = "_frozenDsc";

function Qd(e, t) {
    let n = t.getOptions(),
        {
            publicKey: r
        } = t.getDsn() || {},
        i = {
            environment: n.environment || "production",
            release: n.release,
            public_key: r,
            trace_id: e,
            org_id: kd(t)
        };
    return t.emit("createDsc", i), i;
}

function $d(e, t) {
    let n = t.getPropagationContext();
    return n.dsc || Qd(n.traceId, e);
}

function ef(e) {
    let t = ad();
    if (!t) return {};
    let n = Ud(e),
        r = Ld(n),
        i = r.data,
        a = n.spanContext().traceState,
        o = a ? .get("sentry.sample_rate") ? ? i["sentry.sample_rate"] ? ? i["sentry.previous_trace_sample_rate"];

    function s(e) {
        return (typeof o == "number" || typeof o == "string") && (e.sample_rate = `${o}`), e;
    }
    let c = n[Zd];
    if (c) return s(c);
    let l = a ? .get("sentry.dsc"),
        u = l && vd(l);
    if (u) return s(u);
    let d = Qd(e.spanContext().traceId, t),
        f = i[sd],
        p = r.description;
    return f !== "url" && p && (d.transaction = p), Gd() && (d.sampled = String(Bd(n)), d.sample_rand = a ? .get("sentry.sample_rand") ? ? gd(n).scope ? .getPropagationContext().sampleRand.toString()), s(d), t.emit("createDsc", d, n), d;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/normalize.js
function tf(e, t = 100, n = Infinity) {
    try {
        return rf("", e, t, n);
    } catch (e) {
        return {
            ERROR: `**non-serializable** (${e})`
        };
    }
}

function nf(e, t = 3, n = 100 * 1024) {
    let r = tf(e, t);
    return cf(r) > n ? nf(e, t - 1, n) : r;
}

function rf(e, t, n = Infinity, r = Infinity, i = lf()) {
    let [a, o] = i;
    if (t == null || ["boolean", "string"].includes(typeof t) || typeof t == "number" && Number.isFinite(t)) return t;
    let s = af(e, t);
    if (!s.startsWith("[object ")) return s;
    if (t.__sentry_skip_normalization__) return t;
    let c = typeof t.__sentry_override_normalization_depth__ == "number" ? t.__sentry_override_normalization_depth__ : n;
    if (c === 0) return s.replace("object ", "");
    if (a(t)) return "[Circular ~]";
    let l = t;
    if (l && typeof l.toJSON == "function") try {
        return rf("", l.toJSON(), c - 1, r, i);
    } catch {}
    let u = Array.isArray(t) ? [] : {},
        d = 0,
        f = su(t);
    for (let e in f) {
        if (!Object.prototype.hasOwnProperty.call(f, e)) continue;
        if (d >= r) {
            u[e] = "[MaxProperties ~]";
            break;
        }
        let t = f[e];
        u[e] = rf(e, t, c - 1, r, i), d++;
    }
    return o(t), u;
}

function af(e, t) {
    try {
        if (e === "domain" && t && typeof t == "object" && t._events) return "[Domain]";
        if (e === "domainEmitter") return "[DomainEmitter]";
        if (typeof global < "u" && t === global) return "[Global]";
        if (typeof window < "u" && t === window) return "[Window]";
        if (typeof document < "u" && t === document) return "[Document]";
        if (Yl(t)) return xl(t);
        if (ql(t)) return "[SyntheticEvent]";
        if (typeof t == "number" && !Number.isFinite(t)) return `[${t}]`;
        if (typeof t == "function") return `[Function: ${yl(t)}]`;
        if (typeof t == "symbol") return `[${String(t)}]`;
        if (typeof t == "bigint") return `[BigInt: ${String(t)}]`;
        let n = of (t);
        return /^HTML(\w*)Element$/.test(n) ? `[HTMLElement: ${n}]` : `[object ${n}]`;
    } catch (e) {
        return `**non-serializable** (${e})`;
    }
}

function of (e) {
    let t = Object.getPrototypeOf(e);
    return t ? .constructor ? t.constructor.name : "null prototype";
}

function sf(e) {
    return ~-encodeURI(e).split(/%..|./).length;
}

function cf(e) {
    return sf(JSON.stringify(e));
}

function lf() {
    let e = /* @__PURE__ */ new WeakSet();

    function t(t) {
        return e.has(t) ? !0 : (e.add(t), !1);
    }

    function n(t) {
        e.delete(t);
    }
    return [t, n];
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/envelope.js
function uf(e, t = []) {
    return [e, t];
}

function df(e, t) {
    let [n, r] = e;
    return [n, [...r, t]];
}

function ff(e, t) {
    let n = e[1];
    for (let e of n) {
        let n = e[0].type;
        if (t(e, n)) return !0;
    }
    return !1;
}

function pf(e, t) {
    return ff(e, (e, n) => t.includes(n));
}

function mf(e) {
    let t = Zc(V);
    return t.encodePolyfill ? t.encodePolyfill(e) : new TextEncoder().encode(e);
}

function hf(e) {
    let [t, n] = e, r = JSON.stringify(t);

    function i(e) {
        typeof r == "string" ? r = typeof e == "string" ? r + e : [mf(r), e] : r.push(typeof e == "string" ? mf(e) : e);
    }
    for (let e of n) {
        let [t, n] = e;
        if (i(`\n${JSON.stringify(t)}\n`), typeof n == "string" || n instanceof Uint8Array) i(n);
        else {
            let e;
            try {
                e = JSON.stringify(n);
            } catch {
                e = JSON.stringify(tf(n));
            }
            i(e);
        }
    }
    return typeof r == "string" ? r : gf(r);
}

function gf(e) {
    let t = e.reduce((e, t) => e + t.length, 0),
        n = new Uint8Array(t),
        r = 0;
    for (let t of e) n.set(t, r), r += t.length;
    return n;
}

function _f(e) {
    let t = typeof e.data == "string" ? mf(e.data) : e.data;
    return [{
        type: "attachment",
        length: t.length,
        filename: e.filename,
        content_type: e.contentType,
        attachment_type: e.attachmentType
    }, t];
}
var vf = {
    session: "session",
    sessions: "session",
    attachment: "attachment",
    transaction: "transaction",
    event: "error",
    client_report: "internal",
    user_report: "default",
    profile: "profile",
    profile_chunk: "profile",
    replay_event: "replay",
    replay_recording: "replay",
    check_in: "monitor",
    feedback: "feedback",
    span: "span",
    raw_security: "security",
    log: "log_item",
    metric: "metric",
    trace_metric: "metric"
};

function yf(e) {
    return vf[e];
}

function bf(e) {
    if (!e ? .sdk) return;
    let {
        name: t,
        version: n
    } = e.sdk;
    return {
        name: t,
        version: n
    };
}

function xf(e, t, n, r) {
    let i = e.sdkProcessingMetadata ? .dynamicSamplingContext;
    return {
        event_id: e.event_id,
        sent_at: ( /* @__PURE__ */ new Date()).toISOString(),
        ...t && {
            sdk: t
        },
        ...!!n && r && {
            dsn: wd(r)
        },
        ...i && {
            trace: i
        }
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/envelope.js
function Sf(e, t) {
    if (!t) return e;
    let n = e.sdk || {};
    return e.sdk = {
        ...n,
        name: n.name || t.name,
        version: n.version || t.version,
        integrations: [...e.sdk ? .integrations || [], ...t.integrations || []],
        packages: [...e.sdk ? .packages || [], ...t.packages || []],
        settings: e.sdk ? .settings || t.settings ? {
            ...e.sdk ? .settings,
            ...t.settings
        } : void 0
    }, e;
}

function Cf(e, t, n, r) {
    let i = bf(n);
    return uf({
        sent_at: ( /* @__PURE__ */ new Date()).toISOString(),
        ...i && {
            sdk: i
        },
        ...!!r && t && {
            dsn: wd(t)
        }
    }, ["aggregates" in e ? [{
        type: "sessions"
    }, e] : [{
        type: "session"
    }, e.toJSON()]]);
}

function wf(e, t, n, r) {
    let i = bf(n),
        a = e.type && e.type !== "replay_event" ? e.type : "event";
    Sf(e, n ? .sdk);
    let o = xf(e, i, r, t);
    return delete e.sdkProcessingMetadata, uf(o, [
        [{
            type: a
        }, e]
    ]);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/syncpromise.js
var Tf = 0,
    Ef = 1,
    Df = 2;

function Of(e) {
    return new Af((t) => {
        t(e);
    });
}

function kf(e) {
    return new Af((t, n) => {
        n(e);
    });
}
var Af = class e {
    constructor(e) {
        this._state = Tf, this._handlers = [], this._runExecutor(e);
    }
    then(t, n) {
        return new e((e, r) => {
            this._handlers.push([!1,
                (n) => {
                    if (!t) e(n);
                    else try {
                        e(t(n));
                    } catch (e) {
                        r(e);
                    }
                },
                (t) => {
                    if (!n) r(t);
                    else try {
                        e(n(t));
                    } catch (e) {
                        r(e);
                    }
                }
            ]), this._executeHandlers();
        });
    }
    catch (e) {
        return this.then((e) => e, e);
    } finally(t) {
        return new e((e, n) => {
            let r, i;
            return this.then((e) => {
                i = !1, r = e, t && t();
            }, (e) => {
                i = !0, r = e, t && t();
            }).then(() => {
                if (i) {
                    n(r);
                    return;
                }
                e(r);
            });
        });
    }
    _executeHandlers() {
        if (this._state === Tf) return;
        let e = this._handlers.slice();
        this._handlers = [], e.forEach((e) => {
            e[0] || = (this._state === Ef && e[1](this._value), this._state === Df && e[2](this._value), !0);
        });
    }
    _runExecutor(e) {
        let t = (e, t) => {
                if (this._state === Tf) {
                    if (Kl(t)) {
                        t.then(n, r);
                        return;
                    }
                    this._state = e, this._value = t, this._executeHandlers();
                }
            },
            n = (e) => {
                t(Ef, e);
            },
            r = (e) => {
                t(Df, e);
            };
        try {
            e(n, r);
        } catch (e) {
            r(e);
        }
    }
};
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/eventProcessors.js
function jf(e, t, n, r = 0) {
    try {
        let i = Mf(t, n, e, r);
        return Kl(i) ? i : Of(i);
    } catch (e) {
        return kf(e);
    }
}

function Mf(e, t, n, r) {
    let i = n[r];
    if (!e || !i) return e;
    let a = i({ ...e
    }, t);
    return B && a === null && H.log(`Event processor "${i.id || "?"}" dropped event`), Kl(a) ? a.then((e) => Mf(e, t, n, r + 1)) : Mf(a, t, n, r + 1);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/debug-ids.js
var Nf, Pf, Ff, If;

function Lf(e) {
    let t = V._sentryDebugIds,
        n = V._debugIds;
    if (!t && !n) return {};
    let r = t ? Object.keys(t) : [],
        i = n ? Object.keys(n) : [];
    if (If && r.length === Pf && i.length === Ff) return If;
    Pf = r.length, Ff = i.length, If = {}, Nf || = {};
    let a = (t, n) => {
        for (let r of t) {
            let t = n[r],
                i = Nf ? .[r];
            if (i && If && t) If[i[0]] = t, Nf && (Nf[r] = [i[0], t]);
            else if (t) {
                let n = e(r);
                for (let e = n.length - 1; e >= 0; e--) {
                    let i = n[e] ? .filename;
                    if (i && If && Nf) {
                        If[i] = t, Nf[r] = [i, t];
                        break;
                    }
                }
            }
        }
    };
    return t && a(r, t), n && a(i, n), If;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/scopeData.js
function Rf(e, t) {
    let {
        fingerprint: n,
        span: r,
        breadcrumbs: i,
        sdkProcessingMetadata: a
    } = t;
    Hf(e, t), r && Gf(e, r), Kf(e, n), Uf(e, i), Wf(e, a);
}

function zf(e, t) {
    let {
        extra: n,
        tags: r,
        attributes: i,
        user: a,
        contexts: o,
        level: s,
        sdkProcessingMetadata: c,
        breadcrumbs: l,
        fingerprint: u,
        eventProcessors: d,
        attachments: f,
        propagationContext: p,
        transactionName: m,
        span: h
    } = t;
    Bf(e, "extra", n), Bf(e, "tags", r), Bf(e, "attributes", i), Bf(e, "user", a), Bf(e, "contexts", o), e.sdkProcessingMetadata = Ru(e.sdkProcessingMetadata, c, 2), s && (e.level = s), m && (e.transactionName = m), h && (e.span = h), l.length && (e.breadcrumbs = [...e.breadcrumbs, ...l]), u.length && (e.fingerprint = [...e.fingerprint, ...u]), d.length && (e.eventProcessors = [...e.eventProcessors, ...d]), f.length && (e.attachments = [...e.attachments, ...f]), e.propagationContext = {
        ...e.propagationContext,
        ...p
    };
}

function Bf(e, t, n) {
    e[t] = Ru(e[t], n, 1);
}

function Vf(e, t) {
    let n = rd().getScopeData();
    return e && zf(n, e.getScopeData()), t && zf(n, t.getScopeData()), n;
}

function Hf(e, t) {
    let {
        extra: n,
        tags: r,
        user: i,
        contexts: a,
        level: o,
        transactionName: s
    } = t;
    Object.keys(n).length && (e.extra = {
        ...n,
        ...e.extra
    }), Object.keys(r).length && (e.tags = {
        ...r,
        ...e.tags
    }), Object.keys(i).length && (e.user = {
        ...i,
        ...e.user
    }), Object.keys(a).length && (e.contexts = {
        ...a,
        ...e.contexts
    }), o && (e.level = o), s && e.type !== "transaction" && (e.transaction = s);
}

function Uf(e, t) {
    let n = [...e.breadcrumbs || [], ...t];
    e.breadcrumbs = n.length ? n : void 0;
}

function Wf(e, t) {
    e.sdkProcessingMetadata = {
        ...e.sdkProcessingMetadata,
        ...t
    };
}

function Gf(e, t) {
    e.contexts = {
        trace: Nd(t),
        ...e.contexts
    }, e.sdkProcessingMetadata = {
        dynamicSamplingContext: ef(t),
        ...e.sdkProcessingMetadata
    };
    let n = Ld(Ud(t)).description;
    n && !e.transaction && e.type === "transaction" && (e.transaction = n);
}

function Kf(e, t) {
    e.fingerprint = e.fingerprint ? Array.isArray(e.fingerprint) ? e.fingerprint : [e.fingerprint] : [], t && (e.fingerprint = e.fingerprint.concat(t)), e.fingerprint.length || delete e.fingerprint;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/prepareEvent.js
function qf(e, t, n, r, i, a) {
    let {
        normalizeDepth: o = 3,
        normalizeMaxBreadth: s = 1e3
    } = e, c = {
        ...t,
        event_id: t.event_id || n.event_id || Su(),
        timestamp: t.timestamp || Au()
    }, l = n.integrations || e.integrations.map((e) => e.name);
    Jf(c, e), Zf(c, l), i && i.emit("applyFrameMetadata", t), t.type === void 0 && Yf(c, e.stackParser);
    let u = $f(r, n.captureContext);
    n.mechanism && Eu(c, n.mechanism);
    let d = i ? i.getEventProcessors() : [],
        f = Vf(a, u),
        p = [...n.attachments || [], ...f.attachments];
    return p.length && (n.attachments = p), Rf(c, f), jf([...d, ...f.eventProcessors], c, n).then((e) => (e && Xf(e), typeof o == "number" && o > 0 ? Qf(e, o, s) : e));
}

function Jf(e, t) {
    let {
        environment: n,
        release: r,
        dist: i,
        maxValueLength: a
    } = t;
    e.environment = e.environment || n || "production", !e.release && r && (e.release = r), !e.dist && i && (e.dist = i);
    let o = e.request;
    o ? .url && a && (o.url = hu(o.url, a)), a && e.exception ? .values ? .forEach((e) => {
        e.value && = hu(e.value, a);
    });
}

function Yf(e, t) {
    let n = Lf(t);
    e.exception ? .values ? .forEach((e) => {
        e.stacktrace ? .frames ? .forEach((e) => {
            e.filename && (e.debug_id = n[e.filename]);
        });
    });
}

function Xf(e) {
    let t = {};
    if (e.exception ? .values ? .forEach((e) => {
            e.stacktrace ? .frames ? .forEach((e) => {
                e.debug_id && (e.abs_path ? t[e.abs_path] = e.debug_id : e.filename && (t[e.filename] = e.debug_id), delete e.debug_id);
            });
        }), Object.keys(t).length === 0) return;
    e.debug_meta = e.debug_meta || {}, e.debug_meta.images = e.debug_meta.images || [];
    let n = e.debug_meta.images;
    Object.entries(t).forEach(([e, t]) => {
        n.push({
            type: "sourcemap",
            code_file: e,
            debug_id: t
        });
    });
}

function Zf(e, t) {
    t.length > 0 && (e.sdk = e.sdk || {}, e.sdk.integrations = [...e.sdk.integrations || [], ...t]);
}

function Qf(e, t, n) {
    if (!e) return null;
    let r = {
        ...e,
        ...e.breadcrumbs && {
            breadcrumbs: e.breadcrumbs.map((e) => ({
                ...e,
                ...e.data && {
                    data: tf(e.data, t, n)
                }
            }))
        },
        ...e.user && {
            user: tf(e.user, t, n)
        },
        ...e.contexts && {
            contexts: tf(e.contexts, t, n)
        },
        ...e.extra && {
            extra: tf(e.extra, t, n)
        }
    };
    return e.contexts ? .trace && r.contexts && (r.contexts.trace = e.contexts.trace, e.contexts.trace.data && (r.contexts.trace.data = tf(e.contexts.trace.data, t, n))), e.spans && (r.spans = e.spans.map((e) => ({
        ...e,
        ...e.data && {
            data: tf(e.data, t, n)
        }
    }))), e.contexts ? .flags && r.contexts && (r.contexts.flags = tf(e.contexts.flags, 3, n)), r;
}

function $f(e, t) {
    if (!t) return e;
    let n = e ? e.clone() : new Gu();
    return n.update(t), n;
}

function ep(e) {
    if (e) return tp(e) || rp(e) ? {
        captureContext: e
    } : e;
}

function tp(e) {
    return e instanceof Gu || typeof e == "function";
}
var np = [
    "user",
    "level",
    "extra",
    "contexts",
    "tags",
    "fingerprint",
    "propagationContext"
];

function rp(e) {
    return Object.keys(e).some((e) => np.includes(e));
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/exports.js
function ip(e, t) {
    return td().captureException(e, ep(t));
}

function ap(e, t) {
    let n = typeof t == "string" ? t : void 0,
        r = typeof t == "string" ? void 0 : {
            captureContext: t
        };
    return td().captureMessage(e, n, r);
}

function op(e, t) {
    return td().captureEvent(e, t);
}

function sp(e, t) {
    nd().setTag(e, t);
}

function cp(e) {
    let t = nd(),
        n = td(),
        {
            userAgent: r
        } = V.navigator || {},
        i = Pu({
            user: n.getUser() || t.getUser(),
            ...r && {
                userAgent: r
            },
            ...e
        }),
        a = t.getSession();
    return a ? .status === "ok" && Fu(a, {
        status: "exited"
    }), lp(), t.setSession(i), i;
}

function lp() {
    let e = nd(),
        t = td().getSession() || e.getSession();
    t && Iu(t), up(), e.setSession();
}

function up() {
    let e = nd(),
        t = ad(),
        n = e.getSession();
    n && t && t.captureSession(n);
}

function dp(e = !1) {
    if (e) {
        lp();
        return;
    }
    up();
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/api.js
var fp = "7";

function pp(e) {
    let t = e.protocol ? `${e.protocol}:` : "",
        n = e.port ? `:${e.port}` : "";
    return `${t}//${e.host}${n}${e.path ? `/${e.path}` : ""}/api/`;
}

function mp(e) {
    return `${pp(e)}${e.projectId}/envelope/`;
}

function hp(e, t) {
    let n = {
        sentry_version: fp
    };
    return e.publicKey && (n.sentry_key = e.publicKey), t && (n.sentry_client = `${t.name}/${t.version}`), new URLSearchParams(n).toString();
}

function gp(e, t, n) {
    return t || `${mp(e)}?${hp(e, n)}`;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/integration.js
var _p = [];

function vp(e) {
    let t = {};
    return e.forEach((e) => {
        let {
            name: n
        } = e, r = t[n];
        r && !r.isDefaultInstance && e.isDefaultInstance || (t[n] = e);
    }), Object.values(t);
}

function yp(e) {
    let t = e.defaultIntegrations || [],
        n = e.integrations;
    t.forEach((e) => {
        e.isDefaultInstance = !0;
    });
    let r;
    if (Array.isArray(n)) r = [...t, ...n];
    else if (typeof n == "function") {
        let e = n(t);
        r = Array.isArray(e) ? e : [e];
    } else r = t;
    return vp(r);
}

function bp(e, t) {
    let n = {};
    return t.forEach((t) => {
        t && Sp(e, t, n);
    }), n;
}

function xp(e, t) {
    for (let n of t) n ? .afterAllSetup && n.afterAllSetup(e);
}

function Sp(e, t, n) {
    if (n[t.name]) {
        B && H.log(`Integration skipped because it was already installed: ${t.name}`);
        return;
    }
    if (n[t.name] = t, !_p.includes(t.name) && typeof t.setupOnce == "function" && (t.setupOnce(), _p.push(t.name)), t.setup && typeof t.setup == "function" && t.setup(e), typeof t.preprocessEvent == "function") {
        let n = t.preprocessEvent.bind(t);
        e.on("preprocessEvent", (t, r) => n(t, r, e));
    }
    if (typeof t.processEvent == "function") {
        let n = t.processEvent.bind(t),
            r = Object.assign((t, r) => n(t, r, e), {
                id: t.name
            });
        e.addEventProcessor(r);
    }
    B && H.log(`Integration installed: ${t.name}`);
}

function Cp(e) {
    return e;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/logs/envelope.js
function wp(e) {
    return [{
        type: "log",
        item_count: e.length,
        content_type: "application/vnd.sentry.items.log+json"
    }, {
        items: e
    }];
}

function Tp(e, t, n, r) {
    let i = {};
    return t ? .sdk && (i.sdk = {
        name: t.sdk.name,
        version: t.sdk.version
    }), n && r && (i.dsn = wd(r)), uf(i, [wp(e)]);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/logs/internal.js
function Ep(e, t) {
    let n = t ? ? Dp(e) ? ? [];
    if (n.length === 0) return;
    let r = e.getOptions(),
        i = Tp(n, r._metadata, r.tunnel, e.getDsn());
    Op().set(e, []), e.emit("flushLogs"), e.sendEnvelope(i);
}

function Dp(e) {
    return Op().get(e);
}

function Op() {
    return Qc("clientToLogBufferMap", () => /* @__PURE__ */ new WeakMap());
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/metrics/envelope.js
function kp(e) {
    return [{
        type: "trace_metric",
        item_count: e.length,
        content_type: "application/vnd.sentry.items.trace-metric+json"
    }, {
        items: e
    }];
}

function Ap(e, t, n, r) {
    let i = {};
    return t ? .sdk && (i.sdk = {
        name: t.sdk.name,
        version: t.sdk.version
    }), n && r && (i.dsn = wd(r)), uf(i, [kp(e)]);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/metrics/internal.js
function jp(e, t) {
    let n = t ? ? Mp(e) ? ? [];
    if (n.length === 0) return;
    let r = e.getOptions(),
        i = Ap(n, r._metadata, r.tunnel, e.getDsn());
    Np().set(e, []), e.emit("flushMetrics"), e.sendEnvelope(i);
}

function Mp(e) {
    return Np().get(e);
}

function Np() {
    return Qc("clientToMetricBufferMap", () => /* @__PURE__ */ new WeakMap());
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/promisebuffer.js
var Pp = Symbol.for("SentryBufferFullError");

function Fp(e = 100) {
    let t = /* @__PURE__ */ new Set();

    function n() {
        return t.size < e;
    }

    function r(e) {
        t.delete(e);
    }

    function i(e) {
        if (!n()) return kf(Pp);
        let i = e();
        return t.add(i), i.then(() => r(i), () => r(i)), i;
    }

    function a(e) {
        if (!t.size) return Of(!0);
        let n = Promise.allSettled(Array.from(t)).then(() => !0);
        if (!e) return n;
        let r = [n, new Promise((t) => setTimeout(() => t(!1), e))];
        return Promise.race(r);
    }
    return {
        get $() {
            return Array.from(t);
        },
        add: i,
        drain: a
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/ratelimit.js
var Ip = 60 * 1e3;

function Lp(e, t = mu()) {
    let n = parseInt(`${e}`, 10);
    if (!isNaN(n)) return n * 1e3;
    let r = Date.parse(`${e}`);
    return isNaN(r) ? Ip : r - t;
}

function Rp(e, t) {
    return e[t] || e.all || 0;
}

function zp(e, t, n = mu()) {
    return Rp(e, t) > n;
}

function Bp(e, {
    statusCode: t,
    headers: n
}, r = mu()) {
    let i = { ...e
        },
        a = n ? .["x-sentry-rate-limits"],
        o = n ? .["retry-after"];
    if (a)
        for (let e of a.trim().split(",")) {
            let [t, n, , , a] = e.split(":", 5), o = parseInt(t, 10), s = (isNaN(o) ? 60 : o) * 1e3;
            if (!n) i.all = r + s;
            else
                for (let e of n.split(";")) e === "metric_bucket" ? (!a || a.split(";").includes("custom")) && (i[e] = r + s) : i[e] = r + s;
        }
    else o ? i.all = r + Lp(o, r) : t === 429 && (i.all = r + 60 * 1e3);
    return i;
}

function Vp(e, t, n = Fp(e.bufferSize || 64)) {
    let r = {},
        i = (e) => n.drain(e);

    function a(i) {
        let a = [];
        if (ff(i, (t, n) => {
                let i = yf(n);
                zp(r, i) ? e.recordDroppedEvent("ratelimit_backoff", i) : a.push(t);
            }), a.length === 0) return Promise.resolve({});
        let o = uf(i[0], a),
            s = (t) => {
                if (pf(o, ["client_report"])) {
                    B && H.warn(`Dropping client report. Will not send outcomes (reason: ${t}).`);
                    return;
                }
                ff(o, (n, r) => {
                    e.recordDroppedEvent(t, yf(r));
                });
            };
        return n.add(() => t({
            body: hf(o)
        }).then((e) => (e.statusCode !== void 0 && (e.statusCode < 200 || e.statusCode >= 300) && B && H.warn(`Sentry responded with status code ${e.statusCode} to sent event.`), r = Bp(r, e), e), (e) => {
            throw s("network_error"), B && H.error("Encountered error running transport request:", e), e;
        })).then((e) => e, (e) => {
            if (e === Pp) return B && H.error("Skipped sending event because buffer is full."), s("queue_overflow"), Promise.resolve({});
            throw e;
        });
    }
    return {
        send: a,
        flush: i
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/clientreport.js
function Hp(e, t, n) {
    let r = [{
        type: "client_report"
    }, {
        timestamp: n || Au(),
        discarded_events: e
    }];
    return uf(t ? {
        dsn: t
    } : {}, [r]);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/eventUtils.js
function Up(e) {
    let t = [];
    e.message && t.push(e.message);
    try {
        let n = e.exception.values[e.exception.values.length - 1];
        n ? .value && (t.push(n.value), n.type && t.push(`${n.type}: ${n.value}`));
    } catch {}
    return t;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/transactionEvent.js
function Wp(e) {
    let {
        trace_id: t,
        parent_span_id: n,
        span_id: r,
        status: i,
        origin: a,
        data: o,
        op: s
    } = e.contexts ? .trace ? ? {};
    return {
        data: o ? ? {},
        description: e.transaction,
        op: s,
        parent_span_id: n,
        span_id: r ? ? "",
        start_timestamp: e.start_timestamp ? ? 0,
        status: i,
        timestamp: e.timestamp,
        trace_id: t ? ? "",
        origin: a,
        profile_id: o ? .[ud],
        exclusive_time: o ? .[dd],
        measurements: e.measurements,
        is_segment: !0
    };
}

function Gp(e) {
    return {
        type: "transaction",
        timestamp: e.timestamp,
        start_timestamp: e.start_timestamp,
        transaction: e.description,
        contexts: {
            trace: {
                trace_id: e.trace_id,
                span_id: e.span_id,
                parent_span_id: e.parent_span_id,
                op: e.op,
                status: e.status,
                origin: e.origin,
                data: {
                    ...e.data,
                    ...e.profile_id && {
                        "sentry.profile_id": e.profile_id
                    },
                    ...e.exclusive_time && {
                        "sentry.exclusive_time": e.exclusive_time
                    }
                }
            }
        },
        measurements: e.measurements
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/client.js
var Kp = "Not capturing exception because it's already been captured.",
    qp = "Discarded session because of missing or non-string release",
    Jp = Symbol.for("SentryInternalError"),
    Yp = Symbol.for("SentryDoNotSendEventError"),
    Xp = 5e3;

function Zp(e) {
    return {
        message: e,
        [Jp]: !0
    };
}

function Qp(e) {
    return {
        message: e,
        [Yp]: !0
    };
}

function $p(e) {
    return !!e && typeof e == "object" && Jp in e;
}

function em(e) {
    return !!e && typeof e == "object" && Yp in e;
}

function tm(e, t, n, r, i) {
    let a = 0,
        o, s = !1;
    e.on(n, () => {
        a = 0, clearTimeout(o), s = !1;
    }), e.on(t, (t) => {
        a += r(t), a >= 8e5 ? i(e) : s || (s = !0, o = setTimeout(() => {
            i(e);
        }, Xp));
    }), e.on("flush", () => {
        i(e);
    });
}
var nm = class {
    constructor(e) {
        if (this._options = e, this._integrations = {}, this._numProcessing = 0, this._outcomes = {}, this._hooks = {}, this._eventProcessors = [], this._promiseBuffer = Fp(e.transportOptions ? .bufferSize ? ? 64), e.dsn ? this._dsn = Ad(e.dsn) : B && H.warn("No DSN provided, client will not send events."), this._dsn) {
            let t = gp(this._dsn, e.tunnel, e._metadata ? e._metadata.sdk : void 0);
            this._transport = e.transport({
                tunnel: this._options.tunnel,
                recordDroppedEvent: this.recordDroppedEvent.bind(this),
                ...e.transportOptions,
                url: t
            });
        }
        this._options.enableLogs = this._options.enableLogs ? ? this._options._experiments ? .enableLogs, this._options.enableLogs && tm(this, "afterCaptureLog", "flushLogs", lm, Ep), (this._options.enableMetrics ? ? this._options._experiments ? .enableMetrics ? ? !0) && tm(this, "afterCaptureMetric", "flushMetrics", cm, jp);
    }
    captureException(e, t, n) {
        let r = Su();
        if (Du(e)) return B && H.log(Kp), r;
        let i = {
            event_id: r,
            ...t
        };
        return this._process(() => this.eventFromException(e, i).then((e) => this._captureEvent(e, i, n)).then((e) => e), "error"), i.event_id;
    }
    captureMessage(e, t, n, r) {
        let i = {
                event_id: Su(),
                ...n
            },
            a = Bl(e) ? e : String(e),
            o = Vl(e),
            s = o ? this.eventFromMessage(a, t, i) : this.eventFromException(e, i);
        return this._process(() => s.then((e) => this._captureEvent(e, i, r)), o ? "unknown" : "error"), i.event_id;
    }
    captureEvent(e, t, n) {
        let r = Su();
        if (t ? .originalException && Du(t.originalException)) return B && H.log(Kp), r;
        let i = {
                event_id: r,
                ...t
            },
            a = e.sdkProcessingMetadata || {},
            o = a.capturedSpanScope,
            s = a.capturedSpanIsolationScope,
            c = rm(e.type);
        return this._process(() => this._captureEvent(e, i, o || n, s), c), i.event_id;
    }
    captureSession(e) {
        this.sendSession(e), Fu(e, {
            init: !1
        });
    }
    getDsn() {
        return this._dsn;
    }
    getOptions() {
        return this._options;
    }
    getSdkMetadata() {
        return this._options._metadata;
    }
    getTransport() {
        return this._transport;
    }
    async flush(e) {
        let t = this._transport;
        if (!t) return !0;
        this.emit("flush");
        let n = await this._isClientDoneProcessing(e),
            r = await t.flush(e);
        return n && r;
    }
    async close(e) {
        let t = await this.flush(e);
        return this.getOptions().enabled = !1, this.emit("close"), t;
    }
    getEventProcessors() {
        return this._eventProcessors;
    }
    addEventProcessor(e) {
        this._eventProcessors.push(e);
    }
    init() {
        (this._isEnabled() || this._options.integrations.some(({
            name: e
        }) => e.startsWith("Spotlight"))) && this._setupIntegrations();
    }
    getIntegrationByName(e) {
        return this._integrations[e];
    }
    addIntegration(e) {
        let t = this._integrations[e.name];
        Sp(this, e, this._integrations), t || xp(this, [e]);
    }
    sendEvent(e, t = {}) {
        this.emit("beforeSendEvent", e, t);
        let n = wf(e, this._dsn, this._options._metadata, this._options.tunnel);
        for (let e of t.attachments || []) n = df(n, _f(e));
        this.sendEnvelope(n).then((t) => this.emit("afterSendEvent", e, t));
    }
    sendSession(e) {
        let {
            release: t,
            environment: n = Xd
        } = this._options;
        if ("aggregates" in e) {
            let r = e.attrs || {};
            if (!r.release && !t) {
                B && H.warn(qp);
                return;
            }
            r.release = r.release || t, r.environment = r.environment || n, e.attrs = r;
        } else {
            if (!e.release && !t) {
                B && H.warn(qp);
                return;
            }
            e.release = e.release || t, e.environment = e.environment || n;
        }
        this.emit("beforeSendSession", e);
        let r = Cf(e, this._dsn, this._options._metadata, this._options.tunnel);
        this.sendEnvelope(r);
    }
    recordDroppedEvent(e, t, n = 1) {
        if (this._options.sendClientReports) {
            let r = `${e}:${t}`;
            B && H.log(`Recording outcome: "${r}"${n > 1 ? ` (${n} times)` : ""}`), this._outcomes[r] = (this._outcomes[r] || 0) + n;
        }
    }
    on(e, t) {
        let n = this._hooks[e] = this._hooks[e] || /* @__PURE__ */ new Set(),
            r = (...e) => t(...e);
        return n.add(r), () => {
            n.delete(r);
        };
    }
    emit(e, ...t) {
        let n = this._hooks[e];
        n && n.forEach((e) => e(...t));
    }
    async sendEnvelope(e) {
        if (this.emit("beforeEnvelope", e), this._isEnabled() && this._transport) try {
            return await this._transport.send(e);
        } catch (e) {
            return B && H.error("Error while sending envelope:", e), {};
        }
        return B && H.error("Transport disabled"), {};
    }
    _setupIntegrations() {
        let {
            integrations: e
        } = this._options;
        this._integrations = bp(this, e), xp(this, e);
    }
    _updateSessionFromEvent(e, t) {
        let n = t.level === "fatal",
            r = !1,
            i = t.exception ? .values;
        if (i) {
            r = !0, n = !1;
            for (let e of i)
                if (e.mechanism ? .handled === !1) {
                    n = !0;
                    break;
                }
        }
        let a = e.status === "ok";
        (a && e.errors === 0 || a && n) && (Fu(e, {
            ...n && {
                status: "crashed"
            },
            errors: e.errors || Number(r || n)
        }), this.captureSession(e));
    }
    async _isClientDoneProcessing(e) {
        let t = 0;
        for (; !e || t < e;) {
            if (await new Promise((e) => setTimeout(e, 1)), !this._numProcessing) return !0;
            t++;
        }
        return !1;
    }
    _isEnabled() {
        return this.getOptions().enabled !== !1 && this._transport !== void 0;
    }
    _prepareEvent(e, t, n, r) {
        let i = this.getOptions(),
            a = Object.keys(this._integrations);
        return !t.integrations && a ? .length && (t.integrations = a), this.emit("preprocessEvent", e, t), e.type || r.setLastEventId(e.event_id || t.event_id), qf(i, e, t, n, this, r).then((e) => e === null ? e : (this.emit("postprocessEvent", e, t), e.contexts = {
            trace: od(n),
            ...e.contexts
        }, e.sdkProcessingMetadata = {
            dynamicSamplingContext: $d(this, n),
            ...e.sdkProcessingMetadata
        }, e));
    }
    _captureEvent(e, t = {}, n = td(), r = nd()) {
        return B && om(e) && H.log(`Captured error event \`${Up(e)[0] || "<unknown>"}\``), this._processEvent(e, t, n, r).then((e) => e.event_id, (e) => {
            B && (em(e) ? H.log(e.message) : $p(e) ? H.warn(e.message) : H.warn(e));
        });
    }
    _processEvent(e, t, n, r) {
        let i = this.getOptions(),
            {
                sampleRate: a
            } = i,
            o = sm(e),
            s = om(e),
            c = `before send for type \`${e.type || "error"}\``,
            l = a === void 0 ? void 0 : jd(a);
        if (s && typeof l == "number" && pu() > l) return this.recordDroppedEvent("sample_rate", "error"), kf(Qp(`Discarding event because it's not included in the random sample (sampling rate = ${a})`));
        let u = rm(e.type);
        return this._prepareEvent(e, t, n, r).then((e) => {
            if (e === null) throw this.recordDroppedEvent("event_processor", u), Qp("An event processor returned `null`, will not send event.");
            return t.data && t.data.__sentry__ === !0 ? e : im(am(this, i, e, t), c);
        }).then((i) => {
            if (i === null) {
                if (this.recordDroppedEvent("before_send", u), o) {
                    let t = 1 + (e.spans || []).length;
                    this.recordDroppedEvent("before_send", "span", t);
                }
                throw Qp(`${c} returned \`null\`, will not send event.`);
            }
            let a = n.getSession() || r.getSession();
            if (s && a && this._updateSessionFromEvent(a, i), o) {
                let e = (i.sdkProcessingMetadata ? .spanCountBeforeProcessing || 0) - (i.spans ? i.spans.length : 0);
                e > 0 && this.recordDroppedEvent("before_send", "span", e);
            }
            let l = i.transaction_info;
            return o && l && i.transaction !== e.transaction && (i.transaction_info = {
                ...l,
                source: "custom"
            }), this.sendEvent(i, t), i;
        }).then(null, (e) => {
            throw em(e) || $p(e) ? e : (this.captureException(e, {
                mechanism: {
                    handled: !1,
                    type: "internal"
                },
                data: {
                    __sentry__: !0
                },
                originalException: e
            }), Zp(`Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.\nReason: ${e}`));
        });
    }
    _process(e, t) {
        this._numProcessing++, this._promiseBuffer.add(e).then((e) => (this._numProcessing--, e), (e) => (this._numProcessing--, e === Pp && this.recordDroppedEvent("queue_overflow", t), e));
    }
    _clearOutcomes() {
        let e = this._outcomes;
        return this._outcomes = {}, Object.entries(e).map(([e, t]) => {
            let [n, r] = e.split(":");
            return {
                reason: n,
                category: r,
                quantity: t
            };
        });
    }
    _flushOutcomes() {
        B && H.log("Flushing outcomes...");
        let e = this._clearOutcomes();
        if (e.length === 0) {
            B && H.log("No outcomes to send");
            return;
        }
        if (!this._dsn) {
            B && H.log("No dsn provided, will not send outcomes");
            return;
        }
        B && H.log("Sending outcomes:", e);
        let t = Hp(e, this._options.tunnel && wd(this._dsn));
        this.sendEnvelope(t);
    }
};

function rm(e) {
    return e === "replay_event" ? "replay" : e || "error";
}

function im(e, t) {
    let n = `${t} must return \`null\` or a valid event.`;
    if (Kl(e)) return e.then((e) => {
        if (!Hl(e) && e !== null) throw Zp(n);
        return e;
    }, (e) => {
        throw Zp(`${t} rejected with ${e}`);
    });
    if (!Hl(e) && e !== null) throw Zp(n);
    return e;
}

function am(e, t, n, r) {
    let {
        beforeSend: i,
        beforeSendTransaction: a,
        beforeSendSpan: o,
        ignoreSpans: s
    } = t, c = n;
    if (om(c) && i) return i(c, r);
    if (sm(c)) {
        if (o || s) {
            let t = Wp(c);
            if (s ? .length && qd(t, s)) return null;
            if (o) {
                let e = o(t);
                e ? c = Ru(n, Gp(e)) : Wd();
            }
            if (c.spans) {
                let t = [],
                    n = c.spans;
                for (let e of n) {
                    if (s ? .length && qd(e, s)) {
                        Jd(n, e);
                        continue;
                    }
                    if (o) {
                        let n = o(e);
                        n ? t.push(n) : (Wd(), t.push(e));
                    } else t.push(e);
                }
                let r = c.spans.length - t.length;
                r && e.recordDroppedEvent("before_send", "span", r), c.spans = t;
            }
        }
        if (a) {
            if (c.spans) {
                let e = c.spans.length;
                c.sdkProcessingMetadata = {
                    ...n.sdkProcessingMetadata,
                    spanCountBeforeProcessing: e
                };
            }
            return a(c, r);
        }
    }
    return c;
}

function om(e) {
    return e.type === void 0;
}

function sm(e) {
    return e.type === "transaction";
}

function cm(e) {
    let t = 0;
    return e.name && (t += e.name.length * 2), t += 8, t + um(e.attributes);
}

function lm(e) {
    let t = 0;
    return e.message && (t += e.message.length * 2), t + um(e.attributes);
}

function um(e) {
    if (!e) return 0;
    let t = 0;
    return Object.values(e).forEach((e) => {
        Array.isArray(e) ? t += e.length * dm(e[0]) : Vl(e) ? t += dm(e) : t += 100;
    }), t;
}

function dm(e) {
    return typeof e == "string" ? e.length * 2 : typeof e == "number" ? 8 : typeof e == "boolean" ? 4 : 0;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/eventbuilder.js
function fm(e) {
    return Pl(e) && "__sentry_fetch_url_host__" in e && typeof e.__sentry_fetch_url_host__ == "string";
}

function pm(e) {
    return fm(e) ? `${e.message} (${e.__sentry_fetch_url_host__})` : e.message;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/sdk.js
function mm(e, t) {
    t.debug === !0 && (B ? H.enable() : nl(() => {
        console.warn("[Sentry] Cannot initialize SDK with `debug` option using a non-debug bundle.");
    })), td().update(t.initialScope);
    let n = new e(t);
    return hm(n), n.init(), n;
}

function hm(e) {
    td().setClient(e);
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/url.js
function gm(e) {
    if (!e) return {};
    let t = e.match(/^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
    if (!t) return {};
    let n = t[6] || "",
        r = t[8] || "";
    return {
        host: t[4],
        path: t[5],
        protocol: t[2],
        search: n,
        hash: r,
        relative: t[5] + n + r
    };
}

function _m(e, t = !0) {
    if (e.startsWith("data:")) {
        let n = e.match(/^data:([^;,]+)/),
            r = n ? n[1] : "text/plain",
            i = e.includes(";base64,"),
            a = e.indexOf(","),
            o = "";
        if (t && a !== -1) {
            let t = e.slice(a + 1);
            o = t.length > 10 ? `${t.slice(0, 10)}... [truncated]` : t;
        }
        return `data:${r}${i ? ",base64" : ""}${o ? `,${o}` : ""}`;
    }
    return e;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/ipAddress.js
function vm(e) {
    "aggregates" in e ? e.attrs ? .ip_address === void 0 && (e.attrs = {
        ...e.attrs,
        ip_address: "{{auto}}"
    }) : e.ipAddress === void 0 && (e.ipAddress = "{{auto}}");
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/sdkMetadata.js
function ym(e, t, n = [t], r = "npm") {
    let i = e._metadata || {};
    i.sdk || = {
        name: `sentry.javascript.${t}`,
        packages: n.map((e) => ({
            name: `${r}:@sentry/${e}`,
            version: Yc
        })),
        version: Yc
    }, e._metadata = i;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/breadcrumbs.js
var bm = 100;

function xm(e, t) {
    let n = ad(),
        r = nd();
    if (!n) return;
    let {
        beforeBreadcrumb: i = null,
        maxBreadcrumbs: a = bm
    } = n.getOptions();
    if (a <= 0) return;
    let o = {
            timestamp: Au(),
            ...e
        },
        s = i ? nl(() => i(o, t)) : o;
    s !== null && (n.emit && n.emit("beforeAddBreadcrumb", s, t), r.addBreadcrumb(s, a));
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/integrations/functiontostring.js
var Sm, Cm = "FunctionToString",
    wm = /* @__PURE__ */ new WeakMap(),
    Tm = Cp((() => ({
        name: Cm,
        setupOnce() {
            Sm = Function.prototype.toString;
            try {
                Function.prototype.toString = function(...e) {
                    let t = ou(this),
                        n = wm.has(ad()) && t !== void 0 ? t : this;
                    return Sm.apply(n, e);
                };
            } catch {}
        },
        setup(e) {
            wm.set(e, !0);
        }
    }))),
    Em = [
        /^Script error\.?$/,
        /^Javascript error: Script error\.? on line 0$/,
        /^ResizeObserver loop completed with undelivered notifications.$/,
        /^Cannot redefine property: googletag$/,
        /^Can't find variable: gmo$/,
        /^undefined is not an object \(evaluating 'a\.[A-Z]'\)$/,
        "can't redefine non-configurable property \"solana\"",
        "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)",
        "Can't find variable: _AutofillCallbackHandler",
        /^Non-Error promise rejection captured with value: Object Not Found Matching Id:\d+, MethodName:simulateEvent, ParamCount:\d+$/,
        /^Java exception was raised during method invocation$/
    ],
    Dm = "EventFilters",
    Om = Cp((e = {}) => {
        let t;
        return {
            name: Dm,
            setup(n) {
                t = Am(e, n.getOptions());
            },
            processEvent(n, r, i) {
                return t || = Am(e, i.getOptions()), jm(n, t) ? null : n;
            }
        };
    }),
    km = Cp(((e = {}) => ({
        ...Om(e),
        name: "InboundFilters"
    })));

function Am(e = {}, t = {}) {
    return {
        allowUrls: [...e.allowUrls || [], ...t.allowUrls || []],
        denyUrls: [...e.denyUrls || [], ...t.denyUrls || []],
        ignoreErrors: [
            ...e.ignoreErrors || [],
            ...t.ignoreErrors || [],
            ...e.disableErrorDefaults ? [] : Em
        ],
        ignoreTransactions: [...e.ignoreTransactions || [], ...t.ignoreTransactions || []]
    };
}

function jm(e, t) {
    if (!e.type) {
        if (Mm(e, t.ignoreErrors)) return B && H.warn(`Event dropped due to being matched by \`ignoreErrors\` option.\nEvent: ${wu(e)}`), !0;
        if (Rm(e)) return B && H.warn(`Event dropped due to not having an error message, error type or stacktrace.\nEvent: ${wu(e)}`), !0;
        if (Pm(e, t.denyUrls)) return B && H.warn(`Event dropped due to being matched by \`denyUrls\` option.\nEvent: ${wu(e)}.\nUrl: ${Lm(e)}`), !0;
        if (!Fm(e, t.allowUrls)) return B && H.warn(`Event dropped due to not being matched by \`allowUrls\` option.\nEvent: ${wu(e)}.\nUrl: ${Lm(e)}`), !0;
    } else if (e.type === "transaction" && Nm(e, t.ignoreTransactions)) return B && H.warn(`Event dropped due to being matched by \`ignoreTransactions\` option.\nEvent: ${wu(e)}`), !0;
    return !1;
}

function Mm(e, t) {
    return t ? .length ? Up(e).some((e) => vu(e, t)) : !1;
}

function Nm(e, t) {
    if (!t ? .length) return !1;
    let n = e.transaction;
    return n ? vu(n, t) : !1;
}

function Pm(e, t) {
    if (!t ? .length) return !1;
    let n = Lm(e);
    return n ? vu(n, t) : !1;
}

function Fm(e, t) {
    if (!t ? .length) return !0;
    let n = Lm(e);
    return n ? vu(n, t) : !0;
}

function Im(e = []) {
    for (let t = e.length - 1; t >= 0; t--) {
        let n = e[t];
        if (n && n.filename !== "<anonymous>" && n.filename !== "[native code]") return n.filename || null;
    }
    return null;
}

function Lm(e) {
    try {
        let t = [...e.exception ? .values ? ? []].reverse().find((e) => e.mechanism ? .parent_id === void 0 && e.stacktrace ? .frames ? .length) ? .stacktrace ? .frames;
        return t ? Im(t) : null;
    } catch {
        return B && H.error(`Cannot extract url for event ${wu(e)}`), null;
    }
}

function Rm(e) {
    return e.exception ? .values ? .length ? !e.message && !e.exception.values.some((e) => e.stacktrace || e.type && e.type !== "Error" || e.value) : !1;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/aggregate-errors.js
function zm(e, t, n, r, i, a) {
    if (!i.exception ? .values || !a || !Jl(a.originalException, Error)) return;
    let o = i.exception.values.length > 0 ? i.exception.values[i.exception.values.length - 1] : void 0;
    o && (i.exception.values = Bm(e, t, r, a.originalException, n, i.exception.values, o, 0));
}

function Bm(e, t, n, r, i, a, o, s) {
    if (a.length >= n + 1) return a;
    let c = [...a];
    if (Jl(r[i], Error)) {
        Hm(o, s, r);
        let a = e(t, r[i]),
            l = c.length;
        Um(a, i, l, s), c = Bm(e, t, n, r[i], i, [a, ...c], a, l);
    }
    return Vm(r) && r.errors.forEach((a, l) => {
        if (Jl(a, Error)) {
            Hm(o, s, r);
            let u = e(t, a),
                d = c.length;
            Um(u, `errors[${l}]`, d, s), c = Bm(e, t, n, a, i, [u, ...c], u, d);
        }
    }), c;
}

function Vm(e) {
    return Array.isArray(e.errors);
}

function Hm(e, t, n) {
    e.mechanism = {
        handled: !0,
        type: "auto.core.linked_errors",
        ...Vm(n) && {
            is_exception_group: !0
        },
        ...e.mechanism,
        exception_id: t
    };
}

function Um(e, t, n, r) {
    e.mechanism = {
        handled: !0,
        ...e.mechanism,
        type: "chained",
        source: t,
        exception_id: n,
        parent_id: r
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/instrument/console.js
function Wm(e) {
    let t = "console";
    wl(t, e), Tl(t, Gm);
}

function Gm() {
    "console" in V && $c.forEach(function(e) {
        e in V.console && ru(V.console, e, function(t) {
            return tl[e] = t,
                function(...t) {
                    El("console", {
                        args: t,
                        level: e
                    }), tl[e] ? .apply(V.console, t);
                };
        });
    });
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/severity.js
function Km(e) {
    return e === "warn" ? "warning" : [
        "fatal",
        "error",
        "warning",
        "log",
        "info",
        "debug"
    ].includes(e) ? e : "log";
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/integrations/dedupe.js
var qm = "Dedupe",
    Jm = Cp((() => {
        let e;
        return {
            name: qm,
            processEvent(t) {
                if (t.type) return t;
                try {
                    if (Ym(t, e)) return B && H.warn("Event dropped due to being a duplicate of previously captured event."), null;
                } catch {}
                return e = t;
            }
        };
    }));

function Ym(e, t) {
    return t ? !!(Xm(e, t) || Zm(e, t)) : !1;
}

function Xm(e, t) {
    let n = e.message,
        r = t.message;
    return !(!n && !r || n && !r || !n && r || n !== r || !$m(e, t) || !Qm(e, t));
}

function Zm(e, t) {
    let n = eh(t),
        r = eh(e);
    return !(!n || !r || n.type !== r.type || n.value !== r.value || !$m(e, t) || !Qm(e, t));
}

function Qm(e, t) {
    let n = bl(e),
        r = bl(t);
    if (!n && !r) return !0;
    if (n && !r || !n && r || (n = n, r = r, r.length !== n.length)) return !1;
    for (let e = 0; e < r.length; e++) {
        let t = r[e],
            i = n[e];
        if (t.filename !== i.filename || t.lineno !== i.lineno || t.colno !== i.colno || t.function !== i.function) return !1;
    }
    return !0;
}

function $m(e, t) {
    let n = e.fingerprint,
        r = t.fingerprint;
    if (!n && !r) return !0;
    if (n && !r || !n && r) return !1;
    n = n, r = r;
    try {
        return n.join("") === r.join("");
    } catch {
        return !1;
    }
}

function eh(e) {
    return e.exception ? .values ? .[0];
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/integrations/conversationId.js
var th = "ConversationId",
    nh = Cp((() => ({
        name: th,
        setup(e) {
            e.on("spanStart", (e) => {
                let t = td().getScopeData(),
                    n = nd().getScopeData(),
                    r = t.conversationId || n.conversationId;
                r && e.setAttribute(fd, r);
            });
        }
    })));
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/breadcrumb-log-level.js
function rh(e) {
    if (e !== void 0) {
        if (e >= 400 && e < 500) return "warning";
        if (e >= 500) return "error";
    }
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/supports.js
var ih = V;

function ah() {
    if (!("fetch" in ih)) return !1;
    try {
        return new Headers(), new Request("data:,"), new Response(), !0;
    } catch {
        return !1;
    }
}

function oh(e) {
    return e && /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(e.toString());
}

function sh() {
    if (typeof EdgeRuntime == "string") return !0;
    if (!ah()) return !1;
    if (oh(ih.fetch)) return !0;
    let e = !1,
        t = ih.document;
    if (t && typeof t.createElement == "function") try {
        let n = t.createElement("iframe");
        n.hidden = !0, t.head.appendChild(n), n.contentWindow ? .fetch && (e = oh(n.contentWindow.fetch)), t.head.removeChild(n);
    } catch (e) {
        B && H.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ", e);
    }
    return e;
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/instrument/fetch.js
function ch(e, t) {
    let n = "fetch";
    wl(n, e), Tl(n, () => lh(void 0, t));
}

function lh(e, t = !1) {
    t && !sh() || ru(V, "fetch", function(t) {
        return function(...n) {
            let r = /* @__PURE__ */ Error(),
                {
                    method: i,
                    url: a
                } = fh(n),
                o = {
                    args: n,
                    fetchData: {
                        method: i,
                        url: a
                    },
                    startTimestamp: Nu() * 1e3,
                    virtualError: r,
                    headers: ph(n)
                };
            return e || El("fetch", { ...o
            }), t.apply(V, n).then(async (t) => (e ? e(t) : El("fetch", {
                ...o,
                endTimestamp: Nu() * 1e3,
                response: t
            }), t), (e) => {
                El("fetch", {
                    ...o,
                    endTimestamp: Nu() * 1e3,
                    error: e
                }), Pl(e) && e.stack === void 0 && (e.stack = r.stack, iu(e, "framesToPop", 1));
                let t = ad() ? .getOptions().enhanceFetchErrorMessages ? ? "always";
                if (t !== !1 && e instanceof TypeError && (e.message === "Failed to fetch" || e.message === "Load failed" || e.message === "NetworkError when attempting to fetch resource.")) try {
                    let n = new URL(o.fetchData.url).host;
                    t === "always" ? e.message = `${e.message} (${n})` : iu(e, "__sentry_fetch_url_host__", n);
                } catch {}
                throw e;
            });
        };
    });
}

function uh(e, t) {
    return !!e && typeof e == "object" && !!e[t];
}

function dh(e) {
    return typeof e == "string" ? e : e ? uh(e, "url") ? e.url : e.toString ? e.toString() : "" : "";
}

function fh(e) {
    if (e.length === 0) return {
        method: "GET",
        url: ""
    };
    if (e.length === 2) {
        let [t, n] = e;
        return {
            url: dh(t),
            method: uh(n, "method") ? String(n.method).toUpperCase() : Xl(t) && uh(t, "method") ? String(t.method).toUpperCase() : "GET"
        };
    }
    let t = e[0];
    return {
        url: dh(t),
        method: uh(t, "method") ? String(t.method).toUpperCase() : "GET"
    };
}

function ph(e) {
    let [t, n] = e;
    try {
        if (typeof n == "object" && n && "headers" in n && n.headers) return new Headers(n.headers);
        if (Xl(t)) return new Headers(t.headers);
    } catch {}
}
//#endregion
//#region ../../node_modules/@sentry/browser/node_modules/@sentry/core/build/esm/utils/env.js
function mh() {
    return "npm";
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/helpers.js
var U = V,
    hh = 0;

function gh() {
    return hh > 0;
}

function _h() {
    hh++, setTimeout(() => {
        hh--;
    });
}

function vh(e, t = {}) {
    function n(e) {
        return typeof e == "function";
    }
    if (!n(e)) return e;
    try {
        let t = e.__sentry_wrapped__;
        if (t) return typeof t == "function" ? t : e;
        if (ou(e)) return e;
    } catch {
        return e;
    }
    let r = function(...n) {
        try {
            let r = n.map((e) => vh(e, t));
            return e.apply(this, r);
        } catch (e) {
            throw _h(), id((r) => {
                r.addEventProcessor((e) => (t.mechanism && (Tu(e, void 0, void 0), Eu(e, t.mechanism)), e.extra = {
                    ...e.extra,
                    arguments: n
                }, e)), ip(e);
            }), e;
        }
    };
    try {
        for (let t in e) Object.prototype.hasOwnProperty.call(e, t) && (r[t] = e[t]);
    } catch {}
    au(r, e), iu(e, "__sentry_wrapped__", r);
    try {
        Object.getOwnPropertyDescriptor(r, "name").configurable && Object.defineProperty(r, "name", {
            get() {
                return e.name;
            }
        });
    } catch {}
    return r;
}

function yh() {
    let e = tu(),
        {
            referrer: t
        } = U.document || {},
        {
            userAgent: n
        } = U.navigator || {};
    return {
        url: e,
        headers: {
            ...t && {
                Referer: t
            },
            ...n && {
                "User-Agent": n
            }
        }
    };
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/eventbuilder.js
function bh(e, t) {
    let n = Ch(e, t),
        r = {
            type: Oh(t),
            value: kh(t)
        };
    return n.length && (r.stacktrace = {
        frames: n
    }), r.type === void 0 && r.value === "" && (r.value = "Unrecoverable error caught"), r;
}

function xh(e, t, n, r) {
    let i = ad() ? .getOptions().normalizeDepth,
        a = Ih(t),
        o = {
            __serialized__: nf(t, i)
        };
    if (a) return {
        exception: {
            values: [bh(e, a)]
        },
        extra: o
    };
    let s = {
        exception: {
            values: [{
                type: Ul(t) ? t.constructor.name : r ? "UnhandledRejection" : "Error",
                value: Ph(t, {
                    isUnhandledRejection: r
                })
            }]
        },
        extra: o
    };
    if (n) {
        let t = Ch(e, n);
        t.length && (s.exception.values[0].stacktrace = {
            frames: t
        });
    }
    return s;
}

function Sh(e, t) {
    return {
        exception: {
            values: [bh(e, t)]
        }
    };
}

function Ch(e, t) {
    let n = t.stacktrace || t.stack || "",
        r = Th(t),
        i = Eh(t);
    try {
        return e(n, r, i);
    } catch {}
    return [];
}
var wh = /Minified React error #\d+;/i;

function Th(e) {
    return e && wh.test(e.message) ? 1 : 0;
}

function Eh(e) {
    return typeof e.framesToPop == "number" ? e.framesToPop : 0;
}

function Dh(e) {
    return typeof WebAssembly < "u" && WebAssembly.Exception !== void 0 ? e instanceof WebAssembly.Exception : !1;
}

function Oh(e) {
    let t = e ? .name;
    return !t && Dh(e) ? e.message && Array.isArray(e.message) && e.message.length == 2 ? e.message[0] : "WebAssembly.Exception" : t;
}

function kh(e) {
    let t = e ? .message;
    return Dh(e) ? Array.isArray(e.message) && e.message.length == 2 ? e.message[1] : "wasm exception" : t ? t.error && typeof t.error.message == "string" ? pm(t.error) : pm(e) : "No error message";
}

function Ah(e, t, n, r) {
    let i = Mh(e, t, n ? .syntheticException || void 0, r);
    return Eu(i), i.level = "error", n ? .event_id && (i.event_id = n.event_id), Of(i);
}

function jh(e, t, n = "info", r, i) {
    let a = Nh(e, t, r ? .syntheticException || void 0, i);
    return a.level = n, r ? .event_id && (a.event_id = r.event_id), Of(a);
}

function Mh(e, t, n, r, i) {
    let a;
    if (Il(t) && t.error) return Sh(e, t.error);
    if (Ll(t) || Rl(t)) {
        let i = t;
        if ("stack" in t) a = Sh(e, t);
        else {
            let t = i.name || (Ll(i) ? "DOMError" : "DOMException"),
                o = i.message ? `${t}: ${i.message}` : t;
            a = Nh(e, o, n, r), Tu(a, o);
        }
        return "code" in i && (a.tags = {
            ...a.tags,
            "DOMException.code": `${i.code}`
        }), a;
    }
    return Pl(t) ? Sh(e, t) : Hl(t) || Ul(t) ? (a = xh(e, t, n, i), Eu(a, {
        synthetic: !0
    }), a) : (a = Nh(e, t, n, r), Tu(a, `${t}`, void 0), Eu(a, {
        synthetic: !0
    }), a);
}

function Nh(e, t, n, r) {
    let i = {};
    if (r && n) {
        let r = Ch(e, n);
        r.length && (i.exception = {
            values: [{
                value: t,
                stacktrace: {
                    frames: r
                }
            }]
        }), Eu(i, {
            synthetic: !0
        });
    }
    if (Bl(t)) {
        let {
            __sentry_template_string__: e,
            __sentry_template_values__: n
        } = t;
        return i.logentry = {
            message: e,
            params: n
        }, i;
    }
    return i.message = t, i;
}

function Ph(e, {
    isUnhandledRejection: t
}) {
    let n = uu(e),
        r = t ? "promise rejection" : "exception";
    return Il(e) ? `Event \`ErrorEvent\` captured as ${r} with message \`${e.message}\`` : Ul(e) ? `Event \`${Fh(e)}\` (type=${e.type}) captured as ${r}` : `Object captured as ${r} with keys: ${n}`;
}

function Fh(e) {
    try {
        let t = Object.getPrototypeOf(e);
        return t ? t.constructor.name : void 0;
    } catch {}
}

function Ih(e) {
    for (let t in e)
        if (Object.prototype.hasOwnProperty.call(e, t)) {
            let n = e[t];
            if (n instanceof Error) return n;
        }
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/client.js
var Lh = class extends nm {
    constructor(e) {
        let t = Rh(e);
        ym(t, "browser", ["browser"], U.SENTRY_SDK_SOURCE || mh()), t._metadata ? .sdk && (t._metadata.sdk.settings = {
            infer_ip: t.sendDefaultPii ? "auto" : "never",
            ...t._metadata.sdk.settings
        }), super(t);
        let {
            sendDefaultPii: n,
            sendClientReports: r,
            enableLogs: i,
            _experiments: a,
            enableMetrics: o
        } = this._options, s = o ? ? a ? .enableMetrics ? ? !0;
        U.document && (r || i || s) && U.document.addEventListener("visibilitychange", () => {
            U.document.visibilityState === "hidden" && (r && this._flushOutcomes(), i && Ep(this), s && jp(this));
        }), n && this.on("beforeSendSession", vm);
    }
    eventFromException(e, t) {
        return Ah(this._options.stackParser, e, t, this._options.attachStacktrace);
    }
    eventFromMessage(e, t = "info", n) {
        return jh(this._options.stackParser, e, t, n, this._options.attachStacktrace);
    }
    _prepareEvent(e, t, n, r) {
        return e.platform = e.platform || "javascript", super._prepareEvent(e, t, n, r);
    }
};

function Rh(e) {
    return {
        release: typeof __SENTRY_RELEASE__ == "string" ? __SENTRY_RELEASE__ : U.SENTRY_RELEASE ? .id,
        sendClientReports: !0,
        parentSpanIsAlwaysRootSpan: !0,
        ...e
    };
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/debug-build.js
var zh = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__,
    Bh = globalThis,
    Vh = "10.38.0";
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/carrier.js
function Hh(e, t, n = Bh) {
    let r = n.__SENTRY__ = n.__SENTRY__ || {},
        i = r[Vh] = r["10.38.0"] || {};
    return i[e] || (i[e] = t());
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/utils/debug-logger.js
var Uh = "Sentry Logger ",
    Wh = {};

function Gh(e) {
    if (!("console" in Bh)) return e();
    let t = Bh.console,
        n = {},
        r = Object.keys(Wh);
    r.forEach((e) => {
        let r = Wh[e];
        n[e] = t[e], t[e] = r;
    });
    try {
        return e();
    } finally {
        r.forEach((e) => {
            t[e] = n[e];
        });
    }
}

function Kh() {
    $h().enabled = !0;
}

function qh() {
    $h().enabled = !1;
}

function Jh() {
    return $h().enabled;
}

function Yh(...e) {
    Qh("log", ...e);
}

function Xh(...e) {
    Qh("warn", ...e);
}

function Zh(...e) {
    Qh("error", ...e);
}

function Qh(e, ...t) {
    zh && Jh() && Gh(() => {
        Bh.console[e](`${Uh}[${e}]:`, ...t);
    });
}

function $h() {
    return zh ? Hh("loggerSettings", () => ({
        enabled: !1
    })) : {
        enabled: !1
    };
}
var eg = {
        enable: Kh,
        disable: qh,
        isEnabled: Jh,
        log: Yh,
        warn: Xh,
        error: Zh
    },
    tg = "<anonymous>";

function ng(e) {
    try {
        return !e || typeof e != "function" ? tg : e.name || tg;
    } catch {
        return tg;
    }
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/instrument/handlers.js
var rg = {},
    ig = {};

function ag(e, t) {
    rg[e] = rg[e] || [], rg[e].push(t);
}

function og(e, t) {
    if (!ig[e]) {
        ig[e] = !0;
        try {
            t();
        } catch (t) {
            zh && eg.error(`Error while instrumenting ${e}`, t);
        }
    }
}

function sg(e, t) {
    let n = e && rg[e];
    if (n)
        for (let r of n) try {
            r(t);
        } catch (t) {
            zh && eg.error(`Error while triggering instrumentation handler.\nType: ${e}\nName: ${ng(r)}\nError:`, t);
        }
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/utils/is.js
var cg = Object.prototype.toString;

function lg(e, t) {
    return cg.call(e) === `[object ${t}]`;
}

function ug(e) {
    return lg(e, "String");
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/utils/object.js
function dg(e, t, n) {
    if (!(t in e)) return;
    let r = e[t];
    if (typeof r != "function") return;
    let i = n(r);
    typeof i == "function" && pg(i, r);
    try {
        e[t] = i;
    } catch {
        zh && eg.log(`Failed to replace method "${t}" in object`, e);
    }
}

function fg(e, t, n) {
    try {
        Object.defineProperty(e, t, {
            value: n,
            writable: !0,
            configurable: !0
        });
    } catch {
        zh && eg.log(`Failed to add non-enumerable property "${t}" to object`, e);
    }
}

function pg(e, t) {
    try {
        e.prototype = t.prototype = t.prototype || {}, fg(e, "__sentry_original__", t);
    } catch {}
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/utils/randomSafeContext.js
var mg;

function hg(e) {
    if (mg !== void 0) return mg ? mg(e) : e();
    let t = Symbol.for("__SENTRY_SAFE_RANDOM_ID_WRAPPER__"),
        n = Bh;
    return t in n && typeof n[t] == "function" ? (mg = n[t], mg(e)) : (mg = null, e());
}

function gg() {
    return hg(() => Math.random());
}

function _g() {
    return hg(() => Date.now());
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/utils/misc.js
function vg() {
    let e = Bh;
    return e.crypto || e.msCrypto;
}
var yg;

function bg() {
    return gg() * 16;
}

function xg(e = vg()) {
    try {
        if (e ? .randomUUID) return hg(() => e.randomUUID()).replace(/-/g, "");
    } catch {}
    return yg || = "10000000100040008000100000000000", yg.replace(/[018]/g, (e) => (e ^ (bg() & 15) >> e / 4).toString(16));
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/utils/time.js
var Sg = 1e3;

function Cg() {
    return _g() / Sg;
}

function wg() {
    let {
        performance: e
    } = Bh;
    if (!e ? .now || !e.timeOrigin) return Cg;
    let t = e.timeOrigin;
    return () => (t + hg(() => e.now())) / Sg;
}
var Tg;

function Eg() {
    return (Tg ? ? = wg())();
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/node_modules/@sentry/core/build/esm/utils/supports.js
var Dg = Bh;

function Og() {
    return "history" in Dg && !!Dg.history;
}

function kg(e) {
    return e && /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(e.toString());
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/build/esm/debug-build.js
var Ag = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__,
    jg = Bh,
    Mg = 1e3,
    Ng, Pg, Fg;

function Ig(e) {
    ag("dom", e), og("dom", Lg);
}

function Lg() {
    if (!jg.document) return;
    let e = sg.bind(null, "dom"),
        t = Bg(e, !0);
    jg.document.addEventListener("click", t, !1), jg.document.addEventListener("keypress", t, !1), ["EventTarget", "Node"].forEach((t) => {
        let n = jg[t] ? .prototype;
        n ? .hasOwnProperty ? .("addEventListener") && (dg(n, "addEventListener", function(t) {
            return function(n, r, i) {
                if (n === "click" || n == "keypress") try {
                    let r = this.__sentry_instrumentation_handlers__ = this.__sentry_instrumentation_handlers__ || {},
                        a = r[n] = r[n] || {
                            refCount: 0
                        };
                    if (!a.handler) {
                        let r = Bg(e);
                        a.handler = r, t.call(this, n, r, i);
                    }
                    a.refCount++;
                } catch {}
                return t.call(this, n, r, i);
            };
        }), dg(n, "removeEventListener", function(e) {
            return function(t, n, r) {
                if (t === "click" || t == "keypress") try {
                    let n = this.__sentry_instrumentation_handlers__ || {},
                        i = n[t];
                    i && (i.refCount--, i.refCount <= 0 && (e.call(this, t, i.handler, r), i.handler = void 0, delete n[t]), Object.keys(n).length === 0 && delete this.__sentry_instrumentation_handlers__);
                } catch {}
                return e.call(this, t, n, r);
            };
        }));
    });
}

function Rg(e) {
    if (e.type !== Pg) return !1;
    try {
        if (!e.target || e.target._sentryId !== Fg) return !1;
    } catch {}
    return !0;
}

function zg(e, t) {
    return e === "keypress" ? t ? .tagName ? !(t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable) : !0 : !1;
}

function Bg(e, t = !1) {
    return (n) => {
        if (!n || n._sentryCaptured) return;
        let r = Vg(n);
        if (zg(n.type, r)) return;
        fg(n, "_sentryCaptured", !0), r && !r._sentryId && fg(r, "_sentryId", xg());
        let i = n.type === "keypress" ? "input" : n.type;
        Rg(n) || (e({
            event: n,
            name: i,
            global: t
        }), Pg = n.type, Fg = r ? r._sentryId : void 0), clearTimeout(Ng), Ng = jg.setTimeout(() => {
            Fg = void 0, Pg = void 0;
        }, Mg);
    };
}

function Vg(e) {
    try {
        return e.target;
    } catch {
        return null;
    }
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/build/esm/instrument/history.js
var Hg;

function Ug(e) {
    let t = "history";
    ag(t, e), og(t, Wg);
}

function Wg() {
    if (jg.addEventListener("popstate", () => {
            let e = jg.location.href,
                t = Hg;
            Hg = e, t !== e && sg("history", {
                from: t,
                to: e
            });
        }), !Og()) return;

    function e(e) {
        return function(...t) {
            let n = t.length > 2 ? t[2] : void 0;
            if (n) {
                let r = Hg,
                    i = Gg(String(n));
                if (Hg = i, r === i) return e.apply(this, t);
                sg("history", {
                    from: r,
                    to: i
                });
            }
            return e.apply(this, t);
        };
    }
    dg(jg.history, "pushState", e), dg(jg.history, "replaceState", e);
}

function Gg(e) {
    try {
        return new URL(e, jg.location.origin).toString();
    } catch {
        return e;
    }
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/build/esm/getNativeImplementation.js
var Kg = {};

function qg(e) {
    let t = Kg[e];
    if (t) return t;
    let n = jg[e];
    if (kg(n)) return Kg[e] = n.bind(jg);
    let r = jg.document;
    if (r && typeof r.createElement == "function") try {
        let t = r.createElement("iframe");
        t.hidden = !0, r.head.appendChild(t);
        let i = t.contentWindow;
        i ? .[e] && (n = i[e]), r.head.removeChild(t);
    } catch (t) {
        Ag && eg.warn(`Could not create sandbox iframe for ${e} check, bailing to window.${e}: `, t);
    }
    return n && (Kg[e] = n.bind(jg));
}

function Jg(e) {
    Kg[e] = void 0;
}
//#endregion
//#region ../../node_modules/@sentry-internal/browser-utils/build/esm/instrument/xhr.js
var Yg = "__sentry_xhr_v3__";

function Xg(e) {
    ag("xhr", e), og("xhr", Zg);
}

function Zg() {
    if (!jg.XMLHttpRequest) return;
    let e = XMLHttpRequest.prototype;
    e.open = new Proxy(e.open, {
        apply(e, t, n) {
            let r = /* @__PURE__ */ Error(),
                i = Eg() * 1e3,
                a = ug(n[0]) ? n[0].toUpperCase() : void 0,
                o = Qg(n[1]);
            if (!a || !o) return e.apply(t, n);
            t[Yg] = {
                method: a,
                url: o,
                request_headers: {}
            }, a === "POST" && o.match(/sentry_key/) && (t.__sentry_own_request__ = !0);
            let s = () => {
                let e = t[Yg];
                if (e && t.readyState === 4) {
                    try {
                        e.status_code = t.status;
                    } catch {}
                    sg("xhr", {
                        endTimestamp: Eg() * 1e3,
                        startTimestamp: i,
                        xhr: t,
                        virtualError: r
                    });
                }
            };
            return "onreadystatechange" in t && typeof t.onreadystatechange == "function" ? t.onreadystatechange = new Proxy(t.onreadystatechange, {
                apply(e, t, n) {
                    return s(), e.apply(t, n);
                }
            }) : t.addEventListener("readystatechange", s), t.setRequestHeader = new Proxy(t.setRequestHeader, {
                apply(e, t, n) {
                    let [r, i] = n, a = t[Yg];
                    return a && ug(r) && ug(i) && (a.request_headers[r.toLowerCase()] = i), e.apply(t, n);
                }
            }), e.apply(t, n);
        }
    }), e.send = new Proxy(e.send, {
        apply(e, t, n) {
            let r = t[Yg];
            return r ? (n[0] !== void 0 && (r.body = n[0]), sg("xhr", {
                startTimestamp: Eg() * 1e3,
                xhr: t
            }), e.apply(t, n)) : e.apply(t, n);
        }
    });
}

function Qg(e) {
    if (ug(e)) return e;
    try {
        return e.toString();
    } catch {}
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/transports/fetch.js
var $g = 40;

function e_(e, t = qg("fetch")) {
    let n = 0,
        r = 0;
    async function i(i) {
        let a = i.body.length;
        n += a, r++;
        let o = {
            body: i.body,
            method: "POST",
            referrerPolicy: "strict-origin",
            headers: e.headers,
            keepalive: n <= 6e4 && r < 15,
            ...e.fetchOptions
        };
        try {
            let n = await t(e.url, o);
            return {
                statusCode: n.status,
                headers: {
                    "x-sentry-rate-limits": n.headers.get("X-Sentry-Rate-Limits"),
                    "retry-after": n.headers.get("Retry-After")
                }
            };
        } catch (e) {
            throw Jg("fetch"), e;
        } finally {
            n -= a, r--;
        }
    }
    return Vp(e, i, Fp(e.bufferSize || $g));
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/debug-build.js
var t_ = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__,
    n_ = 30,
    r_ = 50;

function i_(e, t, n, r) {
    let i = {
        filename: e,
        function: t === "<anonymous>" ? "?" : t,
        in_app: !0
    };
    return n !== void 0 && (i.lineno = n), r !== void 0 && (i.colno = r), i;
}
var a_ = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
    o_ = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
    s_ = /\((\S*)(?::(\d+))(?::(\d+))\)/,
    c_ = /at (.+?) ?\(data:(.+?),/,
    l_ = [n_, (e) => {
        let t = e.match(c_);
        if (t) return {
            filename: `<data:${t[2]}>`,
            function: t[1]
        };
        let n = a_.exec(e);
        if (n) {
            let [, e, t, r] = n;
            return i_(e, "?", +t, +r);
        }
        let r = o_.exec(e);
        if (r) {
            if (r[2] && r[2].indexOf("eval") === 0) {
                let e = s_.exec(r[2]);
                e && (r[2] = e[1], r[3] = e[2], r[4] = e[3]);
            }
            let [e, t] = p_(r[1] || "?", r[2]);
            return i_(t, e, r[3] ? +r[3] : void 0, r[4] ? +r[4] : void 0);
        }
    }],
    u_ = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
    d_ = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
    f_ = ml(l_, [r_, (e) => {
        let t = u_.exec(e);
        if (t) {
            if (t[3] && t[3].indexOf(" > eval") > -1) {
                let e = d_.exec(t[3]);
                e && (t[1] = t[1] || "eval", t[3] = e[1], t[4] = e[2], t[5] = "");
            }
            let e = t[3],
                n = t[1] || "?";
            return [n, e] = p_(n, e), i_(e, n, t[4] ? +t[4] : void 0, t[5] ? +t[5] : void 0);
        }
    }]),
    p_ = (e, t) => {
        let n = e.indexOf("safari-extension") !== -1,
            r = e.indexOf("safari-web-extension") !== -1;
        return n || r ? [e.indexOf("@") === -1 ? "?" : e.split("@")[0], n ? `safari-extension:${t}` : `safari-web-extension:${t}`] : [e, t];
    },
    m_ = 1024,
    h_ = "Breadcrumbs",
    g_ = Cp(((e = {}) => {
        let t = {
            console: !0,
            dom: !0,
            fetch: !0,
            history: !0,
            sentry: !0,
            xhr: !0,
            ...e
        };
        return {
            name: h_,
            setup(e) {
                t.console && Wm(y_(e)), t.dom && Ig(v_(e, t.dom)), t.xhr && Xg(b_(e)), t.fetch && ch(x_(e)), t.history && Ug(S_(e)), t.sentry && e.on("beforeSendEvent", __(e));
            }
        };
    }));

function __(e) {
    return function(t) {
        ad() === e && xm({
            category: `sentry.${t.type === "transaction" ? "transaction" : "event"}`,
            event_id: t.event_id,
            level: t.level,
            message: wu(t)
        }, {
            event: t
        });
    };
}

function v_(e, t) {
    return function(n) {
        if (ad() !== e) return;
        let r, i, a = typeof t == "object" ? t.serializeAttribute : void 0,
            o = typeof t == "object" && typeof t.maxStringLength == "number" ? t.maxStringLength : void 0;
        o && o > m_ && (t_ && H.warn(`\`dom.maxStringLength\` cannot exceed ${m_}, but a value of ${o} was configured. Sentry will use ${m_} instead.`), o = m_), typeof a == "string" && (a = [a]);
        try {
            let e = n.event,
                t = C_(e) ? e.target : e;
            r = $l(t, {
                keyAttrs: a,
                maxStringLength: o
            }), i = nu(t);
        } catch {
            r = "<unknown>";
        }
        if (r.length === 0) return;
        let s = {
            category: `ui.${n.name}`,
            message: r
        };
        i && (s.data = {
            "ui.component_name": i
        }), xm(s, {
            event: n.event,
            name: n.name,
            global: n.global
        });
    };
}

function y_(e) {
    return function(t) {
        if (ad() !== e) return;
        let n = {
            category: "console",
            data: {
                arguments: t.args,
                logger: "console"
            },
            level: Km(t.level),
            message: gu(t.args, " ")
        };
        if (t.level === "assert")
            if (t.args[0] === !1) n.message = `Assertion failed: ${gu(t.args.slice(1), " ") || "console.assert"}`, n.data.arguments = t.args.slice(1);
            else return;
        xm(n, {
            input: t.args,
            level: t.level
        });
    };
}

function b_(e) {
    return function(t) {
        if (ad() !== e) return;
        let {
            startTimestamp: n,
            endTimestamp: r
        } = t, i = t.xhr[Yg];
        if (!n || !r || !i) return;
        let {
            method: a,
            url: o,
            status_code: s,
            body: c
        } = i, l = {
            method: a,
            url: o,
            status_code: s
        }, u = {
            xhr: t.xhr,
            input: c,
            startTimestamp: n,
            endTimestamp: r
        }, d = {
            category: "xhr",
            data: l,
            type: "http",
            level: rh(s)
        };
        e.emit("beforeOutgoingRequestBreadcrumb", d, u), xm(d, u);
    };
}

function x_(e) {
    return function(t) {
        if (ad() !== e) return;
        let {
            startTimestamp: n,
            endTimestamp: r
        } = t;
        if (r && !(t.fetchData.url.match(/sentry_key/) && t.fetchData.method === "POST"))
            if (t.fetchData.method, t.fetchData.url, t.error) {
                let i = t.fetchData,
                    a = {
                        data: t.error,
                        input: t.args,
                        startTimestamp: n,
                        endTimestamp: r
                    },
                    o = {
                        category: "fetch",
                        data: i,
                        level: "error",
                        type: "http"
                    };
                e.emit("beforeOutgoingRequestBreadcrumb", o, a), xm(o, a);
            } else {
                let i = t.response,
                    a = {
                        ...t.fetchData,
                        status_code: i ? .status
                    };
                t.fetchData.request_body_size, t.fetchData.response_body_size, i ? .status;
                let o = {
                        input: t.args,
                        response: i,
                        startTimestamp: n,
                        endTimestamp: r
                    },
                    s = {
                        category: "fetch",
                        data: a,
                        type: "http",
                        level: rh(a.status_code)
                    };
                e.emit("beforeOutgoingRequestBreadcrumb", s, o), xm(s, o);
            }
    };
}

function S_(e) {
    return function(t) {
        if (ad() !== e) return;
        let n = t.from,
            r = t.to,
            i = gm(U.location.href),
            a = n ? gm(n) : void 0,
            o = gm(r);
        a ? .path || (a = i), i.protocol === o.protocol && i.host === o.host && (r = o.relative), i.protocol === a.protocol && i.host === a.host && (n = a.relative), xm({
            category: "navigation",
            data: {
                from: n,
                to: r
            }
        });
    };
}

function C_(e) {
    return !!e && !!e.target;
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/integrations/browserapierrors.js
var w_ = /* @__PURE__ */ "EventTarget.Window.Node.ApplicationCache.AudioTrackList.BroadcastChannel.ChannelMergerNode.CryptoOperation.EventSource.FileReader.HTMLUnknownElement.IDBDatabase.IDBRequest.IDBTransaction.KeyOperation.MediaController.MessagePort.ModalWindow.Notification.SVGElementInstance.Screen.SharedWorker.TextTrack.TextTrackCue.TextTrackList.WebSocket.WebSocketWorker.Worker.XMLHttpRequest.XMLHttpRequestEventTarget.XMLHttpRequestUpload".split("."),
    T_ = "BrowserApiErrors",
    E_ = Cp(((e = {}) => {
        let t = {
            XMLHttpRequest: !0,
            eventTarget: !0,
            requestAnimationFrame: !0,
            setInterval: !0,
            setTimeout: !0,
            unregisterOriginalCallbacks: !1,
            ...e
        };
        return {
            name: T_,
            setupOnce() {
                t.setTimeout && ru(U, "setTimeout", D_), t.setInterval && ru(U, "setInterval", D_), t.requestAnimationFrame && ru(U, "requestAnimationFrame", O_), t.XMLHttpRequest && "XMLHttpRequest" in U && ru(XMLHttpRequest.prototype, "send", k_);
                let e = t.eventTarget;
                e && (Array.isArray(e) ? e : w_).forEach((e) => A_(e, t));
            }
        };
    }));

function D_(e) {
    return function(...t) {
        let n = t[0];
        return t[0] = vh(n, {
            mechanism: {
                handled: !1,
                type: `auto.browser.browserapierrors.${yl(e)}`
            }
        }), e.apply(this, t);
    };
}

function O_(e) {
    return function(t) {
        return e.apply(this, [vh(t, {
            mechanism: {
                data: {
                    handler: yl(e)
                },
                handled: !1,
                type: "auto.browser.browserapierrors.requestAnimationFrame"
            }
        })]);
    };
}

function k_(e) {
    return function(...t) {
        let n = this;
        return [
            "onload",
            "onerror",
            "onprogress",
            "onreadystatechange"
        ].forEach((e) => {
            e in n && typeof n[e] == "function" && ru(n, e, function(t) {
                let n = {
                        mechanism: {
                            data: {
                                handler: yl(t)
                            },
                            handled: !1,
                            type: `auto.browser.browserapierrors.xhr.${e}`
                        }
                    },
                    r = ou(t);
                return r && (n.mechanism.data.handler = yl(r)), vh(t, n);
            });
        }), e.apply(this, t);
    };
}

function A_(e, t) {
    let n = U[e] ? .prototype;
    n ? .hasOwnProperty ? .("addEventListener") && (ru(n, "addEventListener", function(n) {
        return function(r, i, a) {
            try {
                j_(i) && (i.handleEvent = vh(i.handleEvent, {
                    mechanism: {
                        data: {
                            handler: yl(i),
                            target: e
                        },
                        handled: !1,
                        type: "auto.browser.browserapierrors.handleEvent"
                    }
                }));
            } catch {}
            return t.unregisterOriginalCallbacks && M_(this, r, i), n.apply(this, [
                r,
                vh(i, {
                    mechanism: {
                        data: {
                            handler: yl(i),
                            target: e
                        },
                        handled: !1,
                        type: "auto.browser.browserapierrors.addEventListener"
                    }
                }),
                a
            ]);
        };
    }), ru(n, "removeEventListener", function(e) {
        return function(t, n, r) {
            try {
                let i = n.__sentry_wrapped__;
                i && e.call(this, t, i, r);
            } catch {}
            return e.call(this, t, n, r);
        };
    }));
}

function j_(e) {
    return typeof e.handleEvent == "function";
}

function M_(e, t, n) {
    e && typeof e == "object" && "removeEventListener" in e && typeof e.removeEventListener == "function" && e.removeEventListener(t, n);
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/integrations/browsersession.js
var N_ = Cp(() => ({
        name: "BrowserSession",
        setupOnce() {
            if (U.document === void 0) {
                t_ && H.warn("Using the `browserSessionIntegration` in non-browser environments is not supported.");
                return;
            }
            cp({
                ignoreDuration: !0
            }), dp(), Ug(({
                from: e,
                to: t
            }) => {
                e !== void 0 && e !== t && (cp({
                    ignoreDuration: !0
                }), dp());
            });
        }
    })),
    P_ = "GlobalHandlers",
    F_ = Cp(((e = {}) => {
        let t = {
            onerror: !0,
            onunhandledrejection: !0,
            ...e
        };
        return {
            name: P_,
            setupOnce() {
                Error.stackTraceLimit = 50;
            },
            setup(e) {
                t.onerror && (I_(e), V_("onerror")), t.onunhandledrejection && (L_(e), V_("onunhandledrejection"));
            }
        };
    }));

function I_(e) {
    Ol((t) => {
        let {
            stackParser: n,
            attachStacktrace: r
        } = H_();
        if (ad() !== e || gh()) return;
        let {
            msg: i,
            url: a,
            line: o,
            column: s,
            error: c
        } = t, l = B_(Mh(n, c || i, void 0, r, !1), a, o, s);
        l.level = "error", op(l, {
            originalException: c,
            mechanism: {
                handled: !1,
                type: "auto.browser.global_handlers.onerror"
            }
        });
    });
}

function L_(e) {
    jl((t) => {
        let {
            stackParser: n,
            attachStacktrace: r
        } = H_();
        if (ad() !== e || gh()) return;
        let i = R_(t),
            a = Vl(i) ? z_(i) : Mh(n, i, void 0, r, !0);
        a.level = "error", op(a, {
            originalException: i,
            mechanism: {
                handled: !1,
                type: "auto.browser.global_handlers.onunhandledrejection"
            }
        });
    });
}

function R_(e) {
    if (Vl(e)) return e;
    try {
        if ("reason" in e) return e.reason;
        if ("detail" in e && "reason" in e.detail) return e.detail.reason;
    } catch {}
    return e;
}

function z_(e) {
    return {
        exception: {
            values: [{
                type: "UnhandledRejection",
                value: `Non-Error promise rejection captured with value: ${String(e)}`
            }]
        }
    };
}

function B_(e, t, n, r) {
    let i = e.exception = e.exception || {},
        a = i.values = i.values || [],
        o = a[0] = a[0] || {},
        s = o.stacktrace = o.stacktrace || {},
        c = s.frames = s.frames || [],
        l = r,
        u = n,
        d = U_(t) ? ? tu();
    return c.length === 0 && c.push({
        colno: l,
        filename: d,
        function: "?",
        in_app: !0,
        lineno: u
    }), e;
}

function V_(e) {
    t_ && H.log(`Global Handler attached: ${e}`);
}

function H_() {
    return ad() ? .getOptions() || {
        stackParser: () => [],
        attachStacktrace: !1
    };
}

function U_(e) {
    if (!(!zl(e) || e.length === 0)) return e.startsWith("data:") ? `<${_m(e, !1)}>` : e;
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/integrations/httpcontext.js
var W_ = Cp(() => ({
        name: "HttpContext",
        preprocessEvent(e) {
            if (!U.navigator && !U.location && !U.document) return;
            let t = yh(),
                n = {
                    ...t.headers,
                    ...e.request ? .headers
                };
            e.request = {
                ...t,
                ...e.request,
                headers: n
            };
        }
    })),
    G_ = "cause",
    K_ = 5,
    q_ = "LinkedErrors",
    J_ = Cp(((e = {}) => {
        let t = e.limit || K_,
            n = e.key || G_;
        return {
            name: q_,
            preprocessEvent(e, r, i) {
                zm(bh, i.getOptions().stackParser, n, t, e, r);
            }
        };
    }));
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/utils/detectBrowserExtension.js
function Y_() {
    return X_() ? (t_ && nl(() => {
        console.error("[Sentry] You cannot use Sentry.init() in a browser extension, see: https://docs.sentry.io/platforms/javascript/best-practices/browser-extensions/");
    }), !0) : !1;
}

function X_() {
    if (U.window === void 0) return !1;
    let e = U;
    if (e.nw || !(e.chrome || e.browser) ? .runtime ? .id) return !1;
    let t = tu();
    return !(U === U.top && [
        "chrome-extension",
        "moz-extension",
        "ms-browser-extension",
        "safari-web-extension"
    ].some((e) => t.startsWith(`${e}://`)));
}
//#endregion
//#region ../../node_modules/@sentry/browser/build/npm/esm/prod/sdk.js
function Z_(e) {
    return [
        km(),
        Tm(),
        nh(),
        E_(),
        g_(),
        F_(),
        J_(),
        Jm(),
        W_(),
        N_()
    ];
}

function Q_(e = {}) {
    let t = !e.skipBrowserExtensionCheck && Y_(),
        n = e.defaultIntegrations == null ? Z_() : e.defaultIntegrations;
    return mm(Lh, {
        ...e,
        enabled: t ? !1 : e.enabled,
        stackParser: hl(e.stackParser || f_),
        integrations: yp({
            integrations: e.integrations,
            defaultIntegrations: n
        }),
        transport: e.transport || e_
    });
}
//#endregion
//#region ../../shared/utils/src/clusters.ts
var $_ = new Set([
    "ada.support",
    "us2.ada.support",
    "eu.ada.support",
    "maple.ada.support",
    "ada-dev.support",
    "ada-dev2.support",
    "ada-stage.support",
    "dev2-ada.support",
    "localhost"
]);
new Set([...$_].filter((e) => e.split(".").length === 2));
//#endregion
//#region ../../shared/utils/src/url.ts
var ev = new Set([
        "localhost",
        "127.0.0.1",
        "[::1]",
        "::1"
    ]),
    tv = ["messaging-assets.net", "messaging-demo.net"],
    nv = new Set([
        "http",
        "https",
        "ftp",
        "ftps",
        "mailto",
        "tel",
        "sms",
        "callto",
        "cid",
        "xmpp"
    ]),
    rv = new Set([
        "javascript",
        "data",
        "vbscript",
        "about",
        "blob",
        "file",
        "filesystem"
    ]),
    iv = /^[A-Za-z0-9._+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/,
    av = 254,
    ov = RegExp("•|%E2%80%A2", "gi");

function sv(e, t) {
    let n = e.replace(ov, "a");
    if (n === e) return !1;
    if (t.hostname === "") return !0;
    try {
        return new URL(n).hostname !== t.hostname;
    } catch {
        return !0;
    }
}

function cv(e) {
    return e.endsWith("/") ? e : `${e}/`;
}

function lv(e) {
    return e.trim().toLowerCase().replace(/:$/, "");
}

function uv(e, t) {
    try {
        let n = new URL(e);
        if (n.username || n.password || sv(e, n)) return !1;
        let r = lv(n.protocol);
        if (rv.has(r)) return !1;
        let i = new Set(t.map(lv).filter(Boolean));
        return nv.has(r) || i.has(r);
    } catch {
        return !1;
    }
}

function dv(e, t = []) {
    if (typeof e != "string") return null;
    let n = e.trim();
    if (!n) return null;
    let r = n.length <= av && iv.test(n) ? `mailto:${n}` : n;
    return uv(r, t) ? r : null;
}

function fv(e, t = []) {
    return typeof e == "string" && e.trim() !== "" && uv(e, t);
}

function pv(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    if (!t) return null;
    try {
        let e = new URL(t);
        if (e.username || e.password || sv(t, e)) return null;
        let n = e.protocol === "https:",
            r = e.protocol === "http:" && mv(e.hostname);
        return n || r ? e.toString() : null;
    } catch {
        return null;
    }
}

function mv(e, t = {}) {
    let n = e.trim().toLowerCase();
    return n ? ev.has(n) || n.endsWith(".localhost") ? !0 : t.additionalHosts ? t.additionalHosts.some((e) => e.trim().toLowerCase() === n) : !1 : !1;
}

function hv(e, t) {
    let n = e.trim();
    if (!n) return null;
    if (n.startsWith("/")) {
        if (n.startsWith("//")) return null;
        try {
            let e = new URL(n, t);
            return e.search || e.hash || e.username || e.password ? null : cv(e.pathname);
        } catch {
            return null;
        }
    }
    try {
        let e = new URL(n);
        if (e.origin === "null" || e.search || e.hash || e.username || e.password) return null;
        let r = e.protocol === "https:",
            i = e.protocol === "http:" && mv(e.hostname),
            a = e.protocol === "http:" && e.origin === t;
        return !r && !i && !a ? null : cv(e.toString());
    } catch {
        return null;
    }
}
var gv = new Set([...$_].filter((e) => e !== "localhost").map((e) => e.split(".").slice(-2).join(".")));

function _v(e) {
    let t;
    try {
        t = new URL(e);
    } catch {
        return !1;
    }
    let n = t.hostname;
    for (let e of gv)
        if (n === e || n.endsWith(`.${e}`)) return !0;
    return !1;
}

function vv(e, t = {}) {
    if (typeof e != "string") return;
    let n = e.trim();
    if (!n) return;
    let r;
    try {
        r = new URL(n);
    } catch {
        return;
    }
    let i = r.protocol === "https:",
        a = r.protocol === "http:" && mv(r.hostname);
    if (!i && !a || r.origin === "null" || r.username !== "" || r.password !== "" || _v(r.origin)) return;
    let o = t.currentOrigin ? Dv(t.currentOrigin) : null;
    if (!(o && r.origin === o)) return r.toString();
}
var yv = "origin",
    bv = "allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads",
    xv = "local-network-access; loopback-network";

function Sv(e) {
    try {
        return mv(new URL(e).hostname);
    } catch {
        return !1;
    }
}
var Cv = /^(\*\.)?([a-z0-9-]+\.)*[a-z0-9-]+(:(\d{1,5}|\*))?$/;

function wv(e) {
    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function Tv(e) {
    if (typeof e != "string") return null;
    let t = e.trim().toLowerCase();
    if (!t) return null;
    t.includes("://") || (t = `https://${t}`);
    let n = t.indexOf("://"),
        r = t.slice(0, n);
    if (r !== "https" && r !== "http") return null;
    let i = t.slice(n + 3),
        a = i.search(/[/?#]/);
    if (a !== -1 && i.slice(a) !== "/") return null;
    let o = a === -1 ? i : i.slice(0, a);
    return Cv.test(o) ? `${r}://${o}` : null;
}

function Ev(e, t) {
    let n = Dv(t);
    return n === null ? !1 : e.some((e) => {
        let t = Tv(e);
        if (t === null) return !1;
        let r = wv(t).replace(/:\\\*/g, "(?::[0-9]+)?").replace(/\\\*/g, "[^/?#]*");
        return RegExp(`^${r}$`).test(n);
    });
}

function Dv(e, t = {}) {
    if (!e) return null;
    let n = e.trim();
    if (!n) return null;
    try {
        let e = t.baseUrl ? .trim() ? new URL(n, t.baseUrl) : new URL(n);
        return e.origin === "null" || e.protocol !== "http:" && e.protocol !== "https:" ? null : e.origin;
    } catch {
        return null;
    }
}

function Ov(e) {
    return e === "file://" || e === "null" ? e : Dv(e);
}

function kv(e) {
    return e === "file://" || e === "null" ? "*" : e;
}
//#endregion
//#region ../../shared/utils/src/webview-privilege.ts
var Av = new Set([
        "messaging-assets.ada.support",
        "static.ada.support",
        "messaging-assets.ada-dev2.support"
    ]),
    jv = "10.0.2.2";

function Mv(e) {
    try {
        if (!e) return !1;
        let t = e.protocol.toLowerCase(),
            n = e.hostname.toLowerCase();
        return e.pathname.toLowerCase().endsWith("/sdk/webview.html") ? t === "https:" && Av.has(n) ? !0 : t !== "https:" && t !== "http:" ? !1 : mv(n, {
            additionalHosts: [...tv, jv]
        }) : !1;
    } catch {
        return !1;
    }
}
//#endregion
//#region ../../shared/utils/src/android-webview.ts
function Nv(e, t, n) {
    if (t !== !0) return null;
    try {
        let t = new URL(n),
            r = new URL(e, t);
        return r.protocol !== "https:" && r.protocol !== "http:" || r.origin === t.origin || Av.has(r.hostname) ? null : dv(e.startsWith("//") ? `${t.protocol}${e}` : e) ? r.href : null;
    } catch {
        return null;
    }
}
var Pv = /\b(?:Firefox|SamsungBrowser|EdgA|OPR|Opera|Opera Mini|UCBrowser|MQQBrowser|QQBrowser|MiuiBrowser|HuaweiBrowser|YaBrowser|Quark|DuckDuckGo)\/\d/;

function Fv(e) {
    return /\bAndroid\b/.test(e) ? /; wv\)/.test(e) ? !0 : Pv.test(e) ? !1 : /\bVersion\/\d+(\.\d+)* Chrome\//.test(e) ? !0 : !/\bChrome\/\d/.test(e) : !1;
}
//#endregion
//#region ../../shared/utils/src/guards.ts
var Iv = Object.prototype.hasOwnProperty;

function W(e) {
    return typeof e == "object" && e ? e : null;
}

function G(e, t = {}) {
    return typeof e != "string" || !e.trim() ? null : t.trimOutput === !1 ? e : e.trim();
}

function Lv(e) {
    return typeof e == "boolean" ? e : null;
}

function Rv(e) {
    return typeof e == "number" && Number.isFinite(e) ? e : null;
}

function zv(e, t) {
    return Iv.call(e, t);
}
//#endregion
//#region ../../shared/utils/src/chat-availability.ts
function Bv(e) {
    return Lv(e.chat_enabled ? ? e.chatEnabled ? ? W(e.chat) ? .enabled ? ? e.chat);
}
var Vv = new Set(["live_chat"]);

function Hv(e) {
    return Vv.has(e);
}
var Uv = new Set([
    "NUMERIC",
    "NUMERIC_TEN",
    "THUMBS",
    "EMOJI"
]);

function Wv(e) {
    return e ? .style === "NUMERIC_TEN" ? e.score / 2 : e ? .style === "THUMBS" ? e.score * 4 + 1 : e ? .score;
}

function Gv(e, t) {
    if (!Number.isInteger(t)) return !1;
    switch (e) {
        case "NUMERIC":
        case "EMOJI":
            return t >= 1 && t <= 5;
        case "NUMERIC_TEN":
            return t >= 1 && t <= 10;
        case "THUMBS":
            return t === 0 || t === 1;
    }
}

function Kv(e, t) {
    if (!Number.isInteger(e) || typeof t != "string" || !t.trim()) return null;
    let n = t.trim();
    if (Uv.has(n)) {
        let t = n;
        return Gv(t, e) ? {
            score: e,
            style: t
        } : null;
    }
    switch (n.toLowerCase()) {
        case "1-5":
            return Gv("NUMERIC", e) ? {
                score: e,
                style: "NUMERIC"
            } : null;
        case "1-10":
            return Gv("NUMERIC_TEN", e) ? {
                score: e,
                style: "NUMERIC_TEN"
            } : null;
        case "emoji":
            return Gv("EMOJI", e) ? {
                score: e,
                style: "EMOJI"
            } : null;
        case "thumbs":
            return e === 1 ? {
                score: 0,
                style: "THUMBS"
            } : e === 5 ? {
                score: 1,
                style: "THUMBS"
            } : null;
        case "1-7":
        case "0-10":
            return null;
        default:
            return null;
    }
}

function qv(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    if (!t) return null;
    switch (t) {
        case "NUMERIC":
            return "1-5";
        case "NUMERIC_TEN":
            return "1-10";
        case "THUMBS":
            return "thumbs";
        case "EMOJI":
            return "emoji";
        default:
            return t;
    }
}
//#endregion
//#region ../../shared/utils/src/csat-settings.ts
var Jv = [
    "satisfaction",
    "followUpFeedback",
    "resolution",
    "openFeedback",
    "customerEffortScore",
    "netPromoterScore"
];

function Yv(e) {
    if (!e || typeof e != "object" || Array.isArray(e)) return;
    let t = Object.entries(e).filter((e) => typeof e[1] == "string" && e[1].trim().length > 0);
    return t.length > 0 ? Object.fromEntries(t) : void 0;
}

function K(e, t, n = "") {
    if (typeof e == "string") return e;
    let r = Yv(e);
    return r ? r[t] ? ? r.en ? ? n : n;
}

function Xv(e, t) {
    return Array.isArray(e) ? e.map((e) => {
        if (typeof e == "string") return {
            id: e,
            label: e
        };
        if (!e || typeof e != "object" || !("label" in e)) return null;
        let n = e,
            r = G(n.id),
            i = Yv(n.label),
            a = K(n.label, t);
        return !r || !a && !i ? null : {
            id: r,
            label: a,
            ...i ? {
                translations: i
            } : {}
        };
    }).filter((e) => e !== null) : [];
}

function Zv(e) {
    return Array.isArray(e) ? e.filter((e) => typeof e == "string") : [];
}

function Qv(e, t = "en") {
    if (!e || typeof e != "object") return null;
    let n = e,
        r = Zv(n.order),
        i = {
            satisfactionLabel: Yv(n.satisfaction_label),
            followUpFeedbackPositiveLabel: Yv(n.follow_up_feedback_positive_label),
            followUpFeedbackNegativeLabel: Yv(n.follow_up_feedback_negative_label),
            resolutionLabel: Yv(n.resolution_label),
            openFeedbackLabel: Yv(n.open_feedback_label),
            openFeedbackHint: Yv(n.open_feedback_hint),
            customerEffortScoreLabel: Yv(n.customer_effort_score_label),
            netPromoterScoreLabel: Yv(n.net_promoter_score_label)
        };
    return {
        satisfactionIsEnabled: n.satisfaction_is_enabled !== !1,
        satisfactionLabel: K(n.satisfaction_label, t),
        satisfactionRange: typeof n.satisfaction_range == "number" ? n.satisfaction_range : 5,
        satisfactionStyle: qv(G(n.satisfaction_style)) ? ? "emoji",
        followUpFeedbackIsEnabled: n.follow_up_feedback_is_enabled === !0,
        followUpFeedbackPositiveLabel: K(n.follow_up_feedback_positive_label, t),
        followUpFeedbackNegativeLabel: K(n.follow_up_feedback_negative_label, t),
        followUpFeedbackPositiveOptions: Xv(n.follow_up_positive_feedback_options, t),
        followUpFeedbackNegativeOptions: Xv(n.follow_up_negative_feedback_options, t),
        resolutionIsEnabled: n.resolution_is_enabled === !0,
        resolutionLabel: K(n.resolution_label, t),
        openFeedbackIsEnabled: n.open_feedback_is_enabled === !0,
        openFeedbackLabel: K(n.open_feedback_label, t),
        openFeedbackHint: K(n.open_feedback_hint, t),
        customerEffortScoreIsEnabled: n.customer_effort_score_is_enabled === !0,
        customerEffortScoreRange: typeof n.customer_effort_score_range == "number" ? n.customer_effort_score_range : 5,
        customerEffortScoreLabel: K(n.customer_effort_score_label, t),
        netPromoterScoreIsEnabled: n.net_promoter_score_is_enabled === !0,
        netPromoterScoreLabel: K(n.net_promoter_score_label, t),
        order: r.length > 0 ? r : Jv,
        required: Zv(n.required),
        respondToNegativeFeedback: n.respond_to_negative_feedback === !0,
        respondToPositiveFeedback: n.respond_to_positive_feedback === !0,
        anytimeSurveyIsEnabled: n.anytime_survey_is_enabled === !0,
        postChatSurveyIsEnabled: n.post_chat_survey_is_enabled !== !1,
        ...Object.values(i).some(Boolean) ? {
            labelTranslations: i
        } : {}
    };
}

function $v(e, t) {
    if (!e) return null;
    let {
        labelTranslations: n,
        ...r
    } = e;
    return {
        ...r,
        satisfactionLabel: K(n ? .satisfactionLabel, t, e.satisfactionLabel),
        followUpFeedbackPositiveLabel: K(n ? .followUpFeedbackPositiveLabel, t, e.followUpFeedbackPositiveLabel),
        followUpFeedbackNegativeLabel: K(n ? .followUpFeedbackNegativeLabel, t, e.followUpFeedbackNegativeLabel),
        followUpFeedbackPositiveOptions: e.followUpFeedbackPositiveOptions.map(({
            translations: e,
            ...n
        }) => ({
            ...n,
            label: K(e, t, n.label)
        })),
        followUpFeedbackNegativeOptions: e.followUpFeedbackNegativeOptions.map(({
            translations: e,
            ...n
        }) => ({
            ...n,
            label: K(e, t, n.label)
        })),
        resolutionLabel: K(n ? .resolutionLabel, t, e.resolutionLabel),
        openFeedbackLabel: K(n ? .openFeedbackLabel, t, e.openFeedbackLabel),
        openFeedbackHint: K(n ? .openFeedbackHint, t, e.openFeedbackHint ? ? ""),
        customerEffortScoreLabel: K(n ? .customerEffortScoreLabel, t, e.customerEffortScoreLabel ? ? ""),
        netPromoterScoreLabel: K(n ? .netPromoterScoreLabel, t, e.netPromoterScoreLabel ? ? "")
    };
}
//#endregion
//#region ../../shared/utils/src/custom-app-frame-styles.ts
var ey = /^#(?:[\da-f]{3}|[\da-f]{4}|[\da-f]{6}|[\da-f]{8})$/i,
    ty = /^(-?(?:\d+(?:\.\d+)?|\.\d+))px$/,
    ny = /^-?\d+(\.\d+)?%$/,
    ry = {
        borderRadius: [0, 2048],
        borderWidth: [0, 32]
    };

function iy(e, t = !1) {
    if (typeof e == "number") return Number.isFinite(e) && e >= (t ? -4096 : 0) && e <= 4096;
    if (typeof e != "string" || ny.exec(e) ? .[0] !== e) return !1;
    let n = Number(e.slice(0, -1));
    return n >= (t ? -100 : 0) && n <= 100;
}

function ay(e) {
    if (e === "none") return !0;
    let t = e.split(/\s+/);
    t[0] === "inset" && t.shift();
    let n = t.pop();
    return !n || !ey.test(n) || t.length < 2 || t.length > 4 ? !1 : t.every((e, t) => {
        let n = ty.exec(e),
            r = NaN;
        return e === "0" ? r = 0 : n && (r = Number(n[1])), Number.isFinite(r) && Math.abs(r) <= 256 && (t !== 2 || r >= 0);
    });
}

function oy(e) {
    if (typeof e != "object" || !e || Array.isArray(e)) return null;
    let t = Object.getPrototypeOf(e);
    if (t !== Object.prototype && t !== null) return null;
    let n = Reflect.ownKeys(e);
    if (n.length > 15) return null;
    let r = {};
    for (let t of n) {
        if (typeof t != "string") return null;
        let n = Object.getOwnPropertyDescriptor(e, t);
        if (!n || !("value" in n)) return null;
        let i = n.value;
        switch (t) {
            case "top":
            case "right":
            case "bottom":
            case "left":
                if (i !== "auto" && !iy(i, !0)) return null;
                r[t] = i;
                break;
            case "width":
            case "height":
            case "minWidth":
            case "minHeight":
            case "maxWidth":
            case "maxHeight":
                if (!iy(i)) return null;
                r[t] = i;
                break;
            case "borderRadius":
            case "borderWidth":
                {
                    let [e, n] = ry[t];
                    if (typeof i != "number" || !Number.isFinite(i) || i < e || i > n) return null;
                    r[t] = i;
                    break;
                }
            case "backgroundColor":
            case "borderColor":
                if (typeof i != "string" || i !== "transparent" && (i.length > 9 || ey.exec(i) ? .[0] !== i)) return null;
                r[t] = i;
                break;
            case "boxShadow":
                if (typeof i != "string" || i.length > 256 || !ay(i.trim())) return null;
                r.boxShadow = i.trim();
                break;
            default:
                return null;
        }
    }
    return r;
}
var sy = 50 * 1024 * 1024,
    cy = [
        "image/png",
        "image/jpeg",
        "image/gif",
        "image/webp",
        "image/heic",
        "image/heif"
    ];
[
    ...cy,
    ".heic",
    ".heif"
].join(",");
var ly = /^[a-z0-9]{1,8}$/i;

function uy(e) {
    if (typeof e != "string") return null;
    let t = e.trim(),
        n = t.lastIndexOf(".");
    if (n <= 0) return null;
    let r = t.slice(n + 1);
    return ly.test(r) ? r.toUpperCase() : null;
}
//#endregion
//#region ../../shared/utils/src/frame-instance.ts
var dy = "ada-instance-id";

function fy(e) {
    return new URLSearchParams(e).get(dy);
}

function py(e, t) {
    let n = new URL(e.href);
    return t !== null && !n.searchParams.has("ada-instance-id") && n.searchParams.set(dy, t), n;
}
//#endregion
//#region ../../shared/utils/src/host-theme.ts
var my = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

function hy(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    return my.test(t) ? t : null;
}
//#endregion
//#region ../../shared/utils/src/host-branding.ts
var gy = {
        aiAgentName: 100,
        aiAgentDescription: 300,
        "launcher.text": 40
    },
    _y = {
        min: 32,
        max: 120
    },
    vy = new Set([
        "aiAgentName",
        "aiAgentDescription",
        "avatarUrl",
        "tintColor",
        "headerColor",
        "headerTextColor",
        "cornerStyle",
        "textSize",
        "launcher"
    ]),
    yy = new Set([
        "backgroundColor",
        "iconUrl",
        "size",
        "text"
    ]),
    by = /^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$/i;

function xy(e) {
    for (let t of e) {
        let e = t.codePointAt(0) ? ? 0;
        if (e < 32 || e >= 127 && e <= 159) return !0;
    }
    return !1;
}

function Sy(e) {
    return typeof e == "object" && !!e && !Array.isArray(e);
}

function Cy(e, t) {
    if (typeof e != "string" || xy(e)) return null;
    let n = e.trim();
    return !n || n.length > t ? null : n;
}

function wy(e, t) {
    if (!Sy(e)) return null;
    let n = Object.entries(e);
    if (n.length === 0) return null;
    let r = {};
    for (let [e, i] of n) {
        let n = e.trim();
        if (!by.test(n)) return null;
        let a = Cy(i, t);
        if (a === null) return null;
        r[n.toLowerCase()] = a;
    }
    return r;
}

function Ty(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    if (!t) return null;
    try {
        let e = new URL(t);
        return e.protocol !== "https:" || e.username || e.password ? null : e.toString();
    } catch {
        return null;
    }
}

function Ey(e) {
    return typeof e != "number" || !Number.isInteger(e) || e < _y.min || e > _y.max ? null : e;
}

function Dy(e, t, n) {
    let r = {};
    for (let t of Object.keys(e)) yy.has(t) || n.push(`launcher.${t}`);
    if (e.backgroundColor !== void 0) {
        let n = hy(e.backgroundColor);
        n ? r.backgroundColor = n : t.push("launcher.backgroundColor");
    }
    if (e.iconUrl !== void 0) {
        let n = Ty(e.iconUrl);
        n ? r.iconUrl = n : t.push("launcher.iconUrl");
    }
    if (e.size !== void 0) {
        let n = Ey(e.size);
        n === null ? t.push("launcher.size") : r.size = n;
    }
    if (e.text !== void 0) {
        let n = wy(e.text, gy["launcher.text"]);
        n ? r.text = n : t.push("launcher.text");
    }
    return Object.keys(r).length > 0 ? r : void 0;
}

function Oy(e) {
    let t = [],
        n = [];
    if (!Sy(e)) return {
        branding: void 0,
        dropped: t,
        unknown: n
    };
    let r = {};
    for (let t of Object.keys(e)) vy.has(t) || n.push(t);
    if (e.aiAgentName !== void 0) {
        let n = wy(e.aiAgentName, gy.aiAgentName);
        n ? r.aiAgentName = n : t.push("aiAgentName");
    }
    if (e.aiAgentDescription !== void 0) {
        let n = wy(e.aiAgentDescription, gy.aiAgentDescription);
        n ? r.aiAgentDescription = n : t.push("aiAgentDescription");
    }
    if (e.avatarUrl !== void 0) {
        let n = Ty(e.avatarUrl);
        n ? r.avatarUrl = n : t.push("avatarUrl");
    }
    if (e.tintColor !== void 0) {
        let n = hy(e.tintColor);
        n ? r.tintColor = n : t.push("tintColor");
    }
    if (e.headerColor !== void 0) {
        let n = hy(e.headerColor);
        n ? r.headerColor = n : t.push("headerColor");
    }
    if (e.headerTextColor !== void 0) {
        let n = hy(e.headerTextColor);
        n ? r.headerTextColor = n : t.push("headerTextColor");
    }
    if (e.cornerStyle !== void 0 && (e.cornerStyle === "round" || e.cornerStyle === "rectangular" ? r.cornerStyle = e.cornerStyle : t.push("cornerStyle")), e.textSize !== void 0 && (e.textSize === "small" || e.textSize === "default" || e.textSize === "large" ? r.textSize = e.textSize : t.push("textSize")), e.launcher !== void 0)
        if (Sy(e.launcher)) {
            let i = Dy(e.launcher, t, n);
            i && (r.launcher = i);
        } else t.push("launcher");
    return {
        branding: Object.keys(r).length > 0 ? r : void 0,
        dropped: t,
        unknown: n
    };
}

function ky(e, t, n) {
    return Ay(e, t) ? ? Ay(e, n) ? ? null;
}

function Ay(e, t) {
    let n = t.trim().toLowerCase();
    return e && Object.hasOwn(e, n) ? e[n] : void 0;
}

function jy(e, t) {
    return Ay(e, t) !== void 0;
}

function My(e, t) {
    if (!e) return [];
    let n = [];
    return e.aiAgentName && !jy(e.aiAgentName, t) && n.push("aiAgentName"), e.aiAgentDescription && !jy(e.aiAgentDescription, t) && n.push("aiAgentDescription"), e.launcher ? .text && !jy(e.launcher.text, t) && n.push("launcher.text"), n;
}

function Ny(e, t) {
    let n = My(e, t);
    if (n.length === 0) return e;
    let {
        aiAgentName: r,
        aiAgentDescription: i,
        launcher: a,
        ...o
    } = e, s = { ...o
    };
    if (r && !n.includes("aiAgentName") && (s.aiAgentName = r), i && !n.includes("aiAgentDescription") && (s.aiAgentDescription = i), a) {
        let {
            text: e,
            ...t
        } = a, r = { ...t
        };
        e && !n.includes("launcher.text") && (r.text = e), Object.keys(r).length > 0 && (s.launcher = r);
    }
    return s;
}
//#endregion
//#region ../../shared/utils/src/host-callback-error-redaction.ts
var Py = "[redacted: host callback error]",
    Fy = new Set([
        "subscribeEvent",
        "subscribeAll",
        "eventCallbacks",
        "zdChatterAuthCallback",
        "adaReadyCallback",
        "chatterTokenCallback",
        "toggleCallback",
        "adaEmbedLoadedCallback"
    ]),
    Iy = "^[A-Za-z][A-Za-z0-9]{0,40}(?:Error|Exception)$",
    Ly = "^(?:(?:ada[:.]|core\\.)[\\w:.-]{1,60}|LIVE_CHAT_(?:PLATFORM_[A-Z_]{1,40}|QUEUE_POSITION|SEND_TRANSCRIPT))$",
    Ry = "^[\\w:.-]{1,64}$",
    zy = 1024;

function By(e) {
    let t = 14695981039346656037 n;
    for (let n = 0; n < e.length; n += 1) t = BigInt.asUintN(64, (t ^ BigInt(e.charCodeAt(n))) * 1099511628211 n);
    return `custom:${t.toString(16).padStart(16, "0")}`;
}

function Vy(e) {
    return new RegExp(Iy).test(e) ? e : "Error";
}

function Hy(e) {
    return Fy.has(e) ? e : "unknown";
}

function Uy(e, t) {
    return t === "eventCallbacks" ? e === "*" || new RegExp(Ry).test(e) ? e : e.length <= zy && e.trim() ? By(e) : "unknown" : new RegExp(Ly).test(e) ? e : "unknown";
}
//#endregion
//#region ../../shared/utils/src/host-telemetry.ts
function Wy(e) {
    return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}

function Gy(e) {
    if (typeof e == "string") switch (e.trim().toLowerCase()) {
        case "ios":
            return "ios";
        case "android":
            return "android";
        case "react-native":
        case "react_native":
        case "reactnative":
            return "react-native";
        case "web":
            return "web";
        case "unknown":
            return "unknown";
        default:
            return;
    }
}

function Ky(e) {
    if (typeof e == "string") switch (e.trim().toLowerCase()) {
        case "mobile":
            return "mobile";
        case "browser":
            return "browser";
        default:
            return;
    }
}

function qy(e) {
    if (typeof e == "string") switch (e.trim().toLowerCase()) {
        case "legacy":
            return "legacy";
        case "messaging":
            return "messaging";
        default:
            return;
    }
}
var Jy = 100,
    Yy = /^[a-z0-9_-]+$/;

function Xy(e) {
    if (typeof e != "string") return;
    let t = e.trim().toLowerCase();
    if (!(!t || t.length > Jy || !Yy.test(t))) return t;
}

function Zy(e) {
    if (typeof e == "string") switch (e.trim().toLowerCase()) {
        case "messaging_sdk":
        case "messaging-sdk":
            return "messaging-sdk";
        case "legacy_sdk":
        case "legacy-sdk":
            return "legacy-sdk";
        default:
            return;
    }
}
var Qy = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

function $y(e) {
    if (typeof e != "string") return;
    let t = e.trim();
    if (!(t.length > Jy || !Qy.test(t))) return t;
}

function eb(e) {
    return e ? "messaging-sdk" : void 0;
}

function tb(e) {
    let t = Wy(e);
    if (!t) return;
    let n = Ky(t.surface),
        r = Gy(t.hostPlatform),
        i = qy(t.webSdkOrigin),
        a = Xy(t.mobilePackage),
        o = $y(t.mobileVersion);
    if (!n || !r || !i) return;
    let s = eb(a) ? ? Zy(t.mobileShell);
    return {
        surface: n,
        hostPlatform: r,
        webSdkOrigin: i,
        ...s ? {
            mobileShell: s
        } : {},
        ...a ? {
            mobilePackage: a
        } : {},
        ...o ? {
            mobileVersion: o
        } : {},
        ...t.nativeViewVisibilitySupported === !0 ? {
            nativeViewVisibilitySupported: !0
        } : {}
    };
}

function nb(e, {
    defaultOrigin: t,
    defaultSurface: n,
    defaultPlatform: r
}) {
    let i = e,
        a = qy(i ? .webSdkOrigin) ? ? t,
        o = Gy(i ? .hostPlatform) ? ? r ? ? (n === "browser" ? "web" : "unknown"),
        s = Ky(i ? .surface) ? ? (o === "web" ? "browser" : n),
        c = Xy(i ? .mobilePackage),
        l = $y(i ? .mobileVersion),
        u = eb(c) ? ? Zy(i ? .mobileShell);
    return {
        surface: s,
        hostPlatform: o,
        webSdkOrigin: a,
        ...u ? {
            mobileShell: u
        } : {},
        ...c ? {
            mobilePackage: c
        } : {},
        ...l ? {
            mobileVersion: l
        } : {},
        ...i ? .nativeViewVisibilitySupported === !0 ? {
            nativeViewVisibilitySupported: !0
        } : {}
    };
}

function rb(e) {
    return {
        surface: e.surface,
        host_platform: e.hostPlatform,
        web_sdk_origin: e.webSdkOrigin,
        ...e.mobileShell ? {
            mobile_shell: e.mobileShell
        } : {},
        ...e.mobilePackage ? {
            mobile_package: e.mobilePackage
        } : {},
        ...e.mobileVersion ? {
            mobile_version: e.mobileVersion
        } : {}
    };
}
//#endregion
//#region ../../shared/utils/src/languages.ts
var ib = new Set(["zh-tw", "zh-hk"]),
    ab = "zh-tw",
    ob = new Map([
        ["fil", "tl"],
        ["nn", "no"],
        ["nb", "no"],
        ["in", "id"],
        ["zh-hant", "zh-tw"],
        ["zh-hans", "zh"]
    ]),
    sb = /^([a-z]{2}|\d{3})$/;

function cb(e) {
    let t = e.trim().toLowerCase();
    if (ib.has(t)) return ab;
    let n = t.split("-");
    for (; n.length > 1 && sb.test(n[n.length - 1] ? ? "");) n.pop();
    let r = n.join("-");
    return ob.get(r) ? ? r;
}

function lb(e, t) {
    let n = cb(e);
    return n ? t.find((e) => typeof e == "string" && e.trim() !== "" && cb(e) === n) ? ? null : null;
}
//#endregion
//#region ../../shared/utils/src/localization.ts
var ub = 10,
    db = 32,
    fb = /^[a-z0-9-]+$/,
    pb = 8e3,
    mb = new Set(["zh-tw"]);

function hb(e) {
    if (typeof e != "string") return "en";
    let t = e.trim().replaceAll("_", "-").toLowerCase();
    return t === "" || t.length > db || !fb.test(t) ? "en" : t;
}
async function gb(e, t, n) {
    let r = null,
        i = !1,
        a = typeof AbortController < "u" ? new AbortController() : null;
    try {
        let o = (n.fetch ? ? globalThis.fetch)(e, a ? {
                signal: a.signal
            } : void 0),
            s = new Promise((e, o) => {
                r = (n.setTimeout ? ? globalThis.setTimeout)(() => {
                    i = !0, a ? .abort(), o( /* @__PURE__ */ Error(`Request timed out after ${t}ms`));
                }, t);
            });
        return await Promise.race([o, s]);
    } catch (e) {
        throw i ? Error(`Request timed out after ${t}ms`) : e;
    } finally {
        r !== null && (n.clearTimeout ? ? globalThis.clearTimeout)(r);
    }
}

function _b(e, t = {}) {
    let n = /* @__PURE__ */ new Map(),
        r = /* @__PURE__ */ new Map();
    async function i(i) {
        let a = hb(i),
            o = mb.has(a) ? a : a.split("-")[0] ? ? a,
            s = n.get(o);
        if (s) return s;
        let c = r.get(o);
        if (c) return c;
        let l = (async () => {
            let r = new URL(`${o}.json`, e),
                i;
            try {
                i = await gb(r, pb, t);
            } catch (e) {
                let t = e instanceof Error ? e.message : String(e);
                throw Error(`Failed to load locale "${o}": ${t}`);
            }
            if (!i.ok) throw Error(`Failed to load locale "${o}": ${i.status}`);
            let a = await i.json();
            if (n.size >= ub) {
                let e = n.keys().next().value;
                e !== void 0 && n.delete(e);
            }
            return n.set(o, a), a;
        })();
        return r.set(o, l), l.finally(() => r.delete(o)).catch(() => {}), l;
    }

    function a(e) {
        let t = e ? .translations;
        return typeof t != "object" || !t || Array.isArray(t) ? null : t;
    }
    async function o(e) {
        let t = hb(e),
            [n, r] = await Promise.allSettled([i(t), t === "en" ? Promise.resolve(null) : i("en")]),
            o = r.status === "fulfilled" ? a(r.value) : null,
            s = n.status === "fulfilled" ? a(n.value) : null;
        if (!s) {
            if (o) return {
                translations: o,
                language: "en",
                fallbackKeys: []
            };
            throw n.status === "rejected" ? n.reason : Error(`Failed to load locale "${t}": malformed body`);
        }
        if (!o) return {
            translations: s,
            language: t,
            fallbackKeys: []
        };
        let c = { ...o
        };
        for (let [e, t] of Object.entries(s)) t != null && (c[e] = t);
        return {
            translations: c,
            language: t,
            fallbackKeys: Object.keys(o).filter((e) => s[e] == null && o[e] != null)
        };
    }
    async function s(e) {
        return (await o(e)).translations;
    }

    function c() {
        n.clear(), r.clear();
    }
    return {
        loadLocale: i,
        loadTranslations: s,
        loadTranslationsWithLanguage: o,
        clearLocaleCache: c
    };
}
//#endregion
//#region ../../shared/utils/src/monitoring-environment.ts
var vb = {
        "ada-dev.support": "dev",
        "ada-dev2.support": "dev2",
        "ada-stage.support": "stage",
        "ada.support": "production"
    },
    yb = new Map([
        ["ada.support", "production"],
        ["us2.ada.support", "production_us2"],
        ["eu.ada.support", "production_eu"],
        ["maple.ada.support", "production_maple"],
        ["ada-dev.support", "dev"],
        ["ada-dev2.support", "dev2"],
        ["dev2-ada.support", "dev2"],
        ["ada-stage.support", "stage"],
        ["localhost", "local"]
    ]);

function bb(e) {
    let t = e.cluster ? .trim().toLowerCase(),
        n = t ? yb.get(t) : void 0;
    if (n) return n;
    let r = e.hostname.toLowerCase(),
        i = Object.keys(vb).find((e) => r.endsWith(e));
    return i ? vb[i] : "dev";
}
var xb = [
    "Failed to fetch",
    "NetworkError when attempting to fetch resource.",
    "The operation was aborted.",
    "AbortError",
    "Load failed"
];
//#endregion
//#region ../../shared/utils/src/proactive-schedule.ts
function Sb(e, t) {
    let n = Date.now();
    return !(e && !(n >= new Date(e).getTime()) || t && !(n < new Date(t).getTime()));
}
//#endregion
//#region ../../shared/utils/src/runtime-assets.ts
var Cb = /^[0-9a-f]{40}$/i,
    wb = /^pr-\d+$/;

function Tb(e) {
    return e ? Cb.test(e) ? e.toLowerCase() : wb.test(e) ? e : null : null;
}

function Eb(e) {
    return Tb(e.split("/").filter(Boolean).at(-1));
}

function Db(e, t, n, r) {
    let i = Tb(t);
    try {
        let r = new URL(e);
        if (r.protocol === "https:" || r.protocol === "http:") {
            let e = t ? `/${t}/` : "",
                a = e ? r.pathname.indexOf(e) : -1;
            if (a >= 0) return {
                assetsBase: `${r.origin}${r.pathname.slice(0, a + 1)}`,
                buildSha: i
            };
            let o = n.replace(/^\/+/, "");
            if (r.pathname.endsWith(`/${o}`)) {
                let e = r.pathname.slice(0, r.pathname.length - o.length);
                return {
                    assetsBase: `${r.origin}${e}`,
                    buildSha: i ? ? Eb(e)
                };
            }
            return {
                assetsBase: r.origin,
                buildSha: i
            };
        }
    } catch {}
    return {
        assetsBase: r,
        buildSha: i
    };
}
//#endregion
//#region ../../shared/utils/src/sdk-owned-meta-fields.ts
var Ob = [
        "initialURL",
        "introShown",
        "test_user"
    ],
    kb = new Set(Ob);

function Ab(e) {
    return kb.has(e);
}

function jb(e) {
    return e == null ? {} : Object.fromEntries(Object.entries(e).filter(([e]) => !Ab(e)));
}

function Mb(e, t) {
    let n = jb(e);
    for (let e of Ob) Object.hasOwn(t, e) && (n[e] = t[e]);
    return n;
}
var Nb = ["device_token", "device_os"];

function Pb(e, t) {
    let n = { ...e
    };
    if (Object.hasOwn(t, "device_token"))
        for (let e of Nb) delete n[e], Object.hasOwn(t, e) && (n[e] = t[e]);
    return n;
}

function Fb(e, t) {
    let n = {};
    return e && (n.device_token = e, t && (n.device_os = t)), n;
}
var Ib = new Set([
    "REACTNATIVE",
    "REACT-NATIVE",
    "REACT_NATIVE"
]);

function Lb(e) {
    return Ib.has(e);
}

function Rb(e) {
    let t = e ? .sdkType;
    if (typeof t != "string") return "WEB";
    let n = t.trim().toUpperCase();
    return Lb(n) || n === "ANDROID" ? "ANDROID" : n === "IOS" ? "IOS" : n === "" || n === "WEB" ? "WEB" : void 0;
}
//#endregion
//#region ../../shared/utils/src/sdk-startup-timeout.ts
var zb = 35e3,
    Bb = ["frame.load.timeout", "chat.activation.timeout"],
    Vb = [
        "core",
        "button",
        "intro"
    ],
    Hb = 1e3,
    Ub = 5e3;

function Wb(e = {}) {
    let t = e.now ? ? (() => Date.now()),
        n = t(),
        r = n,
        i = () => {
            let e = t();
            return r += Math.max(0, e - n), n = e, r;
        },
        a = e.setTimeout ? ? ((e, t) => setTimeout(e, t)),
        o = e.clearTimeout ? ? ((e) => clearTimeout(e)),
        s = [],
        c = new AbortController(),
        l = /* @__PURE__ */ new Set(),
        u = !1,
        d = !1,
        f = !1,
        p = 0,
        m = "activation",
        h, g;

    function _() {
        let t = !d && (u || l.size > 0);
        t !== f && (f = t, f ? (p = i() + Hb, v(), g = e.subscribeLifecycle ? .(y)) : (h !== void 0 && o(h), h = void 0, g ? .(), g = void 0));
    }

    function v() {
        f && (h !== void 0 && o(h), h = a(() => {
            h = void 0, y(), f && h === void 0 && v();
        }, Math.max(0, p - i())));
    }

    function y(t = "timer") {
        if (!f) return;
        let n = i();
        if (n < p) return;
        let r = n - p;
        if (p = n + Hb, r >= 5e3) {
            let i = {
                gap: r,
                at: n,
                lastStep: m,
                source: t
            };
            s.push(i), e.onSuspension ? .(i);
        }
        v();
    }

    function b(e) {
        return y(), s.reduce((t, {
            at: n,
            gap: r
        }) => t + Math.max(0, n - Math.max(e, n - r)), 0);
    }

    function x(e) {
        return Math.max(0, i() - e - b(e));
    }
    return {
        start() {
            d || (u = !0, _());
        },
        stop() {
            y(), u = !1, _();
        },
        dispose() {
            d = !0, u = !1;
            for (let e of l) e();
            _(), c.abort();
        },
        now: i,
        sample: y,
        setLastStep(e) {
            d || (y(), m = e);
        },
        suspendedMsSince: b,
        activeElapsed: x,
        armActiveDeadline(e, t) {
            if (y(), d) throw Error("Cannot arm a deadline on a disposed startup clock");
            let n = i(),
                r, s = () => {
                    o(r), l.delete(s), _();
                },
                c = () => {
                    if (!l.has(s)) return;
                    let i = e - x(n);
                    if (l.has(s)) {
                        if (i > 0) {
                            r = a(c, i);
                            return;
                        }
                        l.delete(s), _(), t();
                    }
                };
            return l.add(s), _(), r = a(c, e), s;
        },
        signal: c.signal,
        get lastSuspension() {
            return s.at(-1) ? ? null;
        }
    };
}
//#endregion
//#region ../../shared/utils/src/startup-page-lifecycle.ts
function Gb(e, t) {
    return (n) => {
        let r = () => n("visibility"),
            i = () => n("pageshow");
        return e.addEventListener("visibilitychange", r), t.addEventListener("pageshow", i), () => {
            e.removeEventListener("visibilitychange", r), t.removeEventListener("pageshow", i);
        };
    };
}
//#endregion
//#region ../../shared/utils/src/template.ts
function Kb(e, t) {
    let n = -1;
    for (let r = 0; r < e.length; r += 1) {
        let i = e[r];
        if (n === -1) {
            i === "{" && e[r + 1] === "{" && (n = r, r += 1);
            continue;
        }
        if ("\n\r\u2028\u2029".includes(i)) {
            n = -1;
            continue;
        }
        i === "}" && e[r + 1] === "}" && (t({
            end: r + 2,
            key: e.slice(n + 2, r),
            start: n
        }), n = -1, r += 1);
    }
}

function qb(e) {
    let t = [];
    return Kb(e, ({
        key: e
    }) => t.push(e)), t;
}

function Jb(e, t) {
    if (!t) return e;
    let n = [],
        r = 0;
    return Kb(e, (i) => {
        let a = Object.hasOwn(t, i.key) ? t[i.key] : void 0;
        n.push(e.slice(r, i.start), a ? ? e.slice(i.start, i.end)), r = i.end;
    }), n.length === 0 ? e : (n.push(e.slice(r)), n.join(""));
}
//#endregion
//#region ../../shared/utils/src/terminal-presence.ts
var Yb = new Set([
    "conversation_ended",
    "conversation_timeout",
    "chatter_timed_out",
    "chatter_idle_time_out"
]);

function Xb(e) {
    return Yb.has(e);
}
//#endregion
//#region ../../shared/utils/src/url-credential-redaction.ts
var Zb = /\/(chatters\/chat|conversations\/recent\/chat|chatters|logs)\/(?!(?:chat|data_storage|js-event-data)(?:[/?#\s]|$))[^/?#\s]+/g,
    Qb = /([?&][^=&#\s]*=)[^&#\s]*/g,
    $b = /#.*$/,
    ex = /^([a-z][a-z0-9+.-]*:\/\/)[^/?#\s]*@/i,
    tx = /[a-z][a-z0-9+.-]*:\/\/[^\s"'<>]+/gi;

function nx(e) {
    return e.replace($b, "").replace(ex, "$1").replace(Zb, "/$1/redacted").replace(Qb, "$1redacted");
}
var rx = /([?&](?:[^=&#\s"'<>]*(?:token|secret|signature|password|api_?key|key|sig)|code|auth|authorization|credential|jwt)=)[^&#\s"'<>)]*/gi,
    ix = new RegExp(rx.source, "i"),
    ax = /(?::\d+){0,2}\)?$/;

function ox(e) {
    let t = ax.exec(e) ? .[0] ? ? "";
    return ix.test(e.replace("#", "&")) ? t.endsWith(")") ? ")" : "" : t;
}

function sx(e) {
    return e.replace(tx, (e) => {
        let t = ox(e);
        return nx(e.slice(0, e.length - t.length)) + t;
    }).replace(Zb, "/$1/redacted").replace(rx, "$1redacted");
}
var cx = RegExp(`/api${Zb.source}`),
    lx = /[?&#][^=&#\s"'<>]*(?:token|secret|signature|password|api_?key|[_-]key|jwt|credential)=/i;

function ux(e) {
    return cx.test(e) || lx.test(e) || (e.match(tx) ? ? []).some((e) => ex.test(e));
}
var dx = 15e3,
    fx = "zendesk_delivery_unknown",
    px = "cross_tab.fatal";
//#endregion
//#region src/host-telemetry.ts
function mx({
    hostTelemetry: e
}) {
    return nb(e, {
        defaultOrigin: "messaging",
        defaultSurface: "browser",
        defaultPlatform: "web"
    });
}

function hx(e) {
    return rb(e);
}
//#endregion
//#region src/monitoring.ts
var gx = "https://1298932c62ed452b0326604d3b772dc0@o38990.ingest.us.sentry.io/4510980191027200",
    _x = "1605299f-2496-42bc-b996-5e74c3522709",
    vx = "pub4db2d43abbc5e1fa507bef80c7b447ea",
    yx = .01,
    bx = /https:\/\/(?!messaging-assets).+\.ada.*\.support.*/;

function xx(e) {
    if (!bx.test(e)) return !1;
    try {
        let t = new URL(e);
        return !t.pathname.endsWith("/client.json") && t.searchParams.get("ada_request_origin") !== "embed";
    } catch {
        return !1;
    }
}
var Sx = !1,
    Cx = !1,
    wx = null;

function Tx(e) {
    return e.startsWith("production") ? "production" : e;
}

function Ex(e) {
    return [e.message, e.stack].some((e) => e !== void 0 && ux(e));
}
var Dx = new Set([
    "url",
    "from",
    "to"
]);

function Ox(e, t = 0) {
    if (typeof e == "string") return sx(e);
    if (typeof e != "object" || !e) return e;
    if (e instanceof Error) return {
        name: e.name,
        message: sx(e.message),
        stack: e.stack && sx(e.stack)
    };
    if (t >= 5) return "[Object]";
    if (Array.isArray(e)) return e.map((e) => Ox(e, t + 1));
    let n = Object.getPrototypeOf(e);
    return n !== Object.prototype && n !== null ? "[Object]" : Object.fromEntries(Object.entries(e).map(([e, n]) => [e, Ox(n, t + 1)]));
}

function kx(e) {
    for (let t of [e, ...e.causes ? ? []]) t.message && = sx(t.message), t.stack && = sx(t.stack);
}

function Ax(e) {
    if (Sx) return;
    let t = mx({
            hostTelemetry: e.hostTelemetry
        }),
        n = {
            handle: e.handle,
            iframe: !0,
            ...hx(t)
        },
        r = Dv(document.referrer),
        i = r === "https://messaging-demo.net:5040" || r === "https://messaging-demo.ada-dev2.support",
        a = window.location.hostname,
        o = e.cluster ? .trim().toLowerCase() || null,
        s = bb({
            cluster: o,
            hostname: a
        }),
        c = !1;
    Q_({
        dsn: gx,
        environment: Tx(s),
        release: e.version,
        beforeBreadcrumb(e) {
            typeof e.message == "string" && (e.message = sx(e.message));
            let t = e.data;
            if (t)
                for (let [e, n] of Object.entries(t)) t[e] = Dx.has(e) && typeof n == "string" ? nx(n) : Ox(n);
            return e;
        },
        beforeSend(t, n) {
            let a = t.request;
            a ? .url && (a.url = nx(a.url));
            let o = a ? .headers ? .Referer;
            a ? .headers && o && (a.headers.Referer = nx(o)), t.message && = sx(t.message), t.extra && = Ox(t.extra), t.contexts && = Ox(t.contexts);
            for (let e of t.exception ? .values ? ? []) {
                e.value && = sx(e.value);
                for (let t of e.stacktrace ? .frames ? ? []) t.filename && = nx(t.filename), t.abs_path && = nx(t.abs_path);
            }
            if (i && window.parent !== window && r && (window.parent.postMessage({
                    type: "SENTRY_ERROR",
                    event: t
                }, r), e.mode !== "prod")) return null;
            if (t.tags ? .source === "host_callback") return t;
            let s = n.originalException,
                c;
            return c = typeof s == "string" ? s : s instanceof Error ? s.message : "", xb.some((e) => c.includes(e)) ? null : t;
        }
    }), sp("handle", e.handle), sp("domain", a), o && sp("cluster", o), sp("surface", t.surface), sp("host_platform", t.hostPlatform), sp("web_sdk_origin", t.webSdkOrigin), t.mobileShell && sp("mobile_shell", t.mobileShell), t.mobilePackage && sp("mobile_package", t.mobilePackage), t.mobileVersion && sp("mobile_version", t.mobileVersion), c = !0, Jc.init({
        applicationId: _x,
        clientToken: vx,
        site: "datadoghq.com",
        service: "messaging",
        env: s,
        version: e.version,
        sessionSampleRate: 10,
        trackingConsent: "not-granted",
        beforeSend(e) {
            if (e.context = {
                    ...e.context,
                    telemetry_consent: wx
                }, e.view && (e.view.url = nx(e.view.url), e.view.referrer && (e.view.referrer = nx(e.view.referrer))), e.type === "resource") e.resource.url = nx(e.resource.url);
            else if (e.type === "error") {
                if (e.error.causes ? .some(Ex)) return !1;
                kx(e.error), e.error.resource && (e.error.resource.url = nx(e.error.resource.url));
            }
            return !0;
        },
        trackUserInteractions: !0,
        enablePrivacyForActionName: !0,
        sessionReplaySampleRate: 0,
        sessionPersistence: "local-storage",
        usePartitionedCrossSiteSessionCookie: !0,
        allowedTracingUrls: [{
            match: xx,
            propagatorTypes: ["tracecontext"]
        }]
    }), Jc.setGlobalContext(n), rn.init({
        clientToken: vx,
        site: "datadoghq.com",
        service: "messaging",
        env: s,
        version: e.version,
        forwardErrorsToLogs: !0,
        beforeSend(e) {
            return Object.assign(e, n, {
                telemetry_consent: wx
            }), e.view && (e.view.url = nx(e.view.url), e.view.referrer && (e.view.referrer = nx(e.view.referrer))), e.message && = sx(e.message), e.http ? .url && (e.http.url = nx(e.http.url)), e.error && kx(e.error), !(e.origin === "network" && e.http ? .method === "HEAD");
        },
        sessionSampleRate: 100,
        trackingConsent: "not-granted"
    }), rn.setGlobalContext(n), Cx = !0, Math.random() < yx && jx("pre_engagement_sample"), c = !0, c && (Sx = !0);
}

function jx(e) {
    if (!(!Cx || wx)) {
        wx = e;
        try {
            Jc.setTrackingConsent("granted");
        } catch {}
        try {
            rn.setTrackingConsent("granted");
        } catch {}
    }
}

function Mx() {
    return Sx;
}

function Nx(e, t, n) {
    if (!Sx) return;
    let {
        tags: r,
        fingerprint: i
    } = n ? ? {};
    if (!t && !r && !i) {
        ip(e);
        return;
    }
    id((n) => {
        for (let [e, r] of Object.entries(t ? ? {})) n.setExtra(e, r);
        for (let [e, t] of Object.entries(r ? ? {})) n.setTag(e, t);
        i && n.setFingerprint(i), ip(e);
    });
}

function Px(e, t) {
    Sx && ap(e, t);
}

function Fx(e, t, n) {
    Sx && xm({
        category: e,
        message: t,
        data: n
    });
}
var Ix = /* @__PURE__ */ new Set();

function Lx(e) {
    if (!(!Sx || !Array.isArray(e)))
        for (let t of e.slice(0, 2)) {
            if (!t || typeof t != "object") continue;
            let {
                received: e,
                kept: n,
                dropped: r,
                truncatedValues: i = 0,
                sensitive: a
            } = t;
            if (!(![
                    e,
                    n,
                    r,
                    i
                ].every((e) => Number.isSafeInteger(e) && e >= 0) || typeof a != "boolean" || i > n || n + r > e)) try {
                Jc.setGlobalContextProperty(a ? "sensitive_meta_fields" : "meta_fields", {
                    received: e,
                    kept: n,
                    dropped: r,
                    truncatedValues: i
                });
                let t = `${a}:${e}:${n}:${r}:${i}`;
                (r > 0 || i > 0) && !Ix.has(t) && (q("meta_fields_dropped", {
                    received: e,
                    kept: n,
                    dropped: r,
                    truncatedValues: i,
                    sensitive: a
                }), Ix.add(t));
            } catch {}
        }
}

function q(e, t) {
    if (Sx) try {
        Jc.addAction(e, t);
    } catch {}
}

function Rx(e, t, n = "info") {
    if (Sx) try {
        rn.logger.log(e, t, n);
    } catch {}
}
//#endregion
//#region src/persistence/storage.ts
var zx = [
    "normal",
    "session",
    "private"
];

function Bx(e) {
    return /^(greetingLease|chatter|created|sessionToken|messagingAuthState|messagingCreatedClock|inLiveChat|liveChatPending|liveChatRevision|liveChatTransition|zdMessagingExternalUserId|zdMessagingChatterCreated|zdMessagingGeneration)$/.test(e) || /^ada:.*:(session|handoff|read)$/.test(e) || /^ada-zd-(session|previous-tags)-/.test(e);
}

function Vx(e, t) {
    let n = {
        mode: e.mode,
        isNoop: e.isNoop,
        readAcrossModes: e.readAcrossModes,
        get: (t) => e.get(t),
        set: (n, r) => {
            t.handoffKeys().includes(n) && t.handoffWritesAllowed() && e.set(n, r);
        },
        remove: (t) => e.remove(t)
    };
    return e.getWriteResult && (n.getWriteResult = e.getWriteResult), e.flush && (n.flush = e.flush), e.refresh && (n.refresh = e.refresh), e.getConfirmedSync && (n.getConfirmedSync = e.getConfirmedSync), e.getConfirmed && (n.getConfirmed = e.getConfirmed), e.hydrated && (n.hydrated = e.hydrated), e.handshook && (n.handshook = e.handshook), e.hydratedCoherently && (n.hydratedCoherently = e.hydratedCoherently), n;
}

function Hx(e) {
    let t = {
        mode: e,
        isNoop: !0,
        get: () => null,
        set: () => {},
        remove: () => {},
        flush: () => Promise.resolve(!0),
        getConfirmedSync: (t) => ({
            confirmed: e === "private",
            coherent: !0,
            values: Object.fromEntries(t.map((e) => [e, null]))
        })
    };
    if (t.getConfirmed = async (e) => t.getConfirmedSync ? .(e) ? ? {
            confirmed: !1,
            values: {}
        }, e === "private") return {
        ...t,
        mode: "private"
    };
    let n = null;
    try {
        typeof window < "u" && (n = e === "session" ? window.sessionStorage : window.localStorage);
    } catch {}
    if (!n) return t;
    let r = /* @__PURE__ */ new Map(),
        i = (e, t) => {
            try {
                t(), r.set(e, !0);
            } catch {
                r.set(e, !1);
            }
        },
        a = {
            mode: e,
            get: (e) => {
                try {
                    return n.getItem(e);
                } catch {
                    return null;
                }
            },
            getConfirmedSync: (e) => {
                try {
                    return {
                        confirmed: !0,
                        coherent: !0,
                        values: Object.fromEntries(e.map((e) => [e, n.getItem(e)]))
                    };
                } catch {
                    return {
                        confirmed: !1,
                        coherent: !1,
                        values: {}
                    };
                }
            },
            set: (e, t) => {
                i(e, () => n.setItem(e, t));
            },
            remove: (e) => {
                i(e, () => n.removeItem(e));
            },
            getWriteResult: (e) => r.get(e),
            flush: (e) => {
                let t = e ? new Set(e) : new Set(r.keys()),
                    n = !0;
                for (let e of t) r.get(e) === !1 && (n = !1), r.delete(e);
                return Promise.resolve(n);
            }
        };
    return a.getConfirmed = async (e) => a.getConfirmedSync ? .(e) ? ? {
        confirmed: !1,
        values: {}
    }, a;
}
//#endregion
//#region src/persistence/bot-domain-storage.ts
var Ux = lr("bot-domain-storage"),
    Wx = "sdk",
    Gx = "x-storage",
    Kx = 4e3,
    qx = 3e3;

function Jx(e, t) {
    return t <= 0 ? (e.catch(() => void 0), Promise.resolve(void 0)) : new Promise((n) => {
        let r = setTimeout(() => n(void 0), t);
        e.then((e) => {
            clearTimeout(r), n(e);
        }, () => {
            clearTimeout(r), n(void 0);
        });
    });
}

function Yx(e) {
    let t = typeof e == "object" && e ? e : {};
    return {
        key: typeof t.key == "string" ? t.key : null,
        value: typeof t.value == "string" ? t.value : null,
        ok: t.ok === !0
    };
}

function Xx(e) {
    let t = e;
    if (typeof e == "string") try {
        t = JSON.parse(e);
    } catch {
        return null;
    }
    if (typeof t != "object" || !t) return null;
    let n = t;
    if (n.name !== Gx || typeof n.type != "string") return null;
    let r = typeof n.payload == "object" && n.payload !== null ? n.payload : {};
    return {
        type: n.type,
        payload: r,
        id: n.id
    };
}
var Zx = class {
    constructor(e, t = {}) {
        j(this, "post", void 0), j(this, "requestTimeoutMs", void 0), j(this, "pending", /* @__PURE__ */ new Map()), j(this, "requestCounter", 0), j(this, "isReady", !1), j(this, "readyResolvers", []), j(this, "frameOps", /* @__PURE__ */ new Set()), this.post = e, this.requestTimeoutMs = t.requestTimeoutMs ? ? Kx;
    }
    whenReady() {
        return this.isReady ? Promise.resolve() : new Promise((e) => {
            this.readyResolvers.push(e);
        });
    }
    markReady() {
        if (this.isReady) return;
        this.isReady = !0;
        let e = this.readyResolvers;
        this.readyResolvers = [];
        for (let t of e) t();
    }
    configure(e) {
        this.post({
            name: Wx,
            type: "storage.configure",
            payload: {
                mode: e
            }
        });
    }
    async getItem(e) {
        let t = await this.request("storage.get", {
            key: e
        });
        return t.ok ? t.value : null;
    }
    async getItemConfirmed(e) {
        let t = await this.request("storage.get", {
            key: e
        });
        return {
            ok: t.ok,
            value: t.ok ? t.value : null
        };
    }
    supportsOp(e) {
        return this.frameOps.has(e);
    }
    async getItemsConfirmed(e, t) {
        let n = await this.request(t ? "storage.getManyInMode" : "storage.getMany", {
                keys: e,
                ...t ? {
                    mode: t
                } : {}
            }),
            r = n.ok ? n.entries ? ? [] : [],
            i = Object.create(null);
        for (let t of e) i[t] = {
            ok: !1,
            value: null
        };
        for (let e of r) e.key !== null && e.key in i && (i[e.key] = {
            ok: e.ok,
            value: e.ok ? e.value : null
        });
        return i;
    }
    async compareAndWrite(e, t) {
        return (await this.compareAndWriteConfirmed(e, t)).ok;
    }
    async compareAndWriteConfirmed(e, t) {
        if (!this.supportsOp("storage.compareAndWrite")) return {
            ok: !1,
            error: "unsupported"
        };
        let n = await this.request("storage.compareAndWrite", {
            expected: e,
            writes: t
        });
        return {
            ok: n.ok,
            error: n.error
        };
    }
    async setItem(e, t) {
        return (await this.request("storage.set", {
            key: e,
            value: t
        })).ok;
    }
    async removeItem(e) {
        return (await this.request("storage.remove", {
            key: e
        })).ok;
    }
    handleFrameMessage(e) {
        let t = Xx(e);
        if (t) {
            if (t.type === "frame.ready" || t.type === "frame.origin.report") {
                if (Array.isArray(t.payload.ops))
                    for (let e of t.payload.ops) typeof e == "string" && this.frameOps.add(e);
                this.markReady();
                return;
            }
            if (t.type === "frame.error") {
                Ux.warn("bot-domain storage frame reported an error", {
                    key: typeof t.payload.key == "string" ? t.payload.key : null,
                    error: typeof t.payload.error == "string" ? t.payload.error : null
                });
                return;
            }
            if (t.type === "storage.value" || t.type === "storage.values" || t.type === "storage.ack") {
                if (typeof t.id != "string") return;
                let e = this.pending.get(t.id);
                if (!e) return;
                clearTimeout(e.timer), this.pending.delete(t.id);
                let {
                    payload: n
                } = t;
                e.resolve({
                    ...Yx(n),
                    error: typeof n.error == "string" ? n.error : void 0,
                    entries: Array.isArray(n.entries) ? n.entries.map(Yx) : void 0
                });
            }
        }
    }
    destroy() {
        for (let e of this.pending.values()) clearTimeout(e.timer), e.resolve({
            key: null,
            value: null,
            ok: !1,
            error: "destroyed"
        });
        this.pending.clear();
    }
    request(e, t) {
        this.requestCounter += 1;
        let n = `bds-${this.requestCounter}`,
            r = typeof t.key == "string" ? t.key : null;
        return new Promise((i) => {
            let a = setTimeout(() => {
                this.pending.delete(n), i({
                    key: r,
                    value: null,
                    ok: !1,
                    error: "timeout"
                });
            }, this.requestTimeoutMs);
            this.pending.set(n, {
                resolve: i,
                timer: a
            }), this.post({
                name: Wx,
                type: e,
                payload: t,
                id: n
            });
        });
    }
};

function Qx(e) {
    if (!e) return null;
    try {
        let t = new URL(e);
        return t.origin === "null" || t.protocol !== "http:" && t.protocol !== "https:" ? null : t.origin;
    } catch {
        return null;
    }
}

function $x(e) {
    let t = e.doc ? ? document,
        n = t.defaultView ? ? window,
        r = new URL(e.url).origin,
        i = t.createElement("iframe");
    i.src = e.url, i.setAttribute("aria-hidden", "true"), i.setAttribute("tabindex", "-1"), i.setAttribute("title", "Ada storage"), i.setAttribute("sandbox", "allow-scripts allow-same-origin"), i.style.display = "none";
    let a = !1,
        o = [],
        s = new Zx((e) => {
            a ? i.contentWindow ? .postMessage(e, r) : o.push(e);
        }, {
            requestTimeoutMs: e.requestTimeoutMs
        }),
        c = (e) => {
            e.source === i.contentWindow && Qx(e.origin) === r && s.handleFrameMessage(e.data);
        };
    n.addEventListener("message", c);
    let l = () => {
        a = !0, s.configure(e.mode);
        for (let e of o) i.contentWindow ? .postMessage(e, r);
        o.length = 0;
    };
    return i.addEventListener("load", l), t.body.appendChild(i), {
        channel: s,
        destroy: () => {
            n.removeEventListener("message", c), i.removeEventListener("load", l), s.destroy(), i.remove();
        }
    };
}

function eS(e, t, n = {}) {
    if (t === "private") return {
        ...Hx("private"),
        hydrate: () => Promise.resolve(),
        refresh: () => Promise.resolve(!0),
        flush: () => Promise.resolve(!0),
        hydrated: () => !0,
        hydratedCoherently: () => !0
    };
    let r = t === "session" ? "session" : "normal";
    e.configure(r);
    let i = /* @__PURE__ */ new Map(),
        a = /* @__PURE__ */ new Map(),
        o = /* @__PURE__ */ new Map(),
        s = () => ({
            latestVersion: null,
            latestSucceeded: !0,
            pending: /* @__PURE__ */ new Set()
        }),
        c = /* @__PURE__ */ new Map(),
        l = /* @__PURE__ */ new Map(),
        u = n.hydrateKeys ? ? [],
        d = n.readyTimeoutMs ? ? qx,
        f = (e, t, n) => {
            let r = c.get(e);
            r || (r = s(), c.set(e, r));
            let i = n.then((e) => e, () => !1);
            return r.pending.add(i), i.then((e) => {
                e !== null && t > (r.latestVersion ? ? 0) && (r.latestVersion = t, r.latestSucceeded = e), r.pending.delete(i);
            }), i;
        },
        p = (e, t, n) => {
            let r = (o.get(e) ? ? 0) + 1;
            o.set(e, r), i.set(e, t), f(e, r, n).then((n) => {
                n && a.set(e, t), o.get(e) === r && i.set(e, n ? t : a.get(e) ? ? null);
            });
        },
        m = !1,
        h = !1,
        g = /* @__PURE__ */ new Set();
    return {
        mode: t,
        readAcrossModes: async (t) => e.supportsOp("storage.getManyInMode") ? Promise.all(["normal", "session"].map(async (n) => {
            let r = await e.getItemsConfirmed(t, n);
            return {
                mode: n,
                values: Object.fromEntries(Object.entries(r).filter(([, e]) => e.ok).map(([e, t]) => [e, t.value]))
            };
        })) : [],
        get conditionalWritesSupported() {
            return e.supportsOp("storage.compareAndWrite");
        },
        get: (e) => i.has(e) ? i.get(e) ? ? null : null,
        hydrated: (e) => m && (e ? ? u).every((e) => g.has(e)),
        handshook: () => m,
        hydratedCoherently: () => h,
        set: (t, n) => {
            p(t, n, e.setItem(t, n));
        },
        remove: (t) => {
            p(t, null, e.removeItem(t));
        },
        compareAndWrite: async (t, n) => {
            if (!await nS(e, d)) return !1;
            if (!e.supportsOp("storage.compareAndWrite")) {
                let t = Object.entries(n).map(([t, n]) => {
                    let r = n === null ? e.removeItem(t) : e.setItem(t, n);
                    return p(t, n, r), r;
                });
                return Promise.all(t).then((e) => e.every(Boolean));
            }
            let r = /* @__PURE__ */ new Map(),
                s = e.compareAndWriteConfirmed(t, n),
                c = s.then(async (t) => {
                    if (t.error === "rollback-failure") {
                        let t = [...r.keys()],
                            n = e.supportsOp("storage.getMany") ? await e.getItemsConfirmed(t) : await tS(e, t);
                        for (let e of t) {
                            let {
                                ok: t,
                                value: s
                            } = n[e];
                            t ? a.set(e, s) : (a.delete(e), g.delete(e)), o.get(e) === r.get(e) && i.set(e, t ? s : null);
                        }
                    }
                    return t;
                });
            for (let [e, t] of Object.entries(n)) {
                let n = (o.get(e) ? ? 0) + 1;
                o.set(e, n), r.set(e, n), f(e, n, c.then(({
                    ok: e,
                    error: t
                }) => !e && t === void 0 ? null : e)), s.then(({
                    ok: r,
                    error: s
                }) => {
                    s !== "rollback-failure" && (r && a.set(e, t), o.get(e) === n && i.set(e, r ? t : a.get(e) ? ? null));
                }, () => void 0);
            }
            return c.then(({
                ok: e
            }) => e);
        },
        hydrate: async () => {
            if (!await nS(e, d)) return;
            let t = e.supportsOp("storage.getMany"),
                n = t ? await e.getItemsConfirmed(u) : await tS(e, u);
            m = !0, h = t;
            for (let e of u) {
                let {
                    ok: t,
                    value: r
                } = n[e] ? ? {
                    ok: !1,
                    value: null
                };
                t && (g.add(e), a.set(e, r)), i.has(e) || i.set(e, r);
            }
        },
        refresh: async (t) => {
            if (!await nS(e, d)) return !1;
            let n = !0;
            for (let r of t) {
                let {
                    ok: t,
                    value: o
                } = await e.getItemConfirmed(r);
                if (!t) {
                    n = !1;
                    continue;
                }
                o !== null && (i.set(r, o), a.set(r, o));
            }
            return n;
        },
        getConfirmed: async (t) => {
            if (!await nS(e, d)) return {
                confirmed: !1,
                coherent: !1,
                values: {}
            };
            let n = e.supportsOp("storage.getMany"),
                r = n ? await e.getItemsConfirmed(t) : await tS(e, t),
                i = !0,
                a = {};
            for (let e of t) {
                let {
                    ok: t,
                    value: n
                } = r[e] ? ? {
                    ok: !1,
                    value: null
                };
                i && = t, a[e] = t ? n : null;
            }
            return {
                confirmed: i,
                coherent: n,
                values: a
            };
        },
        adoptConfirmedSnapshot: (e) => {
            m = !0;
            for (let [t, n] of Object.entries(e)) i.set(t, n), a.set(t, n), g.add(t);
        },
        flush: (e) => {
            let t = [...e ? new Set(e) : new Set([...c.keys(), ...l.keys()])].map((e) => {
                let t = c.get(e) ? ? s();
                c.delete(e);
                let n = Promise.all([...t.pending]).then(() => t.latestSucceeded),
                    r = l.get(e),
                    i = r ? Promise.all([r, n]).then(([e, n]) => t.latestVersion === null ? e && n : n) : n;
                return l.set(e, i), i.then(() => {
                    l.get(e) === i && l.delete(e);
                }), i;
            });
            return Promise.all(t).then((e) => e.every(Boolean));
        }
    };
}
async function tS(e, t) {
    let n = await Promise.all(t.map(async (t) => [t, await e.getItemConfirmed(t)]));
    return Object.fromEntries(n);
}

function nS(e, t) {
    return new Promise((n) => {
        let r = setTimeout(() => n(!1), t);
        e.whenReady().then(() => {
            clearTimeout(r), n(!0);
        });
    });
}

function rS(e) {
    if (!e) return null;
    try {
        let t = e.endsWith("/") ? e : `${e}/`,
            n = new URL("messaging/storage", t);
        return n.protocol !== "http:" && n.protocol !== "https:" ? null : py(n, fy(window.location.search)).href;
    } catch {
        return null;
    }
}
var iS = null;

function aS(e) {
    iS = !e || e.mode === "private" || e.sharedWritesGuarded ? e : new Proxy(e, {
        get(e, t) {
            if (!(t === "compareAndWrite" || t === "update")) return t === "set" ? (t, n) => Bx(t) ? !1 : e.set(t, n) : t === "remove" ? (t) => Bx(t) ? !1 : e.remove(t) : Reflect.get(e, t);
        }
    });
}

function oS() {
    return iS;
}
async function sS(e) {
    let {
        mode: t,
        endpoint: n,
        hydrateKeys: r,
        clearNormalKeys: i = []
    } = e, a = e.handoffOnly !== !0, o = (e) => a ? (aS(e), {
        storage: e,
        destroy: () => aS(null)
    }) : {
        storage: e,
        destroy: () => {}
    }, s = () => {
        let t = Hx("private");
        return e.signal ? .aborted ? {
            storage: t,
            destroy: () => {}
        } : o(t);
    };
    if (t === "private") return s();
    let c = rS(n);
    if (!c) {
        if (i.length > 0) {
            let {
                ConversationPersistenceService: t
            } = await Promise.resolve().then(() => WM), r = Hx("normal");
            if (!await t.clearStorageKeys(r, {
                    handle: i.find((e) => e.startsWith("ada:")) ? .split(":")[1] ? ? "bootstrap",
                    endpoint: n
                }, i, {
                    signal: e.signal
                })) return s();
        }
        return o(Hx(t));
    }
    let l = $x({
        url: c,
        mode: i.length > 0 ? "normal" : t,
        doc: e.doc,
        requestTimeoutMs: e.requestTimeoutMs
    });
    if (i.length > 0) {
        if (!await nS(l.channel, e.readyTimeoutMs ? ? qx)) return l.destroy(), s();
        let t = eS(l.channel, "normal"),
            {
                ConversationPersistenceService: r
            } = await Promise.resolve().then(() => WM);
        if (!await r.clearStorageKeys(t, {
                handle: i.find((e) => e.startsWith("ada:")) ? .split(":")[1] ? ? "bootstrap",
                endpoint: n
            }, i, {
                signal: e.signal
            })) return l.destroy(), s();
    }
    let u = eS(l.channel, t, {
        hydrateKeys: r,
        readyTimeoutMs: e.readyTimeoutMs
    });
    await u.hydrate();
    let d = () => (l.destroy(), {
        storage: u,
        destroy: () => {}
    });
    if (e.signal ? .aborted) return d();
    let f = (e.degradeUnlessHydrated ? ? []).filter((e) => !u.hydrated([e])),
        p = u.handshook ? .() === !0,
        m = Date.now() + 750,
        h = () => m - Date.now();
    if (f.length > 0 && p) {
        let t = u.getConfirmed ? await Jx(u.getConfirmed(f), Math.min(250, h())) : void 0;
        if (e.signal ? .aborted) return d();
        t ? .confirmed && t.coherent !== !1 && (u.adoptConfirmedSnapshot ? .(t.values), f = []);
    }
    if (f.length > 0) {
        let i = p ? "unconfirmed-keys" : "frame-not-ready",
            {
                keys: a = [],
                facets: o = {}
            } = p ? e.degradeRemovals ? .(u) ? ? {} : {},
            c = "nothing-to-wipe";
        if (e.degradeRemovals && !p) c = "unattempted";
        else if (a.length > 0) {
            let t = h() <= 0 ? void 0 : await Jx(Promise.resolve().then(() => WM).then(({
                ConversationPersistenceService: t
            }) => t.clearStorageKeys(u, {
                handle: r.find((e) => e.startsWith("ada:")) ? .split(":")[1] ? ? "bootstrap",
                endpoint: n
            }, a, {
                signal: e.signal,
                ownedKeysOnly: !0
            })), h());
            if (e.signal ? .aborted) return d();
            c = t === void 0 ? "timed-out" : t ? "acknowledged" : "unacknowledged";
        }
        return Ux.warn("persistence mount degraded to the no-op adapter", {
            reason: i,
            unconfirmedKeys: f,
            wipe: c,
            ...o
        }), q("persistence_handoff_only_degraded", {
            reason: i,
            wipe: c,
            ...o
        }), l.destroy(), {
            ...s(),
            degradedFrom: t
        };
    }
    return a && aS(u), {
        storage: u,
        destroy: () => {
            a && aS(null), l.destroy();
        }
    };
}
//#endregion
//#region ../../../chat/src/shared/services/handoff-clear.js
function cS({
    expected: e,
    shared: t,
    current: n,
    isCurrent: r,
    confirmedEnd: i = !1,
    requireStoredOwner: a = !1,
    preservesHandoff: o = !1
}) {
    return t.confirmed && t.coherent !== !1 && r && (!a || e.chatterToken !== null && t.owners.some((t) => t.chatterToken === e.chatterToken)) && [n, ...t.owners].every((t) => (!t.chatterToken || t.chatterToken === e.chatterToken) && (!t.sessionToken || t.sessionToken === e.sessionToken)) && (o && (!t.inHandoff || n.inHandoff || t.owners.some((t) => !!t.chatterToken && t.chatterToken === e.chatterToken)) || i || !t.inHandoff && !n.inHandoff);
}

function lS(e) {
    return e ? .messagingToken || e ? .sessionRefreshToken ? JSON.stringify([
        e.messagingToken ? ? null,
        e.messagingTokenExpiresAt ? ? null,
        e.sessionRefreshToken ? ? null,
        e.refreshGeneration ? ? null
    ]) : null;
}
//#endregion
//#region src/persistence/handoff-snapshot.ts
function J(e) {
    return {
        chatterToken: e.chatterToken,
        sessionToken: e.sessionToken,
        credential: lS(e)
    };
}

function uS(e) {
    return e !== void 0 && (e.inLiveChat || e.inPending || e.handoffKeys.some((t) => Yo(e.baseline[t] ? ? null)));
}

function dS(e, t) {
    let {
        handle: n,
        endpoint: r,
        cluster: i
    } = e.session, a = [
        es(n ? ? "", r, i),
        L,
        R
    ], o = (e) => Object.fromEntries(e.map((e) => [e, t.get(e)]));
    return {
        session: J(e.session),
        inLiveChat: e.liveAgent.inLiveChat,
        inPending: e.liveAgent.inPending,
        handoffKeys: a,
        baseline: o([
            ...a,
            "liveChatRevision",
            "liveChatTransition",
            "zdMessagingExternalUserId",
            "zdMessagingChatterCreated",
            "zdMessagingGeneration"
        ]),
        credentialBaseline: o([
            Zo(n ? ? "", r, i),
            $o(n ? ? ""),
            Ro,
            P,
            F
        ])
    };
}

function fS(e, t, n) {
    return t.liveAgent.inLiveChat === e.inLiveChat && t.liveAgent.inPending === e.inPending && Object.entries(e.baseline).every(([e, t]) => n[e] === t);
}

function pS(e, t, n, r) {
    let {
        values: i
    } = e, a = i.messagingAuthState ? ? null, o = Bo(a) ? .ownerChatterToken ? ? qo(a), s = o ? Jo(a, o) : null;
    return {
        ...e,
        owners: [{
                kind: "pair",
                chatterToken: I(i.zdMessagingExternalUserId ? ? null),
                sessionToken: I(i.sessionToken ? ? null)
            },
            {
                kind: "legacy_chatter",
                chatterToken: I(i.chatter ? ? null),
                sessionToken: I(i.sessionToken ? ? null)
            },
            ...t.map((e) => {
                let t = r(i[e] ? ? null);
                return {
                    kind: "session",
                    chatterToken: t ? .chatterToken ? ? null,
                    sessionToken: t ? .sessionToken ? ? null,
                    credential: lS(t)
                };
            }),
            {
                kind: "auth",
                chatterToken: s ? .ownerChatterToken ? ? null,
                credential: lS(s)
            }
        ],
        inHandoff: !!(I(i.zdMessagingExternalUserId ? ? null) && I(i.zdMessagingChatterCreated ? ? null)) || n.some((e) => Yo(i[e] ? ? null))
    };
}
//#endregion
//#region src/api/messaging-token.ts
function mS(e) {
    return typeof e == "object" && !!e && "handoff_reason" in e && typeof e.handoff_reason == "string" && [
        "no_chatter",
        "no_active_conversation",
        "not_in_handoff"
    ].includes(e.handoff_reason);
}

function hS(e, t) {
    return e === 410 && typeof t == "object" && !!t && "error_code" in t && t.error_code === "exchange_disabled";
}
var gS = new Set([
    "not_configured",
    "missing_credentials",
    "invalid_session_cookie",
    "untrusted_session_cookie_origin",
    "messaging_auth_unavailable",
    "invalid_session",
    "chatter_token_mismatch",
    "expired_session",
    "invalid_refresh_token",
    "refresh_issuance_conflict"
]);

function _S(e) {
    if (typeof e != "object" || !e) return;
    let t = e.message;
    return typeof t == "string" && gS.has(t) ? t : void 0;
}

function vS(e, t = {}) {
    if (typeof e != "object" || !e) return null;
    let {
        defaultExpiresIn: n = 1800,
        missingSessionRefreshToken: r = "leave",
        requireSessionRefreshToken: i = !1
    } = t, a = "data" in e ? e.data : e;
    if (!a || typeof a != "object") return null;
    let o;
    if (o = typeof a.messaging_token == "string" ? a.messaging_token : typeof a.messagingToken == "string" ? a.messagingToken : null, !o) return null;
    let s;
    if (s = typeof a.expires_in == "number" ? a.expires_in : typeof a.expiresIn == "number" ? a.expiresIn : n, !Number.isFinite(s) || s <= 0) return null;
    let c;
    zv(a, "session_refresh_token") ? c = typeof a.session_refresh_token == "string" ? a.session_refresh_token : null : zv(a, "sessionRefreshToken") ? c = typeof a.sessionRefreshToken == "string" ? a.sessionRefreshToken : null : r === "clear" && (c = null);
    let l;
    if (l = typeof a.refresh_generation == "number" ? a.refresh_generation : typeof a.refreshGeneration == "number" ? a.refreshGeneration : void 0, i && !c || c === "" || c && l === void 0 || l !== void 0 && (!Number.isInteger(l) || l < 1 || !c)) return i ? null : {
        messagingToken: o,
        expiresIn: s
    };
    let u = a.session_cookie_set === void 0 ? a.sessionCookieIssued : a.session_cookie_set;
    return {
        messagingToken: o,
        expiresIn: s,
        ...typeof u == "boolean" ? {
            sessionCookieIssued: u
        } : {},
        ...c === void 0 ? {} : {
            sessionRefreshToken: c
        },
        ...l === void 0 ? {} : {
            refreshGeneration: l
        }
    };
}
//#endregion
//#region src/api/cookie-first-refresh.ts
function yS(e, t) {
    return e === 401 && (t === "missing_credentials" || t === "invalid_session_cookie" || t === "chatter_token_mismatch" || t === "invalid_session" || t === "invalid_refresh_token") || e === 403 && t === "untrusted_session_cookie_origin";
}
var bS = class extends Error {
    constructor(e) {
        super(e), j(this, "reason", void 0), this.reason = e;
    }
};
async function xS(e) {
    return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(e))), (e) => e.toString(16).padStart(2, "0")).join("");
}
async function SS(e, t, n, r) {
    if (!n || !globalThis.isSecureContext || !globalThis.crypto ? .subtle) return fetch(e, t);
    let i = new Headers(t.headers),
        a = !!(i.get("Session-Auth") && i.get("Session-Auth-Refresh")),
        o = await xS(i.get("Session-Auth") ? ? ""),
        s = {
            ...t,
            headers: Object.fromEntries(Object.entries(t.headers).filter(([e]) => !["session-auth", "session-auth-refresh"].includes(e.toLowerCase()))),
            credentials: "include",
            body: JSON.stringify({
                ...JSON.parse(String(t.body ? ? "{}")),
                session_id_hash: o
            })
        },
        c = "network_error",
        l;
    try {
        l = await fetch(e, s);
    } catch (e) {
        if (t.signal ? .aborted || !(e instanceof TypeError)) throw e;
    }
    if (l) {
        let e = await l.clone().json().catch(() => null);
        if (l.ok) {
            let t = e ? .data ? ? e,
                n = vS(t),
                r = i.get("Chatter-Token");
            if (n && r && t ? .chatter_token === r && Wo(n.messagingToken, r) && Uo(n.messagingToken) === i.get("Session-Auth")) return l;
            c = "session_mismatch";
        } else if (l.status === 429) c = "rate_limited";
        else {
            let t = _S(e);
            if (yS(l.status, t)) c = t;
            else return l;
        }
    }
    if (t.signal ? .aborted) throw t.signal.reason;
    if (c !== "network_error" && c !== "rate_limited" && r(c), a) return fetch(e, t);
    throw new bS(c);
}
//#endregion
//#region src/api/session-cookie.ts
var CS = 3e3,
    wS = class extends Error {};
async function TS(e, t) {
    let n, r = new Promise((e) => {
        n = () => e(null), t.aborted ? n() : t.addEventListener("abort", n, {
            once: !0
        });
    });
    try {
        return await Promise.race([r, e]);
    } finally {
        t.removeEventListener("abort", n);
    }
}
async function ES(e, t, n, r, i) {
    if (!t) return null;
    let a = dc([n], CS);
    try {
        let n = r && globalThis.crypto ? .subtle ? await xS(r) : void 0,
            o = await Promise.race([fetch(fc(`${e.replace(/\/$/, "")}/auth/tokens/refresh`), {
                method: "POST",
                credentials: "include",
                signal: a.signal,
                headers: {
                    "Content-Type": "application/json",
                    "Chatter-Token": t
                },
                body: JSON.stringify({
                    trigger: "cookie_restore",
                    session_id_hash: n
                })
            }), a.timeoutPromise]);
        if (o.status === 429) throw new wS("Session cookie restore rate limited");
        if (o.status !== 200) {
            if ((o.status === 401 || o.status === 403) && i) {
                let e = _S(await TS(o.json().catch(() => null), a.signal));
                yS(o.status, e) && i(e);
            }
            return null;
        }
        let s = await Promise.race([o.json(), a.timeoutPromise]);
        if (a.signal.aborted) throw Error("Session cookie restore aborted");
        let c = vS(s, {
                requireSessionRefreshToken: !0
            }),
            l = s ? .chatter_token;
        if (!c || typeof l != "string" || !l) return null;
        if (t !== l || !Wo(c.messagingToken, l)) return i ? .("session_mismatch"), null;
        let u = Uo(c.messagingToken);
        return u ? {
            chatterToken: l,
            sessionToken: u,
            ...c
        } : null;
    } finally {
        a.cleanup();
    }
}
async function DS(e, t) {
    let n = dc([t], oc),
        r = fc(`${e.replace(/\/$/, "")}/auth/tokens/reset`);
    try {
        let e = await Promise.race([fetch(r, {
            method: "POST",
            credentials: "include",
            signal: n.signal
        }).catch(async (e) => {
            if (!(e instanceof TypeError) || n.signal.aborted) throw e;
            let t = await fetch(r, {
                method: "POST",
                credentials: "omit",
                signal: n.signal
            });
            if (t.status !== 404) throw e;
            return t;
        }), n.timeoutPromise]);
        if (!e.ok && e.status !== 404) throw Error("Session cookie clear failed");
    } finally {
        n.cleanup();
    }
}
//#endregion
//#region src/api/messaging-auth.ts
var OS = lr("messaging-auth"),
    kS = 6e4,
    AS = "messaging_jwt_auth_failed",
    jS = new Set([
        "missing",
        "expired",
        "invalid"
    ]),
    MS = "expired_before_send",
    NS = "refreshable_jwt_401",
    PS = "expired_before_send",
    FS = "refreshable_jwt_401",
    IS = 1e4,
    LS = new Set([
        "expired_session",
        "invalid_session",
        "chatter_token_mismatch"
    ]),
    RS = null;

function zS(e) {
    RS = e;
}

function BS(e) {
    return Promise.resolve(RS ? .(e)).then((e) => e ? ? "aborted", (e) => (Nx(e, {
        context: "session_terminal_clear_failed"
    }), "unconfirmed"));
}

function VS(e) {
    let t = e.split("?")[0] ? ? e;
    return t.endsWith("/auth/tokens/refresh") || t.endsWith("auth/tokens/refresh");
}

function HS(e, t) {
    if (t.toUpperCase() !== "POST") return !1;
    let n = e.split("?")[0] ? ? e;
    return n.endsWith("/chatters/") || n.endsWith("/chatters") || n.endsWith("chatters/");
}

function US(e, t = Date.now()) {
    return !!(e.messagingToken && e.messagingTokenExpiresAt && e.messagingTokenExpiresAt > t + kS);
}

function WS(e, t) {
    let n = { ...t
    };
    return delete n.Authorization, delete n.authorization, {
        ...n,
        ...e.chatterToken ? {
            "Chatter-Token": e.chatterToken
        } : {},
        ...e.sessionToken ? {
            "Session-Auth": e.sessionToken
        } : {},
        ...e.sessionRefreshToken ? {
            "Session-Auth-Refresh": e.sessionRefreshToken
        } : {}
    };
}
var GS = /* @__PURE__ */ new WeakMap(),
    KS = /* @__PURE__ */ new WeakMap();

function qS(e) {
    return [Ro, Zo(e.handle ? ? "", e.endpoint, e.cluster)];
}

function JS(e, t, n = !t) {
    let r = t ? ? oS() ? ? Hx(e.persistence);
    if (!e.handle || !e.chatterToken || r.mode === "private") return null;
    let i = qS(e),
        a = [{
                mode: r.mode,
                values: Object.fromEntries(i.map((e) => [e, r.get(e)])),
                frame: !!r.refresh
            },
            ...(n ? KS.get(r) ? ? [] : []).map((e) => ({
                ...e,
                frame: !0
            })),
            ...(n ? ["normal", "session"] : []).map((e) => {
                let t = Hx(e);
                return {
                    mode: e,
                    values: Object.fromEntries(i.map((e) => [e, t.get(e)])),
                    frame: !1
                };
            })
        ],
        o = null;
    for (let t of a)
        for (let n of i) {
            let r = Jo(t.values[n], e.chatterToken);
            r && (!o || r.refreshGeneration > o.refreshGeneration) && (o = r, GS.set(r, YS(t.mode, t.frame)));
        }
    return o;
}

function YS(e, t) {
    return t ? e === "session" ? "frame_session" : "frame_local" : e === "session" ? "session_storage" : "local_storage";
}

function XS(e, t, n = e.refreshGeneration) {
    let r = JS(e),
        i = "memory";
    if (!t && r ? .sessionRefreshToken === e.sessionRefreshToken && r) i = GS.get(r) ? ? "memory";
    else if (t && e.sessionToken && e.persistence !== "private" && oS() ? .mode !== "private") {
        let t = [
            oS(),
            Hx("normal"),
            Hx("session")
        ];
        for (let n of t) {
            if (!n || n.mode === "private") continue;
            let t = n.get("sessionToken");
            if (t === e.sessionToken || t === JSON.stringify(e.sessionToken)) {
                i = YS(n.mode, !!n.refresh);
                break;
            }
        }
    }
    return hc("eb157faa62f6aedb4b1659a9563b247e78b9d989", i, n, t);
}

function ZS(e, t = {}, n) {
    let {
        requireUsableToken: r = !0,
        requireSessionRefreshToken: i = !1,
        requireNewerGeneration: a = !1
    } = t, o = JS(e, n);
    if (!o) return null;
    let s = e.refreshGeneration ? ? -1,
        c = o.refreshGeneration ? ? -1,
        l = o.messagingTokenExpiresAt > Date.now() + kS,
        u = c > s,
        d = !e.messagingToken || !r && !e.sessionRefreshToken,
        f = !a && d && c >= s;
    return r && !l || i && !o.sessionRefreshToken || !u && !f ? null : o;
}
async function QS(e, t = oS()) {
    if (!t || t.mode === "private") return;
    let n = qS(e),
        [, r] = await Promise.all([t.refresh ? .(n), t.readAcrossModes ? .(n)]);
    r && KS.set(t, r);
}
async function $S(e, t) {
    await QS(e, t);
    let n = JS(e, t, !0);
    return n ? .sessionRefreshToken ? n : null;
}

function eC(e) {
    if (typeof e != "object" || !e) return null;
    let t = e;
    return t.error_code !== AS || t.refreshable !== !0 ? null : typeof t.reason == "string" && jS.has(t.reason) ? t.reason : null;
}

function tC(e, t) {
    return e !== 401 || typeof t != "object" || !t ? !1 : t.message === "invalid_refresh_token";
}
var nC = (e) => `${e.chatterToken ?? ""}\u0000${e.sessionToken ?? ""}`,
    rC = (e) => `${nC(e)}\u0000${e.refreshGeneration ?? ""}\u0000${e.sessionRefreshToken ?? ""}`,
    iC = (e) => `${nC(e)}\u0000${e.refreshGeneration ?? ""}`,
    aC = /* @__PURE__ */ new WeakMap(),
    oC = /* @__PURE__ */ new WeakMap(),
    sC = /* @__PURE__ */ new WeakSet();

function cC(e, t) {
    aC.set(e.getState, t), e.subscribe && !sC.has(e.getState) && (sC.add(e.getState), e.subscribe(() => {
        let t = oC.get(e.getState),
            n = e.getState().session;
        t && nC(n) !== nC(t) && oC.delete(e.getState);
    }));
}

function lC(e, t = e.getState().session) {
    return globalThis.isSecureContext && !!globalThis.crypto ? .subtle && t.sessionCookieIssued === !0 && (aC.get(e.getState) ? .isEligible(t) ? ? !1);
}

function uC(e, t, n) {
    return US(t) && (n === NS ? (t.refreshGeneration ? ? -1) > (e.refreshGeneration ? ? -1) && t.messagingToken !== e.messagingToken : rC(t) !== rC(e) || t.messagingToken !== e.messagingToken);
}
var Y = (e, t) => {
    let n = t.getState().session,
        r = oC.get(t.getState);
    return r && (r.lifecycleSignal !== _r() || r.lifecycleSignal ? .aborted || !n || nC(n) !== nC(r)) && (oC.delete(t.getState), r = void 0), !!(n && (nC(n) === nC(e) || e.sessionToken === null && r ? .chatterToken === e.chatterToken));
};

function dC(e, t, n = !1) {
    return !n && !VS(e) && !HS(e, t);
}

function fC(e, t = !0) {
    return {
        ...t && US(e) ? {
            Authorization: `Bearer ${e.messagingToken}`
        } : {},
        ...e.chatterToken ? {
            "Chatter-Token": e.chatterToken
        } : {},
        ...e.sessionToken ? {
            "Session-Auth": e.sessionToken
        } : {}
    };
}
async function pC(e, t) {
    let n, r = new Promise((e) => {
        n = () => e(void 0);
        for (let e of t) {
            if (e ? .aborted) {
                n();
                break;
            }
            e ? .addEventListener("abort", n, {
                once: !0
            });
        }
    });
    try {
        return await Promise.race([e, r]);
    } finally {
        for (let e of t) e ? .removeEventListener("abort", n);
    }
}

function mC() {
    let e = /* @__PURE__ */ new WeakMap(),
        t = /* @__PURE__ */ new WeakMap();

    function n(e) {
        let n = t.get(e.getState);
        return n || (n = {
            credentials: gc(),
            sessionPairs: _c(),
            invalidRefreshes: /* @__PURE__ */ new Set(),
            recoveries: /* @__PURE__ */ new Map(),
            activeRecovery: null
        }, t.set(e.getState, n)), n;
    }

    function r(e) {
        return n(e).credentials;
    }

    function i(e) {
        return n(e).sessionPairs;
    }
    let a = /* @__PURE__ */ new Map(),
        o = /* @__PURE__ */ new Map(),
        s = /* @__PURE__ */ new Map(),
        c = /* @__PURE__ */ new Map(),
        l = null,
        u = null,
        d = () => {
            a.clear(), o.clear(), s.clear(), c.clear(), l = null;
        };

    function f() {
        let e = vr();
        return e !== u && (u ? .removeEventListener("abort", d), d(), u = e, u ? .addEventListener("abort", d, {
            once: !0
        })), u ? ? void 0;
    }

    function p(e, t, n, r) {
        t.teardownSignal ? .aborted || !Y(e, t) || s.get(n) !== r || (t.dispatch(Xs({
            token: r.messagingToken,
            expiresIn: Math.max(0, (r.expiresAt - Date.now()) / 1e3),
            sessionRefreshToken: r.sessionRefreshToken,
            refreshGeneration: r.refreshGeneration,
            sessionCookieIssued: r.sessionCookieIssued
        })), s.get(n) === r && s.delete(n));
    }
    async function m({
        endpoint: e,
        headers: t,
        trigger: a,
        session: o,
        api: s,
        cookieFirst: c,
        signal: l,
        timeoutPromise: u,
        source: d,
        triggerReason: f,
        isCurrent: p
    }) {
        let m = (e) => {
                let t = u ? Promise.race([e, u]) : e;
                return d === "rest" ? pC(t, [l]) : t;
            },
            h = `${e}auth/tokens/refresh`,
            g = await m(SS(d === "rest" ? fc(h) : h, {
                method: "POST",
                credentials: "include",
                headers: {
                    "Content-Type": "application/json",
                    ...t
                },
                body: JSON.stringify({
                    trigger: a,
                    ...XS(o)
                }),
                ...l ? {
                    signal: l
                } : {}
            }, c, (e) => s.dispatch(Qs({
                sessionToken: o.sessionToken,
                refreshGeneration: o.refreshGeneration,
                reason: e,
                allowNullStore: !1
            }))));
        if (!g) return null;
        let _ = g.headers.get("content-type") ? .includes("application/json"),
            v;
        v = d === "startup" ? g.json().catch(() => null) : d === "websocket" && !g.ok ? _ ? g.json().catch(() => null) : Promise.resolve(null) : _ ? g.json() : g.text();
        let y = await m(v);
        if (d !== "websocket" && l ? .aborted) return null;
        let b = {
            trigger: a,
            ...d === "rest" ? {
                triggerReason: f
            } : {}
        };
        if (!g.ok) {
            let e = _S(y);
            return q("messaging_jwt_refresh", {
                ...b,
                result: "failed",
                status: g.status,
                reason: e
            }), (d === "rest" ? tC(g.status, y) : g.status === 401 && e === "invalid_refresh_token") ? (d !== "websocket" && n(s).invalidRefreshes.add(iC(o)), r(s).add(o.chatterToken, o, t["Session-Auth"]), "invalid_refresh_token") : g.status === 401 && typeof e == "string" && LS.has(e) ? (e === "chatter_token_mismatch" ? i(s).add(t["Session-Auth"], t["Chatter-Token"], o.refreshGeneration ? ? 0) : r(s).add(o.chatterToken, o, t["Session-Auth"]), "session_dead") : null;
        }
        let x = vS(y, {
                requireSessionRefreshToken: !0
            }),
            S = !!(x && o.chatterToken && Wo(x.messagingToken, o.chatterToken) && (p ? .() ? ? !0));
        return q("messaging_jwt_refresh", {
            ...b,
            result: S ? "success" : "invalid_response"
        }), S ? x : null;
    }
    async function h(e, t, o, c, l, u, d, f = "rest", h) {
        let {
            teardownSignal: g
        } = u, _ = r(u), v = i(u);
        if (g ? .aborted || _.has(l.chatterToken, l, t["Session-Auth"])) return !g ? .aborted && n(u).invalidRefreshes.has(iC(l)) ? "invalid_refresh_token" : null;
        if (v.has(t["Session-Auth"], t["Chatter-Token"], l.refreshGeneration ? ? 0)) return "session_dead";
        let y = s.get(c);
        if (y) return y;
        let b = a.get(c);
        if (b) return b.cookieFirst && h ? .(), b.promise;
        let x = dc([g], oc),
            S, C = lC(u, l);
        return C && h ? .(), S = (async () => {
            try {
                let n = await m({
                    endpoint: e,
                    headers: t,
                    trigger: o,
                    session: l,
                    api: u,
                    triggerReason: d,
                    cookieFirst: C,
                    signal: x.signal,
                    timeoutPromise: x.timeoutPromise,
                    source: f
                });
                if (!n || typeof n == "string") return n;
                let r = {
                    ...n,
                    expiresAt: Date.now() + n.expiresIn * 1e3
                };
                return s.set(c, r), p(l, u, c, r), r;
            } catch (e) {
                return e instanceof bS ? e : (q("messaging_jwt_refresh", {
                    trigger: o,
                    triggerReason: d,
                    result: "error"
                }), null);
            } finally {
                a.get(c) ? .promise === S && a.delete(c), x.cleanup();
            }
        })(), a.set(c, {
            promise: S,
            cookieFirst: C
        }), S;
    }
    async function g(e, t, n, r, i, a, s, l = "no_credential", u) {
        let d = i.chatterToken,
            {
                teardownSignal: f
            } = a;
        if (f ? .aborted) return {
            outcome: "failed"
        };
        let m = c.get(r);
        if (m) return {
            outcome: "success",
            result: m
        };
        let g = o.get(r);
        if (g) return g;
        let _ = dc([f], oc),
            v;
        return v = (async () => {
            try {
                let o;
                if (l !== "credential_rejected" && lC(a, i)) {
                    let c = await h(e, t, n, r, i, a, s);
                    if (c instanceof bS) o = c.reason;
                    else if (c === "session_dead") return {
                        outcome: "terminal"
                    };
                    else if (c === "invalid_refresh_token") return {
                        outcome: "failed",
                        exchanged: !1
                    };
                    else if (c) return p(i, a, r, c), {
                        outcome: "success",
                        result: c,
                        refreshed: !0
                    };
                    else return {
                        outcome: "failed"
                    };
                }
                let f = fc(`${e}auth/tokens/exchange`);
                o && q("messaging_exchange_fallback", {
                    trigger: n,
                    reason: o,
                    sessionCookieIssued: i.sessionCookieIssued === !0,
                    hadStoredCredential: !!i.sessionRefreshToken || l === "credential_rejected"
                });
                let m = async (e) => {
                        let r;
                        try {
                            r = dS(a.getState(), oS() ? ? Hx(i.persistence));
                        } catch (e) {
                            Nx(e, {
                                context: "exchange_handoff_snapshot_failed"
                            });
                        }
                        let o = await pC(Promise.race([fetch(f, {
                            method: "POST",
                            credentials: "include",
                            headers: {
                                "Content-Type": "application/json",
                                ...t,
                                ...e ? {
                                    "Messaging-Issue-Refresh": "true"
                                } : {}
                            },
                            body: JSON.stringify({
                                trigger: n,
                                ...XS(i, l, u ? ? null),
                                client_version: "eb157faa62f6aedb4b1659a9563b247e78b9d989"
                            }),
                            signal: _.signal
                        }), _.timeoutPromise]), [_.signal]);
                        if (!o) return null;
                        let s = await pC(Promise.race([o.headers.get("content-type") ? .includes("application/json") ? o.json() : o.text(), _.timeoutPromise]), [_.signal]);
                        return _.signal.aborted ? null : {
                            response: o,
                            payload: s,
                            handoffSnapshot: r
                        };
                    },
                    g = await m(!0);
                if (!g || g.response.status === 503 && _S(g.payload) === "refresh_issuance_conflict" && (_.signal.aborted || (g = await m(!1), !g)) || _.signal.aborted) return {
                    outcome: "failed"
                };
                let {
                    response: v,
                    payload: b
                } = g;
                if (!v.ok) {
                    if (hS(v.status, b)) {
                        let e = a.getState(),
                            t = uS(g.handoffSnapshot) && mS(b),
                            r = uC(i, e.session) || !t && (e.liveAgent.inLiveChat || e.liveAgent.inPending) ? "failed" : "terminal";
                        return q("messaging_jwt_exchange", {
                            trigger: n,
                            triggerReason: s,
                            result: r,
                            status: v.status,
                            reason: "exchange_disabled",
                            handoffEnded: t
                        }), r === "terminal" && t ? {
                            outcome: r,
                            handoffEnded: g.handoffSnapshot
                        } : {
                            outcome: r
                        };
                    }
                    let e = _S(b),
                        t = (v.status === 401 || v.status === 403) && typeof e == "string" && LS.has(e);
                    return q("messaging_jwt_exchange", {
                        trigger: n,
                        triggerReason: s,
                        result: t ? "terminal" : "failed",
                        status: v.status,
                        reason: e
                    }), {
                        outcome: t ? "terminal" : "failed"
                    };
                }
                let x = vS(b),
                    S = !!(x && d && Wo(x.messagingToken, d) && (l !== "credential_rejected" || !y(i, x, a)));
                if (q("messaging_jwt_exchange", {
                        trigger: n,
                        triggerReason: s,
                        result: S ? "success" : "invalid_response"
                    }), !S || !x) return {
                    outcome: "failed"
                };
                let C = {
                    ...x,
                    expiresAt: Date.now() + x.expiresIn * 1e3
                };
                return c.set(r, C), {
                    outcome: "success",
                    result: C
                };
            } catch {
                return q("messaging_jwt_exchange", {
                    trigger: n,
                    triggerReason: s,
                    result: "error"
                }), {
                    outcome: "failed"
                };
            } finally {
                o.get(r) === v && o.delete(r), _.cleanup();
            }
        })(), o.set(r, v), v;
    }
    async function _(t, n, r, i, a, o, s = "no_credential", u, d) {
        let f = t.endpoint;
        if (!f || !t.sessionToken || !t.chatterToken || t.identitySession) return !1;
        let p = e.get(r.getState),
            m = [
                i,
                r.signal,
                r.teardownSignal
            ],
            h = c.get(rC(t));
        if (await QS(t), !Y(t, r) || m.some((e) => e ? .aborted)) return !1;
        let _ = r.getState().session;
        if (h && h.messagingToken !== t.messagingToken && h.messagingToken === _.messagingToken && US(_) || uC(t, _, a) || v(_, r) && uC(t, r.getState().session, a)) return !0;
        v(_, r, {
            requireUsableToken: !1,
            requireSessionRefreshToken: !0
        });
        let y = r.getState().session;
        if (y.sessionRefreshToken) return C(y, n, r, i, a, o);
        let b = rC(_);
        if (l ? .identity === b && Date.now() < l.until) return !1;
        let x = await pC(g(f, WS(_, n), a, b, _, r, o, s, u), m);
        if (!x || !Y(t, r) || m.some((e) => e ? .aborted)) return !1;
        if (x.outcome === "terminal") {
            l = {
                identity: b,
                until: Date.now() + IS
            };
            let e = await BS({
                chatterToken: t.chatterToken,
                refreshGeneration: t.refreshGeneration,
                sessionAuthDead: !0,
                ...x.handoffEnded ? {
                    handoffEnded: x.handoffEnded
                } : {},
                rejectedSession: J(_),
                staleAuthBaseline: p ? .signal.aborted ? null : p ? .value
            });
            return d && (d.terminalClear = e), !1;
        }
        if (x.outcome !== "success") return x.exchanged !== !1 && (l = {
            identity: b,
            until: Date.now() + IS
        }), !1;
        l = null, x.refreshed || r.dispatch(Zs({
            token: x.result.messagingToken,
            expiresIn: Math.max(0, (x.result.expiresAt - Date.now()) / 1e3),
            sessionRefreshToken: x.result.sessionRefreshToken,
            refreshGeneration: x.result.refreshGeneration,
            sessionCookieIssued: x.result.sessionCookieIssued
        })), c.get(b) === x.result && c.delete(b);
        let S = r.getState().session;
        return S ? US(S) : !1;
    }

    function v(e, t, n = {}) {
        if (!Y(e, t)) return !1;
        let {
            requireUsableToken: i = !0
        } = n, a = ZS(e, n);
        if (!a || r(t).has(e.chatterToken, a, e.sessionToken) || !Y(e, t)) return !1;
        t.dispatch(Xs({
            token: a.messagingToken,
            expiresIn: Math.max(0, Math.round((a.messagingTokenExpiresAt - Date.now()) / 1e3)),
            sessionRefreshToken: a.sessionRefreshToken ? ? e.sessionRefreshToken,
            refreshGeneration: a.refreshGeneration,
            sessionCookieIssued: a.sessionCookieIssued
        }));
        let o = t.getState().session;
        return i ? !!(o && US(o)) : !0;
    }

    function y(e, t, n) {
        let i = r(n);
        return i.has(e.chatterToken, t, e.sessionToken) || i.hasGeneration(e.chatterToken, t.refreshGeneration, e.sessionToken);
    }

    function b(e, t, i, a = MS, o) {
        let s = n(i),
            c = iC(e);
        s.invalidRefreshes.add(c);
        let l = (e) => (OS.error("Rejected-credential recovery failed:", e), s.recoveries.delete(c), "unconfirmed"),
            u = s.recoveries.get(c);
        if (u) return u.then((t) => {
            let n = i.getState().session;
            if (!Y(e, i)) return "aborted";
            let a = r(i).has(n.chatterToken, n, n.sessionToken);
            return n.refreshGeneration === e.refreshGeneration && a ? BS({
                chatterToken: n.chatterToken,
                refreshGeneration: n.refreshGeneration,
                resumeTokenSync: !0
            }) : t === "recovered" && (a || !US(n)) ? "cleared" : t;
        }).catch(l);
        let d = {
                ...i,
                signal: void 0,
                teardownSignal: f()
            },
            p = _r(),
            m = () => Y(e, d) && !p ? .aborted && !d.teardownSignal ? .aborted,
            h = (async () => {
                if (!m()) return "aborted";
                let n = null,
                    r = await BS({
                        chatterToken: e.chatterToken,
                        refreshGeneration: e.refreshGeneration,
                        resumeTokenSync: !0,
                        onSessionTokenResolved: (e) => {
                            n = e;
                        }
                    });
                if (!m()) return "aborted";
                if (r !== "cleared" && r !== "unconfirmed") return r;
                let s = i.getState().session;
                if (r === "unconfirmed" && !s.sessionToken) return r;
                let {
                    endpoint: c,
                    chatterToken: l
                } = e, u = s.hasHydratedClientConfig && (e.sessionCookieIssued !== !0 || s.sessionCookieIssued === !0) && aC.get(i.getState) ? .isEligible(s) === !0 && !!c && !!l;
                if (u) {
                    let t = "rejected_credential",
                        r = (e) => i.dispatch(Qs({
                            sessionToken: s.sessionToken ? ? n,
                            refreshGeneration: s.refreshGeneration,
                            reason: e,
                            allowNullStore: s.sessionToken === null && n !== null
                        }));
                    q("chatter_cookie_restore_attempted", {
                        phase: t
                    });
                    try {
                        let a, o = await ES(c, l, d.teardownSignal ? ? new AbortController().signal, s.sessionToken ? ? n, (e) => {
                                a = e;
                            }),
                            u;
                        if (!m()) return q("chatter_cookie_restore_failed", {
                            phase: t,
                            reason: "superseded"
                        }), "aborted";
                        if (!o) u = a ? ? "rejected_or_unusable", a && r(a);
                        else if (o.sessionToken !== (s.sessionToken ? ? n)) u = "session_mismatch", r(u);
                        else if (o.expiresIn * 1e3 <= kS) u = "expires_soon";
                        else if (y(e, o, i)) u = "rejected_credential";
                        else {
                            let e = i.getState().session,
                                n = await aC.get(i.getState) ? .persist({
                                    ...e,
                                    sessionToken: o.sessionToken
                                }, o, m);
                            if (!m()) return q("chatter_cookie_restore_failed", {
                                phase: t,
                                reason: "superseded"
                            }), "aborted";
                            if (!n) u = "persistence_refused";
                            else {
                                if (e.sessionToken === null && (oC.set(i.getState, {
                                        chatterToken: l,
                                        sessionToken: o.sessionToken,
                                        lifecycleSignal: p
                                    }), i.dispatch(Ss({
                                        sessionToken: o.sessionToken
                                    }))), i.dispatch(Xs({
                                        token: o.messagingToken,
                                        expiresIn: o.expiresIn,
                                        sessionRefreshToken: o.sessionRefreshToken,
                                        refreshGeneration: o.refreshGeneration,
                                        sessionCookieIssued: o.sessionCookieIssued
                                    })), US(i.getState().session)) return q("chatter_cookie_restore_restored", {
                                    phase: t,
                                    durable: n !== "memory"
                                }), "recovered";
                                u = "unusable";
                            }
                        }
                        q("chatter_cookie_restore_failed", {
                            phase: t,
                            reason: u
                        });
                    } catch (e) {
                        let n = e instanceof wS ? "rate_limited" : "network_or_timeout";
                        m() || (n = "superseded"), q("chatter_cookie_restore_failed", {
                            phase: t,
                            reason: n
                        });
                    }
                }
                if (!m()) return "aborted";
                if (r === "unconfirmed") return r;
                u && q("messaging_exchange_fallback", {
                    trigger: a,
                    reason: "cookie_recovery_failed",
                    hadStoredCredential: !0,
                    sessionCookieIssued: e.sessionCookieIssued === !0
                });
                let f = {};
                return await _(i.getState().session, t, d, void 0, a, o, "credential_rejected", e.refreshGeneration, f) ? "recovered" : f.terminalClear ? ? (i.getState().session.chatterToken ? "unconfirmed" : "cleared");
            })().catch(l).then((e) => (s.activeRecovery ? .promise === h && (s.activeRecovery = null), e));
        return s.recoveries.set(c, h), s.activeRecovery = {
            session: e,
            promise: h,
            ownerApi: d
        }, h;
    }

    function x(e, t) {
        let r = n(t).activeRecovery;
        return r && Y(r.session, t) && Y(e, t) ? r : null;
    }

    function S(e, t, n) {
        let r = x(e, t);
        if (!r || r.ownerApi === t) return;
        let i = [
            n,
            t.signal,
            t.teardownSignal
        ];
        return pC(r.promise, i).then(() => {
            let n = t.getState().session;
            return Y(e, t) && !i.some((e) => e ? .aborted) && US(n);
        });
    }
    async function C(e, t, n, r, a, o) {
        let s = e.endpoint;
        if (!s || !e.sessionRefreshToken) return !1;
        let c = [
            r,
            n.signal,
            n.teardownSignal
        ];
        if (await QS(e), !Y(e, n) || c.some((e) => e ? .aborted)) return !1;
        let l = S(e, n, r);
        if (l) return l;
        let u = n.getState().session;
        if (uC(e, u, a) || v(u, n) && uC(e, n.getState().session, a)) return !0;
        if (v(n.getState().session, n, {
                requireUsableToken: !1,
                requireSessionRefreshToken: !0
            }), u = n.getState().session, !u.sessionRefreshToken) return !1;
        let d = rC(u),
            f = (e) => (d = rC(e), pC(h(e.endpoint ? ? s, WS(e, t), a, d, e, n, o), c)),
            m = await f(u);
        if (!Y(e, n) || c.some((e) => e ? .aborted)) return !1;
        let g = u.chatterToken,
            _ = m === "session_dead" ? i(n).getRefreshGeneration(u.sessionToken, u.chatterToken) ? ? u.refreshGeneration : u.refreshGeneration;
        if (m === "invalid_refresh_token") {
            if (await QS(e), !Y(e, n) || c.some((e) => e ? .aborted)) return !1;
            let t = n.getState().session ? ? e;
            if (uC(u, t, a)) return !0;
            let r = v(t, n, {
                    requireUsableToken: !1,
                    requireSessionRefreshToken: !0,
                    requireNewerGeneration: !0
                }),
                o = n.getState().session;
            if (o ? .sessionRefreshToken && (r || (o.refreshGeneration ? ? -1) > (_ ? ? -1)) && (g = o.chatterToken, m = await f(o), _ = m === "session_dead" ? i(n).getRefreshGeneration(o.sessionToken, o.chatterToken) ? ? o.refreshGeneration : o.refreshGeneration, !Y(e, n) || c.some((e) => e ? .aborted))) return !1;
        }
        if (m === "session_dead" || m === "invalid_refresh_token") {
            if (!Y(e, n)) return !1;
            if (m === "invalid_refresh_token") {
                if (await QS(e), !Y(e, n) || c.some((e) => e ? .aborted)) return !1;
                let t = n.getState().session;
                if (v(t, n, {
                        requireUsableToken: !1,
                        requireSessionRefreshToken: !0,
                        requireNewerGeneration: !0
                    }) || (t.refreshGeneration ? ? 0) > (_ ? ? 0)) return US(n.getState().session);
            }
            let r = m === "invalid_refresh_token" ? await pC(b({
                ...e,
                chatterToken: g,
                refreshGeneration: _
            }, t, n, a, o), c) : await BS({
                chatterToken: g,
                refreshGeneration: _,
                resumeTokenSync: !0
            });
            if (r === "recovered") {
                let t = n.getState().session;
                return Y(e, n) && !c.some((e) => e ? .aborted) && US(t);
            }
            if (r === "superseded") {
                if (!Y(e, n)) return !1;
                let t = n.getState().session;
                return !!(t && (a === NS ? uC(e, t, a) : US(t)));
            }
            return !1;
        }
        if (!m || m instanceof bS) return Y(e, n) ? v(n.getState().session ? ? e, n) && uC(e, n.getState().session, a) : !1;
        if (!Y(e, n)) return !1;
        p(e, n, d, m);
        let y = n.getState().session;
        return y ? US(y) : !1;
    }
    async function w(e, t, n, r, i) {
        let a = {
            ...n,
            teardownSignal: f()
        };
        if (a.teardownSignal ? .aborted) return !1;
        let o = S(e, a, r);
        if (o) return o;
        let s;
        if (e.sessionRefreshToken) s = C(e, t, a, r, i ? NS : MS, i);
        else if (e.sessionToken && !e.identitySession) s = _(e, t, a, r, i ? FS : PS, i);
        else return !1;
        return await pC(s, [
            r,
            n.signal,
            a.teardownSignal
        ]) ? ? !1;
    }
    return {
        setLifecycleAuthBaseline(t, n, r) {
            e.set(t.getState, {
                value: n,
                signal: r
            });
        },
        requestMessagingRefresh: m,
        refreshForStartup(e, t, n, r) {
            let i = f();
            return pC(h(e.endpoint ? ? "", WS(e, {
                "X-Ada-Request-Origin": "chat"
            }), n, rC(e), e, {
                ...t,
                teardownSignal: i
            }, void 0, "startup", r), [t.signal, i]);
        },
        rejectedCredentialsFor: r,
        rejectedSessionPairsFor: i,
        recoverRejectedCredential: b,
        waitForCredentialRecovery(e, t) {
            let n = e.getState().session,
                r = x(n, e);
            return r ? pC(r.promise, [
                t,
                e.signal,
                f()
            ]) : void 0;
        },
        async restoreRefreshCredential(e) {
            let t = e.getState().session;
            await QS(t), !e.signal ? .aborted && !e.teardownSignal ? .aborted && v(t, e, {
                requireUsableToken: !1,
                requireSessionRefreshToken: !0
            });
        },
        prepare(e, t, i, a) {
            let o = f();
            if (o ? .aborted) return;
            let l = i.getState().session;
            if (x(e, i) || n(i).invalidRefreshes.has(iC(l)) && r(i).has(l.chatterToken, l, l.sessionToken)) return w(e, t, i, a);
            if (Y(e, i) && r(i).has(l.chatterToken, l, l.sessionToken)) return BS({
                chatterToken: l.chatterToken,
                refreshGeneration: l.refreshGeneration,
                resumeTokenSync: !0
            }).then((n) => n !== "cleared" && n !== "superseded" || !Y(e, i) || a ? .aborted || i.signal ? .aborted || o ? .aborted ? !1 : w(i.getState().session, t, i, a));
            if (e ? .endpoint && (!US(e) || s.has(rC(e)) || c.has(rC(e))) && (e.sessionRefreshToken || e.sessionToken && !e.identitySession)) return w(e, t, i, a);
        },
        renew: w
    };
}
var hC = mC(),
    gC = new Set([
        204,
        205,
        304
    ]),
    _C = 3e4,
    vC = 100,
    yC = "Request aborted because a caller or the lifecycle cancelled it.";

function bC(e) {
    return e ? .name === "AbortError";
}
var xC = "Session expired. Please refresh the page.";

function SC(e) {
    return /(^|\/)message\/(?:chat|handoff_media)($|\/|\?)/.test(e);
}
async function CC(e, t) {
    let n = Date.now();
    for (; Date.now() - n < _C;) {
        if (t ? .aborted) return null;
        let n = e();
        if (Lo(n)) return Fo(n);
        await new Promise((e) => setTimeout(e, vC));
    }
    return null;
}
var wC = (({
        baseUrl: e = "",
        auth: t = mC()
    } = {}) => async ({
        url: n,
        method: r = "GET",
        body: i,
        params: a,
        headers: o,
        credentials: s,
        signal: c,
        bindLifecycleSignal: l = !0,
        timeoutMs: u,
        simpleGet: d = !1,
        beacon: f = !1
    }, p) => {
        let m = _r(),
            h = u ? ? 2e4,
            g = [
                c,
                p.signal,
                l ? m : null
            ],
            _ = dc(g, h),
            v = !1;
        try {
            n = fc(n);
            let c = `${e}${n}`;
            if (a) {
                let e = new URLSearchParams(a);
                c += `?${e.toString()}`;
            }
            let l = dC(c, r, d),
                u = pc({
                    url: n,
                    body: i,
                    headers: o,
                    simpleGet: d
                }),
                h = p.getState(),
                g = h.session,
                y = () => m ? .aborted === !0,
                b = () => ({
                    error: {
                        status: 0,
                        data: cc
                    }
                });
            if (!d && h.session ? .sessionToken && ac(h)) return {
                error: {
                    status: 401,
                    data: xC
                }
            };
            if (l && !f) {
                let e = t.prepare(g, u, p, _.signal);
                if (e && (await e, !Y(g, p) || y())) return b();
            }
            let x = p.getState();
            !d && x.session && Object.assign(u, fC(x.session, l));
            let S = !d && SC(c) && !!x.session ? .features ? .challengeModeEnabled && !!x.security ? .turnstileSiteKey;
            if (S) {
                let e = Lo(x) ? Fo(x) : await CC(p.getState, _.signal);
                if (!Y(g, p) || y()) return b();
                e ? u["X-Turnstile-Token"] = e : p.dispatch(No("Challenge timed out. Please refresh the page and try again."));
            }
            let C = async (e) => {
                let t;
                t = i instanceof FormData ? i : i ? JSON.stringify(i) : void 0;
                let n = await Promise.race([fetch(c, {
                        method: r,
                        ...Object.keys(e).length > 0 ? {
                            headers: e
                        } : {},
                        ...d || s !== void 0 ? {
                            credentials: d ? "omit" : s
                        } : {},
                        ...f ? {
                            keepalive: !0
                        } : {},
                        body: t,
                        signal: _.signal
                    }), _.timeoutPromise]),
                    a;
                if (gC.has(n.status)) a = null;
                else if (n.headers.get("content-type") ? .includes("application/json")) try {
                    a = await n.json();
                } catch (e) {
                    if (n.ok) throw v = e instanceof SyntaxError, e;
                    a = null;
                }
                else a = await n.text();
                return {
                    response: n,
                    data: a
                };
            };
            if (!Y(g, p)) return b();
            let {
                response: w,
                data: T
            } = await C(u);
            if (!w.ok && w.status === 401 && l && !f) {
                let e = eC(T),
                    n = p.getState().session;
                if (e && n && Y(g, p) && !y()) {
                    let r = !1;
                    if ((n.sessionRefreshToken || n.sessionToken && !n.identitySession) && (r = await t.renew(n, u, p, _.signal, e)), r && Y(g, p) && !y()) {
                        let e = p.getState().session;
                        if (e && US(e)) {
                            let t = { ...u
                            };
                            delete t.Authorization, delete t.authorization, delete t["Chatter-Token"], delete t["Session-Auth"], e.messagingToken && (t.Authorization = `Bearer ${e.messagingToken}`), e.chatterToken && (t["Chatter-Token"] = e.chatterToken), e.sessionToken && (t["Session-Auth"] = e.sessionToken), {
                                response: w,
                                data: T
                            } = await C(t);
                        }
                    }
                }
            }
            let ee = Y(g, p) && !y();
            if (!w.ok) {
                if (ee && S && w.status === 403) {
                    let e = typeof T ? .detail == "string" ? T.detail : "Verification failed. Please try again.";
                    p.dispatch(No(e));
                }
                let e = w.status === 429 || w.status === 503 ? w.headers.get("Retry-After") : null;
                return {
                    error: {
                        status: w.status,
                        data: T,
                        ...e === null ? {} : {
                            retryAfter: e
                        }
                    }
                };
            }
            return ee && S && p.dispatch(Mo()), !d && ee && x.session ? .sessionToken && p.dispatch(xs()), {
                data: T
            };
        } catch (e) {
            let t;
            return t = _.didTimeout() ? `${sc} ${h}ms` : bC(e) && g.some((e) => e ? .aborted) ? yC : e instanceof Error ? e.message : "Network error", {
                error: {
                    status: 0,
                    data: t,
                    ...v ? {
                        isParsingError: !0
                    } : {}
                }
            };
        } finally {
            _.cleanup();
        }
    })({
        auth: hC
    }),
    TC = class extends Error {
        constructor(e) {
            super(e[0].message), j(this, "issues", void 0), this.name = "SchemaError", this.issues = e;
        }
    },
    EC = "uninitialized",
    DC = "pending",
    OC = "fulfilled",
    kC = "rejected";

function AC(e) {
    return {
        status: e,
        isUninitialized: e === EC,
        isLoading: e === DC,
        isSuccess: e === OC,
        isError: e === kC
    };
}
var jC = Or;

function MC(e, t) {
    if (e === t || !(jC(e) && jC(t) || Array.isArray(e) && Array.isArray(t))) return t;
    let n = Object.keys(t),
        r = Object.keys(e),
        i = n.length === r.length,
        a = Array.isArray(t) ? [] : {};
    for (let r of n) a[r] = MC(e[r], t[r]), i && = e[r] === a[r];
    return i ? e : a;
}

function NC(e, t, n) {
    return e.reduce((e, r, i) => (t(r, i) && e.push(n(r, i)), e), []).flat();
}

function PC() {
    return typeof document > "u" ? !0 : document.visibilityState !== "hidden";
}

function FC(e) {
    return e != null;
}

function IC(e) {
    return [...e ? .values() ? ? []].filter(FC);
}

function LC() {
    return typeof navigator > "u" || navigator.onLine === void 0 ? !0 : navigator.onLine;
}

function RC(e, t, n) {
    return e.has(t) ? e.get(t) : e.set(t, n(t)).get(t);
}
var zC = () => /* @__PURE__ */ new Map(),
    BC = class {
        constructor(e, t = void 0) {
            this.value = e, this.meta = t;
        }
    },
    VC = "__rtkq/",
    HC = "online",
    UC = "offline",
    WC = "focus",
    GC = "focused",
    KC = "visibilitychange",
    qC = /* @__PURE__ */ Da(`${VC}${GC}`),
    JC = /* @__PURE__ */ Da(`${VC}un${GC}`),
    YC = /* @__PURE__ */ Da(`${VC}${HC}`),
    XC = /* @__PURE__ */ Da(`${VC}${UC}`),
    ZC = {
        onFocus: qC,
        onFocusLost: JC,
        onOnline: YC,
        onOffline: XC
    },
    QC = !1;

function $C(e, t) {
    function n() {
        let [t, n, r, i] = [
            qC,
            JC,
            YC,
            XC
        ].map((t) => () => e(t())), a = () => {
            window.document.visibilityState === "visible" ? t() : n();
        }, o = () => {
            QC = !1;
        };
        if (!QC && typeof window < "u" && window.addEventListener) {
            let e = function(e) {
                    Object.entries(n).forEach(([t, n]) => {
                        e ? window.addEventListener(t, n, !1) : window.removeEventListener(t, n);
                    });
                },
                n = {
                    [WC]: t,
                    [KC]: a,
                    [HC]: r,
                    [UC]: i
                };
            e(!0), QC = !0, o = () => {
                e(!1), QC = !1;
            };
        }
        return o;
    }
    return t ? t(e, ZC) : n();
}
var ew = "query",
    tw = "mutation",
    nw = "infinitequery";

function rw(e) {
    return e.type === ew;
}

function iw(e) {
    return e.type === tw;
}

function aw(e) {
    return e.type === nw;
}

function ow(e) {
    return rw(e) || aw(e);
}

function sw(e, t, n, r, i, a) {
    let o = cw(e) ? e(t, n, r, i) : e;
    return o ? NC(o, FC, (e) => a(lw(e))) : [];
}

function cw(e) {
    return typeof e == "function";
}

function lw(e) {
    return typeof e == "string" ? {
        type: e
    } : e;
}

function uw(e, t) {
    return e.catch(t);
}
var dw = (e, t) => e.endpointDefinitions[t],
    fw = Symbol("forceQueryFn"),
    pw = (e) => typeof e[fw] == "function";

function mw({
    serializeQueryArgs: e,
    queryThunk: t,
    infiniteQueryThunk: n,
    mutationThunk: r,
    api: i,
    context: a,
    getInternalState: o
}) {
    let s = (e) => o(e) ? .runningQueries,
        c = (e) => o(e) ? .runningMutations,
        {
            unsubscribeQueryResult: l,
            removeMutationResult: u,
            updateSubscriptionOptions: d
        } = i.internalActions;
    return {
        buildInitiateQuery: _,
        buildInitiateInfiniteQuery: v,
        buildInitiateMutation: y,
        getRunningQueryThunk: f,
        getRunningMutationThunk: p,
        getRunningQueriesThunk: m,
        getRunningMutationsThunk: h
    };

    function f(t, n) {
        return (r) => {
            let i = e({
                queryArgs: n,
                endpointDefinition: dw(a, t),
                endpointName: t
            });
            return s(r) ? .get(i);
        };
    }

    function p(e, t) {
        return (e) => c(e) ? .get(t);
    }

    function m() {
        return (e) => IC(s(e));
    }

    function h() {
        return (e) => IC(c(e));
    }

    function g(r, a) {
        let o = (c, {
            subscribe: u = !0,
            forceRefetch: f,
            subscriptionOptions: p,
            [fw]: m,
            ...h
        } = {}) => (g, _) => {
            let v = e({
                    queryArgs: c,
                    endpointDefinition: a,
                    endpointName: r
                }),
                y, b = {
                    ...h,
                    type: ew,
                    subscribe: u,
                    forceRefetch: f,
                    subscriptionOptions: p,
                    endpointName: r,
                    originalArgs: c,
                    queryCacheKey: v,
                    [fw]: m
                };
            if (rw(a)) y = t(b);
            else {
                let {
                    direction: e,
                    initialPageParam: t,
                    refetchCachedPages: r
                } = h;
                y = n({
                    ...b,
                    direction: e,
                    initialPageParam: t,
                    refetchCachedPages: r
                });
            }
            let x = i.endpoints[r].select(c),
                S = g(y),
                C = x(_()),
                {
                    requestId: w,
                    abort: T
                } = S,
                ee = C.requestId !== w,
                E = s(g) ? .get(v),
                D = () => x(_()),
                te = Object.assign(m ? S.then(D) : ee && !E ? Promise.resolve(C) : Promise.all([E, S]).then(D), {
                    arg: c,
                    requestId: w,
                    subscriptionOptions: p,
                    queryCacheKey: v,
                    abort: T,
                    async unwrap() {
                        let e = await te;
                        if (e.isError) throw e.error;
                        return e.data;
                    },
                    refetch: (e) => g(o(c, {
                        subscribe: !1,
                        forceRefetch: !0,
                        ...e
                    })),
                    unsubscribe() {
                        u && g(l({
                            queryCacheKey: v,
                            requestId: w
                        }));
                    },
                    updateSubscriptionOptions(e) {
                        te.subscriptionOptions = e, g(d({
                            endpointName: r,
                            requestId: w,
                            queryCacheKey: v,
                            options: e
                        }));
                    }
                });
            if (!E && !ee && !m) {
                let e = s(g);
                e.set(v, te), te.then(() => {
                    e.delete(v);
                });
            }
            return te;
        };
        return o;
    }

    function _(e, t) {
        return g(e, t);
    }

    function v(e, t) {
        return g(e, t);
    }

    function y(e) {
        return (t, {
            track: n = !0,
            fixedCacheKey: i
        } = {}) => (a, o) => {
            let s = a(r({
                    type: "mutation",
                    endpointName: e,
                    originalArgs: t,
                    track: n,
                    fixedCacheKey: i
                })),
                {
                    requestId: l,
                    abort: d,
                    unwrap: f
                } = s,
                p = uw(s.unwrap().then((e) => ({
                    data: e
                })), (e) => ({
                    error: e
                })),
                m = Object.assign(p, {
                    arg: s.arg,
                    requestId: l,
                    abort: d,
                    unwrap: f,
                    reset: () => {
                        a(u({
                            requestId: l,
                            fixedCacheKey: i
                        }));
                    }
                }),
                h = c(a);
            return h.set(l, m), m.then(() => {
                h.delete(l);
            }), i && (h.set(i, m), m.then(() => {
                h.get(i) === m && h.delete(i);
            })), m;
        };
    }
}
var hw = class extends TC {
        constructor(e, t, n, r) {
            super(e), this.value = t, this.schemaName = n, this._bqMeta = r;
        }
    },
    gw = (e, t) => Array.isArray(e) ? e.includes(t) : !!e;
async function _w(e, t, n, r) {
    let i = await e["~standard"].validate(t);
    if (i.issues) throw new hw(i.issues, t, n, r);
    return i.value;
}

function vw(e) {
    return e;
}
var yw = (e = {}) => ({
    ...e,
    [Na]: !0
});

function bw({
    reducerPath: e,
    baseQuery: t,
    context: {
        endpointDefinitions: n
    },
    serializeQueryArgs: r,
    api: i,
    assertTagType: a,
    selectors: o,
    onSchemaFailure: s,
    catchSchemaFailure: c,
    skipSchemaValidation: l
}) {
    let u = (e, t, o, s) => (c, l) => {
        let u = n[e],
            d = r({
                queryArgs: t,
                endpointDefinition: u,
                endpointName: e
            });
        if (c(i.internalActions.queryResultPatched({
                queryCacheKey: d,
                patches: o
            })), !s) return;
        let f = i.endpoints[e].select(t)(l()),
            p = sw(u.providesTags, f.data, void 0, t, {}, a);
        c(i.internalActions.updateProvidedBy([{
            queryCacheKey: d,
            providedTags: p
        }]));
    };

    function d(e, t, n = 0) {
        let r = [t, ...e];
        return n && r.length > n ? r.slice(0, -1) : r;
    }

    function f(e, t, n = 0) {
        let r = [...e, t];
        return n && r.length > n ? r.slice(1) : r;
    }
    let p = (e, t, n, r = !0) => (a, o) => {
            let s = i.endpoints[e].select(t)(o()),
                c = {
                    patches: [],
                    inversePatches: [],
                    undo: () => a(i.util.patchQueryData(e, t, c.inversePatches, r))
                };
            if (s.status === EC) return c;
            let l;
            if ("data" in s)
                if (qr(s.data)) {
                    let [e, t, r] = oa(s.data, n);
                    c.patches.push(...t), c.inversePatches.push(...r), l = e;
                } else l = n(s.data), c.patches.push({
                    op: "replace",
                    path: [],
                    value: l
                }), c.inversePatches.push({
                    op: "replace",
                    path: [],
                    value: s.data
                });
            return c.patches.length === 0 || a(i.util.patchQueryData(e, t, c.patches, r)), c;
        },
        m = (e, t, n) => (r) => r(i.endpoints[e].initiate(t, {
            subscribe: !1,
            forceRefetch: !0,
            [fw]: () => ({
                data: n
            })
        })),
        h = (e, t) => e.query && e[t] ? e[t] : vw,
        g = async (e, {
            signal: r,
            abort: i,
            rejectWithValue: a,
            fulfillWithValue: u,
            dispatch: p,
            getState: m,
            extra: g
        }) => {
            let v = n[e.endpointName],
                {
                    metaSchema: y,
                    skipSchemaValidation: b = l
                } = v,
                x = e.type === ew;
            try {
                let n = vw,
                    a = {
                        signal: r,
                        abort: i,
                        dispatch: p,
                        getState: m,
                        extra: g,
                        endpoint: e.endpointName,
                        type: e.type,
                        forced: x ? _(e, m()) : void 0,
                        queryCacheKey: x ? e.queryCacheKey : void 0
                    },
                    s = x ? e[fw] : void 0,
                    c, l = async (t, n, r, i) => {
                        if (n == null && t.pages.length) return Promise.resolve({
                            data: t
                        });
                        let a = await S({
                                queryArg: e.originalArgs,
                                pageParam: n
                            }),
                            o = i ? d : f;
                        return {
                            data: {
                                pages: o(t.pages, a.data, r),
                                pageParams: o(t.pageParams, n, r)
                            },
                            meta: a.meta
                        };
                    };
                async function S(e) {
                    let r, {
                        extraOptions: i,
                        argSchema: o,
                        rawResponseSchema: c,
                        responseSchema: l
                    } = v;
                    if (o && !gw(b, "arg") && (e = await _w(o, e, "argSchema", {})), s ? r = s() : v.query ? (n = h(v, "transformResponse"), r = await t(v.query(e), a, i)) : r = await v.queryFn(e, a, i, (e) => t(e, a, i)), r.error) throw new BC(r.error, r.meta);
                    let {
                        data: u
                    } = r;
                    c && !gw(b, "rawResponse") && (u = await _w(c, r.data, "rawResponseSchema", r.meta));
                    let d = await n(u, r.meta, e);
                    return l && !gw(b, "response") && (d = await _w(l, d, "responseSchema", r.meta)), {
                        ...r,
                        data: d
                    };
                }
                if (x && "infiniteQueryOptions" in v) {
                    let {
                        infiniteQueryOptions: t
                    } = v, {
                        maxPages: n = Infinity
                    } = t, r = e.refetchCachedPages ? ? t.refetchCachedPages ? ? !0, i, a = {
                        pages: [],
                        pageParams: []
                    }, u = o.selectQueryEntry(m(), e.queryCacheKey) ? .data, d = _(e, m()) && !e.direction || !u ? a : u;
                    if ("direction" in e && e.direction && d.pages.length) {
                        let r = e.direction === "backward";
                        i = await l(d, (r ? Sw : xw)(t, d, e.originalArgs), n, r);
                    } else {
                        let {
                            initialPageParam: a = t.initialPageParam
                        } = e, o = u ? .pageParams ? ? [], c = o[0] ? ? a, f = o.length;
                        if (i = await l(d, c, n), s && (i = {
                                data: i.data.pages[0]
                            }), r)
                            for (let r = 1; r < f; r++) {
                                let r = xw(t, i.data, e.originalArgs);
                                i = await l(i.data, r, n);
                            }
                    }
                    c = i;
                } else c = await S(e.originalArgs);
                return y && !gw(b, "meta") && c.meta && (c.meta = await _w(y, c.meta, "metaSchema", c.meta)), u(c.data, yw({
                    fulfilledTimeStamp: Date.now(),
                    baseQueryMeta: c.meta
                }));
            } catch (t) {
                let n = t;
                if (n instanceof BC) {
                    let t = h(v, "transformErrorResponse"),
                        {
                            rawErrorResponseSchema: r,
                            errorResponseSchema: i
                        } = v,
                        {
                            value: o,
                            meta: s
                        } = n;
                    try {
                        r && !gw(b, "rawErrorResponse") && (o = await _w(r, o, "rawErrorResponseSchema", s)), y && !gw(b, "meta") && (s = await _w(y, s, "metaSchema", s));
                        let n = await t(o, s, e.originalArgs);
                        return i && !gw(b, "errorResponse") && (n = await _w(i, n, "errorResponseSchema", s)), a(n, yw({
                            baseQueryMeta: s
                        }));
                    } catch (e) {
                        n = e;
                    }
                }
                try {
                    if (n instanceof hw) {
                        let t = {
                            endpoint: e.endpointName,
                            arg: e.originalArgs,
                            type: e.type,
                            queryCacheKey: x ? e.queryCacheKey : void 0
                        };
                        v.onSchemaFailure ? .(n, t), s ? .(n, t);
                        let {
                            catchSchemaFailure: r = c
                        } = v;
                        if (r) return a(r(n, t), yw({
                            baseQueryMeta: n._bqMeta
                        }));
                    }
                } catch (e) {
                    n = e;
                }
                throw console.error(n), n;
            }
        };

    function _(e, t) {
        let n = o.selectQueryEntry(t, e.queryCacheKey),
            r = o.selectConfig(t).refetchOnMountOrArgChange,
            i = n ? .fulfilledTimeStamp,
            a = e.forceRefetch ? ? (e.subscribe && r);
        return a ? a === !0 || (Number( /* @__PURE__ */ new Date()) - Number(i)) / 1e3 >= a : !1;
    }
    let v = () => ao(`${e}/executeQuery`, g, {
            getPendingMeta({
                arg: e
            }) {
                let t = n[e.endpointName];
                return yw({
                    startedTimeStamp: Date.now(),
                    ...aw(t) ? {
                        direction: e.direction
                    } : {}
                });
            },
            condition(e, {
                getState: t
            }) {
                let r = t(),
                    i = o.selectQueryEntry(r, e.queryCacheKey),
                    a = i ? .fulfilledTimeStamp,
                    s = e.originalArgs,
                    c = i ? .originalArgs,
                    l = n[e.endpointName],
                    u = e.direction;
                return pw(e) ? !0 : i ? .status === "pending" ? !1 : _(e, r) || rw(l) && l ? .forceRefetch ? .({
                    currentArg: s,
                    previousArg: c,
                    endpointState: i,
                    state: r
                }) ? !0 : !(a && !u);
            },
            dispatchConditionRejection: !0
        }),
        y = v(),
        b = v(),
        x = ao(`${e}/executeMutation`, g, {
            getPendingMeta() {
                return yw({
                    startedTimeStamp: Date.now()
                });
            }
        }),
        S = (e) => "force" in e,
        C = (e) => "ifOlderThan" in e,
        w = (e, t, n = {}) => (r, a) => {
            let o = S(n) && n.force,
                s = C(n) && n.ifOlderThan,
                c = (n = !0) => {
                    let r = {
                        forceRefetch: n,
                        subscribe: !1
                    };
                    return i.endpoints[e].initiate(t, r);
                },
                l = i.endpoints[e].select(t)(a());
            if (o) r(c());
            else if (s) {
                let e = l ? .fulfilledTimeStamp;
                if (!e) {
                    r(c());
                    return;
                }
                (Number( /* @__PURE__ */ new Date()) - Number(new Date(e))) / 1e3 >= s && r(c());
            } else r(c(!1));
        };

    function T(e) {
        return (t) => t ? .meta ? .arg ? .endpointName === e;
    }

    function ee(e, t) {
        return {
            matchPending: Wa(qa(e), T(t)),
            matchFulfilled: Wa(Xa(e), T(t)),
            matchRejected: Wa(Ja(e), T(t))
        };
    }
    return {
        queryThunk: y,
        mutationThunk: x,
        infiniteQueryThunk: b,
        prefetch: w,
        updateQueryData: p,
        upsertQueryData: m,
        patchQueryData: u,
        buildMatchThunkActions: ee
    };
}

function xw(e, {
    pages: t,
    pageParams: n
}, r) {
    let i = t.length - 1;
    return e.getNextPageParam(t[i], t, n[i], n, r);
}

function Sw(e, {
    pages: t,
    pageParams: n
}, r) {
    return e.getPreviousPageParam ? .(t[0], t, n[0], n, r);
}

function Cw(e, t, n, r) {
    return sw(n[e.meta.arg.endpointName][t], Xa(e) ? e.payload : void 0, Ya(e) ? e.payload : void 0, e.meta.arg.originalArgs, "baseQueryMeta" in e.meta ? e.meta.baseQueryMeta : void 0, r);
}

function ww(e) {
    return Kr(e) ? ta(e) : e;
}

function Tw(e, t, n) {
    let r = e[t];
    r && n(r);
}

function Ew(e) {
    return ("arg" in e ? e.arg.fixedCacheKey : e.fixedCacheKey) ? ? e.requestId;
}

function Dw(e, t, n) {
    let r = e[Ew(t)];
    r && n(r);
}
var Ow = {};

function kw({
    reducerPath: e,
    queryThunk: t,
    mutationThunk: n,
    serializeQueryArgs: r,
    context: {
        endpointDefinitions: i,
        apiUid: a,
        extractRehydrationInfo: o,
        hasRehydrationInfo: s
    },
    assertTagType: c,
    config: l
}) {
    let u = Da(`${e}/resetApiState`);

    function d(e, t, n, r) {
        e[t.queryCacheKey] ? ? = {
            status: EC,
            endpointName: t.endpointName
        }, Tw(e, t.queryCacheKey, (e) => {
            e.status = DC, e.requestId = n && e.requestId ? e.requestId : r.requestId, t.originalArgs !== void 0 && (e.originalArgs = t.originalArgs), e.startedTimeStamp = r.startedTimeStamp;
            let a = i[r.arg.endpointName];
            aw(a) && "direction" in t && (e.direction = t.direction);
        });
    }

    function f(e, t, n, r) {
        Tw(e, t.arg.queryCacheKey, (e) => {
            if (e.requestId !== t.requestId && !r) return;
            let {
                merge: a
            } = i[t.arg.endpointName];
            if (e.status = OC, a)
                if (e.data !== void 0) {
                    let {
                        fulfilledTimeStamp: r,
                        arg: i,
                        baseQueryMeta: o,
                        requestId: s
                    } = t;
                    e.data = aa(e.data, (e) => a(e, n, {
                        arg: i.originalArgs,
                        baseQueryMeta: o,
                        fulfilledTimeStamp: r,
                        requestId: s
                    }));
                } else e.data = n;
            else e.data = i[t.arg.endpointName].structuralSharing ? ? !0 ? MC(Kr(e.data) ? Zr(e.data) : e.data, n) : n;
            delete e.error, e.fulfilledTimeStamp = t.fulfilledTimeStamp;
        });
    }
    let p = N({
            name: `${e}/queries`,
            initialState: Ow,
            reducers: {
                removeQueryResult: {
                    reducer(e, {
                        payload: {
                            queryCacheKey: t
                        }
                    }) {
                        delete e[t];
                    },
                    prepare: Pa()
                },
                cacheEntriesUpserted: {
                    reducer(e, t) {
                        for (let n of t.payload) {
                            let {
                                queryDescription: r,
                                value: i
                            } = n;
                            d(e, r, !0, {
                                arg: r,
                                requestId: t.meta.requestId,
                                startedTimeStamp: t.meta.timestamp
                            }), f(e, {
                                arg: r,
                                requestId: t.meta.requestId,
                                fulfilledTimeStamp: t.meta.timestamp,
                                baseQueryMeta: {}
                            }, i, !0);
                        }
                    },
                    prepare: (e) => ({
                        payload: e.map((e) => {
                            let {
                                endpointName: t,
                                arg: n,
                                value: a
                            } = e, o = i[t];
                            return {
                                queryDescription: {
                                    type: ew,
                                    endpointName: t,
                                    originalArgs: e.arg,
                                    queryCacheKey: r({
                                        queryArgs: n,
                                        endpointDefinition: o,
                                        endpointName: t
                                    })
                                },
                                value: a
                            };
                        }),
                        meta: {
                            [Na]: !0,
                            requestId: $a(),
                            timestamp: Date.now()
                        }
                    })
                },
                queryResultPatched: {
                    reducer(e, {
                        payload: {
                            queryCacheKey: t,
                            patches: n
                        }
                    }) {
                        Tw(e, t, (e) => {
                            e.data = sa(e.data, n.concat());
                        });
                    },
                    prepare: Pa()
                }
            },
            extraReducers(e) {
                e.addCase(t.pending, (e, {
                    meta: t,
                    meta: {
                        arg: n
                    }
                }) => {
                    d(e, n, pw(n), t);
                }).addCase(t.fulfilled, (e, {
                    meta: t,
                    payload: n
                }) => {
                    f(e, t, n, pw(t.arg));
                }).addCase(t.rejected, (e, {
                    meta: {
                        condition: t,
                        arg: n,
                        requestId: r
                    },
                    error: i,
                    payload: a
                }) => {
                    Tw(e, n.queryCacheKey, (e) => {
                        if (!t) {
                            if (e.requestId !== r) return;
                            e.status = kC, e.error = a ? ? i;
                        }
                    });
                }).addMatcher(s, (e, t) => {
                    let {
                        queries: n
                    } = o(t);
                    for (let [t, r] of Object.entries(n))(r ? .status === OC || r ? .status === kC) && (e[t] = r);
                });
            }
        }),
        m = N({
            name: `${e}/mutations`,
            initialState: Ow,
            reducers: {
                removeMutationResult: {
                    reducer(e, {
                        payload: t
                    }) {
                        let n = Ew(t);
                        n in e && delete e[n];
                    },
                    prepare: Pa()
                }
            },
            extraReducers(e) {
                e.addCase(n.pending, (e, {
                    meta: t,
                    meta: {
                        requestId: n,
                        arg: r,
                        startedTimeStamp: i
                    }
                }) => {
                    r.track && (e[Ew(t)] = {
                        requestId: n,
                        status: DC,
                        endpointName: r.endpointName,
                        startedTimeStamp: i
                    });
                }).addCase(n.fulfilled, (e, {
                    payload: t,
                    meta: n
                }) => {
                    n.arg.track && Dw(e, n, (e) => {
                        e.requestId === n.requestId && (e.status = OC, e.data = t, e.fulfilledTimeStamp = n.fulfilledTimeStamp);
                    });
                }).addCase(n.rejected, (e, {
                    payload: t,
                    error: n,
                    meta: r
                }) => {
                    r.arg.track && Dw(e, r, (e) => {
                        e.requestId === r.requestId && (e.status = kC, e.error = t ? ? n);
                    });
                }).addMatcher(s, (e, t) => {
                    let {
                        mutations: n
                    } = o(t);
                    for (let [t, r] of Object.entries(n))(r ? .status === OC || r ? .status === kC) && t !== r ? .requestId && (e[t] = r);
                });
            }
        }),
        h = N({
            name: `${e}/invalidation`,
            initialState: {
                tags: {},
                keys: {}
            },
            reducers: {
                updateProvidedBy: {
                    reducer(e, t) {
                        for (let {
                                queryCacheKey: n,
                                providedTags: r
                            } of t.payload) {
                            g(e, n);
                            for (let {
                                    type: t,
                                    id: i
                                } of r) {
                                let r = (e.tags[t] ? ? = {})[i || "__internal_without_id"] ? ? = [];
                                r.includes(n) || r.push(n);
                            }
                            e.keys[n] = r;
                        }
                    },
                    prepare: Pa()
                }
            },
            extraReducers(e) {
                e.addCase(p.actions.removeQueryResult, (e, {
                    payload: {
                        queryCacheKey: t
                    }
                }) => {
                    g(e, t);
                }).addMatcher(s, (e, t) => {
                    let {
                        provided: n
                    } = o(t);
                    for (let [t, r] of Object.entries(n.tags ? ? {}))
                        for (let [i, a] of Object.entries(r)) {
                            let r = (e.tags[t] ? ? = {})[i || "__internal_without_id"] ? ? = [];
                            for (let t of a) r.includes(t) || r.push(t), e.keys[t] = n.keys[t];
                        }
                }).addMatcher(Ua(Xa(t), Ya(t)), (e, t) => {
                    _(e, [t]);
                }).addMatcher(p.actions.cacheEntriesUpserted.match, (e, t) => {
                    _(e, t.payload.map(({
                        queryDescription: e,
                        value: t
                    }) => ({
                        type: "UNKNOWN",
                        payload: t,
                        meta: {
                            requestStatus: "fulfilled",
                            requestId: "UNKNOWN",
                            arg: e
                        }
                    })));
                });
            }
        });

    function g(e, t) {
        let n = ww(e.keys[t] ? ? []);
        for (let r of n) {
            let n = r.type,
                i = r.id ? ? "__internal_without_id",
                a = e.tags[n] ? .[i];
            a && (e.tags[n][i] = ww(a).filter((e) => e !== t));
        }
        delete e.keys[t];
    }

    function _(e, t) {
        let n = t.map((e) => {
            let t = Cw(e, "providesTags", i, c),
                {
                    queryCacheKey: n
                } = e.meta.arg;
            return {
                queryCacheKey: n,
                providedTags: t
            };
        });
        h.caseReducers.updateProvidedBy(e, h.actions.updateProvidedBy(n));
    }
    let v = N({
            name: `${e}/subscriptions`,
            initialState: Ow,
            reducers: {
                updateSubscriptionOptions(e, t) {},
                unsubscribeQueryResult(e, t) {},
                internal_getRTKQSubscriptions() {}
            }
        }),
        y = N({
            name: `${e}/internalSubscriptions`,
            initialState: Ow,
            reducers: {
                subscriptionsUpdated: {
                    reducer(e, t) {
                        return sa(e, t.payload);
                    },
                    prepare: Pa()
                }
            }
        }),
        b = N({
            name: `${e}/config`,
            initialState: {
                online: LC(),
                focused: PC(),
                middlewareRegistered: !1,
                ...l
            },
            reducers: {
                middlewareRegistered(e, {
                    payload: t
                }) {
                    e.middlewareRegistered = e.middlewareRegistered === "conflict" || a !== t ? "conflict" : !0;
                }
            },
            extraReducers: (e) => {
                e.addCase(YC, (e) => {
                    e.online = !0;
                }).addCase(XC, (e) => {
                    e.online = !1;
                }).addCase(qC, (e) => {
                    e.focused = !0;
                }).addCase(JC, (e) => {
                    e.focused = !1;
                }).addMatcher(s, (e) => ({ ...e
                }));
            }
        }),
        x = jr({
            queries: p.reducer,
            mutations: m.reducer,
            provided: h.reducer,
            subscriptions: y.reducer,
            config: b.reducer
        });
    return {
        reducer: (e, t) => x(u.match(t) ? void 0 : e, t),
        actions: {
            ...b.actions,
            ...p.actions,
            ...v.actions,
            ...y.actions,
            ...m.actions,
            ...h.actions,
            resetApiState: u
        }
    };
}
var Aw = /* @__PURE__ */ Symbol.for("RTKQ/skipToken"),
    jw = {
        status: EC
    },
    Mw = /* @__PURE__ */ aa(jw, () => {}),
    Nw = /* @__PURE__ */ aa(jw, () => {});

function Pw({
    serializeQueryArgs: e,
    reducerPath: t,
    createSelector: n
}) {
    let r = (e) => Mw,
        i = (e) => Nw;
    return {
        buildQuerySelector: f,
        buildInfiniteQuerySelector: p,
        buildMutationSelector: m,
        selectInvalidatedBy: h,
        selectCachedArgsForQuery: g,
        selectApiState: o,
        selectQueries: s,
        selectMutations: l,
        selectQueryEntry: c,
        selectConfig: u
    };

    function a(e) {
        return {
            ...e,
            ...AC(e.status)
        };
    }

    function o(e) {
        return e[t];
    }

    function s(e) {
        return o(e) ? .queries;
    }

    function c(e, t) {
        return s(e) ? .[t];
    }

    function l(e) {
        return o(e) ? .mutations;
    }

    function u(e) {
        return o(e) ? .config;
    }

    function d(t, i, a) {
        return (o) => {
            if (o === Aw) return n(r, a);
            let s = e({
                queryArgs: o,
                endpointDefinition: i,
                endpointName: t
            });
            return n((e) => c(e, s) ? ? Mw, a);
        };
    }

    function f(e, t) {
        return d(e, t, a);
    }

    function p(e, t) {
        let {
            infiniteQueryOptions: n
        } = t;

        function r(e) {
            let t = {
                    ...e,
                    ...AC(e.status)
                },
                {
                    isLoading: r,
                    isError: i,
                    direction: a
                } = t,
                o = a === "forward",
                s = a === "backward";
            return {
                ...t,
                hasNextPage: _(n, t.data, t.originalArgs),
                hasPreviousPage: v(n, t.data, t.originalArgs),
                isFetchingNextPage: r && o,
                isFetchingPreviousPage: r && s,
                isFetchNextPageError: i && o,
                isFetchPreviousPageError: i && s
            };
        }
        return d(e, t, r);
    }

    function m() {
        return (e) => {
            let t;
            return t = typeof e == "object" ? Ew(e) ? ? Aw : e, n(t === Aw ? i : (e) => o(e) ? .mutations ? .[t] ? ? Nw, a);
        };
    }

    function h(e, n) {
        let r = e[t],
            i = /* @__PURE__ */ new Set(),
            a = NC(n, FC, lw);
        for (let e of a) {
            let t = r.provided.tags[e.type];
            if (!t) continue;
            let n = (e.id === void 0 ? Object.values(t).flat() : t[e.id]) ? ? [];
            for (let e of n) i.add(e);
        }
        return Array.from(i.values()).flatMap((e) => {
            let t = r.queries[e];
            return t ? {
                queryCacheKey: e,
                endpointName: t.endpointName,
                originalArgs: t.originalArgs
            } : [];
        });
    }

    function g(e, t) {
        return NC(Object.values(s(e)), (e) => e ? .endpointName === t && e.status !== EC, (e) => e.originalArgs);
    }

    function _(e, t, n) {
        return t ? xw(e, t, n) != null : !1;
    }

    function v(e, t, n) {
        return !t || !e.getPreviousPageParam ? !1 : Sw(e, t, n) != null;
    }
}
var Fw = WeakMap ? /* @__PURE__ */ new WeakMap() : void 0,
    Iw = ({
        endpointName: e,
        queryArgs: t
    }) => {
        let n = "",
            r = Fw ? .get(t);
        if (typeof r == "string") n = r;
        else {
            let e = JSON.stringify(t, (e, t) => (t = typeof t == "bigint" ? {
                $bigint: t.toString()
            } : t, t = Or(t) ? Object.keys(t).sort().reduce((e, n) => (e[n] = t[n], e), {}) : t, t));
            Or(t) && Fw ? .set(t, e), n = e;
        }
        return `${e}(${n})`;
    };

function Lw(...e) {
    return function(t) {
        let n = ya((e) => t.extractRehydrationInfo ? .(e, {
                reducerPath: t.reducerPath ? ? "api"
            })),
            r = {
                reducerPath: "api",
                keepUnusedDataFor: 60,
                refetchOnMountOrArgChange: !1,
                refetchOnFocus: !1,
                refetchOnReconnect: !1,
                invalidationBehavior: "delayed",
                ...t,
                extractRehydrationInfo: n,
                serializeQueryArgs(e) {
                    let n = Iw;
                    if ("serializeQueryArgs" in e.endpointDefinition) {
                        let t = e.endpointDefinition.serializeQueryArgs;
                        n = (e) => {
                            let n = t(e);
                            return typeof n == "string" ? n : Iw({
                                ...e,
                                queryArgs: n
                            });
                        };
                    } else t.serializeQueryArgs && (n = t.serializeQueryArgs);
                    return n(e);
                },
                tagTypes: [...t.tagTypes || []]
            },
            i = {
                endpointDefinitions: {},
                batch(e) {
                    e();
                },
                apiUid: $a(),
                extractRehydrationInfo: n,
                hasRehydrationInfo: ya((e) => n(e) != null)
            },
            a = {
                injectEndpoints: s,
                enhanceEndpoints({
                    addTagTypes: e,
                    endpoints: t
                }) {
                    if (e)
                        for (let t of e) r.tagTypes.includes(t) || r.tagTypes.push(t);
                    if (t)
                        for (let [e, n] of Object.entries(t)) typeof n == "function" ? n(dw(i, e)) : Object.assign(dw(i, e) || {}, n);
                    return a;
                }
            },
            o = e.map((e) => e.init(a, r, i));

        function s(e) {
            let t = e.endpoints({
                query: (e) => ({
                    ...e,
                    type: ew
                }),
                mutation: (e) => ({
                    ...e,
                    type: tw
                }),
                infiniteQuery: (e) => ({
                    ...e,
                    type: nw
                })
            });
            for (let [n, r] of Object.entries(t)) {
                if (e.overrideExisting !== !0 && n in i.endpointDefinitions) {
                    if (e.overrideExisting === "throw") throw Error(Eo(39));
                    continue;
                }
                i.endpointDefinitions[n] = r;
                for (let e of o) e.injectEndpoint(n, r);
            }
            return a;
        }
        return a.injectEndpoints({
            endpoints: t.endpoints
        });
    };
}

function Rw(e, ...t) {
    return Object.assign(e, ...t);
}
var zw = ({
        api: e,
        queryThunk: t,
        internalState: n,
        mwApi: r
    }) => {
        let i = `${e.reducerPath}/subscriptions`,
            a = null,
            o = null,
            {
                updateSubscriptionOptions: s,
                unsubscribeQueryResult: c
            } = e.internalActions,
            l = (n, r) => {
                if (s.match(r)) {
                    let {
                        queryCacheKey: e,
                        requestId: t,
                        options: i
                    } = r.payload, a = n.get(e);
                    return a ? .has(t) && a.set(t, i), !0;
                }
                if (c.match(r)) {
                    let {
                        queryCacheKey: e,
                        requestId: t
                    } = r.payload, i = n.get(e);
                    return i && i.delete(t), !0;
                }
                if (e.internalActions.removeQueryResult.match(r)) return n.delete(r.payload.queryCacheKey), !0;
                if (t.pending.match(r)) {
                    let {
                        meta: {
                            arg: e,
                            requestId: t
                        }
                    } = r, i = RC(n, e.queryCacheKey, zC);
                    return e.subscribe && i.set(t, e.subscriptionOptions ? ? i.get(t) ? ? {}), !0;
                }
                let i = !1;
                if (t.rejected.match(r)) {
                    let {
                        meta: {
                            condition: e,
                            arg: t,
                            requestId: a
                        }
                    } = r;
                    if (e && t.subscribe) {
                        let e = RC(n, t.queryCacheKey, zC);
                        e.set(a, t.subscriptionOptions ? ? e.get(a) ? ? {}), i = !0;
                    }
                }
                return i;
            },
            u = () => n.currentSubscriptions,
            d = {
                getSubscriptions: u,
                getSubscriptionCount: (e) => u().get(e) ? .size ? ? 0,
                isRequestSubscribed: (e, t) => !!u() ? .get(e) ? .get(t)
            };

        function f(e) {
            return JSON.parse(JSON.stringify(Object.fromEntries([...e].map(([e, t]) => [e, Object.fromEntries(t)]))));
        }
        return (r, s) => {
            if (a || = f(n.currentSubscriptions), e.util.resetApiState.match(r)) return a = {}, n.currentSubscriptions.clear(), o = null, [!0, !1];
            if (e.internalActions.internal_getRTKQSubscriptions.match(r)) return [!1, d];
            let c = l(n.currentSubscriptions, r),
                u = !0;
            if (c) {
                o || = setTimeout(() => {
                    let t = f(n.currentSubscriptions),
                        [, r] = oa(a, () => t);
                    s.next(e.internalActions.subscriptionsUpdated(r)), a = t, o = null;
                }, 500);
                let c = typeof r.type == "string" && !!r.type.startsWith(i),
                    l = t.rejected.match(r) && r.meta.condition && !!r.meta.arg.subscribe;
                u = !c && !l;
            }
            return [u, !1];
        };
    },
    Bw = 2147483647 / 1e3 - 1,
    Vw = ({
        reducerPath: e,
        api: t,
        queryThunk: n,
        context: r,
        internalState: i,
        selectors: {
            selectQueryEntry: a,
            selectConfig: o
        },
        getRunningQueryThunk: s,
        mwApi: c
    }) => {
        let {
            removeQueryResult: l,
            unsubscribeQueryResult: u,
            cacheEntriesUpserted: d
        } = t.internalActions, f = Ua(u.match, n.fulfilled, n.rejected, d.match);

        function p(e) {
            let t = i.currentSubscriptions.get(e);
            return t ? t.size > 0 : !1;
        }
        let m = {};

        function h(e) {
            for (let t of e.values()) t ? .abort ? .();
        }
        let g = (e, n) => {
            let a = o(n.getState());
            if (f(e)) {
                let t;
                if (d.match(e)) t = e.payload.map((e) => e.queryDescription.queryCacheKey);
                else {
                    let {
                        queryCacheKey: n
                    } = u.match(e) ? e.payload : e.meta.arg;
                    t = [n];
                }
                _(t, n, a);
            }
            if (t.util.resetApiState.match(e)) {
                for (let [e, t] of Object.entries(m)) t && clearTimeout(t), delete m[e];
                h(i.runningQueries), h(i.runningMutations);
            }
            if (r.hasRehydrationInfo(e)) {
                let {
                    queries: t
                } = r.extractRehydrationInfo(e);
                _(Object.keys(t), n, a);
            }
        };

        function _(e, t, n) {
            let r = t.getState();
            for (let i of e) {
                let e = a(r, i);
                e ? .endpointName && v(i, e.endpointName, t, n);
            }
        }

        function v(e, t, n, i) {
            let o = dw(r, t) ? .keepUnusedDataFor ? ? i.keepUnusedDataFor;
            if (o === Infinity) return;
            let c = Math.max(0, Math.min(o, Bw));
            if (!p(e)) {
                let t = m[e];
                t && clearTimeout(t), m[e] = setTimeout(() => {
                    if (!p(e)) {
                        let t = a(n.getState(), e);
                        t ? .endpointName && n.dispatch(s(t.endpointName, t.originalArgs)) ? .abort(), n.dispatch(l({
                            queryCacheKey: e
                        }));
                    }
                    delete m[e];
                }, c * 1e3);
            }
        }
        return g;
    },
    Hw = /* @__PURE__ */ Error("Promise never resolved before cacheEntryRemoved."),
    Uw = ({
        api: e,
        reducerPath: t,
        context: n,
        queryThunk: r,
        mutationThunk: i,
        internalState: a,
        selectors: {
            selectQueryEntry: o,
            selectApiState: s
        }
    }) => {
        let c = Za(r),
            l = Za(i),
            u = Xa(r, i),
            d = {},
            {
                removeQueryResult: f,
                removeMutationResult: p,
                cacheEntriesUpserted: m
            } = e.internalActions;

        function h(e, t, n) {
            let r = d[e];
            r ? .valueResolved && (r.valueResolved({
                data: t,
                meta: n
            }), delete r.valueResolved);
        }

        function g(e) {
            let t = d[e];
            t && (delete d[e], t.cacheEntryRemoved());
        }

        function _(e) {
            let {
                arg: t,
                requestId: n
            } = e.meta, {
                endpointName: r,
                originalArgs: i
            } = t;
            return [
                r,
                i,
                n
            ];
        }
        let v = (n, a, s) => {
            let c = y(n);

            function l(e, t, n, r) {
                let i = o(s, t),
                    c = o(a.getState(), t);
                !i && c && b(e, r, t, a, n);
            }
            if (r.pending.match(n)) {
                let [e, t, r] = _(n);
                l(e, c, r, t);
            } else if (m.match(n))
                for (let {
                        queryDescription: e,
                        value: t
                    } of n.payload) {
                    let {
                        endpointName: r,
                        originalArgs: i,
                        queryCacheKey: a
                    } = e;
                    l(r, a, n.meta.requestId, i), h(a, t, {});
                }
            else if (i.pending.match(n)) {
                if (a.getState()[t].mutations[c]) {
                    let [e, t, r] = _(n);
                    b(e, t, c, a, r);
                }
            } else if (u(n)) h(c, n.payload, n.meta.baseQueryMeta);
            else if (f.match(n) || p.match(n)) g(c);
            else if (e.util.resetApiState.match(n))
                for (let e of Object.keys(d)) g(e);
        };

        function y(e) {
            return c(e) ? e.meta.arg.queryCacheKey : l(e) ? e.meta.arg.fixedCacheKey ? ? e.meta.requestId : f.match(e) ? e.payload.queryCacheKey : p.match(e) ? Ew(e.payload) : "";
        }

        function b(t, r, i, a, o) {
            let s = dw(n, t),
                c = s ? .onCacheEntryAdded;
            if (!c) return;
            let l = {},
                u = new Promise((e) => {
                    l.cacheEntryRemoved = e;
                }),
                f = Promise.race([new Promise((e) => {
                    l.valueResolved = e;
                }), u.then(() => {
                    throw Hw;
                })]);
            f.catch(() => {}), d[i] = l;
            let p = e.endpoints[t].select(ow(s) ? r : i),
                m = a.dispatch((e, t, n) => n),
                h = c(r, {
                    ...a,
                    getCacheEntry: () => p(a.getState()),
                    requestId: o,
                    extra: m,
                    updateCachedData: ow(s) ? (n) => a.dispatch(e.util.updateQueryData(t, r, n)) : void 0,
                    cacheDataLoaded: f,
                    cacheEntryRemoved: u
                });
            Promise.resolve(h).catch((e) => {
                if (e !== Hw) throw e;
            });
        }
        return v;
    },
    Ww = ({
        api: e,
        context: {
            apiUid: t
        },
        reducerPath: n
    }) => (n, r) => {
        e.util.resetApiState.match(n) && r.dispatch(e.internalActions.middlewareRegistered(t));
    },
    Gw = ({
        reducerPath: e,
        context: t,
        context: {
            endpointDefinitions: n
        },
        mutationThunk: r,
        queryThunk: i,
        api: a,
        assertTagType: o,
        refetchQuery: s,
        internalState: c
    }) => {
        let {
            removeQueryResult: l
        } = a.internalActions, u = Ua(Xa(r), Ya(r)), d = Ua(Xa(i, r), Ja(i, r)), f = [], p = 0, m = (e, t) => {
            (i.pending.match(e) || r.pending.match(e)) && p++, d(e) && (p = Math.max(0, p - 1)), u(e) ? g(Cw(e, "invalidatesTags", n, o), t) : d(e) ? g([], t) : a.util.invalidateTags.match(e) && g(sw(e.payload, void 0, void 0, void 0, void 0, o), t);
        };

        function h() {
            return p > 0;
        }

        function g(n, r) {
            let i = r.getState(),
                o = i[e];
            if (f.push(...n), o.config.invalidationBehavior === "delayed" && h()) return;
            let u = f;
            if (f = [], u.length === 0) return;
            let d = a.util.selectInvalidatedBy(i, u);
            t.batch(() => {
                let e = Array.from(d.values());
                for (let {
                        queryCacheKey: t
                    } of e) {
                    let e = o.queries[t],
                        n = RC(c.currentSubscriptions, t, zC);
                    e && (n.size === 0 ? r.dispatch(l({
                        queryCacheKey: t
                    })) : e.status !== EC && r.dispatch(s(e)));
                }
            });
        }
        return m;
    },
    Kw = ({
        reducerPath: e,
        queryThunk: t,
        api: n,
        refetchQuery: r,
        internalState: i
    }) => {
        let {
            currentPolls: a,
            currentSubscriptions: o
        } = i, s = /* @__PURE__ */ new Set(), c = null, l = (e, r) => {
            (n.internalActions.updateSubscriptionOptions.match(e) || n.internalActions.unsubscribeQueryResult.match(e)) && u(e.payload.queryCacheKey, r), (t.pending.match(e) || t.rejected.match(e) && e.meta.condition) && u(e.meta.arg.queryCacheKey, r), (t.fulfilled.match(e) || t.rejected.match(e) && !e.meta.condition) && d(e.meta.arg, r), n.util.resetApiState.match(e) && (m(), c && = (clearTimeout(c), null), s.clear());
        };

        function u(e, t) {
            s.add(e), c || = setTimeout(() => {
                for (let e of s) f({
                    queryCacheKey: e
                }, t);
                s.clear(), c = null;
            }, 0);
        }

        function d({
            queryCacheKey: t
        }, n) {
            let i = n.getState()[e],
                s = i.queries[t],
                c = o.get(t);
            if (!s || s.status === EC) return;
            let {
                lowestPollingInterval: l,
                skipPollingIfUnfocused: u
            } = h(c);
            if (!Number.isFinite(l)) return;
            let f = a.get(t);
            f ? .timeout && (clearTimeout(f.timeout), f.timeout = void 0);
            let p = Date.now() + l;
            a.set(t, {
                nextPollTimestamp: p,
                pollingInterval: l,
                timeout: setTimeout(() => {
                    (i.config.focused || !u) && n.dispatch(r(s)), d({
                        queryCacheKey: t
                    }, n);
                }, l)
            });
        }

        function f({
            queryCacheKey: t
        }, n) {
            let r = n.getState()[e].queries[t],
                i = o.get(t);
            if (!r || r.status === EC) return;
            let {
                lowestPollingInterval: s
            } = h(i);
            if (!Number.isFinite(s)) {
                p(t);
                return;
            }
            let c = a.get(t),
                l = Date.now() + s;
            (!c || l < c.nextPollTimestamp) && d({
                queryCacheKey: t
            }, n);
        }

        function p(e) {
            let t = a.get(e);
            t ? .timeout && clearTimeout(t.timeout), a.delete(e);
        }

        function m() {
            for (let e of a.keys()) p(e);
        }

        function h(e = /* @__PURE__ */ new Map()) {
            let t = !1,
                n = Infinity;
            for (let r of e.values()) r.pollingInterval && (n = Math.min(r.pollingInterval, n), t = r.skipPollingIfUnfocused || t);
            return {
                lowestPollingInterval: n,
                skipPollingIfUnfocused: t
            };
        }
        return l;
    },
    qw = ({
        api: e,
        context: t,
        queryThunk: n,
        mutationThunk: r
    }) => {
        let i = qa(n, r),
            a = Ja(n, r),
            o = Xa(n, r),
            s = {};
        return (n, r) => {
            if (i(n)) {
                let {
                    requestId: i,
                    arg: {
                        endpointName: a,
                        originalArgs: o
                    }
                } = n.meta, c = dw(t, a), l = c ? .onQueryStarted;
                if (l) {
                    let t = {},
                        n = new Promise((e, n) => {
                            t.resolve = e, t.reject = n;
                        });
                    n.catch(() => {}), s[i] = t;
                    let u = e.endpoints[a].select(ow(c) ? o : i),
                        d = r.dispatch((e, t, n) => n);
                    l(o, {
                        ...r,
                        getCacheEntry: () => u(r.getState()),
                        requestId: i,
                        extra: d,
                        updateCachedData: ow(c) ? (t) => r.dispatch(e.util.updateQueryData(a, o, t)) : void 0,
                        queryFulfilled: n
                    });
                }
            } else if (o(n)) {
                let {
                    requestId: e,
                    baseQueryMeta: t
                } = n.meta;
                s[e] ? .resolve({
                    data: n.payload,
                    meta: t
                }), delete s[e];
            } else if (a(n)) {
                let {
                    requestId: e,
                    rejectedWithValue: t,
                    baseQueryMeta: r
                } = n.meta;
                s[e] ? .reject({
                    error: n.payload ? ? n.error,
                    isUnhandledError: !t,
                    meta: r
                }), delete s[e];
            }
        };
    },
    Jw = ({
        reducerPath: e,
        context: t,
        api: n,
        refetchQuery: r,
        internalState: i
    }) => {
        let {
            removeQueryResult: a
        } = n.internalActions, o = (e, t) => {
            qC.match(e) && s(t, "refetchOnFocus"), YC.match(e) && s(t, "refetchOnReconnect");
        };

        function s(n, o) {
            let s = n.getState()[e],
                c = s.queries,
                l = i.currentSubscriptions;
            t.batch(() => {
                for (let e of l.keys()) {
                    let t = c[e],
                        i = l.get(e);
                    if (!i || !t) continue;
                    let u = [...i.values()];
                    (u.some((e) => e[o] === !0) || u.every((e) => e[o] === void 0) && s.config[o]) && (i.size === 0 ? n.dispatch(a({
                        queryCacheKey: e
                    })) : t.status !== EC && n.dispatch(r(t)));
                }
            });
        }
        return o;
    };

function Yw(e) {
    let {
        reducerPath: t,
        queryThunk: n,
        api: r,
        context: i,
        getInternalState: a
    } = e, {
        apiUid: o
    } = i, s = {
        invalidateTags: Da(`${t}/invalidateTags`)
    }, c = (e) => e.type.startsWith(`${t}/`), l = [
        Ww,
        Vw,
        Gw,
        Kw,
        Uw,
        qw
    ];
    return {
        middleware: (n) => {
            let s = !1,
                d = a(n.dispatch),
                f = {
                    ...e,
                    internalState: d,
                    refetchQuery: u,
                    isThisApiSliceAction: c,
                    mwApi: n
                },
                p = l.map((e) => e(f)),
                m = zw(f),
                h = Jw(f);
            return (e) => (a) => {
                if (!Pr(a)) return e(a);
                s || (s = !0, n.dispatch(r.internalActions.middlewareRegistered(o)));
                let l = {
                        ...n,
                        next: e
                    },
                    u = n.getState(),
                    [d, f] = m(a, l, u),
                    g;
                if (g = d ? e(a) : f, n.getState()[t] && (h(a, l, u), c(a) || i.hasRehydrationInfo(a)))
                    for (let e of p) e(a, l, u);
                return g;
            };
        },
        actions: s
    };

    function u(t) {
        return e.api.endpoints[t.endpointName].initiate(t.originalArgs, {
            subscribe: !1,
            forceRefetch: !0
        });
    }
}
var Xw = /* @__PURE__ */ Symbol(),
    Zw = /* @__PURE__ */ Lw((({
        createSelector: e = xa
    } = {}) => ({
        name: Xw,
        init(t, {
            baseQuery: n,
            tagTypes: r,
            reducerPath: i,
            serializeQueryArgs: a,
            keepUnusedDataFor: o,
            refetchOnMountOrArgChange: s,
            refetchOnFocus: c,
            refetchOnReconnect: l,
            invalidationBehavior: u,
            onSchemaFailure: d,
            catchSchemaFailure: f,
            skipSchemaValidation: p
        }, m) {
            ra();
            let h = (e) => e;
            Object.assign(t, {
                reducerPath: i,
                endpoints: {},
                internalActions: {
                    onOnline: YC,
                    onOffline: XC,
                    onFocus: qC,
                    onFocusLost: JC
                },
                util: {}
            });
            let g = Pw({
                    serializeQueryArgs: a,
                    reducerPath: i,
                    createSelector: e
                }),
                {
                    selectInvalidatedBy: _,
                    selectCachedArgsForQuery: v,
                    buildQuerySelector: y,
                    buildInfiniteQuerySelector: b,
                    buildMutationSelector: x
                } = g;
            Rw(t.util, {
                selectInvalidatedBy: _,
                selectCachedArgsForQuery: v
            });
            let {
                queryThunk: S,
                infiniteQueryThunk: C,
                mutationThunk: w,
                patchQueryData: T,
                updateQueryData: ee,
                upsertQueryData: E,
                prefetch: D,
                buildMatchThunkActions: te
            } = bw({
                baseQuery: n,
                reducerPath: i,
                context: m,
                api: t,
                serializeQueryArgs: a,
                assertTagType: h,
                selectors: g,
                onSchemaFailure: d,
                catchSchemaFailure: f,
                skipSchemaValidation: p
            }), {
                reducer: ne,
                actions: re
            } = kw({
                context: m,
                queryThunk: S,
                infiniteQueryThunk: C,
                mutationThunk: w,
                serializeQueryArgs: a,
                reducerPath: i,
                assertTagType: h,
                config: {
                    refetchOnFocus: c,
                    refetchOnReconnect: l,
                    refetchOnMountOrArgChange: s,
                    keepUnusedDataFor: o,
                    reducerPath: i,
                    invalidationBehavior: u
                }
            });
            Rw(t.util, {
                patchQueryData: T,
                updateQueryData: ee,
                upsertQueryData: E,
                prefetch: D,
                resetApiState: re.resetApiState,
                upsertQueryEntries: re.cacheEntriesUpserted
            }), Rw(t.internalActions, re);
            let ie = /* @__PURE__ */ new WeakMap(),
                ae = (e) => RC(ie, e, () => ({
                    currentSubscriptions: /* @__PURE__ */ new Map(),
                    currentPolls: /* @__PURE__ */ new Map(),
                    runningQueries: /* @__PURE__ */ new Map(),
                    runningMutations: /* @__PURE__ */ new Map()
                })),
                {
                    buildInitiateQuery: O,
                    buildInitiateInfiniteQuery: oe,
                    buildInitiateMutation: k,
                    getRunningMutationThunk: se,
                    getRunningMutationsThunk: ce,
                    getRunningQueriesThunk: le,
                    getRunningQueryThunk: ue
                } = mw({
                    queryThunk: S,
                    mutationThunk: w,
                    infiniteQueryThunk: C,
                    api: t,
                    serializeQueryArgs: a,
                    context: m,
                    getInternalState: ae
                });
            Rw(t.util, {
                getRunningMutationThunk: se,
                getRunningMutationsThunk: ce,
                getRunningQueryThunk: ue,
                getRunningQueriesThunk: le
            });
            let {
                middleware: de,
                actions: fe
            } = Yw({
                reducerPath: i,
                context: m,
                queryThunk: S,
                mutationThunk: w,
                infiniteQueryThunk: C,
                api: t,
                assertTagType: h,
                selectors: g,
                getRunningQueryThunk: ue,
                getInternalState: ae
            });
            return Rw(t.util, fe), Rw(t, {
                reducer: ne,
                middleware: de
            }), {
                name: Xw,
                injectEndpoint(e, n) {
                    let r = t,
                        i = r.endpoints[e] ? ? = {};
                    rw(n) && Rw(i, {
                        name: e,
                        select: y(e, n),
                        initiate: O(e, n)
                    }, te(S, e)), iw(n) && Rw(i, {
                        name: e,
                        select: x(),
                        initiate: k(e)
                    }, te(w, e)), aw(n) && Rw(i, {
                        name: e,
                        select: b(e, n),
                        initiate: oe(e, n)
                    }, te(S, e));
                }
            };
        }
    }))()),
    Qw = new Set(["capture", "variable_auto_capture"]),
    $w = new Set(["list_selection", "capture_guess"]),
    eT = "widget_app_pending";

function tT(e, t) {
    return e !== null && e.placeholder === t.placeholder && e.validationErrorMessage === t.validationErrorMessage && e.isOptional === t.isOptional && e.cancelCaptureResponseId === t.cancelCaptureResponseId && e.cancelCaptureLabel === t.cancelCaptureLabel && e.dataId === t.dataId;
}

function nT(e) {
    let t = W(e ? .message_input);
    return t ? {
        placeholder: G(t.placeholder) ? ? "",
        validationErrorMessage: G(t.validation_error_message) ? ? "",
        isOptional: t.is_optional === !0,
        cancelCaptureResponseId: G(t.cancel_capture_response_id) ? ? "",
        cancelCaptureLabel: G(t.cancel_capture_label) ? ? "",
        dataId: G(e ? .data_id) ? ? ""
    } : null;
}

function rT(e, t) {
    let n = W(e ? .list_selection),
        r = W(W(e ? .lob_list_data) ? .data);
    return {
        resolvesByIndex: t === "list_selection" && r !== null && !Array.isArray(r) && Object.keys(r).length > 0,
        cancelCaptureResponseId: G(n ? .cancel_capture_response_id) ? ? "",
        cancelCaptureLabel: G(n ? .cancel_capture_label) ? ? "",
        isOptional: n ? .is_optional === !0,
        showExitListOptionBlock: n ? .show_exit_list_option_block === !0,
        dataId: G(e ? .data_id) ? ? ""
    };
}
//#endregion
//#region src/objectid.ts
function iT() {
    let e = Math.floor(Date.now() / 1e3).toString(16).padStart(8, "0"),
        t = crypto.getRandomValues(new Uint8Array(8));
    return e + Array.from(t, (e) => e.toString(16).padStart(2, "0")).join("");
}
//#endregion
//#region ../../node_modules/uuid/dist/stringify.js
var X = [];
for (let e = 0; e < 256; ++e) X.push((e + 256).toString(16).slice(1));

function aT(e, t = 0) {
    return (X[e[t + 0]] + X[e[t + 1]] + X[e[t + 2]] + X[e[t + 3]] + "-" + X[e[t + 4]] + X[e[t + 5]] + "-" + X[e[t + 6]] + X[e[t + 7]] + "-" + X[e[t + 8]] + X[e[t + 9]] + "-" + X[e[t + 10]] + X[e[t + 11]] + X[e[t + 12]] + X[e[t + 13]] + X[e[t + 14]] + X[e[t + 15]]).toLowerCase();
}
//#endregion
//#region ../../node_modules/uuid/dist/rng.js
var oT, sT = new Uint8Array(16);

function cT() {
    if (!oT) {
        if (typeof crypto > "u" || !crypto.getRandomValues) throw Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
        oT = crypto.getRandomValues.bind(crypto);
    }
    return oT(sT);
}
var lT = {
    randomUUID: typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto)
};
//#endregion
//#region ../../node_modules/uuid/dist/v4.js
function uT(e, t, n) {
    e || = {};
    let r = e.random ? ? e.rng ? .() ? ? cT();
    if (r.length < 16) throw Error("Random bytes length must be >= 16");
    if (r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, t) {
        if (n || = 0, n < 0 || n + 16 > t.length) throw RangeError(`UUID byte range ${n}:${n + 15} is out of buffer bounds`);
        for (let e = 0; e < 16; ++e) t[n + e] = r[e];
        return t;
    }
    return aT(r);
}

function dT(e, t, n) {
    return lT.randomUUID && !t && !e ? lT.randomUUID() : uT(e, t, n);
}
//#endregion
//#region src/localization.ts
var fT =
    import.meta.url,
    {
        loadLocale: pT,
        loadTranslations: mT,
        loadTranslationsWithLanguage: hT,
        clearLocaleCache: gT
    } = _b(new URL("./locales/", fT));

function _T(e, t, n) {
    let r = e[t];
    if (r == null) return t;
    if (n)
        for (let [e, t] of Object.entries(n)) r = r.replaceAll(`<%= ${e} %>`, t);
    return r;
}
//#endregion
//#region src/api/messaging-fetch.ts
var vT = 1e3;
async function yT(e, t) {
    let n;
    try {
        return await Promise.race([e, new Promise((e) => {
            n = setTimeout(() => e(!1), t);
        })]);
    } catch {
        return !1;
    } finally {
        clearTimeout(n);
    }
}
async function bT(e, t, {
    fetchFn: n = fetch,
    isCurrent: r,
    onPhaseChange: i,
    initiatingSession: a = e.getState().session
} = {}) {
    let o = t.bindLifecycleSignal === !1 ? null : _r(),
        s = vr(),
        c = t.timeoutMs ? ? 2e4,
        l = dc([
            t.signal,
            o,
            t.keepalive ? null : s
        ], c),
        u = {
            dispatch: e.dispatch,
            getState: e.getState,
            signal: o ? ? void 0
        },
        d = Math.min(vT, c / 4),
        f = () => Y(a, e) && !o ? .aborted && !s ? .aborted && r ? .() !== !1,
        p = () => {
            if (!t.keepalive && !Y(a, e) || o ? .aborted || r ? .() === !1) throw Error(cc);
            if (l.signal.aborted) throw new DOMException("The request was aborted", "AbortError");
        },
        m;
    try {
        if (i ? .("auth"), s ? .aborted) throw new DOMException("The widget was destroyed", "AbortError");
        p();
        let r = fc(t.url);
        t.params && (r += `?${new URLSearchParams(t.params)}`);
        let o = t.method ? ? "GET",
            c = dC(r, o, t.simpleGet),
            h = pc(t),
            g = () => {
                p();
                let s;
                return t.body instanceof FormData ? s = t.body : t.body && (s = JSON.stringify(t.body)), i ? .("request"), Promise.race([n.call(globalThis, r, {
                    method: o,
                    headers: t.simpleGet ? h : {
                        ...h,
                        ...fC(Y(a, e) ? e.getState().session : a, c)
                    },
                    credentials: t.simpleGet ? "omit" : t.credentials,
                    ...t.beacon || t.keepalive ? {
                        keepalive: !0
                    } : {},
                    body: s,
                    signal: l.signal
                }), l.timeoutPromise]);
            },
            _, v = () => {
                if (!_) try {
                    _ = g();
                } catch (e) {
                    _ = Promise.reject(e);
                }
                return _;
            },
            y = new Promise((e) => {
                t.keepalive && s && (m = () => {
                    v().catch(() => void 0), e();
                }, s.addEventListener("abort", m, {
                    once: !0
                }));
            });
        if (c && !t.beacon) {
            let e = hC.prepare(a, h, u, l.signal);
            e && await Promise.race([
                yT(e, d),
                l.timeoutPromise,
                y
            ]);
        }
        let b = await v();
        if (b.status === 401 && c && !t.beacon && f()) {
            let t = eC(await Promise.race([b.clone().json().catch(() => null), l.timeoutPromise]));
            if (t && f()) {
                i ? .("auth");
                let n = await Promise.race([hC.renew(e.getState().session, h, u, l.signal, t).catch(() => !1), l.timeoutPromise]);
                p(), n && f() && US(e.getState().session) && (b = await g());
            }
        }
        return b;
    } catch (e) {
        throw l.didTimeout() ? new DOMException("The request timed out", "AbortError") : e;
    } finally {
        m && s ? .removeEventListener("abort", m), l.cleanup();
    }
}
//#endregion
//#region ../../../chat/src/shared/services/zdm-continuity.js
function xT({
    explicitPrivateMode: e,
    enabled: t,
    chatterToken: n,
    retainedChatterToken: r,
    externalUserId: i,
    chatterCreated: a
}) {
    return !!(!e && t && n && (r === n || i === n && a));
}
//#endregion
//#region src/conversation-order.ts
var ST = /^[0-9a-f]{24}$/;

function CT(e, t) {
    return ST.test(e) && ST.test(t);
}

function wT(e, t) {
    return !ST.test(e) || !ST.test(t) ? !1 : e > t;
}
var TT = 8;

function ET(e, t) {
    return t ? e === t ? !0 : CT(e, t) ? e.slice(0, TT) < t.slice(0, TT) : !1 : !1;
}
//#endregion
//#region src/proactive/proactive-slice.ts
var DT = "proactive_conversation";

function OT(e) {
    if (!("proactive_conversation" in e)) return e;
    let t = { ...e
    };
    return delete t[DT], t;
}
var kT = 8,
    AT = {
        messages: [],
        messageDuration: null,
        triggerMethod: null,
        messageDisplayDelay: 0,
        messageFrequency: null,
        intentId: null,
        surfaceSeq: 0,
        currentSurfaceId: null,
        candidates: [],
        displayed: null,
        displaySeq: 0,
        clearSeq: 0,
        isHidden: !1,
        wasDismissed: !1
    },
    jT = N({
        name: "proactive",
        initialState: AT,
        reducers: {
            proactiveMessagesReceived(e, t) {
                e.messages = t.payload.messages, e.messageDuration = t.payload.duration, e.triggerMethod = t.payload.triggerMethod ? ? null, e.messageDisplayDelay = t.payload.displayDelay ? ? 0, e.messageFrequency = t.payload.frequency ? ? null, e.intentId = t.payload.intentId ? ? null;
                let n = ++e.surfaceSeq;
                e.currentSurfaceId = n, e.isHidden = !1;
                let r = t.payload.messages[0] ? .campaignKey;
                if (r) {
                    let {
                        pending: i
                    } = t.payload;
                    e.candidates.push({
                        surfaceId: n,
                        campaignKey: r,
                        pending: i ? {
                            key: i.key,
                            params: i.params,
                            playbookId: i.playbookId ? ? null
                        } : null
                    }), e.candidates.length > kT && e.candidates.splice(0, e.candidates.length - kT);
                }
            },
            proactiveDisplayed(e, t) {
                let n = e.candidates.find((e) => e.surfaceId === t.payload.surfaceId);
                !n || n.campaignKey !== t.payload.campaignKey || (e.displayed = n, e.candidates = e.candidates.filter((e) => e.surfaceId >= t.payload.surfaceId), e.displaySeq += 1);
            },
            proactiveSurfaceReplaced(e, t) {
                e.candidates = e.candidates.filter((e) => e.surfaceId !== t.payload.surfaceId), e.displayed ? .surfaceId === t.payload.surfaceId && (e.displayed = null, e.clearSeq += 1);
            },
            proactiveMessagesHidden(e) {
                e.isHidden = !0, e.wasDismissed = !0, e.displayed = null, e.candidates = [], e.clearSeq += 1;
            },
            proactiveCleared(e) {
                return {
                    ...AT,
                    surfaceSeq: e.surfaceSeq,
                    displaySeq: e.displaySeq,
                    clearSeq: e.clearSeq + 1
                };
            },
            proactiveReset(e) {
                return {
                    ...AT,
                    surfaceSeq: e.surfaceSeq,
                    displaySeq: e.displaySeq,
                    clearSeq: e.clearSeq
                };
            }
        }
    }),
    {
        proactiveMessagesReceived: MT,
        proactiveDisplayed: NT,
        proactiveSurfaceReplaced: PT,
        proactiveMessagesHidden: FT,
        proactiveCleared: IT,
        proactiveReset: LT
    } = jT.actions;
//#endregion
//#region src/proactive/index.ts
function RT(e) {
    return e.session.conversationId !== null && !e.liveAgent.hasConversationEnded;
}
async function zT(e, t, n) {
    let {
        endpoint: r,
        chatterToken: i,
        language: a
    } = e.store.getState().session;
    if (!r || !i) return !1;
    try {
        let o = await e.store.dispatch(wI.endpoints.sendProactiveConversation.initiate({
            endpoint: r,
            chatterToken: i,
            language: a,
            proactiveKey: t,
            messageParameters: n
        }));
        return "error" in o ? (e.onCaptureException(o.error, {
            endpoint: r,
            proactiveKey: t
        }), !1) : (Sr(e.signal), q("proactive_conversation_injected", {
            proactiveKey: t
        }), !0);
    } catch (n) {
        return Cr(n) || e.onCaptureException(n, {
            endpoint: r,
            proactiveKey: t
        }), !1;
    }
}
var BT = N({
        name: "activation",
        initialState: {
            progressTick: 0,
            waitingForVisible: !1
        },
        reducers: {
            activationVisibilityWaitChanged(e, t) {
                e.waitingForVisible = t.payload, e.progressTick += 1;
            },
            activationProgressTicked(e) {
                e.progressTick += 1;
            }
        }
    }),
    {
        activationProgressTicked: VT,
        activationVisibilityWaitChanged: HT
    } = BT.actions,
    UT = "live_chat",
    WT = "live_chat_pending",
    GT = "zendesk_liveagent",
    KT = "salesforce_liveagent",
    qT = "zaw_liveagent",
    JT = "zendesk_support_liveagent",
    YT = "influx",
    XT = "dialpad",
    ZT = "handoff_integration_",
    QT = "file_upload",
    $T = "salesforceFileTransfer",
    eE = 5242880,
    tE = 20971520,
    nE = 52428800,
    rE = 52428800,
    iE = 52428800,
    aE = /* @__PURE__ */ "image/jpeg,image/jpg,image/png,image/gif,image/bmp,image/heic,image/heif,image/svg+xml,image/tiff,image/webp,audio/aac,audio/amr,audio/mpeg,audio/x-m4a,audio/ogg,audio/opus,audio/x-wav,video/3gpp2,video/3gpp,video/mp4,video/x-m4v,video/quicktime,video/mpeg,video/ogg,video/webm,video/x-msvideo,video/x-ms-wmv,text/plain,text/markdown,text/csv,text/calendar,text/vcard,message/rfc822,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.openxmlformats-officedocument.presentationml.slideshow,application/vnd.apple.keynote,application/x-iwork-keynote-sffkey,application/vnd.apple.pages,application/x-iwork-pages-sffpages,application/vnd.apple.numbers,application/x-iwork-numbers-sffnumbers,application/vnd.oasis.opendocument.text,application/xml,application/x-yaml,application/x-7z-compressed,application/zip".split(","),
    oE = /* @__PURE__ */ "3g2.3gp.7z.aac.amr.avi.bmp.csv.doc.docx.eml.gif.har.heic.heif.ics.jfif.jpeg.jpg.json.key.keynote.log.m4a.m4v.md.mov.mp3.mp4.mp4a.mpeg.mpg.mpga.neon.numbers.odt.oga.ogg.ogv.opus.pages.pdf.png.pps.ppsx.ppt.pptx.qt.svg.tif.tiff.txt.vcf.wav.webm.webp.wmv.xls.xlsx.xml.yaml.yml.zip".split("."),
    sE = /* @__PURE__ */ "text/plain,text/csv,message/rfc822,image/png,image/svg+xml,image/jpeg,image/gif,image/heif,image/heic,image/avif,audio/x-wav,audio/x-m4a,audio/mpeg,video/mp4,video/x-m4v,video/quicktime,video/mpeg,application/zip,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.apple.keynote,application/x-iwork-keynote-sffkey,application/vnd.apple.pages,application/x-iwork-pages-sffpages,application/vnd.apple.numbers,application/x-iwork-numbers-sffnumbers".split(","),
    cE = /* @__PURE__ */ "avif.csv.doc.docx.eml.gif.heic.heif.jpeg.jpg.key.keynote.log.m4a.m4v.mov.mp3.mp4.mp4a.mpeg.mpg.numbers.pages.pdf.png.ppt.pptx.svg.txt.wav.xls.xlsx.zip".split(".");

function lE(e, t = {}) {
    let n = Object.values(e),
        r = n.find((e) => e.isActive && !e.isColleague);
    return r || t.handoffOpen ? r : n.find((e) => e.isActive);
}

function uE(e) {
    return e.inLiveChat || e.inPending;
}

function dE(e) {
    return typeof e == "number" && Number.isFinite(e) ? e : null;
}

function fE(e) {
    return typeof e == "string" && e.trim() ? e : null;
}

function pE(e) {
    let t = dE(e.progress),
        n = dE(e.fileSize ? ? e.file_size),
        r = fE(e.fileName ? ? e.file_name),
        i = fE(e.type),
        a = fE(e.sessionId ? ? e.session_id),
        o = fE(e.fileToken ? ? e.file_token),
        s = fE(e.uploadServletUrl ? ? e.upload_servlet_url);
    return {
        ...typeof t == "number" ? {
            progress: Math.max(0, Math.min(100, t))
        } : {},
        ...typeof r == "string" ? {
            fileName: r
        } : {},
        ...typeof n == "number" ? {
            fileSize: n
        } : {},
        ...typeof i == "string" ? {
            type: i
        } : {},
        ...typeof a == "string" ? {
            sessionId: a
        } : {},
        ...typeof o == "string" ? {
            fileToken: o
        } : {},
        ...typeof s == "string" ? {
            uploadServletUrl: s
        } : {}
    };
}

function mE(e) {
    return !!e ? .startsWith(ZT);
}
var hE = [
    GT,
    KT,
    qT,
    JT,
    YT,
    XT
];

function gE(e) {
    return e ? hE.includes(e) || mE(e) : !1;
}

function _E(e) {
    let {
        features: t,
        fileUploadEnabled: n,
        liveAgent: r
    } = e, {
        inLiveChat: i,
        platformName: a
    } = r;
    return !i || !a || !n || t[QT] === !1 ? !1 : a === "zendesk_liveagent" || a === "zaw_liveagent" || a === "zendesk_support_liveagent" ? !0 : a === "salesforce_liveagent" ? !!t[$T] : mE(a);
}

function vE(e) {
    let {
        liveAgent: t,
        file: n
    } = e;
    if (!_E(e)) return !1;
    let {
        platformName: r
    } = t;
    return r ? r === "zendesk_liveagent" || r === "zaw_liveagent" || r === "zendesk_support_liveagent" || mE(r) ? !0 : r === "salesforce_liveagent" ? n.transfer ? .type === "Requested" && !n.isUploading : !1 : !1;
}

function yE(e) {
    return Math.floor(e / 1e6);
}

function bE(e) {
    let t = e.trim(),
        n = t.lastIndexOf(".");
    return n <= 0 || n === t.length - 1 ? null : t.slice(n + 1).toLowerCase();
}

function xE(e, t, n) {
    let r = e.type.trim().toLowerCase();
    if (r && t.includes(r)) return !0;
    let i = bE(e.name ? ? "");
    return i !== null && n.includes(i);
}

function SE(e, t) {
    if (!t) return {
        ok: !1,
        error: {
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: "missing_platform"
            }
        }
    };
    let n = eE,
        r = null,
        i = null;
    if (t === "salesforce_liveagent") n = eE;
    else if (t === "zendesk_liveagent") n = tE;
    else if (t === "zaw_liveagent") n = nE, r = aE, i = oE;
    else if (t === "zendesk_support_liveagent") n = rE, r = aE, i = oE;
    else if (mE(t)) n = iE, r = sE, i = cE;
    else return {
        ok: !1,
        error: {
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: "unsupported_platform",
                platform: t
            }
        }
    };
    return e.size > n ? {
        ok: !1,
        error: {
            errorKey: "FILE_UPLOAD_EXCEED_SIZE_LIMIT",
            errorData: {
                maxFileSizeInMB: yE(n)
            }
        }
    } : r && i && !xE(e, r, i) ? {
        ok: !1,
        error: {
            errorKey: "FILE_UPLOAD_UNSUPPORTED_TYPE",
            errorData: {}
        }
    } : {
        ok: !0
    };
}
var CE = {
        sdkInitialized: !1,
        disconnected: !1,
        reconnecting: !1,
        sessionId: null,
        primarySessionId: null,
        lastProcessedTimestamp: null,
        departmentStatus: null,
        departmentId: null,
        tags: null,
        previousTags: null,
        webhookRetryMessageKey: null,
        fatalRequestErrorReached: !1,
        fatalRequestErrorPending: !1,
        fatalRequestErrorCancelFailed: !1,
        chatClosed: !1,
        endDelivered: !1
    },
    wE = {
        initializationStatus: 0,
        initialized: !1,
        disconnected: !1,
        reconnecting: !1,
        conversationId: null
    },
    TE = {
        isUploading: !1,
        uploadError: null,
        transfer: null,
        lastFile: null
    },
    EE = {
        visible: !1,
        pending: !1
    },
    DE = {
        agentAssignmentSeq: 0,
        retryDialogOperationSeq: 0,
        zendeskOperationSeq: 0,
        agentsInactiveByChatterSeq: 0,
        queueCancelSeq: 0,
        integrationCommandSeq: 0
    },
    OE = Object.keys(DE),
    kE = {
        ...DE,
        inLiveChat: !1,
        inPending: !1,
        isActive: !1,
        hasConversationEnded: !1,
        endedConversationReopenCandidateId: null,
        endedConversationReopenCandidateSurfaceIds: [],
        endedConversationReopenCandidateToken: null,
        endedConversationReopenAfterCursor: null,
        conversationEndedByChatter: !1,
        hadHandoff: !1,
        handoffOpenedThisPage: !1,
        liveChatEndedInConversation: !1,
        endChatHandled: !1,
        platformName: null,
        lastNonNullHandoffPlatformName: null,
        platformDepartmentId: null,
        queuePosition: null,
        queueWaitMinutes: null,
        agentAssignmentKnown: !0,
        agentRosterRecovery: null,
        agents: {},
        restoredAgentIds: {},
        zendesk: CE,
        zendeskMessaging: wE,
        file: TE,
        lastHandoffEvent: null,
        retryRequestedCount: 0,
        retryDialog: EE,
        inactiveRetryPending: !1,
        queueCancelPending: !1,
        lastIntegrationCommand: null
    };

function AE(e, {
    stateType: t,
    inState: n
}) {
    return t ? t === "live_chat" ? n : e : !1;
}

function jE(e, {
    stateType: t,
    inState: n
}) {
    return t ? t === "live_chat_pending" ? n : e : !1;
}

function ME(e) {
    e.zendeskOperationSeq += 1, e.zendesk.webhookRetryMessageKey = null, e.lastNonNullHandoffPlatformName = null, e.agentAssignmentSeq += 1, e.agentAssignmentKnown = !0, e.zendesk.chatClosed = !1, e.zendesk.endDelivered = !1, e.zendesk.fatalRequestErrorReached = !1, e.zendesk.fatalRequestErrorPending = !1, e.zendesk.fatalRequestErrorCancelFailed = !1;
}
var NE = N({
        name: "liveAgent",
        initialState: kE,
        reducers: {
            liveAgentConversationStateChanged(e, t) {
                let {
                    inState: n,
                    stateData: r
                } = t.payload, i = e.inLiveChat, a = uE(e);
                e.inLiveChat = AE(e.inLiveChat, t.payload), e.inPending = jE(e.inPending, t.payload), (e.inLiveChat || e.inPending) && (e.handoffOpenedThisPage = !0), e.isActive = uE(e), a !== e.isActive && (e.lastNonNullHandoffPlatformName = e.isActive ? e.platformName : null), e.inLiveChat ? e.liveChatEndedInConversation = !1 : i && !e.isActive && (e.liveChatEndedInConversation = !0, e.agentAssignmentSeq += 1), a && !e.isActive && (e.zendesk.webhookRetryMessageKey = null, e.queuePosition = null, e.queueWaitMinutes = null), n && (e.hadHandoff = !0, e.retryDialog.visible = !1, e.retryDialog.pending = !1, e.inactiveRetryPending = !1);
                let o = dE(r ? .queue_position ? ? r ? .queuePosition);
                if (o !== null && r ? .queue_unit !== "time" && (e.queuePosition = o, e.queueWaitMinutes = null), !e.isActive && Object.keys(e.agents).length > 0)
                    for (let t of Object.values(e.agents)) t.isColleague || (t.isActive = !1, t.isTyping = !1);
            },
            liveAgentPlatformUpdated(e, t) {
                t.payload.platformName !== null && (e.lastNonNullHandoffPlatformName !== null && e.lastNonNullHandoffPlatformName !== t.payload.platformName && (e.zendesk.webhookRetryMessageKey = null), e.lastNonNullHandoffPlatformName = t.payload.platformName), e.platformName = t.payload.platformName, typeof t.payload.departmentId == "number" ? e.platformDepartmentId = t.payload.departmentId : t.payload.departmentId === null && (e.platformDepartmentId = null);
            },
            liveAgentQueuePositionUpdated(e, t) {
                e.queuePosition = t.payload, e.queueWaitMinutes = null;
            },
            liveAgentQueueWaitUpdated(e, t) {
                e.queueWaitMinutes = t.payload, e.queuePosition = null;
            },
            liveAgentConversationEndedByUserSet(e, t) {
                e.hasConversationEnded = t.payload, e.conversationEndedByChatter = t.payload, e.endedConversationReopenCandidateId = null, e.endedConversationReopenCandidateSurfaceIds = [], e.endedConversationReopenCandidateToken = null, e.endedConversationReopenAfterCursor = null, t.payload && (e.retryDialog.visible = !1, e.retryDialog.pending = !1, e.inactiveRetryPending = !1);
            },
            liveChatEndedInConversationCleared(e) {
                e.liveChatEndedInConversation = !1;
            },
            liveAgentEndChatHandledSet(e, t) {
                e.endChatHandled = t.payload;
            },
            liveAgentConversationEndedByServer(e) {
                e.hasConversationEnded = !0;
                for (let t of Object.values(e.agents)) t.isActive = !1, t.isTyping = !1;
                e.endedConversationReopenCandidateId = null, e.endedConversationReopenCandidateSurfaceIds = [], e.endedConversationReopenCandidateToken = null, e.endedConversationReopenAfterCursor = null, e.retryDialog.visible = !1, e.retryDialog.pending = !1, e.inactiveRetryPending = !1, e.zendesk.webhookRetryMessageKey = null;
            },
            liveAgentInjectionPostedPastEndedConversation(e, t) {
                if (e.hasConversationEnded) {
                    let {
                        conversationId: n,
                        surfaceId: r
                    } = t.payload;
                    e.endedConversationReopenCandidateId !== n && (e.endedConversationReopenCandidateId = n, e.endedConversationReopenCandidateSurfaceIds = [], e.endedConversationReopenCandidateToken = r, e.endedConversationReopenAfterCursor = t.payload.afterCursor ? ? null), e.endedConversationReopenCandidateSurfaceIds.includes(r) || e.endedConversationReopenCandidateSurfaceIds.push(r);
                }
            },
            liveAgentInjectionCandidateCleared(e, t) {
                e.endedConversationReopenCandidateId === t.payload.conversationId && (e.endedConversationReopenCandidateSurfaceIds = e.endedConversationReopenCandidateSurfaceIds.filter((e) => e !== t.payload.surfaceId), e.endedConversationReopenCandidateSurfaceIds.length === 0 && (e.endedConversationReopenCandidateId = null, e.endedConversationReopenCandidateToken = null, e.endedConversationReopenAfterCursor = null));
            },
            liveAgentAgentUpserted(e, t) {
                let n = e.agents[t.payload.id],
                    {
                        isActive: r,
                        isTyping: i
                    } = t.payload,
                    a = t.payload.isColleague ? ? n ? .isColleague;
                e.agentAssignmentSeq += 1, e.agentAssignmentKnown = !0, e.agents[t.payload.id] = {
                    id: t.payload.id,
                    name: t.payload.name,
                    imageUrl: t.payload.imageUrl ? ? n ? .imageUrl ? ? null,
                    defaultImage: t.payload.defaultImage ? ? n ? .defaultImage ? ? !1,
                    isActive: typeof r == "boolean" ? r : n ? .isActive ? ? !0,
                    isTyping: typeof i == "boolean" ? i : n ? .isTyping ? ? !1,
                    ...a ? {
                        isColleague: !0
                    } : {}
                }, t.payload.isRestored ? e.restoredAgentIds[t.payload.id] = !0 : delete e.restoredAgentIds[t.payload.id];
            },
            liveAgentAgentAssignmentHydrationStarted(e) {
                e.agentAssignmentKnown = !1, e.agentRosterRecovery = null;
                for (let t of Object.values(e.agents)) t.isTyping = !1;
            },
            liveAgentAgentAssignmentRestored(e, t) {
                e.agentAssignmentKnown || (e.agents = Object.fromEntries(t.payload.agents.map((e) => [e.id, { ...e
                }])), e.restoredAgentIds = Object.fromEntries(t.payload.agents.map((e) => [e.id, !0])), e.agentAssignmentSeq += 1, e.agentAssignmentKnown = !0, e.agentRosterRecovery = t.payload.rosterCutoff === void 0 ? null : {
                    ...t.payload.rosterCutoff,
                    agentAssignmentSeq: e.agentAssignmentSeq
                });
            },
            liveAgentAgentRosterRecoveryCleared(e, t) {
                e.agentRosterRecovery ? .agentAssignmentSeq === t.payload && (e.agentRosterRecovery = null);
            },
            liveAgentAgentTypingSet(e, t) {
                let n = e.agents[t.payload.id];
                n && (n.isTyping = t.payload.isTyping);
            },
            liveAgentAgentInactive(e, t) {
                e.agentAssignmentSeq += 1, e.agentAssignmentKnown = !0;
                let n = e.agents[t.payload];
                n && (n.isActive = !1, n.isTyping = !1);
            },
            liveAgentAgentRemoved(e, t) {
                e.agentAssignmentSeq += 1, delete e.agents[t.payload], delete e.restoredAgentIds[t.payload];
            },
            liveAgentAgentsInactive(e) {
                e.agentAssignmentSeq += 1;
                for (let t of Object.values(e.agents)) t.isActive = !1, t.isTyping = !1;
                e.agentsInactiveByChatterSeq += 1;
            },
            zendeskStatePatched(e, t) {
                e.zendesk = {
                    ...e.zendesk,
                    ...t.payload
                }, t.payload.fatalRequestErrorReached === !0 && (e.retryDialog.visible = !1, e.retryDialog.pending = !1, e.inactiveRetryPending = !1), t.payload.chatClosed === !0 && (e.inactiveRetryPending = !1);
            },
            zendeskStateCleared(e) {
                let {
                    previousTags: t,
                    chatClosed: n,
                    endDelivered: r,
                    fatalRequestErrorReached: i,
                    fatalRequestErrorPending: a,
                    fatalRequestErrorCancelFailed: o
                } = e.zendesk;
                e.zendesk = {
                    ...CE,
                    previousTags: t,
                    chatClosed: n,
                    endDelivered: r,
                    fatalRequestErrorReached: i,
                    fatalRequestErrorPending: a,
                    fatalRequestErrorCancelFailed: o
                };
            },
            zendeskMessagingStatePatched(e, t) {
                e.zendeskMessaging = {
                    ...e.zendeskMessaging,
                    ...t.payload
                };
            },
            fileTransferUpdated(e, t) {
                if (!t.payload) {
                    e.file.transfer = null;
                    return;
                }
                e.file.transfer = pE(t.payload);
            },
            fileUploadStarted(e, t) {
                e.file.isUploading = !0, e.file.uploadError = null, e.file.lastFile = t.payload, e.file.transfer = {
                    ...e.file.transfer,
                    fileName: t.payload.fileName,
                    fileSize: t.payload.fileSize
                };
            },
            fileUploadCompleted(e) {
                e.file.isUploading = !1;
            },
            fileUploadFailed(e, t) {
                e.file.isUploading = !1, e.file.uploadError = t.payload;
            },
            fileUploadErrorCleared(e) {
                e.file.uploadError = null;
            },
            fileUploadReset(e) {
                e.file = TE;
            },
            liveAgentHandoffEventReceived(e, t) {
                e.lastHandoffEvent = t.payload;
            },
            liveAgentInactiveRetryPendingSet(e, t) {
                e.inactiveRetryPending = t.payload;
            },
            liveAgentHandoffRetryRequested(e) {
                e.retryRequestedCount += 1, (e.isActive || e.inactiveRetryPending) && !e.hasConversationEnded && !e.zendesk.chatClosed && !e.zendesk.fatalRequestErrorReached && (e.retryDialog.visible = !0);
            },
            liveAgentRetryDialogHidden(e) {
                e.retryDialog.visible = !1, e.retryDialog.pending = !1, e.inactiveRetryPending = !1;
            },
            liveAgentRetryDialogPendingSet(e, t) {
                e.retryDialog.pending = t.payload, t.payload && (e.retryDialogOperationSeq += 1);
            },
            liveAgentQueueCancelPendingSet(e, t) {
                e.queueCancelPending = t.payload, t.payload && (e.queueCancelSeq += 1);
            },
            liveAgentHandoffStarted(e) {
                ME(e);
            },
            liveAgentFatalHandoffCancelStarted(e) {
                e.zendeskOperationSeq += 1, e.zendesk.fatalRequestErrorPending = !0, e.zendesk.fatalRequestErrorCancelFailed = !1;
            },
            liveAgentIntegrationCommandRequested(e, t) {
                e.integrationCommandSeq += 1, e.lastIntegrationCommand = t.payload;
            },
            liveAgentReset(e, t) {
                let n = {
                    ...kE,
                    agents: {},
                    zendesk: { ...CE
                    },
                    zendeskMessaging: { ...wE
                    },
                    file: { ...TE
                    },
                    retryDialog: { ...EE
                    }
                };
                for (let t of OE) n[t] = e[t];
                return n.handoffOpenedThisPage = t.payload.keepPageLatch && e.handoffOpenedThisPage, n.zendeskOperationSeq += 1, n.agentAssignmentSeq += 1, n;
            }
        }
    }),
    {
        fileTransferUpdated: PE,
        fileUploadCompleted: FE,
        fileUploadErrorCleared: IE,
        fileUploadFailed: LE,
        fileUploadReset: RE,
        fileUploadStarted: zE,
        liveAgentAgentAssignmentHydrationStarted: BE,
        liveAgentAgentAssignmentRestored: VE,
        liveAgentAgentInactive: HE,
        liveAgentAgentRemoved: UE,
        liveAgentAgentRosterRecoveryCleared: WE,
        liveAgentAgentTypingSet: GE,
        liveAgentAgentUpserted: KE,
        liveAgentAgentsInactive: qE,
        liveAgentConversationEndedByServer: JE,
        liveAgentConversationEndedByUserSet: YE,
        liveAgentEndChatHandledSet: XE,
        liveAgentInjectionCandidateCleared: ZE,
        liveAgentInjectionPostedPastEndedConversation: QE,
        liveChatEndedInConversationCleared: $E,
        liveAgentConversationStateChanged: eD,
        liveAgentHandoffEventReceived: tD,
        liveAgentHandoffRetryRequested: nD,
        liveAgentHandoffStarted: rD,
        liveAgentFatalHandoffCancelStarted: iD,
        liveAgentInactiveRetryPendingSet: aD,
        liveAgentIntegrationCommandRequested: oD,
        liveAgentPlatformUpdated: sD,
        liveAgentQueueCancelPendingSet: cD,
        liveAgentQueuePositionUpdated: lD,
        liveAgentQueueWaitUpdated: uD,
        liveAgentRetryDialogHidden: dD,
        liveAgentRetryDialogPendingSet: fD,
        liveAgentReset: pD,
        zendeskMessagingStatePatched: mD,
        zendeskStateCleared: hD,
        zendeskStatePatched: Z
    } = NE.actions,
    gD = new Set([
        "unified_reasoner_generation_started",
        "unified_reasoner_generation_finished",
        "playbook_step_executing",
        "playbook_step_finished",
        "post_sign_in_started",
        "post_sign_in_finished"
    ]);

function _D(e) {
    return e !== void 0 && gD.has(e);
}

function vD(e) {
    return e === "post_sign_in_started" || e === "post_sign_in_finished";
}

function yD(e) {
    return e.sender === "user" && e.type !== "presence";
}

function bD(e) {
    return e.type === "quick_replies" || e.type === "options_message";
}

function xD(e, t) {
    let n = uy(t.name),
        r = n ? {
            ...t,
            fileType: n
        } : t,
        i = e.attachmentRejection;
    if (!(t.batchId !== void 0 && i ? .batchId === t.batchId)) {
        e.attachmentRejection = r;
        return;
    }
    let {
        name: a,
        fileType: o,
        ...s
    } = r;
    e.attachmentRejection = n && i ? .fileType === n ? {
        ...s,
        fileType: n
    } : s;
}
var SD = {
    messages: [],
    retryableMessageSends: {},
    retainedZendeskMessageIds: {},
    isConversationActive: !1,
    userHasSentInCurrentConversation: !1,
    acceptedUserSendSeq: 0,
    isTyping: !1,
    isSending: !1,
    isGenerating: !1,
    isUnifiedReasonerGenerating: !1,
    unifiedReasonerEvidenceCursor: null,
    unifiedReasonerEvidenceCreatedAt: null,
    isUnifiedReasonerBroadFallbackOwned: !1,
    hasPostReasonerOrdinaryGeneration: !1,
    inConversationState: !1,
    inLiveChat: !1,
    inLiveChatPending: !1,
    error: null,
    errorSeq: 0,
    errorClientKey: null,
    historyConversationIds: [],
    historyConversationIndex: 0,
    historyConversationCursor: null,
    historyPageBackoff: null,
    previousMessagesLoadSeq: 0,
    playbookStepExecuting: !1,
    playbookGateEvidenceCursor: null,
    playbookGateEvidenceCreatedAt: null,
    answeredInteractiveMessageIds: [],
    interactiveAnswerOwners: {},
    withdrawnAnswerMessageIds: [],
    canLoadMore: !1,
    loadingPreviousMessages: !1,
    composerText: null,
    composerTextRevisionSeq: 0,
    stagedAttachments: [],
    attachmentRejection: null,
    isBotTyping: !1,
    captureData: null,
    listSelectionData: null,
    widgetAppPending: !1,
    csatAutoTrigger: !1,
    csatAutoTriggerConversationId: null,
    csatIsOpen: !1,
    csatSubmitError: null,
    csatSubmitErrorSurveyType: null,
    csatSubmitErrorConversationId: null,
    csatSubmitErrorSeq: 0,
    csatInlineSubmitErrorIds: [],
    csatSubmitSuccessSeq: 0,
    csatSubmitSuccessSurveyType: null,
    csatSubmitSuccessConversationId: null,
    csatSubmitSuccessSameGeneration: void 0,
    endChatCompletedSeq: 0,
    csatSettings: null,
    csatBotSettings: null,
    csatEndChatEligibility: {
        status: "idle",
        eligible: null,
        surveyTarget: null,
        requestId: null
    },
    csatEndChatEligibilitySeq: 0,
    customJsEventSeq: 0,
    customJsEventPayload: void 0,
    serverProgressSeq: 0,
    sentMessageAck: null,
    messageAppendSeq: 0,
    recentMessagesLoadSeq: 0,
    lastAppendedMessage: null,
    caughtUpAppendSeq: 0,
    lastCaughtUpMessages: [],
    reactions: {},
    messageCursorByConversation: {},
    lastReadCursorByConversation: {}
};

function CD(e, t) {
    if (e.push(t), e.length > 500) {
        let t = e.length - 500;
        e.splice(0, t);
    }
    return e;
}

function wD(e, t) {
    let n = t.cursor;
    if (typeof n == "string") {
        let r = e.findIndex((e) => typeof e.cursor == "string" && e.cursor > n);
        if (r !== -1) {
            e.splice(r, 0, t), e.length > 500 && e.splice(0, e.length - 500);
            return;
        }
    }
    CD(e, t);
}

function TD(e, t) {
    return e.findIndex((e) => e.isStreaming === !0 && (e.streamId === t || e.id === t));
}

function ED(e, t) {
    let n = {
        ...t,
        ...t.buttonType === void 0 && e.buttonType !== void 0 ? {
            buttonType: e.buttonType
        } : {},
        ...t.origin === void 0 && e.origin !== void 0 ? {
            origin: e.origin
        } : {}
    };
    return n.type === "downloadable" && e.type === "downloadable" && n.attachmentGroupId === void 0 && e.attachmentGroupId !== void 0 ? {
        ...n,
        attachmentGroupId: e.attachmentGroupId
    } : n;
}

function DD(e, t) {
    return e.type === "csat" && t.type === "csat" && e.revision !== void 0 && t.revision !== void 0 && t.revision <= e.revision ? e : {
        ...ED(e, t),
        clientKey: e.clientKey ? ? e.id
    };
}

function OD(e, t) {
    let n = e.findIndex((e) => e.id === t.id);
    if (n !== -1) {
        let r = e[n].id;
        return e[n] = DD(e[n], t), r;
    }
    if (t.tempMessageUuid) {
        let n = e.findIndex((e) => e.cursor === void 0 && e.tempMessageUuid === t.tempMessageUuid);
        if (n !== -1) {
            let r = e[n].id;
            return e[n] = DD(e[n], t), r;
        }
    }
    if (t.sender === "user" && t.type === "text" && typeof t.cursor == "string") {
        let n = t.body.trim(),
            r = -1;
        for (let t = e.length - 1; t >= 0; --t) {
            let i = e[t];
            if (i.sender === "user" && i.type === "text" && i.cursor === void 0 && i.body.trim() === n) {
                r = t;
                break;
            }
        }
        if (r !== -1) {
            let n = e[r].id;
            return e[r] = DD(e[r], t), n;
        }
    }
    let r = TD(e, t.streamId ? ? t.id);
    if (r !== -1) {
        let n = e[r].id;
        return e[r] = DD(e[r], t), n;
    }
    return wD(e, t), null;
}

function kD(e, t) {
    t.reaction !== void 0 && (e[t.id] = t.reaction);
}

function AD(e, t, n) {
    if (!t || typeof n != "string" || n.length === 0) return;
    let r = e[t];
    (r === void 0 || n > r) && (e[t] = n);
}

function jD(e) {
    return e.type === "presence" && Xb(e.event);
}

function MD(e) {
    return e.type === "csat" && Hv(e.surveyType) && !e.submitted && e.score === null;
}

function ND(e, t) {
    MD(t) && (e.csatAutoTriggerConversationId = t.conversationId ? ? null, e.csatAutoTrigger = !0);
}

function PD(e) {
    return e.type === "csat" && e.sender === "user";
}

function FD(e) {
    for (let t = e.length - 1; t >= 0; --t) {
        let n = e[t];
        if (jD(n)) return !1;
        if (n.type !== "presence" && !PD(n)) return !0;
    }
    return !1;
}

function ID(e) {
    return e.some((e) => e.sender === "user" && e.type !== "presence" && !PD(e));
}

function LD(e, t) {
    for (let n of t) {
        let t = e.playbookGateEvidenceCursor;
        if (t === n.cursor) continue;
        let r = e.playbookGateEvidenceCreatedAt;
        (t === null || (r !== null && n.createdAt !== void 0 ? n.createdAt > r || n.createdAt === r && n.cursor > t : n.cursor > t)) && (e.playbookStepExecuting = n.executing, e.playbookGateEvidenceCursor = n.cursor, e.playbookGateEvidenceCreatedAt = n.createdAt ? ? null);
    }
}

function RD(e, t) {
    for (let n of t) {
        let t = e.unifiedReasonerEvidenceCursor;
        if (t === n.cursor) continue;
        let r = e.unifiedReasonerEvidenceCreatedAt;
        (t === null || (r !== null && n.createdAt !== void 0 ? n.createdAt > r || n.createdAt === r && n.cursor > t : n.cursor > t)) && (n.generating ? QD(e) : $D(e), e.unifiedReasonerEvidenceCursor = n.cursor, e.unifiedReasonerEvidenceCreatedAt = n.createdAt ? ? null);
    }
}

function zD(e, t) {
    if (!e.isUnifiedReasonerGenerating || e.unifiedReasonerEvidenceCursor === null) return !1;
    for (let n of t) {
        if (e.unifiedReasonerEvidenceCreatedAt !== null && Number.isFinite(n.timestamp)) {
            if (e.unifiedReasonerEvidenceCreatedAt > n.timestamp) continue;
            if (e.unifiedReasonerEvidenceCreatedAt < n.timestamp) return !1;
        }
        if (typeof n.cursor != "string" || n.cursor >= e.unifiedReasonerEvidenceCursor) return !1;
    }
    return !0;
}

function BD(e, t) {
    return t ? e.map((e) => e.conversationId ? e : {
        ...e,
        conversationId: t
    }) : e;
}

function VD(e) {
    return e.type === "text" && e.sender === "user" && e.cursor === void 0 && typeof e.tempMessageUuid == "string" && e.tempMessageUuid.length > 0;
}

function HD(e) {
    return e.type === "text" && e.sender === "user" && typeof e.cursor == "string";
}

function UD(e) {
    let t = new Set(e.messages.filter(VD).map((e) => e.id));
    for (let n of Object.keys(e.retainedZendeskMessageIds)) t.has(n) || delete e.retainedZendeskMessageIds[n];
}

function WD(e, t, n) {
    let r = [...e],
        i = new Set(e.map((e) => e.id)),
        a = new Map(n.map((e, t) => [e.id, t])),
        o = [...t].sort((e, t) => (a.get(e.id) ? ? 2 ** 53 - 1) - (a.get(t.id) ? ? 2 ** 53 - 1));
    for (let e of o) {
        if (e.cursor !== void 0) {
            r.push(e);
            continue;
        }
        let t = a.get(e.id) ? ? -1,
            o;
        for (let e = t + 1; e < n.length; e += 1)
            if (i.has(n[e].id)) {
                o = n[e].id;
                break;
            }
        if (o) {
            let t = r.findIndex((e) => e.id === o);
            if (t !== -1) {
                r.splice(t, 0, e);
                continue;
            }
        }
        let s = r.findIndex(jD),
            c = s === -1 ? r.length : s;
        r.splice(c, 0, e);
    }
    return r;
}

function GD(e) {
    e.inConversationState = e.inLiveChat || e.inLiveChatPending || e.captureData !== null || e.listSelectionData !== null;
}

function KD(e) {
    for (let t of e.messages) e.retryableMessageSends[t.id] ? .transport === "zendesk" && (t.type === "text" && (t.deliveryStatus = "failed", delete t.isRetryable), delete e.retryableMessageSends[t.id]);
}

function qD(e) {
    e.isGenerating = !1, e.isUnifiedReasonerGenerating = !1, e.isUnifiedReasonerBroadFallbackOwned = !1, e.hasPostReasonerOrdinaryGeneration = !1;
}

function JD(e) {
    e.isGenerating = !1, e.isUnifiedReasonerBroadFallbackOwned = !1, e.hasPostReasonerOrdinaryGeneration = !1;
}

function YD(e) {
    e.isUnifiedReasonerGenerating && e.hasPostReasonerOrdinaryGeneration || JD(e);
}

function XD(e) {
    e.isUnifiedReasonerGenerating && (e.isUnifiedReasonerBroadFallbackOwned = !1, e.hasPostReasonerOrdinaryGeneration = !0), e.isGenerating = !0;
}

function ZD(e) {
    e.isGenerating = !0;
}

function QD(e) {
    e.isUnifiedReasonerGenerating || = (e.isUnifiedReasonerBroadFallbackOwned = !e.isGenerating, e.hasPostReasonerOrdinaryGeneration = !1, e.isGenerating = !0, !0);
}

function $D(e) {
    e.isUnifiedReasonerGenerating && (e.isUnifiedReasonerGenerating = !1, e.isUnifiedReasonerBroadFallbackOwned && (e.isGenerating = !1), e.isUnifiedReasonerBroadFallbackOwned = !1, e.hasPostReasonerOrdinaryGeneration = !1);
}

function eO(e, t) {
    t.sender === "user" && t.type !== "presence" && !e.messages.some((e) => e.id === t.id) && (e.acceptedUserSendSeq += 1);
    let n = VD(t) ? e.messages.findIndex((e) => HD(e) && e.tempMessageUuid === t.tempMessageUuid) : -1,
        r = n === -1;
    return r ? (CD(e.messages, t), e.messageAppendSeq += 1, e.lastAppendedMessage = t) : e.messages[n] = ED(t, e.messages[n]), UD(e), e.isConversationActive = FD(e.messages), t.type !== "presence" && (e.userHasSentInCurrentConversation = !0), e.isSending = !1, e.isTyping = !e.inLiveChat, e.inLiveChat ? qD(e) : XD(e), r;
}

function tO(e, t) {
    for (let n of t) delete e.interactiveAnswerOwners[n], e.answeredInteractiveMessageIds.includes(n) || e.answeredInteractiveMessageIds.push(n);
}
var nO = N({
        name: "chat",
        initialState: SD,
        reducers: {
            messageReceived: {
                reducer(e, t) {
                    let n = e.messages.some((e) => e.id === t.payload.id);
                    OD(e.messages, t.payload), UD(e), n || (e.messageAppendSeq += 1, e.lastAppendedMessage = t.payload), n || ND(e, t.payload), e.isConversationActive = FD(e.messages), t.payload.sender === "user" && t.payload.type !== "presence" && !PD(t.payload) && (e.userHasSentInCurrentConversation = !0), t.meta ? .isFinal !== !1 && (e.isTyping = !1, YD(e), e.isBotTyping = !1);
                },
                prepare(e, t) {
                    return {
                        payload: e,
                        meta: {
                            isFinal: t ? .isFinal !== !1
                        }
                    };
                }
            },
            userMessageEchoed(e, t) {
                let n = OD(e.messages, t.payload);
                PD(t.payload) || (n !== null && (delete e.retryableMessageSends[n], HD(t.payload) && delete e.retainedZendeskMessageIds[n]), UD(e), e.isConversationActive = FD(e.messages), t.payload.type !== "presence" && (e.userHasSentInCurrentConversation = !0));
            },
            authLinkExpiryUpdated(e, t) {
                let n = e.messages.find((e) => e.id === t.payload.id);
                n && n.type === "sign_in" && (n.authLinkExpired = t.payload.expired);
            },
            botTypingSet(e, t) {
                e.isBotTyping = t.payload;
            },
            turnSettledWithoutMessages(e) {
                e.messages.some((e) => e.isStreaming === !0) || (e.isTyping = !1, YD(e)), e.isBotTyping = !1;
            },
            messageSent(e, t) {
                eO(e, t.payload);
            },
            zendeskMessageSent(e, t) {
                eO(e, t.payload) && VD(t.payload) && (e.retainedZendeskMessageIds[t.payload.id] = !0);
            },
            zendeskMessageRetentionSettled(e, t) {
                delete e.retainedZendeskMessageIds[t.payload];
            },
            secretMessageSent(e) {
                e.acceptedUserSendSeq += 1, e.isSending = !1, e.userHasSentInCurrentConversation = !0, e.isTyping = !0, XD(e);
            },
            messageSendAcknowledged(e, t) {
                let n = typeof t.payload == "string" ? {
                    id: t.payload
                } : t.payload;
                e.sentMessageAck = {
                    ...n,
                    seq: (e.sentMessageAck ? .seq ? ? 0) + 1
                };
                let r = e.messages.find((e) => e.id === n.id);
                r ? .type === "text" && (delete r.deliveryStatus, delete r.isRetryable), delete e.retryableMessageSends[n.id];
            },
            messageDeliveryFailed(e, t) {
                let {
                    messageId: n,
                    send: r
                } = t.payload, i = e.messages.find((e) => e.id === n);
                i ? .type === "text" && i.sender === "user" && (i.deliveryStatus = "failed", i.isRetryable = !0, e.retryableMessageSends[n] = r, e.isTyping = !1, JD(e));
            },
            messageRetryStarted(e, t) {
                let n = e.messages.find((e) => e.id === t.payload);
                n ? .type === "text" && n.sender === "user" && n.deliveryStatus === "failed" && n.isRetryable === !0 && e.retryableMessageSends[t.payload] && (e.acceptedUserSendSeq += 1), n ? .deliveryStatus === "failed" && delete n.isRetryable, n && VD(n) && e.retryableMessageSends[t.payload] ? .transport === "zendesk" && (e.retainedZendeskMessageIds[t.payload] = !0), e.error = null, e.errorClientKey = null;
            },
            messageDeliveryUnconfirmed(e, t) {
                let n = e.messages.find((e) => e.id === t.payload);
                (n ? .type === "text" || n ? .type === "downloadable") && n.sender === "user" && (n.deliveryStatus = "failed", delete n.isRetryable, e.isTyping = !1, JD(e)), delete e.retryableMessageSends[t.payload];
            },
            groupDeliveryAbandoned(e, t) {
                for (let n of t.payload) {
                    let t = e.messages.find((e) => e.id === n);
                    (t ? .type === "text" || t ? .type === "downloadable") && t.sender === "user" && (t.deliveryStatus = "failed", delete t.isRetryable), delete e.retryableMessageSends[n];
                }
            },
            messageRetryAbandoned(e, t) {
                let {
                    messageId: n,
                    tempMessageUuid: r
                } = t.payload, i = e.messages.find((e) => e.id === n && e.tempMessageUuid === r);
                i ? .type === "text" && i.sender === "user" && (i.deliveryStatus = "failed", i.isRetryable = e.retryableMessageSends[n] ? .tempMessageUuid === r);
            },
            sendingStarted(e) {
                e.isSending = !0, e.error = null, e.errorClientKey = null;
            },
            sendingFailed: {
                prepare(e, t) {
                    return {
                        payload: e,
                        meta: {
                            clientKey: t ? ? null
                        }
                    };
                },
                reducer(e, t) {
                    e.isSending = !1, e.error = t.payload, e.errorSeq += 1, e.errorClientKey = t.meta.clientKey, e.isTyping = !1, JD(e);
                }
            },
            messageSendDropped: {
                prepare(e, t) {
                    return {
                        payload: e,
                        meta: {
                            clientKey: t ? ? null
                        }
                    };
                },
                reducer(e, t) {
                    e.error = t.payload, e.errorSeq += 1, e.errorClientKey = t.meta.clientKey;
                }
            },
            chatErrorSet(e, t) {
                e.isSending = !1, e.isTyping = !1, qD(e), e.error = t.payload, e.errorSeq += 1, e.errorClientKey = null;
            },
            chatErrorCleared(e) {
                e.error = null, e.errorClientKey = null;
            },
            typingStarted(e) {
                e.isTyping = !0;
            },
            typingStopped(e) {
                e.isTyping = !1;
            },
            generationStarted(e) {
                XD(e);
            },
            generationFinished(e) {
                YD(e);
            },
            generationStateCleared(e) {
                qD(e), e.unifiedReasonerEvidenceCursor = null, e.unifiedReasonerEvidenceCreatedAt = null;
            },
            unifiedReasonerGenerationStateCleared(e) {
                $D(e), e.unifiedReasonerEvidenceCursor = null, e.unifiedReasonerEvidenceCreatedAt = null;
            },
            unifiedReasonerGenerationStarted(e) {
                QD(e);
            },
            unifiedReasonerGenerationFinished(e) {
                $D(e);
            },
            unifiedReasonerEvidenceObserved(e, t) {
                RD(e, t.payload);
            },
            playbookStepExecutingSet(e, t) {
                e.playbookStepExecuting = t.payload;
            },
            playbookGateCleared(e) {
                e.playbookStepExecuting = !1, e.playbookGateEvidenceCursor = null, e.playbookGateEvidenceCreatedAt = null;
            },
            playbookGateEvidenceObserved(e, t) {
                LD(e, t.payload);
            },
            serverProgressObserved(e) {
                e.serverProgressSeq += 1;
            },
            interactiveBlockAnswered(e, t) {
                let {
                    messageId: n,
                    answerMessageId: r
                } = typeof t.payload == "string" ? {
                    messageId: t.payload,
                    answerMessageId: void 0
                } : t.payload, i = e.answeredInteractiveMessageIds.includes(n);
                tO(e, [n]), !i && r && (e.interactiveAnswerOwners[n] = r);
            },
            interactiveBlockAnswerReverted(e, t) {
                let {
                    messageId: n,
                    answerMessageId: r
                } = t.payload;
                e.interactiveAnswerOwners[n] === r && (delete e.interactiveAnswerOwners[n], e.answeredInteractiveMessageIds = e.answeredInteractiveMessageIds.filter((e) => e !== n)), e.withdrawnAnswerMessageIds.includes(r) || e.withdrawnAnswerMessageIds.push(r);
            },
            widgetAppDataObserved(e, t) {
                let n = t.payload ? .ids;
                if (n) {
                    tO(e, n);
                    return;
                }
                for (let t = e.messages.length - 1; t >= 0; t--) {
                    let n = e.messages[t];
                    if (bD(n)) {
                        tO(e, [n.id]);
                        return;
                    }
                }
            },
            chatCleared(e) {
                return {
                    ...SD,
                    inLiveChat: e.inLiveChat,
                    inLiveChatPending: e.inLiveChatPending,
                    inConversationState: e.inLiveChat || e.inLiveChatPending,
                    serverProgressSeq: e.serverProgressSeq,
                    endChatCompletedSeq: e.endChatCompletedSeq
                };
            },
            conversationStateCleared(e) {
                e.captureData = null, e.listSelectionData = null, e.widgetAppPending = !1, e.stagedAttachments = [], e.attachmentRejection = null, e.inConversationState = e.inLiveChat || e.inLiveChatPending;
            },
            historyConversationsSet(e, t) {
                e.historyConversationIds = t.payload, e.historyConversationIndex = 0, e.historyConversationCursor = null;
            },
            recentMessagesLoaded(e, t) {
                tO(e, t.payload.answeredInteractiveIds ? ? []);
                let n = new Map(e.messages.map((e) => [e.id, e])),
                    r = (n) => e.retainedZendeskMessageIds[n.id] === !0 && VD(n) && typeof t.payload.conversationId == "string" && t.payload.conversationId.length > 0 && n.conversationId === t.payload.conversationId,
                    i = /* @__PURE__ */ new Set(),
                    a = /* @__PURE__ */ new Map(),
                    o = BD(t.payload.messages, t.payload.conversationId);
                for (let t = o.length - 1; t >= 0; --t) {
                    let s = o[t];
                    if (!(n.has(s.id) || !HD(s)) && !(typeof s.tempMessageUuid != "string" || s.tempMessageUuid.length === 0))
                        for (let t = e.messages.length - 1; t >= 0; --t) {
                            let n = e.messages[t];
                            if (VD(n) && n.tempMessageUuid === s.tempMessageUuid && !r(n) && !i.has(n.id)) {
                                i.add(n.id), a.set(s.id, n);
                                break;
                            }
                        }
                }
                let s = o.map((e) => {
                    let t = n.get(e.id);
                    if (t) return DD(t, e);
                    let r = a.get(e.id);
                    return r ? DD(r, e) : e;
                });
                for (let t of s) kD(e.reactions, t);
                let c = new Set(s.map((e) => e.id)),
                    l = t.payload.messageCursor ? ? "",
                    u = e.messages.filter((e) => !c.has(e.id) && (e.isStreaming === !0 || r(e) || typeof e.cursor == "string" && e.cursor > l)),
                    d = e.messages;
                e.messages = u.length ? WD(s, u, d) : s;
                let f = new Set(e.messages.map((e) => e.id));
                for (let t of Object.keys(e.retryableMessageSends)) f.has(t) || delete e.retryableMessageSends[t];
                for (let t of s) n.has(t.id) && HD(t) && (delete e.retryableMessageSends[t.id], delete e.retainedZendeskMessageIds[t.id]);
                UD(e), (!s.length || !s.every(PD)) && (e.isConversationActive = FD(e.messages)), ID(s) && (e.userHasSentInCurrentConversation = !0), e.canLoadMore = t.payload.canLoadMore, e.loadingPreviousMessages = !1, e.historyConversationCursor = t.payload.historyConversationCursor === void 0 ? s[0] ? .id ? ? null : t.payload.historyConversationCursor, e.recentMessagesLoadSeq += 1, AD(e.messageCursorByConversation, t.payload.conversationId, t.payload.messageCursor);
            },
            messagesCaughtUp(e, t) {
                tO(e, t.payload.answeredInteractiveIds ? ? []);
                let n = BD(t.payload.messages, t.payload.conversationId);
                for (let t of n) kD(e.reactions, t);
                let r = new Set(e.messages.map((e) => e.id)),
                    i = n.filter((e) => !r.has(e.id) && !PD(e)),
                    a = n.length > 0 && n.every(PD),
                    o = i.filter((e) => e.sender !== "user");
                for (let t of n) {
                    let n = OD(e.messages, t);
                    n !== null && HD(t) && (delete e.retryableMessageSends[n], delete e.retainedZendeskMessageIds[n]);
                }
                if (UD(e), t.payload.recovery !== "baseline")
                    for (let t of i) ND(e, t);
                a || (e.isConversationActive = FD(e.messages)), ID(n) && (e.userHasSentInCurrentConversation = !0), !a && !e.messages.some((e) => e.isStreaming === !0) && (e.isTyping = !1, o.length > 0 && !zD(e, o) && YD(e), i.length > 0 && (e.isBotTyping = !1)), i.length > 0 && (e.lastCaughtUpMessages = i, e.caughtUpAppendSeq += 1), AD(e.messageCursorByConversation, t.payload.conversationId, t.payload.messageCursor);
            },
            messageCursorCommitted(e, t) {
                AD(e.messageCursorByConversation, t.payload.conversationId, t.payload.cursor);
            },
            messagesRead(e, t) {
                AD(e.lastReadCursorByConversation, t.payload.conversationId, t.payload.cursor);
            },
            readStateRehydrated(e, t) {
                e.lastReadCursorByConversation = { ...t.payload.lastReadCursorByConversation
                };
            },
            streamingMessageUpdated(e, t) {
                let n = TD(e.messages, t.payload.streamId);
                if (n !== -1) {
                    let r = e.messages[n];
                    if (t.payload.text.length < r.body.length) return;
                    e.messages[n] = {
                        ...r,
                        body: t.payload.text
                    };
                } else {
                    let n = t.payload.streamId;
                    if (e.messages.some((e) => e.isStreaming !== !0 && (e.streamId === n || e.id === n))) return;
                    CD(e.messages, {
                        id: `stream:${t.payload.streamId}`,
                        type: "text",
                        body: t.payload.text,
                        sender: "bot",
                        timestamp: Date.now(),
                        reviewable: !1,
                        streamId: t.payload.streamId,
                        isStreaming: !0
                    }), UD(e);
                }
                e.isConversationActive = FD(e.messages), e.isTyping = !1, ZD(e);
            },
            streamingMessageRemoved(e, t) {
                let n = TD(e.messages, t.payload.streamId);
                n !== -1 && (e.messages.splice(n, 1), e.isConversationActive = FD(e.messages)), YD(e);
            },
            previousMessagesLoaded(e, t) {
                e.previousMessagesLoadSeq += 1, e.historyPageBackoff = null, tO(e, t.payload.answeredInteractiveIds ? ? []);
                let n = new Set(e.messages.map((e) => e.id)),
                    r = BD(t.payload.messages, t.payload.conversationId).filter((e) => !n.has(e.id));
                for (let t of r) kD(e.reactions, t);
                e.messages.unshift(...r), e.isConversationActive = FD(e.messages), t.payload.isCurrentConversation && ID(t.payload.messages) && (e.userHasSentInCurrentConversation = !0), e.canLoadMore = t.payload.canLoadMore, e.historyConversationIndex = t.payload.historyConversationIndex, e.historyConversationCursor = t.payload.historyConversationCursor;
            },
            historyPageBackoffSet(e, t) {
                e.historyPageBackoff = t.payload;
            },
            loadingPreviousMessagesSet(e, t) {
                e.loadingPreviousMessages = t.payload;
            },
            composerTextSet(e, t) {
                e.composerTextRevisionSeq += 1, e.composerText = {
                    text: t.payload,
                    revision: e.composerTextRevisionSeq
                };
            },
            composerTextCleared(e) {
                e.composerText = null;
            },
            attachmentStaged(e, t) {
                let {
                    allowMultiple: n,
                    ...r
                } = t.payload;
                if (n !== !0) {
                    e.stagedAttachments = [{
                        ...r,
                        status: "uploading"
                    }];
                    return;
                }
                e.stagedAttachments.length >= 3 || e.stagedAttachments.push({
                    ...r,
                    status: "uploading"
                });
            },
            attachmentRejected(e, t) {
                xD(e, t.payload);
            },
            attachmentUploadSucceeded(e, t) {
                let n = e.stagedAttachments.find((e) => e.id === t.payload.id);
                !n || n.status !== "uploading" || (n.status = "ready", n.url = t.payload.url, n.s3Key = t.payload.s3Key, t.payload.mimeType && (n.mimeType = t.payload.mimeType), t.payload.name && (n.name = t.payload.name));
            },
            attachmentUploadFailed(e, t) {
                let n = e.stagedAttachments.find((e) => e.id === t.payload.id);
                !n || n.status !== "uploading" || (e.stagedAttachments = e.stagedAttachments.filter((e) => e.id !== t.payload.id), xD(e, {
                    ...t.payload,
                    name: n.name
                }));
            },
            attachmentRemoved(e, t) {
                e.stagedAttachments = e.stagedAttachments.filter((e) => e.id !== t.payload.id);
            },
            canLoadMoreSet(e, t) {
                e.canLoadMore = t.payload;
            },
            conversationActivitySet(e, t) {
                e.isConversationActive = t.payload;
            },
            captureDataSet(e, t) {
                if (t.payload === null) {
                    e.captureData = null;
                    return;
                }
                if (e.inConversationState = !0, tT(e.captureData, t.payload)) return;
                let n = e.captureData ? .dataId === t.payload.dataId;
                e.captureData = {
                    ...t.payload,
                    isSubmitting: n ? e.captureData ? .isSubmitting ? ? !1 : !1,
                    lastSubmitFailure: n ? e.captureData ? .lastSubmitFailure ? ? null : null
                };
            },
            captureDataRetiredLocally(e) {
                e.captureData = null, GD(e);
            },
            captureSubmitStarted(e, t) {
                e.captureData ? .dataId === t.payload && (e.captureData.isSubmitting = !0);
            },
            captureSubmitSettled(e, t) {
                e.captureData ? .dataId === t.payload && (e.captureData.isSubmitting = !1);
            },
            captureSubmitFailed(e, t) {
                e.captureData ? .dataId === t.payload.dataId && (e.captureData.lastSubmitFailure = {
                    submitId: t.payload.submitId,
                    message: t.payload.message
                });
            },
            listSelectionDataSet(e, t) {
                e.listSelectionData = t.payload, t.payload !== null && (e.inConversationState = !0);
            },
            widgetAppPendingRestored(e) {
                e.widgetAppPending = !0, e.inConversationState = !0, e.stagedAttachments = [], e.attachmentRejection = null;
            },
            widgetAppPendingCleared(e) {
                e.widgetAppPending = !1;
            },
            listSelectionDataRetiredLocally(e) {
                e.listSelectionData = null, GD(e);
            },
            csatAutoTriggerSet(e, t) {
                e.csatAutoTrigger = t.payload, t.payload || (e.csatAutoTriggerConversationId = null);
            },
            csatAutoTriggerLowered(e) {
                e.csatAutoTrigger = !1;
            },
            csatSurveyedConversationCaptured(e, t) {
                e.csatAutoTriggerConversationId = t.payload;
            },
            csatIsOpenSet(e, t) {
                e.csatIsOpen = t.payload;
            },
            csatSubmitErrorSet(e, t) {
                (t.payload.message !== null || !t.payload.surveyType && !t.payload.inlineAnswerId) && (e.csatSubmitError = t.payload.message, e.csatSubmitErrorConversationId = t.payload.conversationId ? ? null, e.csatSubmitErrorSurveyType = t.payload.surveyType ? ? null), t.payload.inlineAnswerId && (e.csatInlineSubmitErrorIds = [...e.csatInlineSubmitErrorIds, t.payload.inlineAnswerId].slice(-200)), t.payload.message !== null && (e.csatSubmitErrorSeq += 1);
            },
            endChatCompleted(e) {
                e.endChatCompletedSeq += 1;
            },
            csatSubmitSucceeded(e, t) {
                e.csatSubmitSuccessSeq += 1, e.csatSubmitSuccessSurveyType = t.payload.surveyType, e.csatSubmitSuccessConversationId = t.payload.conversationId ? ? null, e.csatSubmitSuccessSameGeneration = t.payload.sameGeneration;
            },
            csatMessageSubmitted(e, t) {
                let n = t.payload.conversationId ? ? null,
                    r = (e) => e.type === "csat" && e.surveyType === t.payload.surveyType,
                    i = (t) => {
                        for (let n = e.messages.length - 1; n >= 0; --n)
                            if (t(e.messages[n])) return n;
                        return -1;
                    },
                    a = n === null ? -1 : i((e) => r(e) && e.conversationId === n),
                    o = a === -1 ? i((e) => r(e) && (n === null || e.conversationId == null)) : a,
                    s = o === -1 ? null : e.messages[o];
                s ? .type === "csat" && (t.payload.score !== void 0 && (s.score = t.payload.score), t.payload.scaleType !== void 0 && (s.scaleType = t.payload.scaleType), s.submitted = !0, t.payload.feedback !== void 0 && (s.feedback = t.payload.feedback), t.payload.resolved !== void 0 && (s.resolved = t.payload.resolved), t.payload.comment !== void 0 && (s.comment = t.payload.comment), t.payload.customerEffortScore !== void 0 && (s.customerEffortScore = t.payload.customerEffortScore), t.payload.netPromoterScore !== void 0 && (s.netPromoterScore = t.payload.netPromoterScore), t.payload.isPositive !== void 0 && (s.isPositive = t.payload.isPositive));
            },
            csatSettingsLoaded(e, t) {
                e.csatSettings = t.payload;
            },
            csatBotSettingsLoaded(e, t) {
                e.csatBotSettings = t.payload;
            },
            csatEndChatEligibilityRequested(e, t) {
                e.csatEndChatEligibility = {
                    status: "loading",
                    eligible: null,
                    surveyTarget: null,
                    requestId: t.payload.requestId
                };
            },
            csatEndChatEligibilityLoaded(e, t) {
                e.csatEndChatEligibility.requestId === t.payload.requestId && (e.csatEndChatEligibility = {
                    status: "ready",
                    eligible: t.payload.eligible,
                    surveyTarget: t.payload.surveyTarget,
                    requestId: t.payload.requestId
                }, e.csatEndChatEligibilitySeq += 1);
            },
            csatEndChatEligibilityCleared(e) {
                e.csatEndChatEligibility = {
                    status: "idle",
                    eligible: null,
                    surveyTarget: null,
                    requestId: null
                };
            },
            customJavascriptEventReceived(e, t) {
                e.customJsEventSeq += 1, e.customJsEventPayload = t.payload;
            },
            reactionAdded(e, t) {
                e.reactions[t.payload.messageId] = t.payload.reaction;
            },
            reactionReverted(e, t) {
                e.reactions[t.payload.messageId] === t.payload.reaction && delete e.reactions[t.payload.messageId];
            },
            linkPreviewLoaded(e, t) {
                let n = e.messages.find((e) => e.id === t.payload.messageId);
                if (n ? .type === "link") {
                    let {
                        title: e,
                        linkDescription: r,
                        linkIcon: i
                    } = t.payload;
                    Object.assign(n, {
                        ...e && {
                            title: e
                        },
                        ...r && {
                            linkDescription: r
                        },
                        ...i && {
                            linkIcon: i
                        }
                    });
                }
            }
        },
        extraReducers: (e) => {
            e.addCase(ms, (e, t) => {
                e.historyPageBackoff ? .identity.chatterToken !== t.payload.token && (e.historyPageBackoff = null);
            }), e.addCase(ic, (e) => {
                e.historyPageBackoff = null;
            }), e.addCase(eD, (e, t) => {
                let {
                    stateType: n,
                    inState: r
                } = t.payload, i = e.inLiveChat, a = !r && (n !== null && Qw.has(n) && e.listSelectionData !== null || n !== null && $w.has(n) && e.captureData !== null);
                e.inLiveChat = AE(e.inLiveChat, t.payload), e.inLiveChatPending = jE(e.inLiveChatPending, t.payload), i && !e.inLiveChat && KD(e), n === "widget_app_pending" ? e.widgetAppPending = r : r && (e.widgetAppPending = !1), e.inConversationState = r || a || e.inLiveChat || e.inLiveChatPending || e.widgetAppPending, e.inLiveChat && (e.isTyping = !1, qD(e)), (e.inLiveChat || e.inLiveChatPending || e.widgetAppPending) && (e.stagedAttachments = [], e.attachmentRejection = null);
            }), e.addCase(pD, (e) => {
                KD(e), e.inLiveChat = !1, e.inLiveChatPending = !1, e.inConversationState = !1, e.isTyping = !1, qD(e);
            }), e.addCase(rD, (e) => {
                KD(e);
            }), e.addCase(iD, (e) => {
                KD(e);
            }), e.addCase(Z, (e, t) => {
                t.payload.chatClosed && KD(e);
            }), e.addCase(sD, (e, t) => {
                t.payload.platformName !== "zendesk_liveagent" && KD(e);
            }), e.addCase(Ts, (e, t) => {
                e.historyPageBackoff ? .identity.conversationId !== t.payload && (e.historyPageBackoff = null), e.stagedAttachments.some((e) => e.conversationId !== t.payload) && (e.stagedAttachments = []), e.attachmentRejection = null;
                for (let n of e.messages) n.conversationId == null ? n.conversationId = t.payload : n.conversationId !== t.payload && (e.retryableMessageSends[n.id] && (n.deliveryStatus = "failed"), delete n.isRetryable, delete e.retryableMessageSends[n.id]);
                e.historyConversationIds.includes(t.payload) || (e.historyConversationIds = [t.payload, ...e.historyConversationIds], (e.historyConversationIndex > 0 || e.historyConversationCursor !== null) && (e.historyConversationIndex += 1));
            }), e.addCase(Es, (e) => {
                e.historyPageBackoff = null, e.userHasSentInCurrentConversation = !1, e.widgetAppPending = !1, e.stagedAttachments = [], e.attachmentRejection = null, e.playbookStepExecuting = !1, e.playbookGateEvidenceCursor = null, e.playbookGateEvidenceCreatedAt = null, qD(e), e.unifiedReasonerEvidenceCursor = null, e.unifiedReasonerEvidenceCreatedAt = null;
                for (let t of e.messages) e.retryableMessageSends[t.id] && t.type === "text" && (t.deliveryStatus = "failed"), t.type === "text" && t.isRetryable === !0 && delete t.isRetryable;
                e.retryableMessageSends = {};
            });
        }
    }),
    {
        messageReceived: rO,
        messageSent: iO,
        zendeskMessageSent: aO,
        zendeskMessageRetentionSettled: oO,
        secretMessageSent: sO,
        messageSendAcknowledged: cO,
        messageDeliveryFailed: lO,
        messageDeliveryUnconfirmed: uO,
        groupDeliveryAbandoned: dO,
        messageRetryStarted: fO,
        messageRetryAbandoned: pO,
        sendingStarted: mO,
        sendingFailed: hO,
        messageSendDropped: gO,
        chatErrorSet: _O,
        chatErrorCleared: vO,
        typingStarted: yO,
        typingStopped: bO,
        generationStarted: xO,
        generationFinished: SO,
        generationStateCleared: CO,
        unifiedReasonerGenerationStateCleared: wO,
        unifiedReasonerGenerationStarted: TO,
        unifiedReasonerGenerationFinished: EO,
        unifiedReasonerEvidenceObserved: DO,
        interactiveBlockAnswered: OO,
        interactiveBlockAnswerReverted: kO,
        widgetAppDataObserved: AO,
        playbookStepExecutingSet: jO,
        playbookGateCleared: MO,
        playbookGateEvidenceObserved: NO,
        serverProgressObserved: PO,
        chatCleared: FO,
        conversationStateCleared: IO,
        historyConversationsSet: LO,
        recentMessagesLoaded: RO,
        messagesCaughtUp: zO,
        messageCursorCommitted: BO,
        messagesRead: VO,
        readStateRehydrated: HO,
        streamingMessageUpdated: UO,
        streamingMessageRemoved: WO,
        previousMessagesLoaded: GO,
        historyPageBackoffSet: KO,
        loadingPreviousMessagesSet: qO,
        composerTextSet: JO,
        composerTextCleared: YO,
        attachmentStaged: XO,
        attachmentRejected: ZO,
        attachmentUploadSucceeded: QO,
        attachmentUploadFailed: $O,
        attachmentRemoved: ek,
        canLoadMoreSet: tk,
        conversationActivitySet: nk,
        authLinkExpiryUpdated: rk,
        botTypingSet: ik,
        captureDataSet: ak,
        captureDataRetiredLocally: ok,
        captureSubmitFailed: sk,
        captureSubmitSettled: ck,
        captureSubmitStarted: lk,
        turnSettledWithoutMessages: uk,
        userMessageEchoed: dk,
        listSelectionDataSet: fk,
        listSelectionDataRetiredLocally: pk,
        widgetAppPendingCleared: mk,
        widgetAppPendingRestored: hk,
        csatAutoTriggerSet: gk,
        csatAutoTriggerLowered: _k,
        csatSurveyedConversationCaptured: vk,
        csatIsOpenSet: yk,
        csatSettingsLoaded: bk,
        csatBotSettingsLoaded: xk,
        csatEndChatEligibilityRequested: Sk,
        csatEndChatEligibilityLoaded: Ck,
        csatEndChatEligibilityCleared: wk,
        csatSubmitErrorSet: Tk,
        csatSubmitSucceeded: Ek,
        endChatCompleted: Dk,
        csatMessageSubmitted: Ok,
        customJavascriptEventReceived: kk,
        reactionAdded: Ak,
        reactionReverted: jk,
        linkPreviewLoaded: Mk
    } = nO.actions,
    Nk = nO.reducer,
    Pk = {
        transportStatus: "disconnected",
        channelConnected: !1,
        browserOffline: !1,
        transportUnreachable: !1,
        transportConnectedSeq: 0,
        browserConnectivitySeq: 0,
        connectivityLost: !1,
        connectivityVerdictPending: !1,
        connectivityNoticeRaised: !1,
        intentionalTeardown: !1,
        networkConnectivityToast: null
    };

function Fk(e, t = !1) {
    let n = e.browserOffline && e.transportUnreachable;
    if (n !== e.connectivityLost) {
        if (e.connectivityLost = n, n) {
            e.networkConnectivityToast = "offline", e.connectivityNoticeRaised = !0;
            return;
        }
        e.networkConnectivityToast === "offline" && (e.networkConnectivityToast = null);
    }!n && e.connectivityNoticeRaised && t && (e.networkConnectivityToast = "online", e.connectivityNoticeRaised = !1);
}
var Ik = N({
        name: "connection",
        initialState: Pk,
        reducers: {
            transportStatusChanged(e, t) {
                e.transportStatus = t.payload, t.payload === "connected" ? (e.transportUnreachable = !1, e.intentionalTeardown = !1, e.transportConnectedSeq += 1, e.connectivityVerdictPending = !1) : t.payload === "connecting" || e.intentionalTeardown ? e.intentionalTeardown = !1 : (e.transportUnreachable = !0, e.connectivityVerdictPending = !1), Fk(e, t.payload === "connected");
            },
            transportUnreachableReported(e) {
                e.transportUnreachable = !0, e.connectivityVerdictPending = !1, Fk(e);
            },
            transportReachableReported(e) {
                e.transportUnreachable = !1, e.connectivityVerdictPending = !1, Fk(e, !0);
            },
            connectivityNoticeRetired(e) {
                e.connectivityNoticeRaised = !1;
            },
            transportTeardownStarted(e) {
                e.intentionalTeardown = e.transportStatus !== "disconnected";
            },
            browserConnectivityChanged(e, t) {
                let n = !t.payload;
                n !== e.browserOffline && (e.browserConnectivitySeq += 1), e.connectivityVerdictPending = n && !e.browserOffline, n || (e.transportUnreachable = !1), e.browserOffline = n, Fk(e);
            },
            channelConnected(e) {
                e.channelConnected = !0;
            },
            channelDisconnected(e) {
                e.channelConnected = !1;
            },
            networkConnectivityToastSet(e, t) {
                e.networkConnectivityToast = t.payload;
            },
            connectionReset(e) {
                return {
                    ...Pk,
                    browserOffline: e.browserOffline,
                    connectivityVerdictPending: e.browserOffline,
                    transportConnectedSeq: e.transportConnectedSeq,
                    browserConnectivitySeq: e.browserConnectivitySeq
                };
            }
        }
    }),
    {
        browserConnectivityChanged: Lk,
        channelConnected: Rk,
        channelDisconnected: zk,
        connectionReset: Bk,
        connectivityNoticeRetired: Vk,
        networkConnectivityToastSet: Hk,
        transportReachableReported: Uk,
        transportStatusChanged: Wk,
        transportTeardownStarted: Gk,
        transportUnreachableReported: Kk
    } = Ik.actions,
    qk = {
        iconType: "default",
        iconPath: "",
        textEnabled: !1,
        text: "",
        textLanguage: "en",
        size: 64,
        backgroundColor: null
    };

function Jk(e) {
    if (!e.hostBranding || !e.hasHydratedClientConfig) return null;
    let t = Ny(e.hostBranding, e.clientDefaultLanguage);
    return Object.keys(t).length > 0 ? t : null;
}

function Yk(e, t) {
    let n = ky(t, e.language, e.clientDefaultLanguage);
    if (n === null) return null;
    let r = e.language.trim().toLowerCase();
    return {
        text: n,
        language: t && Object.hasOwn(t, r) ? r : e.clientDefaultLanguage.trim().toLowerCase()
    };
}

function Xk(e) {
    let t = Jk(e);
    return t ? .headerTextColor === void 0 || t.headerColor !== void 0 ? !1 : !e.headerColorEnabled || e.headerColor === null;
}

function Zk(e) {
    let t = Jk(e),
        n = Yk(e, t ? .aiAgentName) ? .text,
        r = Yk(e, t ? .aiAgentDescription) ? .text,
        i = t ? .headerColor ? ? e.headerColor,
        a = Xk(e) ? void 0 : t ? .headerTextColor,
        o = t ? .headerColor !== void 0 || a !== void 0;
    return {
        botName: n ? ? e.botName,
        botDescription: r ? ? e.botDescription,
        botDescriptionEnabled: r === void 0 ? e.botDescriptionEnabled : !0,
        botAvatarUrl: t ? .avatarUrl ? ? e.botAvatarUrl,
        avatar: t ? .avatarUrl ? {
            letter: e.avatar.letter,
            image: t.avatarUrl,
            useLetter: !1
        } : e.avatar,
        tintColor: t ? .tintColor ? ? e.tintColor,
        style: t ? .cornerStyle ? ? e.style,
        textSize: t ? .textSize ? ? e.textSize,
        headerColorEnabled: o ? !0 : e.headerColorEnabled,
        headerColor: i,
        headerTextColor: a ? ? e.headerTextColor,
        advancedColorsEnabled: a === void 0 ? e.advancedColorsEnabled : !0,
        textOverAccentColor: e.advancedColorsEnabled ? e.textOverAccentColor : null,
        buttonSize: t ? .launcher ? .size ? ? e.buttonSize,
        buttonBackgroundColor: t ? .launcher ? .backgroundColor ? ? e.buttonBackgroundColor
    };
}

function Qk(e, t) {
    let n = Jk(t) ? .launcher;
    if (!n) return e;
    let r = { ...e ? ? qk
    };
    n.backgroundColor !== void 0 && (r.backgroundColor = n.backgroundColor), n.size !== void 0 && (r.size = n.size), n.iconUrl !== void 0 && (r.iconType = "custom", r.iconPath = n.iconUrl, r.textEnabled = !1);
    let i = Yk(t, n.text);
    return i && (r.textEnabled = !0, r.text = i.text, r.textLanguage = i.language), r;
}
//#endregion
//#region src/feature-flag-definitions.ts
var $k = {
    "messaging-websocket-transport": {
        kind: "boolean",
        defaultValue: !1,
        exposure: "core",
        lifecycle: "planned",
        owner: "messaging-experience",
        removeBy: null
    },
    "disable-text-input-live-chat": {
        kind: "boolean",
        defaultValue: !1,
        exposure: "app",
        lifecycle: "active",
        owner: "experiences",
        removeBy: null
    },
    "messaging-sequential-reveal": {
        kind: "boolean",
        defaultValue: !1,
        exposure: "app",
        lifecycle: "active",
        owner: "experiences",
        removeBy: "2026-11-24"
    }
};
//#endregion
//#region src/feature-flag-registry.ts
function eA() {
    return Object.entries($k);
}

function tA(e) {
    return e.kind === "boolean";
}

function nA(e) {
    return e.kind === "string";
}

function rA(e) {
    return e.kind === "number";
}

function iA(e, t) {
    if (tA(e)) return typeof t == "boolean" ? t : e.defaultValue;
    if (nA(e)) return typeof t == "string" ? t : e.defaultValue;
    if (rA(e)) return typeof t == "number" ? t : e.defaultValue;
    throw Error(`Unsupported feature flag kind: ${String(e)}`);
}

function aA(e) {
    return zv($k, e);
}

function oA() {
    let e = {};
    for (let [t, n] of eA()) e[t] = n.defaultValue;
    return e;
}

function sA(e) {
    let t = oA();
    for (let [n, r] of eA()) zv(e, n) && (t[n] = iA(r, e[n]));
    return t;
}

function cA(e, t) {
    return aA(e) ? {
        key: e,
        value: iA($k[e], t)
    } : null;
}

function lA(e) {
    let t = {};
    for (let [n, r] of eA()) r.exposure === "app" && (t[n] = e[n]);
    return t;
}
//#endregion
//#region src/store/feature-flags-slice.ts
function uA() {
    return {
        flags: oA()
    };
}
var dA = N({
        name: "featureFlags",
        initialState: uA(),
        reducers: {
            flagsInitialized(e, t) {
                e.flags = sA(t.payload);
            },
            flagChanged(e, t) {
                let n = cA(t.payload.key, t.payload.value);
                n && (e.flags[n.key] = n.value);
            },
            featureFlagsReset(e) {
                return uA();
            }
        }
    }),
    {
        flagsInitialized: fA,
        flagChanged: pA,
        featureFlagsReset: mA
    } = dA.actions,
    hA = xa([(e) => e.featureFlags.flags], (e) => lA(e)),
    gA = {
        handle: null,
        introResponseId: null,
        configuredResponseId: null,
        isSent: !1,
        isSkipped: !1,
        isSkippedForPage: !1,
        heldForProactive: null,
        followUpResponseId: null,
        explicitlyRequested: !1
    },
    _A = N({
        name: "greeting",
        initialState: gA,
        reducers: {
            greetingConfigured(e, t) {
                e.handle = t.payload.handle, e.introResponseId = t.payload.introResponseId, e.configuredResponseId = t.payload.configuredResponseId;
            },
            greetingMarkedSent(e) {
                e.isSent = !0;
            },
            greetingSendRejected(e) {
                e.isSent = !1;
            },
            greetingMarkedSkipped(e) {
                e.isSkipped = !0;
            },
            greetingPageSkipEnabled(e) {
                e.isSkippedForPage = !0;
            },
            greetingSkipCleared(e) {
                e.isSkipped = !1;
            },
            greetingHeldForProactive(e, t) {
                e.heldForProactive = t.payload;
            },
            greetingHoldReleased(e, t) {
                e.heldForProactive === t.payload && (e.heldForProactive = null);
            },
            greetingHoldCleared(e) {
                e.heldForProactive = null;
            },
            followUpResponseIdSet(e, t) {
                e.followUpResponseId = t.payload, e.explicitlyRequested = !1, t.payload && (e.isSkipped = !1, e.isSent = !1);
            },
            greetingMarkedExplicitlyRequested(e) {
                e.explicitlyRequested = !0;
            },
            greetingReset(e) {
                return {
                    ...gA,
                    isSkippedForPage: e.isSkippedForPage
                };
            }
        }
    }),
    {
        greetingConfigured: vA,
        greetingHeldForProactive: yA,
        greetingHoldCleared: bA,
        greetingHoldReleased: xA,
        greetingMarkedSent: SA,
        greetingMarkedSkipped: CA,
        greetingPageSkipEnabled: wA,
        greetingSkipCleared: TA,
        greetingSendRejected: EA,
        followUpResponseIdSet: DA,
        greetingMarkedExplicitlyRequested: OA,
        greetingReset: kA
    } = _A.actions,
    AA = N({
        name: "localization",
        initialState: {
            translations: {},
            language: "en",
            fallbackKeys: [],
            isLoaded: !1,
            isLoading: !1
        },
        reducers: {
            translationsLoading(e) {
                e.isLoading = !0;
            },
            translationsLoadFinished(e) {
                e.isLoading = !1;
            },
            translationsLoaded: {
                prepare(e, t = "en", n = []) {
                    return {
                        payload: e,
                        meta: {
                            language: t,
                            fallbackKeys: n
                        }
                    };
                },
                reducer(e, t) {
                    e.translations = t.payload, e.language = t.meta ? .language ? ? "en", e.fallbackKeys = t.meta ? .fallbackKeys ? ? [], e.isLoaded = !0, e.isLoading = !1;
                }
            }
        }
    }),
    {
        translationsLoaded: jA,
        translationsLoading: MA,
        translationsLoadFinished: NA
    } = AA.actions,
    PA = {
        responseDelayed: !1,
        showServiceRestoredToast: !1,
        type: null
    },
    FA = N({
        name: "outage",
        initialState: PA,
        reducers: {
            outageResponseDelayedSet(e, t) {
                e.responseDelayed = t.payload;
            },
            outageServiceRestoredToastSet(e, t) {
                e.showServiceRestoredToast = t.payload;
            },
            outageTypeSet(e, t) {
                e.type = t.payload;
            },
            outageReset() {
                return PA;
            }
        },
        extraReducers: (e) => {
            e.addCase(mO, () => PA);
        }
    }),
    {
        outageResponseDelayedSet: IA,
        outageServiceRestoredToastSet: LA,
        outageTypeSet: RA,
        outageReset: zA
    } = FA.actions,
    BA = {
        backgroundColor: null,
        fontFamily: null,
        header: null,
        headerMessage: null,
        title: null,
        text: null
    },
    VA = 4096,
    HA = 2e3,
    UA = 256;

function WA(e, t) {
    if (typeof e != "string") return null;
    let n = e.trim();
    return n ? n.slice(0, t) : null;
}

function GA(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    return t && t.length <= VA ? t : null;
}

function KA(e) {
    let t = WA(e, UA);
    return t && /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(t) ? t : null;
}

function qA(e) {
    let t = W(e);
    return !t || typeof t.locked != "boolean" ? null : {
        locked: t.locked,
        url: GA(t.url)
    };
}

function JA(e) {
    let t = W(e);
    return t ? {
        backgroundColor: KA(t.backgroundColor ? ? t.background_color),
        fontFamily: WA(t.fontFamily ? ? t.font_family, UA),
        header: WA(t.header, HA),
        headerMessage: WA(t.headerMessage ? ? t.header_message, HA),
        title: WA(t.title, HA),
        text: WA(t.text, HA)
    } : { ...BA
    };
}
//#endregion
//#region src/store/saml-slice.ts
var YA = {
        locked: !1,
        url: null,
        loadedForChatter: !1,
        loginButton: { ...BA
        }
    },
    XA = N({
        name: "saml",
        initialState: YA,
        reducers: {
            samlChatterStateReceived(e, t) {
                e.loadedForChatter = !0, e.locked = t.payload.locked, e.url = t.payload.url;
            },
            samlChatterStartupChecked(e) {
                e.loadedForChatter = !0;
            },
            samlLoginButtonConfigured(e, t) {
                e.loginButton = t.payload;
            },
            samlChatterStateCleared(e) {
                e.loadedForChatter = !1, e.locked = !1, e.url = null;
            },
            samlReset() {
                return {
                    ...YA,
                    loginButton: { ...BA
                    }
                };
            }
        }
    }),
    {
        samlChatterStateReceived: ZA,
        samlChatterStartupChecked: QA,
        samlLoginButtonConfigured: $A,
        samlChatterStateCleared: ej,
        samlReset: tj
    } = XA.actions,
    nj = {
        enabled: !0,
        isRecording: !1,
        mode: "toggle",
        currentTranscript: "",
        isFinal: !1,
        audioLevel: 0,
        error: null,
        ttsEnabled: !0,
        shouldUseTTS: !1
    },
    rj = N({
        name: "voice",
        initialState: nj,
        reducers: {
            voiceRecordingStarted: (e) => {
                e.isRecording = !0, e.error = null, e.currentTranscript = "", e.isFinal = !1, e.shouldUseTTS = !0;
            },
            voiceRecordingStopped: (e) => {
                e.isRecording = !1, e.audioLevel = 0;
            },
            voiceModeSet: (e, t) => {
                e.mode = t.payload;
            },
            voiceTranscriptUpdated: (e, t) => {
                e.currentTranscript = t.payload.transcript, e.isFinal = t.payload.isFinal;
            },
            voiceTranscriptCleared: (e) => {
                e.currentTranscript = "", e.isFinal = !1;
            },
            voiceAudioLevelUpdated: (e, t) => {
                e.audioLevel = Math.max(0, Math.min(1, t.payload));
            },
            voiceErrorSet: (e, t) => {
                e.error = t.payload, e.isRecording = !1, e.audioLevel = 0;
            },
            voiceErrorCleared: (e) => {
                e.error = null;
            },
            voiceTTSEnabledSet: (e, t) => {
                e.ttsEnabled = t.payload;
            },
            voiceShouldUseTTSCleared: (e) => {
                e.shouldUseTTS = !1;
            },
            voiceReset: () => nj
        }
    }),
    {
        voiceRecordingStarted: ij,
        voiceRecordingStopped: aj,
        voiceModeSet: oj,
        voiceTranscriptUpdated: sj,
        voiceTranscriptCleared: cj,
        voiceAudioLevelUpdated: lj,
        voiceErrorSet: uj,
        voiceErrorCleared: dj,
        voiceTTSEnabledSet: fj,
        voiceShouldUseTTSCleared: pj,
        voiceReset: mj
    } = rj.actions;
//#endregion
//#region src/store/store.ts
function hj() {
    let e = Ra({
        reducer: {
            activation: BT.reducer,
            session: cs.reducer,
            security: ko.reducer,
            connection: Ik.reducer,
            chat: Nk,
            outage: FA.reducer,
            saml: XA.reducer,
            greeting: _A.reducer,
            proactive: jT.reducer,
            liveAgent: NE.reducer,
            localization: AA.reducer,
            voice: rj.reducer,
            featureFlags: dA.reducer,
            [wI.reducerPath]: wI.reducer
        },
        middleware: (e) => e().concat(wI.middleware)
    });
    return $C(e.dispatch), e;
}
//#endregion
//#region src/conversation-reopen.ts
var gj = /^[0-9a-f]{24}$/;

function _j(e) {
    let {
        session: t,
        chat: n
    } = e.getState(), r = [
        t.conversationId ? n.messageCursorByConversation[t.conversationId] : null,
        n.playbookGateEvidenceCursor,
        n.unifiedReasonerEvidenceCursor
    ], i = null;
    for (let e of r) typeof e == "string" && gj.test(e) && (i === null || e > i) && (i = e);
    return i;
}

function vj(e, t, n, r) {
    let {
        session: i,
        liveAgent: a
    } = e.getState(), o = a.endedConversationReopenAfterCursor;
    t === null || i.conversationId !== t || n === null || n !== a.endedConversationReopenCandidateToken || o === null || !gj.test(o) || !r.some((e) => typeof e == "string" && gj.test(e) && e > o) || yj(e, t);
}

function yj(e, t) {
    let {
        hasConversationEnded: n,
        endedConversationReopenCandidateId: r
    } = e.getState().liveAgent;
    n && r === t && (q("conversation_reopened", {
        reason: "reused_by_injection"
    }), e.dispatch(YE(!1)), e.dispatch(XE(!1)), e.dispatch($E()), e.getState().liveAgent.zendesk.webhookRetryMessageKey && e.dispatch(Z({
        webhookRetryMessageKey: null
    })), e.dispatch(wk()), e.dispatch(_k()));
}
//#endregion
//#region src/orchestrator-bot-message-runtime.ts
function bj(e) {
    let t = W(e.log),
        n = W(t ? .message);
    if (!t || n ? ._type !== "presence") return null;
    let r = typeof t.id == "string" ? t.id : null;
    if (!r) return null;
    let i = Cj(n.message_cursor ? ? t.message_cursor ? ? e.message_cursor ? ? n.cursor ? ? t.cursor ? ? e.cursor ? ? t._id ? ? t.id);
    return {
        messages: [{
            id: r,
            body: typeof n.body == "string" ? n.body : "",
            type: "presence",
            ...i === void 0 ? {} : {
                cursor: i
            },
            ...wj(n.stream_id ? ? t.stream_id) ? {
                stream_id: wj(n.stream_id ? ? t.stream_id)
            } : {},
            source: jj(n.source) ? ? jj(t.source) ? ? jj(e.source),
            event: typeof n.event == "string" ? n.event : void 0,
            agent_info: W(n.agent_info) ? ? void 0,
            reviewable_message: typeof n.reviewable_message == "boolean" ? n.reviewable_message : void 0,
            created: typeof t.created == "number" ? t.created : void 0
        }],
        conversationId: typeof t.conversation_id == "string" ? t.conversation_id : null,
        ...i === void 0 ? {} : {
            cursor: i
        }
    };
}

function xj(e) {
    let t = W(e.log),
        n = W(t ? .message);
    if (!t || !n) return null;
    let r = typeof t.id == "string" ? t.id : null;
    return r ? {
        ...e,
        message_cursor: r,
        conversation_id: typeof t.conversation_id == "string" ? t.conversation_id : e.conversation_id,
        messages: [{
            ...n,
            id: r,
            ...typeof t.created == "number" ? {
                created: t.created
            } : {},
            ...typeof t.temp_message_uuid == "string" ? {
                temp_message_uuid: t.temp_message_uuid
            } : {},
            ...typeof t.persisted == "boolean" ? {
                server_persisted: t.persisted
            } : {},
            source: n.source ? ? t.source ? ? e.source
        }]
    } : null;
}
var Sj = /^[0-9a-f]{24}$/i;

function Cj(e) {
    return typeof e == "string" && Sj.test(e) ? e : void 0;
}

function wj(e) {
    return typeof e == "string" && e.length > 0 ? e : void 0;
}

function Tj(...e) {
    return e.find((e) => typeof e == "string");
}

function Ej(e) {
    return Cj(e.message_cursor ? ? e.cursor ? ? e._id ? ? e.id);
}

function Dj(e) {
    return e.is_final !== !1;
}

function Oj(e) {
    return wj(e.stream_id ? ? e.streamId ? ? e.generative_actions_event_id ? ? e.generation_event_id);
}
var kj = new Set([
    "streaming",
    "final",
    "aborted"
]);

function Aj(e) {
    if (typeof e != "object" || !e) return null;
    let t = e;
    if (t.kind !== "delta") return null;
    let n = wj(t.stream_id ? ? t.streamId),
        r = null;
    typeof t.conversation_id == "string" ? r = t.conversation_id : typeof t.conversationId == "string" && (r = t.conversationId);
    let i = typeof t.status == "string" && kj.has(t.status) ? t.status : null,
        a = typeof t.text == "string" ? t.text : null;
    return !n || !r || !i || a === null ? null : {
        kind: "delta",
        conversationId: r,
        streamId: n,
        status: i,
        text: a
    };
}

function jj(e) {
    return e === "user" || e === "bot" || e === "agent" ? e : void 0;
}

function Mj(e) {
    if (typeof e != "object" || !e) return null;
    let t = e,
        n = Ej(xj(t) ? ? t),
        r = Dj(t),
        i = bj(t);
    if (i) return {
        ...i,
        ...r ? {} : {
            isFinal: !1
        }
    };
    let a = xj(t) ? ? t,
        o = typeof a.conversation_id == "string" ? a.conversation_id : null;
    if (Array.isArray(a.messages)) {
        let e = [];
        for (let r of a.messages) {
            if (typeof r != "object" || !r) continue;
            let i = r,
                a = null;
            if (typeof i.id == "string" ? a = i.id : typeof i._id == "string" && (a = i._id), !a) continue;
            let o = typeof i.body == "string" ? i.body : "",
                s = "text";
            typeof i._type == "string" ? s = i._type : typeof i.type == "string" && (s = i.type);
            let c = Cj(i.message_cursor ? ? i.cursor ? ? i._id ? ? i.id) ? ? n,
                l = Oj(i),
                u;
            u = typeof i.article_id == "string" ? i.article_id : i.article_id === null ? null : void 0, e.push({
                id: a,
                body: o,
                type: s,
                ...c === void 0 ? {} : {
                    cursor: c
                },
                ...l ? {
                    stream_id: l
                } : {},
                source: jj(i.source) ? ? jj(t.source),
                quick_replies: Array.isArray(i.quick_replies) ? i.quick_replies : void 0,
                is_forced: typeof i.is_forced == "boolean" ? i.is_forced : void 0,
                button_layout: typeof i.button_layout == "string" ? i.button_layout : void 0,
                show_all: typeof i.show_all == "boolean" ? i.show_all : void 0,
                url: typeof i.url == "string" ? i.url : void 0,
                title: typeof i.title == "string" ? i.title : void 0,
                link_text: typeof i.link_text == "string" ? i.link_text : void 0,
                link_description: typeof i.link_description == "string" ? i.link_description : void 0,
                link_icon: typeof i.link_icon == "string" ? i.link_icon : void 0,
                alt_text: typeof i.alt_text == "string" ? i.alt_text : void 0,
                new_window: typeof i.new_window == "boolean" ? i.new_window : void 0,
                generate_link_preview: typeof i.generate_link_preview == "boolean" ? i.generate_link_preview : void 0,
                article_id: u,
                pic_url: typeof i.pic_url == "string" ? i.pic_url : void 0,
                vid_url: typeof i.vid_url == "string" ? i.vid_url : void 0,
                name: typeof i.name == "string" ? i.name : void 0,
                created: typeof i.created == "number" ? i.created : void 0,
                temp_message_uuid: typeof i.temp_message_uuid == "string" ? i.temp_message_uuid : void 0,
                server_persisted: typeof i.server_persisted == "boolean" ? i.server_persisted : void 0,
                mimeType: Tj(i.mime_type, i.mimeType),
                caption: typeof i.caption == "string" ? i.caption : void 0,
                attachment_group_id: typeof i.attachment_group_id == "string" ? i.attachment_group_id : void 0,
                event: typeof i.event == "string" ? i.event : void 0,
                agent_info: W(i.agent_info) ? ? void 0,
                queue_position: typeof i.queue_position == "number" ? i.queue_position : void 0,
                wait_message: typeof i.wait_message == "string" ? i.wait_message : void 0,
                platform: typeof i.platform == "string" ? i.platform : void 0,
                variable_id: typeof i.variable_id == "string" ? i.variable_id : void 0,
                selectables: Array.isArray(i.selectables) ? i.selectables : void 0,
                multiple: typeof i.multiple == "boolean" ? i.multiple : void 0,
                prompt: typeof i.prompt == "string" ? i.prompt : void 0,
                options: Array.isArray(i.options) ? i.options : void 0,
                widget_name: typeof i.widget_name == "string" ? i.widget_name : void 0,
                widget_url: typeof i.widget_url == "string" ? i.widget_url : void 0,
                aria_label: typeof i.aria_label == "string" ? i.aria_label : void 0,
                link_subtext: typeof i.link_subtext == "string" ? i.link_subtext : void 0,
                inline_in_chat: typeof i.inline_in_chat == "boolean" ? i.inline_in_chat : void 0,
                auth_button_label: typeof i.auth_button_label == "string" ? i.auth_button_label : void 0,
                auth_link: typeof i.auth_link == "string" ? i.auth_link : void 0,
                auth_provider: typeof i.auth_provider == "string" ? i.auth_provider : void 0,
                auth_link_expired: typeof i.auth_link_expired == "boolean" ? i.auth_link_expired : void 0,
                message_lead: typeof i.message_lead == "string" ? i.message_lead : void 0,
                window_button_label: typeof i.window_button_label == "string" ? i.window_button_label : void 0,
                window_height: typeof i.window_height == "number" ? i.window_height : void 0,
                window_width: typeof i.window_width == "number" ? i.window_width : void 0,
                window_url: typeof i.window_url == "string" ? i.window_url : void 0,
                window_title: typeof i.window_title == "string" ? i.window_title : void 0,
                is_handoff: typeof i.is_handoff == "boolean" ? i.is_handoff : void 0,
                success_business_event: (() => {
                    let e = W(i.success_business_event);
                    if (!(!e || typeof e.event_key != "string")) return {
                        event_key: e.event_key,
                        value: typeof e.value == "string" || typeof e.value == "number" ? e.value : void 0,
                        is_variable: e.is_variable === !0
                    };
                })(),
                dimensions: W(i.dimensions) ? ? void 0,
                revision: typeof i.revision == "number" && Number.isSafeInteger(i.revision) && i.revision >= 0 ? i.revision : void 0,
                survey_type: typeof i.survey_type == "string" ? i.survey_type : void 0,
                style: typeof i.style == "string" ? i.style : void 0,
                scale_type: typeof i.scale_type == "string" ? i.scale_type : void 0,
                satisfaction_style: typeof i.satisfaction_style == "string" ? i.satisfaction_style : void 0,
                score: typeof i.score == "number" ? i.score : void 0,
                feedback: Array.isArray(i.feedback) ? i.feedback.filter((e) => typeof e == "string") : void 0,
                resolved: typeof i.resolved == "boolean" || i.resolved === null ? i.resolved : void 0,
                comment: typeof i.comment == "string" || i.comment === null ? i.comment : void 0,
                customer_effort_score: typeof i.customer_effort_score == "number" ? i.customer_effort_score : void 0,
                net_promoter_score: typeof i.net_promoter_score == "number" ? i.net_promoter_score : void 0,
                is_positive: typeof i.is_positive == "boolean" || i.is_positive === null ? i.is_positive : void 0,
                follow_up_response_id: typeof i.follow_up_response_id == "string" ? i.follow_up_response_id : void 0,
                reviewable_message: typeof i.reviewable_message == "boolean" ? i.reviewable_message : void 0
            });
        }
        return e.length === 0 ? null : {
            messages: e,
            conversationId: o,
            ...n === void 0 ? {} : {
                cursor: n
            },
            ...r ? {} : {
                isFinal: !1
            }
        };
    }
    let s = null;
    typeof t.id == "string" ? s = t.id : typeof t._id == "string" && (s = t._id);
    let c = typeof t.body == "string" ? t.body : null;
    if (!s || !c) return null;
    let l = "text";
    typeof t._type == "string" ? l = t._type : typeof t.type == "string" && (l = t.type);
    let u = Oj(t);
    return {
        messages: [{
            id: s,
            body: c,
            type: l,
            ...n === void 0 ? {} : {
                cursor: n
            },
            ...u ? {
                stream_id: u
            } : {},
            source: jj(t.source),
            agent_info: W(t.agent_info) ? ? void 0,
            event: typeof t.event == "string" ? t.event : void 0
        }],
        conversationId: o,
        ...n === void 0 ? {} : {
            cursor: n
        },
        ...r ? {} : {
            isFinal: !1
        }
    };
}
var Nj = new Set([
    "thumbs",
    "emoji",
    "1-5",
    "1-7",
    "0-10",
    "1-10"
]);

function Pj(e) {
    let t = qv(typeof e == "string" ? e : null);
    return t && Nj.has(t) ? t : "1-5";
}

function Fj(e) {
    return typeof e != "number" || !Number.isFinite(e) || e <= 0 ? Date.now() : Math.round(e > 0xe8d4a51000 ? e : e * 1e3);
}

function Ij(e) {
    return typeof e == "string" && e.trim() ? e : void 0;
}

function Lj(e) {
    if (typeof e != "object" || !e) return;
    let t = e,
        n = Ij(t.title);
    if (!n) return;
    let r = Ij(t.description),
        i = Ij(t.button_label),
        a;
    if (typeof t.image == "object" && t.image !== null) {
        let e = t.image,
            n = Ij(e.url);
        if (n ? .toLowerCase().startsWith("https://")) {
            let t = Ij(e.alt);
            a = {
                url: n,
                ...t ? {
                    alt: t
                } : {}
            };
        }
    }
    return {
        title: n,
        ...r ? {
            description: r
        } : {},
        ...a ? {
            image: a
        } : {},
        ...i ? {
            buttonLabel: i
        } : {}
    };
}

function Rj(e) {
    let t = nF(e.agent_info),
        n = {
            id: e.id,
            body: e.body,
            sender: e.source ? ? "bot",
            timestamp: Fj(e.created),
            ...e.temp_message_uuid ? {
                tempMessageUuid: e.temp_message_uuid
            } : {},
            ...e.server_persisted === void 0 ? {} : {
                serverPersisted: e.server_persisted
            },
            reviewable: e.reviewable_message === !0,
            ...t ? {
                agentInfo: {
                    name: t.name,
                    imageUrl: t.imageUrl,
                    internalId: t.id,
                    defaultImage: t.defaultImage
                }
            } : {}
        },
        r = {
            ...e.cursor === void 0 ? {} : {
                cursor: e.cursor
            },
            ...e.stream_id ? {
                streamId: e.stream_id
            } : {}
        };
    switch (e.type) {
        case "text":
        case "shuffle":
            return {
                ...n,
                ...r,
                type: "text"
            };
        case "quick_replies":
        case "quick_replies_block":
            return {
                ...n,
                ...r,
                type: "quick_replies",
                quickReplies: (e.quick_replies ? ? []).filter((e) => typeof e == "object" && !!e).map((e) => {
                    let t = "";
                    typeof e.label == "string" ? t = e.label : typeof e.text == "string" && (t = e.text);
                    let n = "suggestion";
                    e.button_type === "switch" ? n = "switch" : e.button_type === "accepted_value" && (n = "accepted_value");
                    let r = typeof e.value == "string" ? e.value : void 0;
                    n === "accepted_value" && !t && r && (t = r);
                    let i = n === "accepted_value" ? Lj(e.card) : void 0;
                    return {
                        label: t,
                        target: typeof e.target == "string" ? e.target : "",
                        buttonType: n,
                        ...r === void 0 ? {} : {
                            value: r
                        },
                        ...i ? {
                            card: i
                        } : {}
                    };
                }),
                isForced: e.is_forced ? ? !1,
                ...e.button_layout === "stacked" || e.button_layout === "carousel" ? {
                    buttonLayout: e.button_layout
                } : {},
                ...typeof e.show_all == "boolean" ? {
                    showAll: e.show_all
                } : {}
            };
        case "web_window":
        case "link":
            return {
                ...n,
                ...r,
                type: "link",
                isHandoff: e.is_handoff === !0,
                isWebWindow: e.type === "web_window",
                ...e.type === "web_window" ? {
                    windowHeight: typeof e.window_height == "number" && Number.isFinite(e.window_height) && e.window_height > 0 ? e.window_height : 568,
                    windowWidth: typeof e.window_width == "number" && Number.isFinite(e.window_width) && e.window_width > 0 ? e.window_width : 320
                } : {},
                ...e.success_business_event ? .event_key ? {
                    successBusinessEvent: {
                        eventKey: e.success_business_event.event_key,
                        value: e.success_business_event.value,
                        isVariable: e.success_business_event.is_variable === !0
                    }
                } : {},
                url : e.window_url ? ? e.url ? ? "",
                linkText: e.window_button_label ? ? e.link_text ? ? "",
                title: e.window_title ? ? e.title ? ? "",
                linkDescription: e.link_description ? ? "",
                linkIcon: e.link_icon ? ? "",
                altText: e.alt_text ? ? "",
                newWindow: e.new_window ? ? !0,
                generateLinkPreview: e.generate_link_preview ? ? !1,
                articleId: e.article_id ? ? null
            };
        case "picture":
            return {
                ...n,
                ...r,
                type: "picture",
                picUrl: e.pic_url ? ? "",
                altText: e.alt_text ? ? ""
            };
        case "video":
            return {
                ...n,
                ...r,
                type: "video",
                vidUrl: e.vid_url ? ? "",
                altText: e.alt_text ? ? ""
            };
        case "downloadable":
            return {
                ...n,
                ...r,
                type: "downloadable",
                url: e.url ? ? "",
                name: e.name ? ? "",
                mimeType: e.mimeType ? ? null,
                ...e.caption ? {
                    caption: e.caption
                } : {},
                ...e.attachment_group_id ? {
                    attachmentGroupId: e.attachment_group_id
                } : {}
            };
        case "presence":
            return {
                ...n,
                ...r,
                type: "presence",
                event: e.event ? ? "generic"
            };
        case "surfaceable_list_selection":
            return {
                ...n,
                ...r,
                type: "surfaceable_list_selection",
                variableId: e.variable_id ? ? "",
                selectables: (e.selectables ? ? []).flatMap((e, t) => typeof e == "string" && e.trim() !== "" ? [{
                    id: e,
                    text: e,
                    index: t
                }] : []),
                multiple: e.multiple ? ? !1,
                prompt: e.prompt ? ? ""
            };
        case "queue_bot_block":
            return {
                ...n,
                ...r,
                type: "queue_bot_block",
                queuePosition: e.queue_position ? ? null,
                waitMessage: e.wait_message,
                platform: e.platform
            };
        case "options_message":
            {
                let t = (e.options ? ? []).filter((e) => typeof e == "object" && !!e && typeof e.label == "string" && e.label.trim() !== "").map((e) => ({
                    id: typeof e.id == "string" ? e.id : "",
                    label: e.label,
                    description: typeof e.description == "string" ? e.description : void 0,
                    datetime: typeof e.datetime == "string" ? e.datetime : void 0
                }));
                return t.length > 0 ? {
                    ...n,
                    ...r,
                    type: "options_message",
                    options: t
                } : null;
            }
        case "widget":
            return {
                ...n,
                ...r,
                type: "widget",
                widgetName: e.widget_name ? ? "",
                ariaLabel: e.aria_label ? ? "",
                widgetUrl: e.widget_url ? ? "",
                linkText: e.link_text ? ? "",
                linkSubtext: e.link_subtext ? ? "",
                inlineInChat: e.inline_in_chat ? ? !1
            };
        case "iframe":
            return {
                ...n,
                ...r,
                type: "widget",
                widgetName: e.widget_name ? ? "",
                ariaLabel: e.aria_label ? ? e.title ? ? "",
                widgetUrl: e.widget_url ? ? e.url ? ? "",
                linkText: e.link_text ? ? "",
                linkSubtext: e.link_subtext ? ? "",
                inlineInChat: !0
            };
        case "local_notification_permission":
            return {
                ...n,
                ...r,
                type: "local_notification_permission",
                body: e.body ? ? ""
            };
        case "sign_in":
            return {
                ...n,
                ...r,
                type: "sign_in",
                authButtonLabel: e.auth_button_label ? ? "",
                authLink: e.auth_link ? ? "",
                authProvider: e.auth_provider ? ? "",
                authLinkExpired: e.auth_link_expired ? ? !1,
                messageLead: e.message_lead ? ? ""
            };
        case "csat":
            return {
                ...n,
                ...r,
                type: "csat",
                revision: e.revision,
                surveyType: e.survey_type ? ? "answer_flow",
                scaleType: Pj(e.style ? ? e.scale_type ? ? e.satisfaction_style),
                score: typeof e.score == "number" ? e.score : null,
                submitted: typeof e.score == "number",
                feedback: e.feedback ? ? [],
                resolved: e.resolved ? ? null,
                comment: e.comment ? ? null,
                customerEffortScore: e.customer_effort_score ? ? null,
                netPromoterScore: e.net_promoter_score ? ? null,
                isPositive: e.is_positive ? ? null
            };
        case "meta":
        case "greeting":
            return null;
        case "incoming_app_data":
            return null;
        case "status":
            return null;
        default:
            return e.body ? {
                ...n,
                ...r,
                type: "text"
            } : null;
    }
}
//#endregion
//#region src/playbook-gate-evidence.ts
var zj = /^[0-9a-f]{24}$/i;

function Bj(e) {
    return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}

function Vj(...e) {
    for (let t of e)
        if (typeof t == "string" && zj.test(t)) return t.toLowerCase();
}

function Hj(e) {
    if (!(typeof e != "number" || !Number.isFinite(e) || e <= 0)) return e > 0xe8d4a51000 ? e : e * 1e3;
}

function Uj(e) {
    let t = Bj(e);
    if (!t) return null;
    let n = Bj(t.log) ? ? t,
        r = Bj(n.message) ? ? n,
        i = Vj(r.message_cursor, n.message_cursor, t.message_cursor, r.cursor, n.cursor, t.cursor, n._id, n.id, t._id, t.id);
    if (!i) return null;
    let a = r._type ? ? r.type,
        o = typeof a == "string" ? a : void 0,
        s = r.event,
        c = typeof s == "string" ? s : void 0,
        l = Hj(n.created ? ? t.created ? ? r.created);
    return o === "presence" && !vD(c) ? {
        cursor: i,
        ...l === void 0 ? {} : {
            createdAt: l
        },
        executing: c === "playbook_step_executing"
    } : null;
}

function Wj(e) {
    let t = [];
    for (let n of e) {
        let e = Uj(n);
        e && t.push(e);
    }
    return t;
}
//#endregion
//#region src/unified-reasoner-evidence.ts
var Gj = /^[0-9a-f]{24}$/i;

function Kj(e) {
    return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}

function qj(...e) {
    for (let t of e)
        if (typeof t == "string" && Gj.test(t)) return t.toLowerCase();
}

function Jj(e) {
    if (!(typeof e != "number" || !Number.isFinite(e) || e <= 0)) return e > 0xe8d4a51000 ? e : e * 1e3;
}

function Yj(e) {
    let t = Kj(e);
    if (!t) return null;
    let n = Kj(t.log) ? ? t,
        r = Kj(n.message) ? ? n,
        i = qj(r.message_cursor, n.message_cursor, t.message_cursor, r.cursor, n.cursor, t.cursor, n._id, n.id, t._id, t.id);
    if (!i) return null;
    let a = r._type ? ? r.type,
        o = typeof a == "string" ? a : void 0,
        s = r.event,
        c = typeof s == "string" ? s : void 0;
    if (o !== "presence" || c !== "unified_reasoner_generation_started" && c !== "unified_reasoner_generation_finished") return null;
    let l = Jj(n.created ? ? t.created ? ? r.created);
    return {
        cursor: i,
        ...l === void 0 ? {} : {
            createdAt: l
        },
        generating: c === "unified_reasoner_generation_started"
    };
}

function Xj(e) {
    let t = [];
    for (let n of e) {
        let e = Yj(n);
        e && t.push(e);
    }
    return t;
}
var Zj = 1e3,
    Qj = 3e4,
    $j = /* @__PURE__ */ new Map(),
    eM = /* @__PURE__ */ new Map(),
    tM = 100;

function nM(e) {
    return e === "user" || e === "agent" ? e : "bot";
}
var rM = 2,
    iM = [250, 500];

function aM(e) {
    return new Promise((t) => setTimeout(t, e));
}

function oM(e, t = 5) {
    if (!/^[0-9a-f]{24}$/i.test(e)) return e;
    let n = Number.parseInt(e.slice(0, 8), 16);
    return Number.isNaN(n) ? e : Math.max(0, n - t).toString(16).padStart(8, "0") + "0".repeat(16);
}

function sM(e) {
    return e ? .type === "picture" ? !!e.picUrl : e ? .type === "video" ? !!e.vidUrl : e ? .type === "downloadable" ? !!e.url : !1;
}

function cM(e) {
    if (!e._id || typeof e.created != "number") return null;
    let t = Math.round(e.created * 1e3),
        n = e.source;
    if ((e.message ? ._type ? ? e.message ? .type) === "presence") {
        let r = typeof e.message ? .event == "string" ? e.message.event : "generic";
        if (_D(r)) return null;
        let i = nF(e.message ? .agent_info);
        return {
            id: e._id,
            type: "presence",
            body: typeof e.message ? .body == "string" ? e.message.body : "",
            event: r,
            sender: nM(n),
            timestamp: t,
            cursor: e.message_cursor ? ? e._id,
            ...i ? {
                agentInfo: {
                    name: i.name,
                    imageUrl: i.imageUrl,
                    internalId: i.id,
                    defaultImage: i.defaultImage
                }
            } : {}
        };
    }
    let r = Mj({
            messages: [{
                ...e.message ? ? {},
                id : e._id,
                _id : e._id,
                source: n,
                message_cursor: e.message_cursor ? ? e._id,
                ...typeof e.stream_id == "string" ? {
                    stream_id: e.stream_id
                } : {},
                ...typeof e.generative_actions_event_id == "string" ? {
                    generative_actions_event_id: e.generative_actions_event_id
                } : {},
                ...typeof e.temp_message_uuid == "string" ? {
                    temp_message_uuid: e.temp_message_uuid
                } : {}
            }]
        }) ? .messages[0],
        i = r ? Rj(r) : null;
    if (n === "user" && (i ? .type === "csat" && i.revision !== void 0 || sM(i))) return {
        ...i,
        sender: "user",
        timestamp: t
    };
    if (n === "user") {
        let n = typeof e.message ? .body == "string" ? e.message.body : "";
        return n ? {
            id: e._id,
            type: "text",
            body: n,
            sender: "user",
            timestamp: t,
            cursor: e.message_cursor ? ? e._id,
            ...typeof e.temp_message_uuid == "string" ? {
                tempMessageUuid: e.temp_message_uuid
            } : {}
        } : null;
    }
    return i ? {
        ...i,
        timestamp: t,
        ...e.review === 1 || e.review === -1 ? {
            reaction: e.review
        } : {}
    } : null;
}

function lM(e) {
    if ("message" in e || "source" in e || "created" in e) return cM(e);
    let t = Mj({
        messages: [e]
    }) ? .messages[0];
    return t ? Rj(t) : null;
}

function uM(e) {
    let t;
    for (let n of e) {
        let e = n.cursor;
        typeof e == "string" && (t === void 0 || e > t) && (t = e);
    }
    return t;
}

function dM(e) {
    let {
        endpoint: t,
        chatterToken: n
    } = e.getState().session;
    return !t || !n ? null : {
        endpoint: t,
        chatterToken: n
    };
}

function fM(e) {
    let {
        endpoint: t,
        chatterToken: n,
        conversationId: r
    } = e.getState().session;
    return !t || !n || !r ? null : {
        endpoint: t,
        chatterToken: n,
        conversationId: r
    };
}

function pM(e) {
    let {
        chatterToken: t,
        conversationId: n,
        conversationGeneration: r
    } = e.getState().session;
    return {
        chatterToken: t,
        conversationId: n,
        conversationGeneration: r,
        reopenCandidateToken: e.getState().liveAgent.endedConversationReopenCandidateToken
    };
}

function mM(e, t) {
    let {
        chatterToken: n,
        conversationGeneration: r
    } = e.getState().session;
    return n !== t.chatterToken || r !== t.conversationGeneration;
}

function hM(e, t) {
    let {
        chatterToken: n,
        conversationId: r,
        conversationGeneration: i
    } = e.getState().session;
    return n !== t.chatterToken || r !== t.conversationId || i !== t.conversationGeneration;
}
var gM = "incoming_app_data";

function _M(e) {
    return (e.message ? ._type ? ? e.message ? .type ? ? e._type ? ? e.type) === gM;
}

function vM(e, t) {
    let n = [],
        r = [],
        i = null;
    for (let a of e) {
        if (_M(a)) {
            i && = (r.push(i), null);
            continue;
        }
        let e = t(a);
        e && (bD(e) && (i = e.id), n.push(e));
    }
    return {
        messages: n,
        answeredInteractiveIds: r
    };
}

function yM(e) {
    return vM(e, (e) => cM(e));
}

function bM(e) {
    let t;
    for (let n of e) {
        if (typeof n != "object" || !n) continue;
        let e = n._id;
        typeof e == "string" && (t === void 0 || e < t) && (t = e);
    }
    return t;
}
async function xM(e, t, n) {
    let {
        endpoint: r,
        chatterToken: i,
        conversationId: a
    } = e.getState().session, o = n ? ? a;
    if (!r || !i || !o) return null;
    let s = pM(e),
        c = await e.dispatch(wI.endpoints.getConversationLogs.initiate({
            endpoint: r,
            chatterToken: i,
            conversationId: o,
            ...t && {
                after: t
            }
        }, {
            forceRefetch: !0,
            subscribe: !1
        }));
    if ("error" in c || !c.data) return null;
    let l = c.data.log,
        {
            messages: u,
            answeredInteractiveIds: d
        } = yM(l),
        f = Wj(l),
        p = Xj(l),
        m = bM(l);
    return l.length > 0 && m === void 0 && q("history_page_cursor_missing"), {
        messages: u,
        answeredInteractiveIds: d,
        playbookGateEvidence: f,
        unifiedReasonerEvidence: p,
        canLoadMore: l.length >= 25 && m !== void 0 && (t === void 0 || m < t),
        historyPageCursor: m,
        messageCursor: uM(u),
        identity: s
    };
}

function SM(e, t, n, r) {
    let {
        liveAgent: i
    } = e.getState();
    if (i.agentAssignmentKnown && r === void 0 || !i.inLiveChat || i.platformName !== "zaw_liveagent") return;
    let a = /* @__PURE__ */ new Map(),
        o = !1,
        s = [...t].sort((e, t) => e.timestamp - t.timestamp || (e.cursor ? ? e.id).localeCompare(t.cursor ? ? t.id));
    for (let e of s) {
        if (e.type !== "presence" || r !== void 0 && (e.timestamp < r.timestamp || r.isServerTime && e.timestamp === r.timestamp) || e.event !== "agent_arrival" && e.event !== "agent_depart" && e.event !== "agent_snoozed" || !e.agentInfo ? .internalId) continue;
        o = !0;
        let t = e.agentInfo.internalId;
        a.set(t, {
            id: t,
            name: e.agentInfo.name,
            imageUrl: e.agentInfo.imageUrl,
            defaultImage: e.agentInfo.defaultImage,
            isActive: e.event === "agent_arrival",
            isTyping: !1
        });
    }
    if (r !== void 0)
        for (let t of a.values()) e.dispatch(KE({
            ...t,
            isRestored: !0,
            isTyping: t.isActive ? i.agents[t.id] ? .isTyping ? ? !1 : !1
        }));
    else(o || !n) && e.dispatch(VE({
        agents: [...a.values()]
    }));
}
async function CM(e) {
    let {
        agentAssignmentSeq: t,
        agentRosterRecovery: n
    } = e.getState().liveAgent, r = await xM(e);
    if (!r || hM(e, r.identity)) return null;
    let {
        historyConversationIds: i
    } = e.getState().chat, a = r.canLoadMore || i.length > 1;
    if (vj(e, r.identity.conversationId, r.identity.reopenCandidateToken, [
            ...r.messages.filter((e) => e.type !== "csat" || e.sender !== "user").map((e) => e.cursor),
            ...r.playbookGateEvidence.map((e) => e.cursor),
            ...r.unifiedReasonerEvidence.map((e) => e.cursor)
        ]), e.dispatch(NO(r.playbookGateEvidence)), e.dispatch(DO(r.unifiedReasonerEvidence)), e.getState().liveAgent.agentAssignmentSeq === t) {
        let n = e.getState().liveAgent.agentRosterRecovery;
        SM(e, r.messages, r.canLoadMore, n ? .agentAssignmentSeq === t ? n : void 0);
    }
    return e.dispatch(RO({
        messages: r.messages,
        answeredInteractiveIds: r.answeredInteractiveIds,
        canLoadMore: a,
        historyConversationCursor: r.historyPageCursor ? ? null,
        conversationId: r.identity.conversationId ? ? void 0,
        messageCursor: r.messageCursor
    })), n && e.dispatch(WE(n.agentAssignmentSeq)), r.messageCursor ? ? null;
}
async function wM(e) {
    let t = fM(e);
    if (!t) return null;
    let n = `${t.chatterToken}:${t.conversationId}`,
        r = $j.get(n);
    if (r) return r;
    let i = CM(e).finally(() => {
        $j.delete(n);
    });
    return $j.set(n, i), i;
}
async function TM(e, t) {
    let n = dM(e);
    if (!n) return null;
    let r = pM(e),
        i = await e.dispatch(wI.endpoints.getMessagesAfterCursor.initiate({
            endpoint: n.endpoint,
            chatterToken: n.chatterToken,
            afterCursor: t
        }, {
            forceRefetch: !0,
            subscribe: !1
        }));
    if ("error" in i || !i.data) return null;
    let {
        messages: a,
        answeredInteractiveIds: o
    } = vM(i.data.messages, lM), s = Wj(i.data.messages), c = Xj(i.data.messages), l = Object.hasOwn(i.data, "conversation_id") && (typeof i.data.conversation_id == "string" || i.data.conversation_id === null);
    return {
        messages: a,
        answeredInteractiveIds: o,
        playbookGateEvidence: s,
        unifiedReasonerEvidence: c,
        pageMaxCursor: typeof i.data.page_max_cursor == "string" ? i.data.page_max_cursor : void 0,
        hasMore: i.data.has_more === !0,
        ...l ? {
            serverConversationId: i.data.conversation_id ? ? null
        } : {},
        identity: r
    };
}
async function EM(e, t, n) {
    for (let r = 0; r <= rM; r += 1) {
        if (hM(e, n)) return null;
        let i = await TM(e, t);
        if (i) return i;
        if (hM(e, n)) return null;
        r < rM && await aM(iM[r]);
    }
    return null;
}
async function DM(e, t, n, r) {
    let i = dM(e);
    if (!i) return null;
    let a = e.getState().session.conversationId,
        o = `${i.chatterToken}:${a}:${t}:${n}`,
        s = eM.get(o);
    if (s) return s;
    let c = (async () => {
        let i = t,
            o = null,
            s = a,
            c = n === "baseline",
            l = pM(e);
        for (let t = 0; t < tM; t += 1) {
            if (mM(e, l)) return null;
            let t = e.getState().session.conversationId;
            t !== s && (i = "", c = !0, o = null, s = t);
            let n = pM(e),
                a = await EM(e, i, n);
            if (!a) {
                if (mM(e, l)) return null;
                let t = e.getState().session.conversationId;
                if (t !== s) {
                    i = "", c = !0, o = null, s = t;
                    continue;
                }
                break;
            }
            if (mM(e, l)) return null;
            let u = a.identity.conversationId;
            if ("serverConversationId" in a) {
                let t = a.serverConversationId;
                if (t == null || e.getState().session.conversationId !== t && !r ? .(t) || e.getState().session.conversationId !== t) return null;
                u = t;
            } else {
                if (!a.identity.conversationId) return null;
                if (hM(e, a.identity)) {
                    let t = e.getState().session.conversationId;
                    if (t !== s) {
                        i = "", c = !0, o = null, s = t;
                        continue;
                    }
                    return null;
                }
            }
            if (u !== s && (s = u, i !== "")) {
                i = "", c = !0, o = null;
                continue;
            }
            let d = a.pageMaxCursor;
            "serverConversationId" in a && vj(e, u, a.identity.reopenCandidateToken, [
                ...a.messages.filter((e) => e.type !== "csat" || e.sender !== "user").map((e) => e.cursor),
                ...a.playbookGateEvidence.map((e) => e.cursor),
                ...a.unifiedReasonerEvidence.map((e) => e.cursor)
            ]), e.dispatch(NO(a.playbookGateEvidence)), e.dispatch(DO(a.unifiedReasonerEvidence)), e.dispatch(zO({
                messages: a.messages,
                answeredInteractiveIds: a.answeredInteractiveIds,
                conversationId: u ? ? void 0,
                recovery: c ? "baseline" : "incremental",
                messageCursor: d
            }));
            let f = typeof d == "string" && d > i;
            if (f && (o = d, i = d), !a.hasMore || !f) break;
        }
        return o;
    })().finally(() => {
        eM.delete(o);
    });
    return eM.set(o, c), c;
}
async function OM(e, t) {
    let {
        canLoadMore: n,
        loadingPreviousMessages: r
    } = e.getState().chat;
    if (!n || r) return;
    let {
        historyConversationIds: i,
        historyConversationIndex: a,
        historyConversationCursor: o
    } = e.getState().chat, s = i[a];
    if (!s || !dM(e)) return;
    let c = e.getState().chat.historyPageBackoff;
    if ((!c || c.conversationId !== s || hM(e, c.identity)) && (c = {
            identity: pM(e),
            conversationId: s,
            delayMs: 0,
            retryAt: 0
        }), Date.now() < c.retryAt) return;
    let l = () => {
        if (hM(e, c.identity)) return;
        let t = Math.min(c.delayMs * 2 || Zj, Qj);
        e.dispatch(KO({
            ...c,
            delayMs: t,
            retryAt: Date.now() + t
        }));
    };
    e.dispatch(qO(!0));
    try {
        let t = await xM(e, o ? ? void 0, s);
        if (!t) {
            l();
            return;
        }
        if (hM(e, t.identity)) return;
        let n, r, c;
        t.canLoadMore ? (n = a, r = t.historyPageCursor ? ? o, c = !0) : (n = a + 1, r = null, c = n < i.length);
        let u = s === e.getState().session.conversationId;
        u && (e.dispatch(NO(t.playbookGateEvidence)), e.dispatch(DO(t.unifiedReasonerEvidence))), e.dispatch(GO({
            messages: t.messages,
            answeredInteractiveIds: t.answeredInteractiveIds,
            canLoadMore: c,
            historyConversationIndex: n,
            historyConversationCursor: r,
            conversationId: s,
            isCurrentConversation: u
        }));
    } catch (e) {
        l(), t ? .(e);
    } finally {
        e.dispatch(qO(!1));
    }
}
//#endregion
//#region src/persistence/greeting-lease.ts
function kM(e) {
    try {
        let t = JSON.parse(e ? ? "null");
        if (!t || typeof t != "object" || Array.isArray(t)) return null;
        for (let [e, n] of Object.entries(t))
            if (!/^[0-9a-f]{16}$/.test(e) || !n || typeof n.owner != "string" || typeof n.expiresAt != "number" || !Number.isFinite(n.expiresAt)) return null;
        return t;
    } catch {
        return null;
    }
}

function AM(e, t) {
    if (e === null) return !1;
    if (t === null) return !0;
    let n = kM(e),
        r = kM(t);
    return n !== null && r !== null && Object.keys(n).length === Object.keys(r).length + 1 && Object.entries(r).every(([e, t]) => n[e] ? .owner === t.owner && n[e] ? .expiresAt === t.expiresAt);
}
//#endregion
//#region src/persistence/session-mirror-channel.ts
var jM = null,
    MM = /* @__PURE__ */ new Set(),
    NM = /* @__PURE__ */ new Set();

function PM(e) {
    NM.add(e);
}

function FM(e) {
    return NM.delete(e);
}

function IM(e) {
    jM = e;
}

function LM(e, t) {
    jM ? .("core.event.publish", {
        key: e,
        data: t
    });
}

function RM(e) {
    return MM.add(e), () => {
        MM.delete(e);
    };
}

function zM() {
    for (let e of MM) e.scheduleEmit();
}

function BM(e) {
    for (let t of MM) t.acknowledgeClear(e);
}

function VM(e, t) {
    for (let n of MM) n.deliverSeed(e, t);
}
//#endregion
//#region src/persistence/shared-session-lock.ts
var HM = !1;

function UM(e) {
    if (HM) return e();
    let t = !1,
        n = () => {
            t = !0, HM = !0;
            try {
                return e();
            } finally {
                HM = !1;
            }
        },
        r;
    try {
        let e = typeof navigator > "u" ? void 0 : navigator.locks;
        if (!e) return n();
        let i = new AbortController();
        return r = setTimeout(() => i.abort(), 2e3), Promise.resolve(e.request(Qo, {
            mode: "exclusive",
            signal: i.signal
        }, () => (clearTimeout(r), n()))).catch((e) => {
            if (t) throw e;
            return n();
        }).finally(() => clearTimeout(r));
    } catch (e) {
        if (clearTimeout(r), t) throw e;
        return n();
    }
}
//#endregion
//#region src/persistence/conversation-persistence.ts
var WM = /* @__PURE__ */ e({
    ConversationPersistenceService: () => gN,
    HANDOFF_ONLY_WIPE_MAX_ATTEMPTS: () => 3,
    HANDOFF_ONLY_WIPE_SETTLE_MS: () => hN,
    LEGACY_HANDOFF_OBSERVATION_GRACE_MS: () => $M,
    parsePersistedSession: () => Q
});

function GM(e) {
    return Bo(e) ? .ownerChatterToken ? ? qo(e);
}

function KM(e) {
    try {
        let t = JSON.parse(e);
        if (t && typeof t == "object" && "chatterToken" in t && typeof t.chatterToken == "string" && t.chatterToken) return {
            chatterToken: t.chatterToken,
            companionCleared: !1
        };
        if (t && typeof t == "object" && "companionCleared" in t && t.companionCleared === !0) return {
            chatterToken: null,
            companionCleared: !0
        };
    } catch {}
    return {
        chatterToken: null,
        companionCleared: !1
    };
}
var qM = /* @__PURE__ */ new Set(),
    JM = /* @__PURE__ */ new Map();

function YM(e) {
    let t = JM.get(e);
    t && (t.signal.removeEventListener("abort", t.onAbort), JM.delete(e));
}

function XM(e) {
    let t = /^seqreq_([A-Za-z0-9-]{1,100})_([1-9][0-9]{0,15})$/.exec(e);
    if (!t ? .[1] || !t[2]) return null;
    let n = Number(t[2]);
    return Number.isSafeInteger(n) ? {
        namespace: t[1],
        highWater: n
    } : null;
}

function ZM(e) {
    return `${e.namespace}:${e.highWater}`;
}

function QM(e) {
    if (!e) return null;
    let t = e.lastIndexOf(":");
    if (t <= 0) return null;
    let n = e.slice(0, t),
        r = Number(e.slice(t + 1));
    return !/^[A-Za-z0-9-]{1,100}$/.test(n) || !Number.isSafeInteger(r) || r < 1 ? null : {
        namespace: n,
        highWater: r
    };
}
var $M = 5 * 6e4,
    eN = 3,
    tN = 3,
    nN = 8,
    rN = 3,
    iN = 5e3,
    aN = 1e3,
    oN = 500,
    sN = 5,
    cN = 3;

function Q(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e);
        return t.version !== 1 || typeof t.chatterToken != "string" || !t.chatterToken ? null : {
            version: 1,
            chatterId: typeof t.chatterId == "string" ? t.chatterId : "",
            chatterToken: t.chatterToken,
            language: typeof t.language == "string" && t.language ? t.language : void 0,
            sessionToken: typeof t.sessionToken == "string" ? t.sessionToken : null,
            sessionTokenExpiresAt: typeof t.sessionTokenExpiresAt == "number" ? t.sessionTokenExpiresAt : null,
            sessionRefreshToken: typeof t.sessionRefreshToken == "string" ? t.sessionRefreshToken : null,
            messagingToken: typeof t.messagingToken == "string" ? t.messagingToken : null,
            messagingTokenExpiresAt: typeof t.messagingTokenExpiresAt == "number" ? t.messagingTokenExpiresAt : null,
            refreshGeneration: typeof t.refreshGeneration == "number" ? t.refreshGeneration : null,
            identitySession: typeof t.identitySession == "boolean" ? t.identitySession : void 0
        };
    } catch {
        return null;
    }
}

function lN(e, t) {
    if (!e) return null;
    try {
        let n = JSON.parse(e);
        return n.version === 1 && (n.clock === "legacy-local" || n.clock === "plain") && n.createdAt === t ? n.clock : null;
    } catch {
        return null;
    }
}

function uN(e, t) {
    return JSON.stringify({
        version: 1,
        clock: e,
        createdAt: t
    });
}

function dN(e, t = Date.now()) {
    return e.sessionTokenExpiresAt !== null && e.sessionTokenExpiresAt <= t;
}

function fN(e, t) {
    return !e || !t ? e === t : e.chatterId === t.chatterId && e.chatterToken === t.chatterToken && e.language === t.language && e.sessionToken === t.sessionToken && e.sessionTokenExpiresAt === t.sessionTokenExpiresAt && e.sessionRefreshToken === t.sessionRefreshToken && e.messagingToken === t.messagingToken && e.messagingTokenExpiresAt === t.messagingTokenExpiresAt && e.refreshGeneration === t.refreshGeneration && e.sessionCookieIssued === t.sessionCookieIssued && e.identitySession === t.identitySession;
}
var pN = lr("conversation-persistence");

function mN(e) {
    if (typeof e == "object" && e && "name" in e) {
        let {
            name: t
        } = e;
        if (typeof t == "string") return t;
    }
    return typeof e;
}
var hN = 1500,
    gN = class e {
        constructor(t, n, r, i) {
            j(this, "lifecycleAuthBaselines", /* @__PURE__ */ new WeakMap()), j(this, "store", void 0), j(this, "storage", void 0), j(this, "handle", void 0), j(this, "key", void 0), j(this, "legacyKey", void 0), j(this, "messagingAuthStateKey", void 0), j(this, "readStateKey", void 0), j(this, "handoffStateKey", void 0), j(this, "existingChatterSnapshotKeys", void 0), j(this, "durableClearReceiptKeyPrefix", void 0), j(this, "durableClearReceiptStorage", void 0), j(this, "pendingResetKey", void 0), j(this, "hydrateKeys", void 0), j(this, "_lastSavedReadState", null), j(this, "_pendingReadState", null), j(this, "_lastRefusedReadState", null), j(this, "_lastSavedHandoffState", null), j(this, "_handoffOnlyWipe", "armed"), j(this, "_handoffOnlyWipeTimer", null), j(this, "_handoffOnlyOwnsMirrors", !1), j(this, "_handoffOnlyWipeFailureReported", !1), j(this, "_handoffOnlyWipeAttempts", 0), j(this, "_handoffOnlyWipeGeneration", 0), j(this, "createChatter", void 0), j(this, "validateRestoredSession", void 0), j(this, "exchangeMessagingSession", void 0), j(this, "_pendingRestoredChatterToken", null), j(this, "_pendingChatterPersistenceCommit", null), j(this, "_pendingChatterCommitAttempt", null), j(this, "_clearingSession", null), j(this, "_terminalClearsInProgress", 0), j(this, "_terminalClearSessions", []), j(this, "_terminalClearsIdleResolvers", []), j(this, "_restoreHistoryPromise", null), j(this, "_historyRestoreGeneration", 0), j(this, "_storeUnsubscribe", null), j(this, "_lastSavedMessagingToken", null), j(this, "_lastSavedRefreshToken", null), j(this, "_lastSavedSessionCookieIssued", !1), j(this, "_lastSavedRefreshGeneration", null), j(this, "_lastSavedLanguage", null), j(this, "_lastSavedChatterToken", null), j(this, "_sessionSaveInFlight", !1), j(this, "_sessionSaveRequested", !1), j(this, "_sessionSaveBackoffTimer", null), j(this, "_sessionSaveBackoffKind", null), j(this, "_sessionSaveDeferredBackoffKind", null), j(this, "_sessionSaveFlushRetries", 0), j(this, "_sessionSaveFailureReported", /* @__PURE__ */ new Set()), j(this, "_sessionSaveConflictEpisodes", 0), j(this, "_sessionSaveConflictStuckReported", !1), j(this, "_tokenSyncEpoch", 0), j(this, "_unverifiedOwnershipChatterToken", null), j(this, "_unverifiedOwnershipRevalidation", null), j(this, "_unverifiedOwnershipWithheldReported", !1), j(this, "handoffOnlyPersistence", void 0), j(this, "isCurrentPersistence", void 0), j(this, "storageMode", void 0), j(this, "zdmPersistence", void 0), j(this, "_zdmSavedCursor", null), j(this, "_zdmOwnedSession", null), j(this, "_confirmedHandoffEnd", null), j(this, "_observedLocalHandoff", !1), j(this, "_sharedMutationPending", null), j(this, "_sharedWriteConflictReported", /* @__PURE__ */ new Set()), j(this, "_sharedWriteBatch", null), j(this, "_sharedWriteOperations", null), j(this, "_sharedMergeKeys", null), j(this, "_sharedCommitCallbacks", null), this.store = t, this.storage = n, this.handle = r, this.storageMode = n.mode;
            let {
                endpoint: a,
                cluster: o
            } = this.store.getState().session;
            this.key = Zo(r, a, o), this.pendingResetKey = `${this.key}:pending-reset`, YM(this.key), this.legacyKey = $o(r), this.messagingAuthStateKey = Ro, this.readStateKey = yN(r, a, o), this.handoffStateKey = es(r, a, o), this.existingChatterSnapshotKeys = FN(r, a, o), this.durableClearReceiptKeyPrefix = `${this.key}:durable-clear-receipt:${this.storageMode}`, this.durableClearReceiptStorage = i.durableClearReceiptStorage ? ? Hx("session"), this.hydrateKeys = PN(r, a, o), this.createChatter = i.createChatter, this.isCurrentPersistence = i.isCurrentPersistence ? ? (() => !0), this.validateRestoredSession = i.validateRestoredSession;
            let s = i.exchangeMessagingSession;
            this.exchangeMessagingSession = s ? (e, t) => s(e, t, n) : void 0, this.handoffOnlyPersistence = i.handoffOnlyPersistence === !0, this.zdmPersistence = n.mode === "session" && i.zdmStorage ? .mode === "normal" ? new e(t, i.zdmStorage, r, {
                ...i,
                zdmStorage: void 0,
                handoffOnlyPersistence: !1,
                isCurrentPersistence: () => this.isCurrentPersistence(this)
            }) : null;
        }
        _zdmTarget() {
            let e = this.store.getState().session;
            return this.storageMode === "private" || e.identityToken || e.identitySession || e.features.adaGlassZendeskMessaging !== !0 ? null : this.zdmPersistence ? ? (this.storageMode === "normal" ? this : null);
        }
        async _restoreZdmContinuity(e) {
            let t = this._zdmTarget();
            if (!t) return null;
            let n = this._readPersistedSession(),
                r = n ? J(n) : {
                    chatterToken: I(this.storage.get(P)),
                    sessionToken: I(this.storage.get(F))
                },
                i = await t._readConfirmedExistingChatterSnapshot(e);
            if (i.kind === "superseded") return {
                kind: "aborted"
            };
            if (i.kind !== "snapshot") return t !== this && n ? null : {
                kind: "ownership_unresolved"
            };
            let a = I(i.values.zdMessagingExternalUserId);
            if (!a || !t._hasZDMessagingContinuity(a, (e) => i.values[e] ? ? null)) return null;
            let o = await t.restoreExistingChatter(a, e, {
                suppressChatterAnnouncement: !1
            });
            if (o.kind === "restored") return this._pendingRestoredChatterToken = o.chatterToken, this._zdmOwnedSession = J(this.store.getState().session), t !== this && this.stageIdentifiedSessionForRestore(r), {
                kind: "restored"
            };
            if (o.kind === "superseded" || o.kind === "aborted") return {
                kind: "aborted"
            };
            if (o.kind === "terminal" || o.kind === "expired") {
                let n = t._assessExistingChatterSnapshot(i);
                if (n.kind !== "eligible" && n.kind !== "expired") return {
                    kind: "ownership_unresolved"
                };
                let r = n.kind === "eligible" ? n.session : Q(i.values[t.key] ? ? null) ? ? Q(i.values[t.legacyKey] ? ? null),
                    s = r ? J(r) : {
                        chatterToken: n.kind === "eligible" ? n.chatterToken : a,
                        sessionToken: I(i.values.sessionToken ? ? null)
                    };
                if (s.chatterToken !== a) return {
                    kind: "ownership_unresolved"
                };
                o.kind === "terminal" && o.handoffEnded && Object.assign(i.values, {
                    [t.handoffStateKey]: null,
                    [L]: null,
                    [R]: null,
                    zdMessagingExternalUserId: null,
                    zdMessagingChatterCreated: null,
                    zdMessagingGeneration: null
                });
                let c;
                if (!await t.mutateSharedSession(s, () => {
                        t._clearConfirmedConversationBucket(), t._removeSharedValue("zdMessagingExternalUserId"), t._removeSharedValue("zdMessagingChatterCreated"), t._removeSharedValue("zdMessagingGeneration");
                    }, {
                        confirmedEnd: !0,
                        baseline: i.values,
                        isCurrent: () => !e.aborted && this.isCurrentPersistence(this),
                        onRefused: (e) => {
                            c = e;
                        }
                    })) return e.aborted ? {
                    kind: "aborted"
                } : {
                    kind: "ownership_unresolved",
                    ...c ? {
                        refusal: c
                    } : {}
                };
            }
            return [
                "unconfirmed",
                "validation_unavailable",
                "exchange_unavailable"
            ].includes(o.kind) ? {
                kind: "ownership_unresolved"
            } : null;
        }
        async _syncZdmContinuity() {
            let e = this._zdmTarget();
            if (!e || this.store.getState().session._chatterAnnouncementSuppressed || this._sharedStateWriteWithheld()) return;
            let {
                session: t,
                liveAgent: n
            } = this.store.getState(), r = n.platformName === "zaw_liveagent" && (n.inPending || n.inLiveChat), i = J(t), a = t.chatterToken;
            if (!a || !i.sessionToken) return;
            let o = JSON.stringify([i, r]),
                s = this._tokenSyncEpoch,
                c = () => s === this._tokenSyncEpoch && this.isCurrentPersistence(this) && this._zdmTarget() === e && !this.store.getState().session._chatterAnnouncementSuppressed && !this._persistenceWithheld(a);
            if (!(o === this._zdmSavedCursor && (!r || e._hasZDMessagingContinuity(a, (t) => e.storage.get(t))))) {
                if (!r) {
                    let t = this._confirmedHandoffEnd;
                    if (!t || t.owner.chatterToken !== i.chatterToken || t.owner.sessionToken !== i.sessionToken || this._zdmOwnedSession ? .chatterToken !== a && I(e.storage.get("zdMessagingExternalUserId")) !== a) return;
                    let n = {
                        ...t.zdmBaseline ? ? t.baseline,
                        ...t.zdmPair
                    };
                    await e.mutateSharedSession(i, () => {
                        e._removeSharedValue("zdMessagingExternalUserId"), e._removeSharedValue("zdMessagingChatterCreated"), e._removeSharedValue("zdMessagingGeneration"), e !== this && (e._removeSharedValue("messagingAuthState"), e._removeLegacySessionKeys());
                    }, {
                        confirmedEnd: !0,
                        endBaseline: n,
                        acceptedStoredCredentials: [i.credential, this._zdmOwnedSession ? this._zdmOwnedSession.credential : t.zdmCredential],
                        isCurrent: () => c() && !(this.store.getState().liveAgent.inPending || this.store.getState().liveAgent.inLiveChat)
                    }) && (this._zdmSavedCursor = o, this._zdmOwnedSession = null);
                    return;
                }
                await e.mutateSharedSession(i, () => {
                    e._setSharedValue("zdMessagingGeneration", JSON.stringify(dT())), e._mirrorLegacySessionKeys(a, t.sessionToken), e._saveMessagingAuthState({
                        ...t,
                        chatterToken: a
                    }), e._setSharedValue("zdMessagingExternalUserId", JSON.stringify(t.chatterToken)), e._updateSharedValues(["zdMessagingChatterCreated"], (e) => ({
                        zdMessagingChatterCreated: e.zdMessagingChatterCreated || JSON.stringify(String(Date.now()))
                    }));
                    let n = e._sharedWriteBatch;
                    e._afterSharedCommit(() => {
                        let e = this._confirmedHandoffEnd;
                        if (!(!e || !n || e.owner.chatterToken !== i.chatterToken || e.owner.sessionToken !== i.sessionToken)) {
                            for (let t of [e.zdmPair, e.zdmBaseline ? ? e.baseline])
                                for (let e of Object.keys(t)) e in n && (t[e] = n[e]);
                            this._zdmOwnedSession = i, this._syncZdmContinuity();
                        }
                    });
                }, {
                    preservesHandoff: !0,
                    replacesOwnership: !0,
                    isCurrent: () => c() && this.store.getState().liveAgent.platformName === "zaw_liveagent" && (this.store.getState().liveAgent.inLiveChat || this.store.getState().liveAgent.inPending)
                }) && (this._zdmSavedCursor = o, this._zdmOwnedSession = i);
            }
        }
        persistsNothingNow() {
            return this.storageMode === "private" || this._persistenceSuppressed();
        }
        _persistenceSuppressed() {
            if (!this.handoffOnlyPersistence) return !1;
            let {
                inLiveChat: e,
                inPending: t
            } = this.store.getState().liveAgent;
            return !(e || t);
        }
        captureLifecycleAuthBaseline(e) {
            return this.lifecycleAuthBaselines.has(e) || this.lifecycleAuthBaselines.set(e, this.captureStaleAuthBaseline()), this.lifecycleAuthBaselines.get(e) ? ? null;
        }
        captureStaleAuthBaseline() {
            let e = [this.messagingAuthStateKey];
            try {
                let t = this.storage.getConfirmedSync ? .(e);
                return t ? t.confirmed ? t.values[this.messagingAuthStateKey] ? ? null : null : this.storage.hydrated ? .(e) === !1 ? null : this.storage.get(this.messagingAuthStateKey);
            } catch {
                return null;
            }
        }
        async restoreOwningIdentity(e, t = {}) {
            let n = 1,
                r, i = this.captureLifecycleAuthBaseline(e);
            for (;; n++) {
                let a = n === eN;
                r = await this.restore(e, {
                    commitUnverified: a,
                    restoreOnly: t.restoreOnly,
                    staleAuthBaseline: i
                });
                let o = this._pendingChatterPersistenceCommit;
                if (r.kind === "uncommitted" && r.refusal ? .refusalGuard === "can_clear_shared_handoff" && r.refusal.refusalOwner === "legacy_chatter" && o ? .kind === "fresh" && o.chatterToken === this.store.getState().session.chatterToken && !e.aborted) {
                    q("chatter_restore_retried", {
                        attempt: n,
                        reason: r.kind,
                        ...r.refusal
                    });
                    let t = await this._readConfirmedSnapshot(this.hydrateKeys, e);
                    if (t.kind === "snapshot" && t.coherent !== !1 && this.hydrateKeys.every((e) => e in t.values) && !e.aborted && this._pendingChatterPersistenceCommit === o && this.store.getState().session.chatterToken === o.chatterToken && this._terminalClearsInProgress === 0 && !this._currentSessionIsClearing()) {
                        let n = this._assessExistingChatterSnapshot({
                            kind: "snapshot",
                            values: t.values
                        });
                        if (n.kind === "eligible" && n.chatterToken !== o.chatterToken && (await this.restoreExistingChatter(n.chatterToken, e, {
                                suppressChatterAnnouncement: !1,
                                requireCommittedSibling: !0
                            })).kind === "restored") return this._pendingChatterPersistenceCommit === o && (this._pendingChatterPersistenceCommit = null), {
                            kind: "restored"
                        };
                    }
                }
                if (r.kind !== "identity_rotated" && r.kind !== "ownership_unresolved" && r.kind !== "pre_create_refused" || a || !this.storage.getConfirmed) break;
                q("chatter_restore_retried", {
                    attempt: n,
                    reason: r.kind,
                    ...r.refusal
                });
                let s = await this._readConfirmedSnapshot(this.hydrateKeys, e);
                if (s.kind === "superseded") return q("chatter_restore_superseded", {
                    reason: "aborted"
                }), {
                    kind: "aborted"
                };
                if (s.kind !== "snapshot") break;
            }
            return (r.kind === "identity_rotated" || r.kind === "pre_create_refused" || r.kind === "uncommitted" || r.kind === "ownership_unresolved") && q("chatter_restore_refused", {
                reason: r.kind,
                attempt: n,
                ...r.refusal
            }), r;
        }
        async restore(e, {
            commitUnverified: t = !1,
            replacementRetry: n = 0,
            restoreOnly: r = !1,
            staleAuthBaseline: i = null
        } = {}) {
            if (this.zdmPersistence) {
                let t = await this._readPendingReset(e);
                if (t === void 0) return {
                    kind: e.aborted ? "aborted" : "ownership_unresolved"
                };
                if (t && !await this.clearDurably(e)) return e.aborted ? {
                    kind: "aborted"
                } : {
                    kind: "ownership_unresolved",
                    refusal: {
                        refusalGuard: "pending_reset_clear",
                        refusalOwner: "none"
                    }
                };
            }
            let a = this._zdmTarget();
            if (a && (a !== this || !this._persistedChatterToken() && !I(this.storage.get("chatter")) && this._hasZDMessagingContinuity(I(this.storage.get("zdMessagingExternalUserId")), (e) => this.storage.get(e)))) {
                let t = await this._restoreZdmContinuity(e);
                if (t) return t;
            }
            let o = JM.get(this.key);
            o && (o.persistence !== this || o.signal !== e || e.aborted || !this.isCurrentPersistence(this)) && YM(this.key), this._rehydrateReadState();
            let s, c = this._readPersistedSession((e) => {
                    s = {
                        source: e,
                        createdPresent: this.storage.get($) !== null,
                        messagingCreatedClockPresent: this.storage.get(_N) !== null,
                        messagingSessionPresent: this.storage.get(this.key) !== null || this.storage.get(this.legacyKey) !== null
                    };
                }),
                l = c ? ? Q(this.storage.get(this.key)) ? ? Q(this.storage.get(this.legacyKey)),
                u = J(this.store.getState().session),
                d = Object.fromEntries([
                    this.key,
                    this.legacyKey,
                    this.messagingAuthStateKey
                ].map((e) => [e, this.storage.get(e)])),
                f = {
                    baseline: {
                        ...this._handoffEndBaseline(),
                        zdMessagingExternalUserId: this.storage.get("zdMessagingExternalUserId"),
                        zdMessagingChatterCreated: this.storage.get("zdMessagingChatterCreated")
                    },
                    inLiveChat: this.store.getState().liveAgent.inLiveChat,
                    inPending: this.store.getState().liveAgent.inPending
                },
                p = l ? J(l) : {
                    chatterToken: I(this.storage.get("chatter")) ? ? u.chatterToken,
                    sessionToken: I(this.storage.get("sessionToken")) ? ? u.sessionToken,
                    credential: lS(this._readMessagingAuthState(I(this.storage.get("chatter")) ? ? void 0)) ? ? u.credential
                },
                m = this._capturedIdentityAnchors(),
                {
                    elapsed: h,
                    awaitedStorage: g,
                    confirmedEnd: _ = !1
                } = await this._chatterExpiryWindowElapsed(c);
            if (e.aborted) return q("chatter_restore_superseded", {
                reason: "aborted"
            }), {
                kind: "aborted"
            };
            let v = await this._identityOwnership(m, g, e),
                y = !1;
            if (v.kind !== "confirmed")
                if (v.kind === "unresolved" && t) y = !0, q("chatter_restore_identity_unreadable", {
                    expiry_skipped: h,
                    committed_unverified: !0
                });
                else return v.outcome;
            else if (h) return YM(this.key), q("chatter_expired_persistence_window"), this._createFreshSession(c ? .chatterToken, e, p, f, {
                confirmedEnd: _,
                discardStaleZdm: !0,
                restoreOnly: r,
                staleAuthBaseline: i,
                credentialBaseline: d
            });
            let b = this.store.getState().session,
                x = JM.get(this.key);
            if (b.endpoint && p.chatterToken && vN(this.storage.get("created")) !== null && b.persistence === "normal" && b.messagingSessionCookieEnabled === !0 && (!qM.has(this.key) || x) && !y && this.storageMode === "normal" && !this.handoffOnlyPersistence && !b.identitySession && !b.identityToken && (!l || l.identitySession === !1) && !c && !p.sessionToken && !p.credential && !b.sessionToken && !b.messagingToken && !b.sessionRefreshToken) {
                if (!x) {
                    q("chatter_cookie_restore_attempted");
                    let t = this.key;
                    qM.add(t), x = {
                        persistence: this,
                        signal: e,
                        onAbort: () => YM(t),
                        result: ES(b.endpoint, p.chatterToken, e).then((e) => e ? {
                            restored: {
                                ...e,
                                messagingTokenExpiresAt: Date.now() + e.expiresIn * 1e3
                            }
                        } : (YM(t), {
                            reason: "rejected_or_unusable"
                        }), (e) => (YM(t), e instanceof wS ? {
                            reason: "rate_limited"
                        } : {
                            reason: "network_or_timeout"
                        }))
                    }, JM.set(t, x), e.addEventListener("abort", x.onAbort, {
                        once: !0
                    }), e.aborted && YM(t);
                }
                let n = await x.result,
                    r = "restored" in n ? n.restored : null;
                if (e.aborted || !this.isCurrentPersistence(this) || r && JM.get(this.key) !== x) return YM(this.key), q("chatter_cookie_restore_failed", {
                    reason: "superseded"
                }), {
                    kind: "aborted"
                };
                if (r ? .sessionRefreshToken && r.refreshGeneration && r.chatterToken === p.chatterToken) {
                    let n = await this._identityOwnership(m, !0, e);
                    if (e.aborted || !this.isCurrentPersistence(this) || JM.get(this.key) !== x) return YM(this.key), q("chatter_cookie_restore_failed", {
                        reason: "superseded"
                    }), {
                        kind: "aborted"
                    };
                    if (n.kind !== "confirmed") {
                        if (q("chatter_cookie_restore_failed", {
                                reason: n.outcome.kind
                            }), n.kind === "stop" || n.kind === "unresolved" && !t) return n.outcome;
                        n.kind === "unresolved" && (y = !0);
                    } else {
                        YM(this.key);
                        let t = {
                                messagingToken: r.messagingToken,
                                messagingTokenExpiresAt: r.messagingTokenExpiresAt,
                                sessionRefreshToken: r.sessionRefreshToken,
                                refreshGeneration: r.refreshGeneration,
                                sessionCookieIssued: r.sessionCookieIssued === !0
                            },
                            n = await this._persistSessionCookie(p, () => this._saveCurrentSession({
                                ...this.store.getState().session,
                                ...t,
                                chatterToken: r.chatterToken,
                                chatterId: "",
                                sessionToken: r.sessionToken,
                                sessionTokenExpiresAt: null,
                                identitySession: !1
                            }), {
                                replacement: r.chatterToken,
                                preservesHandoff: !0,
                                baseline: d,
                                isCurrent: () => {
                                    let t = this.store.getState().session;
                                    return !e.aborted && this.isCurrentPersistence(this) && t.persistence === b.persistence && t.chatterToken === b.chatterToken && !t.sessionToken && !t.messagingToken && !t.sessionRefreshToken;
                                }
                            });
                        if (e.aborted || !this.isCurrentPersistence(this)) return q("chatter_cookie_restore_failed", {
                            reason: "superseded"
                        }), {
                            kind: "aborted"
                        };
                        if (n) return this._hydrateResumedLegacyIdentity(r.chatterToken, r.sessionToken, t), q("chatter_cookie_restore_restored", {
                            durable: n !== "memory"
                        }), {
                            kind: "restored"
                        }; {
                            let e = this.store.getState().session;
                            pN.warn("cookie restore write refused", {
                                persistence: e.persistence,
                                chatterChanged: e.chatterToken !== b.chatterToken,
                                credentialPresent: !!(e.sessionToken || e.messagingToken || e.sessionRefreshToken),
                                baselineChanged: Object.entries(d).some(([e, t]) => this.storage.get(e) !== t)
                            }), q("chatter_cookie_restore_failed", {
                                reason: "write_refused"
                            });
                        }
                    }
                } else YM(this.key), q("chatter_cookie_restore_failed", {
                    reason: "reason" in n ? n.reason : "rejected_or_unusable"
                });
            } else YM(this.key);
            if (c && !dN(c)) {
                let {
                    terminal: a,
                    awaited: o
                } = await this._restoredSessionIsTerminal(c, e);
                if (e.aborted) return q("chatter_restore_superseded", {
                    reason: "aborted"
                }), {
                    kind: "aborted"
                };
                if (o) {
                    let n = await this._identityOwnership(m, !0, e);
                    if (n.kind === "stop" || n.kind === "unresolved" && !t) return n.outcome;
                    n.kind === "unresolved" && (y = !0);
                }
                let s = await this.confirmAndAdoptRestoreSnapshot(e);
                if (e.aborted) return q("chatter_restore_superseded"), {
                    kind: "aborted"
                };
                if (!s) throw Error("ConversationPersistenceService: post-validation session snapshot could not be confirmed");
                if (!fN(c, this._readPersistedSession())) {
                    if (q("chatter_restore_replaced_during_validation"), n >= 1) throw Error("ConversationPersistenceService: persisted session changed repeatedly during validation");
                    return await this.restore(e, {
                        commitUnverified: t,
                        replacementRetry: n + 1,
                        restoreOnly: r,
                        staleAuthBaseline: i
                    });
                }
                return a ? y ? {
                    kind: "ownership_unresolved"
                } : this._createFreshSession(c.chatterToken, e, p, f, {
                    confirmedEnd: !0,
                    credentialBaseline: d,
                    staleAuthBaseline: i,
                    restoreOnly: r
                }) : (await this._restorePersistedSession(c), y && this._withholdPersistenceUntilOwnershipProven(c.chatterToken), {
                    kind: "restored"
                });
            }
            let S = await this._tryResumeLegacyIdentityViaExchange(e);
            return S.kind === "resumed" ? {
                kind: "restored"
            } : S.kind === "superseded" ? S.cause === "aborted" ? {
                kind: "aborted"
            } : {
                kind: S.cause === "rotated" ? "identity_rotated" : "ownership_unresolved"
            } : y ? {
                kind: "ownership_unresolved"
            } : (S.handoffEnded && (Object.assign(f.baseline, {
                [this.handoffStateKey]: null,
                [L]: null,
                [R]: null,
                zdMessagingExternalUserId: null,
                zdMessagingChatterCreated: null
            }), f.inLiveChat = !1, f.inPending = !1), this._createFreshSession(void 0, e, S.rejectedSession ? ? p, f, {
                confirmedEnd: !0,
                credentialBaseline: d,
                staleAuthBaseline: i,
                restoreOnly: r,
                missingCredential: c ? void 0 : s
            }));
        }
        async _identityOwnership(e, t, n) {
            if (!t) return {
                kind: "confirmed"
            };
            let r = await this._identityRotatedSinceCapture(e);
            return n.aborted ? (q("chatter_restore_superseded", {
                reason: "aborted"
            }), {
                kind: "stop",
                outcome: {
                    kind: "aborted"
                }
            }) : r.rotated ? (q("chatter_restore_superseded", {
                reason: "identity_rotated"
            }), {
                kind: "stop",
                outcome: {
                    kind: "identity_rotated"
                }
            }) : r.readable ? {
                kind: "confirmed"
            } : (q("chatter_restore_identity_unreadable", {
                committed_unverified: !1
            }), {
                kind: "unresolved",
                outcome: {
                    kind: "ownership_unresolved"
                }
            });
        }
        async getExistingChatterCandidate(e) {
            let t = await this._readConfirmedExistingChatterSnapshot(e);
            if (t.kind !== "snapshot") return t;
            let n = this._assessExistingChatterSnapshot(t);
            return n.kind === "eligible" ? {
                kind: "candidate",
                chatterToken: n.chatterToken,
                source: n.source,
                identitySession: n.session ? .identitySession === !0,
                handoffActive: this._confirmedHandoffVerdict(t)
            } : n;
        }
        async getExistingChatterNotificationCandidate(e) {
            let t = await this._readConfirmedSnapshot([
                this.key,
                this.legacyKey,
                P
            ], e);
            return t.kind === "snapshot" ? this._assessAnonymousChatterIdentity(t.values[this.key] ? ? null, t.values[this.legacyKey] ? ? null, t.values.chatter ? ? null) : t;
        }
        _assessAnonymousChatterIdentity(e, t, n, r = {}) {
            let i = Q(e),
                a = Q(t),
                o = I(n);
            if (e !== null && !i || t !== null && !a || n !== null && !o) return {
                kind: "malformed"
            };
            if (!r.allowIdentityBound && (i && i.identitySession !== !1 || a && a.identitySession !== !1)) return {
                kind: "identity_bound"
            };
            let s = new Set([
                i ? .chatterToken,
                a ? .chatterToken,
                o
            ].filter((e) => !!e));
            return s.size === 0 ? {
                kind: "missing"
            } : s.size === 1 ? {
                kind: "candidate",
                chatterToken: [...s][0]
            } : {
                kind: "conflicting"
            };
        }
        async restoreExistingChatter(e, t, n = {}) {
            let r = await this._readConfirmedExistingChatterSnapshot(t);
            if (r.kind !== "snapshot") return r;
            let i = this._assessExistingChatterSnapshot(r);
            if (i.kind !== "eligible") return i;
            if (i.chatterToken !== e) return {
                kind: "token_mismatch",
                expectedChatterToken: e,
                actualChatterToken: i.chatterToken
            };
            if (n.requireCommittedSibling && !this._isCommittedSibling(r, e)) return {
                kind: "superseded"
            };
            let a = (e) => n.requireIdentitySession === !0 && (e.kind !== "eligible" || e.source !== "native" || e.session ? .identitySession !== !0);
            if (a(i)) return {
                kind: "unresumable",
                reason: "identity_session_required"
            };
            if (i.source === "legacy_exchange") {
                let a = this.exchangeMessagingSession;
                if (!a || !i.legacySessionToken) return {
                    kind: "unresumable",
                    reason: a ? "missing_session_auth" : "exchange_not_configured"
                };
                let o;
                try {
                    o = await a({
                        chatterToken: e,
                        sessionToken: i.legacySessionToken
                    }, t);
                } catch {
                    o = {
                        kind: "unavailable"
                    };
                } finally {
                    this.store.dispatch(VT());
                }
                let s = await this._reassessExistingChatterAfterAwait(r, e, t, n.requireCommittedSibling);
                if (s.kind !== "eligible") return s;
                if (o.kind === "terminal") {
                    if (uS(o.handoffEnded)) {
                        let n = await this.clearEndedExchangeHandoff({
                            chatterToken: e,
                            sessionToken: i.legacySessionToken,
                            credential: lS(i.session)
                        }, o.handoffEnded, t);
                        return n === "cleared" ? {
                            kind: "terminal",
                            source: "legacy_exchange",
                            handoffEnded: !0
                        } : n === "aborted" ? {
                            kind: "aborted"
                        } : {
                            kind: "terminal",
                            source: "legacy_exchange"
                        };
                    }
                    return {
                        kind: "terminal",
                        source: "legacy_exchange"
                    };
                }
                return o.kind === "unavailable" ? {
                    kind: "exchange_unavailable"
                } : t.aborted ? {
                    kind: "superseded"
                } : (this._rehydrateReadState(), this._hydrateResumedLegacyIdentity(e, i.legacySessionToken, o.credential, n.suppressChatterAnnouncement ? ? !0), q("chatter_resumed_via_exchange"), {
                    kind: "restored",
                    chatterToken: e,
                    source: "legacy_exchange"
                });
            }
            if (!i.session) return {
                kind: "unresumable",
                reason: "missing_session_auth"
            };
            let o = i;
            if (i.session.sessionTokenExpiresAt === null) {
                if (!this.validateRestoredSession) return {
                    kind: "validation_unavailable"
                };
                let a;
                try {
                    a = await this.validateRestoredSession(i.session, t);
                } catch {
                    return t.aborted ? {
                        kind: "superseded"
                    } : {
                        kind: "validation_unavailable"
                    };
                } finally {
                    this.store.dispatch(VT());
                }
                let s = await this._reassessExistingChatterAfterAwait(r, e, t, n.requireCommittedSibling);
                if (s.kind !== "eligible") return s;
                if (a.kind === "terminal") return {
                    kind: "terminal",
                    source: s.source
                };
                if (a.kind === "unavailable") return {
                    kind: "validation_unavailable"
                };
                o = s;
            }
            return a(o) ? {
                kind: "unresumable",
                reason: "identity_session_required"
            } : o.session ? t.aborted ? {
                kind: "superseded"
            } : (this._rehydrateReadState(), await this._restorePersistedSession(o.session, n.suppressChatterAnnouncement ? ? !0), {
                kind: "restored",
                chatterToken: e,
                source: o.source
            }) : {
                kind: "unresumable",
                reason: "missing_session_auth"
            };
        }
        async confirmAndAdoptRestoreSnapshot(e) {
            if (!this.storage.getConfirmed) return !e.aborted;
            for (let t = 0; t < 2; t += 1) {
                let t = await this._readConfirmedExistingChatterSnapshot(e);
                if (t.kind === "snapshot") return !0;
                if (t.kind === "superseded") return !1;
            }
            return !1;
        }
        _existingChatterSnapshotKeys() {
            return this.existingChatterSnapshotKeys;
        }
        async _readConfirmedExistingChatterSnapshot(e) {
            return this._readConfirmedSnapshot(this._existingChatterSnapshotKeys(), e);
        }
        async _readConfirmedSnapshot(e, t, {
            trackActivationProgress: n = !0,
            adoptConfirmedSnapshot: r = !0
        } = {}) {
            if (t.aborted) return {
                kind: "superseded"
            };
            try {
                let i, a;
                if (this.storage.getConfirmed) {
                    let o = await this.storage.getConfirmed(e);
                    if (a = o.coherent, n && this.store.dispatch(VT()), t.aborted) return {
                        kind: "superseded"
                    };
                    if (!o.confirmed || e.some((e) => !Object.hasOwn(o.values, e) || o.values[e] !== null && typeof o.values[e] != "string")) return {
                        kind: "unconfirmed"
                    };
                    r && this.storage.adoptConfirmedSnapshot ? .(o.values), i = o.values;
                } else i = Object.fromEntries(e.map((e) => [e, this.storage.get(e)]));
                return t.aborted ? {
                    kind: "superseded"
                } : {
                    kind: "snapshot",
                    values: i,
                    coherent: a
                };
            } catch {
                return t.aborted ? {
                    kind: "superseded"
                } : {
                    kind: "unconfirmed"
                };
            }
        }
        _assessExistingChatterSnapshot(e) {
            let t = e.values[this.key] ? ? null,
                n = e.values[this.legacyKey] ? ? null,
                r = e.values.chatter ? ? null,
                i = Q(t),
                a = Q(n),
                o = I(e.values.zdMessagingExternalUserId),
                s = !i && !a && !r && this._hasZDMessagingContinuity(o, (t) => e.values[t] ? ? null),
                c = I(r) ? ? (s ? o : null);
            if (t !== null && !i || n !== null && !a || r !== null && !c) return {
                kind: "unresumable",
                reason: "malformed_identity"
            };
            let l = new Set([
                i ? .chatterToken,
                a ? .chatterToken,
                c
            ].filter((e) => !!e));
            if (l.size === 0) return {
                kind: "missing"
            };
            if (l.size !== 1) return {
                kind: "unresumable",
                reason: "conflicting_identity"
            };
            let u = [...l][0],
                d = i ? ? a;
            if (!this._resumesFromLegacyKeys(d)) return {
                kind: "missing"
            };
            if (this._chatterExpiryWindowElapsedFromSnapshot(e, u)) return {
                kind: "expired",
                reason: "persistence_window"
            };
            if (d && dN(d)) return {
                kind: "expired",
                reason: "session"
            };
            let f = e.values[this.messagingAuthStateKey] ? ? null,
                p = this._bindPersistedSessionAuth(d, f);
            if (p) return p.sessionTokenExpiresAt === null && !p.sessionToken ? {
                kind: "unresumable",
                reason: "missing_session_auth"
            } : {
                kind: "eligible",
                chatterToken: u,
                source: "native",
                session: p,
                legacySessionToken: null
            };
            if (d && d.identitySession !== !1) return {
                kind: "unresumable",
                reason: "identity_bound_missing_auth"
            };
            let m = I(e.values.sessionToken ? ? null);
            if (!c || !m) return {
                kind: "unresumable",
                reason: "missing_session_auth"
            };
            let h = this._readMessagingAuthState(u, f);
            return h ? {
                kind: "eligible",
                chatterToken: u,
                source: "legacy_credential",
                session: {
                    version: 1,
                    chatterId: "",
                    chatterToken: u,
                    sessionToken: m,
                    sessionTokenExpiresAt: null,
                    sessionRefreshToken: h.sessionRefreshToken,
                    messagingToken: h.messagingToken,
                    messagingTokenExpiresAt: h.messagingTokenExpiresAt,
                    refreshGeneration: h.refreshGeneration,
                    sessionCookieIssued: h.sessionCookieIssued,
                    identitySession: !1
                },
                legacySessionToken: m
            } : this.exchangeMessagingSession ? {
                kind: "eligible",
                chatterToken: u,
                source: "legacy_exchange",
                session: null,
                legacySessionToken: m
            } : {
                kind: "unresumable",
                reason: "exchange_not_configured"
            };
        }
        _chatterExpiryWindowElapsedFromSnapshot(e, t, n = Date.now()) {
            let {
                timeToExpiryMs: r
            } = this.store.getState().session;
            if (!r || r <= 0 || this._confirmedHandoffVerdict(e) || this._hasZDMessagingContinuity(t, (t) => e.values[t] ? ? null)) return !1;
            let i = vN(e.values.created ? ? null);
            if (i === null) return !0;
            let a = (lN(e.values.messagingCreatedClock ? ? null, i) ? ? "plain") === "legacy-local" ? n + new Date(n).getTimezoneOffset() * 6e4 : n;
            return i + r < a;
        }
        _hasZDMessagingContinuity(e, t) {
            return xT({
                explicitPrivateMode: this.storageMode === "private",
                enabled: this.store.getState().session.features.adaGlassZendeskMessaging === !0,
                chatterToken: e,
                externalUserId: I(t("zdMessagingExternalUserId")),
                chatterCreated: I(t("zdMessagingChatterCreated"))
            });
        }
        _confirmedHandoffVerdict(e) {
            let t = e.values[this.handoffStateKey] ? ? null;
            if (t !== null) return Yo(t);
            let n = e.values.inLiveChat ? ? null,
                r = e.values.liveChatPending ? ? null;
            return n === null && r === null ? null : Yo(n) || Yo(r);
        }
        async _reassessExistingChatterAfterAwait(e, t, n, r = !1) {
            let i = await this._readConfirmedExistingChatterSnapshot(n);
            if (i.kind !== "snapshot") return i;
            if (r && !this._isCommittedSibling(i, t)) return {
                kind: "superseded"
            };
            let a = this._assessExistingChatterSnapshot(i);
            return a.kind === "eligible" ? a.chatterToken === t ? this._existingChatterSnapshotKeys().some((t) => e.values[t] !== i.values[t]) ? {
                kind: "superseded"
            } : a : {
                kind: "token_mismatch",
                expectedChatterToken: t,
                actualChatterToken: a.chatterToken
            } : a;
        }
        _isCommittedSibling(e, t) {
            let n = this._assessExistingChatterSnapshot(e);
            return !!(n.kind === "eligible" && n.source === "native" && n.session && n.chatterToken === t && this._readMessagingAuthState(n.chatterToken, e.values[this.messagingAuthStateKey]) && I(e.values.chatter) === n.chatterToken && I(e.values.sessionToken) === n.session.sessionToken && cS({
                expected: J(n.session),
                current: {
                    ...J(n.session),
                    inHandoff: !1
                },
                isCurrent: !0,
                shared: pS({
                    ...e,
                    confirmed: !0
                }, [this.key, this.legacyKey], [
                    this.handoffStateKey,
                    "inLiveChat",
                    "liveChatPending"
                ], Q),
                preservesHandoff: !0
            }));
        }
        async _chatterExpiryWindowElapsed(e, t = Date.now()) {
            let {
                timeToExpiryMs: n
            } = this.store.getState().session;
            if (!n || n <= 0) return {
                elapsed: !1,
                awaitedStorage: !1
            };
            let r = vN(this.storage.get($)),
                i = e !== null || this._legacyIdentityPresent(),
                a = await this._handoffExemptionActive(n, t),
                {
                    awaitedStorage: o,
                    confirmedEnd: s
                } = a,
                c = I(this.storage.get(P)),
                l = e ? .chatterToken ? ? c;
            if (a.active || this._hasZDMessagingContinuity(l, (e) => this.storage.get(e))) return {
                elapsed: !1,
                awaitedStorage: o
            };
            if (r === null) return {
                elapsed: i,
                awaitedStorage: o,
                confirmedEnd: s
            };
            let u = (lN(this.storage.get("messagingCreatedClock"), r) ? ? "plain") === "legacy-local" ? t + new Date(t).getTimezoneOffset() * 6e4 : t;
            return {
                elapsed: r + n < u,
                awaitedStorage: o,
                confirmedEnd: s
            };
        }
        _capturedIdentityAnchors() {
            return {
                read: this.storage.hydrated ? .([
                    this.key,
                    this.legacyKey,
                    P
                ]) !== !1,
                scoped: (Q(this.storage.get(this.key)) ? ? Q(this.storage.get(this.legacyKey))) ? .chatterToken ? ? null,
                legacy: I(this.storage.get(P))
            };
        }
        async _identityRotatedSinceCapture(e) {
            if (!this.storage.getConfirmed) return {
                rotated: !1,
                readable: !0
            };
            let t = await this.storage.getConfirmed([
                this.key,
                this.legacyKey,
                P
            ]);
            if (!t.confirmed || t.coherent === !1 || !e.read) return {
                rotated: !1,
                readable: !1
            };
            let n = (Q(t.values[this.key] ? ? null) ? ? Q(t.values[this.legacyKey] ? ? null)) ? .chatterToken ? ? null,
                r = I(t.values.chatter ? ? null);
            return {
                rotated: n !== e.scoped || r !== e.legacy,
                readable: !0
            };
        }
        _legacyIdentityPresent() {
            return I(this.storage.get(P)) !== null;
        }
        async _handoffExemptionActive(e, t = Date.now()) {
            if (this.storage.hydratedCoherently ? .() === !1) return this._unboundedHandoffExemption();
            let n = this._readLegacyHandoffFlag(L),
                r = this._readLegacyHandoffFlag(R),
                i = n.observedTrue || r.observedTrue,
                a = i || n.read && r.read,
                o = CN(this.storage.get(SN));
            if (a && o !== null && o.open === i) return await this._attributedHandoffExemption(o, t);
            let s = await this._recordLegacyHandoffObservation(i, a, t, o ? .at ? ? null),
                {
                    sampled: c,
                    own: l,
                    read: u,
                    live: d,
                    indeterminate: f
                } = await this._ownHandoffVerdict(s.ownLive),
                p = !l && !s.observedTrue && (a || !s.dated),
                m = s.confirmed && (s.dated || s.stamped) && s.seenAt + e + Math.min(3e5, e) >= t,
                h = s.inconclusive && s.retired === !0 || f || !p && (l || m);
            return (!p || !a || !u || s.inconclusive) && q("chatter_legacy_handoff_exemption", {
                granted: h,
                bound_applied: !0,
                attributed: !1,
                fresh: m,
                own: l,
                dated_now: s.stamped,
                observed_age_ms: s.dated || s.stamped ? t - s.seenAt : null,
                write_confirmed: s.confirmed,
                pair_read: a,
                own_read: u,
                own_indeterminate: f,
                pair_indeterminate: s.inconclusive,
                retirement_confirmed: s.retired,
                pair_revalidated: s.observedTrue && !i,
                own_revalidated: !c && d ? .own === !0
            }), {
                active: h,
                confirmedEnd: !h && i && a && s.confirmed && s.dated && !m,
                awaitedStorage: d !== null || s.stamped || s.retired !== null
            };
        }
        async _attributedHandoffExemption(e, t) {
            let {
                own: n,
                read: r,
                live: i,
                indeterminate: a
            } = await this._ownHandoffVerdict(), o = e.open || n || a;
            return q("chatter_legacy_handoff_exemption", {
                granted: o,
                bound_applied: !1,
                attributed: !0,
                transition_age_ms: t - e.at,
                pair_open: e.open,
                own: n,
                own_read: r,
                own_indeterminate: a
            }), {
                active: o,
                awaitedStorage: i !== null
            };
        }
        async _ownHandoffVerdict(e = null) {
            let t = this.storage.hydrated ? .([this.handoffStateKey]) !== !1,
                n = t && Yo(this.storage.get(this.handoffStateKey)),
                r = e ? ? (t ? null : await this._liveOwnVerdict());
            return {
                sampled: n,
                own: n || r ? .own === !0,
                read: t,
                live: r,
                indeterminate: !t && r ? .read !== !0
            };
        }
        _unboundedHandoffExemption() {
            let e = this.storage.get(this.handoffStateKey),
                t = e === null ? Yo(this.storage.get("inLiveChat")) || Yo(this.storage.get("liveChatPending")) : Yo(e);
            return q("chatter_legacy_handoff_exemption", {
                granted: t,
                bound_applied: !1,
                attributed: !1
            }), {
                active: t,
                awaitedStorage: !1
            };
        }
        async _liveOwnVerdict() {
            let e = await this._liveHandoffState();
            return {
                own: e.own,
                read: e.confirmed
            };
        }
        _readLegacyHandoffFlag(e) {
            let t = this.storage.hydrated ? .([e]) !== !1;
            return {
                observedTrue: t && Yo(this.storage.get(e)),
                read: t
            };
        }
        async _recordLegacyHandoffObservation(e, t, n, r) {
            let i = xN(this.storage.get(bN)),
                a = r !== null && i !== null && i.seenAt < r ? null : i,
                o = a ? .value === !0 && a.seenAt <= n ? a.seenAt : null;
            if (e && o !== null) return {
                seenAt: o,
                stamped: !1,
                dated: !0,
                confirmed: !0,
                observedTrue: !0,
                ownLive: null,
                inconclusive: !1,
                retired: null
            };
            let s = this.storage.hydrated ? .([bN]) !== !1;
            if (!t || !s) return {
                seenAt: o ? ? n,
                stamped: !1,
                dated: o !== null,
                confirmed: o !== null,
                observedTrue: e,
                ownLive: null,
                inconclusive: !1,
                retired: null
            };
            if (e) return await this._stampLegacyHandoffObservation(n);
            if (i ? .value === !0) {
                let e = await this._retireLegacyHandoffObservation(n),
                    t = await this._liveHandoffState(),
                    r = {
                        own: t.own,
                        read: t.confirmed
                    };
                return t.pairTrue ? await this._stampLegacyHandoffObservation(n, r, e) : {
                    seenAt: n,
                    stamped: !1,
                    dated: !1,
                    confirmed: !0,
                    observedTrue: !1,
                    ownLive: r,
                    inconclusive: !t.coherent || !t.confirmed,
                    retired: e
                };
            }
            return {
                seenAt: n,
                stamped: !1,
                dated: !1,
                confirmed: !0,
                observedTrue: !1,
                ownLive: null,
                inconclusive: !1,
                retired: null
            };
        }
        async _stampLegacyHandoffObservation(e, t = null, n = null) {
            let r = JSON.stringify({
                value: !0,
                seenAt: e
            });
            this.storage.set(bN, r);
            let i = await this.storage.flush ? .(["ada:legacy-handoff-observed"]) ? ? !0;
            return i && zM(), {
                seenAt: e,
                stamped: !0,
                dated: !1,
                confirmed: i,
                observedTrue: !0,
                ownLive: i || t ? .own === !0 ? t : await this._liveOwnVerdict(),
                inconclusive: !1,
                retired: n
            };
        }
        async _retireLegacyHandoffObservation(e) {
            let t = JSON.stringify({
                value: !1,
                seenAt: e
            });
            if (this.storage.set(bN, t), !this.storage.flush) return zM(), !0;
            let n = await this.storage.flush([bN]);
            return n && zM(), q("chatter_legacy_handoff_observation_retired", {
                tombstoned: n
            }), n;
        }
        async _liveHandoffState() {
            let e = [L, R],
                t = [...e, this.handoffStateKey],
                n = this.storage.getConfirmed ? await this.storage.getConfirmed(t) : {
                    confirmed: !0,
                    coherent: !0,
                    values: Object.fromEntries(t.map((e) => [e, this.storage.get(e)]))
                },
                r = (e) => Yo(n.values[e] ? ? null);
            return {
                pairTrue: e.some((e) => r(e)),
                own: r(this.handoffStateKey),
                coherent: n.coherent !== !1,
                confirmed: n.confirmed !== !1
            };
        }
        async _tryResumeLegacyIdentityViaExchange(e) {
            if (!this.exchangeMessagingSession) return {
                kind: "unresumable"
            };
            let t = Q(this.storage.get(this.key)) ? ? Q(this.storage.get(this.legacyKey));
            if (t && t.identitySession !== !1) return q("chatter_exchange_blocked_identity"), {
                kind: "unresumable"
            };
            if (!this._resumesFromLegacyKeys(t)) return {
                kind: "unresumable"
            };
            let n = I(this.storage.get(P)),
                r = I(this.storage.get(F));
            if (!n || !r) return {
                kind: "unresumable"
            };
            let i = {
                    chatterToken: n,
                    sessionToken: r,
                    credential: lS(this._readMessagingAuthState(n))
                },
                a;
            try {
                a = await this.exchangeMessagingSession({
                    chatterToken: n,
                    sessionToken: r
                }, e);
            } finally {
                this.store.dispatch(VT());
            }
            let o = await this._exchangeLifecycleSuperseded(n, r, e);
            if (o) return q("chatter_exchange_superseded", {
                cause: o
            }), {
                kind: "superseded",
                cause: o
            };
            if (a.kind === "terminal") {
                let t = uS(a.handoffEnded) ? a.handoffEnded : void 0;
                if (t) {
                    let n = await this.clearEndedExchangeHandoff(i, t, e);
                    if (n !== "cleared") return n === "aborted" ? {
                        kind: "superseded",
                        cause: "aborted"
                    } : {
                        kind: "unresumable",
                        rejectedSession: i
                    };
                }
                return q("chatter_exchange_failed", {
                    reason: "terminal"
                }), {
                    kind: "unresumable",
                    rejectedSession: i,
                    ...t ? {
                        handoffEnded: !0
                    } : {}
                };
            }
            return a.kind === "unavailable" ? (q("chatter_exchange_failed", {
                reason: "unavailable"
            }), this._hydrateResumedLegacyIdentity(n, r, null), {
                kind: "resumed"
            }) : (q("chatter_resumed_via_exchange"), this._hydrateResumedLegacyIdentity(n, r, a.credential), this.saveCurrentSession(), {
                kind: "resumed"
            });
        }
        async _exchangeLifecycleSuperseded(e, t, n) {
            if (n.aborted) return "aborted";
            let r = this.storage.getConfirmed ? await this.storage.getConfirmed([P, F]).finally(() => {
                this.store.dispatch(VT());
            }) : void 0;
            return n.aborted ? "aborted" : r ? r.confirmed ? I(r.values.chatter ? ? null) !== e || I(r.values.sessionToken ? ? null) !== t ? "rotated" : null : "unresolved" : I(this.storage.get("chatter")) !== e || I(this.storage.get("sessionToken")) !== t ? "rotated" : null;
        }
        _hydrateResumedLegacyIdentity(e, t, n, r = !1) {
            this.store.dispatch(ws({
                token: e,
                id: "",
                sessionToken: t,
                sessionTokenExpiresAt: null,
                sessionRefreshToken: n ? .sessionRefreshToken ? ? null,
                messagingToken: n ? .messagingToken ? ? null,
                messagingTokenExpiresAt: n ? .messagingTokenExpiresAt ? ? null,
                refreshGeneration: n ? .refreshGeneration ? ? null,
                sessionCookieIssued: n ? .sessionCookieIssued === !0,
                identitySession: !1,
                suppressChatterAnnouncement: r
            })), this._pendingRestoredChatterToken = e;
        }
        async _restoredSessionIsTerminal(e, t) {
            if (e.sessionTokenExpiresAt !== null) return {
                terminal: !1,
                awaited: !1
            };
            if (!e.sessionToken) return {
                terminal: !0,
                awaited: !1
            };
            if (!this.validateRestoredSession) return {
                terminal: !1,
                awaited: !1
            };
            try {
                return {
                    terminal: (await this.validateRestoredSession(e, t)).kind === "terminal",
                    awaited: !0
                };
            } catch {
                return {
                    terminal: !1,
                    awaited: !0
                };
            } finally {
                this.store.dispatch(VT());
            }
        }
        stageIdentifiedSessionForRestore(e = J(this.store.getState().session)) {
            let {
                chatterToken: t
            } = this.store.getState().session;
            t && (this._pendingRestoredChatterToken = t, this._pendingChatterPersistenceCommit = {
                chatterToken: t,
                kind: "identity",
                expected: e,
                previousChatterTokens: []
            }, this._applyPendingChatterPersistenceCommit(this._pendingChatterPersistenceCommit));
        }
        async ensureCurrentSessionPersisted(e) {
            let t = this.store.getState().session.chatterToken;
            if (!t || e ? .aborted) return !1;
            let n = this._pendingChatterPersistenceCommit;
            if (n && n.chatterToken !== t) return !1;
            let r = () => !e ? .aborted && this.store.getState().session.chatterToken === t;
            if (await this._terminalClearsIdle(e), !r() || !await (n ? this._applyPendingChatterPersistenceCommit(n, void 0, r) : this.saveCurrentSession({
                    isCurrent: r
                }))) return !1;
            let i = n ? this._pendingChatterPersistenceCommitWriteKeys(n) : this._sessionPersistenceWriteKeys();
            return await this.storage.flush ? .(i) === !1 || e ? .aborted || this.store.getState().session.chatterToken !== t ? !1 : (this._pendingChatterPersistenceCommit === n && (this._pendingChatterPersistenceCommit = null), zM(), !0);
        }
        async ensureAllStorageCleared(e) {
            return await this.storage.flush ? .(this._clearAllStorageWriteKeys()) !== !1 && e ? .aborted !== !0;
        }
        hasPendingRestoredChatter() {
            return this._pendingRestoredChatterToken !== null;
        }
        cancelPendingRestoredHistory() {
            this._historyRestoreGeneration += 1, this._pendingRestoredChatterToken = null, this._restoreHistoryPromise = null;
        }
        _rehydrateReadState() {
            let e = wN(this.storage.get(this.readStateKey));
            e && (this._lastSavedReadState = JSON.stringify(e), this.store.dispatch(HO({
                lastReadCursorByConversation: e
            })));
        }
        _saveReadStateIfChanged() {
            if (!(this.storageMode === "private" || this._sharedStateWriteWithheld() || this._persistenceSuppressed())) try {
                let e = this.store.getState().chat.lastReadCursorByConversation,
                    t = JSON.stringify(e);
                if (t === this._lastSavedReadState || t === this._pendingReadState ? .serialized || t === this._lastRefusedReadState) return;
                let n = {
                    serialized: t
                };
                this._pendingReadState = n, this._lastRefusedReadState = null;
                let r = (e) => {
                    this._pendingReadState === n && (this._pendingReadState = null, e || (this._lastRefusedReadState = t, pN.warn("read cursor persistence refused", {
                        handle: this.handle
                    })));
                };
                try {
                    let e = this.mutateSharedSession(J(this.store.getState().session), () => {
                        this._setSharedValue(this.readStateKey, t), this._afterSharedCommit(() => {
                            this._lastSavedReadState = t, zM();
                        });
                    }, {
                        preservesHandoff: !0
                    });
                    e instanceof Promise ? e.then(r, () => r(!1)) : r(e);
                } catch {
                    r(!1);
                }
            } catch {}
        }
        _saveHandoffStateIfChanged() {
            try {
                if (this.handoffOnlyPersistence)
                    if (!this._persistenceSuppressed()) this._handoffPersistenceResumed();
                    else {
                        this._pendingRestoredChatterToken === null && this._scheduleHandoffOnlyWipe();
                        return;
                    }
                if (this.storageMode === "private" || this._terminalClearsInProgress > 0 || this.store.getState().session._chatterAnnouncementSuppressed || this._sharedStateWriteWithheld()) return;
                let {
                    inLiveChat: e,
                    inPending: t
                } = this.store.getState().liveAgent, n = e || t;
                if (!n && this._pendingRestoredChatterToken !== null || n === this._lastSavedHandoffState) return;
                let r = this.mutateSharedSession(J(this.store.getState().session), () => this._setSharedValue(this.handoffStateKey, JSON.stringify(n)), {
                        preservesHandoff: n,
                        ...n ? {} : this._handoffEndWriteOptions(),
                        isCurrent: () => (this.store.getState().liveAgent.inLiveChat || this.store.getState().liveAgent.inPending) === n
                    }),
                    i = (e) => {
                        e && (this._lastSavedHandoffState = n, zM());
                    };
                if (r instanceof Promise) return r.then(i);
                i(r);
            } catch {}
        }
        async restoreRecentConversationHistory(e) {
            if (!this._pendingRestoredChatterToken) return;
            if (this._restoreHistoryPromise) {
                await this._restoreHistoryPromise;
                return;
            }
            let t = this._pendingRestoredChatterToken,
                n = this._historyRestoreGeneration,
                {
                    agentAssignmentSeq: r
                } = this.store.getState().liveAgent,
                i = this._captureHandoffEnd(),
                a = () => !e.aborted && this._historyRestoreGeneration === n && this._pendingRestoredChatterToken === t && this.store.getState().session.chatterToken === t && this.store.getState().session.sessionToken === i.owner.sessionToken,
                o = (async () => {
                    let e = await this._fetchRecentConversation(t),
                        n = Date.now();
                    if (this.store.dispatch(VT()), a() && e.ok) {
                        if (e.conversationIds.length > 0) {
                            let t = this.store.getState().session.conversationId,
                                i = e.conversationIds[0],
                                a = !!t && wT(t, i),
                                o = !!t && t !== i && !a;
                            this.store.dispatch(LO(a && t ? [t, ...e.conversationIds.filter((e) => e !== t)] : e.conversationIds)), a || (o && (this.store.dispatch(MO()), this.store.dispatch(CO()), this.store.dispatch(mk())), this.store.dispatch(Ts(i)), e.conversationEnded && this.store.dispatch(JE())), e.activeHandoff && !a && this._restoreActiveHandoff(e.activeHandoff, r, n), e.activeCapture && !a && this.store.dispatch(ak(e.activeCapture)), e.activeListSelection && !a && this.store.dispatch(fk(e.activeListSelection)), e.widgetAppPending && !a && this.store.dispatch(hk());
                            try {
                                await CM(this.store);
                            } finally {
                                this.store.dispatch(VT());
                            }
                        }
                        a() && (this._pendingRestoredChatterToken = null, this._confirmedHandoffEnd = !this.store.getState().liveAgent.inLiveChat && !this.store.getState().liveAgent.inPending ? i : null, await this._saveHandoffStateIfChanged(), await this._syncZdmContinuity());
                    }
                })();
            this._restoreHistoryPromise = o;
            try {
                await o;
            } finally {
                this._restoreHistoryPromise === o && (this._restoreHistoryPromise = null);
            }
        }
        _restoreActiveHandoff(e, t, n) {
            let {
                currentState: r,
                platformName: i,
                queuePosition: a,
                departmentId: o
            } = e;
            if (i === "zaw_liveagent" && r === "live_chat") {
                if (this.store.getState().liveAgent.agentAssignmentSeq === t && (this.store.dispatch(BE()), e.agents !== void 0)) {
                    let t = e.agentRosterUpdatedAt;
                    this.store.dispatch(VE({
                        agents: e.agents,
                        rosterCutoff: {
                            timestamp: t ? ? n - 5 * 1e3,
                            isServerTime: t !== void 0
                        }
                    }));
                }
                SF(this.store, "agent");
            }
            i && this.store.dispatch(sD({
                platformName: i,
                ...o === null ? {} : {
                    departmentId: o
                }
            })), e.fileRequest && this.store.dispatch(PE(e.fileRequest)), r === "live_chat" || r === "live_chat_pending" ? this.store.dispatch(eD({
                stateType: r,
                inState: !0,
                ...a === null ? {} : {
                    stateData: {
                        queue_position: a
                    }
                }
            })) : a !== null && this.store.dispatch(lD(a)), e.queueWaitMinutes !== void 0 && this.store.dispatch(uD(e.queueWaitMinutes)), this._reconnectZendeskChat(e);
        }
        _reconnectZendeskChat(e) {
            let t = e.zendeskReconnect;
            if (!t) return;
            let n = AN(this.storage.get(kN(this.handle)));
            if (!n) return;
            t.lastProcessedTimestamp !== null && this.store.dispatch(Z({
                lastProcessedTimestamp: qP(t.lastProcessedTimestamp)
            }));
            let {
                endpoint: r,
                chatterToken: i,
                sessionToken: a
            } = this.store.getState().session;
            this.store.dispatch(oD({
                integration: "zendesk",
                action: "handoff.initialize",
                payload: {
                    accountKey: t.accountKey,
                    ...e.departmentId === null ? {} : {
                        departmentId: e.departmentId
                    },
                    ...t.tags ? {
                        tags: t.tags
                    } : {},
                    options: {
                        ...t.useZdAuth === null ? {} : {
                            useJWTAuth: t.useZdAuth
                        },
                        ...t.overrideProxy ? {
                            sdkProxyOverride: t.overrideProxy
                        } : {}
                    },
                    storage: n,
                    ...r ? {
                        endpoint: r
                    } : {},
                    ...i ? {
                        chatterToken: i
                    } : {},
                    ...a ? {
                        sessionToken: a
                    } : {}
                }
            }));
        }
        _withholdPersistenceUntilOwnershipProven(e) {
            this._unverifiedOwnershipChatterToken = e, this._unverifiedOwnershipWithheldReported = !1;
        }
        _persistenceWithheld(e) {
            return this._unverifiedOwnershipChatterToken !== null && this._unverifiedOwnershipChatterToken === e;
        }
        _sharedStateWriteWithheld() {
            let {
                chatterToken: e
            } = this.store.getState().session;
            return !e || !this._persistenceWithheld(e) ? !1 : (this._notePersistenceWithheld(e), !0);
        }
        _notePersistenceWithheld(e) {
            this._unverifiedOwnershipWithheldReported || (this._unverifiedOwnershipWithheldReported = !0, q("chatter_unverified_ownership_save_withheld")), this._releasePersistenceOnProvenOwnership(e);
        }
        _releasePersistenceOnProvenOwnership(e) {
            if (this._unverifiedOwnershipRevalidation || !this.storage.getConfirmed) return;
            let t = [
                this.key,
                this.legacyKey,
                P
            ];
            this._unverifiedOwnershipRevalidation = this.storage.getConfirmed(t).then((t) => {
                if (this._unverifiedOwnershipChatterToken !== e) return;
                let n = [
                        Q(t.values[this.key] ? ? null) ? .chatterToken ? ? null,
                        Q(t.values[this.legacyKey] ? ? null) ? .chatterToken ? ? null,
                        I(t.values.chatter ? ? null)
                    ].filter((e) => e !== null),
                    r = t.confirmed && t.coherent !== !1 && n.length > 0 && n.every((t) => t === e);
                q("chatter_unverified_ownership_revalidated", {
                    granted: r
                }), r && (this._unverifiedOwnershipChatterToken = null, this._requestAcknowledgedSessionSave(), this._saveReadStateIfChanged(), this._saveHandoffStateIfChanged());
            }).catch(() => void 0).finally(() => {
                this._unverifiedOwnershipRevalidation = null;
            });
        }
        static clearStorageKeys(t, n, r, i = {}) {
            let a = hj();
            a.dispatch(us({
                handle: n.handle,
                endpoint: n.endpoint ? ? "",
                cluster: n.cluster ? ? void 0
            }));
            let o = new e(a, t, n.handle, {
                    createChatter: async () => void 0
                }),
                s = [...new Set([
                    ...o._conversationClearWriteKeys(),
                    L,
                    R,
                    "liveChatRevision",
                    "liveChatTransition",
                    "zdMessagingExternalUserId",
                    "zdMessagingChatterCreated",
                    "zdMessagingGeneration"
                ])],
                c = Object.fromEntries(s.map((e) => [e, t.get(e)])),
                l = GM(c[o.messagingAuthStateKey] ? ? null),
                u = Q(c[o.key] ? ? null) ? ? Q(c[o.legacyKey] ? ? null),
                d = i.expected ? .chatterToken ? i.expected : {
                    chatterToken: u ? .chatterToken ? ? I(c.chatter ? ? null) ? ? l,
                    sessionToken: u ? .sessionToken ? ? I(c.sessionToken ? ? null)
                },
                f = (e) => o.mutateSharedSession(d, () => {
                    for (let e of r) o._removeSharedValue(e);
                }, {
                    confirmedSnapshot: e,
                    confirmedEnd: i.explicitReset,
                    ownedKeysOnly: i.ownedKeysOnly,
                    baseline: c,
                    isCurrent: () => !i.signal ? .aborted
                }),
                p = t.getConfirmedSync ? .(s);
            return p ? f(p) : t.getConfirmed ? .(s).then(f).catch(() => !1) ? ? !1;
        }
        writeSharedSnapshot(e, t, n = {}) {
            let r = n.restorePartialAdoption ? e : t,
                i = Q(r[this.key] ? ? null) ? ? Q(r[this.legacyKey] ? ? null),
                a = {
                    chatterToken: i ? .chatterToken ? ? I(r.chatter ? ? null),
                    sessionToken: i ? .sessionToken ? ? I(r.sessionToken ? ? null)
                };
            return this.mutateSharedSession(a, () => {
                for (let [t, n] of Object.entries(e)) n === null ? this._removeSharedValue(t) : this._setSharedValue(t, n);
            }, {
                baseline: t,
                restorePartialAdoption: n.restorePartialAdoption,
                replacesOwnership: ["chatter", "sessionToken"].some((n) => n in e && e[n] !== t[n]) || [this.key, this.legacyKey].some((n) => {
                    if (!(n in e)) return !1;
                    let r = Q(t[n]),
                        i = Q(e[n]);
                    return r ? .chatterToken !== i ? .chatterToken || r ? .sessionToken !== i ? .sessionToken;
                })
            });
        }
        guardStorageWriters(e) {
            let t = e.compareAndWrite ? .bind(e),
                n = new Set([
                    ...this._clearAllStorageWriteKeys(),
                    L,
                    R,
                    "liveChatRevision",
                    "liveChatTransition",
                    "zdMessagingExternalUserId",
                    "zdMessagingChatterCreated",
                    "zdMessagingGeneration"
                ]),
                r = (e) => !this.handoffOnlyPersistence || this.store.getState().liveAgent.handoffOpenedThisPage && [kN(this.store.getState().session.handle ? ? this.handle), DN(this.store.getState().session.handle ? ? this.handle)].includes(e);
            return {
                ...e,
                sharedWritesGuarded: !0,
                get conditionalWritesSupported() {
                    return e.conditionalWritesSupported;
                },
                compareAndWrite: (n, r) => {
                    let i = this.store.getState().session.chatterToken,
                        a = "greetingLease";
                    return this.handoffOnlyPersistence || e.mode === "private" || e.conditionalWritesSupported !== !0 || !t || Object.keys(n).length !== 1 || Object.keys(r).length !== 1 || !(a in n) || !(a in r) || !i && !AM(n[a], r[a]) ? Promise.resolve(!1) : t(n, r);
                },
                set: (t, i) => {
                    if (!n.has(t) && !Bx(t)) {
                        e.set(t, i);
                        return;
                    }
                    return r(t) ? this.mutateSharedSession(J(this.store.getState().session), () => this._setSharedValue(t, i), {
                        preservesHandoff: i !== "false"
                    }) : !1;
                },
                update: (e, t) => r(e) ? this.mutateSharedSession(J(this.store.getState().session), () => this._updateSharedValues([e], (n) => ({
                    [e]: t(n[e] ? ? null)
                })), {
                    preservesHandoff: !0
                }) : !1,
                remove: (t) => {
                    if (!n.has(t) && !Bx(t)) {
                        e.remove(t);
                        return;
                    }
                    this.mutateSharedSession(J(this.store.getState().session), () => this._removeSharedValue(t));
                }
            };
        }
        _handoffEndBaseline() {
            return Object.fromEntries([
                this.handoffStateKey,
                L,
                R,
                "liveChatRevision",
                "liveChatTransition"
            ].map((e) => [e, this.storage.get(e)]));
        }
        _captureHandoffEnd() {
            let e = this._zdmTarget(),
                t = J(this.store.getState().session),
                n = Ro,
                r = e ? .storage.getConfirmedSync ? .([n]),
                i = null;
            return r ? i = r.confirmed ? r.values[n] : null : e ? .storage.hydrated ? .([n]) !== !1 && e ? .storage.hydratedCoherently ? .() !== !1 && (i = e ? .storage.get(n)), {
                owner: t,
                zdmCredential: lS(Jo(i ? ? null, t.chatterToken ? ? "")),
                baseline: this._handoffEndBaseline(),
                zdmBaseline: e && e !== this ? e._handoffEndBaseline() : void 0,
                zdmPair: Object.fromEntries([
                    "zdMessagingExternalUserId",
                    "zdMessagingChatterCreated",
                    "zdMessagingGeneration"
                ].map((t) => [t, e ? .storage.get(t) ? ? null]))
            };
        }
        _handoffEndWriteOptions() {
            let e = this._confirmedHandoffEnd,
                t = this.store.getState().session;
            return {
                confirmedEnd: !!(e && e.owner.chatterToken === t.chatterToken && e.owner.sessionToken === t.sessionToken),
                endBaseline: e ? .baseline
            };
        }
        _afterSharedCommit(e) {
            this._sharedCommitCallbacks ? this._sharedCommitCallbacks.push(e) : e();
        }
        _setSharedValue(e, t) {
            this._sharedWriteBatch ? (this._sharedWriteBatch[e] = t, this._sharedWriteOperations ? .push((n) => {
                n[e] = t;
            })) : this.mutateSharedSession(J(this.store.getState().session), () => this._setSharedValue(e, t), {
                preservesHandoff: t !== "false"
            });
        }
        _removeSharedValue(e) {
            this._sharedWriteBatch ? (this._sharedWriteBatch[e] = null, this._sharedWriteOperations ? .push((t) => {
                t[e] = null;
            })) : this.mutateSharedSession(J(this.store.getState().session), () => this._removeSharedValue(e));
        }
        _updateSharedValues(e, t) {
            if (!this._sharedWriteBatch || !this._sharedWriteOperations) throw Error("Shared updates require a mutation batch");
            for (let t of e) this._sharedWriteBatch[t] ? ? = this.storage.get(t), this._sharedMergeKeys ? .add(t);
            this._sharedWriteOperations.push((e) => Object.assign(e, t(e)));
        }
        mutateSharedSession(e, t, n = {}) {
            let r = !1,
                i = (e, t = "none", i) => (r || (r = !0, n.onRefused ? .({
                    refusalGuard: e,
                    refusalOwner: t,
                    ...i ? {
                        authRecoveryBlockedBy: i
                    } : {}
                })), !1);
            if (this._sharedWriteBatch) return t() !== !1 || i("collect_refused");
            let a = this._tokenSyncEpoch,
                o = J(this.store.getState().session),
                s = {},
                c = [],
                l = /* @__PURE__ */ new Set(),
                u = [],
                d = (e) => {
                    for (let e of Object.keys(s)) delete s[e];
                    c.length = 0, l.clear(), u.length = 0, this._sharedCommitCallbacks = u, this._sharedWriteBatch = s, this._sharedWriteOperations = c, this._sharedMergeKeys = l;
                    try {
                        return t(e) === !1 ? "refused" : Object.keys(s).length > 0 ? "collected" : "empty";
                    } catch {
                        return "refused";
                    } finally {
                        this._sharedWriteBatch = null, this._sharedWriteOperations = null, this._sharedMergeKeys = null, this._sharedCommitCallbacks = null;
                    }
                };
            if (d() === "refused") return i("collect_refused");
            let f = (e) => {
                let t = e && Object.keys(s).length > 0;
                n.onCommitted ? .(t), t && this.storageMode !== "private" && (this._sharedWriteConflictReported.clear(), n.operation === "session_save" && a === this._tokenSyncEpoch && (this._sessionSaveConflictEpisodes = 0));
                let r = this.store.getState().session;
                if (e && r.chatterToken === o.chatterToken && r.sessionToken === o.sessionToken) {
                    for (let e of u) e();
                    if (this._confirmedHandoffEnd && n.endBaseline === this._confirmedHandoffEnd.baseline)
                        for (let e of Object.keys(this._confirmedHandoffEnd.baseline)) e in s && this.storage.get(e) === s[e] && (this._confirmedHandoffEnd.baseline[e] = s[e]);
                }
                return e;
            };
            if (this.storageMode === "private" || Object.keys(s).length === 0) return f(!0);
            let p = () => {
                    let e = Object.keys(s),
                        t = [...new Set([
                            this.key,
                            this.legacyKey,
                            ...Object.keys(s).filter((e) => e.startsWith("ada:") && e.endsWith(":session"))
                        ])],
                        r = [
                            this.handoffStateKey,
                            L,
                            R,
                            ...Object.keys(s).filter((e) => e.startsWith("ada:") && e.endsWith(":handoff"))
                        ];
                    return {
                        writeKeys: e,
                        sessionKeys: t,
                        handoffKeys: r,
                        keys: [...new Set([
                            ...n.preservesHandoff || n.ownedKeysOnly ? e : [],
                            ...l,
                            ...t,
                            ...r,
                            "zdMessagingExternalUserId",
                            "zdMessagingChatterCreated",
                            "zdMessagingGeneration",
                            this.messagingAuthStateKey,
                            P,
                            F,
                            ...Object.keys(n.baseline ? ? {}),
                            ...Object.keys(n.endBaseline ? ? {}),
                            "liveChatRevision",
                            "liveChatTransition"
                        ])]
                    };
                },
                {
                    writeKeys: m,
                    sessionKeys: h,
                    handoffKeys: g,
                    keys: _
                } = p(),
                v = 0,
                y = 0,
                b = (e, t = !0, r = !1) => {
                    let i = e >= nN + 1;
                    if (n.operation && (i || r || t && Date.now() - v >= iN)) {
                        let t = n.operation;
                        if (!this._sharedWriteConflictReported.has(t)) {
                            this._sharedWriteConflictReported.add(t);
                            let n = "attempts";
                            r ? n = "widening" : i || (n = "deadline");
                            let a = {
                                attempts: e,
                                operation: t,
                                reason: n
                            };
                            pN.warn("shared write conflict exhausted", a), q("shared_write_conflict_exhausted", a);
                        }
                        return n.onSnapshotConflictExhausted ? .(), !0;
                    }
                    return !1;
                },
                x = (t, r = 0) => {
                    if (n.operation && r > 0) {
                        if (n.abortOnTokenSyncEpochChange && a !== this._tokenSyncEpoch) return i("not_current");
                        if (n.operation === "session_save" && (this._terminalClearsInProgress > 0 || this._currentSessionIsClearing())) return n.onRefusedForTerminalClear ? .(), i("terminal_clear");
                        let e = d(t);
                        if (e === "refused") return i("collect_refused");
                        if ({
                                writeKeys: m,
                                sessionKeys: h,
                                handoffKeys: g,
                                keys: _
                            } = p(), e === "empty") return f(!0);
                        if (!_.every((e) => e in t.values)) return b(r, r >= 2 || y > 0, y >= rN) ? i("snapshot_conflict") : (y += 1, this.storage.getConfirmed ? .(_).then((e) => e.confirmed && _.every((t) => t in e.values) ? x(e, r) : i("snapshot_conflict")).catch(() => i("snapshot_conflict")) ? ? i("snapshot_conflict"));
                    }
                    let l;
                    try {
                        l = this.storage.getConfirmedSync ? .(_) ? ? (!this.storage.refresh && t.confirmed ? {
                            ...t,
                            values: Object.fromEntries(_.map((e) => [e, this.storage.get(e)]))
                        } : t);
                    } catch {
                        return i("read_failed");
                    }
                    let u = { ...l.values
                    };
                    for (let e of c) e(u);
                    for (let e of m) {
                        if (n.staleAuthBaseline && e === this.messagingAuthStateKey && u[e] === l.values[e]) {
                            delete s[e];
                            continue;
                        }
                        s[e] = u[e];
                    }
                    let S = Object.keys(s),
                        C = (e, t) => {
                            if (!n.baselineMayBeCleared || !t) return t;
                            if (h.includes(e)) {
                                let e = Q(t);
                                if (e) return JSON.stringify([e.chatterToken, e.sessionToken]);
                            }
                            return e === this.messagingAuthStateKey ? Bo(t) ? .ownerChatterToken ? ? qo(t) ? ? t : t;
                        },
                        w = n.discardStaleZdm ? ["zdMessagingExternalUserId", "zdMessagingChatterCreated"].filter((e) => {
                            let t = l.values[e];
                            return t === null || t === "" || t === "\"\"" || t === "null";
                        }) : [];
                    if (n.baseline && Object.entries(n.baseline).some(([e, t]) => !w.includes(e) && C(e, l.values[e]) !== C(e, t) && !(n.baselineMayBeCleared && l.values[e] === null))) return i("baseline_changed");
                    if (n.confirmedEnd && n.endBaseline && Object.entries(n.endBaseline).some(([e, t]) => !w.includes(e) && l.values[e] !== t)) return i("end_baseline_changed");
                    let T = n.baseline;
                    if (n.restorePartialAdoption && (!T || n.baselineMayBeCleared || S.some((e) => !(e in T)))) return i("baseline_invalid");
                    let ee = n.restorePartialAdoption ? {
                        ...l.values,
                        ...s
                    } : l.values;
                    if (n.discardStaleZdm) {
                        let t = I(l.values.zdMessagingExternalUserId);
                        if (!((t !== null || w.includes("zdMessagingExternalUserId")) && !this._confirmedHandoffVerdict({
                                kind: "snapshot",
                                values: l.values
                            }) && !pS(l, h, g, Q).owners.some((e) => e.chatterToken !== null && e.chatterToken === t && (e.kind === "session" || e.kind === "auth") && e.credential)) && (!e.chatterToken && w.length !== 2 || this._hasZDMessagingContinuity(e.chatterToken, (e) => l.values[e] ? ? null))) return i(e.chatterToken ? "discard_stale_zdm_continuity" : "discard_stale_zdm_missing_owner", "pair");
                        ee = {
                            ...ee,
                            zdMessagingExternalUserId: null,
                            zdMessagingChatterCreated: null
                        };
                    }
                    let E = pS({
                            ...l,
                            values: ee,
                            coherent: this.storage.conditionalWritesSupported === !1 ? !0 : l.coherent
                        }, h, g, Q),
                        D = this.store.getState(),
                        te = J(D.session),
                        ne = this._orphanedAuthRecoveryBlockedBy(e, n.staleAuthBaseline, l.values, n.discardStaleZdm);
                    ne || (E.owners = E.owners.filter((e) => e.kind !== "auth"));
                    let re = n.replacement === te.chatterToken,
                        ie = te.chatterToken === o.chatterToken && te.sessionToken === o.sessionToken && n.isCurrent ? .() !== !1,
                        ae = [
                            "zdMessagingExternalUserId",
                            "zdMessagingChatterCreated",
                            "zdMessagingGeneration"
                        ];
                    if (!l.confirmed && !this.storage.isNoop || !_.every((e) => e in l.values)) {
                        let e = ne === "conditional_writes_unsupported" ? ne : "snapshot_unconfirmed";
                        return i("snapshot_unconfirmed", "none", n.staleAuthBaseline ? e : void 0);
                    }
                    if (n.isCurrent ? .() === !1) return i("not_current");
                    if (!E.confirmed || E.coherent === !1) {
                        let e = E.confirmed ? "snapshot_incoherent" : "snapshot_unconfirmed",
                            t = ne === "conditional_writes_unsupported" ? ne : e;
                        return n.onOwnershipRefused ? .(), i("snapshot_unconfirmed", "none", n.staleAuthBaseline ? t : void 0);
                    }
                    if (!ie) return n.onOwnershipRefused ? .(), i("not_current");
                    if (n.ownedKeysOnly && S.some((e) => s[e] !== null)) return n.onOwnershipRefused ? .(), i("owned_keys_write");
                    if (!n.ownedKeysOnly && !cS({
                            expected: e,
                            shared: E,
                            current: {
                                ...re ? e : te,
                                inHandoff: D.liveAgent.inLiveChat || D.liveAgent.inPending
                            },
                            isCurrent: ie,
                            confirmedEnd: n.confirmedEnd,
                            preservesHandoff: n.credentialOnly && typeof n.maxRefreshGeneration == "number" && !!e.chatterToken && Object.entries(s).every(([e, t]) => e === this.messagingAuthStateKey && t === null) || n.preservesHandoff && !Object.entries(s).some(([e, t]) => t === null && l.values[e] != null && e !== this.readStateKey)
                        })) {
                        let t = "none";
                        if (n.onRefused) {
                            let n = [...E.owners, {
                                    kind: "current",
                                    ...re ? e : te
                                }],
                                r = n.find((t) => t.chatterToken && t.chatterToken !== e.chatterToken) ? ? n.find((t) => t.sessionToken && t.sessionToken !== e.sessionToken);
                            t = r ? .kind ? ? "none", r && r.kind === "pair" && (!r.chatterToken || r.chatterToken === e.chatterToken) ? t = "legacy_session" : !r && (E.inHandoff || D.liveAgent.inLiveChat || D.liveAgent.inPending) && (t = "handoff_open");
                        }
                        return n.onOwnershipRefused ? .(), i("can_clear_shared_handoff", t, n.staleAuthBaseline ? ne : void 0);
                    }
                    if (n.ownedKeysOnly) {
                        for (let t of S) {
                            let n = l.values[t] ? ? null,
                                r = null,
                                i = e.chatterToken;
                            h.includes(t) ? r = Q(n) ? .chatterToken ? ? null : t === this.messagingAuthStateKey ? r = GM(n) : t === this.pendingResetKey ? r = n === null ? null : KM(n).chatterToken : ae.includes(t) ? r = I(l.values.zdMessagingExternalUserId ? ? null) : t === "chatter" ? r = I(n) : t === "sessionToken" && (r = I(n), i = e.sessionToken ? ? null), r !== null && r !== i && delete s[t];
                        }
                        let t = [
                            P,
                            F,
                            $
                        ];
                        if (t.every((e) => S.includes(e)) && t.some((e) => !(e in s)))
                            for (let e of t) delete s[e];
                    }
                    if (n.rejectChangedCredential && (re && (te.chatterToken !== e.chatterToken || te.sessionToken !== e.sessionToken) ? E.owners : [te, ...E.owners]).some((t) => t.credential && t.credential !== e.credential)) return n.onOwnershipRefused ? .(), i("credential_changed");
                    if (n.acceptedStoredCredentials && E.owners.some((e) => e.credential && !n.acceptedStoredCredentials ? .includes(e.credential))) return i("credential_changed");
                    let O = !n.restorePartialAdoption && Jo(l.values[this.messagingAuthStateKey] ? ? null, e.chatterToken ? ? "");
                    O && s[this.messagingAuthStateKey] === null && n.maxRefreshGeneration !== void 0 && O.refreshGeneration > n.maxRefreshGeneration && delete s[this.messagingAuthStateKey];
                    let oe = Bo(s[this.messagingAuthStateKey] ? ? null);
                    if (O && oe && O.ownerChatterToken === oe.ownerChatterToken && (O.refreshGeneration > oe.refreshGeneration || O.refreshGeneration === oe.refreshGeneration && (Uo(O.messagingToken) !== Uo(oe.messagingToken) || (O.messagingToken === oe.messagingToken || O.messagingTokenExpiresAt >= oe.messagingTokenExpiresAt) && O.sessionCookieIssued === !0 == (oe.sessionCookieIssued === !0)) && Bo(l.values[this.messagingAuthStateKey] ? ? null) ? .ownerChatterToken === e.chatterToken) && delete s[this.messagingAuthStateKey], O && oe && O.ownerChatterToken === oe.ownerChatterToken && O.refreshGeneration === oe.refreshGeneration && Uo(O.messagingToken) === Uo(oe.messagingToken) && this.messagingAuthStateKey in s && (s[this.messagingAuthStateKey] = JSON.stringify(O.messagingTokenExpiresAt > oe.messagingTokenExpiresAt ? O : oe)), this.storage.compareAndWrite) return n.operation && r === 0 && (v = Date.now()), this.storage.compareAndWrite(l.values, s).then(async (e) => {
                        if (e) return f(!0);
                        if (!n.operation && r >= 1 || !this.storage.getConfirmed) return i("snapshot_conflict");
                        let t = await this.storage.getConfirmed(_);
                        return t.confirmed ? _.every((e) => t.values[e] === l.values[e]) ? (n.onUnchangedWriteFailure ? .(), i("write_failed")) : n.abortOnTokenSyncEpochChange && a !== this._tokenSyncEpoch ? i("not_current") : n.operation === "session_save" && (this._terminalClearsInProgress > 0 || this._currentSessionIsClearing()) ? (n.onRefusedForTerminalClear ? .(), i("terminal_clear")) : b(r + 1, r >= 1) ? i("snapshot_conflict") : (y = 0, x(t, r + 1)) : i("snapshot_conflict");
                    }).catch(() => i("write_failed"));
                    if (this.storage.refresh && !this.storage.getConfirmedSync) return i("snapshot_conflict");
                    let k = !1;
                    try {
                        for (let [e, t] of Object.entries(s)) t === null ? this.storage.remove(e) : this.storage.set(e, t);
                        k = Object.keys(s).every((e) => this.storage.getWriteResult ? .(e) !== !1);
                    } finally {
                        if (!k) {
                            for (let [e, t] of Object.entries(s)) {
                                let n = l.values[e];
                                if (!(n === void 0 || n === t)) try {
                                    let r = this.storage.getConfirmedSync ? .([e]);
                                    if (!r ? .confirmed || r.values[e] !== t) continue;
                                    n === null ? this.storage.remove(e) : this.storage.set(e, n);
                                } catch {}
                            }
                            let e;
                            try {
                                e = this.storage.getConfirmedSync ? .(_);
                            } catch {
                                e = void 0;
                            }
                            e ? .confirmed && _.every((t) => e.values[t] === l.values[t]) && n.onUnchangedWriteFailure ? .();
                        }
                    }
                    return k ? f(!0) : Promise.resolve(i("write_failed"));
                },
                S = () => {
                    let e;
                    try {
                        e = this.storage.getConfirmedSync ? .(_) ? ? n.confirmedSnapshot;
                        let t = e ? .values;
                        e ? .confirmed && t && !_.every((e) => e in t) && this.storage.getConfirmed && (e = void 0), !e && !this.storage.getConfirmed && !this.storage.refresh && (e = {
                            confirmed: !0,
                            coherent: !0,
                            values: Object.fromEntries(_.map((e) => [e, this.storage.get(e)]))
                        });
                    } catch {
                        return i("read_failed");
                    }
                    return e ? x(e) : this.storage.getConfirmed ? .(_).then(x).catch(() => i("read_failed")) ? ? i("snapshot_unconfirmed");
                },
                C = () => !this.storage.compareAndWrite && !this.storage.refresh && (!this.storage.getConfirmed || this.storage.getConfirmedSync) && (n.replacesOwnership || m.some((e) => s[e] === null || e === this.handoffStateKey && s[e] !== (n.baseline ? .[e] ? ? this.storage.get(e)))) ? UM(S) : S(),
                w = this._sharedMutationPending ? this._sharedMutationPending.then(C, C) : C(),
                T = w instanceof Promise ? w.catch(() => i("write_failed")) : w;
            if (T instanceof Promise) {
                this._sharedMutationPending = T;
                let e = () => {
                    this._sharedMutationPending === T && (this._sharedMutationPending = null);
                };
                T.then(e, e);
            }
            return T;
        }
        saveCurrentSession(e = {}) {
            if (!this._sharedWriteBatch && (this._terminalClearsInProgress > 0 || this._currentSessionIsClearing())) return !1;
            if (!this._sharedWriteBatch && this._pendingChatterPersistenceCommit) {
                let t = this.store.getState().session.chatterToken;
                if (this._pendingChatterPersistenceCommit.chatterToken === t) return this._applyPendingChatterPersistenceCommit(this._pendingChatterPersistenceCommit, e.onFailure, e.isCurrent, {
                    unconditional: !e.isCurrent,
                    onCommitted: e.onCommitted
                });
                t !== null && (this._pendingChatterPersistenceCommit = null);
            }
            return this.mutateSharedSession(J(this.store.getState().session), () => this._saveCurrentSession(), {
                preservesHandoff: !0,
                operation: "session_save",
                abortOnTokenSyncEpochChange: !0,
                isCurrent: e.isCurrent,
                onCommitted: e.onCommitted,
                onSnapshotConflictExhausted: () => e.onFailure ? .("snapshot_conflict_exhausted"),
                onRefusedForTerminalClear: () => e.onFailure ? .("write_refused"),
                onOwnershipRefused: () => e.onFailure ? .("ownership_refused")
            });
        }
        canRecoverSessionCookie(e) {
            return (e.messagingSessionCookieEnabled === !0 || e.messagingSessionCookieEnabled === null && e.sessionCookieIssued === !0) && !e.identitySession && !e.identityToken && e.persistence === "normal" && this.storageMode === "normal" && !this.handoffOnlyPersistence && !this._persistenceWithheld(e.chatterToken);
        }
        async persistRecoveredSessionCookie(e, t, n) {
            if (!this._sharedWriteBatch && (this._terminalClearsInProgress > 0 || this._currentSessionIsClearing())) return this._reportSessionSaveFailure("write_refused"), !1;
            let r = this._tokenSyncEpoch,
                i = !1,
                a = (e) => {
                    i = !0, this._reportSessionSaveFailure(e);
                },
                o = await this._persistSessionCookie(J(e), () => this._saveCurrentSession({
                    ...e,
                    messagingToken: t.messagingToken,
                    messagingTokenExpiresAt: Date.now() + t.expiresIn * 1e3,
                    sessionRefreshToken: t.sessionRefreshToken ? ? null,
                    refreshGeneration: t.refreshGeneration ? ? null,
                    sessionCookieIssued: t.sessionCookieIssued === !0
                }), {
                    preservesHandoff: !0,
                    operation: "session_save",
                    abortOnTokenSyncEpochChange: !0,
                    isCurrent: n,
                    onSnapshotConflictExhausted: () => a("snapshot_conflict_exhausted"),
                    onRefusedForTerminalClear: () => a("write_refused"),
                    onOwnershipRefused: () => a("ownership_refused")
                });
            return o === !1 && !i && r === this._tokenSyncEpoch && n() && this._reportSessionSaveFailure("flush_failed"), o;
        }
        async _persistSessionCookie(e, t, n) {
            let r = this._tokenSyncEpoch,
                i = !1,
                a = await this.mutateSharedSession(e, t, {
                    ...n,
                    onUnchangedWriteFailure: () => {
                        i = !0;
                    }
                });
            return !a && i && r === this._tokenSyncEpoch && this._terminalClearsInProgress === 0 && !this._currentSessionIsClearing() && n.isCurrent() ? "memory" : a;
        }
        _saveCurrentSession(e = this.store.getState().session) {
            let {
                chatterToken: t,
                chatterId: n,
                sessionToken: r,
                sessionTokenExpiresAt: i,
                sessionRefreshToken: a,
                messagingToken: o,
                messagingTokenExpiresAt: s,
                sessionCookieIssued: c,
                refreshGeneration: l,
                identitySession: u,
                language: d
            } = e;
            if (!t || this._persistenceSuppressed()) return;
            if (this.handoffOnlyPersistence && this._handoffPersistenceResumed(), this._persistenceWithheld(t)) {
                this._notePersistenceWithheld(t);
                return;
            }
            let f = {
                version: 1,
                chatterToken: t,
                chatterId: n ? ? "",
                language: d,
                sessionToken: r,
                sessionTokenExpiresAt: i,
                sessionRefreshToken: null,
                messagingToken: null,
                messagingTokenExpiresAt: null,
                refreshGeneration: null,
                identitySession: u
            };
            this._setSharedValue(this.key, JSON.stringify(f)), this._saveMessagingAuthState({
                chatterToken: t,
                messagingToken: o,
                messagingTokenExpiresAt: s,
                sessionRefreshToken: a,
                sessionCookieIssued: c,
                refreshGeneration: l
            }), this._mirrorLegacySessionKeys(t, r), this._afterSharedCommit(() => {
                this._handoffOnlyOwnsMirrors = !0;
            });
        }
        startTokenSync() {
            this.storageMode !== "private" && (this._storeUnsubscribe || (this._tokenSyncEpoch += 1, this._resetSessionSaveConflictState(), this._lastSavedReadState ? ? = JSON.stringify(this.store.getState().chat.lastReadCursorByConversation), this._lastSavedHandoffState = Yo(this.storage.get(this.handoffStateKey)), this.store.getState().liveAgent.liveChatEndedInConversation && !this._confirmedHandoffEnd && (this._confirmedHandoffEnd = this._captureHandoffEnd()), this._observedLocalHandoff = this.store.getState().liveAgent.inLiveChat || this.store.getState().liveAgent.inPending, this._storeUnsubscribe = this.store.subscribe(() => {
                if (this._currentSessionIsClearing()) return;
                let e = this.store.getState().liveAgent.inLiveChat || this.store.getState().liveAgent.inPending;
                this._observedLocalHandoff && !e && this.store.getState().liveAgent.hadHandoff && (this._confirmedHandoffEnd = this._captureHandoffEnd()), e && (this._confirmedHandoffEnd = null, this._observedLocalHandoff || (this._zdmSavedCursor = null)), this._observedLocalHandoff = e, this._syncZdmContinuity(), this._sessionSaveCursorChanged(this._currentSessionSaveCursor()) && this._requestAcknowledgedSessionSave(), this._saveReadStateIfChanged(), this._saveHandoffStateIfChanged();
            }), this._syncZdmContinuity(), this._requestAcknowledgedSessionSave(), this._saveHandoffStateIfChanged()));
        }
        _resetSessionSaveConflictState() {
            this._sessionSaveConflictEpisodes = 0, this._sessionSaveConflictStuckReported = !1, this._sessionSaveFlushRetries = 0, this._cancelSessionSaveBackoff(), this._sessionSaveDeferredBackoffKind = null, this._sessionSaveFailureReported.clear(), this._sharedWriteConflictReported.delete("session_save");
        }
        _cancelSessionSaveBackoff() {
            let e = this._sessionSaveBackoffKind;
            return this._sessionSaveBackoffTimer !== null && (clearTimeout(this._sessionSaveBackoffTimer), this._sessionSaveBackoffTimer = null, this._sessionSaveBackoffKind = null), e;
        }
        stopTokenSync() {
            this._storeUnsubscribe ? .(), this._storeUnsubscribe = null, this._tokenSyncEpoch += 1, this._resetSessionSaveConflictState(), this._sessionSaveInFlight = !1, this._sessionSaveRequested = !1, this._lastSavedMessagingToken = null, this._lastSavedRefreshToken = null, this._lastSavedRefreshGeneration = null, this._lastSavedLanguage = null, this._lastSavedChatterToken = null, this._lastSavedReadState = null, this._pendingReadState = null, this._lastRefusedReadState = null, this._lastSavedHandoffState = null, this._suspendHandoffOnlyWipe();
        }
        _suspendHandoffOnlyWipe() {
            this._handoffOnlyWipeTimer !== null && (clearTimeout(this._handoffOnlyWipeTimer), this._handoffOnlyWipeTimer = null), this._handoffOnlyWipe === "pending" && (this._handoffOnlyWipeGeneration += 1, this._handoffOnlyWipeUnacknowledged("abandoned"));
        }
        _currentSessionSaveCursor() {
            let {
                chatterToken: e,
                messagingToken: t,
                sessionRefreshToken: n,
                sessionCookieIssued: r,
                refreshGeneration: i,
                language: a
            } = this.store.getState().session;
            return {
                chatterToken: e,
                messagingToken: t,
                sessionRefreshToken: n,
                sessionCookieIssued: r,
                refreshGeneration: i,
                language: a
            };
        }
        _sessionPersistenceWriteKeys() {
            return [
                this.key,
                this.messagingAuthStateKey,
                P,
                F,
                $,
                _N
            ];
        }
        _conversationClearWriteKeys() {
            return [
                this.key,
                this.pendingResetKey,
                this.legacyKey,
                this.messagingAuthStateKey,
                this.readStateKey,
                this.handoffStateKey,
                P,
                $,
                _N,
                F
            ];
        }
        _clearAllStorageWriteKeys() {
            return ["greetingLease", ...this._conversationAndZendeskClearWriteKeys()];
        }
        _conversationAndZendeskClearWriteKeys() {
            return [
                ...this._conversationClearWriteKeys(),
                kN(this.handle),
                DN(this.handle)
            ];
        }
        _pendingChatterPersistenceCommitWriteKeys(e) {
            return e.kind === "identity" ? this._clearAllStorageWriteKeys() : [...new Set([
                "greetingLease",
                ...this._sessionPersistenceWriteKeys(),
                this.legacyKey,
                this.handoffStateKey,
                kN(this.handle),
                DN(this.handle),
                L,
                R,
                "zdMessagingExternalUserId",
                "zdMessagingChatterCreated",
                "zdMessagingGeneration"
            ])];
        }
        _applyPendingChatterPersistenceCommit(e, t, n, r = {}) {
            if (!this._sharedWriteBatch && (this._terminalClearsInProgress > 0 || this._currentSessionIsClearing())) return r.onRefused ? .({
                refusalGuard: "terminal_clear",
                refusalOwner: "none"
            }), !1;
            let i = this._pendingChatterCommitAttempt;
            if (i ? .commit === e) return i.guards.push(n ? ? (() => !0)), i.promise.then((e) => (e && r.onCommitted ? .(i.committed.wrote), i.failure.reason && t ? .(i.failure.reason), e));
            let a = {},
                o = {
                    wrote: !1
                },
                s = n ? [n] : [];
            r.unconditional && !n && s.push(() => !0);
            let c = this.mutateSharedSession(e.expected ? ? J(this.store.getState().session), (t) => this._collectPendingChatterPersistenceCommit(e, t), {
                    operation: "session_save",
                    onRefused: r.onRefused,
                    onCommitted: (e) => {
                        o.wrote = e, r.onCommitted ? .(e);
                    },
                    isCurrent: () => s.length === 0 || s.some((e) => e()),
                    onSnapshotConflictExhausted: () => {
                        a.reason = "snapshot_conflict_exhausted", t ? .(a.reason);
                    },
                    onRefusedForTerminalClear: () => {
                        a.reason = "write_refused", t ? .(a.reason);
                    },
                    onOwnershipRefused: () => {
                        a.reason = "ownership_refused", t ? .(a.reason);
                    },
                    replacement: e.chatterToken,
                    replacesOwnership: e.expected ? .chatterToken !== e.chatterToken || e.expected ? .sessionToken !== this.store.getState().session.sessionToken,
                    rejectChangedCredential: e.kind === "fresh",
                    preservesHandoff: e.kind === "identity" && (!e.expected ? .chatterToken || e.expected.chatterToken === e.chatterToken)
                }),
                l = (t) => (t && (e.expected = J(this.store.getState().session)), t);
            if (!(c instanceof Promise)) return l(c);
            let u = c.then(l).finally(() => {
                this._pendingChatterCommitAttempt ? .promise === u && (this._pendingChatterCommitAttempt = null);
            });
            return this._pendingChatterCommitAttempt = {
                commit: e,
                promise: u,
                failure: a,
                committed: o,
                guards: s
            }, u;
        }
        _collectPendingChatterPersistenceCommit(e, t) {
            if (this.store.getState().session.chatterToken !== e.chatterToken) return !1;
            if (e.kind === "identity") {
                let n = t ? t.confirmed && [this.key, this.legacyKey].every((e) => e in t.values) : [this.key, this.legacyKey].every((e) => this.storage.hydrated ? .([e]) !== !1),
                    r = t ? Q(t.values[this.key] ? ? null) ? .chatterToken ? ? Q(t.values[this.legacyKey] ? ? null) ? .chatterToken ? ? null : this._persistedChatterToken();
                n && r !== e.chatterToken && !(this.store.getState().liveAgent.inLiveChat || this.store.getState().liveAgent.inPending) && this.clearAllStorage(), this._afterSharedCommit(() => {
                    this._pendingRestoredChatterToken = e.chatterToken;
                }), this.saveCurrentSession();
                return;
            }
            this._removeSharedValue("greetingLease"), this._removeSharedValue(this.readStateKey), this._removeSharedValue(this.key), this._removeSharedValue(this.pendingResetKey), this._removeSharedValue(this.legacyKey);
            for (let t of e.previousChatterTokens) this._removeMessagingAuthStateIfOwned(t);
            this._removeHandoffState(), this._removeLegacySessionKeys(), this._removeZendeskVisitorKeys(), this._removeLegacyHandoffState(), this.saveCurrentSession();
        }
        _removeZendeskVisitorKeys() {
            this._removeSharedValue(kN(this.handle)), this._removeSharedValue(DN(this.handle));
        }
        _holdsForeignChatter(e, t) {
            return [
                I(e.zdMessagingExternalUserId ? ? null),
                GM(e[this.messagingAuthStateKey] ? ? null),
                I(e.chatter ? ? null),
                ...[this.key, this.legacyKey].map((t) => Q(e[t] ? ? null) ? .chatterToken ? ? null)
            ].some((e) => e !== null && e !== t);
        }
        _sessionSaveCursorChanged(e) {
            return e.chatterToken !== this._lastSavedChatterToken || e.messagingToken !== this._lastSavedMessagingToken || e.sessionRefreshToken !== this._lastSavedRefreshToken || e.refreshGeneration !== this._lastSavedRefreshGeneration || e.sessionCookieIssued === !0 !== this._lastSavedSessionCookieIssued || e.language !== this._lastSavedLanguage;
        }
        _requestAcknowledgedSessionSave() {
            this._currentSessionIsClearing() || !this._storeUnsubscribe || this.storageMode === "private" || this._persistenceSuppressed() || (this._sessionSaveRequested = !0, this._sessionSaveBackoffKind === "flush" && this._cancelSessionSaveBackoff(), this._sessionSaveFlushRetries = 0, this._drainAcknowledgedSessionSave());
        }
        _drainAcknowledgedSessionSave() {
            if (this._terminalClearsInProgress > 0 || this._currentSessionIsClearing() || !this._storeUnsubscribe || this._sessionSaveInFlight || this._sessionSaveBackoffTimer !== null || !this._sessionSaveRequested || this._persistenceSuppressed()) return;
            let e = this._currentSessionSaveCursor();
            if (e.chatterToken && this._persistenceWithheld(e.chatterToken)) {
                this._notePersistenceWithheld(e.chatterToken);
                return;
            }
            if (this._sessionSaveRequested = !1, !this._sessionSaveCursorChanged(e)) return;
            let t = this._tokenSyncEpoch;
            this._sessionSaveInFlight = !0;
            let n, r = "flush_failed",
                i = !1;
            try {
                let e = this.saveCurrentSession({
                    onCommitted: (e) => {
                        i = e;
                    },
                    onFailure: (e) => {
                        r = e;
                    }
                });
                if (e instanceof Promise) n = e.then((e) => e ? this.storage.flush ? .(this._sessionPersistenceWriteKeys()) ? ? !0 : !1);
                else if (e) n = this.storage.flush ? .(this._sessionPersistenceWriteKeys());
                else {
                    this._sessionSaveInFlight = !1, t === this._tokenSyncEpoch && this.store.getState().session.chatterToken && this._terminalClearsInProgress === 0 && !this._currentSessionIsClearing() && !this._persistenceSuppressed() && (this._sessionSaveRequested = !0);
                    return;
                }
            } catch {
                this._finishAcknowledgedSessionSave(t, e, !1, i, "write_exception");
                return;
            }
            if (!n) {
                this._finishAcknowledgedSessionSave(t, e, !0, i);
                return;
            }
            n.then((n) => this._finishAcknowledgedSessionSave(t, e, n, i, n ? void 0 : r), () => this._finishAcknowledgedSessionSave(t, e, !1, i, "flush_rejected"));
        }
        _reportSessionSaveFailure(e) {
            this._sessionSaveFailureReported.has(e) || (this._sessionSaveFailureReported.add(e), q("session_save_flush_failed", {
                reason: e
            }));
        }
        _finishAcknowledgedSessionSave(e, t, n, r, i) {
            if (!(e !== this._tokenSyncEpoch || !this._storeUnsubscribe)) {
                if (this._sessionSaveInFlight = !1, !n && i && this._reportSessionSaveFailure(i), n && !r && t.chatterToken !== null) {
                    this._sessionSaveRequested = !0;
                    return;
                }
                if (n && (r && zM(), this._sessionSaveFailureReported.clear(), this._sessionSaveFlushRetries = 0, this._lastSavedChatterToken = t.chatterToken, this._lastSavedMessagingToken = t.messagingToken, this._lastSavedRefreshToken = t.sessionRefreshToken, this._lastSavedRefreshGeneration = t.refreshGeneration, this._lastSavedSessionCookieIssued = t.sessionCookieIssued === !0, this._lastSavedLanguage = t.language, this._sessionSaveCursorChanged(this._currentSessionSaveCursor()) && (this._sessionSaveRequested = !0)), !n && i === "write_refused") this._sessionSaveRequested = !0;
                else if (!n && i === "snapshot_conflict_exhausted") {
                    if (this._sessionSaveConflictEpisodes += 1, this._sessionSaveConflictEpisodes >= sN && !this._sessionSaveConflictStuckReported) {
                        this._sessionSaveConflictStuckReported = !0;
                        let e = {
                            episodes: this._sessionSaveConflictEpisodes
                        };
                        pN.warn("session save conflict stuck", e), q("session_save_conflict_stuck", e);
                    }
                    this._scheduleSessionSaveBackoff(e, "conflict");
                } else !n && i === "flush_failed" && this._sessionSaveCursorChanged(this._currentSessionSaveCursor()) && this._sessionSaveFlushRetries < cN ? (this._sessionSaveFlushRetries += 1, this._scheduleSessionSaveBackoff(e, "flush")) : this._sessionSaveRequested && this._drainAcknowledgedSessionSave();
            }
        }
        _scheduleSessionSaveBackoff(e, t) {
            if (this._sessionSaveRequested = !0, this._terminalClearsInProgress > 0 || this._currentSessionIsClearing()) {
                this._sessionSaveDeferredBackoffKind = t;
                return;
            }
            let n = aN + Math.random() * oN;
            this._sessionSaveBackoffKind = t, this._sessionSaveBackoffTimer = setTimeout(() => {
                this._sessionSaveBackoffTimer = null, this._sessionSaveBackoffKind = null, !(e !== this._tokenSyncEpoch || !this._storeUnsubscribe) && this._drainAcknowledgedSessionSave();
            }, n);
        }
        clear() {
            return this.mutateSharedSession(J(this.store.getState().session), () => this._clear(), {});
        }
        _clear() {
            this._afterSharedCommit(() => this.cancelPendingRestoredHistory());
            let {
                chatterToken: e
            } = this.store.getState().session;
            this._clearOwnedBy(e);
        }
        _clearOwnedBy(e, t) {
            this._afterSharedCommit(() => this.cancelPendingRestoredHistory()), this._removeSharedValue(this.key), this._removeSharedValue(this.pendingResetKey), this._removeSharedValue(this.legacyKey), this._removeMessagingAuthStateIfOwned(e, void 0, t), this._removeSharedValue(this.readStateKey), this._removeHandoffState(), this._removeLegacySessionKeys();
        }
        _clearConfirmedConversationBucket(e = this._conversationClearWriteKeys()) {
            this._afterSharedCommit(() => this.cancelPendingRestoredHistory());
            for (let t of e) this._removeSharedValue(t);
        }
        async _readDurableClearSnapshot(e, t) {
            if (this.storage.getConfirmed) {
                let n = await this.storage.getConfirmed(e);
                return !n.confirmed || n.coherent === !1 || t ? .aborted ? null : n.values;
            }
            return t ? .aborted ? null : Object.fromEntries(e.map((e) => [e, this.storage.get(e)]));
        }
        async _readPendingReset(e = new AbortController().signal) {
            let t = await this._readConfirmedSnapshot([this.pendingResetKey], e);
            if (t.kind !== "snapshot") return;
            let n = t.values[this.pendingResetKey];
            return n === null ? null : KM(n);
        }
        async clearDurably(e, t, n, r) {
            let i = [
                ...this._conversationAndZendeskClearWriteKeys(),
                "zdMessagingExternalUserId",
                "zdMessagingChatterCreated",
                "zdMessagingGeneration"
            ];
            YM(this.key);
            let a = t ? this._durableClearReceipt(t) : null;
            if (t && !a) return !1;
            if (this.storageMode !== "private" && a && this._receiptCovers(a, this.durableClearReceiptStorage.get(a.primaryKey))) return e ? .aborted !== !0;
            let o = this.zdmPersistence ? await this._readPendingReset(e) : null;
            if (o === void 0) return !1;
            let s = J(this.store.getState().session),
                c = this._conversationClearWriteKeys().filter((e) => !this.zdmPersistence || e !== this.pendingResetKey),
                l = [
                    ...c,
                    L,
                    R,
                    "liveChatRevision",
                    "liveChatTransition",
                    "zdMessagingExternalUserId",
                    "zdMessagingChatterCreated",
                    "zdMessagingGeneration"
                ],
                u = Object.fromEntries(l.map((e) => [e, this.storage.get(e)])),
                d = a && this.storageMode !== "private" ? [...l, a.fallbackKey] : [...l],
                f = await this._readDurableClearSnapshot(d, e);
            if (!f) return !1;
            if (this.storageMode !== "private" && a && f[a.fallbackKey] === t) return e ? .aborted !== !0;
            let p = Q(f[this.key] ? ? null),
                m = Q(f[this.legacyKey] ? ? null),
                h = I(f.chatter ? ? null),
                g = GM(f[this.messagingAuthStateKey] ? ? null),
                _ = /* @__PURE__ */ new Set();
            for (let e of [
                    p ? .chatterToken,
                    m ? .chatterToken,
                    h,
                    g
                ]) e && _.add(e);
            if (_.size > 1) {
                let t = await this._readDurableClearSnapshot(d, e);
                if (!t || d.some((e) => t[e] !== f[e])) return !1;
            }
            let v = _.values().next().value ? ? null;
            if (e ? .aborted) return !1;
            let y = {
                    chatterToken: o ? .chatterToken ? ? r ? .chatterToken ? ? s.chatterToken ? ? v,
                    sessionToken: r ? .sessionToken ? ? s.sessionToken ? ? p ? .sessionToken ? ? m ? .sessionToken ? ? I(f.sessionToken ? ? null)
                },
                b = () => !e ? .aborted && this.store.getState().session.chatterToken === s.chatterToken && this.store.getState().session.sessionToken === s.sessionToken,
                x = {
                    confirmedSnapshot: {
                        confirmed: !0,
                        values: f
                    },
                    confirmedEnd: !0,
                    baseline: u,
                    baselineMayBeCleared: !0,
                    isCurrent: b
                },
                S = async (t) => {
                    if (!await this.mutateSharedSession(y, () => this._setSharedValue(this.pendingResetKey, JSON.stringify(t)), x) || await this.storage.flush ? .([this.pendingResetKey]) === !1) return !1;
                    let n = await this._readPendingReset(e);
                    return "chatterToken" in t ? n ? .chatterToken === t.chatterToken : n ? .companionCleared === !0;
                },
                C = o ? .companionCleared === !0 && !y.chatterToken;
            if (this.zdmPersistence && !C && y.chatterToken && !o ? .chatterToken && !await S({
                    chatterToken: y.chatterToken
                })) return !1;
            if (this.zdmPersistence && !C && (y.chatterToken || o)) {
                let t = this.zdmPersistence,
                    n = await t._readConfirmedExistingChatterSnapshot(e ? ? new AbortController().signal);
                if (n.kind !== "snapshot") return !1;
                let r = I(n.values.zdMessagingExternalUserId),
                    i = pS({
                        confirmed: !0,
                        values: n.values
                    }, [t.key, t.legacyKey], [], Q),
                    a = GM(n.values[t.messagingAuthStateKey] ? ? null),
                    c = a === null && i.owners.every((e) => !e.chatterToken && !e.credential),
                    l = pS({
                        confirmed: !0,
                        values: {
                            ...n.values,
                            zdMessagingExternalUserId: null
                        }
                    }, [t.key, t.legacyKey], [], Q).owners,
                    u = {
                        chatterToken: o ? .chatterToken ? ? y.chatterToken,
                        sessionToken: null
                    },
                    d = o && !u.chatterToken && !c;
                if (d && (u.chatterToken = r ? ? i.owners.find((e) => e.chatterToken) ? .chatterToken ? ? a), u.chatterToken && (u.sessionToken = [
                        p,
                        m,
                        {
                            chatterToken: h,
                            sessionToken: I(f.sessionToken ? ? null)
                        },
                        ...l,
                        s
                    ].find((e) => e ? .chatterToken === u.chatterToken && e.sessionToken) ? .sessionToken ? ? null), d && (!u.chatterToken || l.some((e) => e.chatterToken && (e.chatterToken !== u.chatterToken || e.sessionToken && e.sessionToken !== u.sessionToken)))) return !1;
                let g = r === u.chatterToken,
                    _ = u.chatterToken && (a === null || a === u.chatterToken) && l.some((e) => e.chatterToken === u.chatterToken) && l.every((e) => (!e.chatterToken || e.chatterToken === u.chatterToken) && (!e.sessionToken || e.sessionToken === u.sessionToken)) && (g || !r) && (s.chatterToken !== u.chatterToken || s.sessionToken === u.sessionToken),
                    v = (e) => e.kind === "snapshot" ? (!u.chatterToken || GM(e.values[t.messagingAuthStateKey] ? ? null) !== u.chatterToken) && (!u.sessionToken || I(e.values.sessionToken ? ? null) !== u.sessionToken) && pS({
                        confirmed: !0,
                        values: e.values
                    }, [t.key, t.legacyKey], [], Q).owners.every((e) => (!u.chatterToken || e.chatterToken !== u.chatterToken) && (!u.sessionToken || e.chatterToken && e.chatterToken !== u.chatterToken || e.sessionToken !== u.sessionToken)) : !1;
                if (C = v(n), !o ? .chatterToken && !y.chatterToken && !await S(u.chatterToken ? {
                        chatterToken: u.chatterToken
                    } : {
                        companionCleared: !0
                    }) || (C || = (_ ? await t.clearDurably(e, void 0, void 0, u) : await t.mutateSharedSession(u, () => {
                        t._holdsForeignChatter(n.values, u.chatterToken) || t._removeZendeskVisitorKeys();
                        for (let e of [t.key, t.legacyKey]) Q(n.values[e] ? ? null) ? .chatterToken === u.chatterToken && t._removeSharedValue(e);
                        a === u.chatterToken && t._removeSharedValue(t.messagingAuthStateKey), g && (t._removeSharedValue("zdMessagingExternalUserId"), t._removeSharedValue("zdMessagingChatterCreated"), t._removeSharedValue("zdMessagingGeneration")), u.sessionToken && I(n.values.sessionToken ? ? null) === u.sessionToken && t._removeSharedValue(F), I(n.values.chatter ? ? null) === u.chatterToken && t._removeSharedValue(P);
                    }, {
                        ownedKeysOnly: !0,
                        baseline: n.values,
                        isCurrent: () => !e ? .aborted
                    }), await t.storage.flush ? .([
                        t.key,
                        t.legacyKey,
                        t.messagingAuthStateKey,
                        "zdMessagingExternalUserId",
                        "zdMessagingChatterCreated",
                        "zdMessagingGeneration",
                        kN(t.handle),
                        DN(t.handle),
                        F,
                        P
                    ]), v(await t._readConfirmedExistingChatterSnapshot(e ? ? new AbortController().signal))), !C)) return !1;
            }
            if (this.zdmPersistence && (e ? .aborted || await n ? .(y) === !1) || !await this.mutateSharedSession(y, () => {
                    this._clearConfirmedConversationBucket(c), this._removeZendeskVisitorKeys(), this._removeSharedValue("zdMessagingExternalUserId"), this._removeSharedValue("zdMessagingChatterCreated"), this._removeSharedValue("zdMessagingGeneration");
                }, x) || await this.storage.flush ? .(i) === !1 || e ? .aborted === !0 || !this.zdmPersistence && await n ? .(y) === !1 || e ? .aborted || C && (!await this.mutateSharedSession(y, () => this._removeSharedValue(this.pendingResetKey), {
                    confirmedEnd: !0,
                    isCurrent: b
                }) || await this.storage.flush ? .([this.pendingResetKey]) === !1 || await this._readPendingReset(e) !== null)) return !1;
            if (t && a && this.storageMode !== "private") {
                let n = this.durableClearReceiptStorage.get(a.primaryKey),
                    r = this._nextReceiptValue(a, n);
                r !== n && this.durableClearReceiptStorage.set(a.primaryKey, r);
                let i = await this.durableClearReceiptStorage.flush ? .([a.primaryKey]);
                return e ? .aborted ? !1 : i !== !1 && this._receiptCovers(a, this.durableClearReceiptStorage.get(a.primaryKey)) ? !0 : (this.storage.set(a.fallbackKey, t), await this.storage.flush ? .([a.fallbackKey]) === !1 || e ? .aborted ? !1 : (await this._readDurableClearSnapshot([a.fallbackKey], e)) ? .[a.fallbackKey] === t);
            }
            return !0;
        }
        _durableClearReceipt(e) {
            if (!/^[A-Za-z0-9_-]{1,200}$/.test(e)) return null;
            let t = XM(e);
            return {
                primaryKey: t ? `${this.durableClearReceiptKeyPrefix}:high-water` : `${this.durableClearReceiptKeyPrefix}:${e}`,
                fallbackKey: `${this.durableClearReceiptKeyPrefix}:${e}`,
                requestId: e,
                sequence: t
            };
        }
        _receiptCovers(e, t) {
            if (!e.sequence) return t === e.requestId;
            let n = QM(t);
            return n ? .namespace === e.sequence.namespace && n.highWater >= e.sequence.highWater;
        }
        _nextReceiptValue(e, t) {
            if (!e.sequence) return e.requestId;
            let n = QM(t);
            return n ? .namespace === e.sequence.namespace && n.highWater >= e.sequence.highWater ? t : ZM(e.sequence);
        }
        clearAllStorage(e = J(this.store.getState().session)) {
            return YM(this.key), this.mutateSharedSession(e, () => this._clearAllStorage(), {});
        }
        _clearAllStorage() {
            if (this.clear(), this._removeSharedValue("greetingLease"), this._removeSharedValue(this.messagingAuthStateKey), this._removeZendeskVisitorKeys(), this.storageMode === "session" || this.storageMode === "private") return;
            let {
                handle: e
            } = this.store.getState().session;
        }
        async hasPersistedChatter(e) {
            let t = [
                    this.key,
                    this.legacyKey,
                    P,
                    $,
                    _N,
                    this.handoffStateKey,
                    L,
                    R,
                    "zdMessagingExternalUserId",
                    "zdMessagingChatterCreated"
                ],
                n = {
                    trackActivationProgress: !1,
                    adoptConfirmedSnapshot: !1
                },
                r = await this._readConfirmedSnapshot(t, e, n);
            if (r.kind === "unconfirmed" && (r = await this._readConfirmedSnapshot(t, e, n)), r.kind !== "snapshot") return !1;
            let i = this._assessAnonymousChatterIdentity(r.values[this.key] ? ? null, r.values[this.legacyKey] ? ? null, r.values.chatter ? ? null, {
                allowIdentityBound: !0
            });
            return i.kind === "candidate" ? !this._chatterExpiryWindowElapsedFromSnapshot(r, i.chatterToken) && !e.aborted : !1;
        }
        _persistedChatterToken() {
            return Q(this.storage.get(this.key)) ? .chatterToken ? ? Q(this.storage.get(this.legacyKey)) ? .chatterToken ? ? null;
        }
        _readPersistedSession(e) {
            let t = this.storage.get(this.key),
                n = this.storage.get(this.legacyKey),
                r = Q(t) ? ? Q(n),
                i = this._bindPersistedSessionAuth(r);
            if (i) return i;
            let a = t !== null || n !== null;
            return a && e ? .("messaging_blob"), this._resumesFromLegacyKeys(r) ? this._reconstructFromLegacySession(a ? void 0 : e) : null;
        }
        _resumesFromLegacyKeys(e) {
            return !this.handoffOnlyPersistence || e !== null;
        }
        _bindPersistedSessionAuth(e, t = this.storage.get(this.messagingAuthStateKey)) {
            if (!e) return null;
            let n = this._readMessagingAuthState(e.chatterToken, t);
            if (t && !n) return null;
            let r = Jo(JSON.stringify({
                    messagingToken: e.messagingToken,
                    messagingTokenExpiresAt: e.messagingTokenExpiresAt,
                    sessionRefreshToken: e.sessionRefreshToken,
                    refreshGeneration: e.refreshGeneration,
                    sessionCookieIssued: e.sessionCookieIssued,
                    language: e.language
                }), e.chatterToken),
                i = r && (!n || r.refreshGeneration > n.refreshGeneration) ? r : n;
            return i ? {
                ...e,
                messagingToken: i.messagingToken,
                messagingTokenExpiresAt: i.messagingTokenExpiresAt,
                sessionRefreshToken: i.sessionRefreshToken,
                refreshGeneration: i.refreshGeneration,
                sessionCookieIssued: i.sessionCookieIssued
            } : null;
        }
        async _restorePersistedSession(e, t = !1) {
            this.store.dispatch(ws({
                token: e.chatterToken,
                id: e.chatterId,
                sessionToken: e.sessionToken,
                sessionTokenExpiresAt: e.sessionTokenExpiresAt,
                sessionRefreshToken: e.sessionRefreshToken,
                messagingToken: e.messagingToken,
                messagingTokenExpiresAt: e.messagingTokenExpiresAt,
                refreshGeneration: e.refreshGeneration,
                sessionCookieIssued: e.sessionCookieIssued,
                language: t ? void 0 : e.language,
                identitySession: e.identitySession ? ? !0,
                suppressChatterAnnouncement: t
            })), q("chatter_restored"), this._pendingRestoredChatterToken = e.chatterToken;
        }
        _orphanedAuthRecoveryBlockedBy(e, t, n, r = !1) {
            if (this.storage.refresh && this.storage.conditionalWritesSupported !== !0) return "conditional_writes_unsupported";
            if (!t) return "baseline_missing";
            if (n[this.messagingAuthStateKey] !== t) return "baseline_changed";
            let i = pS({
                    confirmed: !0,
                    values: r ? {
                        ...n,
                        zdMessagingExternalUserId: null,
                        zdMessagingChatterCreated: null
                    } : n
                }, [this.key, this.legacyKey], [
                    this.handoffStateKey,
                    L,
                    R
                ], Q),
                a = this.store.getState(),
                o = i.owners.find((e) => e.kind === "auth");
            if (!o ? .chatterToken) return "auth_owner_missing";
            if (o.chatterToken === e.chatterToken) return "auth_owned_by_expected";
            if (o.chatterToken === a.session.chatterToken) return "auth_owned_by_current";
            if (i.inHandoff) return "handoff_stored";
            if (a.liveAgent.inLiveChat || a.liveAgent.inPending) return "handoff_local";
            if (I(n.zdMessagingExternalUserId) === o.chatterToken) return "zendesk_owner";
            if (i.owners.some((e) => e.kind !== "auth" && e.chatterToken === o.chatterToken)) return "owner_referenced";
        }
        async _createFreshSession(e, t, n, r, i) {
            let a = this.store.getState().session.chatterToken,
                o = [a, e].filter((e) => !!e),
                s, c = !1,
                l = await this.mutateSharedSession(n, () => {
                    i.staleAuthBaseline && this._updateSharedValues([this.messagingAuthStateKey], (e) => (c = !this._orphanedAuthRecoveryBlockedBy(n, i.staleAuthBaseline, e, i.discardStaleZdm), c ? {
                        [this.messagingAuthStateKey]: null
                    } : {})), this._clearOwnedBy(n.chatterToken), this._removeSharedValue("greetingLease"), this._removeZendeskVisitorKeys(), this._removeLegacyHandoffState();
                }, {
                    confirmedEnd: i.confirmedEnd,
                    discardStaleZdm: i.discardStaleZdm,
                    staleAuthBaseline: i.staleAuthBaseline,
                    onRefused: (e) => {
                        s = e;
                    },
                    endBaseline: r.baseline,
                    baseline: {
                        ...i.credentialBaseline,
                        ...i.discardStaleZdm ? {
                            zdMessagingExternalUserId: r.baseline.zdMessagingExternalUserId,
                            zdMessagingChatterCreated: r.baseline.zdMessagingChatterCreated
                        } : {}
                    },
                    isCurrent: () => {
                        let e = this.store.getState(),
                            i = lS(e.session);
                        return !t.aborted && e.liveAgent.inLiveChat === r.inLiveChat && e.liveAgent.inPending === r.inPending && e.session.chatterToken === a && (!i || i === n.credential);
                    }
                });
            if (l && c && q("chatter_orphaned_auth_discarded", {
                    path: i.restoreOnly ? "restore_only" : "fresh_session",
                    expired: !!i.discardStaleZdm
                }), !l || t.aborted) return t.aborted ? {
                kind: "aborted"
            } : {
                kind: "pre_create_refused",
                ...s ? {
                    refusal: s
                } : {}
            };
            if (this._pendingRestoredChatterToken = null, i.missingCredential && q("chatter_reconstruct_skipped_no_credential", {
                    path: i.restoreOnly ? "restore_only" : "fresh_session",
                    ...i.missingCredential
                }), i.restoreOnly) return {
                kind: "needsCreation"
            };
            try {
                await this.createChatter(t);
            } finally {
                this.store.dispatch(VT());
            }
            if (t.aborted) return {
                kind: "aborted"
            };
            let u = this.store.getState().session.chatterToken;
            if (!u) return {
                kind: "uncommitted"
            };
            if (await this._terminalClearsIdle(t), t.aborted || this.store.getState().session.chatterToken !== u) return {
                kind: t.aborted ? "aborted" : "uncommitted"
            };
            this._pendingChatterPersistenceCommit = {
                chatterToken: u,
                kind: "fresh",
                expected: n,
                previousChatterTokens: [...new Set(o)]
            };
            let d = this._pendingChatterPersistenceCommit,
                f = lS(this.store.getState().session),
                p = () => !t.aborted && this.store.getState().session.chatterToken === u && lS(this.store.getState().session) === f && this._pendingChatterPersistenceCommit === d && this._terminalClearsInProgress === 0 && !this._currentSessionIsClearing(),
                m = async (e) => {
                    let n;
                    return await this._applyPendingChatterPersistenceCommit(d, void 0, e === 1 ? void 0 : p, {
                        unconditional: e === 1,
                        onRefused: (e) => {
                            n = e;
                        }
                    }) ? {
                        kind: "created"
                    } : n ? .refusalGuard === "snapshot_unconfirmed" && p() && e < tN ? (q("chatter_restore_retried", {
                        attempt: e,
                        reason: "uncommitted",
                        ...n
                    }), m(e + 1)) : t.aborted ? {
                        kind: "aborted"
                    } : {
                        kind: "uncommitted",
                        ...n ? {
                            refusal: n
                        } : {}
                    };
                };
            return m(1);
        }
        _readMessagingAuthState(e, t = this.storage.get(this.messagingAuthStateKey)) {
            return e ? Jo(t, e) : Bo(t);
        }
        _saveMessagingAuthState({
            chatterToken: e,
            messagingToken: t,
            messagingTokenExpiresAt: n,
            sessionRefreshToken: r,
            sessionCookieIssued: i,
            refreshGeneration: a
        }) {
            if (!r) return;
            if (!t || typeof n != "number" || !Number.isFinite(n) || n <= 0) {
                this._removeMessagingAuthStateIfOwned(e);
                return;
            }
            if (typeof a != "number" || !Number.isInteger(a) || a < 1) {
                this._removeMessagingAuthStateIfOwned(e);
                return;
            }
            let o = {
                ownerChatterToken: e,
                messagingToken: t,
                messagingTokenExpiresAt: n,
                sessionRefreshToken: r,
                sessionCookieIssued: i,
                refreshGeneration: a
            };
            Wo(t, e) && this._setSharedValue(this.messagingAuthStateKey, JSON.stringify(o));
        }
        _removeMessagingAuthStateIfOwned(e, t, n) {
            if (!e) return;
            let r = Jo(n === void 0 ? this.storage.get(this.messagingAuthStateKey) : n, e);
            r && (typeof t == "number" && r.refreshGeneration > t || this._removeSharedValue(this.messagingAuthStateKey));
        }
        async clearDeadMessagingCredential(e, t, n) {
            if (typeof t != "number") return !1;
            let r = {
                ...J(this.store.getState().session),
                chatterToken: e,
                sessionToken: this.store.getState().session.sessionToken ? ? Q(this.storage.get(this.key)) ? .sessionToken ? ? I(this.storage.get("sessionToken"))
            };
            n ? .(r.sessionToken), this._terminalClearsInProgress += 1, this._terminalClearSessions.push(r), this._sessionSaveDeferredBackoffKind = this._cancelSessionSaveBackoff() ? ? this._sessionSaveDeferredBackoffKind;
            try {
                return !await this.mutateSharedSession(r, () => this._removeSharedValue(this.messagingAuthStateKey), {
                    maxRefreshGeneration: t,
                    operation: "terminal_clear",
                    credentialOnly: !0
                }) || await this.storage.flush ? .([this.messagingAuthStateKey]) === !1 ? !1 : (zM(), !0);
            } finally {
                this._finishTerminalClear();
            }
        }
        async getConfirmedHandoff(e) {
            let t = [this.key, this.legacyKey],
                n = [
                    this.handoffStateKey,
                    L,
                    R
                ],
                r = [
                    ...t,
                    ...n,
                    "zdMessagingExternalUserId",
                    "zdMessagingChatterCreated",
                    "zdMessagingGeneration",
                    this.messagingAuthStateKey,
                    P,
                    F
                ];
            try {
                let e = await this.storage.getConfirmed ? .(r);
                return !e || !r.every((t) => t in e.values) ? {
                    confirmed: !1,
                    coherent: !1,
                    owners: [],
                    inHandoff: !0
                } : pS(e, t, n, Q);
            } catch {
                return {
                    confirmed: !1,
                    coherent: !1,
                    owners: [],
                    inHandoff: !0
                };
            }
        }
        async clearEndedExchangeHandoff(e, t, n, r) {
            let i = !1,
                a = !1,
                o = this._zdmTarget(),
                s, c = (e) => (q("messaging_exchange_handoff_clear", {
                    outcome: e,
                    committed: i
                }), e),
                l = () => {
                    let e = J(this.store.getState().session);
                    return e.chatterToken === t.session.chatterToken && e.sessionToken === t.session.sessionToken && e.credential === t.session.credential;
                },
                u = () => !n ? .aborted && this.isCurrentPersistence(this),
                d = () => u() && l() && this.store.getState().liveAgent.inLiveChat === t.inLiveChat && this.store.getState().liveAgent.inPending === t.inPending;
            this._terminalClearsInProgress += 1, this._terminalClearSessions.push(e), this._sessionSaveDeferredBackoffKind = this._cancelSessionSaveBackoff() ? ? this._sessionSaveDeferredBackoffKind;
            try {
                if (o && o !== this) try {
                    s = Object.fromEntries([...Object.keys(t.baseline), ...Object.keys(t.credentialBaseline)].map((e) => [e, o.storage.get(e)]));
                } catch {
                    return c(u() ? "unconfirmed" : "aborted");
                }
                if (i = await this.mutateSharedSession(e, () => {
                        this._removeHandoffState(), this._removeLegacyHandoffState();
                    }, {
                        confirmedEnd: !0,
                        endBaseline: t.baseline,
                        baseline: t.credentialBaseline,
                        operation: "terminal_clear",
                        isCurrent: d
                    }), i) {
                    if (await this.storage.flush ? .([
                            this.handoffStateKey,
                            "inLiveChat",
                            "liveChatPending",
                            "zdMessagingExternalUserId",
                            "zdMessagingChatterCreated",
                            "zdMessagingGeneration"
                        ]) === !1) return c("unconfirmed");
                    if (!d()) return c(u() ? "superseded" : "aborted");
                    if (o && o !== this) {
                        if (!await o.mutateSharedSession(e, () => {
                                o._removeSharedValue("zdMessagingExternalUserId"), o._removeSharedValue("zdMessagingChatterCreated"), o._removeSharedValue("zdMessagingGeneration");
                            }, {
                                confirmedEnd: !0,
                                endBaseline: s,
                                operation: "terminal_clear",
                                isCurrent: () => d() && this._zdmTarget() === o
                            })) {
                            if (u() && this._zdmTarget() === o) try {
                                await o.storage.refresh ? .(Object.keys(s ? ? {}));
                            } catch {}
                            return d() ? c("unconfirmed") : c(u() ? "superseded" : "aborted");
                        }
                        if (await o.storage.flush ? .([
                                "zdMessagingExternalUserId",
                                "zdMessagingChatterCreated",
                                "zdMessagingGeneration"
                            ]) === !1) return c("unconfirmed");
                    }
                    return d() ? (r ? .(), this.store.dispatch(pD({
                        keepPageLatch: !0
                    })), zM(), a = !0, c("cleared")) : c(u() ? "superseded" : "aborted");
                }
                let l = [...Object.keys(t.baseline), ...Object.keys(t.credentialBaseline)],
                    f;
                try {
                    f = this.storage.getConfirmed ? await this.storage.getConfirmed(l) : {
                        confirmed: !0,
                        values: Object.fromEntries(l.map((e) => [e, this.storage.get(e)]))
                    };
                } catch {
                    f = void 0;
                }
                if (!n ? .aborted && this.isCurrentPersistence(this)) try {
                    await this.storage.refresh ? .(l);
                } catch {}
                if (n ? .aborted || !this.isCurrentPersistence(this)) return c("aborted");
                if (!d()) return c("superseded");
                if (!f ? .confirmed || f.coherent === !1 || !l.every((e) => e in f.values)) return c("unconfirmed");
                let p = {
                        ...t.credentialBaseline,
                        zdMessagingExternalUserId: t.baseline.zdMessagingExternalUserId
                    },
                    m = (e) => pS({
                        confirmed: !0,
                        values: Object.fromEntries(Object.keys(p).map((t) => [t, e[t]]))
                    }, [this.key, this.legacyKey], [], Q).owners,
                    h = m(p);
                return m(f.values).some((e, t) => {
                    let n = h[t];
                    return e.chatterToken !== n.chatterToken || e.sessionToken !== n.sessionToken || e.credential !== n.credential;
                }) ? c("superseded") : c("unconfirmed");
            } finally {
                if (i && !a) {
                    let n = [{
                        service: this,
                        baseline: t.baseline
                    }];
                    o && o !== this && s && n.push({
                        service: o,
                        baseline: s
                    }), await Promise.all(n.map(async ({
                        service: t,
                        baseline: n
                    }) => {
                        try {
                            let r = [
                                    "zdMessagingExternalUserId",
                                    "zdMessagingChatterCreated",
                                    "zdMessagingGeneration"
                                ].filter((e) => n[e] != null),
                                i = t.storage.getConfirmed ? await t.storage.getConfirmed(r) : {
                                    confirmed: !0,
                                    values: Object.fromEntries(r.map((e) => [e, t.storage.get(e)]))
                                };
                            if (!i.confirmed) return;
                            let a = r.filter((e) => i.values[e] === null);
                            if (a.length === 0) return;
                            await t.mutateSharedSession(e, () => {
                                t._updateSharedValues(a, (e) => Object.fromEntries(a.map((t) => [t, e[t] ? ? n[t]])));
                            }, {
                                preservesHandoff: !0
                            });
                        } catch {}
                    }));
                }
                this._finishTerminalClear();
            }
        }
        async clearDeadResumedSession(e, t, n, r) {
            let i = this.store.getState().session,
                a = t ? ? {
                    ...J(i),
                    chatterToken: e
                },
                o = t ? Object.fromEntries([
                    this.key,
                    this.legacyKey,
                    this.messagingAuthStateKey
                ].map((e) => [e, this.storage.get(e)])) : void 0,
                s = !1,
                c = !1;
            if (o) {
                let e = [Q(o[this.key]), Q(o[this.legacyKey])],
                    t = lS(this._readMessagingAuthState(a.chatterToken ? ? void 0, o[this.messagingAuthStateKey]));
                c = J(i).credential === a.credential && (!t || t === a.credential) && e.some((e) => {
                    let t = lS(e);
                    return t && t !== a.credential;
                }) && !e.some((e) => {
                    let t = lS(e);
                    return t && t !== a.credential && !(i.refreshGeneration !== null && Number.isSafeInteger(i.refreshGeneration) && i.refreshGeneration > 0 && e ? .refreshGeneration != null && Number.isSafeInteger(e.refreshGeneration) && e.refreshGeneration > 0 && e.refreshGeneration < i.refreshGeneration && e.chatterToken === a.chatterToken && a.sessionToken && e.sessionToken === a.sessionToken);
                });
            }
            this._clearingSession = a, this._terminalClearsInProgress += 1, this._terminalClearSessions.push(a), this._sessionSaveDeferredBackoffKind = this._cancelSessionSaveBackoff() ? ? this._sessionSaveDeferredBackoffKind;
            try {
                return await this.mutateSharedSession(a, (t) => {
                    r && this._updateSharedValues([this.messagingAuthStateKey], (e) => (s = !this._orphanedAuthRecoveryBlockedBy(a, r, e), s ? {
                        [this.messagingAuthStateKey]: null
                    } : {})), this._clearOwnedBy(e, t ? .values[this.messagingAuthStateKey]), this._removeSharedValue("greetingLease"), this._removeZendeskVisitorKeys();
                }, {
                    operation: "terminal_clear",
                    staleAuthBaseline: r,
                    baseline: c ? o : void 0,
                    rejectChangedCredential: !!t && !c,
                    isCurrent: () => {
                        let e = this.store.getState().session,
                            r = lS(e);
                        return !n ? .aborted && e.chatterToken === i.chatterToken && (!t || !r || r === a.credential);
                    }
                }) ? (s && q("chatter_orphaned_auth_discarded", {
                    path: "dead_session_auth",
                    expired: !1
                }), await this.storage.flush ? .(this._clearAllStorageWriteKeys()) !== !1 && !n ? .aborted && this._currentSessionIsClearing() ? (this.stopTokenSync(), zM(), !0) : !1) : !1;
            } finally {
                this._clearingSession === a && (this._clearingSession = null), this._finishTerminalClear();
            }
        }
        _terminalClearsIdle(e) {
            return e ? .aborted || this._terminalClearsInProgress === 0 ? Promise.resolve() : new Promise((t) => {
                let n = () => {
                    let r = this._terminalClearsIdleResolvers.indexOf(n);
                    r !== -1 && this._terminalClearsIdleResolvers.splice(r, 1), e ? .removeEventListener("abort", n), t();
                };
                this._terminalClearsIdleResolvers.push(n), e ? .addEventListener("abort", n, {
                    once: !0
                });
            }).then(() => this._terminalClearsIdle(e));
        }
        _finishTerminalClear() {
            if (--this._terminalClearsInProgress, this._terminalClearsInProgress === 0) {
                let {
                    inLiveChat: e,
                    inPending: t
                } = this.store.getState().liveAgent;
                this._storeUnsubscribe && (e || t || this._lastSavedHandoffState !== null) && this._saveHandoffStateIfChanged();
                let n = this._sessionSaveDeferredBackoffKind;
                this._sessionSaveDeferredBackoffKind = null;
                let r = this._terminalClearSessions.splice(0),
                    i = J(this.store.getState().session);
                for (let e of this._terminalClearsIdleResolvers.splice(0)) e();
                n !== null && this._sessionSaveRequested && this._storeUnsubscribe && !this._sessionSaveInFlight && this._sessionSaveBackoffTimer === null && !r.some((e) => e.chatterToken === i.chatterToken && e.sessionToken === i.sessionToken && e.credential === i.credential) && this._scheduleSessionSaveBackoff(this._tokenSyncEpoch, n);
            }
        }
        _currentSessionIsClearing() {
            let e = this.store.getState().session;
            return this._clearingSession !== null && this._clearingSession.chatterToken === e.chatterToken && this._clearingSession.sessionToken === e.sessionToken;
        }
        _reconstructFromLegacySession(e) {
            let t = I(this.storage.get(P));
            if (!t) return null;
            let n = this.storage.get(this.messagingAuthStateKey),
                r = this._readMessagingAuthState(t, n);
            return r ? (q("chatter_reconstructed_from_legacy"), {
                version: 1,
                chatterId: "",
                chatterToken: t,
                sessionToken: I(this.storage.get(F)),
                sessionTokenExpiresAt: null,
                sessionRefreshToken: r.sessionRefreshToken,
                messagingToken: r.messagingToken,
                messagingTokenExpiresAt: r.messagingTokenExpiresAt,
                refreshGeneration: r.refreshGeneration,
                sessionCookieIssued: r.sessionCookieIssued,
                identitySession: !1
            }) : (e ? .("legacy_mirror"), null);
        }
        _mirrorLegacySessionKeys(e, t) {
            this._setSharedValue(P, JSON.stringify(e)), t && this._setSharedValue(F, JSON.stringify(t));
            let n = Date.now();
            this._updateSharedValues([$, _N], (e) => e.created ? {
                [$]: e[$],
                [_N]: e.messagingCreatedClock ? ? null
            } : {
                [$]: JSON.stringify(String(n)),
                [_N]: uN("plain", n)
            });
        }
        _removeLegacyHandoffState() {
            for (let e of [
                    L,
                    R,
                    "zdMessagingExternalUserId",
                    "zdMessagingChatterCreated",
                    "zdMessagingGeneration"
                ]) this._removeSharedValue(e);
        }
        _removeLegacySessionKeys() {
            this._removeSharedValue(P), this._removeSharedValue($), this._removeSharedValue(_N), this._removeSharedValue(F);
        }
        _removeHandoffState() {
            this._removeSharedValue(this.handoffStateKey), this._afterSharedCommit(() => {
                this._lastSavedHandoffState = null;
            });
        }
        _scheduleHandoffOnlyWipe() {
            this._handoffOnlyWipeTimer !== null || this._handoffOnlyWipe === "done" || this._handoffOnlyWipe === "pending" || this._handoffOnlyWipeExhausted() || (this._handoffOnlyWipeTimer = setTimeout(() => {
                if (this._handoffOnlyWipeTimer = null, !(!this._storeUnsubscribe || !this._persistenceSuppressed() || this._pendingRestoredChatterToken !== null)) try {
                    this._removeHandoffOnlyPersistence();
                } catch (e) {
                    this._handoffOnlyWipe !== "pending" && (this._handoffOnlyWipe = "pending", this._handoffOnlyWipeAttempts += 1), pN.warn("handoff-only wipe failed", {
                        stage: "probe",
                        thrown: mN(e),
                        attempts: this._handoffOnlyWipeAttempts
                    }), this._handoffOnlyWipeUnacknowledged("threw");
                }
            }, hN));
        }
        _handoffPersistenceResumed() {
            this._handoffOnlyWipeTimer === null && this._handoffOnlyWipe === "armed" && this._handoffOnlyWipeAttempts === 0 || (this._handoffOnlyWipeTimer !== null && (clearTimeout(this._handoffOnlyWipeTimer), this._handoffOnlyWipeTimer = null), this._handoffOnlyWipe = "armed", this._handoffOnlyWipeAttempts = 0, this._handoffOnlyWipeGeneration += 1);
        }
        _handoffOnlyWipeExhausted() {
            return this._handoffOnlyWipe === "retry" && this._handoffOnlyWipeAttempts >= 3;
        }
        _handoffOnlyWipeKeys() {
            let e = I(this.storage.get(P));
            e && e === this.store.getState().session.chatterToken && this._afterSharedCommit(() => {
                this._handoffOnlyOwnsMirrors = !0;
            });
            let t = [
                P,
                $,
                F
            ];
            return [
                "greetingLease",
                ...this._conversationClearWriteKeys().filter((e) => this._handoffOnlyOwnsMirrors || !t.includes(e)),
                ...this.store.getState().liveAgent.handoffOpenedThisPage ? [] : [kN(this.handle), DN(this.handle)]
            ];
        }
        _removeHandoffOnlyPersistence() {
            if (!(this._handoffOnlyWipe === "pending" || this._handoffOnlyWipe === "done" || this._handoffOnlyWipeExhausted())) {
                if (this._handoffOnlyWipe === "armed" && !this._handoffOnlyOwnsMirrors && [
                        "greetingLease",
                        this.key,
                        this.pendingResetKey,
                        this.legacyKey,
                        this.messagingAuthStateKey,
                        this.readStateKey,
                        this.handoffStateKey,
                        "messagingCreatedClock",
                        kN(this.handle),
                        DN(this.handle)
                    ].every((e) => this.storage.hydrated ? .([e]) !== !1 && this.storage.get(e) === null)) {
                    this._handoffOnlyWipe = "done";
                    return;
                }
                this._issueHandoffOnlyRemovals(this._handoffOnlyWipeKeys());
            }
        }
        _resetHandoffOnlySaveCursors() {
            this._tokenSyncEpoch += 1, this._resetSessionSaveConflictState(), this._sessionSaveInFlight = !1, this._sessionSaveRequested = !1, this._lastSavedHandoffState = !1, this._lastSavedReadState = null, this._pendingReadState = null, this._lastRefusedReadState = null, this._lastSavedChatterToken = null, this._lastSavedMessagingToken = null, this._lastSavedRefreshToken = null, this._lastSavedRefreshGeneration = null, this._lastSavedLanguage = null;
        }
        _issueHandoffOnlyRemovals(e) {
            this._handoffOnlyWipe = "pending", this._handoffOnlyWipeAttempts += 1;
            let t = ++this._handoffOnlyWipeGeneration;
            try {
                let n = this.mutateSharedSession(J(this.store.getState().session), () => {
                    for (let t of e) this._removeSharedValue(t);
                    this._afterSharedCommit(() => this._resetHandoffOnlySaveCursors());
                }, this._handoffEndWriteOptions());
                if (n instanceof Promise) {
                    n.then((n) => n ? this._acknowledgeHandoffOnlyRemovals(e, t) : this._handoffOnlyWipeUnacknowledged("refused"));
                    return;
                }
                if (!n) {
                    this._handoffOnlyWipeUnacknowledged("refused");
                    return;
                }
            } catch (e) {
                pN.warn("handoff-only wipe failed", {
                    stage: "issue",
                    thrown: mN(e),
                    attempts: this._handoffOnlyWipeAttempts
                }), this._handoffOnlyWipeUnacknowledged("threw");
                return;
            }
            this._acknowledgeHandoffOnlyRemovals(e, t);
        }
        _acknowledgeHandoffOnlyRemovals(e, t) {
            Promise.resolve(this.storage.flush ? .(e) ? ? !0).then((e) => {
                if (t === this._handoffOnlyWipeGeneration) {
                    if (e) {
                        this._handoffOnlyWipe === "pending" && (this._handoffOnlyWipe = "done", this._handoffOnlyOwnsMirrors = !1);
                        return;
                    }
                    this._handoffOnlyWipeUnacknowledged("refused");
                }
            }, () => {
                t === this._handoffOnlyWipeGeneration && this._handoffOnlyWipeUnacknowledged("rejected");
            });
        }
        _handoffOnlyWipeUnacknowledged(e) {
            this._handoffOnlyWipe === "pending" && (this._handoffOnlyWipe = "retry");
            let t = this._handoffOnlyWipeAttempts;
            if (this._handoffOnlyWipeFailureReported || (this._handoffOnlyWipeFailureReported = !0, pN.warn("handoff-only wipe not acknowledged", {
                    reason: e,
                    attempts: t
                }), q("handoff_only_wipe_flush_failed", {
                    reason: e
                })), this._handoffOnlyWipeExhausted()) {
                pN.warn("handoff-only wipe exhausted", {
                    reason: e,
                    attempts: t
                }), q("handoff_only_wipe_exhausted", {
                    reason: e
                });
                return;
            }
            this._handoffOnlyWipe === "retry" && this._storeUnsubscribe && this._persistenceSuppressed() && this._scheduleHandoffOnlyWipe();
        }
        async _fetchRecentConversation(e) {
            let {
                endpoint: t
            } = this.store.getState().session;
            if (!t) return {
                ok: !1
            };
            try {
                let n = await this.store.dispatch(wI.endpoints.getRecentConversation.initiate({
                    endpoint: t,
                    chatterToken: e
                }, {
                    forceRefetch: !0,
                    subscribe: !1
                }));
                return "error" in n || !n.data ? {
                    ok: !1
                } : {
                    ok: !0,
                    conversationIds: n.data.conversationIds,
                    activeHandoff: n.data.activeHandoff,
                    activeCapture: n.data.activeCapture,
                    conversationEnded: n.data.conversationEnded,
                    activeListSelection: n.data.activeListSelection,
                    widgetAppPending: n.data.widgetAppPending
                };
            } catch {
                return {
                    ok: !1
                };
            }
        }
    },
    $ = "created",
    _N = "messagingCreatedClock";

function vN(e) {
    if (!e) return null;
    let t;
    try {
        t = JSON.parse(e);
    } catch {
        return null;
    }
    if (typeof t != "number" && typeof t != "string") return null;
    let n = Number(t);
    return Number.isFinite(n) && n > 0 ? n : null;
}

function yN(e, t, n) {
    return `ada:${e}:${Xo(t, n)}:read`;
}
var bN = "ada:legacy-handoff-observed";

function xN(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e);
        if (!t || typeof t != "object") return null;
        let {
            value: n,
            seenAt: r
        } = t;
        return typeof n != "boolean" || typeof r != "number" || !Number.isFinite(r) || r <= 0 ? null : {
            value: n,
            seenAt: r
        };
    } catch {
        return null;
    }
}
var SN = "liveChatTransition";

function CN(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e);
        if (!t || typeof t != "object") return null;
        let {
            open: n,
            at: r
        } = t;
        return typeof n != "boolean" || typeof r != "number" || !Number.isFinite(r) || r <= 0 ? null : {
            open: n,
            at: r
        };
    } catch {
        return null;
    }
}

function wN(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e);
        if (typeof t != "object" || !t) return null;
        let n = {};
        for (let [e, r] of Object.entries(t)) typeof r == "string" && r.length > 0 && (n[e] = r);
        return n;
    } catch {
        return null;
    }
}

function TN(e) {
    return `ada-user-theme-${e}`;
}

function EN(e) {
    return `ada-user-text-size-${e}`;
}

function DN(e) {
    return `ada-zd-previous-tags-${e}`;
}

function ON(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e);
        if (Array.isArray(t) && t.every((e) => typeof e == "string")) return t.length > 0 ? t : null;
    } catch {}
    return null;
}

function kN(e) {
    return `ada-zd-session-${e}`;
}

function AN(e) {
    if (!e) return null;
    try {
        let t = JSON.parse(e);
        if (t && typeof t == "object" && !Array.isArray(t)) {
            let e = t,
                n = (t) => typeof e[t] == "string" && e[t] ? e[t] : null,
                r = n("zdSessionId"),
                i = n("zdCStore"),
                a = n("zdCid"),
                o = n("zdSetupComplete");
            if (r || i || a) return {
                zdSessionId: r,
                zdCStore: i,
                zdCid: a,
                zdSetupComplete: o,
                ...n("zdAuthSessionId") ? {
                    zdAuthSessionId: n("zdAuthSessionId")
                } : {},
                ...n("zdUsesJwtAuth") ? {
                    zdUsesJwtAuth: n("zdUsesJwtAuth")
                } : {}
            };
        }
    } catch {}
    return null;
}

function jN(e, t, n) {
    return `ada-session-mirror:${e}:${Xo(t, n)}`;
}

function MN(e) {
    return `${e}:generation`;
}

function NN(e, t, n) {
    let r = jN(e, t, n);
    return new Set([
        Zo(e, t, n),
        $o(e),
        Ro,
        P,
        F,
        $,
        _N,
        yN(e, t, n),
        es(e, t, n),
        kN(e),
        DN(e),
        bN,
        L,
        R,
        SN,
        "liveChatRevision",
        "zdMessagingExternalUserId",
        "zdMessagingChatterCreated",
        "zdMessagingGeneration",
        MN(r)
    ]);
}

function PN(e, t, n) {
    return [
        "greetingLease",
        Zo(e, t, n),
        `${Zo(e, t, n)}:pending-reset`,
        $o(e),
        yN(e, t, n),
        es(e, t, n),
        bN,
        SN,
        "liveChatRevision",
        Ro,
        P,
        $,
        _N,
        F,
        L,
        R,
        kN(e),
        "zdMessagingExternalUserId",
        "zdMessagingChatterCreated",
        "zdMessagingGeneration",
        DN(e),
        MN(jN(e, t, n))
    ];
}

function FN(e, t, n) {
    return [
        Zo(e, t, n),
        $o(e),
        Ro,
        P,
        F,
        $,
        _N,
        es(e, t, n),
        L,
        R,
        "zdMessagingExternalUserId",
        "zdMessagingChatterCreated",
        "zdMessagingGeneration"
    ];
}

function IN(e, t, n, r) {
    return [
        "greetingLease",
        Zo(e, t, n),
        `${Zo(e, t, n)}:pending-reset`,
        $o(e),
        Ro,
        yN(e, t, n),
        es(e, t, n),
        _N,
        kN(e),
        DN(e),
        ...r.mirrors ? [
            P,
            $,
            F
        ] : []
    ];
}

function LN(e) {
    return e === "light" || e === "dark" || e === "auto" ? e : null;
}

function RN(e) {
    return e === "small" || e === "default" || e === "large" ? e : null;
}
async function zN(e, t, n, r = {}) {
    let i = (r.mode ? [r.mode] : ["normal", "session"]).map((i) => {
        let a = Hx(i),
            o = [Zo(e, t, n), $o(e)];
        (r.clearMessagingAuthState || r.chatterToken && Jo(a.get("messagingAuthState"), r.chatterToken)) && o.push(Ro);
        let s = a.getConfirmedSync ? .(o);
        return s ? .confirmed && o.every((e) => s.values[e] === null) ? !0 : gN.clearStorageKeys(a, {
            handle: e,
            endpoint: t,
            cluster: n
        }, o, {
            explicitReset: !0,
            expected: r.expected,
            ownedKeysOnly: !0
        });
    });
    return (await Promise.all(i)).every(Boolean);
}
async function BN(e, t, n) {
    let r = ["normal", "session"].map((r) => gN.clearStorageKeys(Hx(r), {
        handle: e,
        endpoint: t,
        cluster: n
    }, [
        Zo(e, t, n),
        $o(e),
        Ro,
        kN(e),
        DN(e),
        yN(e, t, n),
        es(e, t, n),
        P,
        $,
        _N,
        F
    ], {}));
    return (await Promise.all(r)).every(Boolean);
}
//#endregion
//#region src/orchestrator-zendesk-chat-events.ts
var VN = 1e3,
    HN = 10,
    UN = 1e3,
    WN = 1.5,
    GN = 6e4,
    KN = 6e4,
    qN = 1e3,
    JN = new Set([
        408,
        429,
        503,
        504
    ]),
    YN = new Set([
        "live_chat_disconnected",
        "live_chat_init_failure",
        "live_chat_chatter_banned",
        "live_chat_idle_disconnect",
        "live_chat_end_conversation"
    ]),
    XN = "live_chat_inactive_probe",
    ZN = "Chat is no longer active in Zendesk.",
    QN = new Set(["live_chat_reconnected", "live_chat_queue_position"]),
    $N = new Set(["live_chat_message", "live_chat_file_message"]),
    eP = new Set(["live_chat_presence", ...$N]),
    tP = new Set([
        "election_unavailable",
        "owner_connection_failed",
        "relay_failed",
        "delivery_unknown"
    ]),
    nP = /* @__PURE__ */ new WeakMap();

function rP(e, t) {
    let n = e.getState(),
        r = n.liveAgent.zendesk.primarySessionId,
        i = n.session.conversationId;
    if (!r || !i || t === null) {
        nP.delete(e);
        return;
    }
    nP.set(e, {
        primarySessionId: r,
        conversationId: i,
        operationSeq: n.liveAgent.zendeskOperationSeq,
        ...t !== void 0 && Number.isSafeInteger(t) && t > 0 ? {
            stateGeneration: t
        } : {}
    });
}

function iP(e, t) {
    let n = e.getState(),
        r = nP.get(e),
        i = n.liveAgent.zendeskOperationSeq,
        a = (n.liveAgent.inLiveChat || n.liveAgent.inPending) && n.liveAgent.platformName === "zendesk_liveagent" && (n.liveAgent.zendesk.primarySessionId ? ? r ? .primarySessionId) === r ? .primarySessionId;
    !r || r.operationSeq !== t || i !== t + 1 || r.conversationId !== n.session.conversationId || !a || !n.liveAgent.zendesk.fatalRequestErrorReached || n.liveAgent.zendesk.fatalRequestErrorPending || !n.liveAgent.zendesk.fatalRequestErrorCancelFailed || nP.set(e, {
        ...r,
        operationSeq: i
    });
}

function aP(e) {
    let t = W(e);
    if (!t || G(t.integration) !== "zendesk" || G(t.frameId) !== "zendesk") return null;
    let n = G(t.event);
    return n ? {
        event: n,
        payload: W(t.payload) ? ? {},
        relayed: t.source === "cross_tab_relay"
    } : null;
}
var oP = [
    "zdSessionId",
    "zdCStore",
    "zdCid",
    "zdSetupComplete",
    "zdUsesJwtAuth",
    "zdAuthSessionId"
];

function sP(e, t) {
    let n = oP.filter((e) => Object.hasOwn(t, e));
    if (n.length === 0) return;
    let r = e.getState().session.handle;
    if (!r) return;
    let i = oS();
    if (!i) return;
    let a = kN(r),
        o = i.update ? .(a, (e) => {
            let r = AN(e) ? ? {
                zdSessionId: null,
                zdCStore: null,
                zdCid: null,
                zdSetupComplete: null
            };
            for (let e of n) r[e] = G(t[e]) ? ? null;
            return r.zdSessionId || r.zdCStore || r.zdCid ? JSON.stringify(r) : null;
        });
    Promise.resolve(o).then(async (e) => {
        e && await i.flush ? .([a]) !== !1 && zM();
    });
}

function cP(e, t) {
    let n = e.endsWith("/") ? e : `${e}/`;
    return new URL(t, n).toString();
}

function lP(e, t) {
    let n = e.getState(),
        {
            chatterToken: r,
            sessionId: i
        } = n.session;
    if (!r || !i) return null;
    let a = G(t.zd_session) ? ? n.liveAgent.zendesk.sessionId;
    return !a && t.type !== "live_chat_queue_position" ? null : {
        ...t,
        by: G(t.by) ? ? r,
        chat_session: G(t.chat_session) ? ? i,
        zd_session: a
    };
}

function uP(e) {
    let t = e.getState(),
        n = t.liveAgent.zendesk.primarySessionId,
        r = t.session.sessionId;
    return !!(n && r && n !== r);
}

function dP(e) {
    let t = W(e);
    return t ? W(t.data) ? ? t : null;
}
async function fP(e) {
    e <= 0 || await new Promise((t) => setTimeout(t, e));
}

function pP(e) {
    return Math.random() * Math.min(GN, UN * WN ** e);
}

function mP(e) {
    return e instanceof TypeError || typeof e == "object" && !!e && "name" in e && e.name === "AbortError";
}
var hP = class extends Error {
        constructor() {
            super("Zendesk handoff request was superseded"), this.name = "ZendeskHandoffSupersededError";
        }
    },
    gP = class extends Error {
        constructor(e) {
            super(`Request failed with status ${e}`), j(this, "status", void 0), this.status = e;
        }
    };

function _P(e) {
    if (!e()) throw new hP();
}
async function vP(e, t, n, r, i, a, o) {
    _P(i);
    let s = new AbortController(),
        c = globalThis.setTimeout(() => s.abort(), KN);
    try {
        let c = await bT(r, {
            ...n,
            url: t,
            signal: s.signal,
            timeoutMs: KN
        }, {
            fetchFn: e,
            isCurrent: a,
            initiatingSession: o
        });
        return _P(i), c;
    } finally {
        globalThis.clearTimeout(c);
    }
}
var yP = /* @__PURE__ */ new WeakMap();

function bP(e, t, n, r) {
    let i = () => {
        let {
            liveAgent: t
        } = e.getState();
        return n() && !t.hasConversationEnded && !t.zendesk.chatClosed && !t.zendesk.fatalRequestErrorReached && (t.platformName === "zendesk_liveagent" || t.platformName === null) && (t.inLiveChat || t.inPending);
    };
    if (!i() || e.getState().liveAgent.platformName !== "zendesk_liveagent" || e.getState().liveAgent.zendesk.webhookRetryMessageKey || ![
            "live_chat_connecting",
            "live_chat_queue_position",
            ...$N
        ].includes(String(t))) return;
    e.dispatch(Z({
        webhookRetryMessageKey: "TRYING_TO_CONNECT_YOU_WITH_AN_AGENT"
    }));
    let a = [],
        o = () => {
            for (let e of a) clearTimeout(e);
            s(), r ? .removeEventListener("abort", o), yP.delete(e);
        },
        s = e.subscribe(() => {
            (!i() || !e.getState().liveAgent.zendesk.webhookRetryMessageKey) && o();
        });
    for (let [t, n] of ["STILL_TRYING_AGENT_CONNECTION", "AGENT_CONNECTION_IS_TAKING_LONGER_THAN_USUAL"].entries()) a.push(setTimeout(() => {
        i() && e.getState().liveAgent.zendesk.webhookRetryMessageKey && e.dispatch(Z({
            webhookRetryMessageKey: n
        })), (t === 1 || !i()) && o();
    }, (t + 1) * 3e4));
    yP.set(e, o), r ? .addEventListener("abort", o, {
        once: !0
    });
}
async function xP(e, t, n, r, i, a, o, s, c, l) {
    let u = null;
    for (let d = 1; d <= HN; d++) {
        let f = () => a() || l();
        _P(f);
        let p;
        try {
            let o = await vP(t, n, r, e, f, s, c);
            if (o.ok) return a() && r.method === "POST" && (yP.get(e) ? .(), $N.has(String(i.type)) && e.getState().liveAgent.zendesk.webhookRetryMessageKey && e.dispatch(Z({
                webhookRetryMessageKey: null
            }))), o;
            if (u = new gP(o.status), !JN.has(o.status)) break;
            p = {
                status: o.status
            };
        } catch (e) {
            if (e instanceof hP) throw e;
            if (u = e, !mP(e)) break;
            p = {
                error: e instanceof Error ? e.message : String(e)
            };
        }
        if (d >= HN) break;
        q("zendesk_webhook_post_retry", {
            ...i,
            attempt: d,
            ...p
        }), r.method === "POST" && bP(e, i.type, a, o), await fP(pP(d)), _P(f);
    }
    throw u instanceof Error ? u : Error(String(u ? ? "Zendesk webhook request failed"));
}
async function SP(e, t, n, r, i, a, o, s = () => !1) {
    let c = r.bindLifecycleSignal === !1 ? null : _r(),
        l = vr(),
        u = a.liveAgent.zendeskOperationSeq,
        d = a.session.chatterToken,
        f = a.session.conversationId,
        p = () => {
            let t = e.getState();
            return !c ? .aborted && t.liveAgent.zendeskOperationSeq === u && t.session.chatterToken === d && t.session.sessionToken === a.session.sessionToken && t.session.conversationId === f;
        },
        m = () => !l ? .aborted && p(),
        h = i.type === "live_chat_end_conversation" ? () => !0 : () => p() || s(),
        g = nP.get(e),
        _ = g ? .operationSeq === u && g.primarySessionId === a.liveAgent.zendesk.primarySessionId && g.conversationId === a.session.conversationId ? g.stateGeneration : void 0,
        v = a.liveAgent.zendesk.primarySessionId && d && a.session.conversationId ? {
            primarySessionId: a.liveAgent.zendesk.primarySessionId,
            conversationId: a.session.conversationId,
            ..._ === void 0 ? {} : {
                stateGeneration: _
            }
        } : null;
    try {
        return await xP(e, t, n, r, i, m, l, h, a.session, () => !l ? .aborted && s());
    } catch (t) {
        let n = e.getState();
        if (t instanceof hP || !m()) return q("zendesk_webhook_post_ignored", {
            ...i,
            reason: "handoff_superseded"
        }), null;
        if (!o.inLiveChat && !o.inPending) throw t;
        e.dispatch(Z({
            fatalRequestErrorReached: !0,
            fatalRequestErrorPending: !1,
            fatalRequestErrorCancelFailed: !1
        }));
        let r = nP.get(e),
            a = n.liveAgent.zendesk.primarySessionId ? ? (r ? .operationSeq === u && r.conversationId === f && (r.stateGeneration ? ? null) === (v ? .stateGeneration ? ? null) ? r.primarySessionId : null);
        throw v && n.liveAgent.zendeskOperationSeq === u && n.session.chatterToken === d && n.session.conversationId === v.conversationId && a === v.primarySessionId && e.dispatch(oD({
            integration: "zendesk",
            action: px,
            payload: { ...v
            }
        })), t;
    }
}

function CP(e) {
    let t = G(e.primarySessionId),
        n = G(e.conversationId),
        r = Object.hasOwn(e, "stateGeneration"),
        i = e.stateGeneration,
        a = Rv(i);
    return !t || !n || r && (a === null || !Number.isSafeInteger(a) || a <= 0) ? null : {
        primarySessionId: t,
        conversationId: n,
        ...r && a !== null ? {
            stateGeneration: a
        } : {}
    };
}

function wP(e, t) {
    if (!t.relayed) return;
    let n = CP(t.payload);
    if (!n) return;
    let r = e.getState(),
        i = nP.get(e),
        a = r.liveAgent.zendesk.primarySessionId ? ? i ? .primarySessionId,
        o = (r.liveAgent.inLiveChat || r.liveAgent.inPending) && r.liveAgent.platformName === "zendesk_liveagent" && a === n.primarySessionId && i ? .primarySessionId === a && i.conversationId === r.session.conversationId && i.operationSeq === r.liveAgent.zendeskOperationSeq && (i.stateGeneration ? ? null) === (n.stateGeneration ? ? null);
    r.session.conversationId !== n.conversationId || !o || e.dispatch(Z({
        fatalRequestErrorReached: !0,
        fatalRequestErrorPending: !1,
        fatalRequestErrorCancelFailed: !1
    }));
}

function TP(e) {
    let t = W(e);
    if (!t || G(t.type) !== "agent") return null;
    let n = G(t.agent_id ? ? t.internal_id ? ? t.internalId);
    return n ? {
        id: n,
        name: G(t.display_name ? ? t.name) ? ? "Agent",
        imageUrl: G(t.image_url ? ? t.imageUrl) ? ? null,
        defaultImage: !1
    } : null;
}

function EP(e) {
    return Rv(e.position) ? ? Rv(e.queuePosition) ? ? Rv(e.queue_position);
}

function DP(e, t) {
    e.dispatch(eD({
        stateType: UT,
        inState: !0
    })), e.dispatch(eD({
        stateType: WT,
        inState: !1
    })), e.dispatch(lD(null)), e.dispatch(YE(!1)), t && e.dispatch(KE({
        id: t.id,
        name: t.name,
        imageUrl: t.imageUrl,
        defaultImage: t.defaultImage,
        isActive: !0
    }));
}

function OP(e, t) {
    let n = G(t.type);
    if (!n) return;
    if (n === "live_chat_connecting") {
        e.dispatch(Z({
            disconnected: !1,
            reconnecting: e.getState().liveAgent.zendesk.sdkInitialized
        }));
        return;
    }
    if (n === "live_chat_connected" || n === "live_chat_reconnected") {
        e.dispatch(Z({
            sdkInitialized: !0,
            disconnected: !1,
            reconnecting: !1
        }));
        return;
    }
    if (n === "live_chat_connection_failure") {
        e.dispatch(Z({
            disconnected: !0,
            reconnecting: !0
        }));
        return;
    }
    if (n === "live_chat_queue_position") {
        let n = EP(t);
        n !== null && e.dispatch(lD(n));
        return;
    }
    let r = TP(t.member);
    if (n === "live_chat_presence") {
        DP(e, r);
        return;
    }
    if ($N.has(n)) {
        DP(e, r);
        return;
    }
    if (n === "live_chat_presence_left" && r) {
        let n = EP(t);
        n !== null && n > 0 && (e.dispatch(eD({
            stateType: WT,
            inState: !0
        })), e.dispatch(eD({
            stateType: UT,
            inState: !1
        }))), n !== null && e.dispatch(lD(n)), e.dispatch(KE({
            id: r.id,
            name: r.name,
            imageUrl: r.imageUrl,
            isActive: !1
        })), e.dispatch(HE(r.id));
        return;
    }
    if ((n === "live_chat_typing_start" || n === "live_chat_typing_end") && r) {
        let t = e.getState().liveAgent.agents[r.id];
        e.dispatch(KE({
            id: r.id,
            name: r.name,
            imageUrl: r.imageUrl,
            isActive: t ? .isActive ? ? !1
        })), e.dispatch(GE({
            id: r.id,
            isTyping: n === "live_chat_typing_start"
        }));
        return;
    }
    YN.has(n) && (e.dispatch(eD({
        stateType: null,
        inState: !1
    })), e.dispatch(lD(null)));
}
var kP = /* @__PURE__ */ new WeakMap();

function AP(e) {
    let t = Rv(e.timestamp);
    return t === null ? Rv(W(e.message) ? .timestamp) : t;
}

function jP(e, t) {
    let n = e.getState().liveAgent.zendesk.lastProcessedTimestamp;
    if (n === null) return !1;
    let r = AP(t);
    return r !== null && r <= n;
}

function MP(e) {
    let t = kP.get(e);
    t && (clearTimeout(t), kP.delete(e));
}

function NP(e) {
    e.dispatch(hD()), e.dispatch(Z({
        chatClosed: !0
    }));
}
var PP = /* @__PURE__ */ new WeakMap();

function FP(e, t, n = fetch) {
    MP(e);
    let {
        zendesk: r,
        zendeskOperationSeq: i
    } = e.getState().liveAgent, a = PP.get(e), o = VP(e, {
        type: "live_chat_end_conversation",
        timestamp: Date.now(),
        zd_session: r.sessionId ? ? (a ? .operationSeq === i ? a.sessionId : null)
    }, n, t);
    NP(e), o.catch((e) => {
        q("zendesk_webhook_post_failed", {
            type: "live_chat_end_conversation",
            error: e instanceof Error ? e.message : String(e)
        });
    });
}

function IP(e, t, n) {
    MP(e);
    let r = setTimeout(() => {
        kP.delete(e);
        let r = e.getState();
        if (!r.liveAgent.inLiveChat || r.liveAgent.queuePosition || Object.values(r.liveAgent.agents).some((e) => e.isActive)) return;
        let i = {
            type: "live_chat_end_conversation",
            timestamp: Date.now()
        };
        e.dispatch(oD({
            integration: "liveAgent",
            action: "chat.end",
            payload: {}
        })), OP(e, i), n ? .(), FP(e, {
            inLiveChat: !1,
            inPending: !1
        }, t);
    }, VN);
    kP.set(e, r);
}
var LP = /* @__PURE__ */ new WeakMap();

function RP(e, t = fetch) {
    let n = e.getState(),
        {
            endpoint: r,
            chatterToken: i
        } = n.session;
    if (!r || !i || n.liveAgent.platformName !== "zendesk_liveagent" || !n.liveAgent.isActive) return;
    let a = n.liveAgent.zendeskOperationSeq,
        o = LP.get(e);
    if (o ? .operationSeq === a && (o.pending || o.sentAt !== null && Date.now() - o.sentAt < 3e5)) return;
    let s = {
        operationSeq: a,
        pending: !0,
        sentAt: o ? .operationSeq === a ? o.sentAt : null
    };
    LP.set(e, s), bT(e, {
        url: cP(r, "webhooks/live/"),
        method: "POST",
        credentials: "include",
        body: {
            type: "chatter_websocket_disconnect",
            by: i
        },
        timeoutMs: 15e3
    }, {
        fetchFn: t,
        isCurrent: () => e.getState().liveAgent.zendeskOperationSeq === a && e.getState().session.chatterToken === i
    }).then((e) => {
        if (!e.ok) throw Error(`HTTP ${e.status}`);
        s.sentAt = Date.now();
    }).catch(() => {
        q("zendesk_network_disruption_post_failed");
    }).finally(() => {
        s.pending = !1;
    });
}
var zP = /* @__PURE__ */ new WeakMap();

function BP(e, t) {
    return !t || !YN.has(t) || !e.getState().liveAgent.zendesk.endDelivered ? !1 : (q("zendesk_webhook_skipped", {
        reason: "chat_already_closed",
        type: t
    }), !0);
}
async function VP(e, t, n, r, i) {
    let a = vr(),
        o = e.getState(),
        s = G(t.type);
    if (BP(e, s)) return null;
    let {
        endpoint: c
    } = o.session, l = lP(e, t);
    if (!c || !l || a ? .aborted) return null;
    let u = i ? lP(e, i) : null,
        d = o.liveAgent.zendeskOperationSeq,
        f = G(l.zd_session);
    s && YN.has(s) && f && PP.set(e, {
        operationSeq: d,
        sessionId: f
    });
    let p = zP.get(e),
        m = t.type === "live_chat_end_conversation",
        h = m || t.type === "live_chat_disconnected",
        g = !1,
        _ = () => {
            g = !0, p ? .operationSeq === d && p.retainPresence();
        };
    m && _();
    let v = () => e.getState().liveAgent.zendeskOperationSeq === d,
        y = (t) => {
            typeof t == "string" && YN.has(t) && v() && e.dispatch(Z({
                endDelivered: !0
            }));
        },
        b = cP(c, "webhooks/live/"),
        x = /* @__PURE__ */ new Set(),
        S = /* @__PURE__ */ new Set(),
        C = (e) => {
            if (!(x.has(e) || S.has(e))) {
                S.add(e);
                try {
                    n.call(globalThis, fc(b), {
                        method: "POST",
                        credentials: "include",
                        keepalive: !0,
                        headers: {
                            ...pc({
                                url: b,
                                body: e
                            }),
                            ...fC(o.session)
                        },
                        body: JSON.stringify(e)
                    }).catch(() => q("zendesk_webhook_teardown_post_failed"));
                } catch {
                    q("zendesk_webhook_teardown_post_failed");
                }
            }
        },
        w = () => {
            g && u && C(u), (m || g && t.type === "live_chat_presence") && C(l);
        };
    a ? .addEventListener("abort", w, {
        once: !0
    });
    let T = async (t, i) => {
            if (a ? .aborted) return null;
            let s = 0,
                c = await SP(e, async (e, t) => {
                    _P(() => !a ? .aborted || !S.has(i)), x.add(i), s += 1;
                    try {
                        let r = await n.call(globalThis, e, t);
                        return r.ok && S.add(i), r;
                    } finally {
                        --s, s === 0 && x.delete(i);
                    }
                }, b, {
                    method: "POST",
                    credentials: "include",
                    bindLifecycleSignal: !1,
                    keepalive: !0,
                    body: i
                }, {
                    type: G(t)
                }, o, r, () => m || t === "live_chat_presence" && g).then((e) => (e && y(t), e), (e) => {
                    throw e instanceof gP && !JN.has(e.status) && y(t), e;
                });
            if (!c) return null;
            try {
                return dP(await c.json());
            } catch {
                return null;
            }
        },
        ee = async (t, n) => {
            if (m) return T(t, n);
            let r, i = new Promise((n) => {
                let i = () => {
                    !v() && !(t === "live_chat_presence" && g) && n(null);
                };
                r = e.subscribe(i), i();
            });
            try {
                return await Promise.race([T(t, n), i]);
            } finally {
                r ? .();
            }
        },
        E = (async () => {
            if (p) {
                let e = Date.now() + qN,
                    t = async (t, n) => {
                        let r;
                        try {
                            let i = t.catch(() => null);
                            if (n) {
                                let t = e - Date.now();
                                if (t <= 0) return;
                                await Promise.race([i, new Promise((e) => {
                                    r = setTimeout(e, t);
                                })]);
                            } else await i;
                        } finally {
                            clearTimeout(r);
                        }
                    };
                if (await t(p.promise, h || p.isTerminal || d > p.operationSeq), h || await t(p.nonTerminalPromise, d > p.nonTerminalOperationSeq), !v() && !m && !g) return null;
            }
            return u && (await ee("live_chat_presence", u).catch(() => {
                q("zendesk_presence_pre_post_failed");
            }), !v() && !m) || !v() && !m && t.type !== "live_chat_presence" ? null : ee(t.type, l);
        })(),
        D = {
            promise: E,
            nonTerminalPromise: h ? p ? .nonTerminalPromise ? ? Promise.resolve(null) : E,
            nonTerminalOperationSeq: h ? p ? .nonTerminalOperationSeq ? ? d : d,
            operationSeq: d,
            retainPresence: _,
            isTerminal: h
        };
    zP.set(e, D);
    try {
        return await E;
    } finally {
        a ? .removeEventListener("abort", w), D.nonTerminalPromise.catch(() => null).then(() => {
            zP.get(e) === D && zP.delete(e);
        });
    }
}
async function HP(e, t, n) {
    let r = e.getState(),
        {
            inLiveChat: i,
            inPending: a
        } = r.liveAgent,
        {
            endpoint: o
        } = r.session;
    if (!o) return;
    let s = lP(e, t);
    s && await SP(e, n, cP(o, "webhooks/live/agent/"), {
        method: "POST",
        credentials: "include",
        body: s
    }, {
        type: "agent.update"
    }, r, {
        inLiveChat: i,
        inPending: a
    }) && GP(e, t);
}

function UP(e, t) {
    if (!t) return;
    let n = e.getState(),
        r = Array.isArray(t.batched_transcript) ? t.batched_transcript.filter((e) => typeof e == "string" && e.trim() !== "") : [],
        i = G(t.external_chat_id);
    if (!(r.length === 0 || !i)) {
        if (n.session.sessionId && i !== n.session.sessionId) {
            e.dispatch(Z({
                primarySessionId: i
            })), q("zendesk_transcript_session_mismatch", {
                hasExternalChatId: !0
            });
            return;
        }
        e.dispatch(oD({
            integration: "zendesk",
            action: "transcript.send",
            payload: {
                transcript: r,
                externalChatId: i,
                currentSessionId: n.session.sessionId ? ? void 0
            }
        }));
    }
}

function WP(e, t, n, r = !0) {
    let {
        inLiveChat: i,
        inPending: a
    } = e.getState().liveAgent, o = G(t.zd_session), s = {
        type: "live_chat_disconnected",
        errorMessage: ZN,
        ...o ? {
            zd_session: o
        } : {},
        ...t.timestamp === void 0 ? {} : {
            timestamp: t.timestamp
        }
    };
    if (!BP(e, "live_chat_disconnected")) {
        if (!lP(e, s)) {
            q("zendesk_inactive_retry_probe_dropped", {
                reason: "missing_session_context"
            });
            return;
        }
        e.dispatch(aD(!0)), r && VP(e, s, n, {
            inLiveChat: i,
            inPending: a
        }).catch((e) => {
            q("zendesk_inactive_retry_probe_post_failed", {
                error: e instanceof Error ? e.message : String(e)
            });
        });
    }
}

function GP(e, t) {
    let n = TP(t.member);
    n && e.getState().liveAgent.agents[n.id] && e.dispatch(KE({
        id: n.id,
        name: n.name,
        imageUrl: n.imageUrl
    }));
}

function KP({
    store: e,
    payload: t,
    fetchFn: n = fetch,
    onLiveChatEnded: r
}) {
    let i = aP(t);
    if (!i) return;
    if (i.event === "auth.unavailable") {
        q("zendesk_jwt_auth_unavailable");
        return;
    }
    if (i.event === "storage.update") {
        if (Object.hasOwn(i.payload, "zdSessionId")) {
            let t = G(i.payload.zdSessionId);
            e.dispatch(Z({
                sessionId: t
            }));
        }
        sP(e, i.payload);
        return;
    }
    if (i.event === "agent.update") {
        if (uP(e)) {
            q("zendesk_agent_update_ignored", {
                reason: "session_mismatch"
            });
            return;
        }
        if (i.relayed) {
            GP(e, i.payload);
            return;
        }
        HP(e, i.payload, n).catch((e) => {
            q("zendesk_agent_update_post_failed", {
                error: e instanceof Error ? e.message : String(e)
            });
        });
        return;
    }
    if (i.event === "cross_tab.failure") {
        let e = G(i.payload.reason);
        e && tP.has(e) && q("zendesk_cross_tab_failure", {
            reason: e
        });
        return;
    }
    if (i.event === "cross_tab.fatal") {
        wP(e, i);
        return;
    }
    if (i.event !== "webhook") return;
    let a = G(i.payload.type);
    if (!a) return;
    if (a === "chatter_websocket_disconnect") {
        i.relayed || RP(e, n);
        return;
    }
    if (a === XN) {
        WP(e, i.payload, n, !i.relayed);
        return;
    }
    if (uP(e)) {
        q("zendesk_webhook_ignored", {
            reason: "session_mismatch",
            type: a
        });
        return;
    }
    if (jP(e, i.payload)) {
        if (a === "live_chat_presence" && !e.getState().liveAgent.zendesk.chatClosed) {
            let t = TP(i.payload.member);
            t && DP(e, t);
        }
        q("zendesk_webhook_ignored", {
            reason: "stale_timestamp",
            type: a
        });
        return;
    }
    if (eP.has(a) && e.getState().liveAgent.zendesk.chatClosed) {
        q("zendesk_webhook_ignored", {
            reason: "chat_closed",
            type: a
        });
        return;
    }
    let o = G(i.payload.zd_session);
    o && e.dispatch(Z({
        sessionId: o
    })), e.dispatch(sD({
        platformName: GT
    }));
    let {
        inLiveChat: s,
        inPending: c
    } = e.getState().liveAgent, l = a === "live_chat_message" && c && TP(i.payload.member) !== null;
    if (OP(e, i.payload), (a === "live_chat_presence" || YN.has(a)) && MP(e), !i.relayed && a === "live_chat_presence_left" && (EP(i.payload) ? ? 0) <= 0 && IP(e, n, r), i.payload.resume === !0 && QN.has(a)) {
        q("zendesk_webhook_skipped", {
            reason: "refresh_resume",
            type: a
        });
        return;
    }
    if (i.relayed) {
        YN.has(a) && NP(e);
        return;
    }
    let u = VP(e, i.payload, n, {
        inLiveChat: s,
        inPending: c
    }, l ? {
        type: "live_chat_presence",
        member: i.payload.member,
        timestamp: Rv(W(i.payload.message) ? .timestamp) ? ? Date.now()
    } : void 0);
    YN.has(a) && NP(e), u.then((t) => {
        a === "live_chat_send_transcript" && UP(e, t);
    }).catch((t) => {
        q("zendesk_webhook_post_failed", {
            type: a,
            error: t instanceof Error ? t.message : String(t)
        }), a === "live_chat_send_transcript" && e.dispatch(hO("Failed to send Zendesk transcript"));
    });
}

function qP(e) {
    let t = Rv(e);
    return t === null || !Number.isFinite(t) || t <= 0 || t < 1e9 || t >= 0x5af3107a4000 ? null : t;
}
var JP = "live_chat_network_disruption",
    YP = "live_agent_queue",
    XP = "position",
    ZP = "time",
    QP = "unknown",
    $P = 0,
    eF = 15e3;

function tF(e) {
    return G(e, {
        trimOutput: !1
    });
}

function nF(e) {
    let t = W(e);
    if (!t) return null;
    let n = tF(t.internal_id ? ? t.internalId ? ? t.id),
        r = tF(t.name ? ? t.display_name) ? ? "Agent",
        i = tF(t.image_url ? ? t.imageUrl ? ? t.avatar_path) ? ? null,
        a = Lv(t.default_image ? ? t.defaultImage) ? ? !1;
    return n ? {
        id: n,
        name: r,
        imageUrl: i,
        defaultImage: a
    } : null;
}

function rF(e, t) {
    let n = W(t);
    if (!n) return;
    let r = Lv(n.in_state);
    if (r === null) return;
    e.dispatch(PO());
    let i = e.getState(),
        a = i.chat,
        o = i.featureFlags.flags["disable-text-input-live-chat"] === !0 && i.liveAgent.platformName === "zaw_liveagent" && i.liveAgent.inLiveChat && !i.liveAgent.conversationEndedByChatter,
        s = tF(n.state_type),
        c = W(n.state_data),
        l = !!(s && Qw.has(s)),
        u = !!(s && $w.has(s)),
        d = l && !r,
        f = u && !r;
    e.dispatch(eD({
        stateType: s ? ? null,
        inState: r,
        stateData: c
    }));
    let p = e.getState().liveAgent;
    o && s === "live_chat" && !r && !p.inLiveChat && !p.isActive && (e.dispatch(JE()), q("zdm_conversation_ended_after_handoff")), l && r && c ? e.dispatch(ak(nT(c))) : f || e.dispatch(ak(null)), u && r && c ? e.dispatch(fk(rT(c, s))) : d || e.dispatch(fk(null));
    let m = Rv(n.queue_position);
    m !== null && n.queue_unit !== ZP && e.dispatch(lD(m)), q("live_agent_conversation_state_changed", {
        stateType: s,
        inState: r,
        hasStateData: !!c,
        crossTypeExitIsolated: d && a.listSelectionData !== null || f && a.captureData !== null
    });
}

function iF(e, t) {
    let n = W(t);
    if (!n || !("ada_glass_env" in n)) return;
    let r = n.ada_glass_env,
        i = tF(r);
    r !== null && !i || (e.dispatch(sD({
        platformName: i
    })), q("live_agent_platform_updated", {
        platformName: i,
        isHandoffIntegration: i ? .startsWith("handoff_integration_") ? ? !1
    }), i && !gE(i) && q("live_agent_platform_unrecognized", {
        platformName: i
    }));
}

function aF(e, t) {
    let n = W(t),
        r = typeof n ? ._id == "string" ? n._id : null;
    if (!r) return;
    let i = W(n ? .message);
    e.dispatch(rk({
        id: r,
        expired: i ? .auth_link_expired === !0
    }));
}

function oF(e) {
    e.dispatch(nc(!0));
}

function sF(e) {
    e.dispatch(nc(!1));
}

function cF(e, t) {
    if (W(t) ? .state !== "fail") return;
    let n = "SOMETHING_WENT_WRONG",
        r = _T(e.getState().localization.translations, n);
    e.dispatch(hO(r === n ? "Oops, something went wrong" : r));
}

function lF(e, t) {
    let n = W(W(t) ? .notification_info);
    if (n && n.type === YP) {
        if (n.unit === XP) {
            let t = Rv(n.amount);
            t !== null && e.dispatch(lD(t));
            return;
        }
        if (n.unit === QP && e.dispatch(lD($P)), n.unit === ZP) {
            let t = Rv(n.amount);
            t !== null && e.dispatch(uD(t));
        }
    }
}

function uF(e, t) {
    let n = W(t);
    if (!n) return;
    let r = Lv(n.is_typing);
    r !== null && e.dispatch(ik(r));
}

function dF(e, t) {
    let n = W(t);
    if (!n) return;
    let r = Lv(n.is_typing);
    if (r === null) return;
    let i = tF(n.agent_internal_id);
    i || = lE(e.getState().liveAgent.agents) ? .id ? ? null, i && e.dispatch(GE({
        id: i,
        isTyping: r
    }));
}

function fF(e, t) {
    let n = W(t);
    n && (e.dispatch(PE(n)), q("live_agent_file_transfer_update", {
        type: tF(n.type)
    }));
}

function pF(e) {
    if (!Array.isArray(e)) return;
    let t = e.filter((e) => typeof e == "string");
    return t.length > 0 ? t : void 0;
}

function mF(e) {
    return (typeof e == "string" || typeof e == "number" ? Number.parseInt(String(e), 10) : NaN) || null;
}

function hF(e, t) {
    let n = W(t);
    if (!n) return;
    let r = tF(n.account_key ? ? n.accountKey);
    if (!r) return;
    let i = mF(n.department_id ? ? n.departmentId),
        a = pF(n.tags),
        o = W(n.visitor_info ? ? n.visitorInfo),
        s = Lv(n.use_zd_auth ? ? n.useZdAuth),
        c = tF(n.override_proxy ? ? n.overrideProxy),
        l = tF(n.external_chat_id ? ? n.externalChatId),
        u = Object.hasOwn(n, "state_generation") || Object.hasOwn(n, "stateGeneration"),
        d = Object.hasOwn(n, "state_generation") ? n.state_generation : n.stateGeneration,
        f = Rv(d),
        p = f !== null && Number.isSafeInteger(f) && f > 0 ? f : void 0,
        m = tF(n.sdk_script_url ? ? n.sdkScriptUrl),
        h = e.getState(),
        g = h.session.features.crossTabHandoffCoordination === !0,
        _ = _T(h.localization.translations, JP),
        v = _ === JP ? void 0 : _,
        y = h.liveAgent.zendesk.previousTags ? ? (h.session.handle ? ON(oS() ? .get(DN(h.session.handle)) ? ? null) : null);
    e.dispatch(rD()), e.dispatch(sD({
        platformName: GT,
        departmentId: i
    })), e.dispatch(eD({
        stateType: WT,
        inState: !0
    })), e.dispatch(YE(!1)), e.dispatch(Z({
        primarySessionId: l,
        departmentId: i,
        tags: a ? ? null,
        disconnected: !1,
        reconnecting: !1,
        lastProcessedTimestamp: null
    })), rP(e, u && p === void 0 ? null : p), e.dispatch(oD({
        integration: "zendesk",
        action: "handoff.initialize",
        payload: {
            accountKey: r,
            ...i === null ? {} : {
                departmentId: i
            },
            ...a ? {
                tags: a
            } : {},
            ...y && y.length > 0 ? {
                previousTags: y
            } : {},
            ...o ? {
                visitorInfo: o
            } : {},
            options: {
                ...s === null ? {} : {
                    useJWTAuth: s
                },
                ...c ? {
                    sdkProxyOverride: c
                } : {},
                ...m ? {
                    sdkScriptUrl: m
                } : {},
                ...v ? {
                    networkDisruptionMessage: v
                } : {},
                ...g ? {
                    crossTabCoordination: !0
                } : {}
            },
            ...h.session.endpoint ? {
                endpoint: h.session.endpoint
            } : {},
            ...h.session.chatterToken ? {
                chatterToken: h.session.chatterToken
            } : {},
            ...h.session.sessionToken ? {
                sessionToken: h.session.sessionToken
            } : {},
            ...l ? {
                externalChatId: l
            } : {},
            ...u ? {
                stateGeneration: p ? ? d
            } : {},
            ...h.session.conversationId ? {
                conversationId: h.session.conversationId
            } : {}
        }
    })), q("zendesk_init_conversation_received", {
        hasDepartmentId: i !== null,
        hasVisitorInfo: !!o,
        hasTags: !!a ? .length
    });
}

function gF(e, t) {
    let n = W(t);
    if (!n) return;
    let r = Lv(n.is_typing);
    r !== null && e.dispatch(oD({
        integration: "liveAgent",
        action: r ? "typing.start" : "typing.stop",
        payload: {
            source: "server_relay"
        }
    }));
}

function _F(e) {
    e.dispatch(eD({
        stateType: null,
        inState: !1
    })), e.dispatch(lD(null)), e.dispatch(hD()), e.dispatch(oD({
        integration: "zendesk",
        action: "sdk.teardown",
        payload: {}
    }));
}

function vF(e) {
    _F(e), q("zendesk_cancel_live_chat_received");
}

function yF(e) {
    _F(e), q("zendesk_chatter_ended_chat_received");
}

function bF(e, t) {
    let n = W(t);
    if (!n) return;
    let r = qP(n.last_processed_timestamp),
        i = tF(n.external_chat_id),
        a = e.getState().session.sessionId;
    if (i && a && i !== a) {
        e.dispatch(Z({
            primarySessionId: i
        })), q("zendesk_last_processed_session_mismatch", {
            hasExternalChatId: !0
        });
        return;
    }
    let o = e.getState().liveAgent.zendesk.lastProcessedTimestamp,
        s = r !== null && o !== null && o >= 1e9 && r >= o * 1e3,
        c = r !== null && !s && (o === null || r > o);
    e.dispatch(Z({
        ...i ? {
            primarySessionId: i
        } : {},
        ...c ? {
            lastProcessedTimestamp: r
        } : {}
    })), q("zendesk_last_processed_update_received", {
        hasTimestamp: r !== null,
        hasExternalChatId: !!i,
        watermarkRegressed: r !== null && o !== null && r < o
    });
}
var xF = /* @__PURE__ */ new WeakMap();

function SF(e, t) {
    let {
        endpoint: n,
        chatterToken: r,
        sessionToken: i
    } = e.getState().session;
    if (!n || !r) return !1;
    let a = e.getState().chat;
    if (t === "agent" && a.csatSettings !== null || t === "bot" && a.csatBotSettings !== null) return !1;
    let o = JSON.stringify([
            n,
            r,
            t
        ]),
        s = xF.get(e);
    if (s || (s = /* @__PURE__ */ new Set(), xF.set(e, s)), s.has(o)) return !1;
    let c = n.endsWith("/") ? n : `${n}/`,
        l = new URL("csat_settings/", c);
    l.searchParams.set("survey_type", t);
    let u = {
        "X-Ada-Request-Origin": "chat",
        "Chatter-Token": r
    };
    i && (u["Session-Auth"] = i);
    let d = new AbortController(),
        f;
    s.add(o);
    try {
        return f = globalThis.setTimeout(() => {
            d.abort();
        }, eF), fetch(l.toString(), {
            method: "GET",
            credentials: "include",
            headers: u,
            signal: d.signal
        }).then(async (e) => {
            if (!e.ok) {
                q("csat_settings_fetch_failed", {
                    status: e.status,
                    surveyType: t
                });
                return;
            }
            return {
                response: e,
                responseBody: await e.json()
            };
        }).then((n) => {
            if (!n) return;
            let {
                response: i,
                responseBody: a
            } = n;
            if (e.getState().session.chatterToken !== r) return;
            let o = Qv(a && typeof a == "object" && "data" in a ? a.data : a, e.getState().session.language || "en");
            if (!o) {
                q("csat_settings_fetch_failed", {
                    status: i.status,
                    surveyType: t,
                    reason: "unparseable"
                });
                return;
            }
            t === "agent" ? e.dispatch(bk(o)) : e.dispatch(xk(o));
        }).catch(() => {
            q("csat_settings_fetch_error", {
                surveyType: t
            });
        }).finally(() => {
            globalThis.clearTimeout(f), s.delete(o);
        }), !0;
    } catch (e) {
        throw s.delete(o), globalThis.clearTimeout(f), e;
    }
}

function CF(e, t) {
    let {
        endpoint: n,
        chatterToken: r,
        sessionToken: i
    } = e.getState().session, a = dT();
    if (e.dispatch(Sk({
            requestId: a
        })), !n || !r || !t) {
        e.dispatch(Ck({
            eligible: !1,
            surveyTarget: "bot",
            requestId: a
        }));
        return;
    }
    let o = () => e.getState().session.conversationId === t,
        s = n.endsWith("/") ? n : `${n}/`,
        c = new URL("surveys/end_chat_survey_eligible/", s);
    c.searchParams.set("conversation_id", t);
    let l = {
        "X-Ada-Request-Origin": "chat",
        "Chatter-Token": r
    };
    i && (l["Session-Auth"] = i);
    let u = !1;
    fetch(c.toString(), {
        method: "GET",
        credentials: "include",
        headers: l
    }).then((t) => {
        if (o()) return t.ok ? t.json() : (q("csat_end_chat_eligibility_fetch_failed", {
            status: t.status
        }), u = !0, e.dispatch(Ck({
            eligible: !1,
            surveyTarget: "bot",
            requestId: a
        })), null);
    }).then((t) => {
        if (!o() || u) return;
        if (!t || typeof t != "object") {
            q("csat_end_chat_eligibility_malformed_body", {}), e.dispatch(Ck({
                eligible: !1,
                surveyTarget: "bot",
                requestId: a
            }));
            return;
        }
        let n = "data" in t && t.data ? t.data : t,
            r = Lv(n.eligible) ? ? !1,
            i = G(n.survey_target) === "agent" ? "agent" : "bot";
        if (r && e.getState().chat.csatEndChatEligibility.requestId === a) try {
            SF(e, i);
        } catch {}
        e.dispatch(Ck({
            eligible: r,
            surveyTarget: i,
            requestId: a
        }));
    }).catch(() => {
        o() && (q("csat_end_chat_eligibility_fetch_error", {}), e.dispatch(Ck({
            eligible: !1,
            surveyTarget: "bot",
            requestId: a
        })));
    });
}

function wF(e, t) {
    let n = t.event ? ? "generic",
        r = nF(t.agent_info);
    if (n === "agent_arrival") {
        r && e.dispatch(KE({
            id: r.id,
            name: r.name,
            imageUrl: r.imageUrl,
            defaultImage: r.defaultImage,
            isActive: !0,
            isTyping: !1,
            isColleague: !1
        })), e.dispatch(eD({
            stateType: UT,
            inState: !0
        })), e.dispatch(lD(null)), e.dispatch(YE(!1)), SF(e, "agent"), q("live_agent_arrival", {
            agentId: r ? .id ? ? null
        });
        return;
    }
    if (n === "agent_depart" || n === "agent_snoozed") {
        r && e.dispatch(HE(r.id)), q("live_agent_departure", {
            agentId: r ? .id ? ? null,
            event: n
        });
        return;
    }
    if (n === "generic" && r) {
        e.dispatch(KE({
            id: r.id,
            name: r.name,
            imageUrl: r.imageUrl,
            defaultImage: r.defaultImage,
            isActive: !0,
            isTyping: !1,
            isColleague: !0
        })), q("live_agent_colleague_joined", {
            agentId: r.id
        });
        return;
    }
    (n === "live_chat_end" || n === "conversation_ended" || n === "conversation_timeout") && (e.dispatch(eD({
        stateType: UT,
        inState: !1
    })), e.dispatch(lD(null)), (n === "conversation_ended" || n === "conversation_timeout") && e.dispatch(JE()));
}
//#endregion
//#region src/api/client-api.ts
var TF = "0".repeat(24),
    EF = (e) => e || TF,
    DF = (e, t, n) => typeof e == "number" ? e : typeof t == "number" ? t : n,
    OF = 50,
    kF = 256,
    AF = 512;

function jF(e) {
    return typeof e == "boolean" ? e : void 0;
}
var MF = 64,
    NF = 12e4;

function PF(e) {
    let t = e ? .ada_partner_name ? ? e ? .adaPartnerName;
    if (typeof t != "string") return null;
    let n = t.trim();
    return n ? n.slice(0, MF) : null;
}

function FF(e) {
    return typeof e == "number" && Number.isFinite(e) && e > 0 ? e : null;
}

function IF(e, t = "en") {
    if (typeof e == "string") return e || null;
    let n = W(e);
    return n ? G(n[t] ? ? n.en) ? ? null : null;
}

function LF(e) {
    let t = W(e);
    if (!t) return null;
    let n = Object.entries(t).flatMap(([e, t]) => {
        let n = G(t);
        return n ? [
            [e, n]
        ] : [];
    });
    return n.length > 0 ? Object.fromEntries(n) : null;
}

function RF(e) {
    if (typeof e != "string" || !e.trim()) return null;
    try {
        let t = new URL(e.trim());
        return t.protocol === "https:" ? t.toString() : null;
    } catch {
        return null;
    }
}

function zF(e) {
    return typeof e == "string" ? pv(e) : null;
}

function BF(e) {
    return typeof e == "string" ? dv(e) : null;
}

function VF(e) {
    return e === "rectangular" ? "rectangular" : "round";
}

function HF(e) {
    return e === "small" ? "small" : e === "large" ? "large" : "default";
}

function UF(e) {
    return Array.isArray(e) ? e.filter((e) => typeof e == "string") : [];
}

function WF(e, t) {
    return e === "carousel" ? "carousel" : e === "stacked" ? "stacked" : t;
}

function GF(e) {
    return {
        mobile: WF(e ? .button_layout_mobile ? ? e ? .buttonLayoutMobile, "stacked"),
        desktop: WF(e ? .button_layout_desktop ? ? e ? .buttonLayoutDesktop, "stacked")
    };
}

function KF(e) {
    return e === "light" ? "light" : e === "dark" ? "dark" : "auto";
}

function qF(e) {
    let t = G(e);
    if (!t) return "";
    try {
        let e = new URL(t.trim());
        return e.protocol !== "https:" && e.protocol !== "http:" ? "" : t.trim();
    } catch {
        return "";
    }
}
var JF = "zendesk_liveagent";

function YF(e, t) {
    if (e !== JF || !t) return;
    let n = W(t.platform_data),
        r = G(n ? .account_key);
    if (!r) return;
    let i = n ? .tags,
        a = Array.isArray(i) ? i.filter((e) => typeof e == "string") : null;
    return {
        accountKey: r,
        tags: a && a.length > 0 ? a : null,
        useZdAuth: typeof n ? .use_zd_auth == "boolean" ? n.use_zd_auth : null,
        overrideProxy: G(n ? .override_proxy) ? ? null,
        lastProcessedTimestamp: qP(n ? .last_processed_timestamp)
    };
}
var XF = "live_chat",
    ZF = "live_chat_pending",
    QF = "unknown",
    $F = "time",
    eI = 0;

function tI(e) {
    if (!e ? .queued) return null;
    if (e.queue_unit === QF) return eI;
    if (e.queue_unit === $F) return null;
    let t = e.queue_position;
    return typeof t == "number" && Number.isFinite(t) ? t : null;
}

function nI(e) {
    if (!Array.isArray(e)) return;
    let t = [];
    for (let n of e) {
        let e = nF(n),
            r = W(n) ? .currently_in_conversation;
        if (!e || typeof r != "boolean") return;
        t.push({
            ...e,
            isActive: r,
            isTyping: !1
        });
    }
    return t;
}

function rI(e) {
    let t = typeof e == "number" ? Math.round(e * 1e3) : NaN;
    return Number.isSafeInteger(t) && t > 0 ? t : void 0;
}

function iI(e, t) {
    let n = t ? ? 0;
    for (let t of Array.isArray(e.agents) ? e.agents : []) {
        let e = G(W(t) ? .last_interaction_at) ? .match(/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})(?:\.(\d{1,6}))?(Z|[+-]\d{2}:\d{2})?$/);
        if (!e) return;
        let [, r, i = "0", a = "Z"] = e, o = Date.parse(`${r.replace(" ", "T")}${a}`) + Math.round(Number(`0.${i}`) * 1e3);
        if (!Number.isSafeInteger(o) || o <= 0) return;
        n = Math.max(n, o);
    }
    return n || void 0;
}

function aI(e) {
    if (!e ? .queued || e.queue_unit !== $F) return null;
    let t = e.queue_position;
    return typeof t == "number" && Number.isFinite(t) ? t : null;
}

function oI(e) {
    if (!e || e.active === !1) return null;
    let t = e.current_state && typeof e.current_state == "object" && !Array.isArray(e.current_state) ? e.current_state : null,
        n = t && typeof t._type == "string" ? t._type : null,
        r = n === XF || n === ZF ? n : null,
        i = typeof e.ada_glass_env == "string" && e.ada_glass_env ? e.ada_glass_env : null,
        a = tI(t),
        o = aI(t),
        s = t ? .department_id,
        c = typeof s == "string" && s.trim() !== "" ? Number(s) : s,
        l = typeof c == "number" && Number.isFinite(c) ? c : null;
    if (!r && !i && a === null && o === null && l === null) return null;
    let u = YF(i, t),
        d = W(W(t ? .platform_data) ? .file_request),
        f = i === "zaw_liveagent" && r === XF ? nI(e.agents) : void 0,
        p = rI(e.updated),
        m = f === void 0 ? void 0 : iI(e, p);
    return {
        currentState: r,
        platformName: i,
        queuePosition: a,
        ...o === null ? {} : {
            queueWaitMinutes: o
        },
        departmentId: l,
        ...f === void 0 ? {} : {
            agents: f
        },
        ...m === void 0 ? {} : {
            agentRosterUpdatedAt: m
        },
        ...p === void 0 ? {} : {
            conversationUpdatedAt: p
        },
        ...u ? {
            zendeskReconnect: u
        } : {},
        ...d ? {
            fileRequest: d
        } : {}
    };
}

function sI(e) {
    if (!e || e.active === !1) return null;
    let t = W(e.current_state),
        n = G(t ? ._type);
    return !n || !Qw.has(n) ? null : nT(W(W(t ? .data) ? .chat_data));
}

function cI(e) {
    return e ? .active === !1;
}

function lI(e) {
    if (!e || e.active === !1) return null;
    let t = W(e.current_state),
        n = G(t ? ._type);
    return !n || !$w.has(n) ? null : rT(W(W(t ? .data) ? .chat_data), n);
}

function uI(e) {
    return !e || e.active === !1 ? !1 : G(W(e.current_state) ? ._type) === eT;
}

function dI(e) {
    let t = W(e);
    if (!t) return null;
    let n = G(t.label) ? ? "",
        r = qF(t.url);
    return n && r ? {
        label: n,
        url: r
    } : null;
}

function fI(e) {
    return Array.isArray(e) ? e.map((e) => dI(e)).filter((e) => e !== null) : [];
}

function pI(e) {
    let t = W(e);
    if (!t) return null;
    let n = {};
    for (let [e, r] of Object.entries(t)) {
        let t = fI(r);
        t.length > 0 && (n[e] = t);
    }
    return Object.keys(n).length > 0 ? n : null;
}

function mI(e) {
    return typeof e == "string" ? e.trim().length > 0 : Object.values(e).some((e) => e.trim().length > 0);
}

function hI(e) {
    return Array.isArray(e) ? e.length > 0 : Object.values(e).some((e) => e.length > 0);
}

function gI(e, t) {
    let n = LF(e),
        r = LF(t);
    if (!n && !r) {
        let n = G(e) ? ? "",
            r = qF(G(t));
        return n && r ? [{
            label: n,
            url: r
        }] : [];
    }
    let i = new Set([...Object.keys(n ? ? {}), ...Object.keys(r ? ? {})]),
        a = {};
    for (let n of i) {
        let r = IF(e, n) ? ? "",
            i = qF(IF(t, n));
        r && i && (a[n] = [{
            label: r,
            url: i
        }]);
    }
    return Object.keys(a).length > 0 ? a : [];
}

function _I(e) {
    let t = W(e);
    if (!t) return null;
    if ("message" in t || "links" in t || "icon" in t) {
        let e = W(t.icon),
            n = {
                isDefault: e ? e.default !== !1 : !0,
                image: e && qF(e.image) || null
            },
            r = typeof t.message == "string" ? t.message : LF(t.message) ? ? "",
            i = Array.isArray(t.links) ? fI(t.links) : pI(t.links) ? ? [];
        return !mI(r) && !hI(i) && n.isDefault ? null : {
            icon: n,
            message: r,
            links: i
        };
    }
    let n = t.description ? ? t.DESCRIPTION,
        r = t.buttonLabel ? ? t.button_label ? ? t.BUTTON_LABEL,
        i = t.buttonUrl ? ? t.button_url ? ? t.BUTTON_URL,
        a = typeof n == "string" ? n : LF(n) ? ? "",
        o = gI(r, i);
    return !mI(a) && !hI(o) ? null : {
        icon: {
            isDefault: !0,
            image: null
        },
        message: a,
        links: o
    };
}

function vI(e) {
    let t = W(e);
    if (!t) return null;
    let n = {};
    for (let [e, r] of Object.entries(t)) {
        let t = W(r);
        t && (n[e] = {
            key: e,
            order: typeof t.order == "number" && Number.isFinite(t.order) ? t.order : null,
            messages: W(t.messages) ? ? {},
            is_template: typeof t.is_template == "boolean" ? t.is_template : !!t.isTemplate,
            params: W(t.params),
            modality_config: W(t.modality_config ? ? t.modalityConfig),
            images: yI(t.images),
            ctas: bI(t.ctas),
            playbook_id: G(t.playbook_id ? ? t.playbookId)
        });
    }
    return Object.keys(n).length > 0 ? n : null;
}

function yI(e) {
    let t = W(e);
    if (!t) return;
    let n = {};
    for (let [e, r] of Object.entries(t)) {
        if (!Array.isArray(r)) continue;
        let t = [];
        for (let e of r) {
            let n = W(e),
                r = zF(n ? .url);
            r && t.push({
                url: r,
                alt: G(n ? .alt) ? ? ""
            });
        }
        t.length > 0 && (n[e] = t);
    }
    return Object.keys(n).length > 0 ? n : void 0;
}

function bI(e) {
    if (!Array.isArray(e)) return;
    let t = [];
    for (let n of e) {
        let e = W(n),
            r = G(e ? .cta_label ? ? e ? .label),
            i = BF(e ? .cta_url ? ? e ? .url);
        !r || !i || t.push({
            label: r,
            url: i,
            openInNewTab: jF(e ? .cta_open_in_new_tab ? ? e ? .openInNewTab) ? ? !0
        });
    }
    return t.length > 0 ? t : void 0;
}

function xI(e) {
    let t = W(e);
    if (!t) return;
    let n = G(t.response_id ? ? t.responseId) ? ? "",
        r = G(t.body) ? ? "",
        i = W(t.image),
        a = zF(i ? .url),
        o = W(t.cta),
        s = G(o ? .label ? ? o ? .cta_label),
        c = BF(o ? .url ? ? o ? .cta_url);
    return {
        response_id: n,
        body: r,
        delay: DF(t.delay, void 0, 0),
        duration: DF(t.duration, void 0, null),
        style: t.style === "Emoji" ? "Emoji" : "Text",
        paths: UF(t.paths),
        ...a ? {
            image: {
                url: a,
                alt: G(i ? .alt) ? ? ""
            }
        } : {},
        ...s && c ? {
            cta: {
                label: s,
                url: c,
                openInNewTab: jF(o ? .openInNewTab ? ? o ? .cta_open_in_new_tab) ? ? !0
            }
        } : {}
    };
}

function SI(e) {
    if (!Array.isArray(e)) return [];
    let t = [];
    for (let n of e) {
        if (t.length >= OF) break;
        let e = W(n);
        if (!e || jF(e.active) !== !0) continue;
        let r = G(e.regex);
        if (!r || r.length > kF) continue;
        let i = typeof e.replacement == "string" ? e.replacement.slice(0, AF) : void 0;
        t.push({
            pattern: r,
            ...i !== void 0 && {
                replacement: i
            }
        });
    }
    return t;
}

function CI(e) {
    return encodeURIComponent(e);
}
var wI = Zw({
    reducerPath: "coreApi",
    baseQuery: wC,
    tagTypes: ["Client", "Conversation"],
    endpoints: (e) => ({
        getClient: e.query({
            query: ({
                url: e
            }) => ({
                url: e,
                simpleGet: !0
            }),
            transformResponse: (e) => {
                let t = e.client ? ? e.data ? ? e,
                    n = W(t.ui_settings ? ? t.uiSettings ? ? t.UI_SETTINGS),
                    r = W(n ? .chat ? ? n ? .CHAT ? ? n ? .Chat),
                    i = GF(t);
                return {
                    handle: t.handle ? ? t.HANDLE ? ? "",
                    bot_id: t.bot_id ? ? t._id ? ? t.BOT_ID ? ? "",
                    language: t.language ? ? t.LANGUAGE ? ? "en",
                    tint_color: t.tint ? ? t.tint_color ? ? t.TINT_COLOR ? ? "",
                    pusher_key: "",
                    pusher_cluster: "",
                    features: t.features ? ? t.FEATURES ? ? {},
                    translated_languages: UF(t.translated_languages ? ? t.translatedLanguages ? ? t.TRANSLATED_LANGUAGES),
                    email_transcript_enabled: jF(r ? .emailTranscriptSetting ? ? r ? .email_transcript_setting ? ? r ? .EMAIL_TRANSCRIPT_SETTING) ? ? !0,
                    download_transcript_enabled: jF(r ? .downloadTranscriptToggle ? ? r ? .download_transcript_toggle ? ? r ? .DOWNLOAD_TRANSCRIPT_TOGGLE) ? ? !1,
                    file_upload_enabled: jF(r ? .fileUploadEnabled ? ? r ? .file_upload_enabled ? ? r ? .FILE_UPLOAD_ENABLED) ? ? !0,
                    image_upload_enabled: jF(r ? .imageUploadEnabled ? ? r ? .image_upload_enabled ? ? r ? .IMAGE_UPLOAD_ENABLED ? ? r ? .fileUploadEnabled ? ? r ? .file_upload_enabled ? ? r ? .FILE_UPLOAD_ENABLED) ? ? !0,
                    show_branding: jF(t.show_logo ? ? t.showLogo ? ? t.show_branding ? ? t.showBranding) ? ? !1,
                    bot_name: IF(r ? .botName ? ? r ? .bot_name),
                    bot_name_translations: LF(r ? .botName ? ? r ? .bot_name),
                    bot_description: IF(r ? .botDescription ? ? r ? .bot_description),
                    bot_description_enabled: jF(r ? .botDescriptionEnabled ? ? r ? .bot_description_enabled) ? ? !0,
                    bot_avatar_url: W(t.avatar) ? .use_letter === !0 ? null : RF(W(t.avatar) ? .image),
                    style: VF(r ? .style ? ? r ? .STYLE),
                    text_size: HF(r ? .textSize ? ? r ? .text_size),
                    header_color_enabled: jF(r ? .headerColorEnabled ? ? r ? .header_color_enabled) ? ? !1,
                    header_color: G(r ? .headerColor ? ? r ? .header_color),
                    header_text_color: G(r ? .headerTextColor ? ? r ? .header_text_color),
                    chat_enabled: Bv(t) ? ? !0,
                    privacy_link: G(t.privacy_link ? ? t.privacyLink),
                    privacy: jF(t.privacy) ? ? !1,
                    theme: KF(r ? .theme ? ? r ? .THEME),
                    advanced_colors_enabled: jF(r ? .advancedColorsEnabled ? ? r ? .advanced_colors_enabled) ? ? !1,
                    text_over_accent_color: G(r ? .textOverAccentColor ? ? r ? .text_over_accent_color),
                    button_layout_mobile: i.mobile,
                    button_layout_desktop: i.desktop,
                    show_all_quick_replies: jF(t.show_all_quick_replies ? ? t.showAllQuickReplies) ? ? !1,
                    fallback_ui: _I(r ? .fallbackUi ? ? r ? .fallback_ui),
                    allowed_protocols: UF(W(W(t.security_settings ? ? t.securitySettings) ? .chat ? ? t.security_settings ? ? t.securitySettings) ? .allowedProtocols ? ? W(W(t.security_settings ? ? t.securitySettings) ? .chat ? ? t.security_settings ? ? t.securitySettings) ? .allowed_protocols),
                    iframe_allow_list: UF(W(W(t.security_settings ? ? t.securitySettings) ? .chat ? ? t.security_settings ? ? t.securitySettings) ? .iframe_allow_list ? ? W(W(t.security_settings ? ? t.securitySettings) ? .chat ? ? t.security_settings ? ? t.securitySettings) ? .iframeAllowList),
                    custom_redactions: SI(t.custom_redactions ? ? t.customRedactions ? ? t.CUSTOM_REDACTIONS),
                    ada_partner_name: PF(W(t.private_config ? ? t.privateConfig)),
                    persistence: zx.includes(t.persistence) ? t.persistence : "normal",
                    time_to_expiry: FF(t.time_to_expiry ? ? t.timeToExpiry),
                    rollout: typeof t.rollout == "number" ? t.rollout : null,
                    greeting: t.greeting ? ? t.GREETING,
                    intro: xI(t.intro ? ? t.INTRO),
                    button: (() => {
                        let e = W(t.button ? ? t.chat_button);
                        if (!e) return;
                        let r = W(n ? .embed ? ? n ? .EMBED),
                            i = G(r ? .style) === "text",
                            a = W(r ? .button_text ? ? r ? .buttonText),
                            o = Object.fromEntries(Object.entries(a ? ? {}).filter((e) => typeof e[1] == "string" && e[1].length > 0));
                        return {
                            icon_type: G(e.icon_type) ? ? "default",
                            icon_path: G(e.icon_path) ? ? "",
                            text_enabled: i,
                            text_by_language: o,
                            size: typeof e.size == "number" ? e.size : void 0,
                            background_color: G(e.background_color) || G(t.tint_color ? ? t.tint) || "#2563EB"
                        };
                    })(),
                    avatar: t.avatar ? {
                        letter: G(t.avatar.letter) ? ? "",
                        image: qF(t.avatar.image) || null,
                        use_letter: t.avatar.use_letter === !0
                    } : void 0,
                    agent_avatar: t.agent_avatar ? {
                        default: t.agent_avatar.default !== !1,
                        image: qF(t.agent_avatar.image) || null
                    } : void 0,
                    saml_login_button: JA(t.saml_login_button ? ? t.samlLoginButton),
                    proactive_conversations: vI(t.proactive_conversations ? ? t.proactiveConversations),
                    websocket_endpoint: null
                };
            },
            providesTags: ["Client"]
        }),
        getClientConfig: e.query({
            query: ({
                url: e,
                timeoutMs: t
            }) => ({
                url: e,
                timeoutMs: t
            }),
            transformResponse: (e) => {
                let t = W(e),
                    n = W(t ? .data) ? ? t ? ? {};
                return {
                    pusher_key: n.pusher_key ? ? n.PUSHER_KEY ? ? "",
                    pusher_cluster: n.pusher_cluster ? ? n.PUSHER_CLUSTER ? ? "",
                    pusher_fallback_allowed: typeof n.pusher_fallback_allowed == "boolean" ? n.pusher_fallback_allowed : void 0,
                    turnstile_site_key: typeof n.CF_TURNSTILE_SITE_KEY == "string" ? n.CF_TURNSTILE_SITE_KEY : null,
                    messaging_session_cookie_enabled: n.messaging_session_cookie_enabled === !0,
                    zendeskMessagingChatterAuth: n.zendeskMessagingChatterAuth === !0,
                    websocket_endpoint: typeof(n.websocket_endpoint ? ? n.WS_GATEWAY_ENDPOINT) == "string" ? n.websocket_endpoint ? ? n.WS_GATEWAY_ENDPOINT : null
                };
            }
        }),
        sendMessage: e.mutation({
            query: ({
                endpoint: e,
                body: t,
                chatterToken: n,
                sessionId: r,
                messageType: i,
                playbookId: a,
                metaFields: o,
                sensitiveMetaFields: s,
                conversationId: c,
                handoffPlatform: l,
                url: u,
                mimeType: d,
                name: f,
                s3Key: p,
                caption: m,
                attachmentGroupId: h,
                attachmentGroupFinal: g,
                data: _,
                buttonType: v,
                handoffContinuation: y,
                tempMessageUuid: b
            }) => ({
                url: `${e}message/${y ? "handoff_media" : "chat"}/`,
                method: "POST",
                body: {
                    ...t !== void 0 && {
                        body: t
                    },
                    by: n,
                    type: i ? ? "text",
                    ...a !== void 0 && {
                        playbook_id: a
                    },
                    ...o !== void 0 && {
                        meta_fields: o
                    },
                    ...s !== void 0 && {
                        sensitive_meta_fields: s
                    },
                    temp_message_uuid: b ? ? iT(),
                    external_chat_id: r,
                    ...c !== void 0 && {
                        conversation_id: c
                    },
                    ...l !== void 0 && {
                        handoff_platform: l
                    },
                    data: _ ? ? null,
                    ...u !== void 0 && {
                        url: u
                    },
                    ...d !== void 0 && {
                        mime_type: d
                    },
                    ...f !== void 0 && {
                        name: f
                    },
                    ...p !== void 0 && {
                        s3_key: p
                    },
                    ...m !== void 0 && {
                        caption: m
                    },
                    ...h !== void 0 && {
                        attachment_group_id: h
                    },
                    ...g !== void 0 && {
                        attachment_group_final: g
                    },
                    ...v != null && {
                        button_type: v
                    }
                }
            })
        }),
        uploadMessagingAttachment: e.mutation({
            query: ({
                endpoint: e,
                conversationId: t,
                file: n
            }) => {
                let r = new FormData();
                return r.append("file", n, n.name || "image"), {
                    url: `${e}messaging/attachments`,
                    method: "POST",
                    params: {
                        conversation_id: t
                    },
                    body: r,
                    timeoutMs: NF
                };
            },
            transformResponse: (e) => ({
                url: typeof e.url == "string" ? e.url : "",
                mime_type: typeof e.mime_type == "string" ? e.mime_type : "",
                filename: typeof e.filename == "string" ? e.filename : "",
                ...typeof e.s3_key == "string" ? {
                    s3_key: e.s3_key
                } : {}
            })
        }),
        createChatter: e.mutation({
            query: ({
                endpoint: e,
                language: t,
                metaFields: n,
                sensitiveMetaFields: r,
                zendeskChatterAuthToken: i,
                persistenceMode: a
            }) => ({
                url: `${e}chatters/`,
                method: "POST",
                credentials: "include",
                headers: a === "normal" ? {
                    "X-Ada-Session-Cookie-Eligible": "true"
                } : void 0,
                body: {
                    ...i ? {
                        zendesk_chatter_auth_token: i
                    } : {},
                    storage: {
                        meta_variables: {
                            ...n,
                            ...t ? {
                                language: t
                            } : {}
                        },
                        sensitive_meta_variables: { ...r ? ? {}
                        }
                    }
                }
            }),
            transformResponse: (e) => {
                let t = e.data ? ? e;
                return {
                    token: t.token ? ? "",
                    id: t.id ? ? t._id ? ? "",
                    zendeskAuthExpireIn: DF(W(t.zendesk_chatter_auth_results) ? .expire_in, void 0, 0),
                    sessionToken: t.session_token ? ? t.sessionToken,
                    messagingToken: t.messaging_token ? ? t.messagingToken,
                    messagingTokenExpiresIn: DF(t.messaging_token_expires_in, t.messagingTokenExpiresIn, void 0),
                    sessionCookieIssued: jF(t.session_cookie_set),
                    sessionRefreshToken: t.session_refresh_token ? ? t.sessionRefreshToken,
                    refreshGeneration: DF(t.refresh_generation, t.refreshGeneration, void 0),
                    playAlertChime: typeof t.play_alert_chime == "boolean" ? t.play_alert_chime : void 0,
                    deviceNotificationsEnabled: typeof t.device_notifications_enabled == "boolean" ? t.device_notifications_enabled : void 0,
                    smsNotificationsEnabled: typeof t.sms_notifications_enabled == "boolean" ? t.sms_notifications_enabled : void 0,
                    saml: qA(t.saml)
                };
            }
        }),
        identifyMessagingToken: e.mutation({
            query: ({
                endpoint: e,
                identityToken: t
            }) => ({
                url: `${e}auth/tokens/identify`,
                method: "POST",
                credentials: "include",
                body: {
                    identity_token: t
                }
            }),
            transformResponse: (e) => {
                let t = e.data ? ? e;
                return {
                    token: G(t.token ? ? t.chatter_token) ? ? "",
                    id: G(t.id ? ? t._id ? ? t.chatter_id) ? ? "",
                    sessionToken: G(t.session_token) ? ? void 0,
                    messagingToken: G(t.messaging_token) ? ? void 0,
                    messagingTokenExpiresIn: typeof t.messaging_token_expires_in == "number" ? t.messaging_token_expires_in : void 0,
                    sessionCookieIssued: jF(t.session_cookie_set),
                    sessionRefreshToken: G(t.session_refresh_token) ? ? void 0,
                    refreshGeneration: typeof t.refresh_generation == "number" ? t.refresh_generation : void 0,
                    saml: qA(t.saml)
                };
            }
        }),
        updateChatterDataStorage: e.mutation({
            query: ({
                endpoint: e,
                metaFields: t,
                sensitiveMetaFields: n
            }) => ({
                url: `${e}chatters/data_storage/`,
                method: "PATCH",
                body: {
                    ...t && Object.keys(t).length > 0 ? {
                        meta_variables: t
                    } : {},
                    ...n && Object.keys(n).length > 0 ? {
                        sensitive_meta_variables: n
                    } : {}
                }
            }),
            transformResponse: (e) => {
                let t = e.data ? ? e;
                return {
                    message: typeof t.message == "string" ? t.message : void 0
                };
            }
        }),
        getChatterRestoreState: e.mutation({
            query: ({
                endpoint: e,
                chatterToken: t
            }) => ({
                url: `${e}chatters/chat/${CI(t)}/`,
                method: "GET"
            }),
            transformResponse: (e) => {
                let t = e.data ? ? e,
                    n = typeof t.chatter == "object" && t.chatter !== null ? t.chatter : t;
                return {
                    language: typeof n.language == "string" && n.language ? n.language : void 0
                };
            }
        }),
        submitMessageReview: e.mutation({
            query: ({
                endpoint: e,
                conversationId: t,
                responseMessageId: n,
                review: r,
                chatterToken: i
            }) => ({
                url: `${e}message/review/${CI(t)}/`,
                method: "POST",
                body: {
                    type: "review",
                    review: r,
                    response_message_id: n,
                    by: i
                }
            })
        }),
        createEvent: e.mutation({
            query: ({
                endpoint: e,
                chatterToken: t,
                type: n,
                params: r
            }) => ({
                url: `${e}events/`,
                method: "POST",
                body: {
                    by: t,
                    type: n,
                    ...r
                },
                beacon: !0,
                bindLifecycleSignal: !1
            })
        }),
        getJsEventData: e.query({
            query: ({
                endpoint: e
            }) => ({
                url: `${e}chatters/js-event-data/`,
                method: "GET"
            }),
            transformResponse: (e) => {
                let t = (e.data ? ? e).chatter_data;
                return t && typeof t == "object" ? t : {};
            }
        }),
        updateChatterSettings: e.mutation({
            query: ({
                endpoint: e,
                chatterToken: t,
                playAlertChime: n,
                deviceNotificationsEnabled: r,
                smsNotificationsEnabled: i,
                language: a
            }) => ({
                url: `${e}chatters/chat/${CI(t)}/`,
                method: "PATCH",
                body: {
                    ...typeof n == "boolean" ? {
                        play_alert_chime: n
                    } : {},
                    ...typeof r == "boolean" ? {
                        device_notifications_enabled: r
                    } : {},
                    ...typeof i == "boolean" ? {
                        sms_notifications_enabled: i
                    } : {},
                    ...typeof a == "string" ? {
                        language: a
                    } : {}
                }
            }),
            transformResponse: (e) => {
                let t = e.data ? ? e,
                    n = typeof t.chatter == "object" && t.chatter !== null ? t.chatter : t;
                return {
                    playAlertChime: typeof n.play_alert_chime == "boolean" ? n.play_alert_chime : void 0,
                    deviceNotificationsEnabled: typeof n.device_notifications_enabled == "boolean" ? n.device_notifications_enabled : void 0,
                    smsNotificationsEnabled: typeof n.sms_notifications_enabled == "boolean" ? n.sms_notifications_enabled : void 0,
                    language: typeof n.language == "string" ? n.language : void 0
                };
            }
        }),
        sendGreeting: e.mutation({
            query: ({
                endpoint: e,
                chatterToken: t,
                language: n,
                sessionId: r,
                greeting: i
            }) => ({
                url: `${e}message/chat/`,
                method: "POST",
                body: {
                    by: t,
                    type: "greeting",
                    temp_message_uuid: iT(),
                    external_chat_id: r,
                    body: "",
                    data: null,
                    language: n,
                    ...i
                }
            })
        }),
        sendProactiveConversation: e.mutation({
            query: ({
                endpoint: e,
                chatterToken: t,
                language: n,
                proactiveKey: r,
                messageParameters: i
            }) => ({
                url: `${e}proactive_conversations/message`,
                method: "POST",
                body: {
                    chatter_token: t,
                    proactive_conversation_key: r,
                    platform: "chat",
                    language: n,
                    message_parameters: i
                }
            })
        }),
        refreshMessagingToken: e.mutation({
            queryFn: async ({
                endpoint: e
            }, t, n, r) => {
                let i = t.getState().session,
                    a = await r({
                        url: `${e}auth/tokens/refresh`,
                        method: "POST",
                        credentials: "include",
                        body: {
                            trigger: "expired_before_send",
                            ...XS(i)
                        }
                    });
                if (a.error) return {
                    error: a.error
                };
                let o = a.data,
                    s = o.data ? ? o;
                return {
                    data: {
                        messagingToken: s.messaging_token ? ? s.messagingToken ? ? "",
                        expiresIn: DF(s.expires_in, s.expiresIn, 1800),
                        sessionRefreshToken: s.session_refresh_token ? ? s.sessionRefreshToken,
                        sessionCookieIssued: jF(s.session_cookie_set),
                        refreshGeneration: DF(s.refresh_generation, s.refreshGeneration, void 0)
                    }
                };
            }
        }),
        getRecentConversation: e.query({
            query: ({
                endpoint: e,
                chatterToken: t
            }) => ({
                url: `${e}conversations/recent/chat/${CI(t)}/`
            }),
            transformResponse: (e) => {
                let t = e.data ? ? e,
                    n = Array.isArray(t.conversations) ? t.conversations : [];
                return {
                    conversationIds: n.map((e) => typeof e._id == "string" ? e._id : null).filter((e) => e !== null),
                    activeHandoff: oI(n[0]),
                    activeCapture: sI(n[0]),
                    conversationEnded: cI(n[0]),
                    activeListSelection: lI(n[0]),
                    widgetAppPending: uI(n[0])
                };
            }
        }),
        getConversationLogs: e.query({
            query: ({
                endpoint: e,
                chatterToken: t,
                conversationId: n,
                after: r
            }) => ({
                url: `${e}logs/${CI(t)}/`,
                params: {
                    conversation_id: n,
                    page_size: "25",
                    ...r && {
                        after: r
                    }
                }
            })
        }),
        getMessagesAfterCursor: e.query({
            query: ({
                endpoint: e,
                afterCursor: t
            }) => ({
                url: `${e}messaging/messages`,
                params: {
                    after_cursor: EF(t)
                }
            }),
            transformResponse: (e) => {
                let t = e.data ? ? e;
                return {
                    messages: Array.isArray(t.messages) ? t.messages : [],
                    ...typeof t.page_max_cursor == "string" ? {
                        page_max_cursor: t.page_max_cursor
                    } : {},
                    ...typeof t.has_more == "boolean" ? {
                        has_more: t.has_more
                    } : {},
                    ...typeof t.conversation_id == "string" || t.conversation_id === null ? {
                        conversation_id: t.conversation_id
                    } : {}
                };
            }
        }),
        submitZendeskChatterAuth: e.mutation({
            query: ({
                endpoint: e,
                chatterToken: t,
                token: n
            }) => ({
                url: `${e}chatters/${CI(t)}/zendesk_chatter_auth/`,
                method: "PATCH",
                body: {
                    zendesk_chatter_auth_token: n
                }
            }),
            transformResponse: (e) => {
                let t = e.data ? ? e,
                    n = typeof t.zendesk_chatter_auth_results == "object" && t.zendesk_chatter_auth_results !== null ? t.zendesk_chatter_auth_results : t;
                return {
                    expireIn: typeof n.expire_in == "number" ? n.expire_in : 0,
                    ...typeof n.status == "string" ? {
                        status: n.status
                    } : {}
                };
            }
        })
    })
});
//#endregion
export {
    IM as $, Rb as $a, xC as $i, lO as $n, vs as $o, gE as $r, No as $s, cA as $t, IN as A, Fx as Aa, HT as Ai, nk as An, xv as Ao, yD as Ar, Js as As, RA as At, zN as B, dx as Ba, OT as Bi, Tk as Bn, pv as Bo, GT as Br, ps as Bs, SA as Bt, KP as C, cS as Ca, fD as Ci, ck as Cn, G as Co, EO as Cr, nc as Cs, ej as Ct, _N as D, zx as Da, hD as Di, _O as Dn, bv as Do, AO as Dr, Ls as Ds, zA as Dt, $ as E, aS as Ea, mD as Ei, vO as En, Mv as Eo, dk as Er, ic as Es, tj as Et, EN as F, jx as Fa, NT as Fi, wk as Fn, fv as Fo, YT as Fr, Hs as Fs, vA as Ft, Q as G, Wb as Ga, gT as Gi, SO as Gn, hc as Go, FE as Gr, Ro as Gs, TA as Gt, LN as H, Jb as Ha, wT as Hi, vk as Hn, Sv as Ho, lE as Hr, L as Hs, wA as Ht, TN as I, Ax as Ia, FT as Ii, Ck as In, vv as Io, WT as Ir, Us as Is, yA as It, VM as J, zb as Ja, hT as Ji, kO as Jn, cc as Jo, RE as Jr, Zo as Js, fA as Jt, BM as K, Vb as Ka, pT as Ki, CO as Kn, oc as Ko, IE as Kr, es as Ks, mA as Kt, DN as L, Mx as La, MT as Li, Sk as Ln, Dv as Lo, UT as Lr, Ns as Ls, bA as Lt, MN as M, Rx as Ma, zT as Mi, _k as Mn, cv as Mo, bD as Mr, qs as Ms, jA as Mt, NN as N, Nx as Na, DT as Ni, gk as Nn, _v as No, _D as Nr, Gs as Ns, MA as Nt, PN as O, Vx as Oa, Z as Oi, YO as On, yv as Oo, oO as Or, rc as Os, IA as Ot, jN as P, Px as Pa, IT as Pi, xk as Pn, mv as Po, ZT as Pr, Ws as Ps, DA as Pt, RM as Q, Pb as Qa, yC as Qi, BO as Qn, Vs as Qo, mE as Qr, I as Qs, aA as Qt, kN as R, Lx as Ra, LT as Ri, yk as Rn, Ov as Ro, KT as Rr, Ms as Rs, xA as Rt, FP as S, J as Sa, dD as Si, sk as Sn, W as So, DO as Sr, ys as Ss, QA as St, RP as T, sS as Ta, SE as Ti, FO as Tn, Nv as To, wO as Tr, Ds as Ts, $A as Tt, gN as U, Gb as Ua, CT as Ui, kk as Un, hv as Uo, yE as Ur, R as Us, kA as Ut, RN as V, qb as Va, ET as Vi, Ek as Vn, dv as Vo, JT as Vr, P as Vs, CA as Vt, WM as W, Ub as Wa, bT as Wi, Dk as Wn, $_ as Wo, PE as Wr, F as Ws, EA as Wt, zM as X, Lb as Xa, dT as Xi, Mk as Xn, Ps as Xo, vE as Xr, Wo as Xs, lA as Xt, PM as Y, Fb as Ya, _T as Yi, OO as Yn, dc as Yo, zE as Yr, Go as Ys, hA as Yt, LM as Z, Mb as Za, iT as Zi, pk as Zn, ls as Zo, _E as Zr, Yo as Zs, oA as Zt, hF as _, vS as _a, sD as _i, ek as _n, $v as _o, WO as _r, $s as _s, ij as _t, fF as a, US as aa, _r as ac, JE as ai, Zk as an, Py as ao, gO as ar, us as as, wM as at, _F as b, fS as ba, uD as bi, QO as bn, Wv as bo, yO as br, Rs as bs, fj as bt, rF as c, ZS as ca, j as cc, XE as ci, zk as cn, Vy as co, MO as cr, tc as cs, Mj as ct, lF as d, zS as da, nD as di, Hk as dn, Oy as do,
    Ak as dr, As as ds, _j as dt, LS as ea, Ao as ec, HE as ei, sA as en, jb as eo, uO as er, hs as es, kM as et, sF as f, DS as fa, rD as fi, Uk as fn, fy as fo, jk as fr, _s as fs, yj as ft, yF as g, hS as ga, oD as gi, ZO as gn, oy as go, PO as gr, fs as gs, oj as gt, gF as h, mS as ha, QE as hi, Kk as hn, cy as ho, mO as hr, Zs as hs, uj as ht, iF as i, Y as ia, xr as ic, qE as ii, Jk as in , tb as io, cO as ir, ds as is, OM as it, yN as j, q as ja, RT as ji, IO as jn, Ev as jo, vD as jr, Ks as js, NA as jt, FN as k, Hx as ka, VT as ki, JO as kn, tv as ko, aO as kr, ks, LA as kt, dF as l, $S as la, lr as lc, iD as li, Bk as ln, My as lo, NO as lr, Fs as ls, Aj as lt, vF as m, gS as ma, ZE as mi, Gk as mn, sy as mo, hO as mr, Os as ms, lj as mt, SF as n, uC as na, jo as nc, GE as ni, Qk as nn, Sb as no, pO as nr, gs as ns, DM as nt, aF as o, XS as oa, Cr as oc, YE as oi, Lk as on, Uy as oo, iO as or, Es as os, Yj as ot, oF as p, bS as pa, aD as pi, Wk as pn, py as po, sO as pr, bs as ps, hj as pt, FM as q, Bb as qa, mT as qi, dO as qn, sc as qo, LE as qr, $o as qs, pA as qt, CF as r, lC as ra, xa as rc, KE as ri, Xk as rn, lb as ro, fO as rr, Cs as rs, oM as rt, uF as s, BS as sa, Sr as sc, eD as si, Rk as sn, Hy as so, VO as sr, Ts as ss, Uj as st, wI as t, hC as ta, Mo as tc, UE as ti, $k as tn, Db as to, rO as tr, ms as ts, gM as tt, cF as u, cC as ua, tD as ui, Vk as un, ky as uo, jO as ur, Bs as us, Rj as ut, bF as v, _S as va, cD as vi, XO as vn, Hv as vo, UO as vr, ec as vs, aj as vt, iP as w, oS as wa, $E as wi, lk as wn, Fv as wo, TO as wr, zs as ws, ZA as wt, MP as x, uS as xa, pD as xi, ok as xn, Rv as xo, bO as xr, Is as xs, sj as xt, wF as y, dS as ya, lD as yi, $O as yn, Kv as yo, uk as yr, Xs as ys, pj as yt, BN as z, fx as za, PT as zi, Ok as zn, kv as zo, qT as zr, js as zs, OA as zt
};

//# sourceMappingURL=api-DSWB8HJZ.js.map