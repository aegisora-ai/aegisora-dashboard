import {
    i as e
} from "./chunk-DeC0fbbY.js";
import {
    $ as t,
    $a as n,
    $n as r,
    $o as i,
    $r as a,
    $s as o,
    $t as s,
    A as c,
    Aa as l,
    Ai as u,
    An as d,
    Ao as f,
    Ar as p,
    As as m,
    At as h,
    B as g,
    Ba as _,
    Bi as v,
    Bn as y,
    Bo as b,
    Br as x,
    Bs as S,
    Bt as C,
    C as w,
    Ca as T,
    Ci as E,
    Cn as D,
    Co as O,
    Cr as ee,
    Cs as k,
    Ct as A,
    D as j,
    Da as te,
    Di as ne,
    Dn as M,
    Do as re,
    Dr as ie,
    Ds as N,
    Dt as ae,
    E as oe,
    Ea as se,
    Ei as ce,
    En as le,
    Eo as ue,
    Er as de,
    Es as fe,
    Et as pe,
    F as me,
    Fa as he,
    Fi as ge,
    Fn as _e,
    Fo as ve,
    Fr as ye,
    Fs as be,
    Ft as xe,
    G as Se,
    Ga as Ce,
    Gi as we,
    Gn as Te,
    Go as Ee,
    Gr as De,
    Gs as Oe,
    Gt as ke,
    H as Ae,
    Ha as je,
    Hi as Me,
    Hn as Ne,
    Ho as Pe,
    Hr as Fe,
    Hs as Ie,
    Ht as Le,
    I as Re,
    Ia as ze,
    Ii as Be,
    In as Ve,
    Io as He,
    Ir as Ue,
    Is as We,
    It as Ge,
    J as Ke,
    Ja as qe,
    Ji as Je,
    Jn as Ye,
    Jr as Xe,
    Js as Ze,
    Jt as Qe,
    K as $e,
    Ka as et,
    Ki as tt,
    Kn as nt,
    Ko as rt,
    Kr as it,
    Ks as at,
    Kt as ot,
    L as st,
    La as ct,
    Li as lt,
    Ln as ut,
    Lo as dt,
    Lr as ft,
    Ls as pt,
    Lt as mt,
    M as ht,
    Ma as gt,
    Mi as _t,
    Mn as vt,
    Mo as yt,
    Mr as bt,
    Ms as xt,
    Mt as St,
    N as Ct,
    Na as P,
    Ni as wt,
    Nn as Tt,
    No as Et,
    Nr as Dt,
    Ns as Ot,
    Nt as kt,
    O as At,
    Oa as jt,
    Oi as Mt,
    On as Nt,
    Oo as Pt,
    Or as Ft,
    Os as It,
    Ot as Lt,
    P as Rt,
    Pa as zt,
    Pi as Bt,
    Pn as Vt,
    Po as Ht,
    Pr as Ut,
    Ps as Wt,
    Pt as Gt,
    Q as Kt,
    Qa as qt,
    Qn as Jt,
    Qo as Yt,
    Qr as Xt,
    Qs as Zt,
    Qt,
    R as $t,
    Ra as en,
    Ri as tn,
    Rn as nn,
    Ro as rn,
    Rr as an,
    Rs as on,
    Rt as sn,
    S as cn,
    Sa as ln,
    Si as un,
    Sn as dn,
    So as F,
    Sr as fn,
    Ss as pn,
    St as mn,
    T as hn,
    Ta as gn,
    Ti as _n,
    Tn as vn,
    To as yn,
    Tr as bn,
    Ts as xn,
    Tt as Sn,
    U as Cn,
    Ua as wn,
    Ui as Tn,
    Un as En,
    Uo as Dn,
    Ur as On,
    Us as kn,
    Ut as An,
    V as jn,
    Va as Mn,
    Vi as Nn,
    Vn as Pn,
    Vo as Fn,
    Vr as In,
    Vs as Ln,
    Vt as Rn,
    Wi as zn,
    Wn as Bn,
    Wo as Vn,
    Wr as Hn,
    Ws as Un,
    Wt as Wn,
    X as Gn,
    Xa as Kn,
    Xi as I,
    Xn as qn,
    Xo as Jn,
    Xr as Yn,
    Xs as Xn,
    Xt as Zn,
    Y as Qn,
    Ya as $n,
    Yi as er,
    Yn as tr,
    Yo as nr,
    Yr as rr,
    Ys as ir,
    Yt as ar,
    Z as or,
    Za as sr,
    Zi as cr,
    Zn as lr,
    Zo as ur,
    Zr as dr,
    Zs as fr,
    Zt as pr,
    _ as mr,
    _a as hr,
    _i as gr,
    _n as _r,
    _o as vr,
    _r as yr,
    _s as br,
    _t as xr,
    a as Sr,
    aa as Cr,
    ac as wr,
    ai as Tr,
    an as Er,
    ao as Dr,
    ar as Or,
    as as kr,
    at as Ar,
    b as jr,
    ba as Mr,
    bi as Nr,
    bn as Pr,
    bo as Fr,
    br as Ir,
    bs as Lr,
    bt as Rr,
    c as zr,
    ca as Br,
    cc as L,
    ci as Vr,
    cn as Hr,
    co as Ur,
    cr as Wr,
    cs as Gr,
    ct as Kr,
    d as qr,
    da as Jr,
    di as Yr,
    dn as Xr,
    do as Zr,
    dr as Qr,
    ds as $r,
    dt as ei,
    ea as ti,
    ec as ni,
    ei as ri,
    en as ii,
    eo as ai,
    er as oi,
    es as si,
    et as ci,
    f as li,
    fa as ui,
    fi as di,
    fn as fi,
    fo as pi,
    fr as mi,
    fs as hi,
    ft as gi,
    g as _i,
    ga as vi,
    gi as yi,
    gn as bi,
    go as xi,
    gr as Si,
    gs as Ci,
    gt as wi,
    h as Ti,
    ha as Ei,
    hi as Di,
    hn as Oi,
    ho as ki,
    hr as Ai,
    hs as ji,
    ht as Mi,
    i as Ni,
    ia as Pi,
    ic as Fi,
    ii as Ii,
    in as Li,
    io as Ri,
    ir as zi,
    is as Bi,
    it as Vi,
    j as Hi,
    ja as R,
    ji as Ui,
    jn as Wi,
    jo as Gi,
    jr as Ki,
    js as qi,
    jt as Ji,
    k as Yi,
    ka as Xi,
    ki as z,
    kn as Zi,
    ko as Qi,
    kr as $i,
    ks as ea,
    kt as ta,
    l as na,
    la as ra,
    lc as B,
    li as ia,
    ln as aa,
    lo as oa,
    lr as sa,
    ls as ca,
    lt as la,
    m as ua,
    ma as da,
    mi as fa,
    mn as pa,
    mr as V,
    ms as ma,
    mt as ha,
    n as ga,
    na as _a,
    nc as va,
    ni as ya,
    nn as ba,
    no as xa,
    nr as Sa,
    ns as Ca,
    nt as wa,
    o as Ta,
    oa as Ea,
    oc as H,
    oi as Da,
    on as Oa,
    oo as ka,
    or as Aa,
    os as ja,
    ot as Ma,
    p as Na,
    pa as Pa,
    pi as Fa,
    pn as Ia,
    po as La,
    pr as Ra,
    ps as za,
    pt as Ba,
    q as Va,
    qa as Ha,
    qi as Ua,
    qn as Wa,
    qo as Ga,
    qr as U,
    qs as Ka,
    qt as qa,
    r as Ja,
    ra as Ya,
    rc as Xa,
    ri as Za,
    rn as Qa,
    ro as $a,
    rr as eo,
    rs as to,
    rt as no,
    s as ro,
    sa as io,
    sc as W,
    si as ao,
    sn as oo,
    so,
    sr as co,
    ss as lo,
    st as uo,
    t as G,
    ta as fo,
    tc as po,
    ti as mo,
    tn as ho,
    to as go,
    tr as _o,
    ts as vo,
    u as yo,
    ua as bo,
    ui as xo,
    un as So,
    uo as Co,
    ur as wo,
    us as To,
    ut as Eo,
    v as Do,
    va as Oo,
    vi as ko,
    vn as Ao,
    vo as jo,
    vr as Mo,
    vs as No,
    vt as Po,
    w as Fo,
    wa as Io,
    wi as Lo,
    wn as Ro,
    wo as zo,
    wr as Bo,
    ws as Vo,
    wt as Ho,
    x as Uo,
    xa as Wo,
    xi as Go,
    xn as Ko,
    xo as qo,
    xr as Jo,
    xs as Yo,
    xt as Xo,
    y as Zo,
    ya as Qo,
    yi as $o,
    yn as es,
    yo as ts,
    yr as ns,
    ys as rs,
    yt as is,
    z as as,
    za as os,
    zi as ss,
    zn as cs,
    zo as ls,
    zr as us,
    zs as ds,
    zt as fs
} from "./api-DSWB8HJZ.js";
//#region ../../shared/utils/src/browser-polyfills.ts
var ps = Object.prototype.hasOwnProperty;

function ms(e, t, n) {
    Object.defineProperty(e, t, {
        value: n,
        configurable: !0,
        writable: !0
    });
}
Object.hasOwn || ms(Object, "hasOwn", (e, t) => {
    if (e == null) throw TypeError("ada browser-polyfills: Cannot convert undefined or null to object");
    return ps.call(Object(e), t);
});

function hs(e) {
    let t = Math.trunc(Number(this.length)) || 0,
        n = Math.trunc(Number(e)) || 0;
    return n < 0 && (n += t), n < 0 || n >= t ? void 0 : this[n];
}

function gs(e) {
    let t = String(this),
        n = t.length,
        r = Math.trunc(Number(e)) || 0;
    return r < 0 && (r += n), r < 0 || r >= n ? void 0 : t.charAt(r);
}
var _s = [
    globalThis.Int8Array,
    globalThis.Uint8Array,
    globalThis.Uint8ClampedArray,
    globalThis.Int16Array,
    globalThis.Uint16Array,
    globalThis.Int32Array,
    globalThis.Uint32Array,
    globalThis.Float32Array,
    globalThis.Float64Array,
    globalThis.BigInt64Array,
    globalThis.BigUint64Array
].filter(Boolean);
Array.prototype.at || ms(Array.prototype, "at", hs), String.prototype.at || ms(String.prototype, "at", gs);
for (let e of _s) {
    let t = e.prototype;
    t.at || ms(t, "at", hs);
}
//#endregion
//#region src/activation-outage.ts
var vs = B("activation-outage"),
    ys = 15e3;

function bs(e) {
    let t = null,
        n = null;

    function r() {
        t ? .(), t = null, n && = (clearTimeout(n), null);
    }

    function i() {
        let {
            connectivityLost: t,
            connectivityVerdictPending: n
        } = e.getState().connection;
        return t || n;
    }
    return {
        raise(a) {
            if (r(), !i()) {
                a();
                return;
            }
            let o = () => {
                r(), a();
            };
            t = e.subscribe(() => {
                i() || o();
            }), n = setTimeout(() => {
                n = null, !e.getState().connection.connectivityLost && (vs.warn("connectivity verdict never settled; raising the activation outage anyway"), o());
            }, ys);
        },
        cancel() {
            r();
        }
    };
}
//#endregion
//#region src/orchestrator-attachment-runtime.ts
var xs = B("orchestrator"),
    Ss = new Set(ki);

function Cs(e) {
    switch (e) {
        case 400:
            return "unsupported_type";
        case 403:
        case "no_storage_key":
            return "unavailable";
        case 413:
            return "too_large";
        default:
            return "upload_failed";
    }
}

function ws(e) {
    return e.type !== "" && !Ss.has(e.type) ? "unsupported_type" : e.size > 52428800 ? "too_large" : null;
}

function Ts(e) {
    let {
        session: t,
        liveAgent: n,
        chat: r
    } = e;
    return t.hasHydratedClientConfig && t.imageUploadEnabled && !n.inLiveChat && !n.inPending && !r.widgetAppPending;
}

function Es(e) {
    return Ts(e) && e.session.conversationId !== null;
}
async function Ds(e, t, n = !1, r) {
    let i = I(),
        a = r === void 0 ? {} : {
            batchId: r
        },
        o = (n) => {
            e.dispatch(bi({
                id: i,
                error: n,
                name: t.name,
                ...a
            })), R("image_attachment_rejected", {
                reason: n
            });
        },
        s = ws(t);
    if (s) {
        o(s);
        return;
    }
    let c = e.getState();
    if (!Es(c) || !c.session.endpoint) {
        xs.warn("Image attachment dropped: control not available"), o("unavailable");
        return;
    }
    if (n && c.chat.stagedAttachments.length >= 3) {
        xs.warn("Image attachment dropped: staging limit reached"), o("too_many");
        return;
    }
    let {
        endpoint: l,
        conversationId: u
    } = c.session;
    if (!u) return;
    let d = wr(),
        f = {
            id: i,
            name: t.name,
            mimeType: t.type,
            size: t.size,
            conversationId: u
        };
    if (e.dispatch(Ao(n ? {
            ...f,
            allowMultiple: !0
        } : f)), !e.getState().chat.stagedAttachments.some((e) => e.id === f.id)) {
        xs.warn("Image attachment dropped: reducer refused the stage"), o("too_many");
        return;
    }
    R("image_attachment_upload_started", {
        size: t.size,
        mimeType: t.type || "undeclared"
    });
    let p = "unknown",
        m = null,
        h = !1;
    try {
        let n = e.dispatch(G.endpoints.uploadMessagingAttachment.initiate({
            endpoint: l,
            conversationId: u,
            file: t
        }, {
            track: !1
        }));
        m = e.subscribe(() => {
            let t = e.getState().chat.stagedAttachments.some((e) => e.id === f.id);
            !h && !t && (h = !0, n.abort());
        });
        let r = await n;
        if (h || d ? .aborted || "error" in r && r.error.name === "AbortError") return;
        if ("error" in r) {
            let e = r.error.status;
            (typeof e == "number" || typeof e == "string") && (p = e);
        } else if (r.data.url && r.data.s3_key) {
            e.dispatch(Pr({
                id: f.id,
                url: r.data.url,
                s3Key: r.data.s3_key,
                ...r.data.mime_type ? {
                    mimeType: r.data.mime_type
                } : {},
                ...r.data.filename ? {
                    name: r.data.filename
                } : {}
            })), R("image_attachment_upload_succeeded", {
                size: t.size
            });
            return;
        } else p = r.data.url ? "no_storage_key" : "empty_response";
    } catch (e) {
        xs.warn("Image attachment upload threw", {
            error: e
        });
    } finally {
        m ? .();
    }
    xs.warn("Image attachment upload failed", {
        status: p
    });
    let g = Cs(p);
    e.dispatch(es({
        id: f.id,
        error: g,
        ...a
    })), R("image_attachment_upload_failed", {
        status: p
    }), R("image_attachment_rejected", {
        reason: g
    });
}
//#endregion
//#region src/app-bridge.ts
function Os() {
    let e = new URL("../app/index.html", window.location.href),
        t = new URLSearchParams(window.location.search);
    for (let n of ["ada_handle", "ada_cluster"]) {
        let r = t.get(n);
        r && e.searchParams.set(n, r);
    }
    return La(e, pi(window.location.search)).toString();
}

function ks(e) {
    let t = e.sdkType;
    if (typeof t != "string") return null;
    let n = t.trim().toUpperCase();
    return n === "IOS" || n === "ANDROID" ? n : Kn(n) ? "REACTNATIVE" : null;
}

function As(e) {
    if (!e.sdkType) return !0;
    let t = e.sdkSupportsDownloadLink;
    return typeof t == "string" ? t.trim().toLowerCase() === "true" : t === !0;
}

function js(e, t, n) {
    return e ? t || (n ? n === "TRIAL_MODE" ? "TRIAL_MODE" : "OTHER" : null) : "BOT_DISABLED";
}
var Ms = Xa([(e) => e], (e) => {
    if (!e) return null;
    let {
        batchId: t,
        ...n
    } = e;
    return n;
});

function Ns(e, t, n) {
    let r = new Set(n),
        i = /* @__PURE__ */ new Map();
    e.forEach((e, t) => {
        if (!p(e) || r.has(e.id)) return;
        let n = e.conversationId ? ? "",
            a = i.get(n) ? ? {
                maxCursor: null,
                maxCursorlessIndex: -1,
                maxIndex: -1
            },
            o = typeof e.cursor == "string" ? e.cursor : null;
        i.set(n, {
            maxCursor: o && (a.maxCursor === null || o > a.maxCursor) ? o : a.maxCursor,
            maxCursorlessIndex: o === null ? Math.max(a.maxCursorlessIndex, t) : a.maxCursorlessIndex,
            maxIndex: Math.max(a.maxIndex, t)
        });
    });
    let a = new Set(t);
    return e.forEach((e, t) => {
        if (!bt(e)) return;
        let n = i.get(e.conversationId ? ? "");
        if (!n) return;
        let r = typeof e.cursor == "string" ? e.cursor : null;
        (r ? n.maxCursor !== null && n.maxCursor > r || n.maxCursorlessIndex > t : n.maxIndex > t) && a.add(e.id);
    }), [...a];
}
var Ps = ({
        isColleague: e,
        ...t
    }) => t,
    Fs = Xa([(e) => e.liveAgent.agents], (e) => Object.values(e).map(Ps)),
    Is = Xa([
        (e) => e.session,
        (e) => e.saml,
        (e) => e.security,
        (e) => e.connection,
        (e) => e.chat,
        (e) => e.outage,
        (e) => e.greeting,
        (e) => e.liveAgent,
        (e) => e.localization.translations,
        (e) => e.voice,
        (e) => ar(e),
        Fs,
        Xa([
            (e) => e.liveAgent.agents,
            Fs,
            (e) => e.liveAgent.inLiveChat || e.liveAgent.inPending
        ], (e, t, n) => {
            let r = Fe(e, {
                handoffOpen: n
            });
            return r ? t.find((e) => e.id === r.id) ? ? null : null;
        })
    ], (e, t, n, r, i, a, o, s, c, l, u, d, f) => {
        let p = js(e.chatEnabled, a.type, i.error),
            m = i.csatAutoTrigger && (i.csatAutoTriggerConversationId ? ? e.conversationId) === e.conversationId || i.csatSubmitSuccessSurveyType !== null && jo(i.csatSubmitSuccessSurveyType) && i.csatSubmitSuccessConversationId === e.conversationId,
            h = vr(i.csatBotSettings, e.language),
            g = vr(i.csatSettings, e.language),
            _ = i.stagedAttachments.map(({
                s3Key: e,
                conversationId: t,
                ...n
            }) => n),
            v = Er(e);
        return {
            "app.loading": !e.isConfigured || !e.chatterToken || e._chatterAnnouncementSuppressed || !e._appInteractionReady,
            "app.initialized": e.isConfigured,
            "app.conversationStartPending": e._appConversationStartPending,
            "app.testModeBannerLabel": e.testModeBannerLabel,
            "app.sessionId": e.sessionId ? ? "",
            "security.turnstileSiteKey": n.turnstileSiteKey,
            "security.challengeEnabled": !!e.features ? .challengeModeEnabled && !!n.turnstileSiteKey,
            "security.challengeError": n.challengeError,
            "config.handle": e.handle ? ? "",
            "config.features": e.features,
            "config.clientDefaultLanguage": e.clientDefaultLanguage,
            "config.translatedLanguages": e.translatedLanguages,
            "config.emailTranscriptEnabled": e.emailTranscriptEnabled,
            "config.downloadTranscriptEnabled": e.downloadTranscriptEnabled,
            "config.sdkPlatform": ks(e.metaFields),
            "config.androidHostNavigation": !e._appFrameIsCustom && e.androidHostNavigation,
            "config.sdkSupportsDownloadLink": As(e.metaFields),
            "config.showBranding": e.showBranding,
            "config.adaPartnerName": e.adaPartnerName,
            "config.botName": v.botName,
            "config.botDescription": v.botDescription,
            "config.botDescriptionEnabled": v.botDescriptionEnabled,
            "config.botAvatarUrl": v.botAvatarUrl,
            "config.tintColor": v.tintColor,
            "config.style": v.style,
            "config.textSize": v.textSize,
            "config.headerColorEnabled": v.headerColorEnabled,
            "config.headerColor": v.headerColor,
            "config.headerTextColor": v.headerTextColor,
            "config.chatEnabled": e.chatEnabled,
            "config.privacyLink": e.privacyLink,
            "config.privacy": e.privacy,
            "config.theme": e.theme,
            "config.advancedColorsEnabled": v.advancedColorsEnabled,
            "config.textOverAccentColor": v.textOverAccentColor,
            "config.buttonLayoutMobile": e.buttonLayoutMobile,
            "config.buttonLayoutDesktop": e.buttonLayoutDesktop,
            "config.showAllQuickReplies": e.showAllQuickReplies,
            "config.isMobileViewport": e.isMobileViewport,
            "appearance.userTheme": e.userTheme,
            "appearance.hostViewport": e._appFrameIsCustom ? e.hostViewport : null,
            "appearance.userTextSize": e.userTextSize,
            "config.fallbackUi": e.fallbackUi,
            "config.buttonSize": v.buttonSize,
            "config.buttonBackgroundColor": v.buttonBackgroundColor,
            "config.avatar": v.avatar,
            "config.agentAvatar": e.agentAvatar,
            "config.allowedProtocols": e.allowedProtocols ? ? [],
            "config.customRedactions": e.customRedactions ? ? [],
            "saml.locked": t.locked,
            "saml.url": t.url,
            "saml.loginButton": t.loginButton,
            "transcript.email.status": e.transcriptEmailRequestStatus,
            "transcript.email.status.seq": e.transcriptEmailRequestSeq,
            "transcript.email.conflict.email": e.transcriptEmailConflictEmail,
            "transcript.email.conflict.seq": e.transcriptEmailConflictSeq,
            "transcript.download.status": e.transcriptDownloadRequestStatus,
            "transcript.download.status.seq": e.transcriptDownloadRequestSeq,
            "connection.socket.connected": r.transportStatus === "connected",
            "connection.pusher.channelConnected": r.channelConnected,
            "chat.responseLoading": i.isTyping,
            "chat.isGenerating": i.isGenerating,
            "chat.isUnifiedReasonerGenerating": i.isUnifiedReasonerGenerating,
            "chat.isConversationActive": i.isConversationActive,
            "chat.messages": i.messages,
            "chat.isSending": i.isSending,
            "chat.error": i.error,
            "chat.error.seq": i.errorSeq,
            "chat.error.clientKey": i.errorClientKey,
            "chat.canLoadMore": i.canLoadMore,
            "chat.loadingPreviousMessages": i.loadingPreviousMessages,
            "chat.previousMessagesLoadSeq": i.previousMessagesLoadSeq,
            "chat.recentMessagesLoadSeq": i.recentMessagesLoadSeq,
            "chat.lastReadCursor": i.lastReadCursorByConversation[e.conversationId ? ? ""] ? ? "",
            "chat.conversationId": e.conversationId,
            "chat.conversationGeneration": e.conversationGeneration,
            "chat.composerText": i.composerText,
            "chat.stagedAttachments": _,
            "chat.stagedAttachment": _[_.length - 1] ? ? null,
            "chat.attachmentRejection": Ms(i.attachmentRejection),
            "chat.imageUploadOffered": Ts({
                session: e,
                liveAgent: s,
                chat: i
            }),
            "chat.imageUploadVisible": Es({
                session: e,
                liveAgent: s,
                chat: i
            }),
            "chat.messages.reactions": i.reactions,
            "conversation.inState": i.inConversationState,
            "conversation.stateData.capture": i.captureData,
            "conversation.stateData.liveChat": null,
            "conversation.stateData.listSelection": i.listSelectionData,
            "csat.autoTrigger": i.csatAutoTrigger,
            "csat.autoTriggerConversationId": i.csatAutoTriggerConversationId,
            "csat.showAfterEndChat": !m,
            "csat.botSettings": h,
            "csat.agentSettings": g,
            "csat.settings": s.hadHandoff || s.isActive ? g : h,
            "csat.submitError": i.csatSubmitError,
            "csat.submitErrorSurveyType": i.csatSubmitErrorSurveyType,
            "csat.submitErrorConversationId": i.csatSubmitErrorConversationId,
            "csat.submitError.seq": i.csatSubmitErrorSeq,
            "csat.inlineSubmitErrorIds": i.csatInlineSubmitErrorIds,
            "csat.submitSuccess.seq": i.csatSubmitSuccessSeq,
            "csat.submitSuccess.surveyType": i.csatSubmitSuccessSurveyType,
            "csat.submitSuccess.conversationId": i.csatSubmitSuccessConversationId,
            "csat.submitSuccess.sameGeneration": i.csatSubmitSuccessSameGeneration,
            "csat.endChatEligibility.seq": i.csatEndChatEligibilitySeq,
            "csat.endChatEligibility.status": i.csatEndChatEligibility.status,
            "csat.endChatEligible": i.csatEndChatEligibility.eligible,
            "csat.endChatSurveyTarget": i.csatEndChatEligibility.surveyTarget,
            "endChat.canEnd": !s.hasConversationEnded && i.userHasSentInCurrentConversation && e.conversationId !== null,
            "endChat.completedSeq": i.endChatCompletedSeq,
            "config.isParentElementMode": e.isParentElementMode,
            "config.hideDefaultHeader": e.hideDefaultHeader,
            "chat.greeting.handle": o.handle ? ? "",
            "chat.greeting.isFollowUpResponseId": o.followUpResponseId !== null,
            "outage.responseDelayed": a.responseDelayed,
            "outage.showServiceRestoredToast": a.showServiceRestoredToast,
            "outage.networkConnectivityToast": r.networkConnectivityToast,
            "outage.connectivityLost": r.connectivityLost,
            "error.hasErrors": p !== null,
            "error.type": p,
            "chatter.language": e.language,
            "chatter.alertSoundEnabled": e.alertSoundEnabled,
            "chatter.deviceNotificationsEnabled": e.deviceNotificationsEnabled,
            "chatter.hasDeviceToken": !!e.deviceToken,
            "chatter.notificationPermission": e.notificationPermission,
            "chatter.notificationsSupported": e.notificationsSupported,
            "chatter.smsNotificationsEnabled": e.smsNotificationsEnabled,
            "chatter.translations": c,
            "chat.playbookStepExecuting": i.playbookStepExecuting,
            "chat.answeredInteractiveIds": Ns(i.messages, i.answeredInteractiveMessageIds, i.withdrawnAnswerMessageIds),
            "liveAgent.inLiveChat": s.inLiveChat,
            "liveAgent.inPending": s.inPending,
            "liveAgent.isActive": s.isActive,
            "liveAgent.hasConversationEnded": s.hasConversationEnded,
            "liveAgent.conversationEndedByChatter": s.conversationEndedByChatter,
            "liveAgent.liveChatEndedInConversation": s.liveChatEndedInConversation,
            "liveAgent.platform.name": s.platformName,
            "liveAgent.platform.departmentId": s.platformDepartmentId,
            "liveAgent.queuePosition": s.queuePosition,
            "liveAgent.queueWaitMinutes": s.queueWaitMinutes,
            "liveAgent.queueCancelPending": s.queueCancelPending,
            "liveAgent.handoff.lastEvent": s.lastHandoffEvent,
            "liveAgent.handoff.retryRequestedCount": s.retryRequestedCount,
            "ui.showRetryDialog": s.retryDialog.visible,
            "ui.retryDialog.pending": s.retryDialog.pending,
            "agent.assignmentKnown": s.agentAssignmentKnown,
            "agent.list": d,
            "agent.activeAgent": f,
            "zendesk.sdk.initialized": s.zendesk.sdkInitialized,
            "zendesk.sdk.disconnected": s.zendesk.disconnected,
            "zendesk.sdk.reconnecting": s.zendesk.reconnecting,
            "zendesk.sessionId": s.zendesk.sessionId,
            "zendesk.department.status": s.zendesk.departmentStatus,
            "zendesk.department.id": s.zendesk.departmentId,
            "zendesk.tags": s.zendesk.tags,
            "zendesk.fatalRequestErrorReached": s.zendesk.fatalRequestErrorReached,
            "zendesk.webhookRetryMessageKey": s.zendesk.webhookRetryMessageKey,
            "ui.fatalHandoffDialog.pending": s.zendesk.fatalRequestErrorPending,
            "ui.fatalHandoffDialog.cancelFailed": s.zendesk.fatalRequestErrorCancelFailed,
            "zendeskMessaging.sdk.initializationStatus": s.zendeskMessaging.initializationStatus,
            "zendeskMessaging.sdk.initialized": s.zendeskMessaging.initialized,
            "zendeskMessaging.sdk.disconnected": s.zendeskMessaging.disconnected,
            "zendeskMessaging.sdk.reconnecting": s.zendeskMessaging.reconnecting,
            "zendeskMessaging.conversationId": s.zendeskMessaging.conversationId,
            "file.uploadVisible": dr({
                features: e.features,
                fileUploadEnabled: e.fileUploadEnabled,
                liveAgent: {
                    inLiveChat: s.inLiveChat,
                    platformName: s.platformName
                }
            }),
            "file.uploadEnabled": Yn({
                features: e.features,
                fileUploadEnabled: e.fileUploadEnabled,
                liveAgent: {
                    inLiveChat: s.inLiveChat,
                    platformName: s.platformName
                },
                file: {
                    transfer: s.file.transfer,
                    isUploading: s.file.isUploading
                }
            }),
            "file.isUploading": s.file.isUploading,
            "file.uploadError": s.file.uploadError,
            "file.transfer": s.file.transfer ? {
                progress: s.file.transfer.progress,
                fileName: s.file.transfer.fileName,
                fileSize: s.file.transfer.fileSize
            } : null,
            "ui.typingIndicator.visible": i.isTyping || d.some((e) => e.isTyping),
            "ui.botTyping.visible": i.isBotTyping,
            "voice.enabled": l.enabled,
            "voice.isRecording": l.isRecording,
            "voice.mode": l.mode,
            "voice.currentTranscript": l.currentTranscript,
            "voice.isFinal": l.isFinal,
            "voice.audioLevel": l.audioLevel,
            "voice.error": l.error,
            "voice.ttsEnabled": l.ttsEnabled,
            "ui.secretMessage.isOpen": e.secretMessageIsOpen,
            "ui.secretMessage.buttonEnabled": !!e.features.secretMessage,
            featureFlags: u
        };
    }),
    Ls = "core",
    Rs = "core.state.update",
    zs = "app",
    Bs = "app.event";

function Vs(e) {
    let t = e;
    if (typeof e == "string") try {
        t = JSON.parse(e);
    } catch {
        return null;
    }
    if (typeof t != "object" || !t) return null;
    let n = t;
    return n.name === zs && n.type === Bs && typeof n.event == "string" ? n : null;
}
var Hs = 15e3,
    Us = "ada-custom-app",
    Ws = "core/index.js",
    Gs = "dev",
    Ks = "data-ada-app-isolated",
    qs = "--ada-messaging-viewport-height",
    Js = "Ada Chat conversation";

function Ys(e, t, n) {
    return go(e, t, Ws, n).buildSha ? ? Gs;
}

function Xs(e) {
    return `${Us}:${e}`;
}

function Zs() {
    return Ys(
        import.meta.url, "eb157faa62f6aedb4b1659a9563b247e78b9d989", window.location.origin);
}

function Qs() {
    let e = window.visualViewport ? .height;
    return typeof e == "number" && Number.isFinite(e) && e > 0 ? `${Math.round(e)}px` : typeof window.innerHeight == "number" && Number.isFinite(window.innerHeight) && window.innerHeight > 0 ? `${Math.round(window.innerHeight)}px` : "100vh";
}

function $s(e) {
    let t = () => {
        e.style.setProperty(qs, Qs());
    };
    t();
    let n = window.visualViewport;
    return n ? .addEventListener("resize", t), n ? .addEventListener("scroll", t), window.addEventListener("resize", t), window.addEventListener("orientationchange", t), () => {
        n ? .removeEventListener("resize", t), n ? .removeEventListener("scroll", t), window.removeEventListener("resize", t), window.removeEventListener("orientationchange", t);
    };
}
var ec = class extends Error {
        constructor(e, t) {
            super(e), L(this, "code", void 0), this.name = "AppFrameMountTimeoutError", this.code = t;
        }
    },
    tc = /* @__PURE__ */ new WeakMap(),
    nc = class {
        constructor(e) {
            L(this, "_store", void 0), L(this, "_iframe", null), L(this, "_viewportHeightCleanup", null), L(this, "_unsubscribe", null), L(this, "_eventHandler", null), L(this, "_messageListener", null), L(this, "_lastState", null), L(this, "_appOrigin", null), L(this, "_isolated", !1), L(this, "_appPort", null), L(this, "_flushPending", !1), L(this, "_appInitializeHandler", null), this._store = e;
        }
        mount(e, t = document.body, n = {}) {
            this._iframe && this.destroy();
            let r = dt(e, {
                baseUrl: window.location.href
            });
            if (!r) return Promise.reject( /* @__PURE__ */ Error("AppBridge: app iframe URL must resolve to an HTTP(S) origin."));
            this._isolated = n.isolateOrigin === !0, this._iframe = document.createElement("iframe"), this._iframe.src = e, this._iframe.setAttribute("data-ada-frame", "app"), this._iframe.title = Js, this._iframe.lang = "en", this._iframe.setAttribute("style", `display:block;width:100%;height:var(${qs}, 100vh);border:0;`), this._iframe.setAttribute("sandbox", re), tc.set(this._store, this), this._store.dispatch(Yt({
                isCustomApp: this._isolated
            })), this._isolated && (this._iframe.name = Xs(Zs()), this._iframe.setAttribute(Ks, "true"), this._iframe.setAttribute("referrerpolicy", Pt), Pe(r) && this._iframe.setAttribute("allow", f)), this._viewportHeightCleanup = $s(this._iframe), this._appOrigin = r, this._listenForAppEvents();
            let i = this._iframe;
            return new Promise((e, r) => {
                let a = !1,
                    o = !1,
                    s = !1,
                    c = () => {
                        if (!(a || !o || !s)) {
                            if (a = !0, f(), this._iframe !== i) {
                                r( /* @__PURE__ */ Error("AppBridge: app iframe mount was superseded before initialization completed."));
                                return;
                            }
                            this._startStatePush(), e();
                        }
                    },
                    l = () => {
                        o = !0, c();
                    },
                    u = () => {
                        s = !0, c();
                    },
                    d = () => {
                        this._iframe === i && (this._releaseMount(), this._unsubscribe && = (this._unsubscribe(), null), this._messageListener && = (window.removeEventListener("message", this._messageListener), null), this._viewportHeightCleanup ? .(), this._viewportHeightCleanup = null, this._iframe = null, this._lastState = null, this._appOrigin = null, this._isolated = !1, this._appPort ? .close(), this._appPort = null, this._flushPending = !1, this._appInitializeHandler === u && (this._appInitializeHandler = null)), i.isConnected && i.remove();
                    },
                    f = () => {
                        m ? .(), n.startupClock ? .signal.removeEventListener("abort", h), i.removeEventListener("load", l), this._appInitializeHandler === u && (this._appInitializeHandler = null);
                    },
                    p = () => {
                        a || (a = !0, f(), d(), r(new ec(`AppBridge: app iframe failed to initialize within ${Hs}ms`, o ? "handshake_timeout" : "frame_load_failed")));
                    },
                    m, h = () => {
                        a || (a = !0, f(), d(), r(n.startupClock ? .signal.reason));
                    };
                if (n.startupClock ? .signal.aborted) {
                    h();
                    return;
                }
                let g = n.startupClock ? void 0 : setTimeout(p, Hs);
                m = n.startupClock ? n.startupClock.armActiveDeadline(Hs, p) : () => clearTimeout(g), n.startupClock ? .signal.addEventListener("abort", h, {
                    once: !0
                }), this._appInitializeHandler = u, i.addEventListener("load", l), t.appendChild(i);
            });
        }
        onEvent(e) {
            this._eventHandler = e;
        }
        pushState() {
            this._sendState(this._store.getState());
        }
        destroy(e) {
            this._releaseMount(e), this._unsubscribe && = (this._unsubscribe(), null), this._messageListener && = (window.removeEventListener("message", this._messageListener), null), this._viewportHeightCleanup ? .(), this._viewportHeightCleanup = null, this._iframe && = (this._iframe.remove(), null), this._lastState = null, this._appOrigin = null, this._isolated = !1, this._appPort ? .close(), this._appPort = null, this._appInitializeHandler = null;
        }
        _releaseMount(e) {
            tc.get(this._store) === this && (tc.delete(this._store), e !== "reset-remount" && this._isolated && this._processAppEvent({
                name: zs,
                type: Bs,
                event: "ui.frameStyles.set",
                payload: {
                    styles: {}
                }
            }), this._store.dispatch(Yt({
                isCustomApp: !1
            })));
        }
        _startStatePush() {
            this._sendState(this._store.getState()), this._unsubscribe = this._store.subscribe(() => {
                this._flushPending || (this._flushPending = !0, queueMicrotask(() => {
                    this._flushPending = !1, this._sendState(this._store.getState());
                }));
            });
        }
        _sendState(e, t = {}) {
            if (e.session._chatterAnnouncementSuppressed) return;
            let n = Is(e);
            if (!t.force && n === this._lastState) return;
            this._lastState = n;
            let r = {
                name: Ls,
                type: Rs,
                state: n
            };
            if (!this._appOrigin) return;
            if (this._isolated) {
                this._appPort ? .postMessage(r);
                return;
            }
            let i = this._iframe ? .contentWindow;
            i && i.postMessage(r, this._appOrigin);
        }
        _listenForAppEvents() {
            this._messageListener = (e) => {
                if (this._iframe && e.source !== this._iframe.contentWindow || !this._appOrigin || e.origin !== this._appOrigin) return;
                let t = Vs(e.data);
                if (t) {
                    if (this._isolated) {
                        if (t.event !== "app.initialize" || this._appPort !== null) return;
                        let n = e.ports[0];
                        if (!n) return;
                        this._appPort = n, n.onmessage = (e) => {
                            let t = Vs(e.data);
                            t && this._processAppEvent(t);
                        };
                    }
                    this._processAppEvent(t);
                }
            }, window.addEventListener("message", this._messageListener);
        }
        _processAppEvent(e) {
            if (e.event === "app.initialize") {
                let e = this._appInitializeHandler;
                e ? .(), e || this._sendState(this._store.getState(), {
                    force: !0
                });
            }
            if (this._eventHandler) try {
                this._eventHandler(e.event, e.payload);
            } catch (e) {
                P(e instanceof Error ? e : Error(String(e)));
            }
        }
    },
    rc = class extends Error {
        constructor(e, t, n) {
            super(t instanceof Error ? t.message : String(t), {
                cause: t
            }), L(this, "appUrl", void 0), L(this, "code", void 0), this.name = "CustomAppMountError", this.appUrl = e, this.code = n;
        }
    },
    ic = 7500,
    ac = "The appUrl origin is not in this bot's Allowed Websites list. Add your app's origin to Allowed Websites in the Ada dashboard (Channels > Chat). An entry that carries a path, query, or fragment does not authorize a custom app; add the bare origin.",
    oc = "Client config did not arrive in time to verify the appUrl against this bot's Allowed Websites list.";

function sc(e) {
    return e.getState().session.hasHydratedClientConfig ? Promise.resolve(!0) : new Promise((t) => {
        let n = !1,
            r = (e) => {
                n || (n = !0, i(), clearTimeout(a), t(e));
            },
            i = e.subscribe(() => {
                e.getState().session.hasHydratedClientConfig && r(!0);
            }),
            a = setTimeout(() => r(!1), ic);
    });
}

function cc(e) {
    if (!e) return !1;
    try {
        return Ht(new URL(e).hostname);
    } catch {
        return !1;
    }
}
async function lc(e, t, n) {
    return cc(t) && cc(n) ? null : await sc(e) ? Gi(e.getState().session.allowedWebsites, t) ? null : {
        code: "origin_not_allowlisted",
        reason: ac
    } : {
        code: "allowlist_unavailable",
        reason: oc
    };
}
async function uc(e) {
    let t = e.container ? ? document.body,
        n = e.customAppUrl ? ? null;
    if (n !== null) {
        let r = await lc(e.store, n, e.hostPageOrigin ? ? null);
        if (e.startupClock ? .signal.aborted) throw e.startupClock.signal.reason ? ? new DOMException("The operation was aborted.", "AbortError");
        if (r !== null) {
            if (e.fallbackEnabled === !1) throw new rc(n, Error(r.reason), r.code);
            e.onFallback ? .({
                appUrl: n,
                reason: r.reason,
                code: r.code,
                retryable: r.code === "allowlist_unavailable"
            });
        } else {
            let r = new nc(e.store);
            try {
                return await r.mount(n, t, {
                    isolateOrigin: !0,
                    startupClock: e.startupClock
                }), r;
            } catch (t) {
                if (r.destroy(), e.startupClock ? .signal.aborted) throw e.startupClock.signal.reason ? ? new DOMException("The operation was aborted.", "AbortError");
                let i = t instanceof ec ? t.code : "frame_load_failed";
                if (e.fallbackEnabled === !1) throw new rc(n, t, i);
                e.onFallback ? .({
                    appUrl: n,
                    reason: t instanceof Error ? t.message : String(t),
                    code: i,
                    retryable: !1
                });
            }
        }
    }
    let r = new nc(e.store);
    try {
        return await r.mount(e.defaultAppUrl, t, {
            startupClock: e.startupClock
        }), r;
    } catch (e) {
        throw r.destroy(), e;
    }
}
//#endregion
//#region src/business-events.ts
function dc(e, t, n = {}) {
    let {
        endpoint: r,
        chatterToken: i,
        sessionToken: a,
        metaFields: o,
        _chatterAnnouncementSuppressed: s
    } = e;
    if (!r || !i || s) return;
    let c = r.endsWith("/") ? r : `${r}/`,
        l = {
            "Content-Type": "application/json",
            "X-Ada-Request-Origin": "chat",
            "Chatter-Token": i
        };
    a && (l["Session-Auth"] = a);
    let u = typeof o.initialURL == "string" ? o.initialURL.split("?")[0] : void 0;
    globalThis.fetch(`${c}business_events/track`, {
        method: "POST",
        credentials: "include",
        ...n.keepalive ? {
            keepalive: !0
        } : {},
        headers: l,
        body: JSON.stringify({
            event_key: t.key,
            value: t.value ? ? 0,
            is_variable: t.isVariable,
            meta: {
                ...u ? {
                    _ada_url: u
                } : {},
                ...t.meta ? ? {}
            },
            customer_query: {
                token: i
            }
        })
    }).catch(() => {});
}
//#endregion
//#region src/chat-window-event-payload.ts
function fc(e) {
    return {
        conversation_id: e.session.conversationId ? ? void 0,
        is_engaged: e.chat.isConversationActive && e.chat.messages.some((e) => e.sender === "user" && e.type !== "presence")
    };
}
//#endregion
//#region src/integration-chat-end.ts
function pc(e, t = (t) => {
    e.dispatch(yi(t));
}) {
    let {
        liveAgent: n
    } = e.getState(), {
        zendesk: r
    } = n;
    !n.inLiveChat && !n.inPending && n.platformName === null && !r.sdkInitialized && !r.sessionId && !r.primarySessionId || (t({
        integration: "liveAgent",
        action: "chat.end",
        payload: {}
    }), (n.platformName === "zendesk_liveagent" || r.sdkInitialized || r.sessionId || r.primarySessionId) && cn(e, {
        inLiveChat: n.inLiveChat,
        inPending: n.inPending
    }));
}
//#endregion
//#region src/orchestrator-message-runtime.ts
var mc = B("orchestrator"),
    hc = 200,
    gc = 3e4,
    _c = 4e3,
    vc = 3,
    yc = "Returning Capture Validation Error",
    bc = "Processing...",
    xc = "secret";

function K(e, t) {
    return e.store.getState().session.conversationGeneration !== t;
}

function Sc(e, t) {
    let {
        greeting: n
    } = e.getState().session;
    e.dispatch(xe({
        handle: n ? ? t.greeting ? ? null,
        introResponseId: t.intro ? .response_id ? ? null,
        configuredResponseId: e.getState().session.configuredGreetingResponseId ? ? null
    }));
}
var Cc = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function wc(e) {
    return typeof e == "string" && Cc.test(e) ? e : void 0;
}

function Tc(e) {
    return e.messageState.groupSendOwner !== void 0;
}
var Ec = "Your images are still sending. Please wait a moment and try again.";

function Dc(e, t, n) {
    mc.warn(`${t} dropped: a grouped image send is still posting`), e.store.dispatch(Or(Ec, n)), R("user_message_dropped", {
        reason: "group_send_in_flight"
    });
}
async function Oc(e, t, n) {
    let r = wc(n ? .clientKey),
        i = n ? .withStagedAttachment ? e.store.getState().chat.stagedAttachments : [];
    if (i.some((e) => e.status === "uploading")) {
        mc.warn("Message dropped: attachment still uploading");
        let n = t.trim();
        return n && e.store.dispatch(Zi(n)), e.store.dispatch(Or("Your image is still uploading. Please wait a moment and try again.", r)), R("user_message_dropped", {
            reason: "attachment_uploading"
        }), {
            error: "ATTACHMENT_UPLOADING"
        };
    }
    let a = i.filter((e) => e.status === "ready" && e.s3Key),
        o = !1,
        s = t.trim();
    if (a.length > 0 && (!Es(e.store.getState()) || a.some((t) => t.conversationId !== e.store.getState().session.conversationId))) {
        mc.warn("Staged images dropped: control no longer available");
        let t = a[0];
        for (let t of a) e.store.dispatch(_r({
            id: t.id
        }));
        s.length > 0 && t && e.store.dispatch(bi({
            id: t.id,
            error: "unavailable"
        })), R("image_attachment_rejected", {
            reason: "unavailable"
        }), a = [], o = !0;
    }
    if (s.length === 0 && a.length === 0) return o ? (e.store.dispatch(Or("Image attachments aren't available right now.", r)), R("user_message_dropped", {
        reason: "attachment_unavailable"
    })) : mc.warn("Message dropped: empty text"), {
        error: "EMPTY_TEXT"
    };
    if (t.length > 500) return mc.warn("Message dropped: exceeds character limit", {
        length: t.length,
        limit: 500
    }), e.store.dispatch(V("Message too large. Please shorten your message.", r)), R("user_message_dropped", {
        reason: "size_limit_exceeded",
        size: t.length
    }), {
        error: "TOO_LONG"
    };
    let c = Date.now(),
        l = e.messageState.lastMessageSentAt,
        u = c - l;
    if (l > 0 && u < hc) return mc.warn("Message dropped: rate limit exceeded", {
        timeSinceLastMessage: u,
        minInterval: hc
    }), e.store.dispatch(Or("You're sending messages too quickly. Please wait a moment and try again.", r)), R("user_message_dropped", {
        reason: "rate_limit_exceeded",
        timeSinceLastMessage: u
    }), {
        error: "RATE_LIMITED"
    };
    if (Tc(e)) {
        let n = t.trim();
        return n && e.store.dispatch(Zi(n)), Dc(e, "Message", r), {
            error: "GROUP_SEND_IN_FLIGHT"
        };
    }
    e.messageState.lastMessageSentAt = c;
    let {
        endpoint: d,
        chatterToken: f,
        sessionId: p,
        conversationId: m,
        conversationGeneration: h
    } = e.store.getState().session;
    if (!d || !f) return mc.warn("Message dropped: session not ready"), e.store.dispatch(Or("Failed to send message", r)), {
        error: "DISPATCH_FAILED"
    };
    e.store.dispatch(Ai());
    let g = n ? .messageType === xc,
        _ = a.length > 1 ? I() : void 0,
        v = a.length > 0 ? a.map((e, t) => ({
            messageId: I(),
            retryableSend: {
                tempMessageUuid: cr(),
                body: "",
                messageType: "downloadable",
                url: e.url ? ? "",
                mimeType: e.mimeType,
                name: e.name,
                s3Key: e.s3Key,
                ...s && t === 0 ? {
                    caption: s
                } : {},
                ..._ ? {
                    attachmentGroupId: _,
                    attachmentGroupFinal: t === a.length - 1
                } : {}
            }
        })) : [{
            messageId: I(),
            retryableSend: {
                tempMessageUuid: cr(),
                body: t,
                ...n ? .messageType ? {
                    messageType: n.messageType
                } : {},
                ...n ? .data ? {
                    data: n.data
                } : {}
            }
        }],
        y = v[0] ? .messageId ? ? I();
    if (g) e.store.dispatch(Ra());
    else {
        let r = wc(n ? .clientKey);
        for (let [i, o] of v.entries()) {
            let s = a[i],
                c = {
                    id: o.messageId,
                    tempMessageUuid: o.retryableSend.tempMessageUuid,
                    sender: "user",
                    timestamp: Date.now(),
                    ...r && i === 0 ? {
                        clientKey: r
                    } : {},
                    ...m ? {
                        conversationId: m
                    } : {},
                    ...n ? .origin ? {
                        origin: n.origin
                    } : {}
                },
                l = s ? {
                    ...c,
                    type: "downloadable",
                    body: "",
                    url: s.url ? ? "",
                    name: s.name,
                    mimeType: s.mimeType,
                    ...o.retryableSend.caption ? {
                        caption: o.retryableSend.caption
                    } : {},
                    ..._ ? {
                        attachmentGroupId: _
                    } : {}
                } : {
                    ...c,
                    type: "text",
                    body: t
                };
            e.store.dispatch(Aa(l));
        }
        for (let t of a) e.store.dispatch(_r({
            id: t.id
        }));
    }
    R("user_message_sent", {
        bodyLength: t.length,
        ...a.length > 0 ? {
            attachment: "image",
            attachmentCount: a.length
        } : {}
    });
    let b = (t) => {
            for (let n of v.slice(t)) e.store.dispatch(oi(n.messageId));
        },
        x = (t, n = "Failed to send message") => {
            if (t === 0) {
                e.store.dispatch(V(n, r)), b(t);
                return;
            }
            e.store.dispatch(Or(n, r)), S(t);
        },
        S = (t) => {
            let n = v.slice(t).map((e) => e.messageId);
            n.length > 0 && e.store.dispatch(Wa(n));
        },
        C = v.length > 1 ? Symbol("groupSend") : null;
    C !== null && (e.messageState.groupSendOwner = C);
    try {
        for (let [t, n] of v.entries()) try {
            let i = await e.store.dispatch(G.endpoints.sendMessage.initiate({
                ...n.retryableSend,
                endpoint: d,
                chatterToken: f,
                sessionId: p ? ? ""
            }));
            if (W(e.signal), K(e, h)) return a.length > 0 && S(t + 1), {
                id: y
            };
            if ("error" in i) return a.length > 0 ? x(t) : e.store.dispatch(V("Failed to send message", r)), a.length === 0 && !g && Rc(e.store, n.messageId, n.retryableSend, i.error, "result"), e.onCaptureException( /* @__PURE__ */ Error("Failed to send message"), {
                endpoint: d,
                conversationId: m
            }), {
                error: "DISPATCH_FAILED"
            };
            e.store.dispatch(zi(n.messageId));
        } catch (i) {
            return H(i) ? {
                id: y
            } : K(e, h) ? (a.length > 0 && S(t), {
                id: y
            }) : (a.length > 0 ? x(t, "Network error") : (e.store.dispatch(V("Network error", r)), g || Rc(e.store, n.messageId, n.retryableSend, i, "caught")), e.onCaptureException(i, {
                endpoint: d,
                conversationId: m
            }), {
                error: "DISPATCH_FAILED"
            });
        }
        return {
            id: y
        };
    } finally {
        C !== null && e.messageState.groupSendOwner === C && (e.messageState.groupSendOwner = void 0);
    }
}
async function kc(e, t) {
    if (Tc(e)) {
        Dc(e, "Retry");
        return;
    }
    let n = e.store.getState(),
        r = n.chat.messages.find((e) => e.id === t);
    if (r ? .type !== "text" || r.sender !== "user" || r.deliveryStatus !== "failed" || r.isRetryable !== !0 || r.conversationId != null && r.conversationId !== n.session.conversationId) return;
    let i = n.chat.retryableMessageSends[t];
    if (!i) return;
    let a = () => {
        e.cancelOutageTracking ? .(), e.store.dispatch(eo(t));
    };
    if (i.transport === "zendesk") {
        if (!e.sendIntegrationCommand || !n.liveAgent.inLiveChat || n.liveAgent.platformName !== "zendesk_liveagent" || n.liveAgent.zendesk.disconnected || i.zendeskOperationSeq !== n.liveAgent.zendeskOperationSeq) return;
        a(), e.sendIntegrationCommand("core.integration.command", {
            integration: "liveAgent",
            action: "message.send",
            payload: {
                message: i.body,
                messageId: t,
                tempMessageUuid: i.tempMessageUuid,
                zendeskOperationSeq: i.zendeskOperationSeq
            }
        });
        return;
    }
    let {
        endpoint: o,
        chatterToken: s,
        sessionId: c,
        conversationId: l,
        conversationGeneration: u
    } = n.session;
    if (!o || !s) return;
    a();
    let d = () => {
        e.store.dispatch(Sa({
            messageId: t,
            tempMessageUuid: i.tempMessageUuid
        }));
    };
    try {
        let n = await e.store.dispatch(G.endpoints.sendMessage.initiate({
            ...i,
            endpoint: o,
            chatterToken: s,
            sessionId: c ? ? ""
        }));
        if (W(e.signal), K(e, u)) {
            d();
            return;
        }
        if ("error" in n) {
            e.store.dispatch(V("Failed to send message")), Rc(e.store, t, i, n.error, "result"), e.onCaptureException( /* @__PURE__ */ Error("Failed to retry message"), {
                endpoint: o,
                conversationId: l
            });
            return;
        }
        e.store.dispatch(zi(t));
    } catch (n) {
        if (H(n)) {
            d();
            return;
        }
        if (K(e, u)) {
            d();
            return;
        }
        e.store.dispatch(V("Network error")), Rc(e.store, t, i, n, "caught"), e.onCaptureException(n, {
            endpoint: o,
            conversationId: l
        });
    }
}
async function Ac(e, t) {
    let {
        label: n,
        target: r,
        buttonType: i,
        messageId: a,
        value: o,
        origin: s
    } = t, c = i === "accepted_value", l = c && !n ? o ? ? "" : n;
    if (Tc(e)) return Dc(e, "Quick reply"), !1;
    let u = Date.now(),
        d = e.messageState.lastMessageSentAt;
    if (d > 0 && u - d < hc) return mc.warn("Quick reply dropped: rate limit exceeded"), !1;
    e.messageState.lastMessageSentAt = u;
    let {
        endpoint: f,
        chatterToken: p,
        sessionId: m,
        conversationId: h,
        conversationGeneration: g
    } = e.store.getState().session;
    if (!f || !p) return mc.warn("Quick reply dropped: session not ready"), !1;
    let _ = I();
    e.store.dispatch(tr(s === "programmatic" ? {
        messageId: a,
        answerMessageId: _
    } : a)), e.store.dispatch(Ai());
    let v = cr(),
        y = {
            type: "text",
            id: _,
            tempMessageUuid: v,
            body: l,
            sender: "user",
            timestamp: Date.now(),
            ...s ? {
                origin: s
            } : {},
            ...h ? {
                conversationId: h
            } : {},
            ...c ? {} : {
                buttonType: i
            }
        };
    e.store.dispatch(Aa(y));
    let b = c ? {
            tempMessageUuid: v,
            body: l,
            messageType: "text"
        } : {
            tempMessageUuid: v,
            body: l,
            messageType: "trigger",
            data: r,
            buttonType: i
        },
        x = !1,
        S = !1;
    try {
        let t = await e.store.dispatch(G.endpoints.sendMessage.initiate({
            ...b,
            endpoint: f,
            chatterToken: p,
            sessionId: m ? ? ""
        }));
        if (W(e.signal), !K(e, g))
            if ("error" in t) e.store.dispatch(V("Failed to send quick reply")), x = !0, S = Rc(e.store, y.id, b, t.error, "result"), e.onCaptureException( /* @__PURE__ */ Error("Failed to send quick reply"), {
                endpoint: f,
                conversationId: h
            });
            else return e.store.dispatch(zi(y.id)), R("quick_reply_sent", {
                target: r,
                buttonType: i,
                origin: s ? ? "ui"
            }), !0;
    } catch (t) {
        !H(t) && !K(e, g) && (e.store.dispatch(V("Network error")), x = !0, S = Rc(e.store, y.id, b, t, "caught"), e.onCaptureException(t, {
            endpoint: f,
            conversationId: h
        }));
    }
    if (x && R("quick_reply_failed", {
            buttonType: i,
            origin: s ? ? "ui",
            outcome: S ? "rejected" : "unconfirmed"
        }), s === "programmatic" && x) throw S ? (e.store.dispatch(Wa([y.id])), e.store.dispatch(Ye({
        messageId: a,
        answerMessageId: y.id
    })), Error("selectQuickReply rejected by chat: SEND_FAILED")) : Error("selectQuickReply rejected by chat: SEND_UNCONFIRMED");
    return s === "programmatic";
}
async function jc(e, t, n, r) {
    let i = wc(r) ? ? null;
    if (e.store.getState().chat.captureData ? .dataId !== n) return;
    if (Tc(e)) {
        Dc(e, "Capture submit"), e.store.dispatch(dn({
            dataId: n,
            submitId: i,
            message: Ec
        }));
        return;
    }
    if (e.store.getState().chat.captureData ? .isSubmitting) {
        mc.warn("Capture dropped: a submit is already in flight"), e.store.dispatch(dn({
            dataId: n,
            submitId: i,
            message: "A submit for this capture is already in flight."
        }));
        return;
    }
    e.store.dispatch(Ro(n));
    let {
        endpoint: a,
        chatterToken: o,
        sessionId: s,
        conversationId: c,
        conversationGeneration: l
    } = e.store.getState().session;
    if (!a || !o) {
        e.store.dispatch(D(n)), e.store.dispatch(dn({
            dataId: n,
            submitId: i,
            message: "Failed to send message"
        })), e.store.dispatch(V("Failed to send message"));
        return;
    }
    if (t.length > 500) {
        mc.warn("Capture dropped: exceeds character limit", {
            length: t.length,
            limit: 500
        }), e.store.dispatch(D(n)), e.store.dispatch(dn({
            dataId: n,
            submitId: i,
            message: "Message too large. Please shorten your message."
        })), e.store.dispatch(V("Message too large. Please shorten your message.")), R("user_message_dropped", {
            reason: "size_limit_exceeded",
            size: t.length
        });
        return;
    }
    let u = cr();
    try {
        let r = await e.store.dispatch(G.endpoints.sendMessage.initiate({
            endpoint: a,
            body: t,
            chatterToken: o,
            sessionId: s ? ? "",
            tempMessageUuid: u,
            data: {
                "validate-capture": !0
            }
        }));
        if (W(e.signal), K(e, l) || e.store.getState().session.conversationId !== c) return;
        if ("error" in r) {
            e.store.dispatch(D(n)), e.store.dispatch(dn({
                dataId: n,
                submitId: i,
                message: "Failed to send message"
            })), e.store.dispatch(V("Failed to send message")), e.onCaptureException( /* @__PURE__ */ Error("Failed to submit capture"), {
                endpoint: a,
                conversationId: c
            });
            return;
        }
        let d = r.data ? .message;
        if (d === yc) {
            e.store.dispatch(D(n));
            return;
        }
        if (d !== bc) {
            e.store.dispatch(D(n)), e.store.dispatch(dn({
                dataId: n,
                submitId: i,
                message: "Failed to send message"
            })), e.store.dispatch(V("Failed to send message")), e.onCaptureException( /* @__PURE__ */ Error("Unexpected capture submit response"), {
                endpoint: a,
                conversationId: c
            });
            return;
        }
        let f = I();
        e.store.dispatch(Aa({
            type: "text",
            id: f,
            tempMessageUuid: u,
            body: t,
            sender: "user",
            timestamp: Date.now(),
            ...c ? {
                conversationId: c
            } : {}
        }));
        let p = e.store.getState().chat.messages,
            m = p.find((e) => e.id === f) ? .id ? ? p.find((e) => e.tempMessageUuid === u) ? .id ? ? f;
        e.store.dispatch(zi(m)), R("user_message_sent", {
            bodyLength: t.length
        }), e.store.getState().chat.captureData ? .dataId === n && e.store.dispatch(Ko());
    } catch (t) {
        if (H(t)) {
            e.store.dispatch(D(n)), e.store.dispatch(dn({
                dataId: n,
                submitId: i,
                message: "The conversation was reset before this submit resolved."
            }));
            return;
        }
        if (K(e, l)) return;
        e.store.dispatch(D(n)), e.store.dispatch(dn({
            dataId: n,
            submitId: i,
            message: "Network error"
        })), e.store.dispatch(V("Network error")), e.onCaptureException(t, {
            endpoint: a,
            conversationId: c
        });
    }
}
async function Mc(e, t, n, r) {
    if (e.store.getState().chat.captureData ? .dataId !== r) return;
    if (n.length > 500) {
        mc.warn("Capture cancellation dropped: exceeds character limit", {
            length: n.length,
            limit: 500
        }), e.store.dispatch(Or("Message too large. Please shorten your message.")), R("user_message_dropped", {
            reason: "size_limit_exceeded",
            size: n.length
        });
        return;
    }
    e.store.dispatch(Ko());
    let {
        endpoint: i,
        chatterToken: a,
        sessionId: o,
        conversationId: s,
        conversationGeneration: c
    } = e.store.getState().session, l = n ? I() : null, u = cr(), d = {
        tempMessageUuid: u,
        body: n,
        messageType: "trigger",
        data: t,
        buttonType: "suggestion"
    };
    if (l && e.store.dispatch(Aa({
            type: "text",
            id: l,
            tempMessageUuid: u,
            body: n,
            sender: "user",
            timestamp: Date.now(),
            buttonType: "suggestion",
            ...s ? {
                conversationId: s
            } : {}
        })), !(!i || !a)) try {
        let t = await e.store.dispatch(G.endpoints.sendMessage.initiate({
            ...d,
            endpoint: i,
            chatterToken: a,
            sessionId: o ? ? ""
        }));
        if (W(e.signal), K(e, c)) return;
        if ("error" in t) {
            e.store.dispatch(V("Failed to send message")), l && Rc(e.store, l, d, t.error, "result"), e.onCaptureException( /* @__PURE__ */ Error("Failed to cancel capture"), {
                endpoint: i,
                conversationId: s
            });
            return;
        }
        l && e.store.dispatch(zi(l));
    } catch (t) {
        if (H(t) || K(e, c)) return;
        e.store.dispatch(V("Network error")), l && Rc(e.store, l, d, t, "caught"), e.onCaptureException(t, {
            endpoint: i,
            conversationId: s
        });
    }
}
async function Nc(e, t, n, r) {
    if (e.store.getState().chat.listSelectionData ? .dataId !== r) return;
    if (n.length > 500) {
        mc.warn("List cancellation dropped: exceeds character limit", {
            length: n.length,
            limit: 500
        }), e.store.dispatch(Or("Message too large. Please shorten your message.")), R("user_message_dropped", {
            reason: "size_limit_exceeded",
            size: n.length
        });
        return;
    }
    e.store.dispatch(lr());
    let {
        endpoint: i,
        chatterToken: a,
        sessionId: o,
        conversationId: s,
        conversationGeneration: c
    } = e.store.getState().session, l = cr(), u = {
        type: "text",
        id: I(),
        tempMessageUuid: l,
        body: n,
        sender: "user",
        timestamp: Date.now(),
        buttonType: "suggestion",
        ...s ? {
            conversationId: s
        } : {}
    };
    e.store.dispatch(Aa(u));
    let d = {
        tempMessageUuid: l,
        body: n,
        messageType: "trigger",
        data: t,
        buttonType: "suggestion"
    };
    if (!(!i || !a)) try {
        let t = await e.store.dispatch(G.endpoints.sendMessage.initiate({
            ...d,
            endpoint: i,
            chatterToken: a,
            sessionId: o ? ? ""
        }));
        if (W(e.signal), K(e, c)) return;
        if ("error" in t) {
            Rc(e.store, u.id, d, t.error, "result"), e.onCaptureException( /* @__PURE__ */ Error("Failed to cancel list selection"), {
                endpoint: i,
                conversationId: s
            });
            return;
        }
        e.store.dispatch(zi(u.id));
    } catch (t) {
        if (H(t) || K(e, c)) return;
        Rc(e.store, u.id, d, t, "caught"), e.onCaptureException(t, {
            endpoint: i,
            conversationId: s
        });
    }
}
async function Pc(e, t, n) {
    let {
        chat: r
    } = e.store.getState();
    if (r.listSelectionData ? .dataId !== n) return;
    if (Tc(e)) {
        Dc(e, "List selection");
        return;
    }
    let i = t;
    if (r.listSelectionData.resolvesByIndex) {
        let e = r.messages.slice().reverse().find((e) => e.type === "surfaceable_list_selection"),
            n = t.map((t) => e ? .selectables.find((e) => e.text === t) ? .index);
        n.every((e) => e !== void 0 && e !== -1) && (i = n.map(String));
    }
    e.store.dispatch(lr()), await Oc(e, t.join("; "), {
        messageType: "list_selection",
        data: {
            selected: i,
            selected_text: t
        }
    });
}
async function Fc(e, t, n) {
    if (Tc(e)) {
        Dc(e, "Option");
        return;
    }
    let {
        endpoint: r,
        chatterToken: i,
        sessionId: a,
        conversationId: o,
        conversationGeneration: s
    } = e.store.getState().session;
    if (!r || !i) return;
    e.store.dispatch(Ai());
    let c = cr(),
        l = {
            type: "text",
            id: I(),
            tempMessageUuid: c,
            body: n ? .trim() || t,
            sender: "user",
            timestamp: Date.now(),
            ...o ? {
                conversationId: o
            } : {}
        };
    e.store.dispatch(Aa(l));
    let u = {
        tempMessageUuid: c,
        body: t,
        messageType: "selected_option",
        buttonType: "suggestion"
    };
    try {
        let t = await e.store.dispatch(G.endpoints.sendMessage.initiate({
            ...u,
            endpoint: r,
            chatterToken: i,
            sessionId: a ? ? ""
        }));
        if (W(e.signal), K(e, s)) return;
        if ("error" in t) {
            e.store.dispatch(V("Failed to submit selected option")), Rc(e.store, l.id, u, t.error, "result"), e.onCaptureException( /* @__PURE__ */ Error("Failed to submit selected option"), {
                endpoint: r,
                conversationId: o
            });
            return;
        }
        e.store.dispatch(zi(l.id));
    } catch (t) {
        if (H(t) || K(e, s)) return;
        e.store.dispatch(V("Network error")), Rc(e.store, l.id, u, t, "caught"), e.onCaptureException(t, {
            endpoint: r,
            conversationId: o
        });
    }
}

function Ic(e) {
    if (typeof e != "object" || !e) return {
        kind: "unknown"
    };
    if ("status" in e) {
        let {
            status: t,
            data: n
        } = e;
        if (t === 0) return {
            kind: "transport",
            status: t,
            ..."data" in e ? {
                transportError: String(n)
            } : {},
            hasBody: !1
        };
        let r = "data" in e && n !== void 0;
        return typeof t == "number" ? {
            kind: "http",
            status: t,
            hasBody: r
        } : {
            kind: "unknown"
        };
    }
    let {
        name: t,
        code: n
    } = e;
    return typeof t == "string" || typeof n == "string" ? {
        kind: "serialized",
        ...typeof t == "string" ? {
            name: t
        } : {},
        ...typeof n == "string" ? {
            code: n
        } : {}
    } : {
        kind: "unknown"
    };
}

function Lc(e) {
    return e.kind === "http" && typeof e.status == "number" && e.status >= 400 && e.status < 500;
}

function Rc(e, t, n, i, a) {
    return a === "result" && Lc(Ic(i)) ? (e.dispatch(r({
        messageId: t,
        send: n
    })), !0) : (e.dispatch(oi(t)), !1);
}

function zc(e, t) {
    R("greeting_send_failed", {
        kind: e.kind,
        ...e.status === void 0 ? {} : {
            status: e.status
        },
        retryAllowed: t
    });
}

function Bc(e, t, n) {
    return n ? .automatic === !0 && !e && !t && !n.afterProactiveInjection;
}
async function Vc(e, t, n, r) {
    let i = e.store.getState(),
        a = (t) => {
            let {
                endpoint: a,
                chatterToken: o,
                conversationId: s,
                conversationGeneration: c
            } = t.session, {
                heldForProactive: l,
                isSent: u,
                isSkipped: d,
                isSkippedForPage: f,
                followUpResponseId: p
            } = t.greeting, {
                messages: m
            } = t.chat;
            return !(e.signal.aborted || c !== i.session.conversationGeneration || o !== i.session.chatterToken || !n && (l !== null || u || (d || f) && !p || s && m.length > 0 && !r ? .afterProactiveInjection) || !a || !o);
        };
    if (!a(i)) return;
    let o = !1,
        s, c = async () => {
            if (!s) return;
            let e = nr([], _c);
            try {
                await s(e.timeoutPromise);
            } catch {} finally {
                e.cleanup();
            }
        };
    if (Bc(t, n, r) && i.session.chatterToken && e.greetingLeaseOwner) {
        let t = nr([], _c);
        try {
            await Promise.race([e.greetingPersistence, t.timeoutPromise]);
            let n = e.getActivePersistenceStorage ? .();
            if (n ? .mode !== "private" && n ? .conditionalWritesSupported === !0 && n.compareAndWrite && n.getConfirmed) {
                let r = await Promise.race([crypto.subtle.digest("SHA-256", new TextEncoder().encode(i.session.chatterToken)), t.timeoutPromise]),
                    c = Array.from(new Uint8Array(r).slice(0, 8), (e) => e.toString(16).padStart(2, "0")).join(""),
                    l = "greetingLease",
                    u = e.greetingLeaseOwner,
                    d = (e) => {
                        let t = ci(e) ? .[c];
                        return !!t && t.owner !== u && t.expiresAt > Date.now();
                    };
                if (!a(e.store.getState())) return;
                let f = async (r = 0) => {
                    let i = await Promise.race([n.getConfirmed ? .([l]), t.timeoutPromise]);
                    if (!a(e.store.getState())) return !1;
                    if (!i ? .confirmed) return !0;
                    let o = i.values[l] ? ? null;
                    if (d(o)) return R("greeting_lease_skipped", {
                        reason: "sibling_lease"
                    }), !1;
                    if (r === vc) return !0;
                    let p = Date.now(),
                        m = Object.fromEntries(Object.entries(ci(o) ? ? {}).filter(([, e]) => e.expiresAt > p)),
                        h = {
                            owner: u,
                            expiresAt: p + gc
                        },
                        g = JSON.stringify({
                            ...m,
                            [c]: h
                        });
                    return await Promise.race([n.compareAndWrite ? .({
                        [l]: o
                    }, {
                        [l]: g
                    }), t.timeoutPromise]) ? (s = async (e) => {
                        let t = async (t) => {
                            let r = ci(t) ? ? {};
                            return r[c] ? .owner !== h.owner || r[c] ? .expiresAt !== h.expiresAt ? !0 : (delete r[c], Promise.race([n.compareAndWrite ? .({
                                [l]: t
                            }, {
                                [l]: Object.keys(r).length ? JSON.stringify(r) : null
                            }), e]));
                        };
                        if (await t(g)) return;
                        let r = await Promise.race([n.getConfirmed ? .([l]), e]);
                        r ? .confirmed && await t(r.values[l] ? ? null);
                    }, !0) : f(r + 1);
                };
                if (!await f()) return;
                o = !s;
            }
        } catch {
            o = !0;
        } finally {
            t.cleanup(), a(e.store.getState()) || await c();
        }
    }
    let l = e.store.getState();
    if (!a(l) || !l.session.endpoint || !l.session.chatterToken) return;
    o && R("greeting_lease_skipped", {
        reason: "fail_open"
    });
    let {
        endpoint: u,
        chatterToken: d,
        language: f,
        sessionId: p,
        conversationGeneration: m
    } = l.session, {
        followUpResponseId: h,
        introResponseId: g,
        configuredResponseId: _,
        handle: v,
        explicitlyRequested: y
    } = l.greeting, {
        wasDismissed: b
    } = l.proactive;
    e.store.dispatch(C());
    let x, S = {
        explicitly_requested: !0
    };
    x = n ? {
        response_id: n,
        ...S
    } : t ? {
        handle: t,
        ...S
    } : h && (!b || y) ? {
        response_id: h,
        ...y ? S : {}
    } : _ ? {
        response_id: _,
        ...S
    } : g ? {
        response_id: g
    } : {
        handle: v ? ? l.session.handle ? ? void 0 ? ? void 0
    };
    try {
        let t = await e.store.dispatch(G.endpoints.sendGreeting.initiate({
                endpoint: u,
                chatterToken: d,
                language: f,
                sessionId: p ? ? "",
                greeting: x
            })),
            n = "error" in t ? Ic(t.error) : null,
            r = n !== null && Lc(n);
        if (r && await c(), W(e.signal), K(e, m)) return;
        if (n) {
            r && e.store.dispatch(Wn()), zc(n, r), e.onCaptureException(Error("Failed to send greeting", {
                cause: n
            }), {
                endpoint: u,
                greeting: x,
                failure: n,
                retryAllowed: r
            });
            return;
        }
        R("greeting_sent", { ...x
        });
    } catch (t) {
        if (e.signal.aborted || H(t) || K(e, m)) return;
        let n = Ic(t);
        zc(n, !1), e.onCaptureException(Error("Failed to send greeting", {
            cause: n
        }), {
            endpoint: u,
            greeting: x,
            failure: n,
            retryAllowed: !1
        });
    }
}
//#endregion
//#region src/live-agent-message-send.ts
function Hc(e, t, n, r) {
    let i = e.getState(),
        {
            endpoint: a,
            chatterToken: o,
            sessionId: s
        } = i.session;
    return !a || !o || !r || i.session.conversationId !== r || !i.liveAgent.inLiveChat || i.liveAgent.platformName !== "zendesk_liveagent" ? !1 : (Promise.resolve(e.dispatch(G.endpoints.sendMessage.initiate({
        endpoint: a,
        body: t,
        chatterToken: o,
        sessionId: s ? ? "",
        tempMessageUuid: n
    }))).then((e) => {
        typeof e == "object" && e && "error" in e && R("zendesk_message_log_failed", {
            reason: "backend_rejected"
        });
    }).catch(() => {
        R("zendesk_message_log_failed", {
            reason: "request_rejected"
        });
    }), !0);
}

function Uc(e, t, n, r = {}) {
    if (n.length > 500) return e.dispatch(Or("Message too large. Please shorten your message.", wc(r.tempMessageUuid ? .trim()))), R("user_message_dropped", {
        reason: "size_limit_exceeded",
        size: n.length
    }), null;
    let i = I(),
        a = r.tempMessageUuid ? .trim() || cr(),
        o = wc(a),
        s = e.getState(),
        {
            conversationId: c
        } = s.session,
        {
            zendeskOperationSeq: l
        } = s.liveAgent,
        u = {
            type: "text",
            id: i,
            body: n,
            sender: "user",
            timestamp: Date.now(),
            tempMessageUuid: a,
            ...o ? {
                clientKey: o
            } : {},
            ...r.origin ? {
                origin: r.origin
            } : {},
            ...c ? {
                conversationId: c
            } : {}
        };
    return e.dispatch(Ai()), e.dispatch($i(u)), t("core.integration.command", {
        integration: "liveAgent",
        action: "message.send",
        payload: {
            message: n,
            messageId: i,
            tempMessageUuid: a,
            zendeskOperationSeq: l,
            ...r.requestId ? {
                requestId: r.requestId
            } : {}
        }
    }), i;
}
//#endregion
//#region src/orchestrator-events.ts
var Wc = B("events");

function Gc(e, t, n) {
    let {
        endpoint: r,
        chatterToken: i,
        _chatterAnnouncementSuppressed: a
    } = e.store.getState().session;
    !r || !i || a || e.store.dispatch(G.endpoints.createEvent.initiate({
        endpoint: r,
        chatterToken: i,
        type: t,
        params: n
    })).then(({
        error: e
    }) => {
        e && Wc.warn(`${t} event not recorded`, "status" in e ? e.status : e);
    });
}
//#endregion
//#region src/orchestrator-reaction-runtime.ts
var Kc = B("reaction"),
    qc = /^[0-9a-f]{24}$/i;
async function Jc(e, t, n) {
    let {
        store: r
    } = e;
    if (r.getState().chat.reactions[t] != null) {
        Kc.debug("Reaction already submitted for message", t);
        return;
    }
    r.dispatch(Qr({
        messageId: t,
        reaction: n
    }));
    let {
        session: i,
        chat: a
    } = r.getState(), {
        endpoint: o,
        chatterToken: s
    } = i, c = a.messages.find((e) => e.id === t) ? .conversationId ? ? i.conversationId;
    if (!o || !s || !c || !qc.test(t) || !qc.test(c)) {
        r.dispatch(mi({
            messageId: t,
            reaction: n
        })), Kc.warn("Reaction not submittable", t);
        return;
    }
    "error" in await r.dispatch(G.endpoints.submitMessageReview.initiate({
        endpoint: o,
        conversationId: c,
        responseMessageId: t,
        review: n,
        chatterToken: s
    })) && (r.dispatch(mi({
        messageId: t,
        reaction: n
    })), Kc.warn("Reaction submission failed", t));
}
//#endregion
//#region src/app-event-router.ts
var Yc = 20,
    Xc = 64,
    Zc = 64,
    Qc = 2e4,
    $c = new Set(["answer_flow", "end_chat"]),
    el = new Set( /* @__PURE__ */ "ui.composer.textChanged,chat.message.send,chat.message.retry,chat.quickReply.select,liveAgent.handoff.request,liveAgent.handoff.cancel,liveAgent.chat.end,endChat.confirm,endChat.skipCsat,csat.close,endChat.endLiveChat,liveAgent.message.send,ui.retryDialog.confirm,ui.fatalHandoffDialog.cancel,ui.queueCancel.request,app.startNewConversation,app.reset,capture.submit,capture.cancel,listSelection.cancel,chat.selectableList.submit,chat.option.select,chat.message.reaction.add,file.upload.start,file.upload.retry,chat.attachment.stage,csat.checkEndChatEligibility,csat.submit".split(",")),
    tl = new Set(["app.reset"]),
    nl = new Set([
        "app.error.report",
        "ui.closeButton.click",
        "ui.minimizeButton.click",
        "ui.drawer.dismiss",
        "endChat.minimizeAfterThanks",
        "ui.frameStyles.set",
        "chat.error.dismiss",
        "settings.notifications.requestPermission",
        "appearance.setTheme",
        "appearance.setTextSize",
        "voice.transcript.apply",
        "file.upload.errorDismiss",
        "ui.secretMessage.toggle",
        "ui.toast.dismiss",
        "csat.shown",
        "chat.link.click",
        "chat.widget.carouselLinkClick"
    ]);

function rl(e) {
    return e === 1 || e === -1 ? e : null;
}
var il = new Set(["link", "web_window"]),
    al = 2048,
    ol = new Set([
        "endChat.confirm",
        "endChat.skipCsat",
        "csat.close",
        "csat.submit",
        "liveAgent.chat.end",
        "endChat.endLiveChat"
    ]),
    sl = new Set(["ui.composer.textChanged", "csat.checkEndChatEligibility"]),
    cl = new Set([...el].filter((e) => !ol.has(e) && !sl.has(e)));

function ll(e) {
    let t = q(e);
    return il.has(t) ? t : null;
}

function ul(e, t) {
    let n = q(e);
    return !n || n.length > al ? null : ve(n, t) ? n : null;
}
async function dl(e, t, n) {
    let {
        chatterToken: r,
        sessionToken: i
    } = e.store.getState().session;
    try {
        let a = t.endsWith("/") ? t : `${t}/`,
            o = new URL("chatters/js-event-data/?latest_conversation_only=true", a).toString(),
            s = await zn(e.store, {
                url: o,
                method: "GET",
                credentials: "include",
                bindLifecycleSignal: !1,
                keepalive: !0
            }, {
                isCurrent: () => e.store.getState().session.chatterToken === r && e.store.getState().session.sessionToken === i && !e.store.getState().session._chatterAnnouncementSuppressed && e.store.getState().session.conversationId === n
            });
        return s.ok ? await s.json() : null;
    } catch {
        return null;
    }
}
var fl = "END_CONVERSATION";

function pl(e, t, n) {
    let r = e.store.getState(),
        i = n ? {
            afterEndChatMinimize: {
                endChatSeq: r.chat.endChatCompletedSeq
            }
        } : {},
        a = r.session.endpoint,
        o = r.session.chatterToken,
        s = r.session.conversationId,
        c = r.session.chatterId || void 0;
    a && o ? dl(e, a, s).then((n) => {
        let r = e.store.getState().session;
        if (r._chatterAnnouncementSuppressed || r.chatterToken !== o || r.conversationId !== s) {
            t("core.event.publish", {
                key: "ada:end_conversation",
                ...i,
                data: {
                    ...c === void 0 ? {} : {
                        chatter_id: c
                    },
                    event_data: {
                        event_name: fl
                    }
                }
            });
            return;
        }
        let a = hl(n) ? .chatter_data,
            l = hl(a),
            u = l ? .event_data,
            d = l ? .chatter_id,
            f = typeof d == "string" && d ? d : c,
            p = l ? .session_id,
            m = typeof p == "string" && p ? p : void 0;
        t("core.event.publish", {
            key: "ada:end_conversation",
            ...i,
            data: {
                ...f === void 0 ? {} : {
                    chatter_id: f
                },
                ...m === void 0 ? {} : {
                    session_id: m
                },
                event_data: {
                    ...hl(u) ? ? {},
                    event_name : fl
                }
            }
        });
    }) : t("core.event.publish", {
        key: "ada:end_conversation",
        ...i,
        data: {
            ...c === void 0 ? {} : {
                chatter_id: c
            },
            event_data: {
                event_name: fl
            }
        }
    });
}

function ml(e, t) {
    t("core.event.publish", {
        key: "ada:close_chat",
        data: fc(e.store.getState())
    });
}

function hl(e) {
    return typeof e != "object" || !e ? null : e;
}

function q(e) {
    return typeof e == "string" ? e.trim() : "";
}

function gl(e) {
    let t = q(e ? .inlineAnswerId),
        n = e ? .uiComplete === void 0 ? e ? .partial !== !0 : e.uiComplete === !0;
    return {
        uiComplete: n,
        inlineAnswerId: t,
        reportTerminalError: n && !t
    };
}

function _l(e, t) {
    return e.isWebWindow ? {
        type: e.isHandoff ? "handoff" : "link_click",
        params: {
            message_id: e.id,
            url: e.url,
            subtype: "web_window"
        }
    } : {
        type: e.isHandoff && !t ? "handoff" : "link_click",
        params: {
            message_id: e.id,
            url: e.url,
            subtype: e.articleId ? "article" : "link",
            article_id: e.articleId
        }
    };
}

function vl(e) {
    if (!e.articleId) return !1;
    try {
        let t = new URL(e.url);
        return (t.protocol === "http:" || t.protocol === "https:") && !t.username && !t.password;
    } catch {
        return !1;
    }
}

function yl(e) {
    return typeof e == "number" && Number.isFinite(e) ? e : null;
}

function bl(e) {
    if (!Array.isArray(e)) return null;
    let t = e.filter((e) => typeof e == "string");
    return t.length === e.length ? t : null;
}

function xl(e) {
    let t = hl(e);
    return t ? hl(t.data) ? ? t : null;
}
async function Sl(e) {
    try {
        return xl(await e.json());
    } catch {
        return null;
    }
}

function Cl(e) {
    if (!Array.isArray(e)) return;
    let t = e.filter((e) => typeof e == "string").map((e) => e.trim()).filter(Boolean).slice(0, Yc).map((e) => e.slice(0, Xc));
    return t.length > 0 ? t : void 0;
}

function J(e, t) {
    e("core.integration.command", t);
}

function wl(e) {
    return typeof e.liveAgent.platformName == "string" ? e.liveAgent.platformName : void 0;
}
var Tl = new Set(["end_chat", "live_chat"]);

function El(e, t, n) {
    return n || (t !== null && Tl.has(t) ? e.chat.csatAutoTriggerConversationId ? ? e.session.conversationId : e.session.conversationId);
}

function Dl(e) {
    let {
        instance: t,
        orchestrator: n,
        sendToParent: r,
        logger: i
    } = e, a = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = t.store.getState(), l = c.session.conversationId, u = c.liveAgent.hasConversationEnded && c.liveAgent.conversationEndedByChatter, f = t.store.subscribe(() => {
        let {
            session: e,
            liveAgent: n
        } = t.store.getState(), i = e.conversationId, a = n.hasConversationEnded && n.conversationEndedByChatter, o = i !== l || u && !a;
        u = a, i !== l && (s.get(l ? ? "") ? .pending === 0 && s.delete(l ? ? ""), l = i), o && r("core.endChat.cancelMinimize", void 0);
    }), p = !1, h = !1, g = !1, _ = null, v = null;

    function x() {
        v = {
            conversationId: t.store.getState().session.conversationId
        }, ml(t, r);
    }

    function S(e = v) {
        let n = t.store.getState().session.conversationId,
            i = e !== null && e.conversationId === n;
        v === e && (v = null), i || ml(t, r);
    }

    function C() {
        let {
            metaFields: e
        } = t.store.getState().session;
        e.proactive_conversation != null && n.session.setMetaFields({
            [wt]: null
        }, {
            bypassQueue: !0
        }).catch((e) => {
            i.error("Clearing proactive_conversation failed:", e);
        });
    }

    function w() {
        t.store.dispatch(Bt()), r("core.proactive.clear", void 0);
    }

    function T() {
        O(), Uo(t.store), n.clearConversationRuntime(), t.store.dispatch(Wi()), t.store.dispatch(le()), t.store.dispatch(ja()), t.store.dispatch(An()), t.store.dispatch(Go({
            keepPageLatch: !0
        })), w(), C(), t.store.dispatch(Tt(!1)), t.store.dispatch(_e()), n.sendGreeting();
    }

    function E() {
        t.lifecycle.supersede(), t.store.dispatch(pa()), t.transport.disconnect(), O(), Uo(t.store), n.clearConversationRuntime(), t.store.dispatch(vn()), t.store.dispatch(ja()), t.store.dispatch(An()), t.store.dispatch(Go({
            keepPageLatch: !0
        })), w(), C(), n.prepareReactivation(), D(0), r("core.conversation.reset", void 0);
    }
    async function D(e) {
        try {
            switch ((await n.activate()).kind) {
                case "activated":
                    n.sendGreeting();
                    return;
                case "aborted":
                    return;
                case "deferred":
                    n.retryTransportAfterDeferred({
                        automaticGreeting: !1
                    });
                    return;
                case "terminated":
                    e < 1 ? (t.lifecycle.supersede(), n.resetRuntimeState(), await D(e + 1)) : i.error("app.reset reactivate re-terminated; realtime recovery exhausted (REST still available).");
                    return;
            }
        } catch (e) {
            i.error("app.reset reactivate failed:", e);
        }
    }

    function O() {
        pc(t.store, (e) => {
            J(r, e);
        });
    }

    function ee(e = !1) {
        O(), n.liveAgent.endLiveAgentChat(e);
    }

    function k(e, n, i = v) {
        let a = t.store.getState();
        a.session.conversationId !== e || a.liveAgent.endChatHandled || (t.store.dispatch(Vr(!0)), n || S(i), t.store.dispatch(d(!1)), ee(!0), n || t.store.dispatch(Bn()), pl(t, r, !n && !a.session._appFrameIsCustom), C());
    }

    function A(e, n, r) {
        let i = hl(n);
        switch (e) {
            case "chat.message.send":
                {
                    let e = q(i ? .body);
                    if (!e) return;
                    t.store.dispatch(Zi(e));
                    let n = wc(q(i ? .tempMessageUuid));
                    if (r === "history-preserving-reset" && (n === void 0 || !t.store.getState().session._appFrameIsCustom)) return;
                    t.store.dispatch(Or("Failed to send message", n));
                    return;
                }
            case "capture.submit":
                {
                    let e = typeof i ? .dataId == "string" ? i.dataId : null;
                    e !== null && t.store.dispatch(dn({
                        dataId: e,
                        submitId: wc(q(i ? .submitId)) ? ? null,
                        message: "Failed to send message"
                    }));
                    return;
                }
            case "csat.submit":
                {
                    let e = q(i ? .surveyType),
                        {
                            uiComplete: n,
                            inlineAnswerId: r,
                            reportTerminalError: a
                        } = gl(i);
                    e && (n || r) && t.store.dispatch(y({
                        message: a ? "Failed to submit survey" : null,
                        inlineAnswerId: r,
                        surveyType: e,
                        conversationId: El(t.store.getState(), e, q(i ? .conversationId))
                    }));
                    return;
                }
            case "csat.checkEndChatEligibility":
            case "endChat.endLiveChat":
                {
                    let e = t.store.getState().chat.csatEndChatEligibility,
                        n = e.status === "loading" && e.requestId !== null ? e.requestId : I();
                    n !== e.requestId && t.store.dispatch(ut({
                        requestId: n
                    })),
                    t.store.dispatch(Ve({
                        eligible: !1,
                        surveyTarget: "bot",
                        requestId: n
                    }));
                    return;
                }
            case "settings.transcript.email.send":
                t.store.dispatch(Wt());
                return;
            case "settings.transcript.download.request":
                t.store.dispatch(m());
                return;
            case "chat.attachment.stage":
                if (r === "history-preserving-reset" && !t.store.getState().session._appFrameIsCustom) return;
                t.store.dispatch(bi({
                    id: I(),
                    error: "unavailable"
                })), R("image_attachment_rejected", {
                    reason: "unavailable"
                });
                return;
            default:
                return;
        }
    }

    function j(e, c, l = !1) {
        let u = hl(c);
        if (n.isHistoryPreservingResetInProgress() && !nl.has(e)) {
            A(e, c, "history-preserving-reset");
            return;
        }
        if (el.has(e) && !l)
            if (tl.has(e)) n.grantEngagement();
            else if (n.needsEngagedPreparationForAppAction()) {
            n.ensureEngagedForAppAction().then((t) => {
                t ? j(e, c, !0) : A(e, c, "engagement");
            });
            return;
        } else n.grantEngagement();
        switch (cl.has(e) && (v = null), e) {
            case "chat.logs.loadMore":
                Vi(t.store, (e) => i.error("chat.logs.loadMore failed:", e));
                return;
            case "chat.error.dismiss":
                t.store.dispatch(le());
                return;
            case "ui.composer.textChanged":
                n.notifyComposerText();
                return;
            case "chat.message.send":
                {
                    let e = q(u ? .body),
                        i = t.store.getState();
                    if (!e && (u ? .messageType === "secret" || i.liveAgent.inLiveChat || i.chat.stagedAttachments.length === 0)) return;
                    if (t.store.dispatch(Nt()), n.settleChatterTyping(), u ? .messageType === "secret") {
                        n.sendMessage(e, {
                            messageType: "secret"
                        });
                        return;
                    }
                    if (i.liveAgent.inLiveChat && i.liveAgent.platformName === "zendesk_liveagent") {
                        Uc(t.store, r, e, {
                            tempMessageUuid: q(u ? .tempMessageUuid) || void 0
                        });
                        return;
                    }
                    let a = q(u ? .tempMessageUuid);
                    n.sendMessage(e, {
                        withStagedAttachment: !0,
                        ...a ? {
                            clientKey: a
                        } : {}
                    });
                    return;
                }
            case "chat.attachment.stage":
                {
                    let e = u ? .file;
                    if (!(typeof File < "u" && e instanceof File)) return;
                    let t = q(u ? .batchId);
                    n.stageAttachment(e, u ? .allowMultiple === !0, t && t.length <= Zc ? t : void 0);
                    return;
                }
            case "chat.attachment.remove":
                {
                    let e = q(u ? .id);
                    e && n.removeAttachment(e);
                    return;
                }
            case "chat.message.retry":
                {
                    let e = q((typeof u ? .message == "object" && u.message !== null ? u.message : null) ? .id);
                    e && n.retryMessage(e, r);
                    return;
                }
            case "chat.quickReply.select":
                {
                    let e = q(u ? .label),
                        t = q(u ? .target),
                        r = q(u ? .messageId),
                        a = u ? .buttonType,
                        o = a === "suggestion" || a === "switch" || a === "accepted_value" ? a : "suggestion";
                    o !== a && i.warn ? .("Unsupported quick-reply buttonType; defaulting to suggestion", {
                        buttonType: typeof a == "string" ? a.slice(0, 64) : typeof a
                    });
                    let s = o === "accepted_value",
                        c = q(u ? .value);
                    if (!r || !e && (!s || !c) || !t && !s) return;
                    n.sendQuickReply(e, t, o, r, s ? c : void 0);
                    return;
                }
            case "app.error.report":
                {
                    let e = q(u ? .message) || "Unknown app iframe error",
                        t = typeof u ? .stack == "string" ? u.stack : "",
                        n = typeof u ? .componentStack == "string" ? u.componentStack : "";
                    P(Error(e), {
                        stack: t,
                        componentStack: n,
                        source: "app-iframe"
                    });
                    return;
                }
            case "ui.closeButton.click":
                r("core.visibility.request", {
                    isVisible: !1,
                    reason: "close"
                });
                return;
            case "ui.minimizeButton.click":
                r("core.visibility.request", {
                    isVisible: !1,
                    reason: "minimize"
                });
                return;
            case "ui.drawer.dismiss":
                r("core.visibility.request", {
                    isVisible: !1
                });
                return;
            case "endChat.minimizeAfterThanks":
                r("core.endChat.minimizeAfterThanks", {
                    endChatSeq: t.store.getState().chat.endChatCompletedSeq
                });
                return;
            case "settings.alertSound.toggle":
                typeof u ? .enabled == "boolean" && n.session.setAlertSoundEnabled(u.enabled);
                return;
            case "settings.notifications.toggle":
                typeof u ? .enabled == "boolean" && n.session.setDeviceNotificationsEnabled(u.enabled);
                return;
            case "settings.notifications.requestPermission":
                r("core.requestNotifications", void 0);
                return;
            case "settings.smsNotifications.toggle":
                typeof u ? .enabled == "boolean" && n.session.setSmsNotificationsEnabled(u.enabled);
                return;
            case "settings.language.change":
                {
                    let e = q(u ? .language);
                    e && n.session.setLanguage(e);
                    return;
                }
            case "appearance.setTheme":
                {
                    let e = u ? .theme;
                    (e === "light" || e === "dark" || e === "auto") && n.session.setUserTheme(e);
                    return;
                }
            case "appearance.setTextSize":
                {
                    let e = u ? .textSize;
                    (e === "small" || e === "default" || e === "large") && n.session.setUserTextSize(e);
                    return;
                }
            case "settings.transcript.email.send":
                {
                    let e = q(u ? .email);
                    e && n.sendEmailTranscript(e);
                    return;
                }
            case "settings.transcript.download.request":
                n.downloadTranscript();
                return;
            case "liveAgent.handoff.request":
                {
                    let e = hl(u ? .platformData),
                        t = q(e ? .platform);
                    if (!t) return;
                    let i = typeof e ? .departmentId == "number" && Number.isFinite(e.departmentId) ? e.departmentId : void 0,
                        a = Cl(e ? .tags),
                        o = {
                            platform: t,
                            ...i === void 0 ? {} : {
                                departmentId: i
                            },
                            ...a ? {
                                tags: a
                            } : {}
                        };
                    n.liveAgent.requestLiveAgentHandoff({
                        platform: o.platform,
                        departmentId: o.departmentId,
                        tags: o.tags
                    }),
                    J(r, {
                        integration: "liveAgent",
                        action: "handoff.request",
                        payload: {
                            platformData: o
                        }
                    }),
                    r("core.liveAgent.handoff", {
                        platform: t,
                        payload: {
                            departmentId: i,
                            tags: a
                        }
                    });
                    return;
                }
            case "liveAgent.handoff.cancel":
                n.liveAgent.cancelLiveAgentHandoff(), J(r, {
                    integration: "liveAgent",
                    action: "handoff.cancel",
                    payload: {}
                });
                return;
            case "ui.retryDialog.confirm":
                n.liveAgent.confirmRetryDialog();
                return;
            case "ui.retryDialog.dismiss":
                n.liveAgent.dismissRetryDialog();
                return;
            case "ui.handoffDialog.dismiss":
                n.liveAgent.dismissHandoffDialog();
                return;
            case "ui.fatalHandoffDialog.cancel":
                n.settleChatterTyping(), n.liveAgent.cancelFatalHandoff();
                return;
            case "ui.queueCancel.request":
                n.liveAgent.cancelQueue();
                return;
            case "liveAgent.chat.end":
                t.store.dispatch(d(!1)), ee();
                return;
            case "endChat.confirm":
                x();
                return;
            case "csat.close":
                {
                    let e = q(u ? .surveyType);
                    if (!$c.has(e)) return;
                    let n = t.store.getState(),
                        r = a.get(e);
                    if (u ? .conversationId === null && r && r.generation !== n.session.conversationGeneration) return;
                    let i = q(u ? .conversationId) || (u ? .conversationId === null && r ? r.conversationId : El(n, e, null));
                    i && k(i, !0);
                    return;
                }
            case "endChat.skipCsat":
                k(t.store.getState().session.conversationId, !1);
                return;
            case "endChat.endLiveChat":
                {
                    let {
                        inLiveChat: e,
                        inPending: r
                    } = t.store.getState().liveAgent;
                    if (!e && !r) return;
                    S(),
                    O(),
                    n.liveAgent.endLiveAgentLeg();
                    return;
                }
            case "liveAgent.message.send":
                {
                    let e = q(u ? .message);
                    if (!e) return;
                    n.liveAgent.sendLiveAgentMessage(e),
                    J(r, {
                        integration: "liveAgent",
                        action: "message.send",
                        payload: {
                            message: e
                        }
                    });
                    return;
                }
            case "liveAgent.typing.start":
                n.liveAgent.setLiveAgentTyping(!0), J(r, {
                    integration: "liveAgent",
                    action: "typing.start",
                    payload: {}
                });
                return;
            case "liveAgent.typing.stop":
                n.liveAgent.setLiveAgentTyping(!1), J(r, {
                    integration: "liveAgent",
                    action: "typing.stop",
                    payload: {}
                });
                return;
            case "liveAgent.visitor.setInfo":
                {
                    let e = {
                        displayName: typeof u ? .displayName == "string" ? u.displayName : void 0,
                        email: typeof u ? .email == "string" ? u.email : void 0,
                        phone: typeof u ? .phone == "string" ? u.phone : void 0
                    };
                    n.liveAgent.setLiveAgentVisitorInfo(e),
                    J(r, {
                        integration: "liveAgent",
                        action: "visitor.setInfo",
                        payload: e
                    });
                    return;
                }
            case "zendesk.sdk.initialize":
                {
                    let e = q(u ? .accountKey);
                    if (!e) return;
                    let t = hl(u ? .options) ? ? void 0;
                    n.zendesk.initializeZendeskSdk({
                        accountKey: e,
                        options: t
                    }),
                    J(r, {
                        integration: "zendesk",
                        action: "sdk.initialize",
                        payload: {
                            accountKey: e,
                            options: t
                        }
                    });
                    return;
                }
            case "zendesk.sdk.teardown":
                n.zendesk.teardownZendeskSdk(), J(r, {
                    integration: "zendesk",
                    action: "sdk.teardown",
                    payload: {}
                });
                return;
            case "zendesk.department.set":
                {
                    let e = typeof u ? .departmentId == "number" ? u.departmentId : null;
                    if (e === null) return;
                    n.zendesk.setZendeskDepartment(e),
                    J(r, {
                        integration: "zendesk",
                        action: "department.set",
                        payload: {
                            departmentId: e
                        }
                    });
                    return;
                }
            case "zendesk.transcript.send":
                {
                    let e = Array.isArray(u ? .transcript) ? u.transcript.filter((e) => typeof e == "string") : null,
                        i = typeof u ? .externalChatId == "string" ? u.externalChatId : null,
                        a = t.store.getState().session.sessionId;
                    if (i && a && i !== a) {
                        t.store.dispatch(V("Failed to send transcript"));
                        return;
                    }
                    e && i && (n.zendesk.sendZendeskTranscript(e, i), J(r, {
                        integration: "zendesk",
                        action: "transcript.send",
                        payload: {
                            transcript: e,
                            externalChatId: i,
                            currentSessionId: a
                        }
                    }));
                    return;
                }
            case "zendesk.transcript.clear":
                n.zendesk.clearZendeskTranscript(), J(r, {
                    integration: "zendesk",
                    action: "transcript.clear",
                    payload: {}
                });
                return;
            case "zendeskMessaging.sdk.initialize":
                n.zendesk.initializeZendeskMessagingSdk(), J(r, {
                    integration: "zendeskMessaging",
                    action: "sdk.initialize",
                    payload: {}
                });
                return;
            case "zendeskMessaging.sdk.destroy":
                n.zendesk.destroyZendeskMessagingSdk(), J(r, {
                    integration: "zendeskMessaging",
                    action: "sdk.destroy",
                    payload: {}
                });
                return;
            case "zendeskMessaging.conversation.load":
                n.zendesk.loadZendeskMessagingConversation(), J(r, {
                    integration: "zendeskMessaging",
                    action: "conversation.load",
                    payload: {}
                });
                return;
            case "voice.recording.start":
                n.voice.startVoiceRecording();
                return;
            case "voice.recording.stop":
                n.voice.stopVoiceRecording();
                return;
            case "voice.mode.set":
                {
                    let e = u ? .mode === "push-to-talk" ? "push-to-talk" : "toggle";
                    n.voice.setVoiceMode(e);
                    return;
                }
            case "voice.transcript.apply":
                return;
            case "voice.tts.toggle":
                {
                    let e = typeof u ? .enabled == "boolean" ? u.enabled : !1;
                    n.voice.toggleTTS(e);
                    return;
                }
            case "file.upload.start":
                {
                    let e = u ? .file,
                        i = typeof u ? .uploadId == "string" ? u.uploadId : void 0,
                        a = typeof u ? .platform == "string" ? u.platform : void 0;
                    if (!(typeof File < "u" && e instanceof File) || !n.startFileUpload(e, a, i)) return;
                    let o = t.store.getState(),
                        s = wl(o) ? ? a;
                    if (s === "zaw_liveagent") {
                        n.uploadZendeskMessagingAttachment(e);
                        return;
                    }
                    if (s === "zendesk_support_liveagent") {
                        n.uploadZendeskSupportFile(e);
                        return;
                    }
                    if (s === "salesforce_liveagent") {
                        n.uploadSalesforceFile(e);
                        return;
                    }
                    if (s && Xt(s)) {
                        n.uploadHandoffIntegrationFile(e);
                        return;
                    }
                    let c = n.createFileUploadCommandId();
                    if (!c) return;
                    J(r, {
                        integration: "fileUpload",
                        action: "upload.start",
                        commandId: c,
                        payload: {
                            file: e,
                            fileName: e.name,
                            fileType: e.type,
                            fileSize: e.size,
                            platform: s,
                            conversationId: o.session.conversationId,
                            transfer: o.liveAgent.file.transfer
                        }
                    });
                    return;
                }
            case "file.upload.retry":
                {
                    let e = u ? .file,
                        i = typeof u ? .uploadId == "string" ? u.uploadId : void 0;
                    if (!(typeof File < "u" && e instanceof File)) return;
                    if (!n.retryFileUpload(e, i)) {
                        if (t.store.getState().liveAgent.file.isUploading) return;
                        let e = t.store.getState().liveAgent.file.uploadError;
                        t.store.dispatch(U(e ? {
                            ...e,
                            errorData: {
                                ...e.errorData,
                                retryable: !1
                            }
                        } : {
                            errorKey: "FILE_UPLOAD_ERROR",
                            errorData: {
                                reason: "invalid_context"
                            }
                        }));
                        return;
                    }
                    let a = t.store.getState(),
                        o = wl(a);
                    if (o === "zaw_liveagent") {
                        n.uploadZendeskMessagingAttachment(e);
                        return;
                    }
                    if (o === "zendesk_support_liveagent") {
                        n.uploadZendeskSupportFile(e);
                        return;
                    }
                    if (o === "salesforce_liveagent") {
                        n.uploadSalesforceFile(e);
                        return;
                    }
                    if (o && Xt(o)) {
                        n.uploadHandoffIntegrationFile(e);
                        return;
                    }
                    if (o === "zendesk_liveagent" && n.retryZendeskChatDeliveredFileLog()) return;
                    let s = n.createFileUploadCommandId();
                    if (!s) return;
                    J(r, {
                        integration: "fileUpload",
                        action: "upload.retry",
                        commandId: s,
                        payload: {
                            file: e,
                            fileName: e.name,
                            fileType: e.type,
                            fileSize: e.size,
                            platform: o,
                            conversationId: a.session.conversationId,
                            transfer: a.liveAgent.file.transfer
                        }
                    });
                    return;
                }
            case "file.upload.cancel":
                n.cancelFileUpload(), J(r, {
                    integration: "fileUpload",
                    action: "upload.cancel",
                    payload: {}
                });
                return;
            case "file.upload.errorDismiss":
                t.store.dispatch(it());
                return;
            case "security.turnstile.verify":
                {
                    let e = q(u ? .token);
                    e && t.store.dispatch(va(e));
                    return;
                }
            case "security.turnstile.error":
                t.store.dispatch(o("Verification failed. Please try again."));
                return;
            case "security.turnstile.expire":
                t.store.dispatch(po());
                return;
            case "ui.secretMessage.toggle":
                {
                    let e = typeof u ? .open == "boolean" ? u.open : !1;
                    n.settleChatterTyping(),
                    n.setSecretMessageOpen(e);
                    return;
                }
            case "ui.toast.dismiss":
                t.store.dispatch(ta(!1)), t.store.dispatch(Xr(null));
                return;
            case "outage.retry":
                window.location.reload();
                return;
            case "app.startNewConversation":
            case "app.reset":
                {
                    r("core.endChat.cancelMinimize", void 0);
                    let a = t.lifecycle.signal,
                        {
                            session: o
                        } = t.store.getState();
                    if (_ ? .signal === a && _.conversationId === o.conversationId && _.generation === o.conversationGeneration) {
                        _.event = e;
                        return;
                    }
                    let s = n.waitForPendingProactiveInjections();
                    if (!s) {
                        _ ? .release(!1), t.store.dispatch(ur(!1)), e === "app.reset" ? E() : T();
                        return;
                    }
                    _ ? .release(!1);
                    let {
                        settled: c,
                        release: l
                    } = s,
                    u = {
                        event: e,
                        signal: a,
                        conversationId: o.conversationId,
                        generation: o.conversationGeneration,
                        release: m
                    };
                    _ = u;
                    let d = t.store.getState().chat.acceptedUserSendSeq,
                        f = t.store.subscribe(() => {
                            let {
                                session: e,
                                chat: n
                            } = t.store.getState();
                            (e.conversationId !== u.conversationId || e.conversationGeneration !== u.generation || n.acceptedUserSendSeq !== d) && m();
                        }),
                        p = () => m();
                    a.addEventListener("abort", p, {
                        once: !0
                    });

                    function m(e = !0) {
                        _ === u && (_ = null, f(), a.removeEventListener("abort", p), l(), e && t.store.dispatch(ur(!1)));
                    }
                    t.store.dispatch(ur(!0)),
                    c.then((e) => {
                        if (_ !== u || a.aborted) return;
                        let n = t.store.getState();
                        if (!(e || n.session.conversationGeneration !== u.generation || n.session.conversationId !== u.conversationId)) {
                            m(!1);
                            try {
                                j(u.event, void 0);
                            } finally {
                                _ === null && t.store.dispatch(ur(!1));
                            }
                        }
                    }).catch((e) => {
                        i.error("Starting conversation after proactive failed:", e);
                    }).finally(m);
                    return;
                }
            case "capture.submit":
                {
                    let e = q(u ? .value),
                        t = typeof u ? .dataId == "string" ? u.dataId : null,
                        r = q(u ? .submitId) || void 0;
                    e && t !== null && n.submitCapture(e, t, r);
                    return;
                }
            case "capture.cancel":
                {
                    let e = q(u ? .cancelResponseId),
                        t = q(u ? .cancelLabel),
                        r = typeof u ? .dataId == "string" ? u.dataId : null;
                    e && r !== null && n.cancelCapture(e, t, r);
                    return;
                }
            case "listSelection.cancel":
                {
                    let e = q(u ? .cancelResponseId),
                        t = q(u ? .cancelLabel),
                        r = typeof u ? .dataId == "string" ? u.dataId : null;
                    e && r !== null && n.cancelListSelection(e, t, r);
                    return;
                }
            case "chat.selectableList.submit":
                {
                    let e = Array.isArray(u ? .selectedIds) ? u.selectedIds.filter((e) => typeof e == "string") : [],
                        t = typeof u ? .dataId == "string" ? u.dataId : null;
                    e.length > 0 && t !== null && n.submitSelectableList(e, t);
                    return;
                }
            case "chat.option.select":
                {
                    let e = typeof u ? .optionId == "string" ? u.optionId : "",
                        r = typeof u ? .optionLabel == "string" ? u.optionLabel : void 0;
                    if (e) {
                        let i = q(u ? .messageId);
                        i && t.store.dispatch(tr(i)), n.submitSelectedOption(e, r);
                    }
                    return;
                }
            case "chat.message.reaction.add":
                {
                    let e = q(u ? .messageId),
                        n = rl(u ? .reaction);
                    e && n !== null && Jc({
                        store: t.store
                    }, e, n);
                    return;
                }
            case "chat.messages.read":
                {
                    let e = q(u ? .cursor),
                        n = q(u ? .conversationId) || t.store.getState().session.conversationId;
                    n && e && t.store.dispatch(co({
                        conversationId: n,
                        cursor: e
                    }));
                    return;
                }
            case "csat.checkEndChatEligibility":
                {
                    let e = t.store.getState().session.conversationId;
                    t.store.dispatch(Ne(e));
                    try {
                        ga(t.store, "bot");
                    } catch {}
                    try {
                        ga(t.store, "agent");
                    } catch {}
                    Ja(t.store, e ? ? "");
                    return;
                }
            case "csat.shown":
                {
                    let e = q(u ? .surveyType) || "end_chat";
                    if (jo(e)) return;
                    let n = t.store.getState(),
                        r = n.session.endpoint,
                        i = El(n, e, q(u ? .conversationId));
                    if (!r || !i) return;
                    let a = n.session.chatterToken,
                        o = n.session.sessionToken,
                        s = r.endsWith("/") ? r : `${r}/`,
                        c = new URL("surveys/track_survey_shown/", s).toString(),
                        l = {
                            "Content-Type": "application/json",
                            "X-Ada-Request-Origin": "chat",
                            ...a ? {
                                "Chatter-Token": a
                            } : {},
                            ...o ? {
                                "Session-Auth": o
                            } : {}
                        };
                    fetch(c, {
                        method: "POST",
                        credentials: "include",
                        headers: l,
                        body: JSON.stringify({
                            conversation_id: i,
                            survey_type: e
                        })
                    }).catch(() => {});
                    return;
                }
            case "csat.submit":
                {
                    let e = Date.now(),
                        n = hl(u ? .data),
                        o = q(u ? .surveyType),
                        c = u ? .partial === !0,
                        {
                            uiComplete: l,
                            inlineAnswerId: d,
                            reportTerminalError: f
                        } = gl(u),
                        m = u ? .submit,
                        h = u ? .endConversation;
                    m === void 0 && u ? .uiComplete === void 0 && (m = c && o === "proactive" ? void 0 : !c || o === "end_chat", h === void 0 && o === "end_chat" && (h = "endChat"));
                    let g = (e, n) => {
                        !l && !d || t.store.dispatch(y({
                            message: f ? e : null,
                            inlineAnswerId: d,
                            surveyType: o,
                            conversationId: n
                        }));
                    };
                    if (!n || !o) {
                        let e = u ? .surveyType;
                        (l || d) && typeof e == "string" && t.store.dispatch(y({
                            message: f ? "Invalid survey submission." : null,
                            inlineAnswerId: d,
                            surveyType: e,
                            conversationId: El(t.store.getState(), e, q(u ? .conversationId))
                        }));
                        return;
                    }
                    let _ = t.store.getState(),
                        b = _.session.endpoint,
                        x = l && h === "inline" ? a.get(o) : void 0,
                        S = El(_, o, q(u ? .conversationId) || x ? .conversationId),
                        C = s.get(S ? ? "") ? ? {
                            tail: Promise.resolve(),
                            pending: 0,
                            surveys: /* @__PURE__ */ new Map()
                        },
                        w = C.surveys.get(o) ? ? {
                            answers: {},
                            queuedAutosaves: /* @__PURE__ */ new Set()
                        },
                        T = {
                            ...w.answers,
                            ...n
                        },
                        E = T.score !== void 0 && T.score !== null,
                        D = yl(T.score);
                    if (E && D === null) {
                        g("Invalid CSAT score.", S);
                        return;
                    }
                    if (!b || !S) {
                        g("No conversation to submit the survey for.", S);
                        return;
                    }!q(u ? .conversationId) && !x && a.set(o, {
                        conversationId: S,
                        generation: _.session.conversationGeneration
                    });
                    let O = _.session.chatterToken,
                        ee = _.session.sessionToken,
                        A = D === null ? null : ts(D, q(T.style));
                    if (D !== null && !A) {
                        g("Invalid CSAT score for the selected scale.", S);
                        return;
                    }
                    f && t.store.dispatch(y({
                        message: null
                    }));
                    let j = bl(T.feedback),
                        te = x ? .conversationId === S ? x.generation : _.session.conversationGeneration,
                        ne = v;
                    w.answers = T,
                    C.surveys.set(o, w),
                    s.set(S, C),
                    C.pending += 1;
                    let M = new AbortController();
                    if (l) {
                        for (let e of w.queuedAutosaves) e.abort();
                        w.queuedAutosaves.clear();
                    } else w.queuedAutosaves.add(M);
                    let re, ie = !1,
                        N = e + Qc,
                        ae = () => {
                            let e = /* @__PURE__ */ Error("CSAT submission timed out.");
                            !ie && !p && g(e.message, S), M.abort(e);
                        };
                    l && (re = setTimeout(ae, Math.max(0, N - Date.now()))),
                    C.tail = C.tail.then(async () => {
                        if (l && !M.signal.aborted && Date.now() >= N && ae(), M.signal.aborted || p || !l && t.store.getState().session.conversationGeneration !== te) {
                            w.queuedAutosaves.delete(M), clearTimeout(re);
                            return;
                        }
                        w.queuedAutosaves.delete(M);
                        let e, n = !1;
                        try {
                            let a = b.endsWith("/") ? b : `${b}/`,
                                s = new URL("surveys/submit_survey/", a).toString(),
                                u = {
                                    conversation_id: S,
                                    survey_type: o
                                };
                            typeof m == "boolean" && (u.submit = m), c && o !== "proactive" && (u.partial = !0), A && (u.csat_score = A.score, u.csat_style = A.style), typeof T.comment == "string" && (u.comment = T.comment.trim()), j && (u.feedback = j), typeof T.resolved == "boolean" && (u.resolved = T.resolved), typeof T.customerEffortScore == "number" && Number.isFinite(T.customerEffortScore) && (u.customer_effort_score = T.customerEffortScore), typeof T.netPromoterScore == "number" && Number.isFinite(T.netPromoterScore) && (u.net_promoter_score = T.netPromoterScore);
                            let g = {
                                "Content-Type": "application/json",
                                "X-Ada-Request-Origin": "chat",
                                ...O ? {
                                    "Chatter-Token": O
                                } : {},
                                ...ee ? {
                                    "Session-Auth": ee
                                } : {}
                            };
                            ie = !0, l || (re = setTimeout(ae, Qc));
                            let _ = new Promise((t, n) => {
                                    e = () => n(M.signal.reason), M.signal.addEventListener("abort", e, {
                                        once: !0
                                    });
                                }),
                                {
                                    response: v,
                                    responseBody: x
                                } = await Promise.race([fetch(s, {
                                    method: "POST",
                                    credentials: "include",
                                    headers: g,
                                    body: JSON.stringify(u),
                                    signal: M.signal
                                }).then(async (e) => ({
                                    response: e,
                                    responseBody: await Sl(e)
                                })), _]);
                            if (M.signal.aborted) return;
                            if (!v.ok) {
                                p || (f && i.error(`CSAT submission failed with status ${v.status}.`), (f || d) && t.store.dispatch(y({
                                    inlineAnswerId: d,
                                    message: f ? `CSAT submission failed with status ${v.status}.` : null,
                                    surveyType: o,
                                    conversationId: S
                                })));
                                return;
                            }
                            if (n = !0, !p && m === !0 && !(c && o !== "proactive")) {
                                let e = Fr(A);
                                r("core.event.publish", {
                                    key: "ada:csat_submitted",
                                    data: {
                                        conversation_id: S,
                                        ...e === void 0 ? {} : {
                                            csat_score: e
                                        }
                                    }
                                });
                            }
                            if (!l || p) return;
                            let C = {
                                surveyType: o,
                                conversationId: S
                            };
                            A && (C.score = A.score, A.style === "NUMERIC_TEN" ? C.score = Math.ceil(A.score / 2) : A.style === "THUMBS" && (C.score = A.score * 4 + 1), C.scaleType = {
                                NUMERIC: "1-5",
                                NUMERIC_TEN: "1-10",
                                THUMBS: "thumbs",
                                EMOJI: "emoji"
                            }[A.style]);
                            let w = bl(x ? .feedback);
                            (w ? ? j) && (C.feedback = w ? ? j ? ? []), typeof x ? .resolved == "boolean" || x ? .resolved === null ? C.resolved = x.resolved : typeof T.resolved == "boolean" && (C.resolved = T.resolved);
                            let E = typeof x ? .comment == "string" ? x.comment.trim() : null,
                                D = typeof T.comment == "string" ? T.comment.trim() : null,
                                N = E ? ? D;
                            N !== null && (C.comment = N);
                            let oe = yl(x ? .customer_effort_score),
                                se = yl(T.customerEffortScore);
                            (oe !== null || se !== null) && (C.customerEffortScore = oe ? ? se);
                            let ce = yl(x ? .net_promoter_score),
                                le = yl(T.netPromoterScore);
                            (ce !== null || le !== null) && (C.netPromoterScore = ce ? ? le), (typeof x ? .csat_is_positive == "boolean" || x ? .csat_is_positive === null) && (C.isPositive = x.csat_is_positive), t.store.dispatch(cs(C));
                            let ue = t.store.getState().session.conversationId === S,
                                de = t.store.getState().session.conversationGeneration === te;
                            de && (t.store.dispatch(Tt(!1)), t.store.dispatch(nn(!1))), t.store.dispatch(Pn({
                                surveyType: o,
                                conversationId: S,
                                sameGeneration: de
                            })), (h === "inline" || h === "endChat") && $c.has(o) && ue && de && k(S, h === "inline", ne);
                        } catch (e) {
                            if (!p && (f || !n)) {
                                f && i.error("CSAT submission failed:", e);
                                let n = e instanceof Error ? e.message : "CSAT submission failed.";
                                (f || d) && t.store.dispatch(y({
                                    inlineAnswerId: d,
                                    message: f ? n : null,
                                    surveyType: o,
                                    conversationId: S
                                }));
                            }
                        } finally {
                            clearTimeout(re), e && M.signal.removeEventListener("abort", e);
                        }
                    }),
                    C.tail = C.tail.catch((e) => {
                        i.warn ? .("CSAT write chain failed:", e);
                    }).finally(() => {
                        --C.pending, C.pending === 0 && t.store.getState().session.conversationId !== S && s.delete(S);
                    });
                    return;
                }
            case "chat.link.click":
                {
                    let e = t.store.getState(),
                        n = q(u ? .messageId);
                    if (!n) {
                        let t = !e.session._appFrameIsCustom && u ? .navigateInHost === !0 && typeof u.url == "string" ? yn(u.url, e.session.androidHostNavigation, Os()) : null;
                        t && r("core.host.navigate", {
                            url: t,
                            allowedProtocols: e.session.allowedProtocols ? ? []
                        });
                        return;
                    }
                    let i = e.chat.messages.find((e) => e.id === n);
                    if (!i || i.type !== "link") return;
                    let a = e.session.features ? .afmHandoffEvents === !0,
                        o = i.isWebWindow ? void 0 : i.successBusinessEvent;
                    a && o ? .eventKey && dc(e.session, {
                        key: o.eventKey,
                        value: o.value,
                        isVariable: o.isVariable,
                        meta: {
                            triggered_by: i.id,
                            event_subtype: "link_block_handoff"
                        }
                    }, {
                        keepalive: !0
                    });
                    let {
                        type: s,
                        params: c
                    } = _l(i, a);
                    if (Gc({
                            store: t.store
                        }, s, c), u ? .navigateInHost === !0 && !e.session._appFrameIsCustom && !vl(i) && (i.newWindow !== !1 || i.isWebWindow)) {
                        let t = yn(i.url, e.session.androidHostNavigation, Os());
                        t && r("core.host.navigate", {
                            url: t,
                            allowedProtocols: e.session.allowedProtocols ? ? []
                        });
                    }
                    if (u ? .navigateInHost === !0 && i.newWindow === !1 && !vl(i) && !i.isWebWindow) {
                        let t = e.session.allowedProtocols ? ? [],
                            n = Fn(i.url, t);
                        n && r("core.host.navigate", {
                            url: n,
                            allowedProtocols: t
                        });
                    }
                    return;
                }
            case "chat.widget.carouselLinkClick":
                {
                    let e = t.store.getState(),
                        n = q(u ? .messageId),
                        r = ul(u ? .url, e.session.allowedProtocols ? ? []),
                        a = ll(u ? .actionType),
                        o = null;
                    if (n ? r === null ? o = "url outside the link policy" : a === null && (o = "unsupported actionType") : o = "missing messageId", o !== null) {
                        i.warn ? .("chat.widget.carouselLinkClick dropped:", o);
                        return;
                    }
                    let s = e.chat.messages.find((e) => e.id === n);
                    if (!s || s.type !== "widget") {
                        i.warn ? .("chat.widget.carouselLinkClick dropped:", "no stored widget message");
                        return;
                    }
                    Gc({
                        store: t.store
                    }, "link_click", {
                        message_id: s.id,
                        url: r,
                        subtype: a,
                        is_carousel: !0
                    });
                    return;
                }
            case "image.print.request":
                {
                    let e = b(q(u ? .url));
                    e && r("core.host.printImage", {
                        url: e
                    });
                    return;
                }
            case "ui.frameStyles.set":
                {
                    if (!t.store.getState().session._appFrameIsCustom) return;
                    let e = xi(u ? .styles);
                    if (e === null) {
                        let e = hl(u ? .styles),
                            t = e ? Object.keys(e) : [];
                        i.warn ? .("ui.frameStyles.set rejected invalid style keys", {
                            keys: t.slice(0, 15).map((e) => e.slice(0, 32)),
                            totalKeyCount: t.length
                        });
                        return;
                    }
                    g = Object.keys(e).length > 0,
                    r("core.host.frameStyles.set", {
                        styles: e
                    });
                    return;
                }
            case "ui.hostViewport.set":
                typeof u ? .expanded == "boolean" && (h = u.expanded, r("core.host.viewport.set", {
                    expanded: u.expanded
                }));
                return;
            default:
                return;
        }
    }
    return {
        handleEvent: j,
        destroy: (e) => {
            p = !0, f(), s.clear(), _ ? .release(), g && (g = !1, e !== "reset-remount" && r("core.host.frameStyles.set", {
                styles: {}
            })), h && (h = !1, r("core.host.viewport.set", {
                expanded: !1
            }));
        }
    };
}
//#endregion
//#region src/browser-language.ts
function Ol() {
    return typeof navigator < "u" && navigator.language ? navigator.language : void 0;
}
//#endregion
//#region src/connectivity-probe.ts
var kl = B("connectivity-probe"),
    Al = 3e3,
    jl = 1500,
    Ml = 15e3;

function Nl(e) {
    let {
        store: t
    } = e, n = e.fetchImpl ? ? ((e, t) => fetch(e, t)), r = null, i = null, a = null, o = null, s = null, c = null, l = !1;

    function u() {
        let {
            browserOffline: e,
            connectivityNoticeRaised: n
        } = t.getState().connection;
        return e ? "loss" : n ? "recovery" : null;
    }

    function d(e) {
        let {
            browserConnectivitySeq: n,
            transportConnectedSeq: r
        } = t.getState().connection;
        return `${e}:${n}:${r}`;
    }

    function f() {
        a ? .abort(), a = null, o && = (clearTimeout(o), null), s ? .(), s = null;
    }

    function p() {
        l || c || (c = setTimeout(() => {
            c = null;
            let {
                browserOffline: e,
                connectivityLost: n
            } = t.getState().connection;
            l || !e || !n || _.check();
        }, Ml));
    }

    function m(e) {
        return new Promise((t) => {
            s = t, o = setTimeout(t, e);
        });
    }
    async function h(e) {
        let t = new AbortController();
        a = t;
        let r = setTimeout(() => {
            t.abort(new DOMException("Connectivity probe timed out", "TimeoutError"));
        }, Al);
        try {
            return await n(e, {
                method: "HEAD",
                mode: "no-cors",
                cache: "no-store",
                credentials: "omit",
                signal: t.signal
            }), !0;
        } catch {
            return !1;
        } finally {
            clearTimeout(r), a === t && (a = null);
        }
    }
    async function g(e, n, a) {
        let o = () => !l && u() === n && d(n) === a;
        try {
            for (let r = 0; r < 3; r += 1) {
                if (r > 0 && (await m(jl), !o())) return;
                let i = await h(e);
                if (!o()) return;
                if (!i) {
                    if (R("messaging_connectivity_probe_settled", {
                            question: n,
                            reachable: !1,
                            attempts: r + 1
                        }), n === "recovery") {
                        t.dispatch(So());
                        return;
                    }
                    t.dispatch(Oi()), p();
                    return;
                }
            }
            R("messaging_connectivity_probe_settled", {
                question: n,
                reachable: !0,
                attempts: 3
            }), t.dispatch(fi());
        } finally {
            i === a && (r = null, i = null);
        }
    }
    let _ = {
        check() {
            if (l) return Promise.resolve();
            let e = u();
            if (!e) return Promise.resolve();
            let n = d(e);
            if (r) {
                if (i === n) return r;
                f();
            }
            let {
                endpoint: a
            } = t.getState().session;
            return a ? (i = n, r = g(a, e, n), r) : (kl.debug("no endpoint configured yet; skipping probe"), Promise.resolve());
        },
        destroy() {
            l = !0, f(), c && = (clearTimeout(c), null), r = null, i = null;
        }
    };
    return _;
}
//#endregion
//#region ../../node_modules/@launchdarkly/js-client-sdk/dist/index.js
var Pl = Object.defineProperty,
    Fl = Object.defineProperties,
    Il = Object.getOwnPropertyDescriptors,
    Ll = Object.getOwnPropertySymbols,
    Rl = Object.prototype.hasOwnProperty,
    zl = Object.prototype.propertyIsEnumerable,
    Bl = (e, t, n) => t in e ? Pl(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n,
    Y = (e, t) => {
        for (var n in t || = {}) Rl.call(t, n) && Bl(e, n, t[n]);
        if (Ll)
            for (var n of Ll(t)) zl.call(t, n) && Bl(e, n, t[n]);
        return e;
    },
    Vl = (e, t) => Fl(e, Il(t)),
    Hl = (e, t) => {
        var n = {};
        for (var r in e) Rl.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
        if (e != null && Ll)
            for (var r of Ll(e)) t.indexOf(r) < 0 && zl.call(e, r) && (n[r] = e[r]);
        return n;
    };

function Ul(e) {
    return `/${e.replace(/~/g, "~0").replace(/\//g, "~1")}`;
}

function Wl(e) {
    return e.indexOf("~") ? e.replace(/~1/g, "/").replace(/~0/g, "~") : e;
}

function Gl(e) {
    return (e.startsWith("/") ? e.substring(1) : e).split("/").map((e) => Wl(e));
}

function Kl(e) {
    return !e.startsWith("/");
}

function ql(e) {
    return !e.match(/\/\/|(^\/.*~[^0|^1])|~$/);
}
var Jl = class {
    constructor(e, t = !1) {
        if (t) {
            let t = e;
            this.g = [t], this.isValid = t !== "", this.redactionName = t.startsWith("/") ? Ul(t) : t;
        } else {
            if (this.redactionName = e, e === "" || e === "/" || !ql(e)) {
                this.isValid = !1, this.g = [];
                return;
            }
            Kl(e) ? this.g = [e] : e.indexOf("/", 1) < 0 ? this.g = [Wl(e.slice(1))] : this.g = Gl(e), this.g[0] === "_meta" ? this.isValid = !1 : this.isValid = !0;
        }
    }
    get(e) {
        let {
            g: t,
            isValid: n
        } = this;
        if (!n) return;
        let r = e;
        for (let e = 0; e < t.length; e += 1) {
            let n = t[e];
            if (r != null && Object.prototype.hasOwnProperty.call(r, n) && typeof r == "object" && !Array.isArray(r)) r = r[n];
            else return;
        }
        return r;
    }
    getComponent(e) {
        return this.g[e];
    }
    get depth() {
        return this.g.length;
    }
    get isKind() {
        return this.g.length === 1 && this.g[0] === "kind";
    }
    compare(e) {
        return this.depth === e.depth && this.g.every((t, n) => t === e.getComponent(n));
    }
    get components() {
        return [...this.g];
    }
};
Jl.InvalidReference = new Jl("");
var Yl = class {
        is(e) {
            if (Array.isArray(e)) return !1;
            let t = typeof e;
            return t === "function" || t === "object";
        }
        getType() {
            return "factory method or object";
        }
    },
    Xl = class {
        constructor(e, t) {
            this.mt = e, this.typeOf = typeof t;
        }
        is(e) {
            return Array.isArray(e) ? !1 : typeof e === this.typeOf;
        }
        getType() {
            return this.mt;
        }
    },
    Zl = class {
        constructor(e, t) {
            this.mt = e, this.typeOf = typeof t;
        }
        is(e) {
            return Array.isArray(e) ? e.length > 0 ? e.every((e) => typeof e === this.typeOf) : !0 : !1;
        }
        getType() {
            return this.mt;
        }
    },
    Ql = class extends Xl {
        constructor(e) {
            super(`number with minimum value of ${e}`, 0), this.min = e;
        }
        is(e) {
            return typeof e === this.typeOf && e >= this.min;
        }
    },
    $l = class extends Xl {
        constructor(e) {
            super(`string matching ${e}`, ""), this.expression = e;
        }
        is(e) {
            return typeof e == "string" && !!e.match(this.expression);
        }
    },
    eu = class {
        is(e) {
            return typeof e == "function";
        }
        getType() {
            return "function";
        }
    },
    tu = class {
        is(e) {
            return typeof e == "boolean" || e == null;
        }
        getType() {
            return "boolean | undefined | null";
        }
    },
    nu = /^\d\d\d\d-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d\d*)?(Z|[-+]\d\d(:\d\d)?)/,
    ru = class {
        is(e) {
            return typeof e == "number" || typeof e == "string" && nu.test(e);
        }
        getType() {
            return "date";
        }
    },
    iu = class extends $l {
        constructor() {
            super(/^(\w|\.|-)+$/);
        }
        is(e) {
            return super.is(e) && e !== "kind";
        }
    },
    X = class {
        static createTypeArray(e, t) {
            return new Zl(e, t);
        }
        static numberWithMin(e) {
            return new Ql(e);
        }
        static stringMatchingRegex(e) {
            return new $l(e);
        }
    };
X.String = new Xl("string", ""), X.Number = new Xl("number", 0), X.ObjectOrFactory = new Yl(), X.Object = new Xl("object", {}), X.StringArray = new Zl("string[]", ""), X.Boolean = new Xl("boolean", !0), X.Function = new eu(), X.Date = new ru(), X.Kind = new iu(), X.NullableBoolean = new tu();

function au(e) {
    return "kind" in e ? X.String.is(e.kind) && e.kind !== "multi" : !1;
}

function ou(e) {
    return "kind" in e ? X.String.is(e.kind) && e.kind === "multi" : !1;
}

function su(e) {
    return !("kind" in e) || e.kind === null || e.kind === void 0;
}

function cu(e, t = []) {
    if (typeof e != "object" || !e) return JSON.stringify(e);
    if (t.includes(e)) throw Error("Cycle detected");
    return Array.isArray(e) ? `[${e.map((n) => cu(n, [...t, e])).map((e) => e === void 0 ? "null" : e).join(",")}]` : `{${Object.keys(e).sort().map((n) => {
		let r = cu(e[n], [...t, e]);
		if (r !== void 0) return `${JSON.stringify(n)}:${r}`;
	}).filter((e) => e !== void 0).join(",")}}`;
}
var lu = "user";

function uu(e) {
    return e.includes("%") || e.includes(":") ? e.replace(/%/g, "%25").replace(/:/g, "%3A") : e;
}

function du(e) {
    return e && X.Object.is(e);
}

function fu(e) {
    return X.Kind.is(e);
}

function pu(e) {
    return X.String.is(e) && e !== "";
}

function mu(e, t = !1) {
    return e ? e.map((e) => new Jl(e, t)) : [];
}

function hu(e) {
    return e != null;
}

function gu(e) {
    let t = Vl(Y({}, e.custom || []), {
        kind: "user",
        key: String(e.key)
    });
    if (hu(e.anonymous)) {
        let n = !!e.anonymous;
        delete t.anonymous, t.anonymous = n;
    }
    return e.name !== null && e.name !== void 0 && (t.name = e.name), e.ip !== null && e.ip !== void 0 && (t.ip = e.ip), e.firstName !== null && e.firstName !== void 0 && (t.firstName = e.firstName), e.lastName !== null && e.lastName !== void 0 && (t.lastName = e.lastName), e.email !== null && e.email !== void 0 && (t.email = e.email), e.avatar !== null && e.avatar !== void 0 && (t.avatar = e.avatar), e.country !== null && e.country !== void 0 && (t.country = e.country), e.privateAttributeNames !== null && e.privateAttributeNames !== void 0 && (t._meta = {
        privateAttributes: e.privateAttributeNames
    }), t;
}
var _u = class e {
    constructor(e, t, n) {
        this.C = !1, this.it = !1, this.Xt = !1, this.$ = {}, this.kind = t, this.valid = e, this.message = n;
    }
    static b(t, n) {
        return new e(!1, t, n);
    }
    static Re(e, t) {
        if (!(!t || !e.isValid)) return e.depth === 1 && e.getComponent(0) === "anonymous" ? !!(t != null && t.anonymous) : e.get(t);
    }
    Qt(e) {
        if (this.C) return this.$[e];
        if (this.kind === e) return this.y;
    }
    static Me(t) {
        let n = Object.keys(t).filter((e) => e !== "kind"),
            r = n.every(fu);
        if (!n.length) return e.b("multi", "A multi-kind context must contain at least one kind");
        if (!r) return e.b("multi", "Context contains invalid kinds");
        let i = {},
            a = !0,
            o = n.reduce((e, n) => {
                let r = t[n];
                return du(r) ? (e[n] = r, i[n] = mu(r._meta ? .privateAttributes)) : a = !1, e;
            }, {});
        if (!a) return e.b("multi", "Context contained contexts that were not objects");
        if (!Object.values(o).every((e) => pu(e.key))) return e.b("multi", "Context contained invalid keys");
        if (n.length === 1) {
            let t = n[0],
                r = new e(!0, t);
            return r.y = Vl(Y({}, o[t]), {
                kind: t
            }), r.nt = i, r.it = t === "user", r;
        }
        let s = new e(!0, t.kind);
        return s.$ = o, s.nt = i, s.C = !0, s;
    }
    static Fe(t) {
        let {
            key: n,
            kind: r
        } = t, i = fu(r), a = pu(n);
        if (!i) return e.b(r ? ? "unknown", "The kind was not valid for the context");
        if (!a) return e.b(r, "The key for the context was not valid");
        let o = mu(t._meta ? .privateAttributes),
            s = new e(!0, r);
        return s.it = r === "user", s.y = t, s.nt = {
            [r]: o
        }, s;
    }
    static Ue(t) {
        if (!(t.key !== void 0 && t.key !== null)) return e.b("user", "The key for the context was not valid");
        let n = new e(!0, "user");
        return n.it = !0, n.Xt = !0, n.y = gu(t), n.nt = {
            user: mu(t.privateAttributeNames, !0)
        }, n;
    }
    static fromLDContext(t) {
        return t ? au(t) ? e.Fe(t) : ou(t) ? e.Me(t) : su(t) ? e.Ue(t) : e.b("unknown", "Context was not of a valid kind") : e.b("unknown", "No context specified. Returning default value");
    }
    static toLDContext(e) {
        if (!e.valid) return;
        let t = e.getContexts();
        if (!e.C) return t[0][1];
        let n = {
            kind: "multi"
        };
        return t.forEach((e) => {
            let t = e[0];
            n[t] = e[1];
        }), n;
    }
    valueForKind(t, n = lu) {
        return t.isKind ? this.kinds : e.Re(t, this.Qt(n));
    }
    key(e = lu) {
        return this.Qt(e) ? .key;
    }
    get isMultiKind() {
        return this.C;
    }
    get canonicalKey() {
        return this.it ? this.y.key : this.C ? Object.keys(this.$).sort().map((e) => `${e}:${uu(this.$[e].key)}`).join(":") : `${this.kind}:${uu(this.y.key)}`;
    }
    get kinds() {
        return this.C ? Object.keys(this.$) : [this.kind];
    }
    get kindsAndKeys() {
        return this.C ? Object.entries(this.$).reduce((e, [t, n]) => (e[t] = n.key, e), {}) : {
            [this.kind]: this.y.key
        };
    }
    privateAttributes(e) {
        return this.nt ? .[e] || [];
    }
    getContexts() {
        return this.C ? Object.entries(this.$) : [
            [this.kind, this.y]
        ];
    }
    get legacy() {
        return this.Xt;
    }
    canonicalUnfilteredJson() {
        if (this.valid) {
            if (this.yt) return this.yt;
            try {
                this.yt = cu(e.toLDContext(this));
            } catch {}
            return this.yt;
        }
    }
};
_u.UserKind = lu;
var vu = [
        "key",
        "kind",
        "_meta",
        "anonymous"
    ].map((e) => new Jl(e, !0)),
    yu = [
        "name",
        "ip",
        "firstName",
        "lastName",
        "email",
        "avatar",
        "country"
    ];

function bu(e, t) {
    return e.depth === t.length && t.every((t, n) => t === e.getComponent(n));
}

function xu(e, t) {
    let n = [],
        r = {},
        i = [];
    for (n.push(...Object.keys(e).map((t) => ({
            key: t,
            ptr: [t],
            source: e,
            parent: r,
            visited: [e]
        }))); n.length;) {
        let e = n.pop(),
            r = t.find((t) => bu(t, e.ptr));
        if (r) i.push(r.redactionName);
        else {
            let t = e.source[e.key];
            t === null ? e.parent[e.key] = t : Array.isArray(t) ? e.parent[e.key] = [...t] : typeof t == "object" ? e.visited.includes(t) || (e.parent[e.key] = {}, n.push(...Object.keys(t).map((n) => ({
                key: n,
                ptr: [...e.ptr, n],
                source: t,
                parent: e.parent[e.key],
                visited: [...e.visited, t]
            })))) : e.parent[e.key] = t;
        }
    }
    return {
        cloned: r,
        excluded: i.sort()
    };
}
var Su = class {
        constructor(e, t) {
            this.Ve = e, this.je = t;
        }
        filter(e, t = !1) {
            let n = e.getContexts();
            if (n.length === 1) return this.te(e, n[0][1], n[0][0], t);
            let r = {
                kind: "multi"
            };
            return n.forEach(([n, i]) => {
                r[n] = this.te(e, i, n, t);
            }), r;
        }
        He(e, t, n, r) {
            return (r ? Object.keys(t).map((e) => new Jl(e, !0)) : [...this.je, ...e.privateAttributes(n)]).filter((e) => !vu.some((t) => t.compare(e)));
        }
        te(e, t, n, r) {
            let i = this.Ve || r && t.anonymous === !0,
                {
                    cloned: a,
                    excluded: o
                } = xu(t, this.He(e, t, n, i));
            return e.legacy && yu.forEach((e) => {
                e in a && (a[e] = String(a[e]));
            }), o.length && (a._meta || = {}, a._meta.redactedAttributes = o), a._meta && (delete a._meta.privateAttributes, Object.keys(a._meta).length === 0 && delete a._meta), a;
        }
    },
    Cu = 30 * 1e3,
    wu = .5,
    Tu = class {
        constructor(e, t, n = Math.random) {
            this.Be = t, this.ze = n, this.vt = 0, this.ee = Math.max(1, e), this.Ge = Math.ceil(Math.log2(Cu / this.ee));
        }
        I() {
            let e = Math.min(this.vt, this.Ge),
                t = this.ee * 2 ** e;
            return Math.min(t, Cu);
        }
        Ke(e) {
            return e - Math.trunc(this.ze() * wu * e);
        }
        success(e = Date.now()) {
            this.wt = e;
        }
        fail(e = Date.now()) {
            this.wt !== void 0 && e - this.wt > this.Be && (this.vt = 0), this.wt = void 0;
            let t = this.Ke(this.I());
            return this.vt += 1, t;
        }
    },
    Eu;
(function(e) {
    e[e.Valid = 0] = "Valid", e[e.Initializing = 1] = "Initializing", e[e.Interrupted = 2] = "Interrupted", e[e.Closed = 3] = "Closed";
})(Eu || = {});
var Du = class extends Error {
        constructor(e, t, n, r = !0) {
            super(t), this.kind = e, this.status = n, this.name = "LaunchDarklyPollingError", this.recoverable = r;
        }
    },
    Ou = class extends Error {
        constructor(e, t, n, r = !0) {
            super(t), this.kind = e, this.code = n, this.name = "LaunchDarklyStreamingError", this.recoverable = r;
        }
    },
    ku;
(function(e) {
    e.Unknown = "UNKNOWN", e.NetworkError = "NETWORK_ERROR", e.ErrorResponse = "ERROR_RESPONSE", e.InvalidData = "INVALID_DATA";
})(ku || = {});
var Au;
(function(e) {
    e[e.Disabled = 0] = "Disabled", e[e.Enabled = 1] = "Enabled";
})(Au || = {});
var ju;
(function(e) {
    e[e.AnalyticsEvents = 0] = "AnalyticsEvents", e[e.DiagnosticEvent = 1] = "DiagnosticEvent";
})(ju || = {});
var Mu;
(function(e) {
    e[e.Succeeded = 0] = "Succeeded", e[e.Failed = 1] = "Failed", e[e.FailedAndMustShutDown = 2] = "FailedAndMustShutDown";
})(Mu || = {});

function Nu(e) {
    if (typeof e == "string") return e;
    if (e === void 0) return "undefined";
    if (e === null) return "null";
    if (Object.prototype.hasOwnProperty.call(e, "toString")) try {
        return e.toString();
    } catch {}
    if (typeof e == "bigint") return `${e}n`;
    try {
        return JSON.stringify(e);
    } catch (e) {
        return e instanceof TypeError && e.message.indexOf("circular") >= 0 ? "[Circular]" : "[Not Stringifiable]";
    }
}

function Pu(e) {
    return typeof e == "symbol" ? "NaN" : typeof e == "bigint" ? `${e}n` : String(Number(e));
}

function Fu(e) {
    return typeof e == "symbol" ? "NaN" : typeof e == "bigint" ? `${e}n` : String(parseInt(e, 10));
}

function Iu(e) {
    return typeof e == "symbol" ? "NaN" : String(parseFloat(e));
}
var Lu = {
    s: (e) => Nu(e),
    d: (e) => Pu(e),
    i: (e) => Fu(e),
    f: (e) => Iu(e),
    j: (e) => Nu(e),
    o: (e) => Nu(e),
    O: (e) => Nu(e),
    c: () => ""
};

function Ru(...e) {
    let t = e.shift();
    if (X.String.is(t)) {
        let n = "",
            r = 0;
        for (; r < t.length;) {
            let i = t.charAt(r);
            if (i === "%") {
                if (r + 1 < t.length) {
                    let i = t.charAt(r + 1);
                    if (i in Lu && e.length) {
                        let t = e.shift();
                        n += Lu[i] ? .call(Lu, t);
                    } else i === "%" ? n += "%" : n += `%${i}`;
                    r += 2;
                }
            } else n += i, r += 1;
        }
        return e.length && (n.length && (n += " "), n += e.map(Nu).join(" ")), n;
    }
    return e.map(Nu).join(" ");
}
var zu;
(function(e) {
    e[e.debug = 0] = "debug", e[e.info = 1] = "info", e[e.warn = 2] = "warn", e[e.error = 3] = "error", e[e.none = 4] = "none";
})(zu || = {});
var Bu = [
        "debug",
        "info",
        "warn",
        "error",
        "none"
    ],
    Vu = class e {
        static get() {
            return new e({});
        }
        constructor(e) {
            if (this.Qe = zu[e.level ? ? "info"] ? ? zu.info, this.ti = e.name ? ? "LaunchDarkly", this.ae = e.formatter, typeof e.destination == "object") this.oe = {
                [zu.debug]: e.destination.debug,
                [zu.info]: e.destination.info,
                [zu.warn]: e.destination.warn,
                [zu.error]: e.destination.error
            };
            else if (typeof e.destination == "function") {
                let {
                    destination: t
                } = e;
                this.oe = {
                    [zu.debug]: t,
                    [zu.info]: t,
                    [zu.warn]: t,
                    [zu.error]: t
                };
            }
        }
        ei(...e) {
            try {
                return this.ae ? this.ae ? .call(this, ...e) : Ru(...e);
            } catch {
                return Ru(...e);
            }
        }
        ii(e, t) {
            try {
                e(t);
            } catch {
                console.error(t);
            }
        }
        k(e, t) {
            if (e >= this.Qe) {
                let n = `${Bu[e]}: [${this.ti}]`;
                try {
                    let r = this.oe ? .[e];
                    r ? this.ii(r, `${n} ${this.ei(...t)}`) : console.error(...t);
                } catch {
                    console.error(...t);
                }
            }
        }
        error(...e) {
            this.k(zu.error, e);
        }
        warn(...e) {
            this.k(zu.warn, e);
        }
        info(...e) {
            this.k(zu.info, e);
        }
        debug(...e) {
            this.k(zu.debug, e);
        }
    },
    Hu = {
        error: X.Function,
        warn: X.Function,
        info: X.Function,
        debug: X.Function
    },
    Uu = class {
        constructor(e, t) {
            Object.entries(Hu).forEach(([t, n]) => {
                if (!n.is(e[t])) throw Error(`Provided logger instance must support logger.${t}(...) method`);
            }), this.t = e, this.ni = t;
        }
        k(e, t) {
            try {
                this.t[e](...t);
            } catch {
                this.ni[e](...t);
            }
        }
        error(...e) {
            this.k("error", e);
        }
        warn(...e) {
            this.k("warn", e);
        }
        info(...e) {
            this.k("info", e);
        }
        debug(...e) {
            this.k("debug", e);
        }
    },
    Wu = (e) => {
        let t = new Vu({
            level: "info",
            destination: console.error,
            formatter: Ru
        });
        return e ? new Uu(e, t) : t;
    },
    Gu = class {
        static deprecated(e, t) {
            return `"${e}" is deprecated, please use "${t}"`;
        }
        static optionBelowMinimum(e, t, n) {
            return `Config option "${e}" had invalid value of ${t}, using minimum of ${n} instead`;
        }
        static unknownOption(e) {
            return `Ignoring unknown config option "${e}"`;
        }
        static wrongOptionType(e, t, n) {
            return `Config option "${e}" should be of type ${t}, got ${n}, using default value`;
        }
        static wrongOptionTypeBoolean(e, t) {
            return `Config option "${e}" should be a boolean, got ${t}, converting to boolean`;
        }
        static invalidTagValue(e) {
            return `Config option "${e}" must only contain letters, numbers, ., _ or -.`;
        }
        static tagValueTooLong(e) {
            return `Value of "${e}" was longer than 64 characters and was discarded.`;
        }
        static partialEndpoint(e) {
            return `You have set custom uris without specifying the ${e} URI; connections may not work properly`;
        }
    },
    Ku = X.stringMatchingRegex(/^(\w|\.|-)+$/),
    qu = {
        is: (e, t) => Ku.is(e) ? e.length > 64 ? {
            valid: !1,
            message: Gu.tagValueTooLong(t)
        } : {
            valid: !0
        } : {
            valid: !1,
            message: Gu.invalidTagValue(t)
        }
    },
    Ju = class {
        constructor(e) {
            let t = {},
                n = e ? .application,
                r = e ? .logger;
            n && Object.entries(n).forEach(([e, n]) => {
                if (n != null) {
                    let {
                        valid: i,
                        message: a
                    } = qu.is(n, `application.${e}`);
                    i ? e === "versionName" ? t["application-version-name"] = [n] : t[`application-${e}`] = [n] : r ? .warn(a);
                }
            });
            let i = Object.keys(t);
            i.length && (this.value = i.sort().flatMap((e) => t[e].sort().map((t) => `${e}/${t}`)).join(" "));
        }
    },
    Yu = class {
        constructor(e, t, n) {
            this.platform = n, this.basicConfiguration = {
                tags: t.tags,
                logger: t.logger,
                offline: t.offline,
                serviceEndpoints: t.serviceEndpoints,
                sdkKey: e
            };
        }
    };

function Xu(e) {
    return e.replace(/\/+$/, "");
}

function Zu(e) {
    return e.replace(/^\/+/, "").replace(/\?$/, "");
}
var Qu = class e {
    constructor(t, n, r = e.DEFAULT_EVENTS, i = "/bulk", a = "/diagnostic", o = !0, s) {
        this.streaming = Xu(t), this.polling = Xu(n), this.events = Xu(r), this.analyticsEventPath = i, this.diagnosticEventPath = a, this.includeAuthorizationHeader = o, this.payloadFilterKey = s;
    }
};
Qu.DEFAULT_EVENTS = "https://events.launchdarkly.com";

function $u(e, t = []) {
    return t.length === 0 ? e : `${e}?${t.map(({ key: e, value: t }) => `
    $ {
        e
    } = $ {
        t
    }
    `).join("&")}`;
}

function ed(e, t, n) {
    let r = Zu(t),
        i = [...n];
    return e.payloadFilterKey && i.push({
        key: "filter",
        value: e.payloadFilterKey
    }), $u(`${e.streaming}/${r}`, i);
}

function td(e, t, n = []) {
    let r = Zu(t),
        i = [...n];
    return e.payloadFilterKey && i.push({
        key: "filter",
        value: e.payloadFilterKey
    }), $u(`${e.polling}/${r}`, i);
}

function nd(e, t, n = []) {
    let r = Zu(t);
    return $u(`${e.events}/${r}`, n);
}
var rd = class extends Error {
        constructor(e) {
            super(e), this.name = "LaunchDarklyUnexpectedResponseError";
        }
    },
    id = class extends Error {
        constructor(e) {
            super(e), this.name = "LaunchDarklyClientError";
        }
    },
    ad = class extends Error {
        constructor(e) {
            super(e), this.name = "LaunchDarklyTimeoutError";
        }
    };

function od(e) {
    return e >= 400 && e < 500 ? e === 400 || e === 408 || e === 429 : !0;
}

function sd(e) {
    return e === 413 ? !0 : od(e);
}

function cd(e, t) {
    let n, r;
    return {
        promise: new Promise((i, a) => {
            r = i, n = setTimeout(() => {
                a(new ad(`${t} timed out after ${e} seconds.`));
            }, e * 1e3);
        }),
        cancel: () => {
            r(), clearTimeout(n);
        }
    };
}

function ld(e) {
    return e == null ? e : JSON.parse(JSON.stringify(e));
}

function ud(e) {
    return Math.trunc(e * 1e3);
}
var dd = (e) => JSON.stringify(e) === "{}",
    fd = (e, t) => e && Object.entries(e).reduce((e, [n, r]) => (r && !dd(r) && !(t != null && t.includes(n)) && (e[n] = typeof r == "object" ? fd(r, t) : r), e), {});

function pd(e, t) {
    if (e === t) return !0;
    if (e && t && typeof e == "object" && typeof t == "object") {
        if (e.constructor !== t.constructor) return !1;
        var n, r, i;
        if (Array.isArray(e)) {
            if (n = e.length, n != t.length) return !1;
            for (r = n; r-- !== 0;)
                if (!pd(e[r], t[r])) return !1;
            return !0;
        }
        if (e instanceof Map && t instanceof Map) {
            if (e.size !== t.size) return !1;
            for (r of e.entries())
                if (!t.has(r[0])) return !1;
            for (r of e.entries())
                if (!pd(r[1], t.get(r[0]))) return !1;
            return !0;
        }
        if (e instanceof Set && t instanceof Set) {
            if (e.size !== t.size) return !1;
            for (r of e.entries())
                if (!t.has(r[0])) return !1;
            return !0;
        }
        if (ArrayBuffer.isView(e) && ArrayBuffer.isView(t)) {
            if (n = e.length, n != t.length) return !1;
            for (r = n; r-- !== 0;)
                if (e[r] !== t[r]) return !1;
            return !0;
        }
        if (e.constructor === RegExp) return e.source === t.source && e.flags === t.flags;
        if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === t.valueOf();
        if (e.toString !== Object.prototype.toString) return e.toString() === t.toString();
        if (i = Object.keys(e), n = i.length, n !== Object.keys(t).length) return !1;
        for (r = n; r-- !== 0;)
            if (!Object.prototype.hasOwnProperty.call(t, i[r])) return !1;
        for (r = n; r-- !== 0;) {
            var a = i[r];
            if (!pd(e[a], t[a])) return !1;
        }
        return !0;
    }
    return e !== e && t !== t;
}

function md(e, t, n, r = !0, i = "user-agent") {
    let {
        userAgentBase: a,
        version: o,
        wrapperName: s,
        wrapperVersion: c
    } = t.sdkData(), l = {
        [i]: `${a ?? "NodeJSClient"}/${o}`
    };
    return r && (l.authorization = e), s && (l["x-launchdarkly-wrapper"] = c ? `${s}/${c}` : s), n != null && n.value && (l["x-launchdarkly-tags"] = n.value), l;
}

function hd(e, t, n) {
    let r;
    return r = e.status ? `error ${e.status}${e.status === 401 ? " (invalid SDK key)" : ""}` : `I/O error (${e.message || "unknown error"})`, `Received ${r} for ${t} - ${n ?? "giving up permanently"}`;
}

function gd({
    status: e
}) {
    return e ? od(e) : !0;
}
var _d = (e, t) => t.btoa(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""),
    vd = async (e = 1e3) => new Promise((t) => {
        setTimeout(t, e);
    }),
    yd = class {
        constructor(e, t, n) {
            this.p = t, this.si = n, this.bt = [], this.ce = Date.now(), this.le = this.ce, this.ue = {
                diagnosticId: t.crypto.randomUUID(),
                sdkKeySuffix: e.length > 6 ? e.substring(e.length - 6) : e
            };
        }
        createInitEvent() {
            let e = this.p.info.sdkData(),
                t = this.p.info.platformData();
            return {
                kind: "diagnostic-init",
                id: this.ue,
                creationDate: this.ce,
                sdk: e,
                configuration: this.si,
                platform: Y({
                    name: t.name,
                    osArch: t.os ? .arch,
                    osName: t.os ? .name,
                    osVersion: t.os ? .version
                }, t.additional || {})
            };
        }
        recordStreamInit(e, t, n) {
            let r = {
                timestamp: e,
                failed: t,
                durationMillis: n
            };
            this.bt.push(r);
        }
        createStatsEventAndReset(e, t, n) {
            let r = Date.now(),
                i = {
                    kind: "diagnostic",
                    id: this.ue,
                    creationDate: r,
                    dataSinceDate: this.le,
                    droppedEvents: e,
                    deduplicatedUsers: t,
                    eventsInLastBatch: n,
                    streamInits: this.bt
                };
            return this.bt = [], this.le = r, i;
        }
    },
    bd;
(function(e) {
    e.MalformedFlag = "MALFORMED_FLAG", e.UserNotSpecified = "USER_NOT_SPECIFIED", e.FlagNotFound = "FLAG_NOT_FOUND", e.ClientNotReady = "CLIENT_NOT_READY", e.WrongType = "WRONG_TYPE";
})(bd || = {});
var xd = bd,
    Sd = class {
        static invalidMetricValue(e) {
            return `The track function was called with a non-numeric "metricValue" (${e}), only numeric metric values are supported.`;
        }
    };
Sd.MissingContextKeyNoEvent = "Context was unspecified or had no key; event will not be sent";
var Cd = class {
    constructor(e, t) {
        let {
            basicConfiguration: n,
            platform: r
        } = e, {
            serviceEndpoints: {
                analyticsEventPath: i,
                diagnosticEventPath: a
            }
        } = n, {
            crypto: o,
            requests: s
        } = r;
        this.ri = Y({}, t), this.he = nd(n.serviceEndpoints, i, []), this.ai = nd(n.serviceEndpoints, a, []), this.H = s, this.oi = o;
    }
    async st(e, t, n, r) {
        let i = {
                status: Mu.Succeeded
            },
            a = Vl(Y({}, this.ri), {
                "content-type": "application/json"
            });
        n && (a["x-launchdarkly-payload-id"] = n, a["x-launchDarkly-event-schema"] = "4");
        let o;
        try {
            let {
                status: n,
                headers: r
            } = await this.H.fetch(t, {
                headers: a,
                body: JSON.stringify(e),
                compressBodyIfPossible: !0,
                method: "POST",
                keepalive: !0
            }), s = Date.parse(r.get("date") || "");
            if (s && (i.serverTime = s), n <= 204) return i;
            if (o = new rd(hd({
                    status: n,
                    message: "some events were dropped"
                }, "event posting")), !od(n)) return sd(n) ? i.status = Mu.Failed : i.status = Mu.FailedAndMustShutDown, i.error = o, i;
        } catch (e) {
            o = e;
        }
        return o && !r ? (i.status = Mu.Failed, i.error = o, i) : (await vd(), this.st(e, this.he, n, !1));
    }
    async sendEventData(e, t) {
        let n = e === ju.AnalyticsEvents ? this.oi.randomUUID() : void 0,
            r = e === ju.AnalyticsEvents ? this.he : this.ai;
        return this.st(t, r, n, !0);
    }
};

function wd(e) {
    return e.kind === "feature";
}

function Td(e) {
    return e.kind === "identify";
}

function Ed(e) {
    return e.kind === "migration_op";
}
var Dd = class {
    constructor(e, t, n, r, i, a) {
        this.count = e, this.key = t, this.value = n, this.version = i, this.variation = a, this.default = r;
    }
    increment() {
        this.count += 1;
    }
};

function Od(e) {
    return `${e.key}:${e.variation !== null && e.variation !== void 0 ? e.variation : ""}:${e.version !== null && e.version !== void 0 ? e.version : ""}`;
}
var kd = class {
        constructor(e = !1, t) {
            this.ci = e, this.x = t, this.Y = 0, this.rt = 0, this.at = {}, this.ot = {};
        }
        summarizeEvent(e) {
            if (wd(e) && !e.excludeFromSummaries) {
                this.y || = e.context;
                let t = Od(e),
                    n = this.at[t],
                    r = this.ot[e.key];
                r || (r = /* @__PURE__ */ new Set(), this.ot[e.key] = r), e.context.kinds.forEach((e) => r.add(e)), n ? n.increment() : this.at[t] = new Dd(1, e.key, e.value, e.default, e.version, e.variation), (this.Y === 0 || e.creationDate < this.Y) && (this.Y = e.creationDate), e.creationDate > this.rt && (this.rt = e.creationDate);
            }
        }
        getSummary() {
            let e = Object.values(this.at).reduce((e, t) => {
                    let n = e[t.key];
                    n || (n = {
                        default: t.default,
                        counters: [],
                        contextKinds: [...this.ot[t.key]]
                    }, e[t.key] = n);
                    let r = {
                        value: t.value,
                        count: t.count
                    };
                    return t.variation !== void 0 && t.variation !== null && (r.variation = t.variation), t.version !== void 0 && t.version !== null ? r.version = t.version : r.unknown = !0, n.counters.push(r), e;
                }, {}),
                t = {
                    startDate: this.Y,
                    endDate: this.rt,
                    features: e,
                    kind: "summary",
                    context: this.y !== void 0 && this.ci ? this.x ? .filter(this.y) : void 0
                };
            return this.li(), t;
        }
        li() {
            this.Y = 0, this.rt = 0, this.at = {}, this.ot = {};
        }
    },
    Ad = class extends Error {
        constructor(e) {
            super(e), this.name = "LaunchDarklyInvalidSDKKeyError";
        }
    },
    jd = class {
        constructor(e, t) {
            this.x = e, this.t = t, this.Z = {};
        }
        summarizeEvent(e) {
            var t;
            if (wd(e)) {
                let n = e.context.canonicalUnfilteredJson();
                if (!n) {
                    e.context.valid && ((t = this.t) == null || t.error("Unable to serialize context, likely the context contains a cycle."));
                    return;
                }
                let r = this.Z[n];
                r || = (this.Z[n] = new kd(!0, this.x), this.Z[n]), r.summarizeEvent(e);
            }
        }
        getSummaries() {
            let e = this.Z;
            return this.Z = {}, Object.values(e).map((e) => e.getSummary());
        }
    };

function Md(e) {
    let t = Math.trunc(e);
    return t === 1 ? !0 : t === 0 ? !1 : Math.floor(Math.random() * t) === 0;
}

function Nd(e) {
    return e.getSummaries !== void 0;
}
var Pd = class {
        constructor(e, t, n, r, i, a = !0, o = !1) {
            this.e = e, this.ct = r, this.S = i, this.lt = [], this.de = 0, this.kt = 0, this.xt = 0, this.St = !1, this.fe = 0, this.Lt = !1, this.Ct = null, this.ui = e.eventsCapacity, this.t = t.basicConfiguration.logger, this.pe = new Cd(t, n), this.x = new Su(e.allAttributesPrivate, e.privateAttributes.map((e) => new Jl(e))), o ? this.X = new jd(this.x, this.t) : this.X = new kd(), a && this.start();
        }
        start() {
            var e;
            if (this.ct ? .flushInterval !== void 0 && (this.Ct = setInterval(() => {
                    var e;
                    (e = this.ct) == null || e.flush();
                }, this.ct.flushInterval * 1e3)), this.hi = setInterval(async () => {
                    var e;
                    try {
                        await this.flush();
                    } catch (t) {
                        (e = this.t) == null || e.debug(`Flush failed: ${t}`);
                    }
                }, this.e.flushInterval * 1e3), this.S) {
                let e = this.S.createInitEvent();
                this.ge(e), this.me = setInterval(() => {
                    let e = this.S.createStatsEventAndReset(this.kt, this.xt, this.fe);
                    this.kt = 0, this.xt = 0, this.ge(e);
                }, this.e.diagnosticRecordingInterval * 1e3);
            }
            (e = this.t) == null || e.debug("Started EventProcessor.");
        }
        ge(e) {
            this.pe.sendEventData(ju.DiagnosticEvent, e);
        }
        close() {
            clearInterval(this.hi), this.Ct && clearInterval(this.Ct), this.me && clearInterval(this.me);
        }
        async flush() {
            var e;
            if (this.Lt) throw new Ad("Events cannot be posted because a permanent error has been encountered. This is most likely an invalid SDK key. The specific error information is logged independently.");
            let t = this.lt;
            if (this.lt = [], Nd(this.X)) this.X.getSummaries().forEach((e) => {
                Object.keys(e.features).length && t.push(e);
            });
            else {
                let e = this.X.getSummary();
                Object.keys(e.features).length && t.push(e);
            }
            t.length && (this.fe = t.length, (e = this.t) == null || e.debug("Flushing %d events", t.length), await this.st(t));
        }
        sendEvent(e) {
            if (this.Lt) return;
            if (Ed(e)) {
                if (Md(e.samplingRatio)) {
                    let t = Vl(Y({}, e), {
                        context: e.context ? this.x.filter(e.context) : void 0
                    });
                    t.samplingRatio === 1 && delete t.samplingRatio, this.ut(t);
                }
                return;
            }
            this.X.summarizeEvent(e);
            let t = wd(e),
                n = t && e.trackEvents || !t,
                r = this.di(e),
                i = Td(e),
                a = this.ct ? .processContext(e.context);
            a || i || (this.xt += 1), a && !i && this.ut(this.It({
                kind: "index",
                creationDate: e.creationDate,
                context: e.context,
                samplingRatio: 1
            }, !1)), n && Md(e.samplingRatio) && this.ut(this.It(e, !1)), r && Md(e.samplingRatio) && this.ut(this.It(e, !0));
        }
        It(e, t) {
            switch (e.kind) {
                case "feature":
                    {
                        let n = {
                            kind: t ? "debug" : "feature",
                            creationDate: e.creationDate,
                            context: this.x.filter(e.context, !t),
                            key: e.key,
                            value: e.value,
                            default: e.default
                        };
                        return e.samplingRatio !== 1 && (n.samplingRatio = e.samplingRatio),
                        e.prereqOf && (n.prereqOf = e.prereqOf),
                        e.variation !== void 0 && (n.variation = e.variation),
                        e.version !== void 0 && (n.version = e.version),
                        e.reason && (n.reason = e.reason),
                        n;
                    }
                case "index":
                case "identify":
                    {
                        let t = {
                            kind: e.kind,
                            creationDate: e.creationDate,
                            context: this.x.filter(e.context)
                        };
                        return e.samplingRatio !== 1 && (t.samplingRatio = e.samplingRatio),
                        t;
                    }
                case "custom":
                    {
                        let t = {
                            kind: "custom",
                            creationDate: e.creationDate,
                            key: e.key,
                            context: this.x.filter(e.context)
                        };
                        return e.samplingRatio !== 1 && (t.samplingRatio = e.samplingRatio),
                        e.data !== void 0 && (t.data = e.data),
                        e.metricValue !== void 0 && (t.metricValue = e.metricValue),
                        e.url !== void 0 && (t.url = e.url),
                        t;
                    }
                case "click":
                    return {
                        kind: "click",
                        creationDate: e.creationDate,
                        contextKeys: e.context.kindsAndKeys,
                        key: e.key,
                        url: e.url,
                        selector: e.selector
                    };
                case "pageview":
                    return {
                        kind: "pageview",
                        creationDate: e.creationDate,
                        contextKeys: e.context.kindsAndKeys,
                        key: e.key,
                        url: e.url
                    };
                default:
                    return e;
            }
        }
        ut(e) {
            var t;
            this.lt.length < this.ui ? (this.lt.push(e), this.St = !1) : (this.St || (this.St = !0, (t = this.t) == null || t.warn("Exceeded event queue capacity. Increase capacity to avoid dropping events.")), this.kt += 1);
        }
        di(e) {
            return wd(e) && e.debugEventsUntilDate && e.debugEventsUntilDate > this.de && e.debugEventsUntilDate > Date.now();
        }
        async st(e) {
            let t = await this.pe.sendEventData(ju.AnalyticsEvents, e);
            if (t.status === Mu.FailedAndMustShutDown && (this.Lt = !0), t.serverTime && (this.de = t.serverTime), t.error) throw t.error;
        }
    },
    Fd = class {
        constructor(e, t, n, r, i = 1, a) {
            this.context = e, this.key = t, this.data = n, this.metricValue = r, this.samplingRatio = i, this.url = a, this.kind = "custom", this.creationDate = Date.now(), this.context = e;
        }
    },
    Id = class {
        constructor(e, t, n, r, i, a, o, s, c, l, u, d, f = 1) {
            this.withReasons = e, this.context = t, this.key = n, this.samplingRatio = f, this.kind = "feature", this.creationDate = Date.now(), this.value = r, this.default = i, a !== void 0 && (this.version = a), o !== void 0 && (this.variation = o), s !== void 0 && (this.trackEvents = s), c !== void 0 && (this.prereqOf = c), l !== void 0 && (this.reason = l), u !== void 0 && (this.debugEventsUntilDate = u), d !== void 0 && (this.excludeFromSummaries = d);
        }
    },
    Ld = class {
        constructor(e, t = 1) {
            this.context = e, this.samplingRatio = t, this.kind = "identify", this.creationDate = Date.now();
        }
    },
    Rd = class {
        close() {}
        async flush() {}
        sendEvent() {}
    },
    zd = class {
        constructor(e) {
            this.At = e;
        }
        evalEvent(e) {
            return new Id(this.At, e.context, e.flagKey, e.value, e.defaultVal, e.version, e.variation ? ? void 0, e.trackEvents || e.addExperimentData, e.prereqOfFlagKey, this.At || e.addExperimentData ? e.reason : void 0, e.debugEventsUntilDate, e.excludeFromSummaries, e.samplingRatio);
        }
        unknownFlagEvent(e, t, n) {
            return new Id(this.At, n, e, t, t, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
        }
        identifyEvent(e) {
            return new Ld(e, 1);
        }
        customEvent(e, t, n, r, i = 1) {
            return new Fd(t, e, n ? ? void 0, r ? ? void 0, i);
        }
    },
    Bd = "FDv1Fallback";

function Vd(e) {
    return {
        fi: e,
        ye: "",
        useSelector(e) {
            return this.ye = e, this;
        },
        processFullTransfer(e) {
            let t = [{
                event: "server-intent",
                data: {
                    payloads: [{
                        id: Bd,
                        target: 1,
                        intentCode: "xfer-full",
                        reason: "payload-missing"
                    }]
                }
            }];
            Object.entries(e ? .flags || []).forEach(([e, n]) => {
                t.push({
                    event: "put-object",
                    data: {
                        kind: "flag",
                        key: e,
                        version: n.version || 1,
                        object: n
                    }
                });
            }), Object.entries(e ? .segments || []).forEach(([e, n]) => {
                t.push({
                    event: "put-object",
                    data: {
                        kind: "segment",
                        key: e,
                        version: n.version || 1,
                        object: n
                    }
                });
            }), t.push({
                event: "payload-transferred",
                data: {
                    state: this.ye,
                    version: 1,
                    id: Bd
                }
            }), this.fi.processEvents(t);
        }
    };
}
var Hd = class {
        constructor(e, t, n) {
            this.pi = e, this.m = t, this.t = n, this.n = [], this.N = void 0, this.B = !1, this.z = [], this.gi = (e) => {
                var t;
                if (this.Pt(), !e.payloads.length) return;
                let n = e.payloads[0];
                switch (n ? .intentCode) {
                    case "xfer-full":
                        this.B = !0;
                        break;
                    case "xfer-changes":
                        this.B = !1;
                        break;
                    case "none":
                        this.B = !1, this.mi(n);
                        break;
                    default:
                        (t = this.t) == null || t.warn(`Unable to process intent code '${n?.intentCode}'.`);
                        return;
                }
                this.N = n ? .id;
            }, this.yi = (e) => {
                var t;
                if (!this.N || !e.kind || !e.key || !e.version || !e.object) return;
                let n = this.vi(e.kind, e.object);
                if (!n) {
                    (t = this.t) == null || t.warn(`Unable to process object for kind: '${e.kind}'`);
                    return;
                }
                this.z.push({
                    kind: e.kind,
                    key: e.key,
                    version: e.version,
                    object: n
                });
            }, this.wi = (e) => {
                !this.N || !e.kind || !e.key || !e.version || this.z.push({
                    kind: e.kind,
                    key: e.key,
                    version: e.version,
                    deleted: !0
                });
            }, this.mi = (e) => {
                if (!e.id || !e.target) return;
                let t = {
                    id: e.id,
                    version: e.target,
                    basis: !1,
                    updates: []
                };
                this.n.forEach((e) => e(t)), this.ve();
            }, this.Ei = (e) => {
                if (!this.N || e.state === null || e.state === void 0 || !e.version) {
                    this.Pt();
                    return;
                }
                let t = {
                    id: this.N,
                    version: e.version,
                    state: e.state,
                    basis: this.B,
                    updates: this.z
                };
                this.n.forEach((e) => e(t)), this.ve();
            }, this.Di = (e) => {
                var t;
                (t = this.t) == null || t.info(`Goodbye was received from the LaunchDarkly connection with reason: ${e.reason}.`), this.Pt();
            }, this.bi = (e) => {
                var t;
                (t = this.t) == null || t.info(`An issue was encountered receiving updates for payload ${this.N} with reason: ${e.reason}.`), this.ki();
            };
        }
        addPayloadListener(e) {
            this.n.push(e);
        }
        removePayloadListener(e) {
            let t = this.n.indexOf(e, 0);
            t > -1 && this.n.splice(t, 1);
        }
        processEvents(e) {
            e.forEach((e) => {
                switch (e.event) {
                    case "server-intent":
                        this.gi(e.data);
                        break;
                    case "put-object":
                        this.yi(e.data);
                        break;
                    case "delete-object":
                        this.wi(e.data);
                        break;
                    case "payload-transferred":
                        this.Ei(e.data);
                        break;
                    case "goodbye":
                        this.Di(e.data);
                        break;
                    case "error":
                        this.bi(e.data);
                        break;
                }
            });
        }
        vi(e, t) {
            var n;
            return (n = this.pi)[e] ? .call(n, t);
        }
        ve() {
            this.B = !1, this.z = [];
        }
        ki() {
            this.z = [];
        }
        Pt() {
            this.N = void 0, this.B = !1, this.z = [];
        }
    },
    Ud = class {
        constructor(e, t, n, r) {
            this.m = n, this.t = r, this.G(e, "server-intent"), this.G(e, "put-object"), this.G(e, "delete-object"), this.G(e, "payload-transferred"), this.G(e, "goodbye"), this.G(e, "error"), this.Ot = new Hd(t, n, r);
        }
        addPayloadListener(e) {
            this.Ot.addPayloadListener(e);
        }
        removePayloadListener(e) {
            this.Ot.removePayloadListener(e);
        }
        G(e, t) {
            e.addEventListener(t, async (e) => {
                var n, r, i, a, o;
                if (e != null && e.data) {
                    (n = this.t) == null || n.debug(`Received ${t} event.  Data is ${e.data}`);
                    try {
                        this.Ot.processEvents([{
                            event: t,
                            data: JSON.parse(e.data)
                        }]);
                    } catch {
                        (r = this.t) == null || r.error(`Stream received data that was unable to be processed in "${t}" message`), (i = this.t) == null || i.debug(`Data follows: ${e.data}`), (a = this.m) == null || a.call(this, ku.InvalidData, "Malformed data in EventStream.");
                    }
                } else(o = this.m) == null || o.call(this, ku.Unknown, "Event from EventStream missing data.");
            });
        }
    };

function Wd(e) {
    if (e) {
        let t = Object.keys(e).find((e) => e.toLowerCase() === "x-ld-envid");
        if (t) return {
            environmentId: e[t]
        };
    }
}
var Gd = "unknown plugin";

function Kd(e, t) {
    try {
        return t.getMetadata().name || Gd;
    } catch {
        return e.error("Exception thrown getting metadata for plugin. Unable to get plugin name."), Gd;
    }
}

function qd(e, t, n) {
    let r = [];
    return n.forEach((n) => {
        try {
            let i = n.getHooks ? .call(n, t);
            i === void 0 ? e.error(`Plugin ${Kd(e, n)} returned undefined from getHooks.`) : i && i.length > 0 && r.push(...i);
        } catch {
            e.error(`Exception thrown getting hooks for plugin ${Kd(e, n)}. Unable to get hooks.`);
        }
    }), r;
}

function Jd(e, t, n, r) {
    r.forEach((r) => {
        try {
            r.register(n, t);
        } catch {
            e.error(`Exception thrown registering plugin ${Kd(e, r)}.`);
        }
    });
}
var Yd = Object.freeze({
        __proto__: null,
        ClientMessages: Sd,
        DiagnosticsManager: yd,
        ErrorKinds: xd,
        EventFactoryBase: zd,
        EventProcessor: Pd,
        FDv1PayloadAdaptor: Vd,
        InputCustomEvent: Fd,
        InputEvalEvent: Id,
        InputIdentifyEvent: Ld,
        NullEventProcessor: Rd,
        PayloadProcessor: Hd,
        PayloadStreamReader: Ud,
        canonicalize: cu,
        initMetadataFromHeaders: Wd,
        isLegacyUser: su,
        isMultiKind: ou,
        isSingleKind: au,
        safeGetHooks: qd,
        safeGetName: Kd,
        safeRegisterPlugins: Jd,
        shouldSample: Md
    }),
    Xd = {
        Initializing: "INITIALIZING",
        Valid: "VALID",
        Interrupted: "INTERRUPTED",
        SetOffline: "SET_OFFLINE",
        Closed: "CLOSED"
    };

function Zd(e) {
    return e >= 200 && e <= 299;
}
var Qd = class extends Error {
    constructor(e, t) {
        super(e), this.status = t, this.name = "LaunchDarklyRequestError";
    }
};

function $d(e, t, n, r, i, a, o, s, c, l) {
    let u, d = "GET",
        f = Y({}, a);
    c && (d = "REPORT", f["content-type"] = "application/json", u = e);
    let p = c ? n.pathReport(i, e) : n.pathGet(i, e),
        m = [...o ? ? []];
    s && m.push({
        key: "withReasons",
        value: "true"
    }), l && m.push({
        key: "h",
        value: l
    });
    let h = td(t, p, m);
    return {
        async requestPayload() {
            let e;
            try {
                let t = await r.fetch(h, {
                    method: d,
                    headers: f,
                    body: u
                });
                if (Zd(t.status)) return await t.text();
                e = t.status;
            } catch (e) {
                throw new Qd(e ? .message);
            }
            throw new Qd(`Unexpected status code: ${e}`, e);
        }
    };
}
var ef = /* @__PURE__ */ Error("Task has already been executed or shed. This is likely an implementation error. The task will not be executed again.");

function tf(e, t, n = !1) {
    let r, i = new Promise((n) => {
            r = (r, i) => {
                var a;
                try {
                    (a = e.after) == null || a.call(e, r, i);
                } catch (e) {
                    t ? .error(`Error in after callback: ${e}`);
                }
                n(r);
            };
        }),
        a = e.before ? e.before() : Promise.resolve(void 0),
        o = !1;
    return {
        execute: () => {
            o && t ? .error(ef), o = !0, a.then((t) => {
                e.execute(t).then((e) => r({
                    status: "complete",
                    result: e
                }, t)).catch((e) => r({
                    status: "error",
                    error: e
                }, t));
            }).catch((e) => {
                t ? .error(e), r({
                    status: "error",
                    error: e
                }, void 0);
            });
        },
        shed: () => {
            o && t ? .error(ef), o = !0, a.then((e) => {
                r({
                    status: "shed"
                }, e);
            });
        },
        promise: i,
        sheddable: n
    };
}

function nf(e) {
    let t, n = [];

    function r() {
        if (!t && n.length > 0) {
            let e = n.shift();
            t = e.promise.finally(() => {
                t = void 0, r();
            }), e.execute();
        }
    }
    return {
        execute(i, a = !1) {
            var o, s;
            let c = tf(i, e, a);
            return t ? ((o = n[n.length - 1]) != null && o.sheddable && ((s = n.pop()) == null || s.shed()), n.push(c)) : (t = c.promise.finally(() => {
                t = void 0, r();
            }), c.execute()), c.promise;
        },
        pendingCount() {
            return n.length;
        }
    };
}
var rf = {
        logger: X.Object,
        maxCachedContexts: X.numberWithMin(0),
        baseUri: X.String,
        streamUri: X.String,
        eventsUri: X.String,
        capacity: X.numberWithMin(1),
        diagnosticRecordingInterval: X.numberWithMin(2),
        flushInterval: X.numberWithMin(2),
        streamInitialReconnectDelay: X.numberWithMin(0),
        allAttributesPrivate: X.Boolean,
        debug: X.Boolean,
        diagnosticOptOut: X.Boolean,
        withReasons: X.Boolean,
        sendEvents: X.Boolean,
        pollInterval: X.numberWithMin(30),
        useReport: X.Boolean,
        privateAttributes: X.StringArray,
        applicationInfo: X.Object,
        wrapperName: X.String,
        wrapperVersion: X.String,
        payloadFilterKey: X.stringMatchingRegex(/^[a-zA-Z0-9](\w|\.|-)*$/),
        hooks: X.createTypeArray("Hook[]", {}),
        inspectors: X.createTypeArray("LDInspection", {}),
        cleanOldPersistentData: X.Boolean
    },
    af = 300,
    of = "https://clientsdk.launchdarkly.com",
    sf = "https://clientstream.launchdarkly.com";

function cf(e) {
    return e instanceof Uu ? e : Wu(e);
}
var lf = class {
    constructor(e = {}, t = {
        getImplementationHooks: () => [],
        credentialType: "mobileKey"
    }) {
        this.logger = Wu(), this.baseUri = of , this.eventsUri = Qu.DEFAULT_EVENTS, this.streamUri = sf, this.maxCachedContexts = 5, this.capacity = 100, this.diagnosticRecordingInterval = 900, this.flushInterval = 30, this.streamInitialReconnectDelay = 1, this.allAttributesPrivate = !1, this.debug = !1, this.diagnosticOptOut = !1, this.sendEvents = !0, this.sendLDHeaders = !0, this.useReport = !1, this.withReasons = !1, this.privateAttributes = [], this.pollInterval = af, this.hooks = [], this.inspectors = [], this.logger = cf(e.logger), this.xi(e).forEach((e) => this.logger.warn(e)), this.serviceEndpoints = new Qu(this.streamUri, this.baseUri, this.eventsUri, t.analyticsEventPath, t.diagnosticEventPath, t.includeAuthorizationHeader, e.payloadFilterKey), this.useReport = e.useReport ? ? !1, this.tags = new Ju({
            application: this.applicationInfo,
            logger: this.logger
        }), this.userAgentHeaderName = t.userAgentHeaderName ? ? "user-agent", this.trackEventModifier = t.trackEventModifier ? ? ((e) => e), this.credentialType = t.credentialType, this.getImplementationHooks = t.getImplementationHooks;
    }
    xi(e) {
        let t = [];
        return Object.entries(e).forEach(([e, n]) => {
            let r = rf[e];
            if (r)
                if (r.is(n)) e === "logger" || (this[e] = n ? ? void 0);
                else {
                    let i = r.getType();
                    if (i === "boolean") t.push(Gu.wrongOptionTypeBoolean(e, typeof n)), this[e] = !!n;
                    else if (i === "boolean | undefined | null") t.push(Gu.wrongOptionTypeBoolean(e, typeof n)), typeof n != "boolean" && n != null && (this[e] = !!n);
                    else if (r instanceof Ql && X.Number.is(n)) {
                        let {
                            min: i
                        } = r;
                        t.push(Gu.optionBelowMinimum(e, n, i)), this[e] = i;
                    } else t.push(Gu.wrongOptionType(e, r.getType(), typeof n));
                }
            else t.push(Gu.unknownOption(e));
        }), t;
    }
};
async function uf(e, t) {
    if (e.digest) return e.digest(t);
    if (e.asyncDigest) return e.asyncDigest(t);
    throw Error("Platform must implement digest or asyncDigest");
}
var df = async (e, {
    crypto: t,
    storage: n
}) => {
    let r = await n ? .get(e);
    return r || (r = t.randomUUID(), await n ? .set(e, r)), r;
};

function ff(e) {
    return async (t) => uf(e.createHash("sha256").update(t), "base64");
}
var pf = async (e) => e;
async function mf(e) {
    return (await Promise.all(e.map((e) => e.transform(e.value)))).join("_");
}
async function hf(e, t) {
    return mf([{
        value: "LaunchDarkly",
        transform: pf
    }, {
        value: t,
        transform: ff(e)
    }]);
}
async function gf(e) {
    return mf([{
            value: "LaunchDarkly",
            transform: pf
        },
        {
            value: "AnonymousKeys",
            transform: pf
        },
        {
            value: e,
            transform: pf
        }
    ]);
}
async function _f(e) {
    return mf([{
            value: "LaunchDarkly",
            transform: pf
        },
        {
            value: "ContextKeys",
            transform: pf
        },
        {
            value: e,
            transform: pf
        }
    ]);
}
async function vf(e) {
    return mf([{
        value: e,
        transform: pf
    }, {
        value: "ContextIndex",
        transform: pf
    }]);
}
async function yf(e, t, n) {
    return mf([{
        value: t,
        transform: pf
    }, {
        value: n.canonicalKey,
        transform: ff(e)
    }]);
}
var {
    isLegacyUser: bf,
    isSingleKind: xf,
    isMultiKind: Sf
} = Yd, Cf = "1.0", wf = (e) => {
    let t = e,
        {
            kind: n
        } = t,
        r = Hl(t, ["kind"]);
    return {
        kind: "multi",
        [n]: r
    };
}, Tf = async ({
    crypto: e,
    info: t
}, {
    applicationInfo: n
}) => {
    let {
        ld_application: r
    } = t.platformData(), i = fd(r) ? ? {}, a = n ? .id || i ? .id;
    if (a) {
        let t = n ? .version || i ? .version,
            r = n ? .name || i ? .name,
            o = n ? .versionName || i ? .versionName;
        return i = Y(Y(Y(Vl(Y({}, i), {
            id: a
        }), t ? {
            version: t
        } : {}), r ? {
            name: r
        } : {}), o ? {
            versionName: o
        } : {}), i.key = await uf(e.createHash("sha256").update(a), "base64"), i.envAttributesVersion = i.envAttributesVersion || Cf, i;
    }
}, Ef = async (e) => {
    let {
        ld_device: t,
        os: n
    } = e.info.platformData(), r = fd(t) ? ? {}, i = n ? .name || r.os ? .name, a = n ? .version || r.os ? .version, o = r.os ? .family;
    if ((i || a || o) && (r.os = Y(Y(Y({}, i ? {
            name: i
        } : {}), a ? {
            version: a
        } : {}), o ? {
            family: o
        } : {})), Object.keys(r).filter((e) => e !== "key" && e !== "envAttributesVersion").length) return r.key = await df(await _f("ld_device"), e), r.envAttributesVersion = r.envAttributesVersion || Cf, r;
}, Df = async (e, t, n) => {
    if (bf(e)) return e;
    let r, i;
    return xf(e) && e.kind !== "ld_application" || Sf(e) && !e.ld_application ? r = await Tf(t, n) : n.logger.warn("Not adding ld_application environment attributes because it already exists."), xf(e) && e.kind !== "ld_device" || Sf(e) && !e.ld_device ? i = await Ef(t) : n.logger.warn("Not adding ld_device environment attributes because it already exists."), r || i ? Y(Y(Y({}, xf(e) ? wf(e) : e), r ? {
        ld_application: r
    } : {}), i ? {
        ld_device: i
    } : {}) : e;
};

function Of() {
    let e, t;
    return {
        set(n, r) {
            e = n, t = r;
        },
        getContext() {
            return t;
        },
        getUnwrappedContext() {
            return e;
        },
        newIdentificationPromise() {
            let e, t;
            return {
                identifyPromise: new Promise((n, r) => {
                    e = n, t = r;
                }),
                identifyResolve: e,
                identifyReject: t
            };
        },
        hasContext() {
            return t !== void 0;
        },
        hasValidContext() {
            return this.hasContext() && t.valid;
        }
    };
}
var {
    isLegacyUser: kf,
    isMultiKind: Af,
    isSingleKind: jf
} = Yd, Mf = async (e, t, n) => {
    let {
        anonymous: r,
        key: i
    } = t;
    r && !i && (t.key = await df(await gf(e), n));
}, Nf = async (e, t) => {
    await Mf(e.kind, e, t);
}, Pf = async (e, t) => {
    let n = e,
        {
            kind: r
        } = n,
        i = Hl(n, ["kind"]);
    return Promise.all(Object.entries(i).map(([e, n]) => Mf(e, n, t)));
}, Ff = async (e, t) => {
    await Mf("user", e, t);
}, If = async (e, t) => {
    let n = ld(e);
    return jf(n) && await Nf(n, t), Af(n) && await Pf(n, t), kf(n) && await Ff(n, t), n;
}, Lf = (e) => ({
    customBaseURI: e.serviceEndpoints.polling !== of ,
    customStreamURI: e.serviceEndpoints.streaming !== sf,
    customEventsURI: e.serviceEndpoints.events !== Qu.DEFAULT_EVENTS,
    eventsCapacity: e.capacity,
    eventsFlushIntervalMillis: ud(e.flushInterval),
    reconnectTimeMillis: ud(e.streamInitialReconnectDelay),
    diagnosticRecordingIntervalMillis: ud(e.diagnosticRecordingInterval),
    allAttributesPrivate: e.allAttributesPrivate,
    usingSecureMode: !1,
    bootstrapMode: !1
}), Rf = (e, t, n) => {
    if (t.sendEvents && !t.diagnosticOptOut) return new Yd.DiagnosticsManager(e, n, Lf(t));
};

function zf(e, t) {
    return {
        value: t ? ? null,
        variationIndex: null,
        reason: {
            kind: "ERROR",
            errorKind: e
        }
    };
}

function Bf(e, t, n) {
    return Y({
        value: e,
        variationIndex: t ? ? null
    }, n !== void 0 && {
        reason: n
    });
}
var Vf = (e, t, n, r, i) => {
        if (t.sendEvents) return new Yd.EventProcessor(Vl(Y({}, t), {
            eventsCapacity: t.capacity
        }), new Yu(e, t, n), r, void 0, i, !1, !0);
    },
    Hf = class extends Yd.EventFactoryBase {
        evalEventClient(e, t, n, r, i, a) {
            let {
                trackEvents: o,
                debugEventsUntilDate: s,
                trackReason: c,
                flagVersion: l,
                version: u,
                variation: d
            } = r;
            return super.evalEvent({
                addExperimentData: c,
                context: i,
                debugEventsUntilDate: s,
                defaultVal: n,
                flagKey: e,
                reason: a,
                trackEvents: !!o,
                value: t,
                variation: d,
                version: l ? ? u
            });
        }
    },
    Uf = class e {
        constructor() {
            this.container = {
                index: []
            };
        }
        static fromJson(t) {
            let n = new e();
            try {
                n.container = JSON.parse(t);
            } catch {}
            return n;
        }
        toJson() {
            return JSON.stringify(this.container);
        }
        notice(e, t) {
            let n = this.container.index.find((t) => t.id === e);
            n === void 0 ? this.container.index.push({
                id: e,
                timestamp: t
            }) : n.timestamp = t;
        }
        prune(e) {
            let t = Math.max(e, 0);
            return this.container.index.length > t ? (this.container.index.sort((e, t) => e.timestamp - t.timestamp), this.container.index.splice(0, this.container.index.length - t)) : [];
        }
    },
    Wf = class {
        constructor(e, t, n, r, i, a, o = () => Date.now()) {
            this.p = e, this.Tt = t, this.Si = n, this.P = r, this.w = i, this.t = a, this.Li = o, this.we = vf(this.Tt);
        }
        async init(e, t) {
            this.w.init(e, t), await this.Ee(e);
        }
        async upsert(e, t, n) {
            return this.w.upsert(e, t, n) ? (await this.Ee(e), !0) : !1;
        }
        async loadCached(e) {
            let t = await yf(this.p.crypto, this.Tt, e),
                n = await this.p.storage ? .get(t);
            if (n == null) {
                if (n = await this.p.storage ? .get(e.canonicalKey), n == null) return !1;
                await this.p.storage ? .set(t, n), await this.p.storage ? .clear(e.canonicalKey);
            }
            try {
                let t = JSON.parse(n),
                    r = Object.entries(t).reduce((e, [t, n]) => (e[t] = {
                        version: n.version,
                        flag: n
                    }, e), {});
                return this.w.initCached(e, r), this.t.debug("Loaded cached flag evaluations from persistent storage"), !0;
            } catch (e) {
                return this.t.warn(`Could not load cached flag evaluations from persistent storage: ${e.message}`), !1;
            }
        }
        async Ci() {
            if (this.K !== void 0) return this.K;
            let e = await this.p.storage ? .get(await this.we);
            if (!e) return this.K = new Uf(), this.K;
            try {
                this.K = Uf.fromJson(e), this.t.debug("Loaded context index from persistent storage");
            } catch (e) {
                this.t.warn(`Could not load index from persistent storage: ${e.message}`), this.K = new Uf();
            }
            return this.K;
        }
        async Ee(e) {
            let t = await this.Ci(),
                n = await yf(this.p.crypto, this.Tt, e);
            t.notice(n, this.Li());
            let r = t.prune(this.Si);
            await Promise.all(r.map(async (e) => this.p.storage ? .clear(e.id))), await this.p.storage ? .set(await this.we, t.toJson());
            let i = this.P.getAll(),
                a = Object.entries(i).reduce((e, [t, n]) => (n.flag !== null && n.flag !== void 0 && (e[t] = n.flag), e), {}),
                o = JSON.stringify(a);
            await this.p.storage ? .set(n, o);
        }
    };

function Gf() {
    let e = {};
    return {
        init(t) {
            e = Object.entries(t).reduce((e, [t, n]) => (e[t] = n, e), {});
        },
        insertOrUpdate(t, n) {
            e[t] = n;
        },
        get(t) {
            if (Object.prototype.hasOwnProperty.call(e, t)) return e[t];
        },
        getAll() {
            return e;
        }
    };
}

function Kf(e, t) {
    let n = [];
    return Object.entries(e).forEach(([e, r]) => {
        let i = t[e];
        (!i || !pd(r, i)) && n.push(e);
    }), Object.keys(t).forEach((t) => {
        e[t] || n.push(t);
    }), n;
}

function qf(e, t) {
    let n = e,
        r = t,
        i, a = [];
    return {
        handleFlagChanges(e, t) {
            i ? a.forEach((n) => {
                try {
                    n(i, e, t);
                } catch {}
            }) : r.warn("Received a change event without an active context. Changes will not be propagated.");
        },
        init(e, t) {
            i = e;
            let r = n.getAll();
            n.init(t);
            let a = Kf(r, t);
            a.length > 0 && this.handleFlagChanges(a, "init");
        },
        initCached(e, t) {
            i ? .canonicalKey !== e.canonicalKey && this.init(e, t);
        },
        upsert(e, t, a) {
            if (i ? .canonicalKey !== e.canonicalKey) return r.warn("Received an update for an inactive context."), !1;
            let o = n.get(t);
            return o !== void 0 && o.version >= a.version ? !1 : (n.insertOrUpdate(t, a), this.handleFlagChanges([t], "patch"), !0);
        },
        on(e) {
            a.push(e);
        },
        off(e) {
            let t = a.indexOf(e);
            t > -1 && a.splice(t, 1);
        }
    };
}
var Jf = class {
        constructor(e, t, n, r, i = () => Date.now()) {
            this.P = Gf(), this.w = qf(this.P, r), this.$t = this.Ii(e, t, n, r, i);
        }
        async Ii(e, t, n, r, i = () => Date.now()) {
            return new Wf(e, await hf(e.crypto, t), n, this.P, this.w, r, i);
        }
        get(e) {
            return this.r && Object.prototype.hasOwnProperty.call(this.r, e) ? this.Nt(this.r[e]) : this.P.get(e);
        }
        getAll() {
            return this.r ? Y(Y({}, this.P.getAll()), Object.entries(this.r).reduce((e, [t, n]) => (e[t] = this.Nt(n), e), {})) : this.P.getAll();
        }
        presetFlags(e) {
            this.P.init(e);
        }
        setBootstrap(e, t) {
            this.w.init(e, t);
        }
        async init(e, t) {
            return (await this.$t).init(e, t);
        }
        async upsert(e, t, n) {
            return (await this.$t).upsert(e, t, n);
        }
        async loadCached(e) {
            return (await this.$t).loadCached(e);
        }
        on(e) {
            this.w.on(e);
        }
        off(e) {
            this.w.off(e);
        }
        Nt(e) {
            return {
                flag: {
                    value: e,
                    version: 0
                },
                version: 0
            };
        }
        setOverride(e, t) {
            this.r || = {}, this.r[e] = t, this.w.handleFlagChanges([e], "override");
        }
        removeOverride(e) {
            !this.r || !Object.prototype.hasOwnProperty.call(this.r, e) || (delete this.r[e], Object.keys(this.r).length === 0 && (this.r = void 0), this.w.handleFlagChanges([e], "override"));
        }
        clearAllOverrides() {
            if (this.r) {
                let e = Y({}, this.r);
                this.r = void 0, this.w.handleFlagChanges(Object.keys(e), "override");
            }
        }
        getAllOverrides() {
            if (!this.r) return {};
            let e = {};
            return Object.entries(this.r).forEach(([t, n]) => {
                e[t] = this.Nt(n);
            }), e;
        }
        getDebugOverride() {
            return {
                setOverride: this.setOverride.bind(this),
                removeOverride: this.removeOverride.bind(this),
                clearAllOverrides: this.clearAllOverrides.bind(this),
                getAllOverrides: this.getAllOverrides.bind(this)
            };
        }
    },
    Yf = "unknown hook",
    Xf = "beforeEvaluation",
    Zf = "afterEvaluation",
    Qf = "afterTrack";

function $f(e, t, n, r, i) {
    try {
        return r();
    } catch (r) {
        return e ? .error(`An error was encountered in "${t}" of the "${n}" hook: ${r}`), i;
    }
}

function ep(e, t) {
    try {
        return t.getMetadata().name || Yf;
    } catch {
        return e.error("Exception thrown getting metadata for hook. Unable to get hook name."), Yf;
    }
}

function tp(e, t, n) {
    return t.map((t) => $f(e, Xf, ep(e, t), () => (t ? .beforeEvaluation) ? .call(t, n, {}) ? ? {}, {}));
}

function np(e, t, n, r, i) {
    for (let a = t.length - 1; a >= 0; --a) {
        let o = t[a],
            s = r[a];
        $f(e, Zf, ep(e, o), () => (o ? .afterEvaluation) ? .call(o, n, s, i) ? ? {}, {});
    }
}

function rp(e, t, n) {
    return t.map((t) => $f(e, Xf, ep(e, t), () => (t ? .beforeIdentify) ? .call(t, n, {}) ? ? {}, {}));
}

function ip(e, t, n, r, i) {
    for (let a = t.length - 1; a >= 0; --a) {
        let o = t[a],
            s = r[a];
        $f(e, Zf, ep(e, o), () => (o ? .afterIdentify) ? .call(o, n, s, i) ? ? {}, {});
    }
}

function ap(e, t, n) {
    for (let r = t.length - 1; r >= 0; --r) {
        let i = t[r];
        $f(e, Qf, ep(e, i), () => (i ? .afterTrack) ? .call(i, n), void 0);
    }
}
var op = class {
    constructor(e, t) {
        this.t = e, this.R = [], this.R.push(...t);
    }
    withEvaluation(e, t, n, r) {
        if (this.R.length === 0) return r();
        let i = [...this.R],
            a = {
                flagKey: e,
                context: t,
                defaultValue: n
            },
            o = tp(this.t, i, a),
            s = r();
        return np(this.t, i, a, o, s), s;
    }
    identify(e, t) {
        let n = [...this.R],
            r = {
                context: e,
                timeout: t
            },
            i = rp(this.t, n, r);
        return (e) => {
            ip(this.t, n, r, i, e);
        };
    }
    addHook(e) {
        this.R.push(e);
    }
    afterTrack(e) {
        if (this.R.length === 0) return;
        let t = [...this.R];
        ap(this.t, t, e);
    }
};

function sp(e) {
    return {
        getMetadata() {
            return {
                name: "LaunchDarkly-Inspector-Adapter"
            };
        },
        afterEvaluation: (t, n, r) => (e.onFlagUsed(t.flagKey, r, t.context), n),
        afterIdentify(t, n, r) {
            return e.onIdentityChanged(t.context), n;
        }
    };
}

function cp(e, t) {
    return `an inspector: "${t}" of an invalid type (${e}) was configured`;
}

function lp(e, t) {
    return `an inspector: "${t}" of type: "${e}" generated an exception`;
}

function up(e, t) {
    let n = !1,
        r = {
            method: (...i) => {
                try {
                    e.method(...i);
                } catch {
                    n || (n = !0, t.warn(lp(r.type, r.name)));
                }
            },
            type: e.type,
            name: e.name,
            synchronous: e.synchronous
        };
    return r;
}
var dp = "flag-used",
    fp = "flag-details-changed",
    pp = "flag-detail-changed",
    mp = "client-identity-changed",
    hp = [
        dp,
        fp,
        pp,
        mp
    ];

function gp(e, t) {
    let n = hp.includes(e.type) && e.method && typeof e.method == "function";
    return n || t.warn(cp(e.type, e.name)), n;
}
var _p = class {
        constructor(e, t) {
            this.W = [], this.W = e.filter((e) => gp(e, t)).map((e) => up(e, t));
        }
        hasInspectors() {
            return this.W.length !== 0;
        }
        onFlagUsed(e, t, n) {
            this.W.forEach((r) => {
                r.type === dp && r.method(e, t, n);
            });
        }
        onFlagsChanged(e) {
            this.W.forEach((t) => {
                t.type === fp && t.method(e);
            });
        }
        onFlagChanged(e, t) {
            this.W.forEach((n) => {
                n.type === pp && n.method(e, t);
            });
        }
        onIdentityChanged(e) {
            this.W.forEach((t) => {
                t.type === mp && t.method(e);
            });
        }
    },
    vp = class {
        constructor(e) {
            this.t = e, this.n = /* @__PURE__ */ new Map();
        }
        on(e, t) {
            var n;
            this.n.has(e) ? (n = this.n.get(e)) == null || n.push(t) : this.n.set(e, [t]);
        }
        off(e, t) {
            let n = this.n.get(e);
            if (n) {
                if (t) {
                    let r = n.filter((e) => e !== t);
                    r.length === 0 ? this.n.delete(e) : this.n.set(e, r);
                    return;
                }
                this.n.delete(e);
            }
        }
        Ai(e, t, ...n) {
            var r;
            try {
                e(...n);
            } catch (e) {
                (r = this.t) == null || r.error(`Encountered error invoking handler for "${t}", detail: "${e}"`);
            }
        }
        emit(e, ...t) {
            this.n.get(e) ? .forEach((n) => this.Ai(n, e, ...t));
        }
        eventNames() {
            return [...this.n.keys()];
        }
        listenerCount(e) {
            return this.n.get(e) ? .length ? ? 0;
        }
    };

function yp(e, t, n) {
    let r = t.info.sdkData(),
        i;
    n.applicationInfo && (n.applicationInfo.id && (i ? ? = {}, i.id = n.applicationInfo.id), n.applicationInfo.version && (i ? ? = {}, i.version = n.applicationInfo.version), n.applicationInfo.name && (i ? ? = {}, i.name = n.applicationInfo.name), n.applicationInfo.versionName && (i ? ? = {}, i.versionName = n.applicationInfo.versionName));
    let a = {
        name: r.userAgentBase,
        version: r.version
    };
    r.wrapperName && (a.wrapperName = r.wrapperName), r.wrapperVersion && (a.wrapperVersion = r.wrapperVersion);
    let o = {
        sdk: a,
        [n.credentialType]: e
    };
    return i && (o.application = i), o;
}
var {
    ClientMessages: bp,
    ErrorKinds: xp
} = Yd, Sp = 5, Cp = class {
    constructor(e, t, n, r, i, a) {
        if (this.sdkKey = e, this.autoEnvAttributes = t, this.platform = n, this.a = Of(), this.Rt = 15, this.T = new Hf(!1), this.ht = new Hf(!0), this.Mt = !1, this.Pi = nf(), !e) throw Error("You must configure the client with a client-side SDK key");
        if (!n.encoding) throw Error("Platform must implement Encoding because btoa is required.");
        this.e = new lf(r, a), this.logger = this.e.logger, this.De = md(this.sdkKey, this.platform.info, this.e.tags, this.e.serviceEndpoints.includeAuthorizationHeader, this.e.userAgentHeaderName), this.M = new Jf(this.platform, e, this.e.maxCachedContexts, this.e.logger), this.S = Rf(e, this.e, n), this.E = Vf(e, this.e, n, this.De, this.S), this.emitter = new vp(), this.emitter.on("error", (e, t) => {
            this.logger.error(`error: ${t}, context: ${JSON.stringify(e)}`);
        }), this.M.on((e, t, n) => {
            this.Oi(t, n);
            let r = _u.toLDContext(e);
            this.emitter.emit("change", r, t), t.forEach((e) => {
                this.emitter.emit(`change:${e}`, r);
            });
        }), this.dataManager = i(this.M, this.e, this.De, this.emitter, this.S);
        let o = [...this.e.hooks];
        if (this.environmentMetadata = yp(this.sdkKey, this.platform, this.e), this.e.getImplementationHooks(this.environmentMetadata).forEach((e) => {
                o.push(e);
            }), this.F = new op(this.logger, o), this.Q = new _p(this.e.inspectors, this.logger), this.Q.hasInspectors() && this.F.addHook(sp(this.Q)), r.cleanOldPersistentData && a != null && a.getLegacyStorageKeys && this.platform.storage) try {
            this.logger.debug("Cleaning old persistent data."), Promise.all(a.getLegacyStorageKeys().map((e) => this.platform.storage ? .clear(e))).catch((e) => {
                this.logger.error(`Error cleaning old persistent data: ${e}`);
            }).finally(() => {
                this.logger.debug("Cleaned old persistent data.");
            });
        } catch (e) {
            this.logger.error(`Error cleaning old persistent data: ${e}`);
        }
    }
    allFlags() {
        return Object.entries(this.M.getAll()).reduce((e, [t, n]) => (n.flag !== null && n.flag !== void 0 && !n.flag.deleted && (e[t] = n.flag.value), e), {});
    }
    async close() {
        var e;
        await this.flush(), (e = this.E) == null || e.close(), this.dataManager.close(), this.logger.debug("Closed event processor and data source.");
    }
    async flush() {
        try {
            await this.E ? .flush(), this.logger.debug("Successfully flushed event processor.");
        } catch (e) {
            return this.logger.error(`Error flushing event processor: ${e}.`), {
                error: e,
                result: !1
            };
        }
        return {
            result: !0
        };
    }
    getContext() {
        return this.a.hasContext() ? ld(this.a.getUnwrappedContext()) : void 0;
    }
    getInternalContext() {
        return this.a.getContext();
    }
    presetFlags(e) {
        this.M.presetFlags(e);
    }
    async identify(e, t) {
        let n = await this.identifyResult(e, t);
        if (n.status === "error") throw n.error;
        if (n.status === "timeout") {
            let e = new ad(`identify timed out after ${n.timeout} seconds.`);
            throw this.logger.error(e.message), e;
        }
    }
    async identifyResult(e, t) {
        let n = t ? .timeout ? ? Sp,
            r = t ? .timeout === void 0 && t ? .noTimeout === !0;
        n > this.Rt && this.logger.warn(`The identify function was called with a timeout greater than ${this.Rt} seconds. We recommend a timeout of less than ${this.Rt} seconds.`);
        let i = this.Pi.execute({
            before: async () => {
                let n = await If(e, this.platform);
                this.autoEnvAttributes === Au.Enabled && (n = await Df(n, this.platform, this.e));
                let r = _u.fromLDContext(n);
                if (r.valid) {
                    let e = this.F.identify(n, t ? .timeout);
                    return {
                        context: n,
                        checkedContext: r,
                        afterIdentify: e
                    };
                }
                return {
                    context: n,
                    checkedContext: r
                };
            },
            execute: async (e) => {
                var n;
                let {
                    context: r,
                    checkedContext: i
                } = e;
                if (!i.valid) {
                    let e = /* @__PURE__ */ Error("Context was unspecified or had no key");
                    return this.emitter.emit("error", r, e), Promise.reject(e);
                }
                this.a.set(r, i), (n = this.E) == null || n.sendEvent(this.T.identifyEvent(i));
                let {
                    identifyPromise: a,
                    identifyResolve: o,
                    identifyReject: s
                } = this.a.newIdentificationPromise();
                return this.logger.debug(`Identifying ${JSON.stringify(i)}`), await this.dataManager.identify(o, s, i, t), a;
            },
            after: async (e, t) => {
                var n, r, i;
                e.status === "complete" ? (n = t ? .afterIdentify) == null || n.call(t, {
                    status: "completed"
                }) : e.status === "shed" ? (r = t ? .afterIdentify) == null || r.call(t, {
                    status: "shed"
                }) : e.status === "error" && ((i = t ? .afterIdentify) == null || i.call(t, {
                    status: "error"
                }));
            }
        }, t ? .sheddable ? ? !1).then((e) => {
            if (e.status === "error") {
                let t = {
                    status: "error",
                    error: e.error
                };
                return this.maybeSetInitializationResult({
                    status: "failed",
                    error: e.error
                }), t;
            }
            return e.status === "shed" ? {
                status: "shed"
            } : (this.maybeSetInitializationResult({
                status: "complete"
            }), {
                status: "completed"
            });
        });
        if (r) return i;
        let a = new Promise((e) => {
            setTimeout(() => {
                e({
                    status: "timeout",
                    timeout: n
                });
            }, n * 1e3);
        });
        return Promise.race([i, a]);
    }
    maybeSetInitializationResult(e) {
        this.initializeResult === void 0 && (this.initializeResult = e, this.emitter.emit("ready"), e.status === "complete" && this.emitter.emit("initialized"), this.initResolve && = (this.initResolve(e), void 0));
    }
    waitForInitialization(e) {
        let t = e ? .timeout ? ? 5;
        return this.initializeResult ? Promise.resolve(this.initializeResult) : (this.initializedPromise || (this.initializedPromise || = new Promise((e) => {
            this.initResolve = e;
        })), this.promiseWithTimeout(this.initializedPromise, t));
    }
    promiseWithTimeout(e, t) {
        let n = cd(t, "waitForInitialization");
        return Promise.race([e.then((e) => (n.cancel(), e)), n.promise.then(() => ({
            status: "complete"
        })).catch(() => ({
            status: "timeout"
        }))]).catch((e) => {
            var t;
            return (t = this.logger) == null || t.error(e.message), {
                status: "failed",
                error: e
            };
        });
    }
    on(e, t) {
        this.emitter.on(e, t);
    }
    off(e, t) {
        this.emitter.off(e, t);
    }
    track(e, t, n) {
        var r, i;
        if (!this.a.hasValidContext()) {
            this.logger.warn(bp.MissingContextKeyNoEvent);
            return;
        }
        n !== void 0 && !X.Number.is(n) && ((r = this.logger) == null || r.warn(bp.invalidMetricValue(typeof n))), (i = this.E) == null || i.sendEvent(this.e.trackEventModifier(this.T.customEvent(e, this.a.getContext(), t, n))), this.F.afterTrack({
            key: e,
            context: this.a.getUnwrappedContext(),
            data: t,
            metricValue: n
        });
    }
    dt(e, t, n, r) {
        var i, a, o, s, c;
        let l = this.a.hasContext();
        l || (i = this.logger) == null || i.warn("Flag evaluation called before client is fully initialized, data from this evaulation could be stale.");
        let u = this.a.getContext(),
            d = this.M.get(e);
        if (d === void 0 || d.flag.deleted) {
            let n = t ? ? null;
            return (a = this.logger) == null || a.warn(`Unknown feature flag "${e}"; returning default value ${n}.`), l && ((o = this.E) == null || o.sendEvent(this.T.unknownFlagEvent(e, n, u))), zf(xp.FlagNotFound, t);
        }
        let {
            reason: f,
            value: p,
            variation: m,
            prerequisites: h
        } = d.flag;
        if (r) {
            let [i, a] = r(p);
            if (!i) {
                l && ((s = this.E) == null || s.sendEvent(n.evalEventClient(e, t, t, d.flag, u, f)));
                let r = new id(`Wrong type "${a}" for feature flag "${e}"; returning default value`);
                return this.emitter.emit("error", this.a.getUnwrappedContext(), r), zf(xp.WrongType, t);
            }
        }
        let g = Bf(p, m, f);
        return p ? ? (this.logger.debug("Result value is null. Providing default value."), g.value = t), h ? .forEach((e) => {
            this.dt(e, void 0, this.T);
        }), l && ((c = this.E) == null || c.sendEvent(n.evalEventClient(e, p, t, d.flag, u, f))), g;
    }
    variation(e, t) {
        let {
            value: n
        } = this.F.withEvaluation(e, this.a.getUnwrappedContext(), t, () => this.dt(e, t, this.T));
        return n;
    }
    variationDetail(e, t) {
        return this.F.withEvaluation(e, this.a.getUnwrappedContext(), t, () => this.dt(e, t, this.ht));
    }
    _(e, t, n, r) {
        return this.F.withEvaluation(e, this.a.getUnwrappedContext(), t, () => this.dt(e, t, n, r));
    }
    boolVariation(e, t) {
        return this._(e, t, this.T, (e) => [X.Boolean.is(e), X.Boolean.getType()]).value;
    }
    jsonVariation(e, t) {
        return this.variation(e, t);
    }
    numberVariation(e, t) {
        return this._(e, t, this.T, (e) => [X.Number.is(e), X.Number.getType()]).value;
    }
    stringVariation(e, t) {
        return this._(e, t, this.T, (e) => [X.String.is(e), X.String.getType()]).value;
    }
    boolVariationDetail(e, t) {
        return this._(e, t, this.ht, (e) => [X.Boolean.is(e), X.Boolean.getType()]);
    }
    numberVariationDetail(e, t) {
        return this._(e, t, this.ht, (e) => [X.Number.is(e), X.Number.getType()]);
    }
    stringVariationDetail(e, t) {
        return this._(e, t, this.ht, (e) => [X.String.is(e), X.String.getType()]);
    }
    jsonVariationDetail(e, t) {
        return this.variationDetail(e, t);
    }
    addHook(e) {
        this.F.addHook(e);
    }
    setEventSendingEnabled(e, t) {
        var n, r, i, a;
        this.Mt !== e && (this.Mt = e, e ? (this.logger.debug("Starting event processor"), (n = this.E) == null || n.start()) : t ? ((r = this.logger) == null || r.debug("Flushing event processor before disabling."), this.flush().then(() => {
            var e, t;
            this.Mt || ((e = this.logger) == null || e.debug("Stopping event processor."), (t = this.E) == null || t.close());
        })) : ((i = this.logger) == null || i.debug("Stopping event processor."), (a = this.E) == null || a.close()));
    }
    sendEvent(e) {
        var t;
        (t = this.E) == null || t.sendEvent(e);
    }
    getDebugOverrides() {
        var e;
        return (e = this.M).getDebugOverride ? .call(e);
    }
    Oi(e, t) {
        if (!this.Q.hasInspectors()) return;
        let n = {};
        e.forEach((e) => {
            let t = this.M.get(e);
            if (t != null && t.flag && !t.flag.deleted) {
                let {
                    reason: r,
                    value: i,
                    variation: a
                } = t.flag;
                n[e] = Bf(i, a, r);
            } else n[e] = {
                value: void 0,
                variationIndex: null
            };
        }), t === "init" ? this.Q.onFlagsChanged(n) : t === "patch" && Object.entries(n).forEach(([e, t]) => {
            this.Q.onFlagChanged(e, t);
        });
    }
};

function wp(e, t, n) {
    n.forEach((n) => {
        var r;
        try {
            (r = n.registerDebug) == null || r.call(n, t);
        } catch {
            e.error(`Exception thrown registering plugin ${Yd.safeGetName(e, n)}.`);
        }
    });
}

function Tp(e, t, n) {
    return {
        async handlePut(r, i) {
            n.debug(`Got PUT: ${Object.keys(i)}`);
            let a = Object.entries(i).reduce((e, [t, n]) => (e[t] = {
                version: n.version,
                flag: n
            }, e), {});
            await e.init(r, a), t.requestStateUpdate("VALID");
        },
        async handlePatch(t, r) {
            n.debug(`Got PATCH ${JSON.stringify(r, null, 2)}`), e.upsert(t, r.key, {
                version: r.version,
                flag: r
            });
        },
        async handleDelete(t, r) {
            n.debug(`Got DELETE ${JSON.stringify(r, null, 2)}`), e.upsert(t, r.key, {
                version: r.version,
                flag: Vl(Y({}, r), {
                    deleted: !0,
                    flagVersion: 0,
                    value: void 0,
                    variation: 0,
                    trackEvents: !1
                })
            });
        },
        handleStreamingError(e) {
            t.reportError(e.kind, e.message, e.code, e.recoverable);
        },
        handlePollingError(e) {
            t.reportError(e.kind, e.message, e.status, e.recoverable);
        }
    };
}

function Ep(e, t = () => Date.now()) {
    let n = "CLOSED",
        r = t(),
        i;

    function a() {
        return {
            state: n,
            stateSince: r,
            lastError: i
        };
    }

    function o(i, o = !1) {
        let s = i === "INTERRUPTED" && n === "INITIALIZING" ? "INITIALIZING" : i,
            c = n !== s;
        c && (n = s, r = t()), (c || o) && e.emit("dataSourceStatus", a());
    }
    return {
        get status() {
            return a();
        },
        requestStateUpdate(e) {
            o(e);
        },
        reportError(e, n, r, a = !1) {
            i = {
                kind: e,
                message: n,
                statusCode: r,
                time: t()
            }, o(a ? "INTERRUPTED" : "CLOSED", !0);
        }
    };
}

function Dp(e) {
    e ? .debug("Poll completed after the processor was closed. Skipping processing.");
}
var Op = class {
        constructor(e, t, n, r, i) {
            this.Ti = e, this.$i = t, this.Ni = n, this.m = r, this.t = i, this.u = !1;
        }
        async be() {
            var e, t, n, r, i, a, o;
            if (this.u) return;
            let s = (e) => {
                var t, n, r;
                (t = this.t) == null || t.error("Polling received invalid data"), (n = this.t) == null || n.debug(`Invalid JSON follows: ${e}`), (r = this.m) == null || r.call(this, new Du(ku.InvalidData, "Malformed JSON data in polling response"));
            };
            (e = this.t) == null || e.debug("Polling LaunchDarkly for feature flag updates");
            let c = Date.now();
            try {
                let e = await this.Ti.requestPayload();
                try {
                    if (this.u) {
                        Dp(this.t);
                        return;
                    }
                    let r = JSON.parse(e);
                    try {
                        (t = this.Ni) == null || t.call(this, r);
                    } catch (e) {
                        (n = this.t) == null || n.error(`Exception from data handler: ${e}`);
                    }
                } catch {
                    s(e);
                }
            } catch (e) {
                if (this.u) {
                    Dp(this.t);
                    return;
                }
                let t = e;
                if (t.status !== void 0 && !od(t.status)) {
                    (r = this.t) == null || r.error(hd(e, "polling request")), (i = this.m) == null || i.call(this, new Du(ku.ErrorResponse, t.message, t.status));
                    return;
                }
                (a = this.t) == null || a.error(hd(e, "polling request", "will retry"));
            }
            let l = Date.now() - c,
                u = Math.max(this.$i * 1e3 - l, 0);
            (o = this.t) == null || o.debug("Elapsed: %d ms, sleeping for %d ms", l, u), this.Ft = setTimeout(() => {
                this.be();
            }, u);
        }
        start() {
            this.be();
        }
        stop() {
            this.Ft && = (clearTimeout(this.Ft), void 0), this.u = !0;
        }
        close() {
            this.stop();
        }
    },
    kp = (e, t, n, r) => {
        n ? .error(`Stream received invalid data in "${e}" message`), n ? .debug(`Invalid JSON follows: ${t}`), r ? .(new Ou(ku.InvalidData, "Malformed JSON data in event stream"));
    };

function Ap(e, t) {
    t ? .debug(`Received ${e} event after processor was closed. Skipping processing.`);
}

function jp(e) {
    e ? .debug("Ping completed after processor was closed. Skipping processing.");
}
var Mp = class {
        constructor(e, t, n, r, i, a, o, s, c) {
            this.Ri = e, this.Ut = t, this.n = n, this.H = r, this.Mi = a, this.S = o, this.m = s, this.t = c, this.u = !1;
            let l;
            l = t.useReport && !r.getEventSourceCapabilities().customMethod ? t.paths.pathPing(i, e) : t.useReport ? t.paths.pathReport(i, e) : t.paths.pathGet(i, e);
            let u = [...t.queryParameters ? ? []];
            this.Ut.withReasons && u.push({
                key: "withReasons",
                value: "true"
            }), this.H = r, this.ke = Y({}, t.baseHeaders), this.t = c, this.Fi = ed(t.serviceEndpoints, l, u);
        }
        xe() {
            this.ft = Date.now();
        }
        Vt(e) {
            this.ft && this.S && this.S.recordStreamInit(this.ft, !e, Date.now() - this.ft), this.ft = void 0;
        }
        Ui(e) {
            var t, n, r;
            return gd(e) ? ((r = this.t) == null || r.warn(hd(e, "streaming request", "will retry")), this.Vt(!1), this.xe(), !0) : (this.Vt(!1), (t = this.m) == null || t.call(this, new Ou(ku.ErrorResponse, e.message, e.status, !1)), (n = this.t) == null || n.error(hd(e, "streaming request")), !1);
        }
        start() {
            this.xe();
            let e;
            this.Ut.useReport ? (this.ke["content-type"] = "application/json", e = {
                method: "REPORT",
                body: this.Ri
            }) : e = {};
            let t = this.H.createEventSource(this.Fi, Vl(Y({
                headers: this.ke
            }, e), {
                errorFilter: (e) => this.Ui(e),
                initialRetryDelayMillis: this.Ut.initialRetryDelayMillis,
                readTimeoutMillis: 300 * 1e3,
                retryResetIntervalMillis: 60 * 1e3
            }));
            this.Se = t, t.onclose = () => {
                var e;
                (e = this.t) == null || e.info("Closed LaunchDarkly stream connection");
            }, t.onerror = () => {}, t.onopen = () => {
                var e;
                (e = this.t) == null || e.info("Opened LaunchDarkly stream connection");
            }, t.onretrying = (e) => {
                var t;
                (t = this.t) == null || t.info(`Will retry stream connection in ${e.delayMillis} milliseconds`);
            }, this.n.forEach(({
                deserializeData: e,
                processJson: n
            }, r) => {
                t.addEventListener(r, (t) => {
                    var i, a;
                    if (this.u) {
                        Ap(r, this.t);
                        return;
                    }
                    if ((i = this.t) == null || i.debug(`Received ${r} event`), t != null && t.data) {
                        this.Vt(!0);
                        let {
                            data: i
                        } = t, a = e(i);
                        if (!a) {
                            kp(r, i, this.t, this.m);
                            return;
                        }
                        n(a);
                    } else(a = this.m) == null || a.call(this, new Ou(ku.InvalidData, "Unexpected payload from event stream"));
                });
            }), t.addEventListener("ping", async () => {
                var e, t, n, r, i, a, o;
                (e = this.t) == null || e.debug("Got PING, going to poll LaunchDarkly for feature flag updates");
                try {
                    let e = await this.Mi.requestPayload();
                    try {
                        if (this.u) {
                            jp(this.t);
                            return;
                        }
                        let r = JSON.parse(e);
                        try {
                            (t = this.n.get("put")) == null || t.processJson(r);
                        } catch (e) {
                            (n = this.t) == null || n.error(`Exception from data handler: ${e}`);
                        }
                    } catch {
                        (r = this.t) == null || r.error("Polling after ping received invalid data"), (i = this.t) == null || i.debug(`Invalid JSON follows: ${e}`), (a = this.m) == null || a.call(this, new Du(ku.InvalidData, "Malformed JSON data in ping polling response"));
                    }
                } catch (e) {
                    if (this.u) {
                        jp(this.t);
                        return;
                    }
                    let t = e;
                    (o = this.m) == null || o.call(this, new Du(ku.ErrorResponse, t.message, t.status));
                }
            });
        }
        stop() {
            var e;
            (e = this.Se) == null || e.close(), this.Se = void 0, this.u = !0;
        }
        close() {
            this.stop();
        }
    },
    Np = class {
        constructor(e, t, n, r, i, a, o, s, c) {
            this.platform = e, this.flagManager = t, this.credential = n, this.config = r, this.getPollingPaths = i, this.getStreamingPaths = a, this.baseHeaders = o, this.emitter = s, this.diagnosticsManager = c, this.closed = !1, this.logger = r.logger, this.dataSourceStatusManager = Ep(s), this.q = Tp(t, this.dataSourceStatusManager, this.config.logger);
        }
        setConnectionParams(e) {
            this.Vi = e;
        }
        createPollingProcessor(e, t, n, r, i) {
            let a = new Op(n, this.config.pollInterval, async (e) => {
                await this.q.handlePut(t, e), r ? .();
            }, (t) => {
                this.emitter.emit("error", e, t), this.q.handlePollingError(t), i ? .(t);
            }, this.logger);
            this.updateProcessor = this.Le(a, this.dataSourceStatusManager);
        }
        createStreamingProcessor(e, t, n, r, i) {
            let a = new Mp(JSON.stringify(e), {
                credential: this.credential,
                serviceEndpoints: this.config.serviceEndpoints,
                paths: this.getStreamingPaths(),
                baseHeaders: this.baseHeaders,
                initialRetryDelayMillis: this.config.streamInitialReconnectDelay * 1e3,
                withReasons: this.config.withReasons,
                useReport: this.config.useReport,
                queryParameters: this.Vi ? .queryParameters
            }, this.createStreamListeners(t, r), this.platform.requests, this.platform.encoding, n, this.diagnosticsManager, (t) => {
                this.emitter.emit("error", e, t), this.q.handleStreamingError(t), i ? .(t);
            }, this.logger);
            this.updateProcessor = this.Le(a, this.dataSourceStatusManager);
        }
        createStreamListeners(e, t) {
            let n = /* @__PURE__ */ new Map();
            return n.set("put", {
                deserializeData: JSON.parse,
                processJson: async (n) => {
                    await this.q.handlePut(e, n), t ? .();
                }
            }), n.set("patch", {
                deserializeData: JSON.parse,
                processJson: async (t) => {
                    this.q.handlePatch(e, t);
                }
            }), n.set("delete", {
                deserializeData: JSON.parse,
                processJson: async (t) => {
                    this.q.handleDelete(e, t);
                }
            }), n;
        }
        Le(e, t) {
            return {
                start: () => {
                    t.requestStateUpdate("INITIALIZING"), e.start();
                },
                stop: () => {
                    e.stop(), t.requestStateUpdate("CLOSED");
                },
                close: () => {
                    e.close(), t.requestStateUpdate("CLOSED");
                }
            };
        }
        close() {
            var e;
            (e = this.updateProcessor) == null || e.close(), this.closed = !0;
        }
    };

function Pp(e, t) {
    let n = Object.keys(t),
        r = "$flagsState",
        i = "$valid",
        a = t[r];
    !a && n.length && e.warn("LaunchDarkly client was initialized with bootstrap data that did not include flag metadata. Events may not be sent correctly."), t[i] === !1 && e.warn("LaunchDarkly bootstrap data is not available because the back end could not read the flags.");
    let o = {};
    return n.forEach((e) => {
        if (e !== r && e !== i) {
            let n;
            n = a && a[e] ? Y({
                value: t[e]
            }, a[e]) : {
                value: t[e],
                version: 0
            }, o[e] = {
                version: n.version,
                flag: n
            };
        }
    }), o;
}

function Fp() {
    return !0;
}

function Ip() {
    return !0;
}

function Lp(e, t, n) {
    return Fp() ? (document.addEventListener(e, t, n), () => {
        document.removeEventListener(e, t, n);
    }) : () => {};
}

function Rp(e, t, n) {
    return Fp() ? (window.addEventListener(e, t, n), () => {
        window.removeEventListener(e, t, n);
    }) : () => {};
}

function zp() {
    return Ip() ? window.location.href : "";
}

function Bp() {
    return Ip() ? window.location.search : "";
}

function Vp() {
    return Ip() ? window.location.hash : "";
}

function Hp() {
    return crypto;
}

function Up() {
    return Fp() ? document.visibilityState : "visibile";
}

function Wp(e) {
    if (Fp()) return document.querySelectorAll(e);
}
var Gp = "[BrowserDataManager]",
    Kp = class extends Np {
        constructor(e, t, n, r, i, a, o, s, c, l) {
            super(e, t, n, r, a, o, s, c, l), this.Xi = i, this.tt = void 0, this.jt = !1, this.tt = i.streaming;
        }
        L(e, ...t) {
            this.logger.debug(`${Gp} ${e}`, ...t);
        }
        async identify(e, t, n, r) {
            if (this.closed) {
                this.L("Identify called after data manager was closed.");
                return;
            }
            this.context = n;
            let i = r;
            i != null && i.hash ? this.setConnectionParams({
                queryParameters: [{
                    key: "h",
                    value: i.hash
                }]
            }) : this.setConnectionParams(), this.Ht = i ? .hash, i != null && i.bootstrap ? this.ji(n, i, e) : (await this.flagManager.loadCached(n) && this.L("Identify - Flags loaded from cache. Continuing to initialize via a poll."), await this.Hi(n, e, t)), this.Bt();
        }
        async Bi(e) {
            let t = $d(JSON.stringify(_u.toLDContext(e)), this.config.serviceEndpoints, this.getPollingPaths(), this.platform.requests, this.platform.encoding, this.baseHeaders, [], this.config.withReasons, this.config.useReport, this.Ht),
                n;
            for (let e = 0; e <= 3; e += 1) try {
                return await t.requestPayload();
            } catch (t) {
                if (!gd(t)) throw t;
                n = t, e < 3 && (this.L(hd(t, "initial poll request", "will retry")), await vd(1e3));
            }
            throw n;
        }
        async Hi(e, t, n) {
            try {
                this.dataSourceStatusManager.requestStateUpdate(Xd.Initializing);
                let n = await this.Bi(e);
                try {
                    let r = this.createStreamListeners(e, t).get("put");
                    r.processJson(r.deserializeData(n));
                } catch (e) {
                    this.dataSourceStatusManager.reportError(ku.InvalidData, e.message ? ? "Could not parse poll response");
                }
            } catch (e) {
                this.dataSourceStatusManager.reportError(ku.NetworkError, e.message ? ? "unexpected network error", e.status), n(e);
            }
        }
        ji(e, t, n) {
            let {
                bootstrapParsed: r
            } = t;
            r || = Pp(this.logger, t.bootstrap), this.flagManager.setBootstrap(e, r), this.L("Identify - Initialization completed from bootstrap"), n();
        }
        setForcedStreaming(e) {
            this.tt = e, this.Bt();
        }
        setAutomaticStreamingState(e) {
            this.jt = e, this.Bt();
        }
        Bt() {
            let e = this.tt || this.jt && this.tt === void 0;
            this.L(`Updating streaming state. forced(${this.tt}) automatic(${this.jt})`), e ? this.zi() : this.Gi();
        }
        Gi() {
            var e;
            this.updateProcessor && this.L("Stopping update processor."), (e = this.updateProcessor) == null || e.close(), this.updateProcessor = void 0;
        }
        zi() {
            if (this.updateProcessor) {
                this.L("Update processor already active. Not changing state.");
                return;
            }
            if (!this.context) {
                this.L("Context not set, not starting update processor.");
                return;
            }
            this.L("Starting update processor."), this.Ki(this.context);
        }
        Ki(e, t, n) {
            var r;
            let i = _u.toLDContext(e);
            (r = this.updateProcessor) == null || r.close();
            let a = $d(JSON.stringify(_u.toLDContext(e)), this.config.serviceEndpoints, this.getPollingPaths(), this.platform.requests, this.platform.encoding, this.baseHeaders, [], this.config.withReasons, this.config.useReport, this.Ht);
            this.createStreamingProcessor(i, e, a, t, n), this.updateProcessor.start();
        }
    };

function qp(e) {
    let t = Lp("visibilitychange", () => {
            Up() === "hidden" && e();
        }),
        n = Rp("pagehide", e);
    return () => {
        t(), n();
    };
}

function Jp(e) {
    if (typeof e != "string") throw TypeError("Expected a string");
    return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}

function Yp(e, t, n, r) {
    let i = ((e.kind === "substring" || e.kind === "regex") && r.includes("/") ? t : t.replace(r, "")).replace(n, "");
    switch (e.kind) {
        case "exact":
            return RegExp(`^${Jp(e.url)}/?$`).test(t);
        case "canonical":
            return RegExp(`^${Jp(e.url)}/?$`).test(i);
        case "substring":
            return RegExp(`.*${Jp(e.substring)}.*$`).test(i);
        case "regex":
            return new RegExp(e.pattern).test(i);
        default:
            return !1;
    }
}

function Xp(e, t) {
    let n = [];
    return t.forEach((t) => {
        let r = e.target,
            {
                selector: i
            } = t,
            a = Wp(i);
        for (; r && a != null && a.length;) {
            for (let e = 0; e < a.length; e += 1)
                if (r === a[e]) {
                    n.push(t);
                    break;
                }
            r = r.parentNode;
        }
    }), n;
}
var Zp = class {
        constructor(e, t) {
            let n = e.filter((e) => e.urls ? .some((e) => Yp(e, zp(), Bp(), Vp()))),
                r = n.filter((e) => e.kind === "pageview"),
                i = n.filter((e) => e.kind === "click");
            r.forEach((e) => t(e)), i.length && (this.Ce = Lp("click", (e) => {
                Xp(e, i).forEach((e) => {
                    t(e);
                });
            }));
        }
        close() {
            var e;
            (e = this.Ce) == null || e.call(this);
        }
    },
    Qp = 300,
    $p = class {
        constructor(e) {
            this.zt = zp();
            let t = () => {
                let t = zp();
                t !== this.zt && (this.zt = t, e());
            };
            this.Gt = setInterval(t, Qp);
            let n = Rp("popstate", t);
            this.Ie = () => {
                n();
            };
        }
        close() {
            var e;
            this.Gt && clearInterval(this.Gt), (e = this.Ie) == null || e.call(this);
        }
    },
    em = class {
        constructor(e, t, n, r, i, a = (e) => new $p(e)) {
            this.H = t, this.qi = r, this._i = i, this.pt = [], this.Pe = !1, this.gt = `${n}/sdk/goals/${e}`, this.Ae = a(() => {
                this.Wt();
            });
        }
        async initialize() {
            await this.Wi(), this.Wt();
        }
        startTracking() {
            this.Pe = !0, this.Wt();
        }
        Wt() {
            var e;
            this.Pe && ((e = this.Kt) == null || e.close(), this.pt && this.pt.length && (this.Kt = new Zp(this.pt, (e) => {
                this._i(zp(), e);
            })));
        }
        async Wi() {
            try {
                this.pt = await (await this.H.fetch(this.gt)).json();
            } catch (e) {
                this.qi(new rd(`Encountered error fetching goals: ${e}`));
            }
        }
        close() {
            var e, t;
            (e = this.Ae) == null || e.close(), (t = this.Kt) == null || t.close();
        }
    };

function tm(e) {
    return e.kind === "click";
}
var nm = 2,
    rm = {
        fetchGoals: !0,
        eventUrlTransformer: (e) => e,
        streaming: void 0,
        plugins: []
    },
    im = {
        fetchGoals: X.Boolean,
        eventUrlTransformer: X.Function,
        streaming: X.Boolean,
        plugins: X.createTypeArray("LDPlugin", {})
    };

function am(e) {
    let t = Y({}, e);
    return t.flushInterval ? ? = nm, t;
}

function om(e) {
    let t = am(e);
    return Object.keys(rm).forEach((e) => {
        delete t[e];
    }), t;
}

function sm(e, t) {
    let n = Y({}, rm);
    return Object.entries(im).forEach((r) => {
        let [i, a] = r, o = e[i];
        o !== void 0 && (a.is(o) ? n[i] = o : t.warn(Gu.wrongOptionType(i, a.getType(), typeof o)));
    }), n;
}
var cm = class {
        constructor(e, t) {
            switch (this.Ji = e, this.Oe = [], t) {
                case "sha1":
                    this._t = "SHA-1";
                    break;
                case "sha256":
                    this._t = "SHA-256";
                    break;
                default:
                    throw Error(`Algorithm is not supported ${t}`);
            }
        }
        async asyncDigest(e) {
            let t = this.Oe.join(""),
                n = new TextEncoder().encode(t),
                r = await this.Ji.subtle.digest(this._t, n);
            switch (e) {
                case "base64":
                    return btoa(String.fromCharCode(...new Uint8Array(r)));
                case "hex":
                    return [...new Uint8Array(r)].map((e) => e.toString(16).padStart(2, "0")).join("");
                default:
                    throw Error(`Encoding is not supported ${e}`);
            }
        }
        update(e) {
            return this.Oe.push(e), this;
        }
    },
    lm = {
        start: 0,
        end: 3
    },
    um = {
        start: 4,
        end: 5
    },
    dm = {
        start: 6,
        end: 7
    },
    fm = {
        start: 8,
        end: 8
    },
    pm = {
        start: 9,
        end: 9
    },
    mm = {
        start: 10,
        end: 15
    };

function hm() {
    if (crypto && crypto.getRandomValues) {
        let e = new Uint8Array(16);
        return crypto.getRandomValues(e), [...e.values()];
    }
    let e = [];
    for (let t = 0; t < 16; t += 1) e.push(Math.floor(Math.random() * 256));
    return e;
}

function gm(e, t) {
    let n = "";
    for (let r = t.start; r <= t.end; r += 1) n += e[r].toString(16).padStart(2, "0");
    return n;
}

function _m(e) {
    return e[fm.start] = (e[fm.start] | 128) & 191, e[dm.start] = e[dm.start] & 15 | 64, `${gm(e, lm)}-${gm(e, um)}-${gm(e, dm)}-${gm(e, fm)}${gm(e, pm)}-${gm(e, mm)}`;
}

function vm() {
    return _m(hm());
}

function ym() {
    return typeof crypto.randomUUID == "function" ? crypto.randomUUID() : vm();
}
var bm = class {
    createHash(e) {
        return new cm(Hp(), e);
    }
    randomUUID() {
        return ym();
    }
};

function xm(e) {
    let t = Array.from(e, (e) => String.fromCodePoint(e)).join("");
    return btoa(t);
}
var Sm = class {
        btoa(e) {
            return xm(new TextEncoder().encode(e));
        }
    },
    Cm = class {
        constructor(e) {
            this.e = e;
        }
        platformData() {
            return {
                name: "JS"
            };
        }
        sdkData() {
            let e = {
                name: "@launchdarkly/js-client-sdk",
                version: "4.0.0",
                userAgentBase: "JSClient"
            };
            return this.e.wrapperName && (e.wrapperName = this.e.wrapperName), this.e.wrapperVersion && (e.wrapperVersion = this.e.wrapperVersion), e;
        }
    },
    wm = class {
        constructor(e, t) {
            this.gt = e, this.n = {}, this.I = new Tu(t.initialRetryDelayMillis, t.retryResetIntervalMillis), this.Te = t.errorFilter, this.$e();
        }
        $e() {
            this.J = new EventSource(this.gt), this.J.onopen = () => {
                var e;
                this.I.success(), (e = this.onopen) == null || e.call(this);
            }, this.J.onerror = (e) => {
                var t;
                this.Yi(e), (t = this.onerror) == null || t.call(this, e);
            }, Object.entries(this.n).forEach(([e, t]) => {
                t.forEach((t) => {
                    var n;
                    (n = this.J) == null || n.addEventListener(e, t);
                });
            });
        }
        addEventListener(e, t) {
            var n, r;
            (n = this.n)[e] ? ? (n[e] = []), this.n[e].push(t), (r = this.J) == null || r.addEventListener(e, t);
        }
        close() {
            var e, t;
            clearTimeout(this.qt), this.qt = void 0, (e = this.J) == null || e.close(), (t = this.onclose) == null || t.call(this);
        }
        Zi(e) {
            var t;
            (t = this.onretrying) == null || t.call(this, {
                delayMillis: e
            }), this.qt = setTimeout(() => {
                this.$e();
            }, e);
        }
        Yi(e) {
            this.close(), !(e.status && typeof e.status == "number" && !this.Te(e)) && this.Zi(this.I.fail());
        }
    },
    Tm = class {
        fetch(e, t) {
            return fetch(e, t);
        }
        createEventSource(e, t) {
            return new wm(e, t);
        }
        getEventSourceCapabilities() {
            return {
                customMethod: !1,
                readTimeout: !1,
                headers: !1
            };
        }
    };

function Em() {
    return typeof localStorage < "u";
}

function Dm() {
    if (!Em()) return [];
    let e = [];
    for (let t = 0; t < localStorage.length; t += 1) {
        let n = localStorage.key(t);
        n && e.push(n);
    }
    return e;
}
var Om = class {
        constructor(e) {
            this.t = e;
        }
        async clear(e) {
            var t;
            try {
                localStorage.removeItem(e);
            } catch (n) {
                (t = this.t) == null || t.error(`Error clearing key from localStorage: ${e}, reason: ${n}`);
            }
        }
        async get(e) {
            var t;
            try {
                return localStorage.getItem(e) ? ? null;
            } catch (n) {
                return (t = this.t) == null || t.error(`Error getting key from localStorage: ${e}, reason: ${n}`), null;
            }
        }
        async set(e, t) {
            var n;
            try {
                localStorage.setItem(e, t);
            } catch (t) {
                (n = this.t) == null || n.error(`Error setting key in localStorage: ${e}, reason: ${t}`);
            }
        }
    },
    km = class {
        constructor(e, t) {
            this.encoding = new Sm(), this.crypto = new bm(), this.requests = new Tm(), Em() && (this.storage = new Om(e)), this.info = new Cm(t);
        }
    },
    Am = class extends Cp {
        constructor(e, t, n = {}, r) {
            let {
                logger: i,
                debug: a
            } = n, o = i ? ? new Vu({
                destination: {
                    debug: console.debug,
                    info: console.info,
                    warn: console.warn,
                    error: console.error
                },
                level: a ? "debug" : "info"
            }), s = n.baseUri ? ? "https://clientsdk.launchdarkly.com", c = r ? ? new km(o, n), l = sm(n, o), u = om(Vl(Y({}, n), {
                logger: o
            })), {
                eventUrlTransformer: d
            } = l;
            super(e, t, c, u, (t, n, r, i, a) => new Kp(c, t, e, n, l, () => ({
                pathGet(t, n) {
                    return `/sdk/evalx/${e}/contexts/${_d(n, t)}`;
                },
                pathReport(t, n) {
                    return `/sdk/evalx/${e}/context`;
                },
                pathPing(e, t) {
                    throw Error("Ping for polling unsupported.");
                }
            }), () => ({
                pathGet(t, n) {
                    return `/eval/${e}/${_d(n, t)}`;
                },
                pathReport(t, n) {
                    return `/eval/${e}`;
                },
                pathPing(t, n) {
                    return `/ping/${e}`;
                }
            }), r, i, a), {
                getLegacyStorageKeys: () => Dm().filter((t) => t.startsWith(`ld:${e}:`)),
                analyticsEventPath: `/events/bulk/${e}`,
                diagnosticEventPath: `/events/diagnostic/${e}`,
                includeAuthorizationHeader: !1,
                highTimeoutThreshold: 5,
                userAgentHeaderName: "x-launchdarkly-user-agent",
                trackEventModifier: (e) => new Yd.InputCustomEvent(e.context, e.key, e.data, e.metricValue, e.samplingRatio, d(zp())),
                getImplementationHooks: (e) => Yd.safeGetHooks(o, e, l.plugins),
                credentialType: "clientSideId"
            }), this.setEventSendingEnabled(!0, !1), this.Yt = l.plugins, l.fetchGoals && (this.Jt = new em(e, c.requests, s, (e) => {
                o.error(e.message);
            }, (e, t) => {
                let n = this.getInternalContext();
                if (!n) return;
                let r = d(e);
                tm(t) ? this.sendEvent({
                    kind: "click",
                    url: r,
                    samplingRatio: 1,
                    key: t.key,
                    creationDate: Date.now(),
                    context: n,
                    selector: t.selector
                }) : this.sendEvent({
                    kind: "pageview",
                    url: r,
                    samplingRatio: 1,
                    key: t.key,
                    creationDate: Date.now(),
                    context: n
                });
            }), this.Jt.initialize(), l.automaticBackgroundHandling && qp(() => this.flush()));
        }
        registerPlugins(e) {
            Yd.safeRegisterPlugins(this.logger, this.environmentMetadata, e, this.Yt || []);
            let t = this.getDebugOverrides();
            t && wp(this.logger, t, this.Yt || []);
        }
        setInitialContext(e) {
            this.Zt = e;
        }
        async identify(e, t) {
            return super.identify(e, t);
        }
        async identifyResult(e, t) {
            var n;
            if (!this.et) return this.logger.error("Client must be started before it can identify a context, did you forget to call start()?"), {
                status: "error",
                error: /* @__PURE__ */ Error("Identify called before start")
            };
            let r = Y({}, t);
            t ? .sheddable === void 0 && (r.sheddable = !0);
            let i = await super.identifyResult(e, r);
            return (n = this.Jt) == null || n.startTracking(), i;
        }
        start(e) {
            if (this.initializeResult) return Promise.resolve(this.initializeResult);
            if (this.et) return this.et;
            if (!this.Zt) return this.logger.error("Initial context not set"), Promise.resolve({
                status: "failed",
                error: /* @__PURE__ */ Error("Initial context not set")
            });
            let t = Vl(Y({}, e ? .identifyOptions ? ? {}), {
                sheddable: !1
            });
            if (e != null && e.bootstrap && !t.bootstrap && (t.bootstrap = e.bootstrap), t != null && t.bootstrap) try {
                t.bootstrapParsed || = Pp(this.logger, t.bootstrap), this.presetFlags(t.bootstrapParsed);
            } catch (e) {
                this.logger.error("Failed to bootstrap data", e);
            }
            return this.initializedPromise || = new Promise((e) => {
                this.initResolve = e;
            }), this.et = this.promiseWithTimeout(this.initializedPromise, e ? .timeout ? ? 5), this.identifyResult(this.Zt, t), this.et;
        }
        setStreaming(e) {
            this.dataManager.setForcedStreaming(e);
        }
        Ne() {
            this.dataManager.setAutomaticStreamingState(!!this.emitter.listenerCount("change"));
        }
        on(e, t) {
            super.on(e, t), this.Ne();
        }
        off(e, t) {
            super.off(e, t), this.Ne();
        }
    };

function jm(e, t, n, r = {}, i) {
    let a = new Am(e, n, r, i);
    a.setInitialContext(t);
    let o = {
        variation: (e, t) => a.variation(e, t),
        variationDetail: (e, t) => a.variationDetail(e, t),
        boolVariation: (e, t) => a.boolVariation(e, t),
        boolVariationDetail: (e, t) => a.boolVariationDetail(e, t),
        numberVariation: (e, t) => a.numberVariation(e, t),
        numberVariationDetail: (e, t) => a.numberVariationDetail(e, t),
        stringVariation: (e, t) => a.stringVariation(e, t),
        stringVariationDetail: (e, t) => a.stringVariationDetail(e, t),
        jsonVariation: (e, t) => a.jsonVariation(e, t),
        jsonVariationDetail: (e, t) => a.jsonVariationDetail(e, t),
        track: (e, t, n) => a.track(e, t, n),
        on: (e, t) => a.on(e, t),
        off: (e, t) => a.off(e, t),
        flush: () => a.flush(),
        setStreaming: (e) => a.setStreaming(e),
        identify: (e, t) => a.identifyResult(e, t),
        getContext: () => a.getContext(),
        close: () => a.close(),
        allFlags: () => a.allFlags(),
        addHook: (e) => a.addHook(e),
        waitForInitialization: (e) => a.waitForInitialization(e),
        logger: a.logger,
        start: (e) => a.start(e)
    };
    return a.registerPlugins(o), o;
}

function Mm(e, t, n) {
    return jm(e, t, Au.Disabled, n);
}
//#endregion
//#region src/feature-flags.ts
var Nm = "643ee9d1c151bc13169830e6",
    Pm = B("feature-flags"),
    Fm = 5,
    Im = null,
    Lm = 0;
async function Rm(e, t, n) {
    if (Im) return;
    let r = Mm(Nm, {
            kind: "client_handle",
            key: e
        }, {
            streaming: !1
        }),
        i = ++Lm;
    Im = r, r.start();
    let a = await r.waitForInitialization({
        timeout: Fm
    });
    if (Im !== r || i !== Lm) {
        await r.close();
        return;
    }
    if (a.status !== "complete") {
        Pm.warn("LaunchDarkly initialization did not complete:", a.status), Im = null, await r.close();
        return;
    }
    Pm.info("LaunchDarkly initialized"), t(r.allFlags()), r.on("change", (e) => {
        if (!(Im !== r || i !== Lm))
            for (let [t, r] of Object.entries(e)) n(t, r.current);
    });
}
async function zm() {
    Lm += 1;
    let e = Im;
    Im = null, e && await e.close();
}
//#endregion
//#region src/orchestrator-session-settings-runtime.ts
var Bm = /* @__PURE__ */ new WeakMap(),
    Vm = /* @__PURE__ */ new WeakMap(),
    Hm = /* @__PURE__ */ new WeakMap();

function Um(e, t) {
    let n = {
        chatterToken: e.getState().session.chatterToken,
        signal: t
    };
    return Hm.set(e, n), () => {
        Hm.get(e) === n && Hm.delete(e);
    };
}

function Wm(e) {
    let t = e ? .status;
    if (typeof t != "number") return {
        reason: "unknown"
    };
    let n = e.data;
    if (t === 0) {
        if (typeof n == "string") {
            if (n.startsWith("Request timed out after")) return {
                reason: "timeout"
            };
            if (n === "Request aborted because a caller or the lifecycle cancelled it.") return {
                reason: "aborted"
            };
            if (n === "Request cancelled because the active session changed before it could be sent.") return {
                reason: "session_changed"
            };
        }
        return {
            reason: "network"
        };
    }
    return t === 401 && n === "Session expired. Please refresh the page." ? {
        reason: "session_expired"
    } : {
        reason: "http",
        status: t
    };
}

function Gm(e) {
    return {
        tags: e.status === void 0 ? {
            reason: e.reason
        } : {
            reason: e.reason,
            status: e.status
        },
        fingerprint: ["{{ default }}", e.reason]
    };
}

function Km(e) {
    let t = {};
    for (let [n, r] of Object.entries(e)) n && (typeof r == "string" || typeof r == "number" || typeof r == "boolean" || r === null) && (t[n] = r);
    return t;
}
async function qm(e, {
    metaFields: t,
    sensitiveMetaFields: n
}, r = {}) {
    let {
        endpoint: i,
        chatterToken: a,
        _chatterAnnouncementSuppressed: o
    } = e.store.getState().session, s = e.getLifecycleSignal ? .(), c = Hm.get(e.store), l = r.allowSuppressedChatter || c ? .chatterToken === a && c ? .signal === s;
    if (!i || !a || o && !l || s ? .aborted || (!t || Object.keys(t).length === 0) && (!n || Object.keys(n).length === 0)) return;
    let u = !!t && Object.keys(t ? ? {}).length > 0,
        d = !!n && Object.keys(n ? ? {}).length > 0,
        f = r.bypassQueue ? void 0 : Vm.get(e.store);
    !r.bypassQueue && !f && (f = /* @__PURE__ */ new Map(), Vm.set(e.store, f));
    let p = f ? .get(a),
        m, h = new Promise((e) => {
            m = e;
        });
    f ? .set(a, h);
    try {
        if (p && await p, s ? .aborted || e.store.getState().session.chatterToken !== a) return;
        let o;
        try {
            let r = await e.store.dispatch(G.endpoints.updateChatterDataStorage.initiate({
                endpoint: i,
                metaFields: t,
                sensitiveMetaFields: n
            }));
            if (s ? .aborted) return;
            if ("error" in r) {
                let e = Wm(r.error);
                o = {
                    error: Error(`Failed to update chatter data storage (${e.reason})`, {
                        cause: r.error
                    }),
                    detail: e
                };
            }
        } catch (e) {
            if (s ? .aborted) return;
            o = {
                error: e,
                detail: Wm(e)
            };
        }
        if (o !== void 0 && (e.onCaptureException(o.error, {
                endpoint: i,
                hasMetaFields: u,
                hasSensitiveMetaFields: d
            }, Gm(o.detail)), r.throwOnError)) throw o.error;
    } finally {
        m(), f ? .get(a) === h && f.delete(a);
    }
}
async function Jm(e, t) {
    let {
        endpoint: n,
        chatterToken: r,
        _chatterAnnouncementSuppressed: i
    } = e.store.getState().session, a = e.getLifecycleSignal ? .();
    if (e.store.dispatch(Jn(t)), !(!n || !r || i)) try {
        let i = await e.store.dispatch(G.endpoints.updateChatterSettings.initiate({
            endpoint: n,
            chatterToken: r,
            playAlertChime: t
        }));
        if (a ? .aborted) return;
        if ("data" in i && i.data && typeof i.data.playAlertChime == "boolean") {
            e.store.dispatch(Jn(i.data.playAlertChime));
            return;
        }
        if ("error" in i) {
            let t = Wm(i.error);
            e.onCaptureException( /* @__PURE__ */ Error(`Failed to persist alert sound setting (${t.reason})`), {
                endpoint: n
            }, Gm(t));
        }
    } catch (t) {
        if (a ? .aborted) return;
        e.onCaptureException(t, {
            endpoint: n
        }, Gm(Wm(t)));
    }
}
async function Ym(e, t) {
    let n = e.store.getState(),
        {
            endpoint: r,
            chatterToken: i,
            _chatterAnnouncementSuppressed: a
        } = n.session,
        o = n.session.deviceNotificationsEnabled,
        s = e.getLifecycleSignal ? .();
    if (e.store.dispatch(ca(t)), !(!r || !i || a)) try {
        let n = await e.store.dispatch(G.endpoints.updateChatterSettings.initiate({
            endpoint: r,
            chatterToken: i,
            deviceNotificationsEnabled: t
        }));
        if (s ? .aborted) return;
        if ("data" in n && n.data && typeof n.data.deviceNotificationsEnabled == "boolean") {
            e.store.dispatch(ca(n.data.deviceNotificationsEnabled));
            return;
        }
        if ("error" in n) {
            e.store.dispatch(ca(o));
            let t = Wm(n.error);
            e.onCaptureException( /* @__PURE__ */ Error(`Failed to toggle device notifications (${t.reason})`), {
                endpoint: r
            }, Gm(t));
        }
    } catch (t) {
        if (s ? .aborted) return;
        e.store.dispatch(ca(o)), e.onCaptureException(t, {
            endpoint: r
        }, Gm(Wm(t)));
    }
}
async function Xm(e, t) {
    let n = e.store.getState(),
        {
            endpoint: r,
            chatterToken: i,
            _chatterAnnouncementSuppressed: a
        } = n.session,
        o = n.session.smsNotificationsEnabled,
        s = e.getLifecycleSignal ? .();
    if (e.store.dispatch(N(t)), !(!r || !i || a)) try {
        let n = await e.store.dispatch(G.endpoints.updateChatterSettings.initiate({
            endpoint: r,
            chatterToken: i,
            smsNotificationsEnabled: t
        }));
        if (s ? .aborted) return;
        if ("data" in n && n.data && typeof n.data.smsNotificationsEnabled == "boolean") {
            e.store.dispatch(N(n.data.smsNotificationsEnabled));
            return;
        }
        if ("error" in n) {
            e.store.dispatch(N(o));
            let t = Wm(n.error);
            e.onCaptureException( /* @__PURE__ */ Error(`Failed to toggle SMS notifications (${t.reason})`), {
                endpoint: r
            }, Gm(t));
        }
    } catch (t) {
        if (s ? .aborted) return;
        e.store.dispatch(N(o)), e.onCaptureException(t, {
            endpoint: r
        }, Gm(Wm(t)));
    }
}
async function Zm(e, t) {
    let n = e.getLifecycleSignal ? .();
    e.store.dispatch(ma(t)), await e.onLoadTranslations(t, n);
}
async function Qm(e, t, n = {}) {
    let r = e.store.getState(),
        {
            clientDefaultLanguage: i,
            translatedLanguages: a
        } = r.session,
        o = $a(t, [i, ...a]) ? ? t,
        s = r.session.language,
        c = e.getLifecycleSignal ? .(),
        l = (Bm.get(e.store) ? ? 0) + 1;
    if (Bm.set(e.store, l), e.store.dispatch(ma(o)), await e.onLoadTranslations(o, c), c ? .aborted) return;
    let {
        endpoint: u,
        chatterToken: d,
        _chatterAnnouncementSuppressed: f
    } = e.store.getState().session;
    if (!u || !d || f) return;
    let p = async () => {
            s !== o && Bm.get(e.store) === l && (e.store.dispatch(ma(s)), await e.onLoadTranslations(s, c));
        },
        m;
    try {
        let t = await e.store.dispatch(G.endpoints.updateChatterSettings.initiate({
            endpoint: u,
            chatterToken: d,
            language: o
        }));
        if (c ? .aborted) return;
        if ("error" in t) {
            let e = Wm(t.error);
            m = {
                error: /* @__PURE__ */ Error(`Failed to change language (${e.reason})`),
                detail: e
            };
        }
    } catch (e) {
        m = {
            error: e,
            detail: Wm(e)
        };
    }
    if (m !== void 0) {
        if (c ? .aborted) return;
        if (await p(), e.onCaptureException(m.error, {
                endpoint: u,
                language: o
            }, Gm(m.detail)), n.throwOnError) throw m.error;
    }
}
async function $m(e, t, n = {}) {
    let r = Km(t);
    Object.keys(r).length !== 0 && (e.store.dispatch(Lr(r)), await qm(e, {
        metaFields: r
    }, n));
}
async function eh(e, t, n = {}) {
    let r = Km(t);
    Object.keys(r).length !== 0 && (e.store.dispatch(Vo(r)), await qm(e, {
        sensitiveMetaFields: r
    }, n));
}

function th(e, t) {
    e.store.dispatch(ds(t));
    let {
        handle: n
    } = e.store.getState().session;
    n && Io() ? .set(Re(n), t);
}

function nh(e, t) {
    e.store.dispatch(on(t));
    let {
        handle: n
    } = e.store.getState().session;
    n && Io() ? .set(me(n), t);
}
async function rh(e, t, r) {
    let i = t.trim();
    if (!i) return;
    let a = r === void 0 ? n(e.store.getState().session.metaFields) : r;
    e.store.dispatch(To({
        token: i,
        deviceOs: a ? ? null
    })), await eh(e, {
        device_token: i,
        device_os: a ? ? null
    });
}
var ih = class {
        constructor(e) {
            L(this, "ctx", void 0), L(this, "pendingSdkOwnedMetaFields", null), L(this, "sdkOwnedMetaFieldsSync", null), this.ctx = e;
        }
        async flushSdkOwnedMetaFields() {
            for (; this.pendingSdkOwnedMetaFields;) {
                let e = this.pendingSdkOwnedMetaFields;
                this.pendingSdkOwnedMetaFields = null, await qm(this.ctx, {
                    metaFields: { ...e
                    }
                });
            }
        }
        setAlertSoundEnabled(e) {
            return Jm(this.ctx, e);
        }
        setDeviceNotificationsEnabled(e) {
            return Ym(this.ctx, e);
        }
        setSmsNotificationsEnabled(e) {
            return Xm(this.ctx, e);
        }
        setLanguage(e, t) {
            return Qm(this.ctx, e, t);
        }
        applyServerLanguage(e) {
            return Zm(this.ctx, e);
        }
        syncChatterDataStorage(e, t) {
            return qm(this.ctx, e, t);
        }
        setMetaFields(e, t) {
            return $m(this.ctx, e, t);
        }
        setSdkOwnedMetaFields(e) {
            let t = this.ctx.store.getState().session.metaFields,
                n = {};
            if (typeof e.initialURL == "string" && e.initialURL && e.initialURL !== t.initialURL && (n.initialURL = e.initialURL), typeof e.introShown == "boolean" && e.introShown !== t.introShown && (n.introShown = e.introShown), Object.keys(n).length === 0) return this.sdkOwnedMetaFieldsSync ? ? Promise.resolve();
            if (this.ctx.store.dispatch(Lr({ ...n
                })), this.pendingSdkOwnedMetaFields = {
                    ...this.pendingSdkOwnedMetaFields,
                    ...n
                }, !this.sdkOwnedMetaFieldsSync) {
                let e = this.flushSdkOwnedMetaFields();
                this.sdkOwnedMetaFieldsSync = e;
                let t = () => {
                    this.sdkOwnedMetaFieldsSync === e && (this.sdkOwnedMetaFieldsSync = null);
                };
                e.then(t, t);
            }
            return this.sdkOwnedMetaFieldsSync ? ? Promise.resolve();
        }
        setSensitiveMetaFields(e, t) {
            return eh(this.ctx, e, t);
        }
        setDeviceToken(e, t) {
            return rh(this.ctx, e, t);
        }
        setUserTheme(e) {
            th(this.ctx, e);
        }
        setUserTextSize(e) {
            nh(this.ctx, e);
        }
    },
    ah = B("custom-js"),
    oh = (e) => typeof e == "object" && e && !Array.isArray(e) ? e : null,
    sh = (e) => {
        let t = oh(e.event_data) ? .event_name;
        return typeof t == "string" ? t : null;
    },
    ch = (e, t) => {
        let n = oh(e.event_data) ? ? {};
        return {
            ...e,
            event_data: {
                ...n,
                ...t === null ? {} : {
                    event_name: t
                }
            }
        };
    },
    lh = async (e, t, n) => {
        let r = e.getState().session;
        if (r._chatterAnnouncementSuppressed) return;
        let i = r.endpoint,
            a = r.chatterToken;
        if (!i) {
            e.dispatch(En(t));
            return;
        }
        let o = null;
        try {
            let n = await e.dispatch(G.endpoints.getJsEventData.initiate({
                endpoint: i
            }, {
                forceRefetch: !0,
                subscribe: !1
            }));
            n.data && (o = ch(n.data, sh(t)));
        } catch (e) {
            ah.warn("custom JavaScript event enrichment failed:", e);
        }
        let s = e.getState().session;
        n ? .aborted || s._chatterAnnouncementSuppressed || s.chatterToken !== a || e.dispatch(En(o ? ? t));
    },
    uh = B("link-preview");

function dh(e) {
    if (typeof e != "object" || !e) return {};
    let t = e;
    return {
        title: typeof t.title == "string" ? t.title : void 0,
        description: typeof t.desc == "string" ? t.desc : void 0,
        icon: typeof t.icon == "string" ? t.icon : void 0
    };
}

function fh(e, t) {
    let n = new URL(`https://previews.${e}/`);
    return n.searchParams.set("url", t), n.toString();
}

function ph(e, t) {
    if (!t.generateLinkPreview || t.title ? .trim() && t.linkDescription ? .trim()) return;
    let n = e.store.getState().session.cluster,
        r = fh(n && n !== "localhost" ? n : "ada.support", t.url),
        i = e.fetchFn ? ? fetch;
    (async () => {
        try {
            let n = await i(r);
            if (!n.ok) {
                uh.warn("Link preview fetch failed", t.id, n.status);
                return;
            }
            let a = dh(await n.json());
            if (!a.title && !a.description && !a.icon) return;
            e.store.dispatch(qn({
                messageId: t.id,
                ...a.title ? {
                    title: a.title
                } : {},
                ...a.description ? {
                    linkDescription: a.description
                } : {},
                ...a.icon ? {
                    linkIcon: a.icon
                } : {}
            }));
        } catch (e) {
            uh.warn("Link preview fetch failed", t.id, e);
        }
    })();
}
//#endregion
//#region src/orchestrator-subscription-runtime.ts
var mh = B("subscription"),
    hh = 3,
    gh = 1e3,
    _h = 1e4,
    vh = "_ada_event_id";

function yh(e) {
    return e.subscriptionState.streamFallbackTimers || (e.subscriptionState.streamFallbackTimers = /* @__PURE__ */ new Map()), e.subscriptionState.streamFallbackTimers;
}

function bh(e, t) {
    let n = e.subscriptionState.streamFallbackTimers,
        r = n ? .get(t);
    r && (clearTimeout(r), n ? .delete(t));
}

function xh(e, t) {
    let n = e.onStreamFallback;
    if (!n) return;
    bh(e, t);
    let r = e.streamFinalFallbackMs ? ? _h,
        i = setTimeout(() => {
            yh(e).delete(t), n(t).catch(() => {
                e.store.dispatch(yr({
                    streamId: t
                }));
            });
        }, r);
    yh(e).set(t, i);
}

function Sh(e) {
    return e.subscriptionState.confirmedChannels || (e.subscriptionState.confirmedChannels = /* @__PURE__ */ new Set()), e.subscriptionState.confirmedChannels;
}

function Ch(e, t) {
    if (!e.awaitsSubscriptionConfirmation || e.subscriptionState.subscriptionTransportStatusCleanup || !e.transport.onStatusChange || !e.transport.offStatusChange) return;
    let n = e.transport;
    e.subscriptionState.subscriptionTransportWasConnected = n.status === "connected";
    let r = (n) => {
        if (n === "connected") {
            e.subscriptionState.subscriptionTransportWasConnected = !0;
            return;
        }
        n !== "connecting" && n !== "disconnected" || !e.subscriptionState.subscriptionTransportWasConnected || (e.subscriptionState.subscriptionTransportWasConnected = !1, e.subscriptionState.subscriptionConfirmationReported = !1, t.clear(), e.store.dispatch(Hr()));
    };
    n.onStatusChange ? .(r), e.subscriptionState.subscriptionTransportStatusCleanup = () => {
        n.offStatusChange ? .(r);
    };
}

function wh(e) {
    return e.subscriptionState.seenWidgetMarkerIds || (e.subscriptionState.seenWidgetMarkerIds = /* @__PURE__ */ new Set()), e.subscriptionState.seenWidgetMarkerIds;
}

function Th(e) {
    return e.subscriptionState.seenForwardedEventIds || (e.subscriptionState.seenForwardedEventIds = /* @__PURE__ */ new Set()), e.subscriptionState.seenForwardedEventIds;
}

function Eh(e) {
    let t = F(e);
    if (!t || Array.isArray(t) || !("_ada_event_id" in t)) return {
        id: null,
        payload: e
    };
    let {
        [vh]: n, ...r
    } = t;
    return {
        id: typeof n == "string" && n.length > 0 ? n : null,
        payload: r
    };
}

function Z(e, t, n, r) {
    t.bind(n, (i) => {
        let {
            id: a,
            payload: o
        } = Eh(i);
        if (a === null) {
            r(o);
            return;
        }
        let s = Th(e),
            c = `${t.name}:${a}`;
        if (s.has(c)) {
            R("forwarded_event_duplicate_dropped", {
                event: n
            });
            return;
        }
        if (s.add(c), s.size > 64) {
            let e = s.values().next().value;
            e !== void 0 && s.delete(e);
        }
        r(o);
    });
}

function Dh(e, t, n) {
    e.store.dispatch(Si());
    let r = e.store.getState().session.conversationId,
        i = 0,
        a = !1;
    for (let o of t.messages) {
        let t = e.toBotMessage(o);
        if (!t) continue;
        r && t.conversationId == null && (t.conversationId = r);
        let s = uo(o);
        s && e.store.dispatch(sa([s]));
        let c = Ma(o);
        if (c && e.store.dispatch(fn([c])), n && (t.streamId ? bh(e, t.streamId) : bh(e, t.id)), t.type === "presence" && (e.onProcessLiveAgentPresence(o), c || (o.event === "unified_reasoner_generation_started" ? e.store.dispatch(Bo()) : o.event === "unified_reasoner_generation_finished" && e.store.dispatch(ee())), !s && !Ki(o.event) && e.store.dispatch(wo(o.event === "playbook_step_executing")), Dt(o.event))) {
            a = !0;
            continue;
        }
        i += 1, e.store.dispatch(_o(t, {
            isFinal: n
        })), t.type === "link" && ph({
            store: e.store
        }, t), R("bot_message_displayed", {
            messageId: o.id,
            messageType: t.type
        });
    }
    n && i === 0 && !a && e.store.dispatch(ns());
}

function Oh(e, t) {
    if (!t) return !0;
    let {
        conversationId: n,
        clearedConversationId: r
    } = e.store.getState().session;
    return n ? n === t ? (gi(e.store, t), !0) : Me(t, n) ? (R("conversation_adopted", {
        reason: "newer_conversation_event"
    }), e.onConversationSuperseded ? .(), e.store.dispatch(lo(t)), !0) : (R("stale_conversation_event_dropped", {
        reason: Tn(t, n) ? "older_conversation_event" : "unordered_conversation_id"
    }), !1) : Nn(t, r) ? (R("stale_conversation_event_dropped", {
        reason: t === r ? "cleared_conversation_event" : "behind_cleared_conversation"
    }), !1) : (e.store.dispatch(lo(t)), !0);
}

function kh(e, t) {
    if (t.messages.length > 0 && t.messages.every((e) => e.type === "csat" && e.source === "user")) {
        let {
            conversationId: n,
            clearedConversationId: r
        } = e.store.getState().session;
        if (n && t.conversationId !== n || !n && r) {
            R("stale_conversation_event_dropped", {
                reason: "survey_answer_outside_current_conversation"
            });
            return;
        }!n && t.conversationId && e.store.dispatch(lo(t.conversationId));
    } else if (!Oh(e, t.conversationId)) return;
    let n = /* @__PURE__ */ new Map(),
        r = {
            ...e,
            toBotMessage: (t) => {
                let r = n.get(t);
                if (r !== void 0) return r;
                let i = e.toBotMessage(t);
                return n.set(t, i), i;
            }
        },
        i = [],
        a = !1,
        o = null,
        s = t.messages.filter((t) => {
            if (t.type === "incoming_app_data") {
                let n = wh(e);
                if (t.id) {
                    if (n.has(t.id)) return R("widget_marker_duplicate_dropped", {
                        messageId: t.id
                    }), !1;
                    if (n.add(t.id), n.size > 64) {
                        let e = n.values().next().value;
                        e !== void 0 && n.delete(e);
                    }
                }
                return o ? (i.push(o), o = null) : t.id && (a = !0), !1;
            }
            let n = r.toBotMessage(t);
            return n && bt(n) && (o = n.id), !0;
        });
    if (a && e.store.dispatch(ie()), s.length > 0 && s.every((e) => e.source === "user")) {
        let n = [],
            i = e.store.getState().session.conversationId;
        for (let t of s) {
            if (t.type === "presence") {
                n.push(t);
                continue;
            }
            let a = r.toBotMessage(t);
            a && !(a.type === "presence" && Dt(a.event)) && e.store.dispatch(de(i ? {
                ...a,
                conversationId: i
            } : a));
        }
        n.length > 0 && Dh(r, {
            ...t,
            messages: n
        }, t.isFinal !== !1);
    } else Dh(r, {
        ...t,
        messages: s
    }, t.isFinal !== !1);
    i.length > 0 && e.store.dispatch(ie({
        ids: i
    })), typeof t.cursor == "string" && t.cursor.length > 0 && e.onCommitMessageCursor ? .(t.cursor);
}

function Ah(e, t) {
    let n = la(t);
    if (n && Oh(e, n.conversationId)) {
        if (n.status === "aborted") {
            bh(e, n.streamId), e.store.dispatch(Te());
            let t = e.onStreamFallback ? .(n.streamId);
            t ? t.catch(() => {}).finally(() => {
                e.store.dispatch(yr({
                    streamId: n.streamId
                }));
            }) : e.store.dispatch(yr({
                streamId: n.streamId
            }));
            return;
        }
        e.store.dispatch(Mo({
            streamId: n.streamId,
            text: n.text
        })), n.status === "final" && e.store.dispatch(Te()), xh(e, n.streamId);
    }
}

function jh(e) {
    let {
        chatterToken: t
    } = e.store.getState().session;
    if (!t) {
        mh.error("subscribeToChannelRuntime called before chatterToken was set");
        return;
    }
    let n = e.transport.subscribe("control");
    e.subscriptionState.controlChannel = n;
    let r = e.transport.subscribe(t);
    e.subscriptionState.mainChannel = r;
    let i = e.transport.subscribe(`private-encrypted-${t}`);
    e.subscriptionState.encryptedChannel = i;
    let a = [t, `private-encrypted-${t}`],
        o = Sh(e);
    Ch(e, o);
    let s = !1,
        c = () => {
            (e.awaitsSubscriptionConfirmation ? e.subscriptionState.subscriptionConfirmationReported : s) || !a.every((e) => o.has(e)) || (e.awaitsSubscriptionConfirmation ? e.subscriptionState.subscriptionConfirmationReported = !0 : s = !0, e.onSubscriptionConfirmed ? .(), e.store.dispatch(oo()), e.awaitsSubscriptionConfirmation && e.onBaselineResync ? .());
        },
        l = (t, n) => {
            t.bind("pusher:subscription_succeeded", () => {
                o.add(t.name), R("transport_subscription_succeeded", {
                    channel: n
                }), c();
            }), t.bind("pusher:subscription_error", () => {
                o.delete(t.name), e.subscriptionState.subscriptionConfirmationReported = !1, e.store.dispatch(Hr()), R("transport_subscription_error", {
                    channel: n
                }), e.onRetrySubscription();
            });
        };
    if (n.bind("refresh-requested", () => {
            e.onControlChannelRefreshRequested();
        }), Z(e, r, "oauth-success", (t) => {
            e.onHandleAuthSucceeded(t);
        }), Z(e, r, "request_secret_message", (t) => {
            e.onHandleSecretMessageRequested(t);
        }), Z(e, r, "secret_message_received_by_agent", (t) => {
            e.onHandleSecretMessageReceivedByAgent(t);
        }), Z(e, r, "message_state", (t) => {
            e.onHandleMessageStateChanged(t);
        }), Z(e, r, "notification", (t) => {
            e.onHandleNotification(t);
        }), Z(e, r, "language", (t) => {
            e.onHandleLanguageChanged(t);
        }), Z(e, r, "typing_indicator", (t) => {
            e.onHandleBotTypingIndicator(t);
        }), Z(e, r, "live_agent_typing_indicator", (t) => {
            e.onHandleLiveAgentTypingIndicator(t);
        }), Z(e, r, "conversation_state_changed", (t) => {
            e.onHandleConversationStateChanged(t);
        }), Z(e, r, "ada_glass_env_update", (t) => {
            e.onHandleAdaGlassEnvUpdate(t);
        }), Z(e, r, "agent_file_transfer", (t) => {
            e.onHandleAgentFileTransfer(t);
        }), Z(e, r, "request_retry_handoff", () => {
            e.store.dispatch(Yr()), R("live_handoff_retry_requested");
        }), Z(e, r, "zendesk_live_agent_init_conversation", (t) => {
            e.onHandleZendeskInitConversation(t);
        }), Z(e, r, "zendesk_chatter_typing_indicator", (t) => {
            e.onHandleZendeskChatterTypingIndicator(t);
        }), Z(e, r, "zendesk_cancel_live_chat_request", (t) => {
            e.onHandleZendeskCancelChat(t);
        }), Z(e, r, "zendesk_chatter_ended_chat", (t) => {
            e.onHandleZendeskEndChat(t);
        }), Z(e, r, "zendesk_live_agent_last_processed_update", (t) => {
            e.onHandleZendeskLastProcessedUpdate(t);
        }), Z(e, r, "custom-javascript-event", (t) => {
            let n = F(t);
            if (!n) {
                mh.warn("Ignoring malformed custom-javascript-event payload");
                return;
            }
            lh(e.store, n, e.getLifecycleSignal ? .());
        }), r.bind("ready", () => {
            e.onBaselineResync ? .();
        }), r.bind("resync", () => {
            e.onIncrementalResync ? .();
        }), r.bind("token_expired", () => {
            e.store.dispatch(Hr()), R("transport_token_expired"), e.onTokenExpired();
        }), l(r, "main"), i.bind("message-delta", (t) => {
            Ah(e, t);
        }), i.bind("message-added", (t) => {
            let n = e.extractBotMessages(t);
            n && kh(e, n);
        }), l(i, "encrypted"), e.onSubscriptionEstablished(), !e.awaitsSubscriptionConfirmation)
        for (let e of a) o.add(e);
    c();
}

function Mh(e) {
    Nh(e), e.subscriptionState.encryptedChannel && (e.subscriptionState.encryptedChannel.unbindAll(), e.subscriptionState.encryptedChannel = null), e.subscriptionState.mainChannel && (e.subscriptionState.mainChannel.unbindAll(), e.subscriptionState.mainChannel = null), e.subscriptionState.controlChannel && (e.subscriptionState.controlChannel.unbindAll(), e.subscriptionState.controlChannel = null);
}

function Nh(e) {
    for (let t of e.subscriptionState.streamFallbackTimers ? .values() ? ? []) clearTimeout(t);
    e.subscriptionState.streamFallbackTimers ? .clear();
}

function Ph(e) {
    let t = e.maxSubscriptionRetries ? ? hh,
        n = e.subscriptionRetryBaseMs ? ? gh;
    if (e.subscriptionState.retryCount >= t) {
        e.onLogError(`Channel subscription failed after ${t} retries`), e.onCaptureException( /* @__PURE__ */ Error("Channel subscription failed after max retries"));
        return;
    }
    if (e.subscriptionState.retryTimer) return;
    let r = e.subscriptionState.retryCount + 1;
    e.subscriptionState.retryCount = r;
    let i = n * 2 ** (r - 1);
    e.onLogWarning(`Retrying channel subscription (attempt ${r}/${t}) in ${i}ms`);
    let a = setTimeout(() => {
        try {
            Mh(e), e.onResubscribe();
        } catch (t) {
            e.onLogWarning(`Subscription retry failed: ${t instanceof Error ? t.message : String(t)}`);
        } finally {
            e.subscriptionState.retryTimer = null;
        }
    }, i);
    e.subscriptionState.retryTimer = a;
}
//#endregion
//#region src/persistence/session-mirror.ts
var Fh = B("session-mirror"),
    Ih = 4500,
    Lh = "core.session.mirror",
    Rh = "core.session.mirrorClear",
    zh = "core.session.mirrorRequest";

function Bh(e, t) {
    try {
        if (typeof e != "object" || !e || Array.isArray(e)) return null;
        let n = e;
        if (n.version !== 1 || typeof n.scopeKey != "string" || !n.scopeKey) return null;
        let r = n.generation;
        if (typeof r != "number" || !Number.isInteger(r) || r < 1) return null;
        let i = n.entries;
        if (typeof i != "object" || !i || Array.isArray(i)) return null;
        let a = {};
        for (let [e, n] of Object.entries(i))
            if (t.has(e)) {
                if (typeof n != "string") return null;
                a[e] = n;
            }
        let o = ht(n.scopeKey);
        return Object.keys(a).some((e) => e !== o) ? {
            version: 1,
            scopeKey: n.scopeKey,
            generation: r,
            writtenAt: typeof n.writtenAt == "number" && Number.isFinite(n.writtenAt) ? n.writtenAt : 0,
            entries: a
        } : null;
    } catch {
        return null;
    }
}

function Vh(e) {
    if (!e) return null;
    let t = Number(e);
    return Number.isInteger(t) && t >= 1 ? t : null;
}

function Hh(e) {
    try {
        if (typeof crypto < "u" && crypto.randomUUID) return `${e}-${crypto.randomUUID()}`;
    } catch {}
    return `${e}-${Date.now()}-${Math.floor(Math.random() * 1e9)}`;
}

function Uh(e) {
    let {
        storage: t,
        scopeKey: n,
        allowedKeys: r,
        primarySessionKey: i,
        mode: a,
        emitFrameEvent: o
    } = e, s = e.now ? ? (() => Date.now()), c = e.debounceMs ? ? 1e3, l = e.ackTimeoutMs ? ? 8e3, u = e.seedRequestTimeoutMs ? ? Ih, d = e.maxSerializedEntries ? ? 131072, f = e.maxUnconfirmedReadRetries ? ? 5, p = ht(n), m = !1, h = e.writesArmed !== !1, g = !1, _ = !1, v = !1, y = !1, b = 0, x = !1, S = !1, C = !1, w = !1, T = !1, E = 0, D = null, O = 0, ee = 0, k = /* @__PURE__ */ new Map(), A = /* @__PURE__ */ new Map();
    async function j(e) {
        try {
            if (t.getConfirmed) {
                let n = await t.getConfirmed(e);
                return n.confirmed ? n.values : null;
            }
            return Object.fromEntries(e.map((e) => [e, t.get(e)]));
        } catch {
            return null;
        }
    }
    async function te() {
        if (!(m || a !== "normal" || !h)) {
            if (S) {
                C = !0;
                return;
            }
            S = !0;
            try {
                let i = [...r],
                    a = await j(i);
                if (m) return;
                if (!a) {
                    if (E >= f) {
                        Fh.warn("Session mirror emit stopped re-arming after repeated unconfirmed reads; the next persisted write resumes it");
                        return;
                    }
                    E += 1, T = !0;
                    return;
                }
                E = 0;
                let c = Vh(a[p] ? ? null),
                    l = Math.max((c ? ? 0) + 1, O),
                    u = {};
                for (let e of i) {
                    let t = a[e];
                    typeof t == "string" && e !== p && (u[e] = t);
                }
                u[p] = String(l);
                let h = 0;
                try {
                    h = JSON.stringify(u).length;
                } catch {
                    return;
                }
                if (h > d) {
                    Fh.warn("Session mirror write dropped: snapshot exceeds the size guard"), e.onEmitDropped ? .("oversize");
                    return;
                }
                t.set(p, String(l));
                let g = await (t.flush ? .([p]) ? ? Promise.resolve(!0));
                if (m || g === !1) return;
                O = l >= O ? 0 : O, o(Lh, {
                    version: 1,
                    scopeKey: n,
                    generation: l,
                    writtenAt: s(),
                    entries: u
                }), b += 1;
            } finally {
                S = !1, m || (w ? (w = !1, C = !1, T = !1, te()) : C ? (C = !1, T = !1, M()) : T && (T = !1, ne()));
            }
        }
    }

    function ne() {
        if (!(m || a !== "normal")) {
            if (!h) {
                Qn(n), v || (v = !0, e.onEmitDropped ? .("writes-unarmed"));
                return;
            }
            if (!x) {
                if (!y) {
                    y = !0, te();
                    return;
                }
                x = !0, D = setTimeout(() => {
                    x = !1, D = null, te();
                }, c);
            }
        }
    }

    function M() {
        E = 0, ne();
    }

    function re() {
        m || h || _ || (h = !0, Va(n) && M());
    }

    function ie() {
        if (m || a !== "normal" || !h) return;
        let e = D !== null;
        if (D !== null && (clearTimeout(D), D = null, x = !1), S) {
            w = !0;
            return;
        }
        e && te();
    }

    function N() {
        try {
            return t.get(p);
        } catch {
            return null;
        }
    }

    function ae(e) {
        let r = Hh("mirror-clear"),
            i = new Promise((e) => {
                let t = setTimeout(() => {
                    k.delete(r), Fh.warn("Session mirror clear was not acknowledged within the ack timeout; keeping the generation stamp"), e(!1);
                }, l);
                k.set(r, {
                    resolve: e,
                    timer: t
                });
            });
        return o(Rh, {
            version: 1,
            scopeKey: n,
            requestId: r
        }), i.then((n) => {
            if (n) try {
                t.get(p) === e && t.remove(p);
            } catch {}
            return n;
        });
    }
    async function oe(e, t) {
        return m ? !1 : t < 1 ? (Fh.warn("Session mirror clear was never acknowledged; a surviving native blob can still be adopted by a later normal-mode mount"), !1) : await ae(e) ? !0 : oe(e, t - 1);
    }

    function se(e) {
        if (m || a !== "normal" || b === e) return;
        let t = !y;
        M(), t || ie();
    }

    function ce() {
        if (m) return Promise.resolve(!1);
        let e = b;
        return oe(N(), 3).then((t) => (se(e), t));
    }

    function le(e = {}) {
        if (m) return Promise.resolve(!1);
        let t = ae(N());
        return e.awaitAck ? t : Promise.resolve(!0);
    }

    function ue() {
        if (m) return Promise.reject( /* @__PURE__ */ Error("Session mirror runtime destroyed before the seed request"));
        let e = Hh("mirror-seed"),
            t = new Promise((t, n) => {
                let r = setTimeout(() => {
                    A.delete(e), g = !0, Fh.warn("Session mirror seed request was not answered within the timeout; proceeding with no seed"), t(void 0);
                }, u);
                A.set(e, {
                    resolve: t,
                    reject: n,
                    timer: r
                });
            });
        return o(zh, {
            version: 1,
            scopeKey: n,
            requestId: e
        }), t;
    }
    async function de(o, s = {}) {
        if (m) return null;
        if (a !== "normal") return ce(), {
            outcome: "mode-cleared",
            seededMirror: !1
        };
        if (s.identityTokenPresent) return ee = Bh(o, r) ? .generation ? ? 0, Va(n), {
            outcome: "identity-preempted",
            seededMirror: !1
        };
        if (g) return _ = !0, h = !1, {
            outcome: "seed-timeout",
            seededMirror: !1
        };
        if (o == null) return {
            outcome: "empty",
            seededMirror: !1
        };
        let c = Bh(o, r);
        if (!c) return {
            outcome: "corrupt-blob",
            seededMirror: !1
        };
        if (c.scopeKey !== n) return {
            outcome: "scope-mismatch",
            seededMirror: !1
        };
        let l = [...r],
            u = Object.fromEntries(l.map((e) => [e, t.get(e)])),
            d = await j(l);
        if (m) return null;
        if (!d) return {
            outcome: "kept-local",
            seededMirror: !1
        };
        let f = Vh(d[p] ? ? null),
            v = typeof d[i] == "string" && d[i] !== "",
            y, b = !1;
        if (f === null ? v ? (y = !1, O = Math.max(O, c.generation + 1), b = !0) : y = !0 : y = c.generation > f, !y) return b && M(), {
            outcome: "kept-local",
            seededMirror: b
        };
        let x = {};
        for (let e of l) {
            if (e === p) continue;
            let t = c.entries[e];
            x[e] = typeof t == "string" ? t : null;
        }
        x[p] = String(c.generation);
        let S = !1,
            C = null;
        try {
            if (!await e.writeSharedSnapshot(x, u)) return {
                outcome: "kept-local",
                seededMirror: !1
            };
            let n = await (t.flush ? .(l) ? ? Promise.resolve(!0));
            if (!m) {
                let e = await j(l);
                C = e, S = n === !0 && e !== null && l.every((t) => (e[t] ? ? null) === x[t]);
            }
        } catch {
            S = !1;
        }
        if (m) return null;
        if (S) return {
            outcome: "adopted-native",
            seededMirror: !1
        };
        let w = !1;
        try {
            C ? ? = await j(l);
            let n = C;
            if (n && l.every((e) => n[e] === (d[e] ? ? null) || n[e] === x[e])) {
                let r = Object.fromEntries(l.map((e) => [e, d[e] ? ? null]));
                if (await e.writeSharedSnapshot(r, n, {
                        restorePartialAdoption: !0
                    })) {
                    let e = await (t.flush ? .(l) ? ? Promise.resolve(!0)),
                        n = await j(l);
                    w = e === !0 && n !== null && l.every((e) => n[e] === r[e]);
                }
            }
        } catch {
            w = !1;
        }
        return O = Math.max(O, c.generation + 1), Fh.warn(w ? "Session mirror adoption could not be confirmed; rolled back to the pre-adoption state" : "Session mirror adoption could not be confirmed; rollback could not be confirmed"), {
            outcome: "adoption-failed",
            seededMirror: !1
        };
    }
    return {
        scopeKey: n,
        adoptSeed: de,
        scheduleEmit: M,
        armWrites: re,
        flush: ie,
        clearMirror: le,
        clearMirrorDurably: ce,
        requestSeed: ue,
        acknowledgeClear(e) {
            let t = k.get(e);
            t && (k.delete(e), clearTimeout(t.timer), t.resolve(!0));
        },
        deliverSeed(e, t) {
            let n = A.get(e);
            n && (A.delete(e), clearTimeout(n.timer), n.resolve(t));
        },
        noteIdentityExchangeResolved() {
            let e = Vh(t.get(p));
            O = Math.max(e ? ? 0, ee) + 1, ee = 0, ce();
        },
        noteIdentityExchangeFailed() {
            return ce();
        },
        destroy() {
            m = !0, D !== null && (clearTimeout(D), D = null), x = !1;
            for (let [e, t] of k) clearTimeout(t.timer), t.resolve(!1), k.delete(e);
            for (let [e, t] of A) clearTimeout(t.timer), t.reject( /* @__PURE__ */ Error("Session mirror runtime destroyed with a pending seed request")), A.delete(e);
        }
    };
}
//#endregion
//#region src/transport/mock-transport.ts
var Wh = class {
        constructor(e) {
            L(this, "name", void 0), L(this, "_handlers", /* @__PURE__ */ new Map()), this.name = e;
        }
        bind(e, t) {
            let n = this._handlers.get(e);
            n || (n = /* @__PURE__ */ new Set(), this._handlers.set(e, n)), n.add(t);
        }
        unbind(e, t) {
            this._handlers.get(e) ? .delete(t);
        }
        unbindAll() {
            this._handlers.clear();
        }
        emit(e, t) {
            let n = this._handlers.get(e);
            if (n)
                for (let e of n) e(t);
        }
    },
    Gh = class {
        constructor() {
            L(this, "reconnectRequestedByServer", !1), L(this, "_status", "disconnected"), L(this, "_channels", /* @__PURE__ */ new Map()), L(this, "_statusHandlers", /* @__PURE__ */ new Set());
        }
        get status() {
            return this._status;
        }
        connect(e) {
            this._setStatus("connecting"), queueMicrotask(() => {
                this._setStatus("connected");
            });
        }
        disconnect() {
            for (let e of this._channels.values()) e.unbindAll();
            this._channels.clear(), this._setStatus("disconnected");
        }
        subscribe(e) {
            let t = this._channels.get(e);
            return t || (t = new Wh(e), this._channels.set(e, t)), t;
        }
        unsubscribe(e) {
            let t = this._channels.get(e);
            t && (t.unbindAll(), this._channels.delete(e));
        }
        onStatusChange(e) {
            this._statusHandlers.add(e);
        }
        offStatusChange(e) {
            this._statusHandlers.delete(e);
        }
        getChannel(e) {
            return this._channels.get(e);
        }
        simulateStatus(e) {
            this._setStatus(e);
        }
        simulateEvent(e, t, n) {
            this._channels.get(e) ? .emit(t, n);
        }
        _setStatus(e) {
            if (e !== this._status) {
                this._status = e;
                for (let t of this._statusHandlers) t(e);
            }
        }
    },
    Kh = B("pusher-auth"),
    qh = 0,
    Jh = 1e4,
    Yh = 1e3,
    Xh = "indexed",
    Zh = [
        "http://localhost:8000",
        "https://localhost:8000",
        "http://127.0.0.1:8000",
        "https://127.0.0.1:8000"
    ],
    Qh = [...Vn].filter((e) => e !== "localhost").map((e) => `.${e}`);

function $h(e) {
    return typeof e == "function" ? e() ? ? {} : e ? ? {};
}

function eg(e) {
    let t = e;
    for (let n of Zh) {
        if (e === n) {
            t = "/";
            break;
        }
        if (e.startsWith(`${n}/`)) {
            t = e.slice(n.length);
            break;
        }
    }
    try {
        let e = new URL(t, window.location.origin);
        if (e.pathname.split("/").some((e) => e === "..")) return Kh.warn("Auth endpoint rejected: path traversal detected"), "/";
        if (!(e.hostname === window.location.hostname || e.hostname === "messaging-demo.net" || e.hostname === "localhost" || e.hostname.endsWith(".localhost") || Qh.some((t) => e.hostname.endsWith(t)))) return Kh.warn("Auth endpoint rejected: hostname not in allow-list"), "/";
    } catch {
        return "/";
    }
    return t;
}

function tg(e) {
    return typeof e != "object" || !e ? null : e;
}

function ng(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    return t.length > 0 ? t : null;
}

function rg(e) {
    let t = new AbortController(),
        n = !1,
        r = window.setTimeout(() => {
            n = !0, t.abort();
        }, e);
    return {
        signal: t.signal,
        cleanup: () => window.clearTimeout(r),
        didTimeout: () => n
    };
}

function ig(e, t, n, r) {
    let i = new URLSearchParams();
    if (i.set("socket_id", e), t.length === 1) {
        let [e] = t;
        e && i.set("channel_name", e);
    } else
        for (let [e, n] of t.entries()) {
            if (r === "indexed") {
                i.set(`channel_name[${e}]`, n);
                continue;
            }
            if (r === "plain") {
                i.append("channel_name", n);
                continue;
            }
            i.append("channel_name[]", n);
        }
    for (let [e, t] of Object.entries(n.params ? ? {})) i.set(e, t);
    return i.toString();
}

function ag(e, t) {
    let n = tg(e);
    if (!n) return {
        data: null,
        error: /* @__PURE__ */ Error("Pusher auth response payload must be an object")
    };
    let r = ng(n.auth);
    if (r) {
        let e = ng(n.shared_secret),
            t = ng(n.channel_data),
            i = {
                ...n,
                auth: r
            };
        return e ? i.shared_secret = e : delete i.shared_secret, t ? i.channel_data = t : delete i.channel_data, {
            data: i,
            error: null
        };
    }
    let i = tg(n[t]);
    if (!i) return {
        data: null,
        error: /* @__PURE__ */ Error(`Pusher auth response missing channel payload for "${t}"`)
    };
    let a = i;
    if (typeof a.status == "number" && a.status !== 200) return {
        data: null,
        error: /* @__PURE__ */ Error(`Unable to retrieve auth string from auth endpoint - received status: ${a.status}`)
    };
    let o = tg(a.data) ? ? i,
        s = ng(o ? .auth);
    if (!s) return {
        data: null,
        error: /* @__PURE__ */ Error(`Pusher auth response missing required auth token for "${t}"`)
    };
    let c = ng(o ? .shared_secret),
        l = ng(o ? .channel_data),
        u = {
            ...o,
            auth: s
        };
    return c ? u.shared_secret = c : delete u.shared_secret, l ? u.channel_data = l : delete u.channel_data, {
        data: u,
        error: null
    };
}
var og = class {
    constructor(e) {
        L(this, "socketId", void 0), L(this, "authEndpoint", void 0), L(this, "authDelayMs", void 0), L(this, "authOptions", void 0), L(this, "authTimeoutMs", void 0), L(this, "channelParamStyle", void 0), L(this, "onSessionExpired", void 0), L(this, "requestTimer", null), L(this, "callbacks", /* @__PURE__ */ new Map()), this.socketId = e.socketId, this.authEndpoint = e.authEndpoint, this.authDelayMs = e.authDelayMs, this.authOptions = e.authOptions, this.authTimeoutMs = e.authTimeoutMs, this.channelParamStyle = e.channelParamStyle, this.onSessionExpired = e.onSessionExpired;
    }
    add(e, t) {
        let n = this.callbacks.get(e);
        n || (n = /* @__PURE__ */ new Set(), this.callbacks.set(e, n)), n.add(t), this.requestTimer === null && (this.requestTimer = window.setTimeout(() => {
            this.requestTimer = null, this.flush();
        }, this.authDelayMs));
    }
    async flush() {
        if (this.callbacks.size === 0) return;
        let e = new Map(this.callbacks);
        this.callbacks.clear();
        let t = [...e.keys()],
            n = eg(this.authEndpoint),
            r = rg(this.authTimeoutMs),
            i = ig(this.socketId, t, this.authOptions, this.channelParamStyle);
        try {
            let t = await fetch(n, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    ...this.authOptions.headers ? ? {}
                },
                body: i,
                signal: r.signal
            });
            if (!t.ok) {
                if (t.status === 401) {
                    r.cleanup();
                    let e;
                    try {
                        tg(await Promise.race([t.json().catch(() => null), new Promise((t) => {
                            e = window.setTimeout(() => t(null), Yh);
                        })])) ? .message === "You're not authorized - session expired." && this.onSessionExpired ? .();
                    } finally {
                        window.clearTimeout(e);
                    }
                }
                throw Error(`Unable to retrieve auth string from auth endpoint - received status: ${t.status}`);
            }
            let a = await t.text(),
                o;
            try {
                o = JSON.parse(a);
            } catch {
                throw Error("JSON returned from auth endpoint was invalid, yet status code was 200.");
            }
            for (let [t, n] of e) {
                let {
                    data: e,
                    error: r
                } = ag(o, t);
                for (let t of n) t(r, r ? null : e);
            }
        } catch (t) {
            let n;
            n = r.didTimeout() && t instanceof Error ? /* @__PURE__ */ Error(`Unable to retrieve auth string from auth endpoint - request timed out after ${this.authTimeoutMs}ms`) : t instanceof Error ? t : /* @__PURE__ */ Error("Unable to retrieve auth string from auth endpoint");
            for (let t of e.values())
                for (let e of t) e(n, null);
        } finally {
            r.cleanup();
        }
    }
};

function sg(e = {}) {
    return cg(e);
}

function cg(e = {}) {
    let t = /* @__PURE__ */ new Map();
    return (n, r) => ({
        authorize: (i, a) => {
            for (let e of t.keys()) e.startsWith(`${i}:`) || t.delete(e);
            let o = ng(r.authEndpoint);
            if (!o) {
                a( /* @__PURE__ */ Error("Pusher auth endpoint is not configured for private channels"), null);
                return;
            }
            let s = typeof r.authDelay == "number" && r.authDelay >= 0 ? r.authDelay : qh,
                c = $h(r.auth),
                l = e.channelParamStyle ? ? Xh,
                u = `${i}:${o}:${l}:${JSON.stringify(c)}`,
                d = t.get(u);
            d || (d = new og({
                socketId: i,
                authEndpoint: o,
                authDelayMs: s,
                authOptions: c,
                authTimeoutMs: Jh,
                channelParamStyle: l,
                onSessionExpired: e.onSessionExpired
            }), t.set(u, d)), d.add(n.name, a);
        }
    });
}
//#endregion
//#region src/transport/pusher-transport.ts
var lg = B("pusher"),
    ug = class {
        constructor(e, t) {
            L(this, "name", void 0), L(this, "_pusherChannel", void 0), this.name = e, this._pusherChannel = t;
        }
        bind(e, t) {
            this._pusherChannel.bind(e, t);
        }
        unbind(e, t) {
            this._pusherChannel.unbind(e, t);
        }
        unbindAll() {
            this._pusherChannel.unbind_all();
        }
    },
    dg = class {
        constructor() {
            L(this, "reconnectRequestedByServer", !1), L(this, "_pusher", null), L(this, "_status", "disconnected"), L(this, "_channels", /* @__PURE__ */ new Map()), L(this, "_debug", !1), L(this, "_statusHandlers", /* @__PURE__ */ new Set()), L(this, "_connectionHandlers", []);
        }
        get status() {
            return this._status;
        }
        async connect(t) {
            this._pusher && this._teardown({
                silent: !0
            }), this._setStatus("connecting"), this._debug = t.debug ? ? !1;
            try {
                let [n, r] = await Promise.all([
                    import ("./with-encryption-XPxvTnNo.js").then((t) => /* @__PURE__ */ e(t.default, 1)),
                    import ("./nacl-fast-ByhJa28A.js").then((t) => /* @__PURE__ */ e(t.default, 1))
                ]), i = n.default;
                i.logToConsole = this._debug, this._pusher = new i(t.key, {
                    cluster: t.cluster || "us2",
                    nacl: r.default ? ? r,
                    authorizer: sg({
                        onSessionExpired: t.onSessionExpired
                    }),
                    authEndpoint: t.authEndpoint,
                    auth: {
                        headers: t.authHeaders ? ? {}
                    },
                    activityTimeout: 25e3,
                    pongTimeout: 1e4
                });
                let a = (e) => {
                        if (typeof e != "object" || !e) return;
                        let n = e;
                        (n.type === "AuthError" || n.error ? .data ? .message ? .toLowerCase() ? .includes("auth")) && (lg.error("Pusher authentication error", {
                            errorType: n.type,
                            errorMessage: n.error ? .data ? .message,
                            authEndpoint: t.authEndpoint
                        }), R("pusher_auth_error", {
                            errorType: n.type,
                            errorMessage: n.error ? .data ? .message
                        }));
                    },
                    o = () => this._setStatus("connected"),
                    s = () => this._setStatus("connecting"),
                    c = () => this._setStatus("error");
                this._connectionHandlers = [{
                        event: "error",
                        handler: a
                    },
                    {
                        event: "connected",
                        handler: o
                    },
                    {
                        event: "connecting",
                        handler: s
                    },
                    {
                        event: "error",
                        handler: c
                    },
                    {
                        event: "disconnected",
                        handler: () => this._setStatus("disconnected")
                    },
                    {
                        event: "unavailable",
                        handler: c
                    },
                    {
                        event: "failed",
                        handler: c
                    }
                ];
                for (let {
                        event: e,
                        handler: t
                    } of this._connectionHandlers) this._pusher.connection.bind(e, t);
            } catch (e) {
                throw this._setStatus("error"), P(e instanceof Error ? e : Error(String(e))), e;
            }
        }
        disconnect() {
            this._teardown({
                silent: !1
            });
        }
        _teardown({
            silent: e
        }) {
            if (this._pusher) {
                for (let e of this._channels.values()) e.unbindAll();
                this._channels.clear();
                for (let {
                        event: e,
                        handler: t
                    } of this._connectionHandlers) this._pusher.connection.unbind(e, t);
                this._connectionHandlers = [];
                try {
                    this._pusher.disconnect();
                } finally {
                    this._pusher = null;
                }
            } else this._channels.clear();
            e || this._setStatus("disconnected");
        }
        subscribe(e) {
            if (!this._pusher) throw Error("PusherTransport: not connected");
            let t = this._channels.get(e);
            if (!t) {
                let n = this._pusher.subscribe(e);
                this._debug && n.bind_global((t, n) => {
                    lg.debug(`${e} :: ${t}`, n);
                }), t = new ug(e, n), this._channels.set(e, t);
            }
            return t;
        }
        unsubscribe(e) {
            this._pusher && this._pusher.unsubscribe(e), this._channels.delete(e);
        }
        onStatusChange(e) {
            this._statusHandlers.add(e);
        }
        offStatusChange(e) {
            this._statusHandlers.delete(e);
        }
        _setStatus(e) {
            if (e !== this._status) {
                this._status = e;
                for (let t of this._statusHandlers) t(e);
            }
        }
    },
    fg = B("ws-transport"),
    pg = class {
        constructor(e, t) {
            L(this, "name", void 0), L(this, "handlers", /* @__PURE__ */ new Map()), L(this, "onBind", void 0), this.name = e, this.onBind = t;
        }
        bind(e, t) {
            let n = this.handlers.get(e);
            n || (n = /* @__PURE__ */ new Set(), this.handlers.set(e, n)), n.add(t), this.onBind ? .(e, t);
        }
        unbind(e, t) {
            this.handlers.get(e) ? .delete(t);
        }
        unbindAll() {
            this.handlers.clear();
        }
        emit(e, t) {
            let n = this.handlers.get(e);
            if (!n) return 0;
            for (let e of n) e(t);
            return n.size;
        }
    },
    mg = 55e3,
    hg = 1e4,
    gg = 1e3,
    _g = 3e4,
    vg = 6e4,
    yg = 3e5,
    bg = 1e4,
    xg = 8e3,
    Sg = new Set([
        "ready",
        "resync",
        "token_expired"
    ]),
    Cg = class {
        constructor() {
            L(this, "ws", null), L(this, "retiredSockets", /* @__PURE__ */ new WeakSet()), L(this, "lastCloseCode", null), L(this, "channels", /* @__PURE__ */ new Map()), L(this, "statusHandlers", []), L(this, "_status", "disconnected"), L(this, "_reconnectRequestedByServer", !1), L(this, "config", null), L(this, "pingTimer", null), L(this, "reconnectTimer", null), L(this, "stabilityTimer", null), L(this, "readyWatchdogTimer", null), L(this, "pongTimer", null), L(this, "reconnectAttempt", 0), L(this, "deferredReconnectCode", null), L(this, "reconnectScheduleId", 0), L(this, "connectionAttemptId", 0), L(this, "settlePendingConnect", null), L(this, "intentionalDisconnect", !1), L(this, "pendingControlActions", /* @__PURE__ */ new Set()), L(this, "tokenGetter", null);
        }
        get reconnectRequestedByServer() {
            return this._reconnectRequestedByServer;
        }
        get status() {
            return this._status;
        }
        setTokenGetter(e) {
            this.tokenGetter = e;
        }
        connect(e) {
            return this.config = e, this.intentionalDisconnect = !1, this.retiredSockets = /* @__PURE__ */ new WeakSet(), this.deferredReconnectCode = null, this.startConnectionAttempt({
                rejectOnFailure: !0
            });
        }
        disconnect() {
            this.intentionalDisconnect = !0, this.settlePendingConnect ? .(), this.connectionAttemptId += 1, this.retiredSockets = /* @__PURE__ */ new WeakSet(), this.deferredReconnectCode = null, this.stopPing(), this.clearStabilityTimer(), this.clearReadyWatchdog(), this.clearReconnectTimer(), this.ws && = (this.ws.close(), null), this.pendingControlActions.clear(), this.lastCloseCode = null, this.setStatus("disconnected");
        }
        subscribe(e) {
            let t = this.channels.get(e);
            return t || (t = new pg(e, (e, t) => {
                this.replayPendingControlAction(e, t);
            }), this.channels.set(e, t)), t;
        }
        unsubscribe(e) {
            let t = this.channels.get(e);
            t && (t.unbindAll(), this.channels.delete(e));
        }
        onStatusChange(e) {
            this.statusHandlers.push(e);
        }
        offStatusChange(e) {
            let t = this.statusHandlers.indexOf(e);
            t !== -1 && this.statusHandlers.splice(t, 1);
        }
        refreshToken(e) {
            this.ws ? .readyState === WebSocket.OPEN && this.ws.send(JSON.stringify({
                action: "token_refresh",
                token: e
            }));
        }
        startConnectionAttempt(e) {
            this.clearReconnectTimer(), this.clearStabilityTimer(), this.clearReadyWatchdog(), this.stopPing();
            let t = ++this.connectionAttemptId;
            if (this.ws) {
                let e = this.ws;
                this.ws = null, e.close();
            }
            let n = this.doConnect(t);
            return e.rejectOnFailure ? n : n.catch(() => {});
        }
        doConnect(e) {
            if (!this.config) return Promise.resolve();
            this.setStatus("connecting");
            let t = this.config.key,
                n = this.tokenGetter ? .() ? ? this.config.authHeaders ? .["Chat-Token"] ? ? "";
            if (!n) return this.connectionAttemptId === e && this.setStatus("error"), Promise.reject( /* @__PURE__ */ Error("No messaging token available for WebSocket"));
            try {
                let e = `${t}/${this.config.authHeaders?.["X-Ada-Client-Handle"] ?? new URL(this.config.authEndpoint ?? t).hostname.split(".")[0]}/ws?token=${encodeURIComponent(n)}`;
                this.lastCloseCode = null, this.ws = new WebSocket(e);
            } catch {
                return this.connectionAttemptId === e && (this.setStatus("error"), this.scheduleReconnect()), Promise.reject( /* @__PURE__ */ Error(`WebSocket construction failed for ${t}`));
            }
            let r = this.ws;
            return new Promise((n, i) => {
                let a = !1,
                    o = !1,
                    s = (e) => {
                        o || (o = !0, this.settlePendingConnect === s && (this.settlePendingConnect = null), e ? i(e) : n());
                    };
                this.settlePendingConnect = s;
                let c = () => this.connectionAttemptId === e;
                r.onopen = () => {
                    if (!c() || this.retiredSockets.has(r)) {
                        r.close(), s( /* @__PURE__ */ Error("WebSocket connection superseded by a newer attempt"));
                        return;
                    }
                    a = !0, this.armStabilityReset(), this.armReadyWatchdog(r, e), this.setStatus("connected"), this.startPing(), this.config ? .debug && fg.debug(`connected to ${t}`), s();
                }, r.onmessage = (e) => {
                    !c() || this.retiredSockets.has(r) || this.handleMessage(e.data);
                }, r.onclose = (e) => {
                    if (this.retiredSockets.has(r)) {
                        this.intentionalDisconnect || (this.lastCloseCode = e.code, (e.code === 4001 || e.code === 4403 || e.code === 4029 || e.code === 4008) && this.handleCloseCode(e.code));
                        return;
                    }
                    if (!c()) {
                        s( /* @__PURE__ */ Error("WebSocket connection superseded by a newer attempt"));
                        return;
                    }
                    this.stopPing(), this.clearStabilityTimer(), this.clearReadyWatchdog(), this.ws === r && (this.ws = null), this.intentionalDisconnect || (this.lastCloseCode = e.code, this.setStatus("disconnected"), this.handleCloseCode(e.code)), a || s( /* @__PURE__ */ Error("WebSocket closed before open"));
                }, r.onerror = () => {
                    !c() || this.retiredSockets.has(r) || this.setStatus("error");
                };
            });
        }
        handleMessage(e) {
            let t;
            try {
                t = JSON.parse(e);
            } catch {
                return;
            }
            if (this.clearPongWatchdog(), !t || typeof t != "object") return;
            let n = t.action;
            if (n === "reconnect") {
                this.config ? .debug && fg.debug("server requested reconnect"), this.reconnectOnServerRequest();
                return;
            }
            if (n === "token_expired") {
                this.emitControlAction("token_expired");
                return;
            }
            if (n === "pong" || n === "token_refresh_ack" || n === "ready" || n === "resync") {
                n === "ready" && (this.clearReadyWatchdog(), this.retiredSockets = /* @__PURE__ */ new WeakSet(), this.deferredReconnectCode = null), (n === "ready" || n === "resync") && this.emitControlAction(n);
                return;
            }
            if (n === "token_refresh_failed") {
                this.emitControlAction("token_refresh_failed");
                return;
            }
            if (t.kind === "delta") {
                for (let e of this.channels.values()) e.emit("message-delta", t);
                return;
            }
            let r = t.event,
                i = t.data;
            if (r && i !== void 0) {
                let e;
                e = typeof t.cursor == "string" ? t.cursor : typeof t.message_cursor == "string" ? t.message_cursor : void 0;
                let n = e !== void 0 && typeof i == "object" && i && !Array.isArray(i) ? {
                    ...i,
                    cursor: e
                } : i;
                for (let e of this.channels.values()) e.emit(r, n);
            }
        }
        emitControlAction(e) {
            let t = 0;
            for (let n of this.channels.values()) t += n.emit(e, {});
            t === 0 && Sg.has(e) && this.pendingControlActions.add(e);
        }
        replayPendingControlAction(e, t) {
            this.pendingControlActions.has(e) && (this.pendingControlActions.delete(e), t({}));
        }
        setStatus(e, t = !1) {
            if (this._reconnectRequestedByServer = t, this._status !== e) {
                this._status = e;
                for (let t of this.statusHandlers) try {
                    t(e);
                } catch {
                    fg.error("status change handler failed");
                }
            }
        }
        startPing() {
            this.stopPing(), this.pingTimer = setInterval(() => {
                this.ws ? .readyState === WebSocket.OPEN && (this.ws.send(JSON.stringify({
                    action: "ping"
                })), this.armPongWatchdog(this.ws, this.connectionAttemptId));
            }, mg);
        }
        stopPing() {
            this.pingTimer && = (clearInterval(this.pingTimer), null), this.clearPongWatchdog();
        }
        armPongWatchdog(e, t) {
            this.clearPongWatchdog(), this.pongTimer = setTimeout(() => {
                this.pongTimer = null, !(this.connectionAttemptId !== t || this.ws !== e) && (fg.warn(`no pong within ${hg}ms; closing socket to force a reconnect`), R("messaging_ws_pong_watchdog_fired", {
                    timeoutMs: hg,
                    reconnectAttempt: this.reconnectAttempt
                }), this.setStatus("error"), this.connectionAttemptId += 1, this.retiredSockets.add(e), this.ws = null, this.stopPing(), e.close(), this.scheduleReconnect());
            }, hg);
        }
        clearPongWatchdog() {
            this.pongTimer && = (clearTimeout(this.pongTimer), null);
        }
        reconnectOnServerRequest() {
            let e = this.ws;
            e && (this.setStatus("connecting", !0), this.connectionAttemptId += 1, this.retiredSockets.add(e), this.ws = null, this.stopPing(), this.clearStabilityTimer(), this.clearReadyWatchdog(), e.close(), this.scheduleReconnect());
        }
        handleCloseCode(e) {
            if (e === 4001) {
                this.intentionalDisconnect = !0, this.connectionAttemptId += 1, this.clearReconnectTimer(), this.stopPing(), this.clearStabilityTimer(), this.clearReadyWatchdog();
                let e = this.ws;
                this.ws = null, e && (e.close(), this.setStatus("disconnected")), this.emitControlAction("token_expired");
                return;
            }
            if (e === 4403) {
                fg.error("ws-gateway rejected the connection as forbidden (4403); not reconnecting"), this.intentionalDisconnect = !0, this.connectionAttemptId += 1, this.clearReconnectTimer(), this.stopPing(), this.clearStabilityTimer(), this.clearReadyWatchdog();
                let e = this.ws;
                this.ws = null, e ? .close(), this.setStatus("error");
                return;
            }
            if ((e === 4029 || e === 4008) && (this.deferredReconnectCode = e), this.deferredReconnectCode !== null) {
                this.ws || (this.reconnectTimer && --this.reconnectAttempt, this.scheduleReconnect({
                    baseMs: vg,
                    maxMs: yg
                }));
                return;
            }
            this.scheduleReconnect();
        }
        scheduleReconnect(e = {}) {
            if (this.intentionalDisconnect) return;
            this.clearReconnectTimer(), this.deferredReconnectCode = null;
            let t = e.baseMs ? ? gg,
                n = e.maxMs ? ? _g,
                r = Math.min(t * 2 ** this.reconnectAttempt, n),
                i = Math.round(r * (1 + Math.random() * .5));
            this.reconnectAttempt++, this.config ? .debug && fg.debug(`reconnecting in ${i}ms`);
            let a = ++this.reconnectScheduleId;
            this.reconnectTimer = setTimeout(() => {
                this.reconnectScheduleId === a && (this.reconnectTimer = null, this.startConnectionAttempt({
                    rejectOnFailure: !1
                }));
            }, i);
        }
        clearReconnectTimer() {
            this.reconnectScheduleId += 1, this.reconnectTimer && = (clearTimeout(this.reconnectTimer), null);
        }
        armStabilityReset() {
            this.clearStabilityTimer();
            let e = this.connectionAttemptId;
            this.stabilityTimer = setTimeout(() => {
                this.stabilityTimer = null, this.connectionAttemptId === e && (this.reconnectAttempt = 0);
            }, bg);
        }
        clearStabilityTimer() {
            this.stabilityTimer && = (clearTimeout(this.stabilityTimer), null);
        }
        armReadyWatchdog(e, t) {
            this.clearReadyWatchdog(), this.readyWatchdogTimer = setTimeout(() => {
                this.readyWatchdogTimer = null, !(this.connectionAttemptId !== t || this.ws !== e) && (fg.warn(`no ready frame within ${xg}ms; closing socket to force a reconnect`), R("messaging_ws_ready_watchdog_fired", {
                    timeoutMs: xg,
                    reconnectAttempt: this.reconnectAttempt
                }), this.setStatus("error"), this.retiredSockets.add(e), this.ws = null, this.stopPing(), this.clearStabilityTimer(), e.close(), this.scheduleReconnect(this.deferredReconnectCode === null ? void 0 : {
                    baseMs: vg,
                    maxMs: yg
                }));
            }, xg);
        }
        clearReadyWatchdog() {
            this.readyWatchdogTimer && = (clearTimeout(this.readyWatchdogTimer), null);
        }
    },
    wg = B("startup"),
    Tg = "localhost",
    Eg = 240,
    Dg = "expired_before_send",
    Og = 2,
    kg = 3e3,
    Ag = "identity_token_exchange_failed",
    jg = "identity_token_expired",
    Mg = 3e3,
    Ng = 3,
    Pg = [250, 750],
    Fg = 1e4,
    Ig = rt,
    Lg = 0,
    Rg = new Set([
        "not_configured",
        "missing_identity_token",
        "invalid_identity_token",
        "chatter_not_found",
        "identity_token_already_used",
        "identity_token_state_unavailable"
    ]),
    zg = /* @__PURE__ */ new WeakMap();

function Bg(e) {
    return e.endsWith("/") ? e : `${e}/`;
}

function Vg(e, t) {
    let n = () => {};
    if (!t) return n;
    if (t.aborted) return e.abort(), n;
    let r = () => e.abort();
    return t.addEventListener("abort", r, {
        once: !0
    }), () => t.removeEventListener("abort", r);
}

function Hg(e) {
    if (e == null) return null;
    let t = (typeof e == "string" ? e : (() => {
        try {
            return JSON.stringify(e);
        } catch {
            return String(e);
        }
    })()).trim();
    return t ? t.length <= Eg ? t : `${t.slice(0, Eg)}...` : null;
}

function Ug(e) {
    if (typeof e != "object" || !e || "status" in e && e.status === "PARSING_ERROR" || "isParsingError" in e && e.isParsingError === !0) return !1;
    if ("status" in e && e.status === "TIMEOUT_ERROR") return !0;
    let t = Wm("status" in e && e.status === "FETCH_ERROR" ? {
        status: 0,
        data: "error" in e ? e.error : void 0
    } : e);
    return t.reason === "network" || t.reason === "timeout";
}

function Wg(e, t, n, r = "") {
    let i = [];
    if (typeof n == "object" && n) {
        let e = n;
        (typeof e.status == "number" || typeof e.status == "string") && i.push(`status ${e.status}`);
        let t = Hg(e.data) ? ? Hg(e.error);
        t && i.push(t);
    } else {
        let e = Hg(n);
        e && i.push(e);
    }
    return `${e} ${t}${i.length > 0 ? ` (${i.join("; ")})` : ""}.${r}`;
}

function Gg(e) {
    if (typeof e != "object" || !e) return;
    let t = e;
    return typeof t.status == "number" ? t.status : t.status === "PARSING_ERROR" && typeof t.originalStatus == "number" ? t.originalStatus : typeof t.status == "string" ? t.status : void 0;
}
var Kg = class extends Error {
    constructor(e, t, n) {
        super(e), L(this, "target", void 0), L(this, "status", void 0), this.name = "StartupRequestError", this.target = t, this.status = Gg(n);
    }
};

function qg(e) {
    return e instanceof Kg || Ug(e) ? !0 : e instanceof Error ? e.cause && qg(e.cause) ? !0 : e.message.startsWith("Request timed out after") || e instanceof TypeError && /failed to fetch|network|load failed/i.test(e.message) : !1;
}

function Jg(e) {
    return e instanceof Kg && e.target === "public-client" && typeof e.status == "number" && e.status >= 400 && e.status < 500;
}

function Yg(e, t) {
    if (typeof e != "object" || !e) return null;
    let n = e[t];
    return typeof n == "string" && n.trim() || null;
}

function Xg(e) {
    let t = typeof e == "string" ? e.trim() : null,
        n = Yg(e, "message") ? ? Yg(e, "reason") ? ? Yg(e, "error"),
        r = t ? ? n;
    return r && Rg.has(r) ? r : null;
}

function Zg(e) {
    if (typeof e == "object" && e) {
        let t = e;
        return Xg(t.data) ? ? Xg(t.error) ? ? Ag;
    }
    return Xg(e) ? ? Ag;
}
var Qg = class extends Error {
    constructor(e, t) {
        super(e), L(this, "reason", void 0), this.name = "IdentityTokenExchangeError", this.reason = t;
    }
};

function $g(e) {
    let t = e.trim().toLowerCase();
    if (!Vn.has(t)) {
        let t = Array.from(Vn).sort().join(", ");
        throw Error(`CoreOrchestrator: unsupported cluster "${e}". Supported values: ${t}.`);
    }
    return t;
}

function e_(e, t, n) {
    if (e === Tg) {
        try {
            let e = new URL(Bg(n));
            if (Ht(e.hostname, {
                    additionalHosts: Qi
                })) return new URL("?ada_request_origin=embed", e).toString();
        } catch {}
        return "/api/?ada_request_origin=embed";
    }
    return `https://rollout.${e}/${t}/client.json`;
}

function t_(e, t) {
    return e === Tg ? null : `https://${t}.${e}/api/?ada_request_origin=embed`;
}

function n_(e, t, n) {
    if (e === Tg) {
        try {
            let e = new URL(Bg(n));
            if (Ht(e.hostname, {
                    additionalHosts: Qi
                })) return new URL("client-config/", e).toString();
        } catch {}
        return "/api/client-config/";
    }
    return `https://${t}.${e}/api/client-config/`;
}

function r_(e, t, n, r) {
    if (e) return $g(e);
    try {
        let e = new URL(t).hostname.toLowerCase();
        if (Ht(e, {
                additionalHosts: Qi
            })) return Tg;
        let r = `${n.toLowerCase()}.`;
        if (e.startsWith(r) && e.length > r.length) return $g(e.slice(r.length));
    } catch {}
    let i = (r ? ? (typeof window < "u" ? window.location.hostname : void 0) ? ? "").toLowerCase().split(".");
    if (i.length >= 2) return $g(i.slice(1).join("."));
    throw Error("CoreOrchestrator: unable to resolve rollout cluster. Provide \"cluster\" in AdaMessagingClient config.");
}
var i_ = /* @__PURE__ */ new WeakMap();
async function a_(e, t, n, r) {
    let i = n ? ? e.getState().session.language,
        a = (i_.get(e) ? ? 0) + 1;
    i_.set(e, a), e.dispatch(kt());
    try {
        let t = await Je(i);
        if (r ? .aborted || a !== i_.get(e)) return;
        e.dispatch(St(t.translations, t.language, t.fallbackKeys));
    } catch (e) {
        t("Failed to load translations:", e);
    } finally {
        a === i_.get(e) && e.dispatch(Ji());
    }
}
async function o_(e) {
    let {
        endpoint: t,
        handle: n,
        cluster: r
    } = e.store.getState().session;
    if (!t || !n) throw Error("CoreOrchestrator: session not configured");
    let i = e.onResolveRolloutCluster ? .(r, t, n) ? ? r_(r, t, n),
        a = e.onGetClientUrl ? .(i, n, t) ? ? e_(i, n, t),
        o = await e.store.dispatch(G.endpoints.getClient.initiate({
            url: a
        })),
        s = a;
    if (e.store.dispatch(z()), ("error" in o || !o.data) && i !== Tg) {
        let t = t_(i, n);
        t && (s = t, o = await e.store.dispatch(G.endpoints.getClient.initiate({
            url: t
        })), e.store.dispatch(z()));
    }
    if ("error" in o || !o.data) {
        e.signal && W(e.signal);
        let t = "error" in o ? o.error : null;
        throw Ug(t) && e.store.dispatch(Oi()), new Kg(Wg("CoreOrchestrator: failed to fetch client from", s, t, i === Tg ? " Local dev note: verify this localhost bootstrap route responds for your bot handle; /client-config/ succeeding alone is not enough." : ""), "public-client", t);
    }
    return o.data;
}

function s_(e) {
    let {
        reason: t,
        status: n
    } = Wm(e);
    return Ug(e) || t === "http" && n !== void 0 && (n === 408 || n === 429 || n >= 500 && n < 600);
}

function c_(e) {
    if (typeof e != "object" || !e || !("status" in e) || e.status !== 429 && e.status !== 503 || !("retryAfter" in e) || typeof e.retryAfter != "string") return;
    let t = e.retryAfter.trim();
    if (/^\d+$/.test(t)) return Number(t) * 1e3;
    let n = /[a-z]/i.test(t) ? Date.parse(t) : NaN;
    return Number.isFinite(n) ? Math.max(0, n - Date.now()) : void 0;
}
async function l_(e, t) {
    t && W(t), await new Promise((n) => {
        let r = () => {
                clearTimeout(i), t ? .removeEventListener("abort", r), n();
            },
            i = setTimeout(r, e);
        t ? .addEventListener("abort", r, {
            once: !0
        });
    }), t && W(t);
}
async function u_(e, t, n = {}) {
    let {
        endpoint: r,
        handle: i,
        cluster: a
    } = e.store.getState().session;
    if (!r || !i) throw Error("CoreOrchestrator: session not configured");
    let o = e.onResolveRolloutCluster ? .(a, r, i) ? ? r_(a, r, i),
        s = e.onGetClientConfigUrl ? .(o, i, r) ? ? n_(o, i, r),
        c = Date.now() + qe,
        l = e.random ? ? Math.random,
        u = {
            error: {
                status: 0,
                data: `${Ga} ${qe}ms`
            }
        },
        d = async (t) => {
            e.signal && W(e.signal), Lg += 1;
            let r = e.store.dispatch(G.endpoints.getClientConfig.initiate({
                    url: s,
                    requestScope: `startup:${Lg}`,
                    ...t > 1 ? {
                        timeoutMs: Math.min(Ig, c - Date.now())
                    } : {}
                }, {
                    subscribe: !1
                })),
                i, a;
            try {
                a = await Promise.race([r, new Promise((e) => {
                    i = setTimeout(() => {
                        e(u), r.abort ? .();
                    }, Math.max(0, c - Date.now()));
                })]);
            } finally {
                clearTimeout(i);
            }
            if (a.data && Date.now() >= c && (a = u), e.store.dispatch(z()), "error" in a || !a.data) {
                e.signal && W(e.signal);
                let r = "error" in a ? a.error : null,
                    i = c - Date.now() - Fg;
                if (n.retryFailures !== !1 && t < Ng && i >= 0 && s_(r)) {
                    let n = c_(r),
                        o = Pg[t - 1],
                        s = n === void 0 ? o / 2 + l() * o / 2 : Math.min(n, i);
                    return s > i || (await l_(s, e.signal), Date.now() + Fg > c) ? a : d(t + 1);
                }
            }
            return a;
        },
        f = await d(1);
    if ("error" in f || !f.data) {
        e.signal && W(e.signal);
        let t = "error" in f ? f.error : null;
        throw Ug(t) && e.store.dispatch(Oi()), new Kg(Wg("CoreOrchestrator: failed to fetch client config from", s, t, o === Tg ? " Local dev note: verify the localhost client-config route is reachable for your bot handle." : ""), "client-config", t);
    }
    return f.data.turnstile_site_key && !e.signal ? .aborted && e.store.dispatch(ni(f.data.turnstile_site_key)), e.signal ? .aborted || (e.store.dispatch(Ci(f.data.messaging_session_cookie_enabled === !0)), e.store.dispatch(S(f.data.zendeskMessagingChatterAuth === !0))), {
        ...t,
        pusher_key: f.data.pusher_key,
        pusher_cluster: f.data.pusher_cluster,
        pusher_fallback_allowed: f.data.pusher_fallback_allowed,
        websocket_endpoint: f.data.websocket_endpoint ? ? null
    };
}

function d_(e, t) {
    e.dispatch(Sn(t.saml_login_button ? ? {
        backgroundColor: null,
        fontFamily: null,
        header: null,
        headerMessage: null,
        title: null,
        text: null
    })), e.dispatch(Bi({
        clientDefaultLanguage: t.language,
        translatedLanguages: t.translated_languages,
        features: t.features,
        emailTranscriptEnabled: t.email_transcript_enabled,
        downloadTranscriptEnabled: t.download_transcript_enabled,
        fileUploadEnabled: t.file_upload_enabled,
        imageUploadEnabled: t.image_upload_enabled,
        showBranding: t.show_branding,
        adaPartnerName: t.ada_partner_name,
        botName: t.bot_name,
        botNameTranslations: t.bot_name_translations,
        botDescription: t.bot_description,
        botDescriptionEnabled: t.bot_description_enabled,
        botAvatarUrl: t.bot_avatar_url,
        tintColor: t.tint_color || null,
        style: t.style,
        textSize: t.text_size,
        headerColorEnabled: t.header_color_enabled,
        headerColor: t.header_color,
        headerTextColor: t.header_text_color,
        chatEnabled: t.chat_enabled,
        privacyLink: t.privacy_link,
        privacy: t.privacy,
        theme: t.theme,
        advancedColorsEnabled: t.advanced_colors_enabled,
        textOverAccentColor: t.text_over_accent_color,
        buttonLayoutMobile: t.button_layout_mobile,
        buttonLayoutDesktop: t.button_layout_desktop,
        showAllQuickReplies: t.show_all_quick_replies,
        fallbackUi: t.fallback_ui,
        buttonSize: t.button ? .size,
        buttonBackgroundColor: t.button ? .background_color ? ? null,
        avatar: t.avatar ? {
            letter: t.avatar.letter,
            image: t.avatar.image,
            useLetter: t.avatar.use_letter
        } : void 0,
        agentAvatar: t.agent_avatar ? {
            isDefault: t.agent_avatar.default,
            image: t.agent_avatar.image
        } : void 0,
        allowedProtocols: t.allowed_protocols,
        allowedWebsites: t.iframe_allow_list,
        customRedactions: t.custom_redactions,
        persistence: t.persistence,
        timeToExpiryMs: t.time_to_expiry,
        rollout: t.rollout
    }));
}

function f_(e) {
    let {
        language: t,
        clientDefaultLanguage: n,
        translatedLanguages: r
    } = e.getState().session, i = $a(t, [n, ...r]);
    i && i !== t && e.dispatch(ma(i));
}
async function p_(e) {
    let {
        endpoint: t,
        chatterToken: n
    } = e.store.getState().session;
    if (!(!t || !n)) try {
        let r = await e.store.dispatch(G.endpoints.getChatterRestoreState.initiate({
            endpoint: t,
            chatterToken: n
        }));
        if (e.store.dispatch(z()), e.signal.aborted) return;
        if ("error" in r || !r.data) {
            P( /* @__PURE__ */ Error("Failed to restore chatter state"), {
                context: "chatter-state-restore"
            });
            return;
        }
        let {
            clientDefaultLanguage: i,
            translatedLanguages: a,
            languageFromHost: o
        } = e.store.getState().session;
        if (r.data.language && !o) {
            let t = r.data.language.trim().toLowerCase() === "in" ? "id" : r.data.language,
                n = $a(t, [i, ...a]) ? ? t;
            e.store.dispatch(ma(n));
        }
    } catch (t) {
        e.signal.aborted || P(t, {
            context: "chatter-state-restore"
        });
    }
}
async function m_(e, t, n, r) {
    let {
        endpoint: i
    } = e.getState().session;
    if (!i) throw Error("CoreOrchestrator: endpoint not set");
    let a = await r ? .requestToken(t);
    if (t.aborted) return;
    let {
        language: o,
        languageFromHost: s,
        metaFields: c,
        sensitiveMetaFields: l
    } = e.getState().session, u = v(c), d = await e.dispatch(G.endpoints.createChatter.initiate({
        endpoint: i,
        persistenceMode: n,
        ...s ? {
            language: o
        } : {},
        metaFields: u,
        sensitiveMetaFields: l,
        ...a ? {
            zendeskChatterAuthToken: a
        } : {}
    }));
    if (t.aborted) {
        R("chatter_created_superseded");
        return;
    }
    if ("error" in d || !d.data) throw Error(Wg("CoreOrchestrator: failed to create chatter via", `${Bg(i)}chatters/`, "error" in d ? d.error : null), {
        cause: "error" in d ? d.error : void 0
    });
    if (d.data.messagingToken && !Xn(d.data.messagingToken, d.data.token)) throw Error("CoreOrchestrator: chatter creation returned mismatched messaging credentials");
    r ? .seed(d.data.token, d.data.zendeskAuthExpireIn, a ? ? null), e.dispatch(vo({
        token: d.data.token,
        id: d.data.id,
        sessionToken: d.data.sessionToken,
        messagingToken: d.data.messagingToken,
        messagingTokenExpiresIn: d.data.messagingTokenExpiresIn,
        sessionRefreshToken: d.data.sessionRefreshToken,
        refreshGeneration: d.data.refreshGeneration,
        sessionCookieIssued: d.data.sessionCookieIssued,
        playAlertChime: d.data.playAlertChime,
        deviceNotificationsEnabled: d.data.deviceNotificationsEnabled,
        smsNotificationsEnabled: d.data.smsNotificationsEnabled,
        suppressAnnouncement: !0
    })), zg.set(t, {
        chatterToken: d.data.token,
        metaFields: u,
        sensitiveMetaFields: l
    }), e.dispatch(A()), e.dispatch(d.data.saml ? Ho(d.data.saml) : mn()), R("chatter_created");
}
async function h_(e, t, n, r) {
    let i = e.prepareClock ? ? e.beginStartupTracking();
    W(i.signal), i.start(), i.setLastStep("chat_startup_metadata");
    let a, o = !1,
        s = typeof document > "u" ? void 0 : document,
        c = !1,
        l = () => {
            s ? .visibilityState === "visible" && (c = !0);
        };
    try {
        await Promise.race([n(), new Promise((e) => {
            l(), s ? .addEventListener("visibilitychange", l), a = i.armActiveDeadline(Mg, () => {
                o = !0, e();
            });
        })]);
    } finally {
        a ? .(), s ? .removeEventListener("visibilitychange", l), e.prepareClock || i.dispose();
    }
    if (!e.signal.aborted && o) {
        let e = /* @__PURE__ */ Error("Timed out updating chatter startup data storage"),
            n = s ? .visibilityState ? ? "unknown",
            i = c || n === "visible";
        if (r.throwOnError || i) {
            let r = Gm({
                reason: "startup_gate_timeout"
            });
            P(e, {
                context: `${t}-timeout`,
                timeoutMs: Mg
            }, {
                ...r,
                tags: {
                    ...r.tags,
                    host_visibility: i ? "visible" : n
                }
            });
        } else R("chat_startup_gate_slow", {
            context: t,
            timeout_ms: Mg,
            host_visibility: n
        });
        if (r.throwOnError) throw e;
    }
}

function g_(e, t, n, r) {
    return qm({
        store: e.store,
        getLifecycleSignal: () => e.signal,
        onLoadTranslations: e.onLoadTranslations,
        onCaptureException: (e, n, r) => P(e, {
            context: t,
            ...n
        }, r)
    }, n, r);
}
async function __(e, t = {}) {
    let n = zg.get(e.signal);
    zg.delete(e.signal);
    let {
        chatterToken: r,
        metaFields: i,
        sensitiveMetaFields: a
    } = e.store.getState().session;
    if (!n || e.signal.aborted || n.chatterToken !== r) return;
    let o = Object.fromEntries(Object.entries(v(i)).filter(([e, t]) => n.metaFields[e] !== t)),
        s = Object.fromEntries(Object.entries(a).filter(([e, t]) => n.sensitiveMetaFields[e] !== t));
    if (("device_token" in s || "device_os" in s) && (s.device_token = a.device_token, s.device_os = a.device_os), !(Object.keys(o).length === 0 && Object.keys(s).length === 0)) try {
        await h_(e, "created-chatter-startup-meta-fields", () => g_(e, "created-chatter-startup-meta-fields", {
            metaFields: o,
            sensitiveMetaFields: s
        }, {
            allowSuppressedChatter: !0,
            throwOnError: !0
        }), {});
    } catch (r) {
        if (t.throwOnError) throw zg.set(e.signal, n), r;
    }
}
async function v_(e, t) {
    let {
        endpoint: n,
        identityToken: r
    } = e.getState().session;
    if (!n) throw Error("CoreOrchestrator: endpoint not set");
    if (!r) throw Error("CoreOrchestrator: identity token not set");
    let i = await e.dispatch(G.endpoints.identifyMessagingToken.initiate({
        endpoint: n,
        identityToken: r
    }));
    if (t.aborted) {
        R("chatter_identified_superseded");
        return;
    }
    if ("error" in i || !i.data) {
        let e = "error" in i ? i.error : null,
            t = Zg(e),
            a = t === "invalid_identity_token" && ir(r, Date.now()) ? jg : t;
        throw new Qg(Wg("CoreOrchestrator: failed to exchange identity token via", `${Bg(n)}auth/tokens/identify`, e), a);
    }
    let a = O(i.data.token),
        o = O(i.data.id),
        s = O(i.data.sessionToken),
        c = O(i.data.messagingToken),
        l = O(i.data.sessionRefreshToken);
    if (!a || !o || !s || !c || typeof i.data.messagingTokenExpiresIn != "number" || !Number.isFinite(i.data.messagingTokenExpiresIn) || i.data.messagingTokenExpiresIn <= 0 || !l || !Xn(c, a) || typeof i.data.refreshGeneration != "number" || !Number.isInteger(i.data.refreshGeneration) || i.data.refreshGeneration < 1) throw new Qg("CoreOrchestrator: identity token exchange returned an incomplete chatter identity", Ag);
    e.dispatch(vo({
        token: a,
        id: o,
        sessionToken: s,
        messagingToken: c,
        messagingTokenExpiresIn: i.data.messagingTokenExpiresIn,
        sessionRefreshToken: l,
        refreshGeneration: i.data.refreshGeneration,
        sessionCookieIssued: i.data.sessionCookieIssued,
        identityTokenConsumed: !0,
        suppressAnnouncement: !0
    })), e.dispatch(A()), e.dispatch(i.data.saml ? Ho(i.data.saml) : mn()), R("chatter_identified");
}
async function y_(e, t, n = {}) {
    let {
        metaFields: r,
        sensitiveMetaFields: i,
        language: a,
        clientDefaultLanguage: o,
        translatedLanguages: s
    } = e.store.getState().session, c = n.applySessionLanguage ? $a(a, [o, ...s]) : null, {
        initialURL: l,
        ...u
    } = r, d = l === null ? u : r, f = c ? {
        ...d,
        language: c
    } : d;
    await h_(e, t, () => {
        let r = g_(e, t, {
            metaFields: v(f),
            sensitiveMetaFields: i
        }, {
            throwOnError: n.throwOnError,
            allowSuppressedChatter: n.allowSuppressedChatter
        });
        return n.throwOnError ? r : r.catch((e) => {
            P(e, {
                context: t
            }, Gm({
                reason: "unknown"
            }));
        });
    }, n);
}

function b_(e) {
    return e instanceof Qg ? e.reason : Ag;
}

function x_(e) {
    return e instanceof Error ? e : Error(Ag);
}

function S_(e, t) {
    let n = e.store.getState().session;
    t && n.chatterToken === t && n.identitySession && n._chatterPersistenceAnnouncementPending && n._pendingIdentityTokenConsumedChatterId && e.store.dispatch(za({
        reason: Ag
    }));
}

function C_(e) {
    let {
        handle: t
    } = e.getState().session;
    t && Rm(t, (t) => e.dispatch(Qe(t)), (t, n) => e.dispatch(qa({
        key: t,
        value: n
    }))).catch((e) => {
        wg.error("Feature flags initialization failed:", e), P(e instanceof Error ? e : Error(String(e)), {
            context: "feature-flags-init"
        });
    });
}
async function w_(e, t, n, r, i, a, o) {
    if (!i || !r) return {
        token: null,
        refreshGeneration: a
    };
    let s = i,
        c = a,
        l = {
            ...n ? {
                "Chatter-Token": n
            } : {},
            "X-Ada-Request-Origin": "chat"
        },
        u = async (i) => {
            if (o ? .aborted || !k_(e, n, r)) return {
                token: null,
                refreshGeneration: c
            };
            let a = e.getState().session;
            if ((a.refreshGeneration ? ? 0) > (c ? ? 0) && a.sessionRefreshToken && (s = a.sessionRefreshToken, c = a.refreshGeneration, Cr(a))) return {
                token: a.messagingToken,
                refreshGeneration: c
            };
            let d = await A_(e, t, l, n, r, s, c, o);
            if (o ? .aborted || !k_(e, n, r)) return {
                token: null,
                refreshGeneration: c
            };
            if (d === "invalid_refresh_token") {
                if (await fo.restoreRefreshCredential({
                        getState: e.getState,
                        dispatch: e.dispatch,
                        signal: o
                    }), o ? .aborted || !k_(e, n, r)) return {
                    token: null,
                    refreshGeneration: c
                };
                let t = e.getState().session;
                if ((t.refreshGeneration ? ? 0) > (c ? ? 0) && t.sessionRefreshToken) return Cr(t) ? {
                    token: t.messagingToken,
                    refreshGeneration: t.refreshGeneration
                } : (s = t.sessionRefreshToken, c = t.refreshGeneration, i > 1 ? u(i - 1) : {
                    token: null,
                    refreshGeneration: c
                });
            }
            return !d && i > 1 ? u(i - 1) : {
                token: d,
                refreshGeneration: c
            };
        };
    return u(Og);
}
async function T_(e, t, n) {
    if (!e || !t.sessionToken) return {
        kind: "unavailable"
    };
    let r = (e, t) => {
            try {
                R("messaging_jwt_introspect", {
                    result: e,
                    ...t
                });
            } catch {}
        },
        i = new AbortController(),
        a = Vg(i, n),
        o = setTimeout(() => i.abort(), kg);
    try {
        let n = await fetch(`${Bg(e)}auth/tokens/introspect`, {
            method: "POST",
            signal: i.signal,
            headers: {
                "Content-Type": "application/json",
                "X-Ada-Request-Origin": "chat",
                ...t.chatterToken ? {
                    "Chatter-Token": t.chatterToken
                } : {},
                "Session-Auth": t.sessionToken
            },
            body: "{}"
        });
        if (!n.ok) return r("keep_http_error", {
            status: n.status
        }), {
            kind: "unavailable"
        };
        let a = n.headers.get("content-type") ? .includes("application/json") ? await n.json().catch(() => null) : null,
            o = a ? .alive,
            s = a ? .reason;
        return o === !1 ? (r("terminal", typeof s == "string" && da.has(s) ? {
            reason: s
        } : void 0), {
            kind: "terminal"
        }) : (r(o === !0 ? "alive" : "keep_inconclusive"), o === !0 ? {
            kind: "keep"
        } : {
            kind: "unavailable"
        });
    } catch {
        return r("keep_error"), {
            kind: "unavailable"
        };
    } finally {
        clearTimeout(o), a();
    }
}
async function E_(e, t, n, r = "bootstrap", i = Ee("eb157faa62f6aedb4b1659a9563b247e78b9d989", "memory", null, "no_credential"), a, o) {
    if (!e) return {
        kind: "unavailable"
    };
    let s = new AbortController(),
        c = Vg(s, n),
        l = setTimeout(() => s.abort(), kg);
    try {
        a && R("messaging_exchange_fallback", {
            trigger: r,
            ...a
        });
        let n = async (n) => {
                let a = await fetch(`${Bg(e)}auth/tokens/exchange`, {
                    method: "POST",
                    credentials: "include",
                    signal: s.signal,
                    headers: {
                        "Content-Type": "application/json",
                        "X-Ada-Request-Origin": "chat",
                        "Chatter-Token": t.chatterToken,
                        "Session-Auth": t.sessionToken,
                        ...n ? {
                            "Messaging-Issue-Refresh": "true"
                        } : {}
                    },
                    body: JSON.stringify({
                        trigger: r,
                        ...i,
                        client_version: "eb157faa62f6aedb4b1659a9563b247e78b9d989"
                    })
                });
                return {
                    res: a,
                    payload: a.headers.get("content-type") ? .includes("application/json") ? await a.json().catch(() => null) : null
                };
            },
            {
                res: c,
                payload: l
            } = await n(!0);
        if (c.status === 503 && Oo(l) === "refresh_issuance_conflict") {
            if (s.signal.aborted) return {
                kind: "unavailable"
            };
            ({
                res: c,
                payload: l
            } = await n(!1));
        }
        if (!c.ok) {
            if (vi(c.status, l)) return {
                kind: "exchange_disabled",
                ...Wo(o) && Ei(l) ? {
                    handoffEnded: !0
                } : {}
            };
            let e = Oo(l);
            return (c.status === 401 || c.status === 403) && typeof e == "string" && ti.has(e) ? {
                kind: "terminal"
            } : {
                kind: "unavailable"
            };
        }
        let u = hr(l);
        return !u || !Xn(u.messagingToken, t.chatterToken) ? {
            kind: "unavailable"
        } : {
            kind: "success",
            credential: {
                messagingToken: u.messagingToken,
                messagingTokenExpiresAt: Date.now() + u.expiresIn * 1e3,
                sessionRefreshToken: u.sessionRefreshToken,
                refreshGeneration: u.refreshGeneration,
                sessionCookieIssued: u.sessionCookieIssued
            }
        };
    } catch {
        return {
            kind: "unavailable"
        };
    } finally {
        clearTimeout(l), c();
    }
}
async function D_(e, t, n, r = Io() ? ? Xi(e.store.getState().session.persistence), i = "no_credential", a = null) {
    let o = e.store.getState().session,
        s = {
            ...o,
            ...t,
            ...k_(e.store, t.chatterToken, t.sessionToken) ? {} : {
                messagingToken: null,
                messagingTokenExpiresAt: null,
                sessionRefreshToken: null,
                refreshGeneration: null,
                sessionCookieIssued: !1
            }
        },
        c;
    if (i !== "credential_rejected" && Ya(e.store, s) && s.endpoint) {
        let t = nr([e.signal], kg),
            r = !1;
        try {
            let i = await Promise.race([fo.refreshForStartup({
                ...s,
                endpoint: Bg(s.endpoint)
            }, {
                ...e.store,
                signal: t.signal
            }, n, () => {
                r = !0;
            }), t.timeoutPromise]);
            if (i instanceof Pa) throw i;
            if (i === "session_dead") return {
                kind: "terminal"
            };
            if (!i) return {
                kind: "unavailable"
            };
            if (i !== "invalid_refresh_token") return {
                kind: "success",
                refreshed: !0,
                credential: {
                    messagingToken: i.messagingToken,
                    messagingTokenExpiresAt: i.expiresAt,
                    sessionRefreshToken: i.sessionRefreshToken,
                    refreshGeneration: i.refreshGeneration,
                    sessionCookieIssued: i.sessionCookieIssued
                }
            };
            r && (c = {
                reason: "invalid_refresh_token",
                hadStoredCredential: !!s.sessionRefreshToken,
                sessionCookieIssued: s.sessionCookieIssued === !0
            });
        } catch (e) {
            if (!(e instanceof Pa) || t.signal.aborted) return {
                kind: "unavailable"
            };
            if (e.reason === "session_mismatch") return R("messaging_jwt_refresh", {
                trigger: n,
                result: "invalid_response"
            }), {
                kind: "unavailable"
            };
            c = {
                sessionCookieIssued: s.sessionCookieIssued === !0,
                reason: e.reason,
                hadStoredCredential: !!s.sessionRefreshToken
            };
        } finally {
            t.cleanup();
        }
    }
    let l;
    try {
        l = Qo(e.store.getState(), r);
    } catch (e) {
        P(e, {
            context: "exchange_handoff_snapshot_failed"
        });
    }
    let u = await E_(s.endpoint, t, e.signal, n, Ea(s, i, a), c, l);
    if (u.kind !== "exchange_disabled" || !s.handle) return u;
    let d = [
            Ie,
            kn,
            at(s.handle, s.endpoint, s.cluster)
        ],
        f;
    try {
        let e = await r.getConfirmed ? .([
            Oe,
            Ze(s.handle, s.endpoint, s.cluster),
            ...d,
            ...u.handoffEnded && Wo(l) ? Object.keys(l.baseline) : []
        ]);
        if (!e ? .confirmed || e.coherent === !1) return u;
        f = e.values;
    } catch {
        return u;
    }
    if (e.signal.aborted || !k_(e.store, t.chatterToken, t.sessionToken) && !k_(e.store, o.chatterToken, o.sessionToken)) return {
        kind: "unavailable"
    };
    let p = e.store.getState(),
        m = k_(e.store, t.chatterToken, t.sessionToken) ? p.session : s,
        h = Br(m, {}, {
            ...r,
            get: (e) => f[e] ? ? null
        }),
        g = [m, h ? {
            ...m,
            ...h
        } : m].find((e) => _a(s, e));
    if (g ? .messagingToken && g.messagingTokenExpiresAt) return {
        kind: "exchange_disabled",
        credential: {
            messagingToken: g.messagingToken,
            messagingTokenExpiresAt: g.messagingTokenExpiresAt,
            sessionRefreshToken: g.sessionRefreshToken,
            refreshGeneration: g.refreshGeneration ? ? void 0,
            sessionCookieIssued: g.sessionCookieIssued
        }
    };
    if (u.handoffEnded && Wo(l)) {
        if (Mr(l, p, f)) return {
            kind: "terminal",
            handoffEnded: l
        };
        try {
            await r.refresh ? .(Object.keys(l.baseline));
        } catch {}
        if (e.signal.aborted) return {
            kind: "unavailable"
        };
        f = Object.fromEntries(d.map((e) => [e, r.get(e)]));
    }
    let _ = e.store.getState().liveAgent;
    return _.inLiveChat || _.inPending || d.some((e) => fr(f[e])) ? u : {
        kind: "terminal"
    };
}
async function O_(e, t, n) {
    let r = e.store.getState().session,
        i = await ra({
            ...r,
            ...t
        }, n);
    if (e.signal.aborted || !k_(e.store, r.chatterToken, r.sessionToken)) return {
        kind: "unavailable"
    };
    let a = Se(n.get(Ze(r.handle ? ? "", r.endpoint, r.cluster))) ? ? Se(n.get(Ka(r.handle ? ? ""))),
        o = a ? .chatterToken === t.chatterToken && a.sessionToken === t.sessionToken && a.sessionTokenExpiresAt !== null && a.sessionTokenExpiresAt <= Date.now(),
        s = fo.rejectedCredentialsFor(e.store).has(t.chatterToken, i, t.sessionToken);
    if (i && !o && !s) return {
        kind: "success",
        credential: i
    };
    let c = await D_(e, t, "bootstrap", n, o ? "other" : s ? "credential_rejected" : "no_credential", s ? i ? .refreshGeneration ? ? null : null);
    return c.kind === "exchange_disabled" ? c.credential ? {
        kind: "success",
        credential: c.credential
    } : {
        kind: "unavailable"
    } : c;
}

function k_(e, t, n) {
    return Pi({
        chatterToken: t,
        sessionToken: n
    }, e);
}
async function A_(e, t, n, r, i, a, o, s) {
    let c = {
            sessionRefreshToken: a,
            refreshGeneration: o
        },
        l = fo.rejectedCredentialsFor(e);
    if (fo.rejectedSessionPairsFor(e).has(i, r, o ? ? 0)) return "session_dead";
    if (l.has(r, c, i)) return "invalid_refresh_token";
    let u = {
            ...e.getState().session,
            chatterToken: r,
            sessionToken: i,
            sessionRefreshToken: a,
            refreshGeneration: o
        },
        d = nr([s], rt);
    try {
        let o = await fo.requestMessagingRefresh({
            endpoint: Bg(t),
            headers: {
                ...n,
                "Content-Type": "application/json",
                "Session-Auth": i,
                "Session-Auth-Refresh": a
            },
            trigger: Dg,
            session: u,
            api: e,
            cookieFirst: Ya(e, u),
            signal: d.signal,
            timeoutPromise: d.timeoutPromise,
            source: "websocket",
            isCurrent: () => k_(e, r, i)
        });
        if (typeof o == "string") return o;
        if (o) return e.dispatch(rs({
            token: o.messagingToken,
            expiresIn: o.expiresIn,
            sessionRefreshToken: o.sessionRefreshToken,
            refreshGeneration: o.refreshGeneration,
            sessionCookieIssued: o.sessionCookieIssued
        })), o.messagingToken;
    } catch {
        R("messaging_jwt_refresh", {
            trigger: Dg,
            result: "error"
        }), wg.warn("messaging token refresh failed");
    } finally {
        d.cleanup();
    }
    return null;
}

function j_(e) {
    return !e.websocket_endpoint && (e.pusher_fallback_allowed === !1 || !e.pusher_key.trim());
}
async function M_(e, t, n = null) {
    if (e.signal.aborted) return {
        kind: "aborted"
    };
    let r = fo.waitForCredentialRecovery(e.store, e.signal);
    if (r) {
        let t = await r;
        if (e.signal.aborted || t === "aborted") return {
            kind: "aborted"
        };
        if (t === "cleared") return {
            kind: "terminated"
        };
        if (t === "unconfirmed") return {
            kind: "deferred"
        };
    }
    let i = e.store.getState().session;
    if (fo.rejectedCredentialsFor(e.store).has(i.chatterToken, i, i.sessionToken)) {
        let t = await io({
            chatterToken: i.chatterToken,
            refreshGeneration: i.refreshGeneration,
            resumeTokenSync: !0
        });
        if (e.signal.aborted || !k_(e.store, i.chatterToken, i.sessionToken) || t === "aborted") return {
            kind: "aborted"
        };
        if (t === "unconfirmed") return {
            kind: "deferred"
        };
    }
    let a = j_(t),
        o = e.store.getState(),
        s = o.session;
    if (a && (((e.transport.status ? ? o.connection.transportStatus) !== "disconnected" || o.connection.transportConnectedSeq > 0) && (e.store.dispatch(pa()), e.transport.disconnect ? .()), e.store.dispatch(Ia("connecting"))), (t.websocket_endpoint || a) && !Cr(s) && await fo.restoreRefreshCredential({
            getState: e.store.getState,
            dispatch: e.store.dispatch,
            signal: e.signal
        }), e.signal.aborted) return {
        kind: "aborted"
    };
    let c = e.store.getState(),
        {
            endpoint: l,
            chatterToken: u,
            sessionToken: d,
            sessionRefreshToken: f,
            messagingToken: p,
            refreshGeneration: m,
            identitySession: h,
            mode: g
        } = c.session;
    if (!u) return {
        kind: "terminated"
    };
    if (!k_(e.store, s.chatterToken, s.sessionToken)) return {
        kind: "aborted"
    };
    if (a) return e.store.dispatch(Ia("connecting")), {
        kind: "deferred",
        appReady: !0
    };
    let _ = e.transport;
    if (t.websocket_endpoint && _ instanceof dg) {
        let t = new Cg();
        t.setTokenGetter(() => e.store.getState().session.messagingToken ? ? ""), e.setTransport(t), _ = t;
    } else if (!t.websocket_endpoint && _ instanceof Cg) {
        let t = new dg();
        e.setTransport(t), _ = t;
    }
    if (t.websocket_endpoint) {
        let {
            messagingTokenExpiresAt: r
        } = c.session, i = p && r && r > Date.now() + 6e4, a = m, o = i ? p : null;
        if (!o && l) {
            let t = await w_(e.store, l, u, d, f, m, e.signal);
            o = t.token, a = t.refreshGeneration, e.store.dispatch(z());
        }
        if (o === "invalid_refresh_token" && !h) {
            let t = await fo.recoverRejectedCredential({
                ...c.session,
                refreshGeneration: a
            }, {
                "X-Ada-Request-Origin": "chat"
            }, e.store, "ws_connect");
            if (e.signal.aborted) return {
                kind: "aborted"
            };
            switch (t) {
                case "recovered":
                case "superseded":
                    {
                        let t = e.store.getState().session;
                        if (!k_(e.store, u, d)) return {
                            kind: "aborted"
                        };
                        if (!Cr(t)) return {
                            kind: "deferred"
                        };
                        o = t.messagingToken;
                        break;
                    }
                case "cleared":
                    return {
                        kind: "terminated"
                    };
                case "unconfirmed":
                    return {
                        kind: "deferred"
                    };
                case "aborted":
                    if (!s.sessionRefreshToken) return {
                        kind: "aborted"
                    };
                    break;
            }
            if (!e.store.getState().session.chatterToken) return {
                kind: "terminated"
            };
        }
        if (!o && l && !f && !h && u && d) {
            let t = ln(e.store.getState().session),
                r = await D_(e, {
                    chatterToken: u,
                    sessionToken: d
                }, "ws_connect", void 0);
            if (e.store.dispatch(z()), e.signal.aborted || !k_(e.store, u, d)) return {
                kind: "aborted"
            };
            if ((r.kind === "success" || r.kind === "exchange_disabled") && r.credential && Xn(r.credential.messagingToken, u)) {
                if (r.refreshed || e.store.dispatch(ji({
                        token: r.credential.messagingToken,
                        expiresIn: Math.max(0, Math.round((r.credential.messagingTokenExpiresAt - Date.now()) / 1e3)),
                        sessionRefreshToken: r.credential.sessionRefreshToken,
                        refreshGeneration: r.credential.refreshGeneration,
                        sessionCookieIssued: r.credential.sessionCookieIssued
                    })), o = e.store.getState().session.messagingToken ? ? null, r.kind === "exchange_disabled") return {
                    kind: "deferred"
                };
                r.refreshed || R("messaging_jwt_exchange", {
                    trigger: "ws_connect",
                    result: "success"
                });
            } else if (r.kind === "terminal") return R("messaging_jwt_exchange", {
                trigger: "ws_connect",
                result: "terminal",
                handoffEnded: !!r.handoffEnded
            }), {
                kind: "terminated",
                terminalInfo: {
                    chatterToken: u,
                    refreshGeneration: m,
                    sessionAuthDead: !0,
                    rejectedSession: t,
                    staleAuthBaseline: n,
                    ...r.handoffEnded ? {
                        handoffEnded: r.handoffEnded
                    } : {}
                }
            };
            else return R("messaging_jwt_exchange", {
                trigger: "ws_connect",
                result: r.kind === "success" ? "invalid_response" : "unavailable"
            }), {
                kind: "deferred"
            };
        }
        if (e.signal.aborted || !k_(e.store, u, d)) return {
            kind: "aborted"
        };
        if (o === "session_dead" || o === "invalid_refresh_token") return {
            kind: "terminated",
            terminalInfo: {
                chatterToken: u,
                refreshGeneration: o === "session_dead" ? fo.rejectedSessionPairsFor(e.store).getRefreshGeneration(d, u) ? ? m : a
            }
        };
        if (!o) {
            if (!f) return {
                kind: "terminated"
            };
            throw R("websocket_token_connect_failed", {
                reason: "messaging_token_unavailable"
            }), Error("CoreOrchestrator: unable to obtain messaging token for WebSocket transport");
        }
        await _.connect({
            key: t.websocket_endpoint,
            authHeaders: {
                ...o ? {
                    "Chat-Token": o
                } : {},
                ...d ? {
                    "Session-Auth": d
                } : {},
                "X-Ada-Client-Handle": t.handle,
                "X-Ada-Request-Origin": "chat"
            },
            debug: g === "dev" || g === "test"
        });
    } else await _.connect({
        key: t.pusher_key,
        cluster: t.pusher_cluster,
        authEndpoint: l ? `${l}auth/pusher/chatter/multi/` : void 0,
        onSessionExpired: () => {
            let t = e.store.getState().session;
            if (e.signal.aborted || !t.sessionToken || t.chatterToken !== u || t.sessionToken !== d) return;
            let r = e.claimPusherSessionRecovery ? .(t.sessionToken);
            r !== !1 && Promise.resolve().then(() => io({
                chatterToken: u,
                refreshGeneration: t.refreshGeneration,
                sessionAuthDead: !0,
                rejectedSession: ln(t),
                staleAuthBaseline: n,
                recoveryTrigger: "pusher_session_expired"
            })).then(async (t) => {
                t === "cleared" && !e.signal.aborted && await e.onPusherSessionCleared ? .() ? r ? .commit() : r ? .release();
            }).catch((e) => {
                wg.error("Pusher session recovery failed:", e), r ? .release();
            });
        },
        authHeaders: {
            ...u ? {
                "Chatter-Token": u
            } : {},
            ...d ? {
                "Session-Auth": d
            } : {},
            "X-Ada-Request-Origin": "chat"
        },
        debug: g === "dev" || g === "test"
    });
    if (e.store.dispatch(z()), e.signal.aborted) {
        e.store.dispatch(pa());
        try {
            _.disconnect ? .();
        } catch {}
        return {
            kind: "aborted"
        };
    }
    return R("transport_connected"), {
        kind: "activated"
    };
}
async function N_(e) {
    if (W(e.signal), e.startupState.client) return e.startupState.client;
    if (!e.startupState.publicClientPromise) {
        let t = (async () => {
            e.startupClock ? .setLastStep("chat_public_config_start"), R("chat_public_config_start");
            let t = await o_(e);
            return W(e.signal), e.startupState.client = t, d_(e.store, t), f_(e.store), e.startupClock ? .setLastStep("chat_public_config_complete"), R("chat_public_config_complete"), t;
        })();
        e.startupState.publicClientPromise = t;
    }
    let t = e.startupState.publicClientPromise;
    try {
        let n = await t;
        return W(e.signal), n;
    } catch (n) {
        throw e.startupState.publicClientPromise === t && (e.startupState.publicClientPromise = null), n;
    }
}
async function P_(e, t, n = {}) {
    if (W(e.signal), !e.startupState.transportConfigPromise) {
        let r = (async () => {
            let r = await u_(e, t, n);
            return W(e.signal), e.startupState.client = r, r;
        })();
        e.startupState.transportConfigPromise = r;
    }
    let r = e.startupState.transportConfigPromise;
    try {
        let t = await r;
        return W(e.signal), t;
    } catch (t) {
        throw e.startupState.transportConfigPromise === r && (e.startupState.transportConfigPromise = null), t;
    }
}
async function F_(e) {
    try {
        return await N_(e);
    } catch (e) {
        if (H(e)) return null;
        throw e;
    }
}

function I_(e, t, n) {
    return new Cn(e.store, t, n, {
        zdmStorage: t.zdmContinuityStorage,
        isCurrentPersistence: (t) => e.startupState.persistence === t,
        handoffOnlyPersistence: t.mode === "session" && R_(e),
        createChatter: (n) => m_(e.store, n, t.mode, e.zendeskChatAuth),
        validateRestoredSession: (t, n) => T_(e.store.getState().session.endpoint, t, n),
        exchangeMessagingSession: (t, n, r) => O_({
            store: e.store,
            signal: n
        }, t, r)
    });
}

function L_(e) {
    bo(e.store, {
        isEligible: (t) => e.startupState.persistence ? .canRecoverSessionCookie(t) ? ? !1,
        persist: async (t, n, r) => {
            let i = e.startupState.persistence;
            return i ? .persistRecoveredSessionCookie(t, n, () => !e.signal.aborted && e.startupState.persistence === i && r()) ? ? !1;
        }
    }), Jr(async (t) => {
        let n = e.startupState.persistence,
            r = e.store.getState().session,
            i = t ? t.chatterToken : r.chatterToken,
            a = t ? t.refreshGeneration : r.refreshGeneration ? ? null;
        if (t ? .sessionAuthDead) {
            let a = t.rejectedSession ? ? ln(r);
            if (n && t.handoffEnded) {
                let r = await n.clearEndedExchangeHandoff(a, t.handoffEnded, e.signal, () => {
                    pc(e.store), Uo(e.store);
                });
                if (e.signal.aborted || e.startupState.persistence !== n) return "aborted";
                if (r === "aborted" || r === "superseded") return r;
            }
            let o = async () => {
                    let t = await n ? .getConfirmedHandoff(i),
                        r = e.store.getState();
                    return t && [ln(r.session), ...t.owners].every((e) => !e.credential || e.credential === a.credential) && T({
                        expected: a,
                        shared: t,
                        current: {
                            ...ln(r.session),
                            inHandoff: r.liveAgent.inLiveChat || r.liveAgent.inPending
                        },
                        isCurrent: !e.signal.aborted && e.startupState.persistence === n
                    });
                },
                s = await n ? .clearDeadResumedSession(i, t.rejectedSession, e.signal, t.staleAuthBaseline);
            if (e.startupState.persistence !== n) return "aborted";
            if (s !== !0) return "unconfirmed";
            if (!await o()) return n ? .startTokenSync(), "superseded";
            let c = await e.startupState.sessionMirror ? .clearMirror({
                awaitAck: !0
            });
            if (e.startupState.persistence !== n) return "aborted";
            if (e.signal.aborted) return "superseded";
            if (c === !1) try {
                R("messaging_session_mirror_clear_unconfirmed", {
                    reason: "dead_session_drop"
                });
            } catch {}
            return await o() ? (e.store.dispatch(Gr()), c === !1 ? "unconfirmed" : (!e.startupState.activatePromise && t.recoveryTrigger !== "pusher_session_expired" && e.onSessionDropped ? .(t.recoveryTrigger ? ? "rest_dead_session"), "cleared")) : (n ? .startTokenSync(), "superseded");
        }
        let o = r.refreshGeneration;
        if (typeof o == "number" && o > (a ? ? -1)) return "superseded";
        n ? .stopTokenSync();
        let s = !1;
        try {
            s = await n ? .clearDeadMessagingCredential(i, a, t ? .onSessionTokenResolved) === !0;
        } catch (e) {
            P(e, {
                context: "session_terminal_clear_failed"
            });
        }
        if (e.startupState.persistence !== n) return "aborted";
        let c = e.store.getState().session,
            l = c.refreshGeneration;
        return c.chatterToken !== i || typeof l == "number" && l > (a ? ? -1) ? (n ? .startTokenSync(), "superseded") : (e.store.dispatch(br()), t ? .resumeTokenSync && n ? .startTokenSync(), s ? "cleared" : "unconfirmed");
    });
}

function R_(e) {
    return !e.privateMode && e.store.getState().session.persistence === "private";
}

function z_(e, t) {
    let n = e.store.getState().session;
    return t || (e.privateMode ? "private" : R_(e) ? "session" : n.identityToken && n.persistence === "normal" ? n.nativeSessionMirror ? "normal" : "session" : n.persistence);
}

function B_(e, t) {
    e.startupState.persistence === t && (t.stopTokenSync(), V_(e), e.onReleasePersistenceStorage ? .(), e.startupState.persistence = null, e.startupState.persistencePromise = null);
}

function V_(e) {
    e.startupState.sessionMirror ? .destroy(), e.startupState.sessionMirrorRelease ? .(), e.startupState.sessionMirror = null, e.startupState.sessionMirrorRelease = null;
}

function H_(e) {
    if (typeof document > "u" || typeof window > "u") return () => void 0;
    let t = () => {
            document.visibilityState === "hidden" && e.flush();
        },
        n = () => {
            e.flush();
        };
    return document.addEventListener("visibilitychange", t), window.addEventListener("pagehide", n), () => {
        document.removeEventListener("visibilitychange", t), window.removeEventListener("pagehide", n);
    };
}
async function U_(e, t, n, r = {}) {
    V_(e);
    let i = e.store.getState().session;
    if (!i.nativeSessionMirror) return;
    let {
        endpoint: a,
        cluster: o
    } = i, s = Uh({
        storage: t,
        writeSharedSnapshot: (t, n, r) => e.startupState.persistence ? .writeSharedSnapshot(t, n, r) ? ? !1,
        scopeKey: Rt(n, a, o),
        allowedKeys: Ct(n, a, o),
        primarySessionKey: Ze(n, a, o),
        mode: t.mode,
        emitFrameEvent: or,
        writesArmed: !1,
        onEmitDropped: (e) => {
            try {
                R("messaging_session_mirror_emit_dropped", {
                    reason: e
                });
            } catch {}
        }
    });
    e.startupState.sessionMirror = s;
    let c = H_(s),
        l = Kt(s);
    e.startupState.sessionMirrorRelease = () => {
        c(), l();
    };
    let u = r.issueSeedRequest !== !1,
        d;
    if (u && t.mode === "normal" && !i.identityToken) try {
        d = await s.requestSeed();
    } catch {
        return;
    }
    let f = await s.adoptSeed(d, {
        identityTokenPresent: !!i.identityToken
    });
    if (f && u) try {
        R("messaging_session_mirror_adoption", {
            outcome: f.outcome
        });
    } catch {}
    if (e.startupState.sessionMirror === s) {
        if (!u) {
            Va(s.scopeKey);
            return;
        }
        s.armWrites();
    }
}

function W_(e) {
    let t = e.startupState.persistence;
    t && B_(e, t);
}
async function G_(e, t = {}) {
    if (!e.startupState.persistencePromise) {
        let n = (async () => {
            let n = e.store.getState().session,
                r = z_(e, t.storageModeOverride),
                i = r === "session" && R_(e),
                a = i && (!t.storageModeOverride || t.storageModeOverride === z_(e)),
                o = !t.storageModeOverride && !i && !!n.identityToken && (r === "session" || r === "normal" && n.nativeSessionMirror === !0),
                s = !0;
            !e.createPersistenceStorage && o && (s = await as(n.handle ? ? "", n.endpoint, n.cluster));
            let c = e.createPersistenceStorage ? await e.createPersistenceStorage(r, {
                clearNormalIdentityStorage: o,
                ...i ? {
                    handoffOnly: i
                } : {},
                ...a ? {
                    degradeWhenUnconfirmed: a
                } : {}
            }, e.signal) : Xi(s ? r : "private");
            e.store.dispatch(z());
            let {
                handle: l
            } = e.store.getState().session;
            if (!l) throw Error("CoreOrchestrator: handle not set when creating persistence service");
            W(e.signal);
            let u = I_(e, c, l);
            e.startupState.persistence = u;
            let d = Io();
            return d && se(u.guardStorageWriters(d)), await U_(e, c, l, {
                issueSeedRequest: !t.skipSeedRequest
            }), W(e.signal), {
                persistence: u,
                storage: c,
                degradedFrom: c.degradedFrom,
                handle: l,
                clearNormalIdentityStorage: o
            };
        })();
        e.startupState.persistencePromise = n;
    }
    let n = e.startupState.persistencePromise,
        r = null;
    try {
        let i = await n;
        if (r = i, W(e.signal), t.storageModeOverride && i.storage.mode !== t.storageModeOverride && i.degradedFrom !== t.storageModeOverride) throw B_(e, i.persistence), Error("CoreOrchestrator: exact reset persistence scope changed during startup");
        return i;
    } catch (t) {
        throw r && B_(e, r.persistence), e.startupState.persistencePromise === n && (e.startupState.persistencePromise = null, e.startupState.persistence = null), t;
    }
}
async function K_(e, t, n = {}) {
    if (!e.store.getState().session.clearPersistenceOnPrepare) return !0;
    if (!e.startupState.persistenceClearPromise) {
        let r = (async () => {
            try {
                let r = e.store.getState().session,
                    i = r.chatterToken ? ln(r) : void 0,
                    a = z_(e),
                    o = r.clearPersistenceStorageModes,
                    s;
                s = e.privateMode ? ["private"] : !n.clearAllPersistentModes && R_(e) ? r.clearPersistenceOutgoingStorageMode === "normal" ? ["normal", "session"] : ["session"] : o.length > 0 && !n.clearAllPersistentModes ? [...o, a] : ["normal", "session"];
                let c = [...new Set(s)];
                c.sort((e, t) => e === a ? 1 : t === a ? -1 : 0);
                for (let n of c) {
                    let r = e.startupState.persistence;
                    r && r.storageMode !== n && B_(e, r);
                    let {
                        persistence: o
                    } = await G_(e, {
                        storageModeOverride: n,
                        skipSeedRequest: !0
                    });
                    W(e.signal);
                    let s = await o.clearDurably(e.signal, t, n === "private" ? void 0 : async (t) => {
                        (t.chatterToken || t.sessionToken) && (i ? ? = t);
                        let r = e.store.getState().session;
                        return await g(r.handle ? ? "", r.endpoint, r.cluster, {
                            clearMessagingAuthState: !0,
                            expected: t,
                            mode: n
                        }) ? await e.startupState.sessionMirror ? .clearMirrorDurably() !== !1 : !1;
                    }, i);
                    if (W(e.signal), e.store.dispatch(z()), !s) return !1;
                    n !== a && B_(e, o);
                }
                if (r.endpoint) {
                    try {
                        await ui(r.endpoint, e.signal);
                    } catch (t) {
                        e.signal.aborted || P(t, {
                            source: "session_cookie_clear"
                        });
                    }
                    W(e.signal);
                }
                return e.startupState.sessionMirror ? .armWrites(), e.store.dispatch(to()), !0;
            } catch (e) {
                return H(e) || wg.warn("Persisted conversation clear could not be confirmed", e), !1;
            }
        })();
        e.startupState.persistenceClearPromise = r, r.finally(() => {
            e.startupState.persistenceClearPromise === r && (e.startupState.persistenceClearPromise = null);
        });
    }
    return e.startupState.persistenceClearPromise;
}

function q_(e) {
    let t = e.store.getState().session;
    return !e.privateMode && t.persistence !== "private" && !t.identityToken && !t.clearPersistenceOnPrepare;
}

function J_(e, t) {
    e.store.dispatch(pt({
        userTheme: Ae(t.storage.get(Re(t.handle))),
        userTextSize: jn(t.storage.get(me(t.handle)))
    }));
}
var Y_ = /* @__PURE__ */ new WeakSet();

function X_(e, t) {
    if (t.aborted || Y_.has(e)) return;
    let n = /* @__PURE__ */ new Set(),
        r = !1,
        i = !1,
        a, o = null,
        s = (e) => {
            i || (i = !0, wg.error("Failed to fetch CSAT settings for transcript surveys:", e));
        },
        c = () => {
            try {
                if (t.aborted) return;
                let {
                    chat: c,
                    session: l
                } = e.getState();
                if (c.messages === a ? .messages && c.csatSettings === a ? .csatSettings && c.csatBotSettings === a ? .csatBotSettings && l.chatterToken === o) return;
                if (l.chatterToken !== o && (n.clear(), r = !1, i = !1), o = l.chatterToken, !l.chatterToken || !l.endpoint) {
                    a = void 0;
                    return;
                }
                a = c;
                let u = !1,
                    d = !1,
                    f = !1,
                    p = /* @__PURE__ */ new Set();
                for (let e of c.messages) p.add(e.id), n.has(e.id) || (u = !0), e.type === "csat" && !e.submitted && e.score === null && jo(e.surveyType) && (d = c.csatSettings === null), e.type === "csat" && !e.submitted && e.score === null && !jo(e.surveyType) && (f = c.csatBotSettings === null);
                n = p;
                let m = [];
                c.csatBotSettings === null && (!r || f && u) && m.push("bot"), d && u && m.push("agent");
                for (let t of m) try {
                    ga(e, t) && t === "bot" && (r = !0);
                } catch (e) {
                    t === "bot" && (r = !0), s(e);
                }
            } catch (e) {
                s(e);
            }
        },
        l = e.subscribe(c);
    Y_.add(e), t.addEventListener("abort", () => {
        l(), Y_.delete(e);
    }, {
        once: !0
    }), c();
}
async function Z_(e, t, n) {
    return e.store.getState().session.chatterToken !== n || (await e.zendeskChatAuth ? .authenticate(e.signal), W(e.signal), e.store.getState().session.chatterToken !== n) || (e.startupState.persistence ? .hasPendingRestoredChatter() === !0 && (await p_(e), W(e.signal)), e.store.getState().session.chatterToken !== n) ? !1 : (X_(e.store, e.signal), C_(e.store), e.onConfigureGreeting(t), await e.onLoadTranslations(void 0, e.signal), W(e.signal), e.store.getState().session.chatterToken === n);
}
async function Q_(e) {
    try {
        if (await N_(e), W(e.signal), !q_(e)) return null;
        let {
            persistence: t
        } = await G_(e);
        if (W(e.signal), !q_(e)) return null;
        let n = await t.getExistingChatterNotificationCandidate(e.signal);
        return n.kind === "candidate" ? n.chatterToken : null;
    } catch (e) {
        if (H(e)) return null;
        throw e;
    }
}
async function $_(e) {
    try {
        if (await N_(e), W(e.signal), !q_(e)) return !1;
        let {
            persistence: t
        } = await G_(e);
        if (W(e.signal), !q_(e)) return !1;
        let n = await t.hasPersistedChatter(e.signal);
        return W(e.signal), q_(e) && n;
    } catch (e) {
        if (H(e)) return !1;
        throw e;
    }
}
async function ev(e, t = {}) {
    W(e.signal);
    let n = e.store.getState().session,
        r = !!n.identityToken && !(n.chatterToken && n._chatterPersistenceAnnouncementPending);
    if (!n.isParentElementMode || e.hostTelemetry ? .mobileShell === "messaging-sdk" || document.visibilityState !== "hidden" || r && (await (e.prepareRestoreOnly ? e.prepareRestoreOnly(t) : rv(e, {
            ...t,
            restoreOnly: !0
        })), W(e.signal), document.visibilityState !== "hidden")) return !1;
    if (e.startupClock ? .dispose(), e.startupState.visibilityWait ? .signal === e.signal) return e.startupState.visibilityWait.promise;
    let i = Date.now();
    he("engaged"), R("chat_start_waiting_for_visible"), e.store.dispatch(u(!0));
    let a = new Promise((t) => {
        let n = () => {
                document.removeEventListener("visibilitychange", r), window.removeEventListener("pageshow", r), e.signal.removeEventListener("abort", n), e.startupState.visibilityWait = void 0, e.store.dispatch(u(!1)), t();
            },
            r = () => {
                document.visibilityState !== "hidden" && n();
            };
        document.addEventListener("visibilitychange", r), window.addEventListener("pageshow", r), e.signal.addEventListener("abort", n, {
            once: !0
        });
    }).then(() => (W(e.signal), R("chat_start_waited_for_visible", {
        wait_ms: Date.now() - i
    }), !0));
    return e.startupState.visibilityWait = {
        signal: e.signal,
        promise: a
    }, a;
}
async function tv(e, t, n = {}) {
    if (!t || !q_(e)) return !1;
    try {
        let r = await N_(e);
        if (W(e.signal), !q_(e)) return !1;
        let i;
        n.identitySession && (i = e.store.getState().session.nativeSessionMirror ? "normal" : "session");
        let a = await G_(e, {
                storageModeOverride: i
            }),
            {
                persistence: o
            } = a;
        if (W(e.signal), !q_(e) || (await o.restoreExistingChatter(t, e.signal, {
                requireIdentitySession: n.identitySession === !0
            })).kind !== "restored" || (W(e.signal), e.store.getState().session.chatterToken !== t)) return !1;
        L_(e);
        let s = await P_(e, r);
        W(e.signal);
        let c = await o.getExistingChatterCandidate(e.signal);
        if (c.kind !== "candidate" || c.chatterToken !== t || n.identitySession && !c.identitySession || e.store.getState().session.chatterToken !== t || (W(e.signal), J_(e, a), !await Z_(e, s, t))) return !1;
        let l = await o.getExistingChatterCandidate(e.signal);
        return l.kind !== "candidate" || l.chatterToken !== t || n.identitySession && !l.identitySession || e.store.getState().session.chatterToken !== t || (W(e.signal), e.store.getState().session.chatterToken !== t) ? !1 : (R("chat_background_resume_restored"), !0);
    } catch (e) {
        if (H(e)) return !1;
        throw e;
    }
}
async function nv(e, t, n = {}) {
    return e.startupState.backgroundResumePreparedChatterToken !== t || e.store.getState().session.chatterToken !== t ? (e.startupState.backgroundResumePreparedChatterToken === t && (e.startupState.backgroundResumePreparedChatterToken = null), !1) : (await y_(e, "background-resume-startup-meta-fields", {
        throwOnError: n.throwOnError,
        applySessionLanguage: !0
    }), W(e.signal), e.startupState.backgroundResumePreparedChatterToken !== t || e.store.getState().session.chatterToken !== t ? !1 : (e.startupState.backgroundResumePreparedChatterToken = null, e.startupState.isPrepared = !0, R("chat_background_resume_prepare_complete"), !0));
}
async function rv(e, t = {}) {
    if (t.restoreOnly || (he("engaged"), e.startupState.initStartSignal !== e.signal && (e.startupState.initStartSignal = e.signal, R("chat_init_start", {
            host_visibility: t.hostVisibility ? ? (typeof document > "u" ? "unknown" : document.visibilityState),
            waited_for_visible: t.waitedForVisible === !0
        }))), e.startupState.isPrepared || t.restoreOnly && e.startupState.backgroundResumePreparedChatterToken && e.startupState.backgroundResumePreparedChatterToken === e.store.getState().session.chatterToken) return;
    if (!e.startupState.preparePromise) {
        let n = e.beginStartupTracking(),
            r = (async (e) => {
                let n = e.startupState.backgroundResumePreparedChatterToken;
                if (n && await nv(e, n)) return;
                t.restoreOnly || e.startupClock ? .setLastStep("chat_init_start");
                let r = await N_(e);
                e.startupClock ? .setLastStep("chat_transport_config");
                let i = await P_(e, r);
                if (W(e.signal), e.store.getState().session.clearPersistenceOnPrepare) {
                    let t = await K_(e, e.store.getState().session.clearPersistenceAckRequestId ? ? void 0);
                    if (W(e.signal), !t) throw Error("CoreOrchestrator: persisted session clear could not be confirmed before restore");
                }
                e.startupClock ? .setLastStep("chat_session_restore");
                let {
                    persistence: a,
                    storage: o,
                    handle: s,
                    clearNormalIdentityStorage: c
                } = await G_(e);
                L_(e), J_(e, {
                    storage: o,
                    handle: s
                });
                let l = e.store.getState().session,
                    u = !!(l.chatterToken && l._chatterPersistenceAnnouncementPending),
                    d = u && l.identitySession;
                if (d && l.identityTokenFailureReason) throw Error("CoreOrchestrator: identified chatter persistence previously failed");
                if (!u && l.identityToken) {
                    let n = ln(e.store.getState().session);
                    try {
                        if (c && o.mode !== "session" && !(o.mode === "normal" && e.store.getState().session.nativeSessionMirror === !0)) throw new Qg("CoreOrchestrator: shared identity storage could not be cleared", Ag);
                        try {
                            await v_(e.store, e.signal);
                        } finally {
                            e.store.dispatch(z());
                        }
                        W(e.signal), d = !0, a.stageIdentifiedSessionForRestore(n), e.startupState.sessionMirror ? .noteIdentityExchangeResolved();
                    } catch (r) {
                        if (H(r)) throw r;
                        let i = b_(r);
                        wg.warn("Identity token exchange failed; starting an anonymous session", r), P(x_(r), {
                            context: "identity-token-exchange"
                        }), e.store.dispatch(za({
                            reason: i
                        }));
                        let o = await a.clearAllStorage(n) && await a.ensureAllStorageCleared(e.signal);
                        e.store.dispatch(z()), o || wg.warn("Identity-sensitive session storage could not be fully cleared"), await e.startupState.sessionMirror ? .noteIdentityExchangeFailed() === !1 && wg.warn("Native session mirror clear was not acknowledged after a failed identity exchange; a surviving blob may be adopted on the next boot"), V_(e), W(e.signal);
                        let c = e.createPersistenceStorage ? await e.createPersistenceStorage("private", void 0, e.signal) : Xi("private");
                        e.store.dispatch(z()), e.createPersistenceStorage || se(c);
                        let l = new Cn(e.store, c, s, {
                            createChatter: (t) => m_(e.store, t, c.mode, e.zendeskChatAuth),
                            validateRestoredSession: (t, n) => T_(e.store.getState().session.endpoint, t, n),
                            exchangeMessagingSession: (t, n, r) => O_({
                                store: e.store,
                                signal: n
                            }, t, r)
                        });
                        if (e.startupState.persistence = l, e.startupState.persistencePromise = Promise.resolve({
                                persistence: l,
                                storage: c,
                                handle: s,
                                clearNormalIdentityStorage: !1
                            }), d = !1, (await iv(e, l, t)).kind === "needsCreation") return;
                    }
                } else if (!u) {
                    let n = await a.confirmAndAdoptRestoreSnapshot(e.signal);
                    if (W(e.signal), !n) throw Error("CoreOrchestrator: persisted session snapshot could not be confirmed");
                    if ((await iv(e, a, t)).kind === "needsCreation") return;
                    a.hasPendingRestoredChatter() && (await y_(e, "restored-chatter-startup-meta-fields", {
                        throwOnError: t.throwOnStartupDataSyncError,
                        applySessionLanguage: !0
                    }), e.store.dispatch(z()));
                }
                let f = null,
                    p = e.store.getState().session;
                if (p._chatterPersistenceAnnouncementPending) {
                    let n = p.chatterToken,
                        r = e.startupState.persistence,
                        i = !1;
                    try {
                        i = n && r ? await r.ensureCurrentSessionPersisted(e.signal) : !1;
                    } catch (t) {
                        throw W(e.signal), d && S_(e, n), t;
                    }
                    if (W(e.signal), !i || !n) throw d && S_(e, n), Error("CoreOrchestrator: new chatter could not be durably persisted before announcement");
                    f = n, d && (r ? .persistsNothingNow() || (e.store.dispatch(hi({
                        chatterToken: n
                    })), W(e.signal)), await y_(e, "identity-token-startup-meta-fields", {
                        allowSuppressedChatter: !0,
                        applySessionLanguage: !0,
                        throwOnError: t.throwOnStartupDataSyncError
                    }), e.store.dispatch(z()));
                }
                W(e.signal);
                let m = e.store.getState().session.chatterToken;
                if (!m || !await Z_(e, i, m)) throw Error("CoreOrchestrator: chatter changed during UI preparation");
                e.store.dispatch(z()), W(e.signal);
                let h = Um(e.store, e.signal);
                try {
                    await __(e, {
                        throwOnError: t.throwOnStartupDataSyncError
                    }), W(e.signal), e.store.dispatch(z()), W(e.signal), e.startupState.isPrepared = !0, f && e.store.dispatch(Ca({
                        chatterToken: f
                    }));
                } finally {
                    h();
                }
                e.startupClock ? .setLastStep("chat_prepare_complete"), R("chat_prepare_complete");
            })({
                ...e,
                startupClock: n,
                prepareClock: n
            }).catch((t) => {
                if (H(t)) {
                    R("chat_prepare_superseded"), e.startupState.preparePromise === r && (e.startupState.preparePromise = null);
                    return;
                }
                throw t;
            }).finally(() => n.dispose());
        e.startupState.preparePromise = r;
    }
    let n = e.startupState.preparePromise;
    try {
        await n, !e.startupState.isPrepared && e.startupState.preparePromise === n && (e.startupState.preparePromise = null), !t.restoreOnly && !e.signal.aborted && !e.startupState.isPrepared && await rv(e, t);
    } catch (t) {
        throw e.startupState.preparePromise === n && (e.startupState.preparePromise = null, e.startupState.initStartSignal = void 0), t;
    }
}
async function iv(e, t, n = {}) {
    let r = t.restoreOwningIdentity(e.signal, n);
    fo.setLifecycleAuthBaseline(e.store, t.captureLifecycleAuthBaseline(e.signal), e.signal);
    let i = await r;
    return ov(i), i;
}
var av = class extends Error {
    constructor(e) {
        super(`CoreOrchestrator: prepare holds no persisted session (${e.kind})`), L(this, "refusal", void 0), this.name = "RestoreOwnershipError", this.refusal = e.refusal;
    }
};

function ov(e) {
    if (e.kind === "identity_rotated" || e.kind === "ownership_unresolved" || e.kind === "pre_create_refused" || e.kind === "uncommitted") throw new av(e);
}
async function sv(e, t = {}) {
    if (e.startupState.isActivated) return {
        kind: "activated"
    };
    if (!t.skipPrepare && !e.startupState.isPrepared && await rv(e), e.signal.aborted) return {
        kind: "aborted"
    };
    let n = e.startupState.persistence ? .captureLifecycleAuthBaseline(e.signal) ? ? null;
    fo.setLifecycleAuthBaseline(e.store, n, e.signal);
    let r = e.startupState.client;
    if (!r) throw Error("CoreOrchestrator: missing client config before activation");
    if (X_(e.store, e.signal), j_(r) && !e.startupState.transportConfigPromise) try {
        r = await P_(e, r, {
            retryFailures: !1
        });
    } catch (e) {
        if (H(e)) return {
            kind: "aborted"
        };
        wg.warn("Unable to refresh realtime transport configuration", e);
    }
    if (await e.startupState.persistence ? .restoreRecentConversationHistory(e.signal), e.signal.aborted) return {
        kind: "aborted"
    };
    j_(r) && (e.startupState.transportConfigPromise = null), e.startupState.isActivated = !0;
    try {
        if (await e.zendeskChatAuth ? .authenticate(e.signal), e.signal.aborted) return {
            kind: "aborted"
        };
        let t = await M_(e, r, n);
        if (t.kind === "aborted") return e.startupState.isActivated = !1, {
            kind: "aborted"
        };
        if (t.kind === "deferred") return e.startupState.isActivated = !1, t;
        if (t.kind === "terminated") {
            if (t.terminalInfo) {
                let i = await io(t.terminalInfo);
                if (i === "superseded") {
                    if (t = await M_(e, r, n), t.kind === "aborted") return e.startupState.isActivated = !1, {
                        kind: "aborted"
                    };
                    if (t.kind === "deferred") return e.startupState.isActivated = !1, t;
                    if (t.kind === "activated") return e.onSubscribeToChannel(), e.startupClock ? .setLastStep("chat_init_complete"), R("chat_init_complete"), {
                        kind: "activated"
                    };
                    if (t.terminalInfo) {
                        let n = await io(t.terminalInfo);
                        if (n === "aborted") return e.startupState.isActivated = !1, {
                            kind: "aborted"
                        };
                        if (n === "unconfirmed") throw e.startupState.isActivated = !1, Error("CoreOrchestrator: messaging session terminal but clear unconfirmed during activation");
                    }
                } else if (i === "aborted") return e.startupState.isActivated = !1, {
                    kind: "aborted"
                };
                else if (i === "unconfirmed") throw e.startupState.isActivated = !1, Error("CoreOrchestrator: messaging session terminal but clear unconfirmed during activation");
            }
            return e.startupState.isActivated = !1, {
                kind: "terminated"
            };
        }
        return e.onSubscribeToChannel(), e.startupClock ? .setLastStep("chat_init_complete"), R("chat_init_complete"), {
            kind: "activated"
        };
    } catch (t) {
        if (e.signal.aborted || H(t)) return {
            kind: "aborted"
        };
        throw e.startupState.isActivated = !1, t;
    }
}

function cv(e) {
    e.subscriptionState.retryTimer && (clearTimeout(e.subscriptionState.retryTimer), e.subscriptionState.retryTimer = null), Mh(e), e.subscriptionState.subscriptionTransportStatusCleanup ? .(), e.subscriptionState.subscriptionTransportStatusCleanup = null, e.subscriptionState.subscriptionTransportWasConnected = !1, e.subscriptionState.subscriptionConfirmationReported = !1, e.subscriptionState.confirmedChannels ? .clear();
}
//#endregion
//#region src/init.ts
var lv = 5e3,
    uv = B("init");

function dv(e) {
    try {
        return r_(e.cluster ? ? null, e.endpoint, e.handle, "");
    } catch (e) {
        return uv.warn("Failed to resolve the monitoring cluster; attributing the session to the assets host", e), null;
    }
}

function fv(e, t) {
    ze({
        mode: e.mode ? ? null,
        handle: e.handle,
        cluster: dv(e),
        hostTelemetry: e.hostTelemetry,
        version: "eb157faa62f6aedb4b1659a9563b247e78b9d989"
    });
    let n = Ba();
    if (n.dispatch(kr({
            handle: e.handle,
            cluster: e.cluster,
            endpoint: e.endpoint,
            language: e.language ? ? Ol(),
            languageFromHost: e.language !== void 0,
            hostLanguage: e.language ? ? null,
            greeting: e.greeting,
            configuredGreetingResponseId: e.configuredGreetingResponseId,
            identityToken: e.identityToken,
            appUrl: e.appUrl,
            appUrlFallback: e.appUrlFallback,
            metaFields: e.metaFields,
            metaFieldsBaseline: e.metaFieldsBaseline,
            theme: e.theme,
            hostBranding: Zr(e.branding).branding ? ? null,
            mode: e.mode,
            isParentElementMode: e.isParentElementMode,
            isMobileViewport: e.isMobileViewport,
            hideDefaultHeader: e.hideDefaultHeader,
            allowMetaFieldsInReset: e.allowMetaFieldsInReset,
            enableProgrammaticControl: e.enableProgrammaticControl,
            nativeSessionMirror: e.nativeSessionMirror,
            androidHostNavigation: e.androidHostNavigation,
            clearPersistenceOnPrepare: e.clearPersistenceOnPrepare,
            clearPersistenceAckRequestId: e.clearPersistenceAckRequestId,
            clearPersistenceAckResponseType: e.clearPersistenceAckResponseType,
            clearPersistenceStorageModes: e.clearPersistenceStorageModes,
            clearPersistenceOutgoingStorageMode: e.clearPersistenceOutgoingStorageMode
        })), e.sensitiveMetaFields && Object.keys(e.sensitiveMetaFields).length > 0 && n.dispatch(Vo(e.sensitiveMetaFields)), n.dispatch(xn(I())), e.greetingResponseId !== void 0) {
        let t = typeof e.greetingResponseId == "string" ? e.greetingResponseId.trim() : "";
        n.dispatch(Gt(t || null)), t && n.dispatch(fs());
    }
    e.skipGreeting === !0 && n.dispatch(Le()), (e.skipGreeting === !0 || e.skipGreetingOnce === !0) && n.dispatch(Rn());
    let r;
    r = t || (e.mode === "test" ? new Gh() : e.websocketEndpoint ? new Cg() : new dg());
    let i = null,
        a = !1,
        o = null,
        s = (e) => {
            if (e === "connected") {
                let {
                    liveAgent: e
                } = n.getState();
                o ? .operationSeq === e.zendeskOperationSeq && (hn(n), o.notifyAgent && Date.now() - o.startedAt >= lv && e.platformName === "zendesk_liveagent" && e.inLiveChat && e.zendesk.sdkInitialized && n.dispatch(yi({
                    integration: "zendesk",
                    action: "networkDisruption.notify"
                }))), o = null, a = !0;
            } else {
                let {
                    liveAgent: e
                } = n.getState();
                a && = (o = {
                    operationSeq: e.zendeskOperationSeq,
                    startedAt: Date.now(),
                    notifyAgent: !1
                }, !1), o && !r.reconnectRequestedByServer && e.platformName === "zendesk_liveagent" && e.inLiveChat && e.zendesk.sdkInitialized && (o.notifyAgent = !0);
            }
            i = e === "disconnected" ? r.lastCloseCode ? ? null : null, n.dispatch(Ia(e));
        };
    r.onStatusChange(s);
    let c = Nl({
            store: n
        }),
        l = () => {
            n.dispatch(Oa(!1)), c.check();
        },
        u = () => {
            n.dispatch(Oa(!0)), c.check();
        };
    window.addEventListener("offline", l), window.addEventListener("online", u);
    let d = () => {
            let {
                browserOffline: e,
                connectivityVerdictPending: t
            } = n.getState().connection;
            return e && t && n.getState().session.endpoint !== null;
        },
        f = n.getState().connection.transportUnreachable,
        p = n.getState().connection.connectivityLost,
        m = n.getState().connection.connectivityNoticeRaised,
        h = d(),
        g = n.subscribe(() => {
            let {
                transportUnreachable: e,
                transportStatus: t,
                browserOffline: r,
                connectivityLost: a,
                connectivityNoticeRaised: o
            } = n.getState().connection, s = i;
            i = null;
            let l = e && !f,
                u = a !== p,
                g = d(),
                _ = g && !h;
            f = e, p = a, h = g;
            let v = o && !m;
            if (m = o, l) {
                let e = t === "disconnected" && s !== null ? {
                    closeCode: s
                } : {};
                R("messaging_transport_unreachable", {
                    transportStatus: t,
                    browserOffline: r,
                    ...e
                }), gt("transport unreachable", {
                    reason: "transport_unreachable",
                    transportStatus: t,
                    browserOffline: r,
                    ...e
                }, "warn");
            }
            u && R("messaging_connectivity_verdict_changed", {
                lost: a
            }), v && gt("connectivity lost notice shown", {
                fallbackMessageShown: !0,
                reason: "connectivity_lost"
            }, "warn"), (l && r || _) && c.check();
        });
    navigator.onLine || l();
    let _ = {
        store: n,
        transport: r,
        privateMode: e.privateMode ? ? !1,
        hostTelemetry: e.hostTelemetry,
        headless: e.headless === !0,
        lifecycle: new Fi(),
        setTransport(e) {
            a = !1, o = null, r.offStatusChange ? .(s), r.disconnect(), r = e, _.transport = e, r.onStatusChange(s);
        },
        destroy() {
            window.removeEventListener("offline", l), window.removeEventListener("online", u), window.removeEventListener("pagehide", v), g(), c.destroy(), r.offStatusChange ? .(s), _.lifecycle.destroy(), r.disconnect();
        }
    };

    function v(e) {
        e.persisted || _.destroy();
    }
    return window.addEventListener("pagehide", v), _;
}
//#endregion
//#region src/bootstrap.ts
var pv = B("bootstrap"),
    mv = "core",
    hv = 15e3;

function gv() {
    return dt(document.referrer);
}

function _v(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    return t ? Dn(t, window.location.origin) : null;
}

function vv(e) {
    if (e == null) return;
    let t = He(e, {
        currentOrigin: window.location.origin
    });
    if (t !== void 0) return t;
    typeof e == "string" && Et(e.trim()) ? pv.warn("Rejected configured appUrl on an Ada-controlled origin; host your custom app on an origin you control. Mounting the default app instead.") : pv.warn("Rejected configured appUrl (must be an absolute https: URL, or http: on a loopback host for local development, and not on this frame's own origin); mounting the default app instead.");
}

function yv(e) {
    if (typeof e != "object" || !e) return;
    let t = Object.entries(e),
        n = {};
    for (let [e, r] of t) e && (typeof r == "string" || typeof r == "number" || typeof r == "boolean" || r === null) && (n[e] = r);
    return Object.keys(n).length > 0 ? n : void 0;
}

function bv(e) {
    let t = typeof e.clearPersistenceAckRequestId == "string" ? e.clearPersistenceAckRequestId.trim() : "",
        n = e.clearPersistenceAckResponseType;
    return !t || n !== "core.reset.response" && n !== "core.history.delete.response" ? {} : {
        clearPersistenceAckRequestId: t,
        clearPersistenceAckResponseType: n
    };
}

function xv(e) {
    return te.includes(e) ? e : void 0;
}

function Sv(e) {
    if (Array.isArray(e.clearPersistenceStorageModes)) return [...new Set(e.clearPersistenceStorageModes.filter((e) => xv(e) !== void 0))];
    let t = xv(e.clearPersistenceStorageMode);
    if (t) return [t];
}

function Cv(e) {
    try {
        let t = typeof e.data == "string" ? JSON.parse(e.data) : e.data;
        if (t && typeof t.name == "string" && t.name === "sdk" && typeof t.type == "string") return t;
    } catch {}
    return null;
}

function wv() {
    try {
        let e = window.parent;
        return !e || e === window ? !1 : ue(e.location);
    } catch {
        return !1;
    }
}

function Tv(e) {
    if (typeof e != "object" || !e) return null;
    let t = e,
        n = typeof t.handle == "string" ? t.handle.trim() : "";
    if (!n) return null;
    let r = _v(t.endpoint);
    if (!r) return null;
    let i;
    i = t.cluster === null ? null : typeof t.cluster == "string" && t.cluster.trim() || void 0;
    let a = t.nativeSessionMirror === !0 && wv(),
        o = Ri(t.hostTelemetry);
    return o ? .nativeViewVisibilitySupported && (o.mobileShell !== "messaging-sdk" || !wv()) && delete o.nativeViewVisibilitySupported, {
        handle: n,
        cluster: i,
        endpoint: r,
        language: typeof t.language == "string" && t.language.trim() ? t.language.trim() : void 0,
        greeting: typeof t.greeting == "string" && t.greeting.trim() ? t.greeting.trim() : void 0,
        skipGreeting: t.skipGreeting === !0,
        skipGreetingOnce: t.skipGreetingOnce === !0,
        configuredGreetingResponseId: typeof t.configuredGreetingResponseId == "string" && t.configuredGreetingResponseId.trim() ? t.configuredGreetingResponseId.trim() : void 0,
        identityToken: typeof t.identityToken == "string" && t.identityToken.trim() ? t.identityToken.trim() : void 0,
        appUrl: vv(t.appUrl),
        appUrlFallback: t.appUrlFallback !== !1,
        metaFields: yv(t.metaFields),
        metaFieldsBaseline: yv(t.metaFieldsBaseline),
        sensitiveMetaFields: yv(t.sensitiveMetaFields),
        hostTelemetry: o,
        androidHostNavigation: t.androidHostNavigation === !0,
        branding: Zr(t.branding).branding,
        theme: t.theme === "light" || t.theme === "dark" || t.theme === "auto" ? t.theme : void 0,
        mode: t.mode === "test" || t.mode === "dev" || t.mode === "prod" ? t.mode : void 0,
        privateMode: t.privateMode === !0,
        isParentElementMode: t.isParentElementMode === !0,
        headless: t.headless === !0,
        isMobileViewport: t.isMobileViewport === !0,
        hideDefaultHeader: t.hideDefaultHeader === !0,
        clearPersistenceOnPrepare: t.clearPersistenceOnPrepare === !0,
        ...bv(t),
        clearPersistenceStorageModes: Sv(t),
        clearPersistenceOutgoingStorageMode: xv(t.clearPersistenceOutgoingStorageMode),
        allowMetaFieldsInReset: t.allowMetaFieldsInReset !== !1,
        enableProgrammaticControl: t.enableProgrammaticControl === !0,
        nativeSessionMirror: a
    };
}

function Ev(e) {
    let t = gv(),
        n = !1;

    function r(e, n, r) {
        !t || !window.parent || window.parent === window || window.parent.postMessage({
            name: mv,
            type: e,
            payload: n,
            id: r
        }, ls(t));
    }

    function i() {
        n || !t || (r("frame.origin.report", {
            origin: window.location.origin
        }), n = !0);
    }
    return i(), new Promise((n, a) => {
        let o = setTimeout(() => {
            window.removeEventListener("message", s), t && window.parent ? .postMessage({
                name: "core",
                type: "frame.config.timeout"
            }, ls(t)), a( /* @__PURE__ */ Error(`bootstrapCoreFrame: timed out waiting for sdk.config.set after ${hv}ms`));
        }, hv);

        function s(c) {
            if (c.source !== window.parent) return;
            let l = rn(c.origin);
            if (!l) return;
            if (!t) t = l, l === "file://" || l === "null" ? pv.debug(`Core locked bundled-host parent origin via TOFU: ${l}.`) : pv.warn("Core locked parent origin via TOFU: " + l + ". Ensure the embedding page does not suppress the Referer header."), i();
            else if (l !== t) return;
            let u = Cv(c);
            if (u && u.type === "sdk.config.set") {
                window.removeEventListener("message", s), clearTimeout(o);
                let t = Tv(u.payload);
                if (!t) {
                    a( /* @__PURE__ */ Error("bootstrapCoreFrame: invalid config payload"));
                    return;
                }
                let i = fv(t, e);
                en(u.payload.metaFieldCounts), r("frame.ready", {
                    name: mv
                }), n(i);
            }
        }
        window.addEventListener("message", s);
    });
}
//#endregion
//#region src/launcher-text.ts
function Dv({
    textEnabled: e,
    textByLanguage: t,
    sessionLanguage: n,
    botDefaultLanguage: r
}) {
    if (!e) return {
        text: "",
        textLanguage: "en"
    };
    let i = n.toLowerCase();
    for (let e of [
            i,
            i.split("-")[0],
            r.toLowerCase(),
            "en"
        ]) {
        if (!Object.hasOwn(t, e)) continue;
        let n = t[e];
        if (typeof n == "string" && n) return {
            text: n,
            textLanguage: e
        };
    }
    return {
        text: "Chat",
        textLanguage: "en"
    };
}
//#endregion
//#region src/orchestrator-chatter-presence-post.ts
function Ov(e, t) {
    return `${e.endsWith("/") ? e : `${e}/`}${t}`;
}

function kv(e) {
    let t = e.getState(),
        {
            chatterToken: n,
            conversationId: r
        } = t.session;
    return n ? {
        chatterToken: n,
        conversationId: r,
        handoffOperationSeq: t.liveAgent.zendeskOperationSeq
    } : null;
}

function Av(e, t) {
    let n = e.getState();
    return n.session.chatterToken === t.chatterToken && n.session.conversationId === t.conversationId && n.liveAgent.zendeskOperationSeq === t.handoffOperationSeq;
}

function jv({
    store: e,
    fetchFn: t,
    type: n,
    identity: r,
    rumPrefix: i,
    isStillEligible: a,
    onRejected: o
}) {
    if (!Av(e, r)) return;
    let {
        endpoint: s,
        chatterToken: c
    } = e.getState().session;
    !s || !c || zn(e, {
        url: Ov(s, "webhooks/live/"),
        method: "POST",
        credentials: "include",
        body: {
            type: n,
            by: c
        }
    }, {
        fetchFn: t,
        isCurrent: () => Av(e, r) && a(e)
    }).then((t) => {
        if (!t.ok) {
            if (t.status === 400) {
                Av(e, r) && a(e) && (o(), Av(e, r) && a(e) && (e.dispatch(ao({
                    stateType: ft,
                    inState: !1
                })), e.dispatch($o(null)))), R(`${i}_rejected`, {
                    type: n
                });
                return;
            }
            R(`${i}_post_failed`, {
                type: n,
                status: t.status
            });
        }
    }).catch(() => {
        R(`${i}_post_failed`, {
            type: n,
            reason: "network"
        });
    });
}
//#endregion
//#region src/orchestrator-chatter-typing-runtime.ts
var Mv = 1e3;

function Nv(e) {
    let {
        liveAgent: t
    } = e.getState();
    return t.inLiveChat && !t.inPending && !t.hasConversationEnded;
}

function Pv(e) {
    return Nv(e) && !e.getState().session.secretMessageIsOpen;
}
var Fv = class {
    constructor(e, t = fetch, n = () => void 0) {
        L(this, "idleTimer", null), L(this, "isTyping", !1), L(this, "burstIdentity", null), L(this, "store", void 0), L(this, "fetchFn", void 0), L(this, "onCurrentHandoffRejected", void 0), this.store = e, this.fetchFn = t, this.onCurrentHandoffRejected = n;
    }
    notifyComposerChanged() {
        if (!Pv(this.store)) {
            this.clearLocalState();
            return;
        }
        if (this.burstIdentity && !Av(this.store, this.burstIdentity) && this.clearLocalState(), !this.isTyping) {
            if (this.isTyping = !0, this.burstIdentity = kv(this.store), !this.burstIdentity) {
                this.clearLocalState();
                return;
            }
            this.postTypingEdge(!0, this.burstIdentity);
        }
        this.armIdleStop();
    }
    settle() {
        if (this.idleTimer && = (globalThis.clearTimeout(this.idleTimer), null), !this.isTyping) return;
        let e = this.burstIdentity;
        this.isTyping = !1, this.burstIdentity = null, e && Av(this.store, e) && Nv(this.store) && this.postTypingEdge(!1, e);
    }
    clear() {
        this.clearLocalState();
    }
    armIdleStop() {
        this.idleTimer && globalThis.clearTimeout(this.idleTimer), this.idleTimer = globalThis.setTimeout(() => {
            this.idleTimer = null, this.settle();
        }, Mv);
    }
    clearLocalState() {
        this.idleTimer && = (globalThis.clearTimeout(this.idleTimer), null), this.isTyping = !1, this.burstIdentity = null;
    }
    postTypingEdge(e, t) {
        jv({
            store: this.store,
            fetchFn: this.fetchFn,
            type: e ? "chatter_typing_start" : "chatter_typing_end",
            identity: t,
            rumPrefix: "live_agent_chatter_typing",
            isStillEligible: Nv,
            onRejected: () => {
                this.clearLocalState(), this.onCurrentHandoffRejected();
            }
        });
    }
};
//#endregion
//#region src/orchestrator-chatter-visibility-runtime.ts
function Iv(e) {
    let {
        liveAgent: t
    } = e.getState();
    return t.inLiveChat && !t.inPending && !t.hasConversationEnded && t.platformName === "zendesk_liveagent";
}
var Lv = class {
        constructor(e, t = fetch, n = () => void 0) {
            L(this, "store", void 0), L(this, "fetchFn", void 0), L(this, "onCurrentHandoffRejected", void 0), L(this, "onVisibilityChange", () => {
                this.notifyVisibilityChanged();
            }), this.store = e, this.fetchFn = t, this.onCurrentHandoffRejected = n, document.addEventListener("visibilitychange", this.onVisibilityChange);
        }
        notifyVisibilityChanged() {
            if (!Iv(this.store)) return;
            let e = kv(this.store);
            e && jv({
                store: this.store,
                fetchFn: this.fetchFn,
                type: document.visibilityState === "visible" ? "chatter_visibility_visible" : "chatter_visibility_hidden",
                identity: e,
                rumPrefix: "live_agent_chatter_visibility",
                isStillEligible: Iv,
                onRejected: this.onCurrentHandoffRejected
            });
        }
        destroy() {
            document.removeEventListener("visibilitychange", this.onVisibilityChange);
        }
    },
    Rv = 15e3,
    zv = new Set([
        "stale_conversation",
        "conversation_not_found",
        "not_live",
        "wrong_platform",
        "malformed_conversation",
        "invalid_context"
    ]);

function Bv(e) {
    let t = e;
    return t ? .status === 409 && typeof t.data ? .failure_reason == "string" && zv.has(t.data.failure_reason);
}

function Vv(e) {
    let t = e;
    return t ? .status === 409 ? t.data ? .failure_reason === "definite_rejection" ? "rejected" : t.data ? .failure_reason === "retryable_rejection" ? "retryable_rejection" : null : null;
}

function Hv(e) {
    let t = e;
    return t ? .status === 400 && t.data ? .message === "Channel 'handoff_media' is not configured";
}

function Uv(e) {
    let t = e ? .status;
    return t === 0 || t === "FETCH_ERROR" || t === "TIMEOUT_ERROR" || t === "PARSING_ERROR" || t === 408 || typeof t == "number" && t >= 500;
}

function Wv(e, t, n) {
    return {
        id: e.tempMessageUuid,
        role: "user",
        type: n,
        createdAt: Date.now() / 1e3,
        data: {
            url: t.url,
            ...n === "downloadable" && t.name ? {
                name: t.name
            } : {},
            ...t.mimeType ? {
                mimeType: t.mimeType
            } : {}
        }
    };
}

function Gv(e, t, n) {
    let r = e.getState().chat.messages.find((e) => e.sender === "user" && e.tempMessageUuid === t && typeof e.cursor == "string" && (!n || e.serverPersisted !== !1));
    return r ? .type === "downloadable" || r ? .type === "picture";
}

function Kv(e, t, n, r) {
    return Gv(e, t, n) ? Promise.resolve(!0) : r.aborted ? Promise.resolve(!1) : new Promise((i) => {
        let a = null,
            o = (e) => {
                a ? .(), r.removeEventListener("abort", s), i(e);
            },
            s = () => o(!1);
        a = e.subscribe(() => {
            Gv(e, t, n) && o(!0);
        }), r.addEventListener("abort", s, {
            once: !0
        }), Gv(e, t, n) && o(!0);
    });
}
async function qv(e, t, n, r, i, a) {
    let {
        endpoint: o,
        chatterToken: s,
        sessionId: c,
        conversationId: l,
        tempMessageUuid: u
    } = r;
    if (!o || !s || !l || i.aborted) return "failed";
    let d = t === "zendeskMessaging" && n.mimeType.startsWith("image/") ? "picture" : "downloadable",
        f = () => e.dispatch(zi({
            id: u,
            eventMessage: Wv(r, n, d)
        })),
        p = () => {
            if (e.getState().chat.messages.some((e) => e.tempMessageUuid === u)) return;
            let t = {
                id: u,
                tempMessageUuid: u,
                sender: "user",
                timestamp: Date.now(),
                body: "",
                conversationId: l
            };
            e.dispatch(_o(d === "picture" ? {
                ...t,
                type: "picture",
                picUrl: n.url,
                altText: n.name
            } : {
                ...t,
                type: "downloadable",
                url: n.url,
                name: n.name,
                mimeType: n.mimeType
            }));
        };
    if (Gv(e, u, r.requiresDurableLog)) return f(), "sent";
    if (r.deliveryOutcome === "indeterminate") return a(), await Kv(e, u, r.requiresDurableLog, i) ? (f(), "sent") : "indeterminate";
    r.deliveryOutcome = "sending";
    let m = {
            endpoint: o,
            chatterToken: s,
            sessionId: c ? ? "",
            messageType: d,
            tempMessageUuid: u,
            conversationId: l,
            handoffPlatform: r.platformName ? ? void 0,
            url: n.url,
            mimeType: n.mimeType,
            name: n.name,
            ...n.s3Key && {
                s3Key: n.s3Key
            }
        },
        h = async (t) => {
            let n = e.dispatch(G.endpoints.sendMessage.initiate({
                    ...m,
                    handoffContinuation: t
                })),
                r = () => n.abort();
            i.addEventListener("abort", r, {
                once: !0
            });
            try {
                return await n;
            } finally {
                i.removeEventListener("abort", r);
            }
        },
        g = await h(!0);
    if (i.aborted) return r.deliveryOutcome = "indeterminate", "indeterminate";
    if ("error" in g && Hv(g.error)) {
        if (t === "zendeskMessaging" && d === "downloadable") return R("handoff_media_legacy_route_fallback_suppressed", {
            platform: r.platformName ? ? "unknown",
            messageType: d
        }), r.deliveryOutcome = "failed", "rejected";
        R("handoff_media_legacy_route_fallback", {
            platform: r.platformName ? ? "unknown"
        }), a(), g = await h(!1);
    }
    if (i.aborted) return r.deliveryOutcome = "indeterminate", "indeterminate";
    if ("error" in g) {
        if (Bv(g.error)) return r.deliveryOutcome = "failed", "refused";
        let e = Vv(g.error);
        if (e) return r.deliveryOutcome = "failed", e;
        if (!Uv(g.error)) return r.deliveryOutcome = "failed", "failed";
        r.deliveryOutcome = "indeterminate";
    } else r.deliveryOutcome = "accepted";
    return !r.requiresDurableLog && r.deliveryOutcome === "accepted" ? (p(), f(), "sent") : (a(), await Kv(e, u, r.requiresDurableLog, i) ? (f(), "sent") : (r.deliveryOutcome !== "accepted" && (r.deliveryOutcome = "indeterminate"), "indeterminate"));
}
async function Jv(e, t, n, r, i) {
    let a = new AbortController(),
        o = () => a.abort();
    i.aborted ? o() : i.addEventListener("abort", o, {
        once: !0
    });
    let s = null,
        c = () => {
            s !== null && globalThis.clearTimeout(s), s = globalThis.setTimeout(o, Rv);
        };
    c();
    try {
        return await qv(e, t, n, r, a.signal, c);
    } finally {
        s !== null && globalThis.clearTimeout(s), i.removeEventListener("abort", o);
    }
}
//#endregion
//#region src/orchestrator-live-agent-upload.ts
var Yv = 12e4;

function Xv(e, t, n, r, i) {
    return (i === void 0 || e.clientUploadId === i) && e.endpoint === n.session.endpoint && e.chatterToken === n.session.chatterToken && e.conversationId === n.session.conversationId && e.conversationGeneration === n.session.conversationGeneration && e.platformName === r && e.fileName === t.name && e.fileSize === t.size && e.fileType === t.type && e.fileLastModified === t.lastModified;
}

function Zv(e, t, n, r, i = cr(), a, o, s) {
    return {
        operationId: I(),
        clientUploadId: r,
        tempMessageUuid: i,
        endpoint: e.session.endpoint,
        chatterToken: e.session.chatterToken,
        sessionToken: e.session.sessionToken,
        sessionId: e.session.sessionId,
        conversationId: e.session.conversationId,
        conversationGeneration: e.session.conversationGeneration,
        platformName: n,
        fileName: t.name,
        fileSize: t.size,
        fileType: t.type,
        fileLastModified: t.lastModified,
        requiresDurableLog: s ? ? (!e.session.features.disable_live_chat_log && !e.session.features.disableLiveChatLog),
        ...a ? {
            deliveredMedia: a
        } : {},
        ...o ? {
            deliveryOutcome: o
        } : {}
    };
}

function Qv(e, t) {
    let n = e.store.getState(),
        r = n.liveAgent.platformName,
        i = e.uploadState.activeOperation;
    if (i && Xv(i, t, n, r)) return i;
    let a = Zv(n, t, r, I());
    return e.uploadState.activeOperation = a, a;
}

function $v(e, t, n) {
    let r = e.store.getState();
    return e.uploadState.activeOperation ? .operationId === t.operationId && (!n || e.uploadState.activeController === n) && n ? .signal.aborted !== !0 && r.liveAgent.file.isUploading && r.liveAgent.inLiveChat && r.liveAgent.platformName === t.platformName && r.session.endpoint === t.endpoint && r.session.chatterToken === t.chatterToken && r.session.conversationId === t.conversationId && r.session.conversationGeneration === t.conversationGeneration;
}

function ey(e, t) {
    e.activeOperation ? .operationId === t.operationId && (e.activeOperation = null);
}

function ty(e) {
    e.uploadState.activeCommandId = null, e.uploadState.resultTimeoutId && (clearTimeout(e.uploadState.resultTimeoutId), e.uploadState.resultTimeoutId = null);
}

function ny(e, t) {
    e.uploadState.resultTimeoutId && clearTimeout(e.uploadState.resultTimeoutId);
    let n = setTimeout(() => {
        if (e.uploadState.activeCommandId === t) {
            if (!e.store.getState().liveAgent.file.isUploading) {
                ty(e);
                return;
            }
            e.uploadState.activeOperation && (e.uploadState.activeOperation.deliveryOutcome = "indeterminate"), e.store.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "integration_result_timeout",
                    indeterminate: !0
                }
            })), R("live_agent_file_upload_failed", {
                reason: "integration_result_timeout"
            }), ty(e);
        }
    }, Yv);
    e.uploadState.resultTimeoutId = n;
}

function ry(e, t, n, r = null, i = I()) {
    let a = e.store.getState();
    if (a.liveAgent.file.isUploading) return R("live_agent_file_upload_ignored", {
        reason: "upload_in_progress"
    }), !1;
    ty(e);
    let o = a.liveAgent.platformName;
    o && n && n !== o && R("live_agent_file_upload_platform_override_ignored", {
        currentPlatform: o,
        overridePlatform: n
    });
    let s = o ? ? n ? ? null;
    if (!Yn({
            features: a.session.features,
            fileUploadEnabled: a.session.fileUploadEnabled,
            liveAgent: {
                inLiveChat: a.liveAgent.inLiveChat,
                platformName: s
            },
            file: {
                transfer: a.liveAgent.file.transfer,
                isUploading: a.liveAgent.file.isUploading
            }
        })) return e.store.dispatch(U({
        errorKey: "FILE_UPLOAD_ERROR",
        errorData: {
            reason: "upload_not_enabled"
        }
    })), !1;
    let c = _n(t, s);
    if (!c.ok) return e.store.dispatch(U(c.error)), !1;
    let l = !!(r && Xv(r, t, a, s, i)),
        u = l ? r ? .tempMessageUuid : void 0;
    return e.uploadState.activeOperation = Zv(a, t, s, i, u, l ? r ? .deliveredMedia : void 0, l ? r ? .deliveryOutcome : void 0, l ? r ? .requiresDurableLog : void 0), e.store.dispatch(it()), ty(e), e.store.dispatch(rr({
        fileName: t.name,
        fileSize: t.size,
        fileType: t.type
    })), R("live_agent_file_upload_requested", {
        platform: s,
        size: t.size,
        type: t.type
    }), !0;
}

function iy(e, t, n, r = I()) {
    return ry(e, t, n, null, r);
}

function ay(e, t, n) {
    let r = e.store.getState(),
        i = e.uploadState.activeOperation;
    return !i || !Xv(i, t, r, r.liveAgent.platformName, n) ? (R("live_agent_file_upload_ignored", {
        reason: "retry_operation_mismatch"
    }), !1) : (n === void 0 && R("live_agent_file_upload_legacy_retry_identity_fallback", {
        platform: r.liveAgent.platformName
    }), i.deliveryOutcome === "indeterminate" && !i.deliveredMedia ? (R("live_agent_file_upload_ignored", {
        reason: "indeterminate_delivery_cannot_retry"
    }), !1) : ry(e, t, void 0, i, n ? ? i.clientUploadId));
}

function oy(e) {
    if (!e.store.getState().liveAgent.file.isUploading) return null;
    let t = e.uploadState.activeOperation;
    if (t ? .deliveredMedia) return e.store.dispatch(U({
        errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
        errorData: {
            reason: "durability_unknown",
            deliveryConfirmed: !0
        }
    })), null;
    if (t ? .deliveryOutcome === "indeterminate") return e.store.dispatch(U({
        errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
        errorData: {
            reason: "delivery_unknown"
        }
    })), null;
    t && (t.deliveryOutcome = "sending");
    let n = `file_upload_${I()}`;
    return e.uploadState.activeCommandId = n, ny(e, n), n;
}

function sy(e) {
    e.activeController ? .abort(), e.activeController = null, e.activeOperation = null;
}

function cy(e) {
    sy(e.uploadState), ty(e), e.store.dispatch(De()), e.store.dispatch(it()), R("live_agent_file_upload_cancelled");
}
//#endregion
//#region src/orchestrator-handoff-integration-network.ts
var ly = 12e4,
    uy = new Set([
        "stale_conversation",
        "conversation_not_found",
        "chatter_not_found",
        "not_live",
        "wrong_platform"
    ]);

function dy(e) {
    return e.endsWith("/") ? e : `${e}/`;
}

function fy(e, t, n) {
    let r = n ? "durable_file_upload" : "file_upload";
    return `${dy(e)}handoffs/${r}?conversation_id=${encodeURIComponent(t)}`;
}

function py(e) {
    let t = F(e),
        n = O(t ? .url),
        r = O(t ? .mime_type),
        i = O(t ? .filename, {
            trimOutput: !1
        }),
        a = O(t ? .s3_key);
    return !n || !r || !i || t ? .s3_key !== void 0 && !a ? null : {
        url: n,
        mime_type: r,
        filename: i,
        ...a && {
            s3_key: a
        }
    };
}
async function my(e) {
    try {
        let t = await e.clone().json();
        if (typeof t != "object" || !t) return null;
        let n = t.failure_reason;
        return typeof n == "string" ? n : null;
    } catch {
        return null;
    }
}
async function hy({
    store: e,
    file: t,
    uploadState: n,
    clearFileUploadCommandTracking: r,
    onCaptureException: i
}) {
    if (!e.getState().liveAgent.file.isUploading) return !1;
    let a = {
            store: e,
            uploadState: n
        },
        o = Qv(a, t),
        {
            endpoint: s,
            chatterToken: c,
            sessionToken: l,
            conversationId: u
        } = o,
        d = n.activeController;
    if (d && (d.abort(), n.activeController = null), !s || !c || !u) return e.dispatch(U({
        errorKey: "FILE_UPLOAD_ERROR",
        errorData: {
            reason: "invalid_context"
        }
    })), R("handoff_integration_file_upload_failed", {
        status: "invalid_context"
    }), r(), !1;
    R("handoff_integration_file_upload_requested", {
        size: t.size,
        type: t.type
    });
    let f = new AbortController();
    n.activeController = f;
    let p = !1,
        m = null,
        h = () => {
            f.signal.aborted || (m !== null && globalThis.clearTimeout(m), p = !1, m = globalThis.setTimeout(() => {
                p = !0, f.abort();
            }, ly));
        };
    h();
    try {
        if (!o.deliveredMedia) {
            let i = new FormData();
            i.append("file", t);
            let d = {
                    method: "POST",
                    credentials: "include",
                    headers: {
                        "X-Ada-Request-Origin": "chat",
                        "Chatter-Token": c,
                        ...l ? {
                            "Session-Auth": l
                        } : {}
                    },
                    body: i,
                    signal: f.signal
                },
                m, g = o.requiresDurableLog;
            try {
                m = await fetch(fy(s, u, o.requiresDurableLog), d);
            } catch (e) {
                if (!g || f.signal.aborted) throw e;
                R("handoff_integration_file_upload_legacy_fallback", {
                    reason: "route_unobservable"
                }), g = !1, h(), m = await fetch(fy(s, u, !1), d);
            }
            let _ = g ? await my(m) : null;
            if (g && (m.status === 404 && _ === null || _ === "retention_disabled") && (R("handoff_integration_file_upload_legacy_fallback", {
                    reason: m.status === 404 ? "route_missing" : "retention_disabled"
                }), _ === "retention_disabled" && (o.requiresDurableLog = !1), g = !1, h(), m = await fetch(fy(s, u, !1), d)), p && n.activeOperation ? .operationId === o.operationId && n.activeController === f) return o.deliveryOutcome = "failed", e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "timeout",
                    retryable: !0
                }
            })), r(), !1;
            if (!$v(a, o, f)) return R("handoff_integration_file_upload_ignored", {
                reason: "stale_upload_operation"
            }), !1;
            if (!m.ok) {
                let t = "FILE_UPLOAD_UNKNOWN_ERROR",
                    n = _ && uy.has(_) ? "handoff_ended" : "http_error";
                m.status === 413 ? (t = "FILE_UPLOAD_EXCEED_SIZE_LIMIT", n = "http_413") : m.status === 400 && (t = "FILE_UPLOAD_UNSUPPORTED_TYPE", n = "http_400");
                let r = {
                    errorKey: t,
                    errorData: {
                        reason: n,
                        status: m.status,
                        ...t === "FILE_UPLOAD_UNKNOWN_ERROR" && n !== "handoff_ended" ? {
                            retryable: !0
                        } : {}
                    }
                };
                return e.dispatch(U(r)), R("handoff_integration_file_upload_failed", {
                    status: m.status
                }), !1;
            }
            let v = null;
            try {
                v = await m.json();
            } catch {
                v = null;
            }
            if (p && n.activeOperation ? .operationId === o.operationId && n.activeController === f) return o.deliveryOutcome = "failed", e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "timeout",
                    retryable: !0
                }
            })), r(), !1;
            if (!$v(a, o, f)) return !1;
            let y = py(v);
            if (!y || g && !y.s3_key) return e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "invalid_response",
                    retryable: !0
                }
            })), R("handoff_integration_file_upload_failed", {
                status: "invalid_response"
            }), !1;
            o.deliveredMedia = {
                url: y.url,
                mimeType: y.mime_type,
                name: y.filename,
                ...y.s3_key && {
                    s3Key: y.s3_key
                }
            };
        }
        m !== null && globalThis.clearTimeout(m);
        let i = await Jv(e, "handoffIntegration", o.deliveredMedia, o, f.signal);
        if (!$v(a, o, f)) return R("handoff_integration_file_upload_ignored", {
            reason: "stale_upload_operation"
        }), !1;
        if (i !== "sent") {
            let t = i === "refused",
                n = "message_send_failed";
            return t ? n = "handoff_ended" : i === "indeterminate" && (n = "delivery_unknown"), e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: n,
                    ...i === "failed" ? {
                        retryable: !0
                    } : {}
                }
            })), R("handoff_integration_file_upload_failed", {
                status: n,
                sendResult: i
            }), !1;
        }
        return e.dispatch(Hn({
            type: "Uploaded",
            fileName: t.name,
            fileSize: t.size,
            progress: 100
        })), e.dispatch(De()), e.dispatch(it()), ey(n, o), r(), R("handoff_integration_file_upload_succeeded"), !0;
    } catch (t) {
        if (!(n.activeOperation ? .operationId === o.operationId && n.activeController === f)) return !1;
        let a = p || t instanceof DOMException && t.name === "AbortError";
        return !p && f.signal.aborted ? (R("handoff_integration_file_upload_cancelled"), !1) : (e.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: a ? "timeout" : "network_error",
                retryable: !0
            }
        })), r(), R("handoff_integration_file_upload_failed", {
            status: a ? "timeout" : "network_error"
        }), a || i(t, {
            endpoint: s
        }), !1);
    } finally {
        m !== null && globalThis.clearTimeout(m), n.activeController === f && (n.activeController = null);
    }
}
//#endregion
//#region src/orchestrator-integration-events.ts
function gy(e, t) {
    let n = e.getState().chat.messages.find((e) => e.id === t || e.clientKey === t);
    return n ? .type !== "text" || n.sender !== "user" ? null : {
        ...n,
        sender: "user"
    };
}

function _y(e, t, n) {
    let r = e.getState(),
        i = t ? gy(e, t) : null;
    return !i || i.id !== t || !i.tempMessageUuid || i.conversationId == null || i.conversationId !== r.session.conversationId || !r.liveAgent.inLiveChat || r.liveAgent.platformName !== "zendesk_liveagent" || r.liveAgent.zendesk.chatClosed || r.liveAgent.hasConversationEnded || n !== r.liveAgent.zendeskOperationSeq ? null : {
        ...i,
        sender: "user",
        tempMessageUuid: i.tempMessageUuid,
        conversationId: i.conversationId
    };
}

function Q(e) {
    return O(e, {
        trimOutput: !1
    });
}

function vy(e) {
    let t = F(e);
    if (!t) return null;
    let n = Q(t.integration),
        r = Q(t.action),
        i = Q(t.status),
        a = Q(t.commandId),
        o = F(t.data),
        s = F(t.error),
        c = Q(s ? .code),
        l = Q(s ? .message),
        u = F(s ? .details) ? ? {};
    return !n || !r || i !== "success" && i !== "error" ? null : {
        integration: n,
        action: r,
        status: i,
        commandId: a,
        data: o,
        errorCode: c,
        errorMessage: l,
        errorDetails: u
    };
}

function yy(e, t, n, r, i, a) {
    let o = t.activeOperation;
    if (!o || o.operationId !== n || !e.getState().liveAgent.file.isUploading || (a ? t.activeController !== a : t.activeController !== null)) {
        R("zendesk_chat_file_upload_ignored", {
            reason: "stale_upload_operation"
        });
        return;
    }
    o.deliveryOutcome = "indeterminate", e.dispatch(U({
        errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
        errorData: {
            reason: "durability_unknown",
            deliveryConfirmed: !0
        }
    })), r(), R("zendesk_chat_file_log_failed", {
        sendResult: "exception",
        error: i instanceof Error ? i.message : String(i)
    });
}
async function by(e, t, n, r) {
    let i = t.activeOperation,
        a = {
            store: e,
            uploadState: t
        };
    if (!i || i.platformName !== "zendesk_liveagent" || !$v(a, i)) return;
    let o = t.activeController;
    o && o.abort();
    let s = new AbortController();
    t.activeController = s;
    try {
        let o = await Jv(e, "zendeskChat", n, i, s.signal);
        if (!$v(a, i, s)) {
            R("zendesk_chat_file_upload_ignored", {
                reason: "stale_upload_operation"
            });
            return;
        }
        if (o !== "sent") {
            R("zendesk_chat_file_log_failed", {
                sendResult: o
            });
            let t = o === "refused",
                n = "durability_failed";
            t ? n = "handoff_ended" : o === "indeterminate" && (n = "durability_unknown"), e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: n,
                    deliveryConfirmed: !0,
                    ...o === "failed" ? {
                        retryable: !0
                    } : {}
                }
            })), r();
            return;
        }
        e.dispatch(De()), ey(t, i), r();
    } catch (n) {
        yy(e, t, i.operationId, r, n, s);
    } finally {
        t.activeController === s && (t.activeController = null);
    }
}
async function xy(e, t, n, r) {
    let i = t.activeOperation,
        a = {
            store: e,
            uploadState: t
        };
    if (!i || i.platformName !== "zendesk_liveagent" || !$v(a, i)) return;
    let o = F(n ? .attachment),
        s = o ? Q(o.url) : null;
    if (!o || !s) {
        i.deliveryOutcome = "indeterminate", e.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: "invalid_response",
                indeterminate: !0
            }
        })), r();
        return;
    }
    let c = {
        url: s,
        name: Q(o.name) ? ? "",
        mimeType: Q(o.mime_type) ? ? ""
    };
    i.deliveredMedia = c, i.deliveryOutcome = "accepted", r(), await by(e, t, c, r);
}

function Sy({
    store: e,
    uploadState: t,
    clearFileUploadCommandTracking: n
}) {
    let r = t.activeOperation;
    return !r || r.platformName !== "zendesk_liveagent" || !r.deliveredMedia || !$v({
        store: e,
        uploadState: t
    }, r) ? !1 : (by(e, t, r.deliveredMedia, n).catch((i) => {
        yy(e, t, r.operationId, n, i);
    }), !0);
}

function Cy(e, t, n, i, a) {
    let o = n === os,
        s = Q(t.messageId),
        c = Q(t.requestId),
        l = qo(t.zendeskOperationSeq),
        u = _y(e, s, l);
    u && l !== null ? (e.dispatch(V(o ? "Message delivery could not be confirmed" : "Failed to send message")), o ? e.dispatch(oi(u.id)) : e.dispatch(r({
        messageId: u.id,
        send: {
            transport: "zendesk",
            zendeskOperationSeq: l,
            tempMessageUuid: u.tempMessageUuid,
            body: u.body
        }
    }))) : s && e.dispatch(oi(s)), c && a ? .("core.message.response", {
        requestId: c,
        error: "sendMessage rejected by chat: DISPATCH_FAILED"
    }), R("zendesk_message_send_failed", {
        code: n ? ? void 0,
        message: i ? ? void 0
    });
}

function wy({
    store: e,
    payload: t,
    uploadState: n,
    activeFileUploadCommandId: r,
    clearFileUploadCommandTracking: i,
    sendToParent: a
}) {
    let o = vy(t);
    if (!o) return;
    let {
        integration: s,
        action: c,
        status: l,
        commandId: u,
        data: d,
        errorCode: f,
        errorMessage: p,
        errorDetails: m
    } = o;
    if (s === "integration") {
        if (c === "result.timeout" && l === "error" && Q(m.integration) === "zendesk" && Q(m.action) === "handoff.initialize") {
            R("zendesk_handoff_initialize_timeout", {
                dispatched: m.dispatched
            });
            return;
        }
        if (c === "result.timeout" && l === "error" && Q(m.integration) === "liveAgent" && Q(m.action) === "message.send") {
            Cy(e, m, m.dispatched === !1 ? f : os, p, a);
            return;
        }
        let t = Q(m.frameId),
            n = t === "zendesk" || t === "zendeskMessaging";
        c === "frame.load" && l === "error" && e.getState().liveAgent.file.isUploading && r && n && (e.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: "integration_frame_load_error",
                details: m
            }
        })), i(), R("live_agent_file_upload_failed", {
            reason: "integration_frame_load_error"
        }));
        return;
    }
    if ((s === "zendesk" || s === "zendeskMessaging") && c === "frame.error" && l === "error" && e.getState().liveAgent.file.isUploading && r) {
        let t = s === "zendesk" && n.activeOperation ? .platformName === "zendesk_liveagent";
        t && n.activeOperation && (n.activeOperation.deliveryOutcome = "indeterminate"), e.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: "integration_frame_error",
                ...t ? {
                    indeterminate: !0
                } : {},
                details: {
                    integration: s,
                    ...p ? {
                        message: p
                    } : {},
                    ...m
                }
            }
        })), i(), R("live_agent_file_upload_failed", {
            reason: "integration_frame_error",
            integration: s
        });
        return;
    }
    if (s === "fileUpload") {
        let t = c === "upload.cancel",
            a = c === "upload.start" || c === "upload.retry";
        if ((a || t) && !e.getState().liveAgent.file.isUploading) {
            R("live_agent_file_upload_result_ignored", {
                reason: "upload_not_in_progress",
                action: c,
                status: l
            });
            return;
        }
        if (a && (!r || u !== r)) {
            R("live_agent_file_upload_result_ignored", {
                reason: "stale_command",
                action: c,
                status: l
            });
            return;
        }
        if (t) {
            R("live_agent_file_upload_result_ignored", {
                reason: "cancel_result_ignored",
                action: c,
                status: l
            });
            return;
        }
        if (l === "success") {
            if (d ? .transfer) {
                let t = F(d.transfer);
                t && e.dispatch(Hn(t));
            }
            if (c === "upload.start" || c === "upload.retry") {
                let t = n.activeOperation ? .operationId;
                xy(e, n, d, i).catch((r) => {
                    t && yy(e, n, t, i, r);
                });
                return;
            }
        }
        if (l === "error") {
            let t = "FILE_UPLOAD_UNKNOWN_ERROR";
            f === "FILE_UPLOAD_UNSUPPORTED_TYPE" ? t = "FILE_UPLOAD_UNSUPPORTED_TYPE" : f === "FILE_UPLOAD_EXCEED_SIZE_LIMIT" ? t = "FILE_UPLOAD_EXCEED_SIZE_LIMIT" : f === "FILE_UPLOAD_ERROR" && (t = "FILE_UPLOAD_ERROR");
            let r = n.activeOperation ? .platformName === "zendesk_liveagent" && t === "FILE_UPLOAD_UNKNOWN_ERROR",
                a = Q(m.sdkErrorCode),
                o = Q(m.reason);
            n.activeOperation && (n.activeOperation.deliveryOutcome = r ? "indeterminate" : "failed");
            let s = {};
            r ? s = {
                indeterminate: !0
            } : t === "FILE_UPLOAD_ERROR" && !a && !o && (s = {
                retryable: !0
            }), e.dispatch(U({
                errorKey: t,
                errorData: {
                    reason: "integration_error",
                    ...f ? {
                        integrationErrorCode: f
                    } : {},
                    ...s,
                    details: m
                }
            })), i();
        }
        return;
    }
    if (s === "zendesk") {
        if (c === "transcript.send" && l === "error" && f === "zendesk_transcript_send_failed") {
            R("zendesk_transcript_send_failed", {
                sent: qo(m.sent) ? ? 0,
                failedChunkCount: Array.isArray(m.failedChunks) ? m.failedChunks.length : 0
            });
            return;
        }
        if (c === "sdk.teardown") {
            e.dispatch(ne());
            return;
        }
        if (c === "sdk.initialize" && l === "error" && f !== "zendesk_init_torn_down" && e.dispatch(Mt({
                sdkInitialized: !1,
                disconnected: !0
            })), c === "handoff.initialize") {
            if (l === "success" && d ? .tornDownDuringConnect === !0) return;
            if (l === "success") {
                e.dispatch(Mt({
                    chatClosed: !1,
                    endDelivered: !1
                })), d ? .availability === "department_not_found" && R("zendesk_department_not_found");
                let t = F(d ? .departmentError);
                t && R("zendesk_department_set_failed", {
                    code: Q(t.code) ? ? void 0,
                    message: Q(t.message) ? ? void 0
                });
                let n = Array.isArray(d ? .tags) ? d.tags.filter((e) => typeof e == "string") : null;
                if (n && n.length > 0) {
                    e.dispatch(Mt({
                        previousTags: n
                    }));
                    let t = e.getState().session.handle;
                    t && (Io() ? .set(st(t), JSON.stringify(n)), Gn());
                }
            } else e.dispatch(Mt({
                sdkInitialized: !1,
                disconnected: !0,
                reconnecting: !1
            }));
        }
        c === "department.set" && l === "error" && (e.dispatch(Mt({
            departmentStatus: null
        })), R("zendesk_department_set_failed", {
            code: f ? ? void 0,
            message: p ? ? void 0
        }));
        return;
    }
    if (s === "liveAgent") {
        if (c === "message.send" && l === "success") {
            let t = Q(d ? .id),
                n = qo(d ? .zendeskOperationSeq);
            if (t) {
                let r = gy(e, t),
                    i = _y(e, t, n);
                i && Hc(e, i.body, i.tempMessageUuid, i.conversationId) && e.dispatch(Ft(t)), r && e.dispatch(zi(t));
            }
            let r = Q(d ? .requestId);
            r && t && a ? .("core.message.response", {
                requestId: r,
                id: t
            });
        }
        c === "message.send" && l === "error" && Cy(e, m, f, p, a);
        return;
    }
    if (s === "zendeskMessaging") {
        if (c === "sdk.initialize") {
            e.dispatch(ce({
                initializationStatus: l === "success" ? 2 : 0,
                initialized: l === "success",
                disconnected: l === "error",
                reconnecting: !1
            }));
            return;
        }
        if (c === "conversation.load" && l === "success") {
            let t = Q(d ? .conversationId);
            t && e.dispatch(ce({
                conversationId: t
            }));
            return;
        }
    }
}
//#endregion
//#region src/orchestrator-live-agent-runtime.ts
var Ty = 15e3,
    Ey = 10,
    Dy = 1e3,
    Oy = 1.5,
    ky = 6e4,
    Ay = new Set([
        408,
        429,
        503,
        504
    ]);

function jy(e, t) {
    return `${e.endsWith("/") ? e : `${e}/`}${t}`;
}

function My(e, t) {
    return {
        "Content-Type": "application/json",
        "X-Ada-Request-Origin": "chat",
        "Chatter-Token": e,
        ...t ? {
            "Session-Auth": t
        } : {}
    };
}
async function Ny(e, t, n = {}) {
    let {
        endpoint: r,
        chatterToken: i,
        sessionId: a,
        sessionToken: o
    } = e.getState().session;
    if (!r || !i || !a) return {
        ok: !1,
        reason: "config"
    };
    let s = n.retryTransient ? Ey : 1,
        c = {
            ok: !1,
            reason: "network"
        };
    for (let e = 1; e <= s; e += 1) {
        if (n.shouldContinue && !n.shouldContinue()) return {
            ok: !1,
            reason: "config"
        };
        let l = new AbortController(),
            u = globalThis.setTimeout(() => {
                l.abort();
            }, Ty);
        try {
            let e = await fetch(jy(r, t), {
                method: "POST",
                credentials: "include",
                headers: My(i, o),
                body: JSON.stringify({
                    chatter_token: i,
                    chat_session: a
                }),
                signal: l.signal
            });
            if (e.ok || n.acceptBadRequest === !0 && e.status === 400) return {
                ok: !0
            };
            c = {
                ok: !1,
                reason: "http",
                status: e.status
            };
        } catch {
            c = {
                ok: !1,
                reason: l.signal.aborted ? "timeout" : "network"
            };
        } finally {
            globalThis.clearTimeout(u);
        }
        if (!(c.reason === "network" || c.reason === "timeout" || c.reason === "http" && typeof c.status == "number" && Ay.has(c.status)) || e === s) return c;
        let d = Math.random() * Math.min(ky, Dy * Oy ** e);
        await new Promise((e) => globalThis.setTimeout(e, d));
    }
    return c;
}

function Py(e) {
    return {
        ...e.reason ? {
            reason: e.reason
        } : {},
        ...typeof e.status == "number" ? {
            status: e.status
        } : {}
    };
}

function Fy(e, t) {
    let n = t.platform.trim();
    n && (e.dispatch(di()), e.dispatch(gr({
        platformName: n,
        departmentId: typeof t.departmentId == "number" ? t.departmentId : void 0
    })), e.dispatch(ao({
        stateType: Ue,
        inState: !0
    })), e.dispatch(Da(!1)), R("live_agent_handoff_requested", {
        platform: n
    }));
}

function Iy(e) {
    e.dispatch(ao({
        stateType: null,
        inState: !1
    })), e.dispatch($o(null)), R("live_agent_handoff_cancelled");
}

function Ly(e, t) {
    let n = e.getState(),
        {
            endpoint: r,
            chatterToken: i,
            conversationId: a,
            sessionToken: o
        } = n.session,
        {
            zendeskOperationSeq: s
        } = n.liveAgent;
    !r || !i || zn(e, {
        url: jy(r, "webhooks/chat"),
        method: "POST",
        credentials: "include",
        bindLifecycleSignal: !1,
        keepalive: !0,
        body: {
            type: t,
            by: i
        }
    }, {
        isCurrent: () => e.getState().session.chatterToken === i && e.getState().session.sessionToken === o && e.getState().session.conversationId === a && e.getState().liveAgent.zendeskOperationSeq === s
    }).catch(() => {
        R("live_agent_chatter_closed_webhook_failed");
    });
}

function Ry(e, t = !1) {
    let n = e.getState().liveAgent,
        r = n.inLiveChat || n.inPending;
    e.dispatch(Da(!0)), e.dispatch(ao({
        stateType: ft,
        inState: !1
    })), e.dispatch($o(null)), e.dispatch(Ii()), R("live_agent_chat_ended_by_user"), Ly(e, !t && r ? "close_live_agent_conversation" : "chatter_closed");
}

function zy(e) {
    e.dispatch(ao({
        stateType: null,
        inState: !1
    })), e.dispatch($o(null)), e.dispatch(Ii()), R("live_agent_leg_ended_by_user"), Ly(e, "close_live_agent_conversation");
}
async function By(e) {
    let {
        retryDialog: t
    } = e.getState().liveAgent;
    if (!t.visible || t.pending) return;
    e.dispatch(E(!0));
    let n = e.getState().liveAgent.retryDialogOperationSeq,
        r = await Ny(e, "message/live_chat/retry/", {
            retryTransient: !0,
            shouldContinue: () => e.getState().liveAgent.retryDialogOperationSeq === n && e.getState().liveAgent.retryDialog.pending
        }),
        i = e.getState().liveAgent;
    if (!(!i.retryDialog.pending || i.retryDialogOperationSeq !== n)) {
        if (r.ok) {
            e.dispatch(un()), R("live_agent_handoff_retry_confirmed");
            return;
        }
        e.dispatch(E(!1)), R("live_agent_handoff_retry_failed", Py(r));
    }
}
async function Vy(e) {
    let {
        retryDialog: t,
        inPending: n
    } = e.getState().liveAgent;
    if (!t.visible || t.pending) return;
    if (!n) {
        e.dispatch(un()), R("live_agent_handoff_retry_dismissed");
        return;
    }
    e.dispatch(E(!0));
    let r = e.getState().liveAgent.retryDialogOperationSeq,
        i = await Ny(e, "message/live_chat/cancel/", {
            acceptBadRequest: !0,
            retryTransient: !0,
            shouldContinue: () => e.getState().liveAgent.retryDialogOperationSeq === r && e.getState().liveAgent.retryDialog.pending
        });
    if (!(!e.getState().liveAgent.retryDialog.pending || e.getState().liveAgent.retryDialogOperationSeq !== r)) {
        if (i.ok) {
            e.dispatch(un()), Iy(e), R("live_agent_handoff_retry_cancelled");
            return;
        }
        e.dispatch(E(!1)), R("live_agent_handoff_retry_cancel_failed", Py(i));
    }
}

function Hy(e) {
    let {
        retryDialog: t,
        zendesk: n
    } = e.getState().liveAgent;
    if (n.fatalRequestErrorReached) {
        if (n.fatalRequestErrorPending) return;
        e.dispatch(Mt({
            fatalRequestErrorReached: !1,
            fatalRequestErrorPending: !1,
            fatalRequestErrorCancelFailed: !1
        })), R("live_agent_fatal_handoff_dialog_dismissed");
        return;
    }
    t.visible && !t.pending && (e.dispatch(un()), R("live_agent_handoff_retry_dialog_dismissed"));
}
async function Uy(e) {
    let {
        zendesk: t
    } = e.getState().liveAgent;
    if (!t.fatalRequestErrorReached || t.fatalRequestErrorPending) return;
    let n = e.getState().liveAgent.zendeskOperationSeq;
    e.dispatch(ia());
    let r = e.getState().liveAgent.zendeskOperationSeq,
        i = await Ny(e, "message/live_chat/cancel/", {
            acceptBadRequest: !0,
            retryTransient: !0,
            shouldContinue: () => e.getState().liveAgent.zendeskOperationSeq === r && e.getState().liveAgent.zendesk.fatalRequestErrorPending
        }),
        a = e.getState().liveAgent;
    if (!(!a.zendesk.fatalRequestErrorPending || a.zendeskOperationSeq !== r)) {
        if (!i.ok) {
            e.dispatch(Mt({
                fatalRequestErrorPending: !1,
                fatalRequestErrorCancelFailed: !0
            })), Fo(e, n), R("live_agent_fatal_handoff_cancel_failed", Py(i));
            return;
        }
        e.dispatch(Mt({
            fatalRequestErrorReached: !1,
            fatalRequestErrorPending: !1,
            fatalRequestErrorCancelFailed: !1
        })), Iy(e), e.dispatch(yi({
            integration: "liveAgent",
            action: "handoff.cancel",
            payload: {}
        })), R("live_agent_fatal_handoff_cancelled");
    }
}
async function Wy(e) {
    let {
        inPending: t,
        retryDialog: n,
        queueCancelPending: r
    } = e.getState().liveAgent;
    if (!t || n.visible || r) return;
    e.dispatch(ko(!0));
    let i = e.getState().liveAgent.queueCancelSeq,
        a = await Ny(e, "message/live_chat/cancel/", {
            acceptBadRequest: !0,
            retryTransient: !0,
            shouldContinue: () => e.getState().liveAgent.queueCancelSeq === i && e.getState().liveAgent.queueCancelPending
        }),
        o = e.getState().liveAgent;
    if (!(!o.queueCancelPending || o.queueCancelSeq !== i)) {
        if (e.dispatch(ko(!1)), !a.ok) {
            R("live_agent_queue_cancel_failed", Py(a));
            return;
        }
        if (!o.inPending) {
            R("live_agent_queue_cancel_superseded");
            return;
        }
        Iy(e), R("live_agent_queue_cancelled");
    }
}
async function Gy(e, t) {
    let n = t.trim();
    if (!n) return;
    let r = e.store.getState().liveAgent.platformName;
    R("live_agent_message_send_requested", {
        platform: r
    }), await e.onSendMessage(n);
}

function Ky(e) {
    R("live_agent_chatter_typing", {
        isTyping: e
    });
}

function qy(e) {
    R("live_agent_visitor_info_set", {
        hasDisplayName: typeof e.displayName == "string",
        hasEmail: typeof e.email == "string",
        hasPhone: typeof e.phone == "string"
    });
}
var Jy = class {
        constructor(e, t, n = () => void 0) {
            L(this, "store", void 0), L(this, "onSendMessage", void 0), L(this, "onEndLiveAgentChat", void 0), this.store = e, this.onSendMessage = t, this.onEndLiveAgentChat = n;
        }
        requestLiveAgentHandoff(e) {
            Fy(this.store, e);
        }
        cancelLiveAgentHandoff() {
            Iy(this.store);
        }
        endLiveAgentChat(e = !1) {
            this.onEndLiveAgentChat(), Ry(this.store, e);
        }
        endLiveAgentLeg() {
            this.onEndLiveAgentChat(), zy(this.store);
        }
        async confirmRetryDialog() {
            await By(this.store);
        }
        async dismissRetryDialog() {
            await Vy(this.store);
        }
        dismissHandoffDialog() {
            Hy(this.store);
        }
        async cancelFatalHandoff() {
            await Uy(this.store);
        }
        async cancelQueue() {
            await Wy(this.store);
        }
        async sendLiveAgentMessage(e) {
            await Gy({
                store: this.store,
                onSendMessage: this.onSendMessage
            }, e);
        }
        setLiveAgentTyping(e) {
            Ky(e);
        }
        setLiveAgentVisitorInfo(e) {
            qy(e);
        }
    },
    Yy = 6e4,
    Xy = 2 * 6e4,
    Zy = [
        5e3,
        1e4,
        2e4,
        4e4
    ],
    Qy = 6e4,
    $y = "ada_outage_backoff";

function eb(e, t, n) {
    R("messaging_outage_fallback_shown", {
        outageType: e,
        reason: t,
        ...n
    }), gt("outage fallback shown", {
        fallbackMessageShown: !0,
        outageType: e,
        reason: t,
        ...n
    }, "warn");
}

function tb(e, t) {
    R("messaging_outage_escalated", {
        outageType: e,
        reason: "response_timeout",
        attempt: t
    }), gt("outage escalated", {
        outageType: e,
        reason: "response_timeout",
        attempt: t
    }, "warn");
}

function nb(e) {
    return Zy[e] ? ? Qy;
}

function rb() {
    let e = Io();
    if (e) {
        let t = e.get($y);
        return t !== null && Number.isFinite(Number(t)) ? Number(t) : 0;
    }
    try {
        let e = window.localStorage.getItem($y);
        return e !== null && Number.isFinite(Number(e)) ? Number(e) : 0;
    } catch {
        return 0;
    }
}

function ib(e) {
    let t = Io();
    if (t) {
        t.set($y, String(e));
        return;
    }
    try {
        window.localStorage.setItem($y, String(e));
    } catch {}
}

function ab() {
    let e = Io();
    if (e) {
        e.remove($y);
        return;
    }
    try {
        window.localStorage.removeItem($y);
    } catch {}
}

function ob(e) {
    let {
        store: t,
        onRetry: n
    } = e, r = null, i = null, a = null, o = null, s = t.getState().chat.isSending, c = w(), l = T(), u = t.getState().chat.serverProgressSeq, d = E(), f = t.getState().session.conversationGeneration, p = !1, m = t.getState().chat.sentMessageAck ? .seq ? ? 0, g = !0, _ = !1, v = Yy, y = Xy, b = null, x = 0, S = !1, C = !1;

    function w() {
        let {
            messages: e
        } = t.getState().chat;
        return e.filter((e) => e.sender === "bot" || e.sender === "agent").length;
    }

    function T() {
        let {
            chat: e,
            liveAgent: n
        } = t.getState();
        return n.isActive || e.captureData !== null || e.listSelectionData !== null;
    }

    function E() {
        return t.getState().connection.connectivityLost;
    }

    function D() {
        if (!b) return;
        let e = Math.max(0, Date.now() - x);
        b === "delayed" ? v = Math.max(0, v - e) : y = Math.max(0, y - e), b = null;
    }

    function O() {
        v = Yy, y = Xy, b = null, S = !1, C = !1;
    }

    function k() {
        r && clearTimeout(r), i && clearTimeout(i), a && clearTimeout(a), r = null, i = null, a = null;
    }

    function A() {
        return w() > c;
    }

    function j() {
        O(), te();
    }

    function te() {
        if (k(), b = null, c = w(), T() || E()) {
            E() && R("messaging_outage_ladder_suppressed_connectivity");
            return;
        }
        if (x = Date.now(), v > 0) {
            b = "delayed", r = setTimeout(ne, v);
            return;
        }
        M(), re();
    }

    function ne() {
        r = null, v = 0, M(), re();
    }

    function M() {
        _ = !0, t.dispatch(Lt(!0)), t.dispatch(Jo()), t.dispatch(ee()), t.dispatch(Te()), t.dispatch(h("CHAT_OUTAGE_MID_CONVERSATION")), S || (S = !0, eb("CHAT_OUTAGE_MID_CONVERSATION", "response_timeout"));
    }

    function re() {
        b = "fullPage", x = Date.now(), i = setTimeout(() => {
            i = null, b = null, y = 0;
            let e = rb();
            ib(e + 1), t.dispatch(h("CHAT_OUTAGE_FULL_PAGE")), C || (C = !0, tb("CHAT_OUTAGE_FULL_PAGE", e + 1)), a = setTimeout(() => {
                a = null, n();
            }, nb(e));
        }, y);
    }

    function ie() {
        let e = t.getState().outage;
        return (e.type === "CHAT_OUTAGE_MID_CONVERSATION" || e.responseDelayed) && A();
    }

    function N() {
        let e = t.getState(),
            n = e.chat.isSending,
            r = T(),
            i = e.connection.connectivityLost,
            a = e.session.conversationGeneration,
            o = e.chat.serverProgressSeq,
            h = n && !s,
            v = o !== u,
            y = r && !l,
            b = i && !d,
            x = !i && d,
            S = e.chat.sentMessageAck ? .seq ? ? 0,
            C = S > m;
        m = S;
        let E = a !== f;
        s = n, l = r, u = o, d = i, f = a, e.outage.type === null && !e.outage.responseDelayed && (_ = !1), (y || b || E) && (D(), k(), (y || E) && (O(), p = !1, g = !0), (y || E || _) && (e.outage.type !== null || e.outage.responseDelayed) && (_ = !1, t.dispatch(ae()))), h && (g = !1, j()), C && !g && !r && (p = !0), x && p && (R("messaging_outage_wait_resumed_after_connectivity"), te()), v && (e.outage.type !== null || e.outage.responseDelayed ? oe() : (k(), O(), p = !1, g = !0, c = w())), ie() ? oe() : A() && (k(), O(), p = !1, g = !0, c = w());
    }
    o = t.subscribe(N);

    function oe() {
        k(), ab(), O(), p = !1, g = !0, _ = !1, c = w(), t.dispatch(le()), t.dispatch(ae()), t.dispatch(ta(!0));
    }

    function se() {
        k(), O(), p = !1, g = !0;
    }

    function ce() {
        k(), o && = (o(), null);
    }
    return {
        onServiceRestored: oe,
        cancelTracking: se,
        destroy: ce
    };
}
//#endregion
//#region src/orchestrator-salesforce-network.ts
var sb = 12e4;

function cb(e) {
    return e.endsWith("/") ? e : `${e}/`;
}

function lb(e) {
    return `${cb(e)}salesforce_file_transfer`;
}
async function ub({
    store: e,
    file: t,
    uploadState: n,
    clearFileUploadCommandTracking: r,
    onCaptureException: i
}) {
    let a = e.getState();
    if (!a.liveAgent.file.isUploading) return !1;
    let o = {
            store: e,
            uploadState: n
        },
        s = Qv(o, t),
        {
            endpoint: c,
            conversationId: l
        } = s,
        u = n.activeController;
    if (u && (u.abort(), n.activeController = null), !c) return e.dispatch(U({
        errorKey: "FILE_UPLOAD_ERROR",
        errorData: {
            reason: "invalid_context"
        }
    })), R("salesforce_file_upload_failed", {
        status: "invalid_context"
    }), r(), !1;
    let d = a.liveAgent.file.transfer,
        f = d ? .sessionId,
        p = d ? .fileToken,
        m = d ? .uploadServletUrl;
    if (!f || !p || !m) return e.dispatch(U({
        errorKey: "FILE_UPLOAD_ERROR",
        errorData: {
            reason: "missing_transfer_data"
        }
    })), R("salesforce_file_upload_failed", {
        status: "missing_transfer_data"
    }), r(), !1;
    R("salesforce_file_upload_requested", {
        size: t.size,
        type: t.type
    });
    let h = new AbortController();
    n.activeController = h;
    let g = !1,
        _ = globalThis.setTimeout(() => {
            g = !0, h.abort();
        }, sb);
    try {
        let i = new FormData();
        i.append("file", t), i.append("chatId", f), i.append("fileToken", p), i.append("instanceUrl", m), l && i.append("conversationId", l), s.deliveryOutcome = "sending";
        let a = await fetch(lb(c), {
            method: "POST",
            credentials: "include",
            body: i,
            signal: h.signal
        });
        if (g && n.activeOperation ? .operationId === s.operationId && n.activeController === h) return s.deliveryOutcome = "indeterminate", e.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: "delivery_unknown",
                indeterminate: !0
            }
        })), r(), !1;
        if (!$v(o, s, h)) return R("salesforce_file_upload_ignored", {
            reason: "stale_upload_operation"
        }), !1;
        if (!a.ok) {
            let t = a.status === 408 || a.status >= 500;
            return s.deliveryOutcome = t ? "indeterminate" : "failed", e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: t ? "delivery_unknown" : "http_error",
                    status: a.status,
                    ...t ? {
                        indeterminate: !0
                    } : {}
                }
            })), R("salesforce_file_upload_failed", {
                status: a.status
            }), !1;
        }
        return e.dispatch(Hn({
            type: "Uploaded",
            fileName: t.name,
            fileSize: t.size,
            progress: 100
        })), e.dispatch(De()), e.dispatch(it()), ey(n, s), r(), R("salesforce_file_upload_succeeded"), !0;
    } catch (t) {
        if (!(n.activeOperation ? .operationId === s.operationId && n.activeController === h)) return !1;
        let a = g || t instanceof DOMException && t.name === "AbortError";
        return !g && h.signal.aborted ? (R("salesforce_file_upload_cancelled"), !1) : (s.deliveryOutcome = "indeterminate", e.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: "delivery_unknown",
                indeterminate: !0
            }
        })), r(), R("salesforce_file_upload_failed", {
            status: a ? "timeout" : "network_error"
        }), a || i(t, {
            endpoint: c
        }), !1);
    } finally {
        globalThis.clearTimeout(_), n.activeController === h && (n.activeController = null);
    }
}
//#endregion
//#region src/orchestrator-transcript-transport.ts
var db = 15e3,
    fb = "transcript.txt",
    pb = 180,
    mb = 6e4;

function hb(e, t) {
    return `${yt(e)}chatters/${encodeURIComponent(t)}/transcript/txt/?remove_summary=true`;
}

function gb(e, t, n) {
    let r = new URL(hb(e, t), globalThis.location.href);
    return n && r.searchParams.set("session_token", n), r.href;
}

function _b(e, t) {
    return `${yt(e)}chatters/${encodeURIComponent(t)}/transcript/email/`;
}

function vb(e) {
    let t = Array.from(e).filter((e) => {
        let t = e.charCodeAt(0);
        return t >= 32 && t !== 127;
    }).join("").trim();
    if (!t) return fb;
    let n = (t.replace(/\\/g, "/").split("/").filter(Boolean).pop() ? ? "").replace(/\s+/g, " ").trim().replace(/[<>:"|?*]/g, "_").replace(/^\.+/, "").slice(0, pb);
    return !n || n === "." || n === ".." ? fb : n;
}

function yb(e) {
    if (!e) return fb;
    let t = /filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i.exec(e),
        n = t ? .[1] ? ? t ? .[2] ? ? "";
    if (!n.trim()) return fb;
    try {
        return vb(decodeURIComponent(n));
    } catch {
        return vb(n);
    }
}

function bb(e) {
    let t = document.createElement("iframe");
    t.setAttribute("sandbox", "allow-downloads"), t.hidden = !0, t.title = "Ada transcript download", t.lang = "en", t.src = e, document.body.append(t), globalThis.setTimeout(() => {
        t.remove();
    }, mb);
}

function xb(e, t) {
    let n = globalThis.URL.createObjectURL(e),
        r = document.createElement("a");
    r.href = n, r.download = t, document.body.append(r), r.click(), r.remove(), globalThis.setTimeout(() => {
        globalThis.URL.revokeObjectURL(n);
    }, 0);
}
async function Sb(e, t) {
    let n = t.trim(),
        {
            endpoint: r,
            chatterToken: i,
            conversationId: a,
            sessionToken: o,
            emailTranscriptEnabled: s,
            transcriptEmailPendingEmail: c
        } = e.store.getState().session;
    if (!s) return e.store.dispatch(Wt()), R("transcript_email_ignored", {
        reason: "feature_disabled"
    }), !1;
    if (c !== null) return n === c ? (R("transcript_email_ignored", {
        reason: "request_in_progress"
    }), !1) : (e.store.dispatch(Ot(n)), R("transcript_email_ignored", {
        reason: "conflicting_request_in_progress"
    }), !1);
    if (!n || !r || !i) return e.store.dispatch(Wt()), !1;
    e.store.dispatch(be(n)), R("transcript_email_requested");
    let l = new AbortController(),
        u = globalThis.setTimeout(() => {
            l.abort();
        }, db);
    try {
        let t = await zn(e.store, {
            url: _b(r, i),
            method: "POST",
            bindLifecycleSignal: !1,
            keepalive: !0,
            body: {
                email: n
            },
            signal: l.signal,
            timeoutMs: db
        }, {
            isCurrent: () => e.store.getState().session.chatterToken === i && e.store.getState().session.sessionToken === o && e.store.getState().session.conversationId === a
        });
        return t.ok ? (e.store.dispatch(We()), R("transcript_email_succeeded"), !0) : (e.store.dispatch(Wt()), R("transcript_email_failed", {
            status: t.status
        }), !1);
    } catch (t) {
        return e.store.dispatch(Wt()), R("transcript_email_failed", {
            status: t instanceof DOMException && t.name === "AbortError" ? "timeout" : "network_error"
        }), t instanceof DOMException && t.name === "AbortError" || e.onCaptureException(t, {
            endpoint: r
        }), !1;
    } finally {
        globalThis.clearTimeout(u);
    }
}
async function Cb(e) {
    let {
        endpoint: t,
        chatterToken: n,
        sessionToken: r,
        downloadTranscriptEnabled: i,
        transcriptDownloadRequestStatus: a
    } = e.store.getState().session;
    if (!i) return e.store.dispatch(m()), R("transcript_download_ignored", {
        reason: "feature_disabled"
    }), !1;
    if (a === "pending") return R("transcript_download_ignored", {
        reason: "request_in_progress"
    }), !1;
    if (!t || !n) return e.store.dispatch(m()), !1;
    e.store.dispatch(qi()), R("transcript_download_requested");
    let o = new AbortController(),
        s = globalThis.setTimeout(() => {
            o.abort();
        }, db);
    try {
        let i = await fetch(hb(t, n), {
            method: "GET",
            headers: {
                "X-Ada-Request-Origin": "chat",
                ...r ? {
                    "Session-Auth": r
                } : {}
            },
            signal: o.signal
        });
        if (!i.ok) return e.store.dispatch(m()), R("transcript_download_failed", {
            status: i.status
        }), !1;
        if (zo(globalThis.navigator ? .userAgent ? ? "")) return i.body ? .cancel().catch(() => void 0), bb(gb(t, n, r)), e.store.dispatch(xt()), R("transcript_download_link_opened"), !0;
        let a = yb(i.headers.get("content-disposition"));
        return xb(await i.blob(), a), e.store.dispatch(xt()), R("transcript_download_succeeded"), !0;
    } catch (n) {
        return e.store.dispatch(m()), R("transcript_download_failed", {
            status: n instanceof DOMException && n.name === "AbortError" ? "timeout" : "network_error"
        }), n instanceof DOMException && n.name === "AbortError" || e.onCaptureException(n, {
            endpoint: t
        }), !1;
    } finally {
        globalThis.clearTimeout(s);
    }
}
//#endregion
//#region src/orchestrator-transport-revalidation.ts
var wb = B("transport-revalidation"),
    Tb = 3e4;

function Eb(e) {
    e.timer !== null && (clearInterval(e.timer), e.timer = null), e.activeRun ? .abort(), e.activeRun = null, e.inFlight = !1, e.withdrawalStreak = 0;
}
async function Db(e) {
    let {
        state: t
    } = e;
    if (t.inFlight) return;
    let n = e.now();
    if (n - t.lastCheckedAt < 15e3) return;
    t.lastCheckedAt = n;
    let r = e.getClientConfigUrl();
    if (!r) return;
    let i = new AbortController();
    t.inFlight = !0, t.activeRun = i;
    try {
        let a = await e.store.dispatch(G.endpoints.getClientConfig.initiate({
            url: r,
            requestScope: "transport-revalidation"
        }, {
            forceRefetch: !0,
            subscribe: !1
        }));
        if (i.signal.aborted || t.activeRun !== i || !a.data) return;
        let o = j_(a.data);
        t.withdrawalStreak = o ? t.withdrawalStreak + 1 : 0;
        let s = !!(a.data.websocket_endpoint ? ? null),
            c = e.isWebSocketTransport();
        if (s === c && !o || !e.isSwapSafe()) return;
        if (o) {
            if (e.isTransportConnected() && t.withdrawalStreak < 2) return;
            wb.info("Transport routing changed; swapping transport", {
                from: c ? "websocket" : "pusher",
                to: "degraded",
                reason: "credentials_withdrawn"
            }), R("transport_revalidation_swap", {
                to: "degraded",
                reason: "credentials_withdrawn"
            }), await e.swapTransport(a.data, i.signal);
            return;
        }
        if (t.lastSwapAt > 0 && n - t.lastSwapAt >= 3e5 && (t.swapCount = 0, t.giveUpReported = !1), t.swapCount >= 3) {
            t.giveUpReported || (t.giveUpReported = !0, R("transport_revalidation_giveup", {
                swaps: t.swapCount
            }), wb.error(`Pausing transport swaps after ${t.swapCount} in quick succession; /client-config keeps disagreeing with the live transport (check for a half-rolled fleet). Checks continue and swapping resumes once it settles.`));
            return;
        }
        t.swapCount += 1, t.lastSwapAt = n, wb.info("Transport routing changed; swapping transport", {
            from: c ? "websocket" : "pusher",
            to: s ? "websocket" : "pusher",
            swap: t.swapCount
        }), R("transport_revalidation_swap", {
            to: s ? "websocket" : "pusher",
            swap: t.swapCount
        }), await e.swapTransport(a.data, i.signal);
    } catch (e) {
        if (i.signal.aborted || t.activeRun !== i) return;
        wb.warn("Transport revalidation failed", {
            err: e.message
        });
    } finally {
        t.activeRun === i && (t.activeRun = null, t.inFlight = !1);
    }
}

function Ob(e) {
    e.state.withdrawalStreak = 0, e.state.lastCheckedAt === 0 && (e.state.lastCheckedAt = e.now()), e.state.timer !== null && clearInterval(e.state.timer), e.state.timer = setInterval(() => {
        Db(e);
    }, Tb);
}
//#endregion
//#region src/orchestrator-voice-runtime.ts
function kb(e) {
    e.dispatch(xr()), R("voice_recording_started");
}

function Ab(e) {
    e.dispatch(Po()), R("voice_recording_stopped");
}

function jb(e, t) {
    e.dispatch(wi(t)), R("voice_mode_changed", {
        mode: t
    });
}

function Mb(e, t) {
    e.dispatch(Rr(t)), R("voice_tts_toggled", {
        enabled: t
    });
}

function Nb(e, t, n) {
    e.dispatch(Xo({
        transcript: t,
        isFinal: n
    })), n && R("voice_transcript_finalized", {
        length: t.length
    });
}

function Pb(e, t) {
    e.dispatch(Mi(t)), R("voice_error", {
        error: t
    });
}

function Fb(e, t) {
    e.dispatch(ha(t));
}
var Ib = class {
        constructor(e) {
            L(this, "store", void 0), this.store = e;
        }
        startVoiceRecording() {
            kb(this.store);
        }
        stopVoiceRecording() {
            Ab(this.store);
        }
        setVoiceMode(e) {
            jb(this.store, e);
        }
        toggleTTS(e) {
            Mb(this.store, e);
        }
        handleVoiceTranscript(e, t) {
            Nb(this.store, e, t);
        }
        handleVoiceError(e) {
            Pb(this.store, e);
        }
        handleVoiceAudioLevel(e) {
            Fb(this.store, e);
        }
    },
    Lb = B("zd-chat-auth"),
    Rb = "adaGlassZendeskChatterAuth",
    zb = "zendeskMessagingChatterAuth",
    Bb = 1e3,
    Vb = 3e4,
    Hb = 5,
    Ub = 2147483647,
    Wb = 6e4;

function Gb(e) {
    let {
        features: t
    } = e.getState().session;
    return t[Rb] === !0;
}

function Kb(e) {
    return e.getState().session[zb] === !0;
}

function qb(e) {
    return Gb(e) || Kb(e);
}

function Jb(e) {
    let t = e,
        n = t ? .status === "PARSING_ERROR" ? t.originalStatus : t ? .status;
    return n === 0 || n === "FETCH_ERROR" || n === "TIMEOUT_ERROR" || typeof n == "number" && n >= 500 && n < 600 || e instanceof TypeError;
}

function Yb(e) {
    let t = e;
    return t ? .name === "AbortError" || t ? .data === "Request aborted because a caller or the lifecycle cancelled it.";
}

function Xb(e, t, n, r, i) {
    let a = r,
        o = i,
        s = null,
        c = null,
        l = Bb,
        u = 0,
        d = new AbortController(),
        {
            chatterToken: f,
            endpoint: p
        } = e.store.getState().session,
        m = Kb(e.store),
        h = m && !Gb(e.store),
        g = () => {
            d.abort(), a = void 0, o = void 0, c ? .(), c = null, s !== null && (clearTimeout(s), s = null), t ? .removeEventListener("abort", g);
        };
    t ? .addEventListener("abort", g, {
        once: !0
    }), t ? .aborted && g();

    function _(e) {
        d.signal.aborted || h || (s !== null && clearTimeout(s), s = setTimeout(() => {
            s = null, b();
        }, e));
    }

    function v(e) {
        _(Math.min(Math.max(e - Wb, Math.floor(e / 2)), Ub));
    }

    function y() {
        if (u >= Hb) {
            Lb.warn("Zendesk Chat auth retry limit reached");
            return;
        }
        u += 1, _(l), l = Math.min(l * 2, Vb);
    }
    async function b() {
        if (d.signal.aborted) return;
        if (!f || !p) {
            Lb.warn("No chatterToken available for Zendesk Chat auth");
            return;
        }
        let t = async (t) => {
            let n = e.store.dispatch(G.endpoints.submitZendeskChatterAuth.initiate({
                endpoint: p,
                chatterToken: f,
                token: t
            }));
            c = () => n.abort ? .();
            let r = await n;
            return c = null, r;
        };
        try {
            let n = a !== void 0,
                r = await (a === void 0 ? Zb(e, d.signal) : {
                    token: a,
                    error: o
                });
            if (a = void 0, o = void 0, d.signal.aborted || e.store.getState().session.chatterToken !== f) return;
            if (!r.token || r.error === "no_callback" || r.error === "callback_error") {
                let e = !r.token && r.error === void 0 || r.error === "no_callback" || r.error === "invalid_token";
                if (m && e) {
                    Lb.warn("Zendesk Messaging auth: no token received; continuing startup");
                    let e = await t("").catch((e) => ({
                        error: e
                    }));
                    if (d.signal.aborted || Yb(e.error)) return;
                    "error" in e && Lb.warn("Zendesk Messaging auth clear PATCH failed; continuing startup");
                } else m && Lb.warn("Zendesk Messaging auth: callback did not answer; keeping stored identity");
                if (h) return;
                Lb.warn("Zendesk Chat auth: no token received", r.error), (n || r.error === "timeout" || r.error === "core_timeout") && y();
                return;
            }
            let i = await t(r.token);
            if (d.signal.aborted) return;
            if ("error" in i || !i.data || m && i.data.status === "error") {
                if (Yb(i.error) || (m && (Lb.warn("Zendesk Messaging auth PATCH failed; continuing startup", i.error ? ? i), i.error instanceof Error && P(i.error, {
                        context: "zendesk-messaging-auth"
                    })), h)) return;
                Lb.error("Zendesk Chat auth PATCH failed:", i), !m && i.error instanceof Error && P(i.error, {
                    context: "zendesk-chat-auth"
                }), (n || Jb(i.error)) && y();
                return;
            }
            if (h) return;
            let {
                expireIn: s
            } = i.data;
            s > 0 ? (u = 0, l = Bb, v(s)) : Lb.warn("Zendesk Chat auth PATCH returned no usable expiry");
        } catch (e) {
            if (d.signal.aborted || Yb(e) || (m && (Lb.warn("Zendesk Messaging auth failed; continuing startup", e), e instanceof Error && P(e, {
                    context: "zendesk-messaging-auth"
                })), h)) return;
            Lb.error("Zendesk Chat auth flow failed:", e), (!m || !(e instanceof Error)) && P(e instanceof Error ? e : Error(String(e)), {
                context: "zendesk-chat-auth"
            }), Jb(e) && y();
        } finally {
            c = null;
        }
    }
    return n !== void 0 && (n > 0 ? v(n) : y()), {
        ready: n === void 0 ? b() : Promise.resolve(),
        destroy: g
    };
}

function Zb(e, t) {
    return new Promise((n, r) => {
        if (t.aborted) {
            n({
                token: null
            });
            return;
        }
        let i = I(),
            a = (e) => {
                clearTimeout(c), s(), t.removeEventListener("abort", o);
                let r = typeof e == "object" && e ? e : {};
                n({
                    token: typeof r.token == "string" ? r.token : null,
                    error: typeof r.error == "string" ? r.error : void 0
                });
            },
            o = () => a({
                token: null
            }),
            s = e.onSdkMessage("sdk.zd.auth.response", (e) => {
                typeof e == "object" && e && e.requestId === i && a(e);
            }),
            c = setTimeout(() => a({
                token: null,
                error: "core_timeout"
            }), _);
        t.addEventListener("abort", o, {
            once: !0
        });
        try {
            e.sendToParent("core.zd.auth.request", {
                requestId: i,
                chatterToken: e.store.getState().session.chatterToken ? ? ""
            });
        } catch (e) {
            clearTimeout(c), s(), t.removeEventListener("abort", o), r(e);
        }
    });
}

function Qb(e) {
    let t = null,
        n = null,
        r, i = null,
        a = !1,
        o = !1,
        s = () => {
            a = !0, i = null, n && (n.token = void 0, n.error = void 0), c();
        };

    function c() {
        t ? .signal ? .removeEventListener("abort", s), t ? .refresh.destroy(), t = null;
    }

    function l() {
        let {
            chatterToken: r,
            _chatterAnnouncementSuppressed: l
        } = e.store.getState().session, u = e.getLifecycleSignal ? .();
        if (t && (t.chatterToken !== r || t.signal !== u) && c(), o || a || u ? .aborted || !r || !qb(e.store) || l && i !== r) {
            c();
            return;
        }
        if (t) return;
        let d, f, p;
        n ? .chatterToken === r && (Kb(e.store) ? (f = n.token, p = n.error) : n.expiresAt === null ? d = 0 : n.expiresAt > Date.now() && (d = n.expiresAt - Date.now())), n = null, t = {
            chatterToken: r,
            signal: u,
            refresh: Xb(e, u, d, f, p)
        }, u ? .addEventListener("abort", s, {
            once: !0
        });
    }
    let u = e.store.subscribe(l);
    return l(), {
        async requestToken(t) {
            if (r = void 0, o || t.aborted || !qb(e.store)) return null;
            let n = await Zb(e, t);
            return r = n.error, t.aborted ? null : n.token;
        },
        seed(t, i, a) {
            qb(e.store) && (n = {
                chatterToken: t,
                expiresAt: i > 0 ? Date.now() + i : null,
                token: Kb(e.store) ? a : void 0,
                error: r
            });
        },
        async authenticate(n) {
            n.aborted || o || (a = !1, i = e.store.getState().session.chatterToken, l(), await t ? .refresh.ready);
        },
        destroy() {
            o = !0, n = null, u(), c();
        }
    };
}
//#endregion
//#region src/orchestrator-zendesk-messaging-network.ts
var $b = 12e4,
    ex = "zendesk_messaging_glass/";

function tx(e) {
    return e.endsWith("/") ? e : `${e}/`;
}

function nx(e) {
    return `${tx(e)}${ex}attachment_upload`;
}

function rx(e) {
    let t = F(F(e) ? .attachment),
        n = O(t ? .mediaName, {
            trimOutput: !1
        }),
        r = O(t ? .mediaUrl),
        i = O(t ? .mediaType);
    return !n || !r || !i ? null : {
        mediaName: n,
        mediaUrl: r,
        mediaType: i
    };
}
async function ix({
    store: e,
    file: t,
    uploadState: n,
    clearFileUploadCommandTracking: r,
    onCaptureException: i
}) {
    if (!e.getState().liveAgent.file.isUploading) return !1;
    let a = {
            store: e,
            uploadState: n
        },
        o = Qv(a, t),
        {
            endpoint: s,
            chatterToken: c,
            sessionToken: l
        } = o,
        u = n.activeController;
    if (u && (u.abort(), n.activeController = null), !s || !c) return e.dispatch(U({
        errorKey: "FILE_UPLOAD_ERROR",
        errorData: {
            reason: "invalid_context"
        }
    })), R("zendesk_messaging_attachment_upload_failed", {
        status: "invalid_context"
    }), r(), !1;
    R("zendesk_messaging_attachment_upload_requested", {
        size: t.size,
        type: t.type
    });
    let d = new AbortController();
    n.activeController = d;
    let f = !1,
        p = globalThis.setTimeout(() => {
            f = !0, d.abort();
        }, $b);
    try {
        if (!o.deliveredMedia) {
            let i = new FormData();
            i.append("file", t);
            let u = await fetch(nx(s), {
                method: "POST",
                credentials: "include",
                headers: {
                    "X-Ada-Request-Origin": "chat",
                    "Chatter-Token": c,
                    ...l ? {
                        "Session-Auth": l
                    } : {}
                },
                body: i,
                signal: d.signal
            });
            if (f && n.activeOperation ? .operationId === o.operationId && n.activeController === d) return o.deliveryOutcome = "failed", e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "timeout",
                    retryable: !0
                }
            })), r(), !1;
            if (!$v(a, o, d)) return R("zendesk_messaging_attachment_upload_ignored", {
                reason: "stale_upload_operation"
            }), !1;
            if (!u.ok) {
                let t = "FILE_UPLOAD_UNKNOWN_ERROR",
                    n = "http_error";
                u.status === 413 ? (t = "FILE_UPLOAD_EXCEED_SIZE_LIMIT", n = "http_413") : u.status === 415 && (t = "FILE_UPLOAD_UNSUPPORTED_TYPE", n = "http_415");
                let r = {
                    errorKey: t,
                    errorData: {
                        reason: n,
                        status: u.status,
                        ...t === "FILE_UPLOAD_UNKNOWN_ERROR" ? {
                            retryable: !0
                        } : {}
                    }
                };
                return e.dispatch(U(r)), R("zendesk_messaging_attachment_upload_failed", {
                    status: u.status
                }), !1;
            }
            let p = null;
            try {
                p = await u.json();
            } catch {
                p = null;
            }
            if (f && n.activeOperation ? .operationId === o.operationId && n.activeController === d) return o.deliveryOutcome = "failed", e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "timeout",
                    retryable: !0
                }
            })), r(), !1;
            if (!$v(a, o, d)) return !1;
            let m = rx(p);
            if (!m) return e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "invalid_response",
                    retryable: !0
                }
            })), R("zendesk_messaging_attachment_upload_failed", {
                status: "invalid_response"
            }), !1;
            o.deliveredMedia = {
                url: m.mediaUrl,
                mimeType: m.mediaType,
                name: m.mediaName
            };
        }
        globalThis.clearTimeout(p);
        let i = await Jv(e, "zendeskMessaging", o.deliveredMedia, o, d.signal);
        if (!$v(a, o, d)) return R("zendesk_messaging_attachment_upload_ignored", {
            reason: "stale_upload_operation"
        }), !1;
        if (i !== "sent") {
            let t = i === "refused",
                n = "message_send_failed",
                r = !1;
            return t ? n = "handoff_ended" : i === "indeterminate" ? (r = o.deliveryOutcome === "accepted", n = r ? "durability_unknown" : "delivery_unknown") : i === "rejected" && (n = "provider_rejected"), e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: n,
                    ...r ? {
                        deliveryConfirmed: !0
                    } : {},
                    ...i === "failed" || i === "retryable_rejection" ? {
                        retryable: !0
                    } : {}
                }
            })), R("zendesk_messaging_attachment_upload_failed", {
                status: n,
                sendResult: i
            }), !1;
        }
        return e.dispatch(Hn({
            type: "Uploaded",
            fileName: t.name,
            fileSize: t.size,
            progress: 100
        })), e.dispatch(De()), e.dispatch(it()), ey(n, o), r(), R("zendesk_messaging_attachment_upload_succeeded"), !0;
    } catch (t) {
        if (!(n.activeOperation ? .operationId === o.operationId && n.activeController === d)) return !1;
        let a = f || t instanceof DOMException && t.name === "AbortError";
        return !f && d.signal.aborted ? (R("zendesk_messaging_attachment_upload_cancelled"), !1) : (e.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: a ? "timeout" : "network_error",
                retryable: !0
            }
        })), r(), R("zendesk_messaging_attachment_upload_failed", {
            status: a ? "timeout" : "network_error"
        }), a || i(t, {
            endpoint: s
        }), !1);
    } finally {
        globalThis.clearTimeout(p), n.activeController === d && (n.activeController = null);
    }
}
//#endregion
//#region src/orchestrator-zendesk-runtime.ts
function ax(e, t) {
    e.dispatch(gr({
        platformName: x
    })), e.dispatch(Mt({
        sdkInitialized: !0,
        disconnected: !1,
        reconnecting: !1
    })), R("zendesk_sdk_initialize_requested", {
        accountKeyLength: t.accountKey.length
    });
}

function ox(e) {
    e.dispatch(Mt({
        sdkInitialized: !1,
        disconnected: !1,
        reconnecting: !1,
        sessionId: null
    })), R("zendesk_sdk_teardown_requested");
}

function sx(e, t) {
    e.dispatch(gr({
        platformName: x,
        departmentId: t
    })), e.dispatch(Mt({
        departmentId: t,
        departmentStatus: "ONLINE"
    })), R("zendesk_department_set", {
        departmentId: t
    });
}

function cx(e, t) {
    R("zendesk_transcript_send_requested", {
        lines: e.length,
        externalChatId: t
    });
}

function lx() {
    R("zendesk_transcript_clear_requested");
}

function ux(e) {
    e.dispatch(gr({
        platformName: us
    })), e.dispatch(ce({
        initializationStatus: 1,
        initialized: !1,
        disconnected: !1,
        reconnecting: !1
    })), R("zendesk_messaging_initialize_requested");
}

function dx(e) {
    e.dispatch(ce({
        initializationStatus: 0,
        initialized: !1,
        disconnected: !1,
        reconnecting: !1,
        conversationId: null
    })), R("zendesk_messaging_destroy_requested");
}

function fx() {
    R("zendesk_messaging_conversation_load_requested");
}
var px = class {
        constructor(e) {
            L(this, "store", void 0), this.store = e;
        }
        initializeZendeskSdk(e) {
            ax(this.store, e);
        }
        teardownZendeskSdk() {
            ox(this.store);
        }
        setZendeskDepartment(e) {
            sx(this.store, e);
        }
        sendZendeskTranscript(e, t) {
            cx(e, t);
        }
        clearZendeskTranscript() {
            lx();
        }
        initializeZendeskMessagingSdk() {
            ux(this.store);
        }
        destroyZendeskMessagingSdk() {
            dx(this.store);
        }
        loadZendeskMessagingConversation() {
            fx();
        }
    },
    mx = 12e4,
    hx = new Set([
        "stale_conversation",
        "not_live",
        "wrong_platform",
        "not_escalated"
    ]),
    gx = new Set(["not_configured", "missing_ticket"]);

function _x(e) {
    return e.endsWith("/") ? e : `${e}/`;
}

function vx(e) {
    return `${_x(e)}zendesk_support/file_upload`;
}

function yx(e) {
    let t = F(F(e) ? .attachment),
        n = O(t ? .mediaName, {
            trimOutput: !1
        }),
        r = O(t ? .mediaUrl),
        i = O(t ? .mediaType);
    return !n || !r || !i ? null : {
        mediaName: n,
        mediaUrl: r,
        mediaType: i
    };
}
async function bx(e) {
    try {
        return F(await e.clone().json());
    } catch {
        return null;
    }
}
async function xx(e, t) {
    let n, r = new Promise((e, r) => {
        n = () => r(new DOMException("The upload was aborted", "AbortError")), t.aborted ? n() : t.addEventListener("abort", n, {
            once: !0
        });
    });
    try {
        return await Promise.race([e, r]);
    } finally {
        t.removeEventListener("abort", n);
    }
}
async function Sx({
    store: e,
    file: t,
    uploadState: n,
    clearFileUploadCommandTracking: r,
    onCaptureException: i
}) {
    if (!e.getState().liveAgent.file.isUploading) return !1;
    let a = {
            store: e,
            uploadState: n
        },
        o = Qv(a, t),
        {
            endpoint: s,
            chatterToken: c,
            sessionToken: l,
            conversationId: u
        } = o;
    if (o.deliveryOutcome === "indeterminate" && !o.deliveredMedia) return e.dispatch(U({
        errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
        errorData: {
            reason: "delivery_unknown"
        }
    })), !1;
    let d = n.activeController;
    if (d && (d.abort(), n.activeController = null), !s || !c || !u) return e.dispatch(U({
        errorKey: "FILE_UPLOAD_ERROR",
        errorData: {
            reason: "invalid_context"
        }
    })), R("zendesk_support_file_upload_failed", {
        status: "invalid_context"
    }), r(), !1;
    R("zendesk_support_file_upload_requested", {
        size: t.size,
        type: t.type
    });
    let f = new AbortController();
    n.activeController = f;
    let p = () => $v(a, o, f) && e.getState().session.sessionToken === l,
        m = !1,
        h = !0,
        g = globalThis.setTimeout(() => {
            m = !0, f.abort();
        }, mx);
    try {
        if (!o.deliveredMedia) {
            o.deliveryOutcome = "sending";
            let i = new FormData();
            i.append("file", t), i.append("conversation_id", u);
            let c = await zn(e, {
                url: vx(s),
                method: "POST",
                credentials: "include",
                body: i,
                signal: f.signal,
                bindLifecycleSignal: !1,
                timeoutMs: mx
            }, {
                isCurrent: p,
                onPhaseChange: (e) => {
                    h = e === "auth";
                }
            });
            if (m && n.activeOperation ? .operationId === o.operationId && n.activeController === f) return o.deliveryOutcome = "indeterminate", e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "delivery_unknown"
                }
            })), R("zendesk_support_file_upload_failed", {
                status: "timeout"
            }), r(), !1;
            if (!$v(a, o, f)) return R("zendesk_support_file_upload_ignored", {
                reason: "stale_upload_operation"
            }), !1;
            if (!c.ok) {
                let t = await xx(bx(c), f.signal),
                    n = t ? .error_code === "messaging_jwt_auth_failed",
                    r = c.status === 409 ? O(t ? .failure_reason) : null;
                if (r && hx.has(r)) return o.deliveryOutcome = "failed", e.dispatch(U({
                    errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                    errorData: {
                        reason: "handoff_ended",
                        status: c.status
                    }
                })), R("zendesk_support_file_upload_failed", {
                    status: r
                }), !1;
                if (r && gx.has(r)) return o.deliveryOutcome = "failed", e.dispatch(U({
                    errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                    errorData: {
                        reason: "provider_rejected",
                        status: c.status
                    }
                })), R("zendesk_support_file_upload_failed", {
                    status: r
                }), !1;
                let i = "FILE_UPLOAD_UNKNOWN_ERROR",
                    a = "http_error";
                c.status === 413 ? (i = "FILE_UPLOAD_EXCEED_SIZE_LIMIT", a = "http_413") : c.status === 415 && (i = "FILE_UPLOAD_UNSUPPORTED_TYPE", a = "http_415");
                let s = !n && (c.status === 408 || c.status >= 500);
                return o.deliveryOutcome = s ? "indeterminate" : "failed", s && (a = "delivery_unknown"), e.dispatch(U({
                    errorKey: i,
                    errorData: {
                        reason: a,
                        status: c.status,
                        ...!s && i === "FILE_UPLOAD_UNKNOWN_ERROR" ? {
                            retryable: !0
                        } : {}
                    }
                })), R("zendesk_support_file_upload_failed", {
                    status: r ? ? c.status
                }), !1;
            }
            let l = null;
            try {
                l = await xx(c.json(), f.signal);
            } catch {
                l = null;
            }
            if (m && n.activeOperation ? .operationId === o.operationId && n.activeController === f) return o.deliveryOutcome = "indeterminate", e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "delivery_unknown"
                }
            })), R("zendesk_support_file_upload_failed", {
                status: "timeout"
            }), r(), !1;
            if (!$v(a, o, f)) return R("zendesk_support_file_upload_ignored", {
                reason: "stale_upload_operation"
            }), !1;
            let d = yx(l);
            if (!d) return o.deliveryOutcome = "indeterminate", e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: "delivery_unknown"
                }
            })), R("zendesk_support_file_upload_failed", {
                status: "invalid_response"
            }), !1;
            o.deliveredMedia = {
                url: d.mediaUrl,
                name: d.mediaName,
                mimeType: d.mediaType
            }, o.deliveryOutcome = "accepted";
        }
        globalThis.clearTimeout(g);
        let i = await Jv(e, "zendeskSupport", o.deliveredMedia, o, f.signal);
        if (!$v(a, o, f)) return R("zendesk_support_file_upload_ignored", {
            reason: "stale_upload_operation"
        }), !1;
        if (i !== "sent") {
            let t = "message_send_failed";
            return i === "refused" ? t = "handoff_ended" : i === "indeterminate" && (t = "durability_unknown"), e.dispatch(U({
                errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
                errorData: {
                    reason: t,
                    deliveryConfirmed: !0,
                    ...i === "failed" ? {
                        retryable: !0
                    } : {}
                }
            })), R("zendesk_support_file_upload_failed", {
                status: t,
                sendResult: i
            }), !1;
        }
        return e.dispatch(Hn({
            type: "Uploaded",
            fileName: t.name,
            fileSize: t.size,
            progress: 100
        })), e.dispatch(De()), e.dispatch(it()), ey(n, o), r(), R("zendesk_support_file_upload_succeeded"), !0;
    } catch (t) {
        if (!(n.activeOperation ? .operationId === o.operationId && n.activeController === f) || !m && !f.signal.aborted && !p()) return !1;
        let a = h && !o.deliveredMedia;
        o.deliveredMedia || (o.deliveryOutcome = a ? "failed" : "indeterminate");
        let c = m || t instanceof DOMException && t.name === "AbortError";
        if (!m && f.signal.aborted) return R("zendesk_support_file_upload_cancelled"), !1;
        let l = "delivery_unknown";
        o.deliveredMedia ? l = "durability_unknown" : a && (l = c ? "timeout" : "network_error"), e.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: {
                reason: l,
                ...a ? {
                    retryable: !0
                } : {},
                ...o.deliveredMedia ? {
                    deliveryConfirmed: !0
                } : {}
            }
        })), r();
        let u = "network_error";
        return c ? u = "timeout" : o.deliveredMedia && (u = "durability_unknown"), R("zendesk_support_file_upload_failed", {
            status: u
        }), c || i(t, {
            endpoint: s
        }), !1;
    } finally {
        globalThis.clearTimeout(g), n.activeController === f && (n.activeController = null);
    }
}
//#endregion
//#region src/playbook-trigger-error.ts
var Cx = class extends Error {
        constructor(e, t = `triggerPlaybook rejected: ${e}`) {
            super(t), L(this, "failureReason", void 0), this.name = "PlaybookTriggerRefusalError", this.failureReason = e;
        }
    },
    wx = B("orchestrator"),
    Tx = 1e3,
    Ex = 3e4,
    Dx = 6e4,
    Ox = 6,
    kx = 5 * 6e4,
    Ax = 1e3,
    jx = 4e4;

function Mx(e, t) {
    let n = new AbortController(),
        r = () => n.abort();
    return e.aborted || t.aborted ? (n.abort(), {
        signal: n.signal,
        cleanup: () => {}
    }) : (e.addEventListener("abort", r, {
        once: !0
    }), t.addEventListener("abort", r, {
        once: !0
    }), {
        signal: n.signal,
        cleanup: () => {
            e.removeEventListener("abort", r), t.removeEventListener("abort", r);
        }
    });
}

function Nx(e, t, n) {
    return t === null ? e === n ? "cleared_conversation_frame" : "behind_cleared_conversation_frame" : Tn(e, t) ? "older_conversation_frame" : "unordered_conversation_id";
}
var Px = class {
    beginStartupTracking(e = this._lifecycleSignal) {
        let t = Ce({
                subscribeLifecycle: wn(document, window),
                onSuspension: ({
                    gap: t,
                    lastStep: n,
                    source: r
                }) => {
                    let i = Date.now();
                    this.lastReportedSuspensionAt !== null && Math.abs(i - this.lastReportedSuspensionAt) <= 5e3 || (this.lastReportedSuspensionAt === null && e.addEventListener("abort", () => {
                        this.lastReportedSuspensionAt = null;
                    }, {
                        once: !0
                    }), this.lastReportedSuspensionAt = i, R("chat_freeze_detected", {
                        gap_ms: t,
                        last_step: this.startupSteps.get(e) ? ? n,
                        source: r
                    }));
                }
            }),
            n = t.setLastStep;
        t.setLastStep = (r) => {
            n(r), t.signal.aborted || this.startupSteps.set(e, r);
        };
        let r = t.dispose,
            i = () => {
                r(), e.removeEventListener("abort", i), this.startupClocks.delete(t);
            };
        return t.dispose = i, this.startupClocks.add(t), t.start(), e.addEventListener("abort", i, {
            once: !0
        }), e.aborted && i(), t;
    }
    _registerGuardedActiveStorage(e, t = !1) {
        se(new Cn(this.store, e, this.store.getState().session.handle ? ? "", {
            createChatter: async () => void 0,
            handoffOnlyPersistence: t
        }).guardStorageWriters(t ? this._handoffOnlyActiveStorage(e) : e));
    }
    _handoffOnlyActiveStorage(e) {
        return jt(e, {
            handoffWritesAllowed: () => this.store.getState().liveAgent.handoffOpenedThisPage,
            handoffKeys: () => {
                let {
                    handle: e
                } = this.store.getState().session;
                return e ? [$t(e), st(e)] : [];
            }
        });
    }
    constructor(e, t, n, r = {}) {
        L(this, "_instance", void 0), L(this, "startupClocks", /* @__PURE__ */ new Set()), L(this, "startupSteps", /* @__PURE__ */ new WeakMap()), L(this, "lastReportedSuspensionAt", null), L(this, "cancelOutageTracking", void 0), L(this, "_greetingLeaseOwner", I()), L(this, "_getActivePersistenceStorage", void 0), L(this, "_resetGreetingSignal", null), L(this, "_greetingAttempt", null), L(this, "startupState", {
            client: null,
            publicClientPromise: null,
            transportConfigPromise: null,
            persistence: null,
            persistencePromise: null,
            persistenceClearPromise: null,
            preparePromise: null,
            activatePromise: null,
            backgroundResumePreparedChatterToken: null,
            isPrepared: !1,
            isActivated: !1
        }), L(this, "subscriptionState", {
            encryptedChannel: null,
            mainChannel: null,
            controlChannel: null,
            retryCount: 0,
            retryTimer: null,
            streamFallbackTimers: /* @__PURE__ */ new Map(),
            transportConfigRetryDelayMs: 0,
            tokenExpiredRecoveryInFlight: !1,
            tokenExpiredStreak: 0,
            lastTokenExpiredAt: 0,
            tokenExpiredBackoffTimer: null,
            tokenExpiredGaveUp: !1,
            tokenExpiredGiveUpProbeTimer: null,
            subscriptionConfirmedAt: 0,
            tokenExpiredRecoveryGeneration: 0,
            messagingTokenUnsubscribe: null
        }), L(this, "uploadState", {
            activeController: null,
            activeCommandId: null,
            resultTimeoutId: null,
            activeOperation: null
        }), L(this, "_persistenceStorageDestroy", null), L(this, "_deadSessionRecoveryPromise", null), L(this, "_pusherSessionRecoveryTokens", /* @__PURE__ */ new Set()), L(this, "_pusherSessionRecoveryAttempts", 0), L(this, "_engagementStarted", !1), L(this, "_deferredGreeting", null), L(this, "_engagedAppActionReady", !1), L(this, "_engagedAppActionPromise", null), L(this, "_historyPreservingResetInProgress", !1), L(this, "_historyPreservingResetAppReady", null), L(this, "_startupFallbackReported", !1), L(this, "_backgroundResume", null), L(this, "_passiveSession", null), L(this, "_restoreOwner", null), L(this, "_proactiveInjections", /* @__PURE__ */ new WeakMap()), L(this, "_proactiveConversationStartWaiter", null), L(this, "messageState", {
            lastMessageSentAt: 0,
            groupSendOwner: void 0
        }), L(this, "stateGenerations", /* @__PURE__ */ new Map()), L(this, "chatterTyping", void 0), L(this, "chatterVisibility", void 0), L(this, "transportRevalidationState", {
            timer: null,
            lastCheckedAt: 0,
            inFlight: !1,
            activeRun: null,
            withdrawalStreak: 0,
            swapCount: 0,
            lastSwapAt: 0,
            giveUpReported: !1
        }), L(this, "_captureException", (e, t, n) => {
            P(e, t, n);
        }), L(this, "voice", void 0), L(this, "zendesk", void 0), L(this, "session", void 0), L(this, "liveAgent", void 0), L(this, "zendeskChatAuth", void 0), this._instance = e, this._getActivePersistenceStorage = r.getActivePersistenceStorage ? ? Io, this.store.getState().session.clearPersistenceOnPrepare && (this._resetGreetingSignal = this._lifecycleSignal), this.cancelOutageTracking = t, n && (this.zendeskChatAuth = Qb({
            store: this.store,
            ...n,
            getLifecycleSignal: () => this._lifecycleSignal
        }), e.lifecycle.teardownSignal.addEventListener("abort", this.zendeskChatAuth.destroy, {
            once: !0
        }));
        let i = () => {
            this._retireActiveFileUpload(), this.store.getState().liveAgent.platformName === "zendesk_liveagent" && jr(this.store);
        };
        this.chatterTyping = new Fv(this.store, fetch, i), this.chatterVisibility = new Lv(this.store, fetch, i), this.voice = new Ib(this.store), this.zendesk = new px(this.store), this.session = new ih({
            store: this.store,
            onCaptureException: this._captureException,
            onLoadTranslations: async (e, t) => {
                await this._loadTranslations(e, t);
            },
            getLifecycleSignal: () => this._lifecycleSignal
        }), this.liveAgent = new Jy(this.store, async (e) => {
            await this.sendMessage(e);
        }, () => {
            this.chatterTyping.settle(), this._retireActiveFileUpload();
        });
    }
    get store() {
        return this._instance.store;
    }
    get transport() {
        return this._instance.transport;
    }
    get _lifecycleSignal() {
        return this._instance.lifecycle.signal;
    }
    getStorageMode() {
        return this.startupState.persistence ? this.startupState.persistence.storageMode : z_(this._getStartupRuntimeContext());
    }
    async fetchStartupConfig() {
        await F_(this._getStartupRuntimeContext());
    }
    async hasPersistedChatter() {
        return $_(this._getStartupRuntimeContext());
    }
    async clearPersistenceDurably(e) {
        let t = this._getStartupRuntimeContext(),
            n = !1;
        try {
            if (!await F_(t)) return !1;
        } catch {
            if (t.signal.aborted) return !1;
            n = !0;
        }
        try {
            return await K_(t, e, {
                clearAllPersistentModes: n
            });
        } catch {
            return !1;
        } finally {
            n && !t.signal.aborted && W_(t);
        }
    }
    async getExistingChatterNotificationCandidate() {
        if (this._engagementStarted) return null;
        let e = await Q_(this._getStartupRuntimeContext());
        return this._engagementStarted ? null : e;
    }
    async resumeExistingChatter(e, t, n) {
        if (!t || !e || this._engagementStarted) return !1;
        if (this._backgroundResume) return this._backgroundResume.chatterToken === e ? this._backgroundResume.promise : !1;
        let r = this._lifecycleSignal,
            i = (async () => (this._passiveSession && await this._passiveSession.catch(() => void 0), this._withRestoreOwnership(r, async () => {
                if (this._engagementStarted) return this._parkBackgroundSession("resume_engagement_raced"), !1;
                try {
                    if (this.startupState.isPrepared && (this.store.getState().session.chatterToken !== e || r.aborted)) return !1;
                    if (!(this.startupState.isPrepared || await tv(this._getStartupRuntimeContext(r, n), e)) || r.aborted || this._engagementStarted) return !r.aborted && (this._engagementStarted || this.store.getState().session.chatterToken === e && this.store.getState().session._chatterAnnouncementSuppressed) && this._parkBackgroundSession(this._engagementStarted ? "resume_engagement_raced" : "resume_prepare_rejected"), !1;
                    let t = await this._activateRuntime(!0, r, {
                            startupClock: n
                        }),
                        i = t.kind === "activated" ? await this.startupState.persistence ? .getExistingChatterCandidate(r) : null,
                        a = this.store.getState(),
                        o = a.liveAgent.inLiveChat || a.liveAgent.inPending;
                    return t.kind === "activated" && i ? .kind === "candidate" && i.chatterToken === e && i.handoffActive !== !1 && !r.aborted && !this._engagementStarted && a.session.chatterToken === e && o ? this.finalizeExistingChatterResume(e) : (r.aborted || this._parkBackgroundSession(this._engagementStarted ? "resume_engagement_raced" : `resume_${t.kind}`), !1);
                } catch (e) {
                    return r.aborted || (wx.warn("Background chatter resume failed:", e), this._parkBackgroundSession(this._engagementStarted ? "resume_engagement_raced" : "resume_failed")), !1;
                }
            })))().then((e) => e === !0);
        this._backgroundResume = {
            chatterToken: e,
            promise: i
        };
        try {
            return await i;
        } finally {
            this._backgroundResume ? .promise === i && (this._backgroundResume = null);
        }
    }
    async prepareHistoryPreservingReset(e, t = {}) {
        if (!e) return !1;
        let n = this._lifecycleSignal,
            r = this.store.getState().session;
        if (r.chatterToken === e && !r._chatterAnnouncementSuppressed && (this.startupState.isPrepared || this.startupState.backgroundResumePreparedChatterToken === e) && this.startupState.client && this.startupState.persistence) return !0;
        if (r.chatterToken && r.chatterToken !== e) return !1;
        try {
            return !await tv(this._getStartupRuntimeContext(n, t.startupClock), e, t) || n.aborted || this.store.getState().session.chatterToken !== e ? (n.aborted || this.parkProvisionalChatterForReset(e), !1) : !0;
        } catch (t) {
            return n.aborted || (wx.warn("History-preserving chatter restore failed:", t), this.parkProvisionalChatterForReset(e)), !1;
        }
    }
    async activateHistoryPreservingReset(e, t = {}) {
        let n = this._lifecycleSignal;
        this._historyPreservingResetAppReady = null;
        let r = this.store.getState().session,
            a = r.chatterToken === e && r._chatterAnnouncementSuppressed;
        if (!(r.chatterToken === e && (!t.identitySession || r.identitySession) && this.startupState.client && this.startupState.persistence && (a || this.startupState.isPrepared || this.startupState.backgroundResumePreparedChatterToken === e)) || n.aborted) return {
            kind: "aborted"
        };
        let o = await this._activateRuntime(!0, n, {
            startupClock: t.startupClock
        });
        if (o.kind !== "activated" && !(o.kind === "deferred" && o.appReady) || n.aborted) return a && !n.aborted && this._parkBackgroundSession(`history_preserving_reset_${o.kind}`), o;
        if (a) {
            let r = await this.startupState.persistence ? .getExistingChatterCandidate(n),
                a = this.store.getState().session;
            if (r ? .kind !== "candidate" || r.chatterToken !== e || t.identitySession && !r.identitySession || a.chatterToken !== e || n.aborted) return n.aborted || this._parkBackgroundSession("history_preserving_reset_final_proof_failed"), {
                kind: "aborted"
            };
            this.store.dispatch(si({
                chatterToken: e
            })), this.store.dispatch(i(!1)), this.startupState.backgroundResumePreparedChatterToken = e, this.startupState.isPrepared = !1, this._watchMessagingTokenForTransportRefresh(), this.startupState.persistence ? .startTokenSync(), Ob(this._getTransportRevalidationContext());
        }
        let s = this.store.getState().session;
        return s.chatterToken !== e || t.identitySession && !s.identitySession ? {
            kind: "aborted"
        } : (o.kind === "deferred" && o.appReady && (this._historyPreservingResetAppReady = {
            chatterToken: e,
            signal: n
        }), o);
    }
    _isHistoryPreservingResetAppReady(e) {
        return this.startupState.isActivated || this._historyPreservingResetAppReady ? .chatterToken === e && this._historyPreservingResetAppReady.signal === this._lifecycleSignal && !this._historyPreservingResetAppReady.signal.aborted;
    }
    async completeHistoryPreservingResetPreparation(e, t = {}) {
        let n = this.store.getState().session;
        if (n.chatterToken !== e || n._chatterAnnouncementSuppressed || !this._isHistoryPreservingResetAppReady(e)) throw Error("History-preserving reset lost its exact chatter before startup completion");
        if (!t.engagementAuthorized || this.startupState.isPrepared) return !1;
        if (this.startupState.backgroundResumePreparedChatterToken !== e) throw Error("History-preserving reset has no exact startup preparation to complete");
        if (!await nv(this._getStartupRuntimeContext(), e, {
                throwOnError: !0
            })) throw Error("History-preserving reset startup preparation was superseded");
        return !0;
    }
    beginHistoryPreservingReset() {
        this._historyPreservingResetAppReady = null, this._historyPreservingResetInProgress = !0, this.store.dispatch(i(!1)), this._engagedAppActionReady = !1;
    }
    completeHistoryPreservingReset(e, t = {}) {
        let n = this.store.getState().session;
        return n.chatterToken !== e || n._chatterAnnouncementSuppressed || !this._isHistoryPreservingResetAppReady(e) ? !1 : (this.store.dispatch(i(!0)), this._historyPreservingResetInProgress = !1, t.engagementAuthorized ? (this.grantEngagement(), this._engagedAppActionReady = !0) : this.canRevealRestoredChat(e) && he("engaged"), this.startupState.persistence ? .startTokenSync(), this.startupState.isActivated || this.retryTransportAfterDeferred({
            deferGreeting: !0
        }), !0);
    }
    releaseHistoryPreservingResetAfterFailure(e) {
        let t = this.store.getState().session;
        return this._historyPreservingResetInProgress = !1, this._historyPreservingResetAppReady = null, t.chatterToken !== e || t._chatterAnnouncementSuppressed ? !1 : (this.store.dispatch(i(!0)), this._engagedAppActionReady = !1, !0);
    }
    isHistoryPreservingResetInProgress() {
        return this._historyPreservingResetInProgress;
    }
    finalizeExistingChatterResume(e) {
        return this.canRevealRestoredChat(e) ? (this.store.getState().session._chatterAnnouncementSuppressed && this.store.dispatch(si({
            chatterToken: e
        })), he("engaged"), this.startupState.isPrepared || (this.startupState.backgroundResumePreparedChatterToken = e), this._engagedAppActionReady = !1, this._watchMessagingTokenForTransportRefresh(), this.startupState.persistence ? .startTokenSync(), Ob(this._getTransportRevalidationContext()), !0) : (this.parkExistingChatterResume(e), !1);
    }
    canRevealRestoredChat(e) {
        let t = this.store.getState();
        return !!e && t.session.chatterToken === e && this.startupState.isActivated && (t.liveAgent.inLiveChat || t.liveAgent.inPending);
    }
    parkExistingChatterResume(e) {
        let t = this.store.getState().session;
        !this._engagementStarted && t.chatterToken === e && t._chatterAnnouncementSuppressed && this._parkBackgroundSession("app_mount_failed");
    }
    parkProvisionalChatterForReset(e) {
        let t = this.store.getState().session;
        t.chatterToken === e && t._chatterAnnouncementSuppressed && this._parkBackgroundSession("soft_reset_superseded_resume");
    }
    waitForParentElementVisible(e, t = {}) {
        let n = this._lifecycleSignal,
            r = this._getStartupRuntimeContext(n, e);
        return ev({
            ...r,
            prepareRestoreOnly: async (e) => {
                await this._withRestoreOwnership(n, () => rv(r, {
                    ...e,
                    restoreOnly: !0
                }));
            }
        }, t);
    }
    async _withRestoreOwnership(e, t) {
        if (!e.aborted && this._restoreOwner ? .signal === e) return await this._restoreOwner.promise, this._withRestoreOwnership(e, t);
        if (e.aborted) return;
        let n = Promise.resolve().then(t),
            r = {
                signal: e,
                promise: n.then(() => void 0, () => void 0)
            };
        this._restoreOwner = r;
        try {
            return await n;
        } finally {
            this._restoreOwner === r && (this._restoreOwner = null);
        }
    }
    async prepare(e = {}) {
        let t = this._lifecycleSignal;
        e.restoreOnly || this.grantEngagement(), await this._withRestoreOwnership(t, () => rv(this._getStartupRuntimeContext(t), e));
    }
    get waitsForEngagement() {
        return this._instance.headless === !0 || this._instance.hostTelemetry ? .mobileShell === "messaging-sdk" && this._instance.hostTelemetry.nativeViewVisibilitySupported === !0;
    }
    preparePassiveSession() {
        if (this._passiveSession) return this._passiveSession;
        let e = this._lifecycleSignal,
            t = Promise.resolve().then(async () => {
                if (this._passiveSession !== t || e.aborted || (await this.prepare({
                        restoreOnly: !0
                    }), this._passiveSession !== t || e.aborted || !this.startupState.isPrepared)) return;
                let n = await this.activate({
                    deferAppInteractionReady: !0
                });
                this._passiveSession !== t || e.aborted || this._engagementStarted || (n.kind === "deferred" ? this.retryTransportAfterDeferred({
                    deferGreeting: !0
                }) : n.kind !== "activated" && this._parkBackgroundSession(`passive_${n.kind}`));
            }).catch((e) => {
                throw this._passiveSession === t && (this._passiveSession = null), e;
            });
        return this._passiveSession = t, e.addEventListener("abort", () => {
            this._passiveSession === t && (this._passiveSession = null);
        }, {
            once: !0
        }), t;
    }
    resetEngagement() {
        this._engagementStarted = !1, this._engagedAppActionReady = !1, this._engagedAppActionPromise = null, this._backgroundResume = null, this._passiveSession = null, this._historyPreservingResetInProgress = !1, this._historyPreservingResetAppReady = null;
    }
    grantEngagement() {
        this._engagementStarted = !0, he("engaged");
    }
    needsEngagedPreparationForAppAction() {
        let e = this.store.getState().session;
        return !this._engagedAppActionReady && e._appInteractionReady && !!e.chatterToken;
    }
    async ensureEngagedForAppAction() {
        if (this._engagedAppActionReady) return !0;
        if (this._engagedAppActionPromise) return this._engagedAppActionPromise;
        let e = this._lifecycleSignal,
            t = (async () => {
                this.grantEngagement();
                try {
                    await this.prepare();
                    let t = await this.activate(),
                        n = !e.aborted && (t.kind === "activated" || t.kind === "deferred" && t.appReady === !0 && this._engagedAppActionReady);
                    return this._engagedAppActionReady = n, n;
                } catch (e) {
                    return wx.error("App engagement startup failed:", e), !1;
                }
            })();
        this._engagedAppActionPromise = t;
        try {
            return await t;
        } finally {
            this._engagedAppActionPromise === t && (this._engagedAppActionPromise = null);
        }
    }
    async showStartupOutage(e) {
        let t = this._lifecycleSignal;
        if (t.aborted) return !1;
        let n = e instanceof Error ? e.message : String(e);
        this.store.dispatch(M(n));
        let r = Jg(e),
            i = r ? "CHAT_OUTAGE_FULL_PAGE_NO_BACKOFF" : "CHAT_OUTAGE_FULL_PAGE";
        this.store.dispatch(h(i));
        let a = e instanceof rc && (e.code === "origin_not_allowlisted" || e.code === "frame_load_failed" || e.code === "handshake_timeout");
        return !r && !a && !this._startupFallbackReported && (this._startupFallbackReported = !0, eb(i, "startup_failure", e instanceof av ? e.refusal : void 0)), await this._loadTranslations(void 0, t), !t.aborted;
    }
    getStartupConfig() {
        let e = this.startupState.client;
        if (!e) return null;
        let t = this.store.getState().session;
        return {
            chatEnabled: e.chat_enabled,
            tintColor: e.tint_color ? ? "",
            button: ba(e.button ? {
                iconType: e.button.icon_type,
                iconPath: e.button.icon_path,
                textEnabled: e.button.text_enabled,
                ...Dv({
                    textEnabled: e.button.text_enabled,
                    textByLanguage: e.button.text_by_language,
                    sessionLanguage: t.language,
                    botDefaultLanguage: e.language
                }),
                size: e.button.size ? ? 64,
                backgroundColor: e.button.background_color ? ? null
            } : null, t),
            intro: e.intro ? {
                responseId: e.intro.response_id,
                body: e.intro.body,
                delay: e.intro.delay,
                duration: e.intro.duration,
                style: e.intro.style,
                paths: e.intro.paths,
                ...e.intro.image ? {
                    image: e.intro.image
                } : {},
                ...e.intro.cta ? {
                    cta: e.intro.cta
                } : {}
            } : null,
            fallbackUi: e.fallback_ui,
            advancedColorsEnabled: e.advanced_colors_enabled,
            textOverAccentColor: e.text_over_accent_color,
            proactiveConversations: e.proactive_conversations,
            features: e.features,
            allowedProtocols: e.allowed_protocols
        };
    }
    async activate(e = {}) {
        return this._activateRuntime(!1, this._lifecycleSignal, e);
    }
    async _activateRuntime(e, t = this._lifecycleSignal, n = {}) {
        if (this.startupState.activatePromise) {
            let r = this.startupState.activatePromiseSkipPrepare,
                a = await this.startupState.activatePromise;
            return r === !1 && !e && !n.deferAppInteractionReady && !t.aborted && (a.kind === "activated" || a.kind === "deferred" && a.appReady) && (this.startupState.persistence ? .startTokenSync(), this.store.dispatch(i(!0)), this._engagedAppActionReady = !0), a;
        }
        if (this.startupState.isActivated) return !e && !n.deferAppInteractionReady && !t.aborted && !this._backgroundResume && !this.store.getState().session._chatterAnnouncementSuppressed && (this.startupState.persistence ? .startTokenSync(), this._watchMessagingTokenForTransportRefresh(), this.store.dispatch(i(!0)), this._engagedAppActionReady = !0), {
            kind: "activated"
        };
        let r = sv(this._getStartupRuntimeContext(t, n.startupClock), {
            skipPrepare: e
        }).then((r) => {
            if (r.kind === "deferred" && r.appReady && !t.aborted && !e) {
                let e = this.store.getState().session.chatterToken;
                e && t === this._lifecycleSignal && (!n.deferAppInteractionReady || this._historyPreservingResetInProgress) && (this._historyPreservingResetAppReady = {
                    chatterToken: e,
                    signal: t
                }), n.deferAppInteractionReady || (this.startupState.persistence ? .startTokenSync(), this.store.dispatch(i(!0)), this._engagedAppActionReady = !0);
            }
            return r.kind === "activated" ? (this.subscriptionState.transportConfigRetryDelayMs = 0, this._startupFallbackReported = !1, e || (this._watchMessagingTokenForTransportRefresh(), this.startupState.persistence ? .startTokenSync(), n.deferAppInteractionReady || (this.store.dispatch(i(!0)), this._engagedAppActionReady = !0)), r) : r;
        }).finally(() => {
            this.startupState.activatePromise === r && (this.startupState.activatePromise = null, this.startupState.activatePromiseSkipPrepare = void 0);
        });
        return this.startupState.activatePromise = r, this.startupState.activatePromiseSkipPrepare = e, r;
    }
    async start() {
        await this.prepare(), await this.activate();
    }
    prepareReactivation() {
        this._teardownSubscriptions(), this._clearTokenExpiredRecovery(), this.startupState.activatePromise = null, this.startupState.isActivated = !1;
    }
    retryTransportAfterDeferred(e) {
        e ? .automaticGreeting === !1 && (this._resetGreetingSignal = this._lifecycleSignal), (e || this._deferredGreeting ? .signal !== this._lifecycleSignal) && (this._deferredGreeting = {
            signal: this._lifecycleSignal,
            allowed: !e ? .deferGreeting
        }), this._retryDeferredTransport();
    }
    _retryDeferredTransport(e = this.startupState.client !== null && j_(this.startupState.client)) {
        if (!e) {
            this.subscriptionState.transportConfigRetryDelayMs = 0, this._handleTokenExpired();
            return;
        }
        if (this.subscriptionState.tokenExpiredRecoveryInFlight) return;
        this._clearTokenExpiredGiveUpProbe(), this.subscriptionState.subscriptionConfirmedAt = 0;
        let t = this.subscriptionState.transportConfigRetryDelayMs;
        this.subscriptionState.transportConfigRetryDelayMs = Math.min(t === 0 ? Ax : t * 2, jx), this._scheduleTransportRecovery(t, !0);
    }
    resetMessageRateLimit() {
        this.messageState.lastMessageSentAt = 0, this.messageState.groupSendOwner = void 0;
    }
    _acceptStateGeneration(e, t, n) {
        let r = F(n),
            i = r ? .conversation_id,
            a = typeof i == "string" && i.length > 0 ? i : null,
            {
                conversationId: o,
                clearedConversationId: s
            } = this.store.getState().session,
            c = this._judgeStateGeneration(e, t, r ? .state_generation, a, o, s);
        return c && a !== null && a === o && gi(this.store, a), c;
    }
    _judgeStateGeneration(e, t, n, r, i, a) {
        let o = r !== null && i !== null && Me(r, i);
        if (r !== null && !o && (i !== null && i !== r || i === null && Nn(r, a))) return R("conversation_state_stale_frame_ignored", {
            event: t,
            conversationId: r,
            reason: Nx(r, i, a),
            generation: typeof n == "number" && Number.isFinite(n) ? n : null
        }), !1;
        if (r !== null && (o || i === null) && (o && (R("conversation_adopted", {
                reason: "newer_state_frame",
                event: t
            }), this.clearSupersededConversationRuntime()), this.store.dispatch(lo(r))), r === null || typeof n != "number" || !Number.isSafeInteger(n) || n <= 0) return !0;
        let s = `${e}:${r}`,
            c = this.stateGenerations.get(s);
        return c !== void 0 && n <= c ? (R("conversation_state_stale_frame_ignored", {
            event: t,
            conversationId: r,
            reason: "generation_regression",
            generation: n,
            latestGeneration: c
        }), !1) : (this.stateGenerations.set(s, n), !0);
    }
    clearConversationForFreshSession() {
        this.store.dispatch(ja()), this.store.dispatch(vn()), this.store.dispatch(An()), this.store.dispatch(Da(!1)), this.store.dispatch(Lo()), this.store.getState().liveAgent.zendesk.webhookRetryMessageKey && this.store.dispatch(Mt({
            webhookRetryMessageKey: null
        })), this.store.dispatch(Vr(!1));
    }
    clearConversationRuntime() {
        this._startupFallbackReported = !1, this.chatterTyping.settle(), this._retireActiveFileUpload(), this.resetMessageRateLimit(), Nh({
            subscriptionState: this.subscriptionState
        });
        let e = this.store.getState().chat.messages.flatMap((e) => e.isStreaming === !0 && e.streamId ? [e.streamId] : []);
        for (let t of e) this.store.dispatch(yr({
            streamId: t
        }));
    }
    clearSupersededConversationRuntime(e = !1) {
        this.chatterTyping.clear(), this._retireActiveFileUpload(), this.store.dispatch(Wr()), this.store.dispatch(e ? bn() : nt()), this.store.dispatch(Da(!1)), this.store.dispatch(Lo()), this.store.getState().liveAgent.zendesk.webhookRetryMessageKey && this.store.dispatch(Mt({
            webhookRetryMessageKey: null
        })), this.store.dispatch(Vr(!1)), this.store.dispatch(vt()), this.store.dispatch(_e()), this.store.dispatch(Wi());
    }
    resetRuntimeState({
        preservePreparedSession: e = !1,
        resetChatHistory: t = !1,
        continueActivationFrom: n
    } = {}) {
        (t || n && this._resetGreetingSignal === n) && (this._resetGreetingSignal = this._lifecycleSignal), t && (this._pusherSessionRecoveryTokens = /* @__PURE__ */ new Set(), this._pusherSessionRecoveryAttempts = 0), this._deferredGreeting = null, this._passiveSession = null, this._historyPreservingResetAppReady = null, this.clearConversationRuntime(), Eb(this.transportRevalidationState), Uo(this.store), this._teardownSubscriptions(), this._clearTokenExpiredRecovery();
        let r = this.store.getState().session.chatterToken,
            i = this.startupState.isPrepared || !!r && this.startupState.backgroundResumePreparedChatterToken === r;
        if (e && i && this.startupState.client && this.startupState.persistence) {
            L_(this._getStartupRuntimeContext()), this.startupState.activatePromise = null, this.startupState.isActivated = !1, this._engagedAppActionReady = !1;
            return;
        }
        this._resetStartupState();
    }
    resetFeatureFlags() {
        zm();
    }
    async sendMessage(e, t) {
        await Oc(this._getMessageRuntimeContext(), e, t);
    }
    async stageAttachment(e, t = !1, n) {
        await Ds(this.store, e, t, n);
    }
    removeAttachment(e) {
        this.store.dispatch(_r({
            id: e
        }));
    }
    async triggerPlaybook(e, t, n) {
        let {
            endpoint: r,
            chatterToken: i,
            sessionId: a
        } = this.store.getState().session;
        if (!r || !i || !a) throw new Cx("session_inactive", "triggerPlaybook requires an active session");
        if ((await this.store.dispatch(G.endpoints.sendMessage.initiate({
                endpoint: r,
                chatterToken: i,
                sessionId: a,
                messageType: "trigger_playbook",
                playbookId: e,
                metaFields: t,
                sensitiveMetaFields: n
            })).unwrap().catch((e) => {
                let t = e;
                if (typeof t ? .status == "number" && t.status >= 400 && t.status < 500) {
                    let e = "refused";
                    throw typeof t.data ? .failure_reason == "string" ? e = t.data.failure_reason : t.status === 429 ? e = "rate_limited" : (t.status === 401 || t.status === 403) && (e = "unauthorized"), new Cx(e);
                }
                let n = typeof t ? .data ? .failure_reason == "string" ? t.data.failure_reason : "trigger_unavailable";
                throw Error(`triggerPlaybook rejected: ${n}`);
            })).accepted !== !0) throw new Cx("not_accepted", "triggerPlaybook was not accepted");
    }
    async sendProgrammaticMessage(e) {
        let t = await Oc(this._getMessageRuntimeContext(), e, {
            origin: "programmatic"
        });
        if ("error" in t) throw Error(`sendMessage rejected by chat: ${t.error}`);
        return t;
    }
    async retryMessage(e, t) {
        await kc({
            ...this._getMessageRuntimeContext(),
            sendIntegrationCommand: t
        }, e);
    }
    async sendQuickReply(e, t, n, r, i, a) {
        return Ac(this._getMessageRuntimeContext(), {
            label: e,
            target: t,
            buttonType: n,
            messageId: r,
            value: i,
            origin: a
        });
    }
    async submitCapture(e, t, n) {
        await jc(this._getMessageRuntimeContext(), e, t, n);
    }
    async cancelCapture(e, t, n) {
        await Mc(this._getMessageRuntimeContext(), e, t, n);
    }
    async cancelListSelection(e, t, n) {
        await Nc(this._getMessageRuntimeContext(), e, t, n);
    }
    async submitSelectableList(e, t) {
        await Pc(this._getMessageRuntimeContext(), e, t);
    }
    async submitSelectedOption(e, t) {
        await Fc(this._getMessageRuntimeContext(), e, t);
    }
    startFileUpload(e, t, n) {
        return iy(this._getLiveAgentFileUploadRuntimeContext(), e, t, n);
    }
    retryFileUpload(e, t) {
        return ay(this._getLiveAgentFileUploadRuntimeContext(), e, t);
    }
    createFileUploadCommandId() {
        return oy(this._getLiveAgentFileUploadCommandTrackingContext());
    }
    async uploadZendeskMessagingAttachment(e) {
        return ix({
            store: this.store,
            file: e,
            uploadState: this.uploadState,
            clearFileUploadCommandTracking: () => {
                this._clearUploadTracking();
            },
            onCaptureException: this._captureException
        });
    }
    async uploadZendeskSupportFile(e) {
        return Sx({
            store: this.store,
            file: e,
            uploadState: this.uploadState,
            clearFileUploadCommandTracking: () => {
                this._clearUploadTracking();
            },
            onCaptureException: this._captureException
        });
    }
    async uploadSalesforceFile(e) {
        return ub({
            store: this.store,
            file: e,
            uploadState: this.uploadState,
            clearFileUploadCommandTracking: () => {
                this._clearUploadTracking();
            },
            onCaptureException: this._captureException
        });
    }
    async uploadHandoffIntegrationFile(e) {
        return hy({
            store: this.store,
            file: e,
            uploadState: this.uploadState,
            clearFileUploadCommandTracking: () => {
                this._clearUploadTracking();
            },
            onCaptureException: this._captureException
        });
    }
    cancelFileUpload() {
        cy(this._getLiveAgentFileUploadRuntimeContext());
    }
    handleIntegrationResult(e, t) {
        wy({
            store: this.store,
            payload: e,
            uploadState: this.uploadState,
            activeFileUploadCommandId: this.uploadState.activeCommandId,
            clearFileUploadCommandTracking: () => {
                this._clearUploadTracking();
            },
            sendToParent: t
        });
    }
    retryZendeskChatDeliveredFileLog() {
        return Sy({
            store: this.store,
            uploadState: this.uploadState,
            clearFileUploadCommandTracking: () => {
                this._clearUploadTracking();
            }
        });
    }
    handleIntegrationEvent(e) {
        let t = this.store.getState().liveAgent.inLiveChat;
        w({
            store: this.store,
            payload: e,
            onLiveChatEnded: () => this._retireActiveFileUpload()
        }), t && !this.store.getState().liveAgent.inLiveChat && (this.chatterTyping.clear(), this._retireActiveFileUpload());
    }
    setTheme(e) {
        this.store.dispatch(ea(e));
    }
    async sendEmailTranscript(e) {
        return Sb({
            store: this.store,
            onCaptureException: (e, t) => {
                P(e, t);
            }
        }, e);
    }
    async downloadTranscript() {
        return Cb({
            store: this.store,
            onCaptureException: (e, t) => {
                P(e, t);
            }
        });
    }
    async sendGreeting(e, t, n) {
        if (this.waitsForEngagement && !this._engagementStarted) return;
        let r = this._lifecycleSignal,
            i = n,
            a = Bc(e, t, n);
        a && r === this._resetGreetingSignal && (this._resetGreetingSignal = null, i = {
            ...n,
            automatic: !1
        }, a = !1);
        let o = this.store.getState().session.conversationGeneration;
        if (a && this._greetingAttempt ? .signal === r && this._greetingAttempt.generation === o) return this._greetingAttempt.promise;
        let s = Vc({
            ...this._getMessageRuntimeContext(),
            greetingPersistence: this.startupState.persistencePromise ? ? void 0,
            getActivePersistenceStorage: this._getActivePersistenceStorage,
            greetingLeaseOwner: this._greetingLeaseOwner
        }, e, t, i);
        if (!a) return s;
        let c = {
            signal: r,
            generation: o,
            promise: s
        };
        this._greetingAttempt = c;
        try {
            await s;
        } finally {
            this._greetingAttempt === c && (this._greetingAttempt = null);
        }
    }
    async injectProactiveConversation(e, t) {
        let n = this._lifecycleSignal,
            r = this._getProactiveInjectionGroup(n);
        if (!r) {
            let {
                session: e,
                chat: t,
                liveAgent: i
            } = this.store.getState();
            r = {
                pending: /* @__PURE__ */ new Set(),
                injected: !1,
                conversationId: e.conversationId,
                generation: e.conversationGeneration,
                acceptedUserSendSeq: t.acceptedUserSendSeq,
                reopenCandidateToken: i.endedConversationReopenCandidateToken
            }, this._proactiveInjections.set(n, r);
        }
        let i = _t({
            store: this.store,
            signal: n,
            onCaptureException: (e, t) => {
                P(e, t);
            }
        }, e, t);
        r.pending.add(i);
        try {
            let e = await i;
            return r.injected || = e, e;
        } finally {
            r.pending.delete(i), this._getProactiveInjectionGroup(n);
        }
    }
    _getProactiveInjectionGroup(e) {
        let t = this._proactiveInjections.get(e);
        if (t && t.pending.size === 0) {
            let {
                session: n,
                chat: r,
                liveAgent: i
            } = this.store.getState();
            if (!t.injected || e.aborted || n.conversationId !== t.conversationId || n.conversationGeneration !== t.generation || r.acceptedUserSendSeq !== t.acceptedUserSendSeq || i.endedConversationReopenCandidateToken !== t.reopenCandidateToken || n.conversationId !== null && !i.hasConversationEnded) {
                this._proactiveInjections.delete(e);
                return;
            }
        }
        return t;
    }
    waitForPendingProactiveInjections() {
        let e = this._lifecycleSignal,
            t = this._getProactiveInjectionGroup(e);
        if (!t) return null;
        let n = (async () => {
                let n = !1;
                for (; t;) {
                    if (await Promise.allSettled(t.pending), e.aborted) return !1;
                    n || = t.injected;
                    let r = this._proactiveInjections.get(e);
                    if (!r) break;
                    if (t = r, t.pending.size === 0) {
                        n || = t.injected;
                        break;
                    }
                }
                return n;
            })(),
            r = {
                signal: e,
                settled: n
            };
        return this._proactiveConversationStartWaiter = r, {
            settled: n,
            release: () => {
                this._proactiveConversationStartWaiter === r && (this._proactiveConversationStartWaiter = null, t ? .pending.size === 0 && this._proactiveInjections.get(e) === t && this._proactiveInjections.delete(e));
            }
        };
    }
    getQueuedProactiveConversationStart() {
        return this._proactiveConversationStartWaiter ? .signal === this._lifecycleSignal && !this._lifecycleSignal.aborted ? this._proactiveConversationStartWaiter.settled : null;
    }
    _getTransportRevalidationContext() {
        return {
            store: this.store,
            state: this.transportRevalidationState,
            now: () => Date.now(),
            getClientConfigUrl: () => {
                let {
                    handle: e,
                    endpoint: t,
                    cluster: n
                } = this.store.getState().session;
                if (!e || !t) return null;
                try {
                    return n_(r_(n, t, e), e, t);
                } catch {
                    return null;
                }
            },
            isWebSocketTransport: () => this._instance.transport instanceof Cg,
            isTransportConnected: () => this._instance.transport.status === "connected",
            isSwapSafe: () => {
                let e = this.store.getState().session;
                return this.startupState.activatePromise === null && this.startupState.isActivated && !!e.chatterToken && !e._chatterAnnouncementSuppressed;
            },
            swapTransport: async (e, t = this._lifecycleSignal) => {
                let n = this.store.getState().session;
                if (t.aborted || !this.startupState.isActivated || this.startupState.activatePromise !== null || !n.chatterToken || n._chatterAnnouncementSuppressed) return;
                let r = Mx(this._lifecycleSignal, t),
                    i = r.signal;
                try {
                    if (i.aborted) return;
                    let t = this.startupState.client;
                    if (!t) return;
                    let n = this.store.getState().chat.messages.flatMap((e) => e.isStreaming === !0 && e.streamId ? [e.streamId] : []);
                    t.websocket_endpoint = e.websocket_endpoint, t.pusher_key = e.pusher_key, t.pusher_cluster = e.pusher_cluster, t.pusher_fallback_allowed = e.pusher_fallback_allowed, this.prepareReactivation();
                    let r;
                    try {
                        r = this._engagementStarted ? await this._activateRuntime(!1, i) : await this._activateRuntime(!0, i);
                    } catch (e) {
                        wx.error("Transport swap threw; arming recovery", {
                            err: e.message
                        }), R("transport_revalidation_swap_failed", {
                            outcome: "threw"
                        }), !i.aborted && !this._engagementStarted ? this._parkBackgroundSession("transport_swap_failed") : i.aborted || this.retryTransportAfterDeferred();
                        return;
                    }
                    if (i.aborted || r.kind === "aborted") return;
                    if (r.kind === "deferred" && r.appReady) {
                        for (let e of n) this.store.dispatch(yr({
                            streamId: e
                        }));
                        this.retryTransportAfterDeferred();
                        return;
                    }
                    if (r.kind !== "activated") {
                        if (!this._engagementStarted) {
                            this._parkBackgroundSession(`transport_swap_${r.kind}`);
                            return;
                        }
                        wx.warn("Transport swap did not connect; arming recovery", {
                            outcome: r.kind
                        }), R("transport_revalidation_swap_failed", {
                            outcome: r.kind
                        }), this.retryTransportAfterDeferred();
                        return;
                    }
                    for (let e of n) this.store.dispatch(yr({
                        streamId: e
                    }));
                } finally {
                    r.cleanup();
                }
            }
        };
    }
    async _revalidateTransport() {
        let e = this.store.getState().session;
        !this.startupState.isActivated || !e.chatterToken || e._chatterAnnouncementSuppressed || await Db(this._getTransportRevalidationContext());
    }
    _handleTokenExpired() {
        if (this.subscriptionState.tokenExpiredRecoveryInFlight) return;
        let e = Date.now();
        this.subscriptionState.tokenExpiredGaveUp && this._tokenExpiredRecoveryProven(e) && this._releaseTokenExpiredGiveUp(), this.subscriptionState.subscriptionConfirmedAt = 0;
        let t = e - this.subscriptionState.lastTokenExpiredAt;
        if (this.subscriptionState.tokenExpiredStreak = this.subscriptionState.lastTokenExpiredAt > 0 && t < Dx ? this.subscriptionState.tokenExpiredStreak + 1 : 1, this.subscriptionState.lastTokenExpiredAt = e, this.subscriptionState.tokenExpiredGaveUp || this.subscriptionState.tokenExpiredStreak > Ox) {
            this._giveUpTokenExpiredRecovery();
            return;
        }
        let n = this.subscriptionState.tokenExpiredStreak <= 1 ? 0 : Math.min(Tx * 2 ** (this.subscriptionState.tokenExpiredStreak - 2), Ex);
        this._scheduleTransportRecovery(n);
    }
    _scheduleTransportRecovery(e, t = !1) {
        if (this.subscriptionState.tokenExpiredRecoveryInFlight = !0, this.subscriptionState.tokenExpiredRecoveryGeneration += 1, e === 0) {
            this._reactivateAfterTokenExpired(t);
            return;
        }
        this.subscriptionState.tokenExpiredBackoffTimer = setTimeout(() => {
            this.subscriptionState.tokenExpiredBackoffTimer = null, this._reactivateAfterTokenExpired(t);
        }, e);
    }
    _tokenExpiredRecoveryProven(e) {
        let t = this.subscriptionState.subscriptionConfirmedAt;
        return t > 0 && e - t >= Dx;
    }
    _clearTokenExpiredGiveUpProbe() {
        this.subscriptionState.tokenExpiredGaveUp = !1, this.subscriptionState.tokenExpiredGiveUpProbeTimer && (clearInterval(this.subscriptionState.tokenExpiredGiveUpProbeTimer), this.subscriptionState.tokenExpiredGiveUpProbeTimer = null);
    }
    _releaseTokenExpiredGiveUp() {
        this._clearTokenExpiredGiveUpProbe(), this.subscriptionState.tokenExpiredStreak = 0, this.subscriptionState.lastTokenExpiredAt = 0;
    }
    _giveUpTokenExpiredRecovery() {
        let e = !this.subscriptionState.tokenExpiredGaveUp;
        this.subscriptionState.tokenExpiredGaveUp = !0, e && (R("transport_token_expired_giveup"), wx.error(`Giving up rapid WebSocket re-activation after ${Ox} rapid token_expired events; the gateway is rejecting tokens (check MESSAGING_JWT_SIGNING_SECRET / ws-gateway build). Probing once every ${kx}ms so a repaired gateway recovers without a reload.`)), !this.subscriptionState.tokenExpiredGiveUpProbeTimer && (this.subscriptionState.tokenExpiredGiveUpProbeTimer = setInterval(() => {
            if (!this.subscriptionState.tokenExpiredRecoveryInFlight) {
                if (this._tokenExpiredRecoveryProven(Date.now())) {
                    R("transport_token_expired_giveup_recovered"), this._releaseTokenExpiredGiveUp();
                    return;
                }
                R("transport_token_expired_giveup_probe"), this.subscriptionState.tokenExpiredRecoveryInFlight = !0, this._reactivateAfterTokenExpired();
            }
        }, kx));
    }
    _recoverDroppedSession(e) {
        if (!this._engagementStarted) return this._parkBackgroundSession("session_auth_terminal"), !1;
        if (this._deadSessionRecoveryPromise) return !1;
        let t = this._deferredGreeting ? .signal === this._lifecycleSignal ? this._deferredGreeting : null;
        R("session_dropped_recovery_started", {
            trigger: e
        }), this._instance.lifecycle.supersede();
        let n = this._instance.lifecycle.signal;
        return this.store.dispatch(xn(I())), this.clearConversationForFreshSession(), this.resetRuntimeState(), this._deferredGreeting = {
            signal: n,
            allowed: t ? .allowed !== !1
        }, this._deadSessionRecoveryPromise = this.prepare().then(() => n.aborted ? {
            kind: "aborted"
        } : this.activate()).then((r) => {
            if (!n.aborted) {
                if (r.kind === "deferred") {
                    this._retryDeferredTransport(r.appReady === !0);
                    return;
                }
                r.kind === "activated" && (R("session_dropped_recovery_succeeded", {
                    trigger: e
                }), this._deferredGreeting = null, this._engagementStarted && t ? .allowed !== !1 && this.sendGreeting(void 0, void 0, {
                    automatic: !0
                }));
            }
        }).catch((t) => {
            R("session_dropped_recovery_failed", {
                trigger: e
            }), wx.error("Dead-session recovery failed:", t);
        }).finally(() => {
            this._deadSessionRecoveryPromise = null;
        }), !0;
    }
    _parkBackgroundSession(e) {
        let t = this.store.getState().session;
        if (e === "resume_engagement_raced" && this._engagementStarted && !t._chatterAnnouncementSuppressed) return;
        R("background_session_parked", {
            reason: e
        }), this._historyPreservingResetAppReady = null;
        let n = t._chatterAnnouncementSuppressed ? t.chatterToken : null;
        this.startupState.persistence ? .stopTokenSync(), this.startupState.persistence ? .cancelPendingRestoredHistory(), this.store.dispatch(pa()), this.transport.disconnect(), Eb(this.transportRevalidationState), this._teardownSubscriptions(), this._clearTokenExpiredRecovery(), this.subscriptionState.messagingTokenUnsubscribe ? .(), this.subscriptionState.messagingTokenUnsubscribe = null, this.startupState.activatePromise = null, this.startupState.isActivated = !1, this.startupState.isPrepared = !1, this.startupState.backgroundResumePreparedChatterToken = null, this._engagedAppActionReady = !1, n && (this.clearConversationRuntime(), Uo(this.store), this.clearConversationForFreshSession(), this.store.dispatch(Go({
            keepPageLatch: !0
        })), this.store.dispatch(aa()), this.store.dispatch(pn({
            chatterToken: n
        })));
    }
    _reactivateAfterTokenExpired(e = !1) {
        let t = this._lifecycleSignal,
            n = this._deferredGreeting ? .signal === t ? this._deferredGreeting : null;
        this.subscriptionState.tokenExpiredRecoveryGeneration += 1;
        let r = this.subscriptionState.tokenExpiredRecoveryGeneration;
        this._teardownSubscriptions(), e || this.startupState.persistence ? .stopTokenSync(), this.subscriptionState.messagingTokenUnsubscribe ? .(), this.subscriptionState.messagingTokenUnsubscribe = null, this.startupState.activatePromise = null, this.startupState.isActivated = !1, e || this.store.dispatch(No());
        let i = !1,
            a;
        (this._engagementStarted ? this.activate() : this._activateRuntime(!0)).then((e) => {
            if (!(t.aborted || r !== this.subscriptionState.tokenExpiredRecoveryGeneration)) {
                if (e.kind === "activated" && n && (this._deferredGreeting = null, this._engagementStarted && n.allowed && this.sendGreeting(void 0, void 0, {
                        automatic: !0
                    })), e.kind === "terminated") {
                    if (!this._engagementStarted) {
                        this._parkBackgroundSession("token_expired_terminal");
                        return;
                    }
                    this._instance.lifecycle.supersede();
                    let e = this._instance.lifecycle.signal;
                    return this.clearConversationForFreshSession(), this.resetRuntimeState(), this._deferredGreeting = {
                        signal: e,
                        allowed: n ? .allowed !== !1
                    }, r = this.subscriptionState.tokenExpiredRecoveryGeneration, this.activate().then((t) => {
                        if (!(e.aborted || r !== this.subscriptionState.tokenExpiredRecoveryGeneration)) {
                            if (t.kind === "deferred") {
                                i = !0, a = t.appReady === !0;
                                return;
                            }
                            t.kind === "activated" && (this._deferredGreeting = null, this._engagementStarted && n ? .allowed !== !1 && this.sendGreeting(void 0, void 0, {
                                automatic: !0
                            })), t.kind === "terminated" && wx.error("Token-expired reinit re-terminated; realtime recovery exhausted (REST still available).");
                        }
                    });
                }
                if (e.kind === "deferred") {
                    if (!this._engagementStarted && !e.appReady) {
                        this._parkBackgroundSession("token_expired_deferred");
                        return;
                    }
                    i = !0, a = e.appReady === !0;
                }
            }
        }).catch((e) => {
            if (wx.error("Re-activation after token_expired failed:", e), !this._engagementStarted) {
                this._parkBackgroundSession("token_expired_failed");
                return;
            }
            i = !0;
        }).finally(() => {
            r === this.subscriptionState.tokenExpiredRecoveryGeneration && (this.subscriptionState.tokenExpiredRecoveryInFlight = !1, i && this._retryDeferredTransport(a));
        });
    }
    _clearTokenExpiredRecovery() {
        this.subscriptionState.transportConfigRetryDelayMs = 0, this.subscriptionState.tokenExpiredBackoffTimer && (clearTimeout(this.subscriptionState.tokenExpiredBackoffTimer), this.subscriptionState.tokenExpiredBackoffTimer = null), this._clearTokenExpiredGiveUpProbe(), this.subscriptionState.subscriptionConfirmedAt = 0, this.subscriptionState.tokenExpiredRecoveryInFlight = !1, this.subscriptionState.tokenExpiredRecoveryGeneration += 1;
    }
    _watchMessagingTokenForTransportRefresh() {
        if (this.subscriptionState.messagingTokenUnsubscribe) return;
        let e = this.store.getState().session.messagingToken;
        this.subscriptionState.messagingTokenUnsubscribe = this.store.subscribe(() => {
            let t = this.store.getState().session.messagingToken;
            t && t !== e && (e = t, this.transport.refreshToken ? .(t));
        });
    }
    notifyComposerText() {
        this.chatterTyping.notifyComposerChanged();
    }
    settleChatterTyping() {
        this.chatterTyping.settle();
    }
    destroy() {
        for (let e of this.startupClocks) e.dispose();
        this.zendeskChatAuth ? .destroy(), this._engagementStarted = !1, this._engagedAppActionReady = !1, this._engagedAppActionPromise = null, this._backgroundResume = null, this._passiveSession = null, this.clearConversationRuntime(), this.chatterVisibility.destroy(), Eb(this.transportRevalidationState), Uo(this.store), this._teardownSubscriptions(), this._clearTokenExpiredRecovery(), this.startupState.persistence ? .stopTokenSync(), this._persistenceStorageDestroy ? .(), this._persistenceStorageDestroy = null, this.startupState.persistence = null, this.subscriptionState.messagingTokenUnsubscribe ? .(), this.subscriptionState.messagingTokenUnsubscribe = null, Jr(null), this.resetFeatureFlags(), this._instance.destroy();
    }
    _clearUploadTracking() {
        ty(this._getLiveAgentFileUploadCommandTrackingContext());
    }
    _retireActiveFileUpload() {
        let e = this.store.getState().liveAgent.file.isUploading,
            t = this.uploadState.activeOperation;
        if (sy(this.uploadState), this._clearUploadTracking(), !e) return;
        let n = !!t ? .deliveredMedia && (t ? .platformName === "zendesk_liveagent" || t ? .platformName === "zendesk_support_liveagent") || t ? .platformName === "zaw_liveagent" && t.deliveryOutcome === "accepted",
            r = t ? .deliveryOutcome === "sending" || t ? .deliveryOutcome === "accepted" || t ? .deliveryOutcome === "indeterminate",
            i = {
                reason: "handoff_ended"
            };
        n ? i = {
            reason: "durability_unknown",
            deliveryConfirmed: !0
        } : r && (i = {
            reason: "delivery_unknown",
            indeterminate: !0
        }), this.store.dispatch(U({
            errorKey: "FILE_UPLOAD_UNKNOWN_ERROR",
            errorData: i
        }));
    }
    _teardownSubscriptions() {
        cv({
            subscriptionState: this.subscriptionState
        });
    }
    _resetStartupState() {
        this.startupState.persistence ? .stopTokenSync(), this._persistenceStorageDestroy ? .(), this._persistenceStorageDestroy = null, this.startupState.client = null, this.startupState.publicClientPromise = null, this.startupState.transportConfigPromise = null, this.startupState.persistencePromise = null, this.startupState.persistenceClearPromise = null, this.startupState.preparePromise = null, this.startupState.activatePromise = null, this.startupState.backgroundResumePreparedChatterToken = null, this.startupState.isPrepared = !1, this.startupState.isActivated = !1, this._engagedAppActionReady = !1, this.startupState.persistence = null, this.subscriptionState.retryCount = 0;
    }
    _getLiveAgentFileUploadCommandTrackingContext() {
        return {
            store: this.store,
            uploadState: this.uploadState
        };
    }
    _getLiveAgentFileUploadRuntimeContext() {
        return {
            store: this.store,
            uploadState: this.uploadState
        };
    }
    _getStartupRuntimeContext(e = this._lifecycleSignal, t) {
        return {
            store: this.store,
            hostTelemetry: this._instance.hostTelemetry,
            transport: this.transport,
            signal: e,
            setTransport: (e) => {
                this._instance.setTransport(e);
            },
            startupState: this.startupState,
            startupClock: t,
            beginStartupTracking: () => this.beginStartupTracking(e),
            zendeskChatAuth: this.zendeskChatAuth,
            onConfigureGreeting: (e) => {
                Sc(this.store, e);
            },
            onLoadTranslations: async (e, t) => {
                await this._loadTranslations(e, t);
            },
            onSubscribeToChannel: () => {
                jh(this._getSubscriptionRuntimeContext());
            },
            onSessionDropped: (e) => {
                this._recoverDroppedSession(e);
            },
            onPusherSessionCleared: async () => e.aborted || (await this.startupState.activatePromise ? .catch(() => void 0), await this._deadSessionRecoveryPromise, e.aborted || this.store.getState().session.chatterToken) ? !1 : this._recoverDroppedSession("pusher_session_expired"),
            claimPusherSessionRecovery: (e) => {
                let t = this._pusherSessionRecoveryTokens;
                if (t.has(e) || this._pusherSessionRecoveryAttempts >= 3) return R("session_dropped_recovery_refused", {
                    reason: t.has(e) ? "already_claimed" : "capped",
                    trigger: "pusher_session_expired"
                }), !1;
                t.add(e);
                let n = !1,
                    r = !1;
                return {
                    commit: () => {
                        !n && !r && t === this._pusherSessionRecoveryTokens && (n = !0, this._pusherSessionRecoveryAttempts += 1);
                    },
                    release: () => {
                        r || (r = !0, t.delete(e));
                    }
                };
            },
            onResolveRolloutCluster: (e, t, n) => r_(e, t, n),
            onGetClientUrl: (e, t, n) => e_(e, t, n),
            onGetClientConfigUrl: (e, t, n) => n_(e, t, n),
            createPersistenceStorage: async (e, t, n) => {
                let r = this.store.getState().session,
                    i = e === "session" && r.features.adaGlassZendeskMessaging === !0 && (r.clearPersistenceOnPrepare || !r.identityToken && !r.identitySession),
                    {
                        handle: a,
                        endpoint: o,
                        cluster: s,
                        mode: l
                    } = this.store.getState().session;
                if (l === "test") {
                    this._persistenceStorageDestroy ? .();
                    let r = !0;
                    if (t ? .clearNormalIdentityStorage) {
                        let e = Xi("normal");
                        r = await Cn.clearStorageKeys(e, {
                            handle: a ? ? "",
                            endpoint: o,
                            cluster: s
                        }, [
                            "greetingLease",
                            Ze(a ? ? "", o, s),
                            Ka(a ? ? ""),
                            Hi(a ? ? "", o, s),
                            at(a ? ? "", o, s),
                            Oe,
                            Ln,
                            oe,
                            j,
                            Un,
                            ...a ? [$t(a), st(a)] : []
                        ], {
                            signal: n
                        });
                    }
                    let c = {
                        ...Xi(r ? e : "private"),
                        ...r && i ? {
                            zdmContinuityStorage: Xi("normal")
                        } : {}
                    };
                    return this._registerGuardedActiveStorage(c, t ? .handoffOnly), this._persistenceStorageDestroy = () => {
                        se(null);
                    }, c;
                }
                let u = a ? [
                        ...At(a, o, s),
                        $y,
                        Re(a),
                        me(a)
                    ] : [Oe, $y],
                    d = t ? .clearNormalIdentityStorage && a ? [
                        "greetingLease",
                        Ze(a, o, s),
                        Ka(a),
                        Hi(a, o, s),
                        at(a, o, s),
                        Oe,
                        Ln,
                        oe,
                        j,
                        Un,
                        $t(a),
                        st(a)
                    ] : [];
                this._persistenceStorageDestroy ? .(), this._persistenceStorageDestroy = null;
                let f = await gn({
                    mode: e,
                    endpoint: o,
                    hydrateKeys: u,
                    clearNormalKeys: d,
                    signal: n,
                    handoffOnly: t ? .handoffOnly || i,
                    ...t ? .degradeWhenUnconfirmed && a ? {
                        degradeUnlessHydrated: Yi(a, o, s),
                        degradeRemovals: (e) => {
                            let t = [Ze(a, o, s), Ka(a)],
                                n = t.every((t) => e.hydrated ? .([t]) !== !1 && e.get(t) === null),
                                r = t.map((t) => e.hydrated ? .([t]) === !1 ? null : Se(e.get(t)) ? .chatterToken).find(Boolean),
                                i = e.hydrated ? .(["chatter"]) === !1 ? null : Zt(e.get(Ln)),
                                l = "removed";
                            return n ? l = "left" : r && i && r !== i && (l = "foreign"), {
                                keys: c(a, o, s, {
                                    mirrors: l === "removed"
                                }),
                                facets: {
                                    mirrors: l
                                }
                            };
                        }
                    } : {}
                });
                if (n ? .aborted) return f.storage;
                let p = i && f.storage.mode === "session" ? await gn({
                    mode: "normal",
                    endpoint: o,
                    hydrateKeys: u,
                    signal: n,
                    handoffOnly: !0
                }) : null;
                if (n ? .aborted) return p ? .destroy(), f.destroy(), f.storage;
                let m = p ? Object.assign(f.storage, {
                    zdmContinuityStorage: p.storage
                }) : f.storage;
                return this._registerGuardedActiveStorage(f.storage, t ? .handoffOnly), this._persistenceStorageDestroy = () => {
                    se(null), p ? .destroy(), f.destroy();
                }, f.degradedFrom ? {
                    ...m,
                    degradedFrom: f.degradedFrom
                } : m;
            },
            onReleasePersistenceStorage: () => {
                this._persistenceStorageDestroy ? .(), this._persistenceStorageDestroy = null;
            },
            privateMode: this._instance.privateMode
        };
    }
    _getMessageRuntimeContext() {
        return {
            store: this.store,
            signal: this._lifecycleSignal,
            messageState: this.messageState,
            cancelOutageTracking: this.cancelOutageTracking,
            onCaptureException: this._captureException
        };
    }
    _getSubscriptionRuntimeContext() {
        let {
            chatterToken: e,
            sessionToken: t
        } = this.store.getState().session, n = this.transport, r = this._lifecycleSignal;
        return {
            getLifecycleSignal: () => this._lifecycleSignal,
            subscriptionState: this.subscriptionState,
            store: this.store,
            transport: this.transport,
            extractBotMessages: Kr,
            toBotMessage: Eo,
            onControlChannelRefreshRequested: () => {
                wx.info("Refresh requested via control channel"), R("control_channel_refresh_requested"), typeof window < "u" && window.location && window.location.reload();
            },
            onRetrySubscription: () => {
                Ph(this._getSubscriptionRetryRuntimeContext());
            },
            onTokenExpired: () => {
                this._handleTokenExpired();
            },
            onHandleLiveAgentTypingIndicator: (e) => {
                na(this.store, e);
            },
            onHandleBotTypingIndicator: (e) => {
                ro(this.store, e);
            },
            onHandleAuthSucceeded: (e) => {
                Ta(this.store, e);
            },
            onHandleSecretMessageRequested: (e) => {
                this._acceptStateGeneration("secret_mode", "request_secret_message", e) && (this.chatterTyping.settle(), Na(this.store));
            },
            onHandleSecretMessageReceivedByAgent: (e) => {
                this._acceptStateGeneration("secret_mode", "secret_message_received_by_agent", e) && li(this.store);
            },
            onHandleMessageStateChanged: (e) => {
                yo(this.store, e);
            },
            onHandleNotification: (e) => {
                qr(this.store, e);
            },
            onHandleLanguageChanged: (e) => {
                let t = e,
                    n = typeof t ? .language == "string" ? t.language : null;
                n && this.session.applyServerLanguage(n);
            },
            onHandleConversationStateChanged: (e) => {
                if (!this._acceptStateGeneration("conversation_state", "conversation_state_changed", e)) return;
                let t = this.store.getState().liveAgent.inLiveChat;
                zr(this.store, e), t && !this.store.getState().liveAgent.inLiveChat && (this.chatterTyping.clear(), this._retireActiveFileUpload());
            },
            onHandleAdaGlassEnvUpdate: (e) => {
                let t = this.store.getState().liveAgent.platformName;
                Ni(this.store, e), t !== this.store.getState().liveAgent.platformName && this._retireActiveFileUpload();
            },
            onHandleAgentFileTransfer: (e) => {
                Sr(this.store, e);
            },
            onHandleZendeskInitConversation: (e) => {
                this._acceptStateGeneration("zendesk_handoff", "zendesk_live_agent_init_conversation", e) && mr(this.store, e);
            },
            onHandleZendeskChatterTypingIndicator: (e) => {
                Ti(this.store, e);
            },
            onHandleZendeskCancelChat: (e) => {
                this._acceptStateGeneration("zendesk_handoff", "zendesk_cancel_live_chat_request", e) && (this.chatterTyping.clear(), this._retireActiveFileUpload(), ua(this.store));
            },
            onHandleZendeskEndChat: (e) => {
                this._acceptStateGeneration("zendesk_handoff", "zendesk_chatter_ended_chat", e) && (this.chatterTyping.clear(), this._retireActiveFileUpload(), _i(this.store));
            },
            onHandleZendeskLastProcessedUpdate: (e) => {
                Do(this.store, e);
            },
            onProcessLiveAgentPresence: (e) => {
                let t = this.store.getState().liveAgent.inLiveChat;
                Zo(this.store, e), t && !this.store.getState().liveAgent.inLiveChat && (this.chatterTyping.clear(), this._retireActiveFileUpload());
            },
            onSubscriptionEstablished: () => {
                this.store.getState().session._chatterAnnouncementSuppressed || Ob(this._getTransportRevalidationContext());
            },
            awaitsSubscriptionConfirmation: this._instance.transport instanceof dg,
            onSubscriptionConfirmed: () => {
                let i = this.store.getState().session;
                n instanceof dg && n === this.transport && !r.aborted && i.chatterToken === e && i.sessionToken === t && (this._pusherSessionRecoveryAttempts = 0, this._pusherSessionRecoveryTokens = /* @__PURE__ */ new Set()), this.subscriptionState.retryCount = 0, this.subscriptionState.subscriptionConfirmedAt = Date.now();
            },
            onBaselineResync: async () => {
                await this._baselineMessageResync(), this._revalidateTransport();
            },
            onIncrementalResync: async () => {
                await this._incrementalMessageResync();
            },
            onCommitMessageCursor: (e) => {
                this._commitMessageCursor(e);
            },
            onConversationSuperseded: () => {
                this.clearSupersededConversationRuntime(!0);
            },
            onStreamFallback: async (e) => {
                await this._fetchStreamFinal(e);
            }
        };
    }
    _getSubscriptionRetryRuntimeContext() {
        return {
            subscriptionState: this.subscriptionState,
            onLogWarning: (e) => {
                wx.warn(e);
            },
            onLogError: (e) => {
                wx.error(e);
            },
            onCaptureException: (e) => {
                P(e);
            },
            onResubscribe: () => {
                jh(this._getSubscriptionRuntimeContext());
            }
        };
    }
    async _loadTranslations(e, t) {
        await a_(this.store, (e, t) => {
            wx.warn(e, t);
        }, e, t);
    }
    _getLastSeenMessageCursor() {
        let {
            conversationId: e
        } = this.store.getState().session;
        return e ? this.store.getState().chat.messageCursorByConversation[e] ? ? "" : "";
    }
    _commitMessageCursor(e) {
        let {
            conversationId: t
        } = this.store.getState().session;
        t && this.store.dispatch(Jt({
            conversationId: t,
            cursor: e
        }));
    }
    _acceptCatchUpConversation(e) {
        return Oh({
            store: this.store,
            onConversationSuperseded: () => {
                this.clearSupersededConversationRuntime();
            }
        }, e);
    }
    async _baselineMessageResync() {
        if (!this.store.getState().session.conversationId) {
            await this.startupState.persistence ? .restoreRecentConversationHistory(this._lifecycleSignal), this.store.getState().session.conversationId && await wa(this.store, "", "baseline", (e) => this._acceptCatchUpConversation(e));
            return;
        }
        let e = this._getLastSeenMessageCursor();
        await Ar(this.store), await wa(this.store, e ? no(e) : "", "baseline", (e) => this._acceptCatchUpConversation(e));
    }
    async _incrementalMessageResync() {
        await wa(this.store, no(this._getLastSeenMessageCursor()), "incremental", (e) => this._acceptCatchUpConversation(e));
    }
    async _fetchStreamFinal(e) {
        await this._incrementalMessageResync(), this.store.getState().chat.messages.some((t) => t.isStreaming === !0 && t.streamId === e) && this.store.dispatch(yr({
            streamId: e
        }));
    }
    setSecretMessageOpen(e) {
        this.store.dispatch(k(e));
    }
};
//#endregion
//#region src/sdk-public-message.ts
function Fx(e) {
    let t = Fe(e.liveAgent.agents);
    if (t) return {
        id: t.id,
        name: t.name,
        ...t.imageUrl && !t.defaultImage ? {
            avatarUrl: t.imageUrl
        } : {}
    };
}

function Ix(e, t) {
    return e.agentInfo ? .internalId ? {
        id: e.agentInfo.internalId,
        name: e.agentInfo.name,
        ...e.agentInfo.imageUrl && !e.agentInfo.defaultImage ? {
            avatarUrl: e.agentInfo.imageUrl
        } : {}
    } : e.sender === "agent" ? Fx(t) : void 0;
}

function Lx(e) {
    switch (e.type) {
        case "quick_replies":
            return {
                quickReplies: e.quickReplies,
                isForced: e.isForced
            };
        case "link":
            return {
                url: e.url,
                linkText: e.linkText,
                title: e.title,
                linkDescription: e.linkDescription,
                linkIcon: e.linkIcon,
                altText: e.altText,
                newWindow: e.newWindow,
                articleId: e.articleId
            };
        case "picture":
            return {
                picUrl: e.picUrl,
                altText: e.altText
            };
        case "video":
            return {
                vidUrl: e.vidUrl,
                altText: e.altText
            };
        case "downloadable":
            return {
                url: e.url,
                name: e.name,
                mimeType: e.mimeType,
                ...e.caption ? {
                    caption: e.caption
                } : {},
                ...e.attachmentGroupId ? {
                    attachmentGroupId: e.attachmentGroupId
                } : {}
            };
        case "options_message":
            return {
                options: e.options
            };
        case "surfaceable_list_selection":
            return {
                variableId: e.variableId,
                selectables: e.selectables,
                multiple: e.multiple,
                prompt: e.prompt
            };
        case "queue_bot_block":
            return {
                queuePosition: e.queuePosition,
                waitMessage: e.waitMessage,
                platform: e.platform
            };
        case "widget":
            return {
                widgetName: e.widgetName,
                ariaLabel: e.ariaLabel,
                widgetUrl: e.widgetUrl,
                linkText: e.linkText,
                linkSubtext: e.linkSubtext,
                inlineInChat: e.inlineInChat
            };
        case "sign_in":
            return {
                authButtonLabel: e.authButtonLabel,
                authProvider: e.authProvider,
                authLinkExpired: e.authLinkExpired,
                messageLead: e.messageLead
            };
        case "csat":
            return {
                surveyType: e.surveyType,
                scaleType: e.scaleType,
                score: e.score,
                submitted: e.submitted
            };
        case "presence":
            return {
                event: e.event
            };
        default:
            return;
    }
}

function Rx(e, t) {
    let n = Ix(e, t),
        r = Lx(e),
        i = e.buttonType == null ? r : {
            ...r ? ? {},
            buttonType : e.buttonType
        };
    return {
        id: e.id,
        role: e.sender,
        type: e.type,
        ...e.body ? {
            body: e.body
        } : {},
        createdAt: e.timestamp / 1e3,
        ...n ? {
            agent: n
        } : {},
        ...i ? {
            data: i
        } : {},
        ...e.origin ? {
            origin: e.origin
        } : {}
    };
}
var zx = new Set(["presence"]);

function Bx(e) {
    return !zx.has(e.type);
}
//#endregion
//#region src/sdk-message-router.ts
function Vx(e) {
    let t = F(e);
    return !t || Array.isArray(t) ? null : t;
}

function $(e) {
    return O(e) ? ? "";
}

function Hx(e) {
    return !!Vx(e);
}

function Ux(e, t) {
    return e ? Object.keys(e).some((n) => n !== "proactive_conversation" && (!Object.hasOwn(t, n) || t[n] !== e[n])) : !1;
}
var Wx = new Set([
    "FETCH_ERROR",
    "PARSING_ERROR",
    "TIMEOUT_ERROR",
    "CUSTOM_ERROR"
]);

function Gx(e, t) {
    let n = Vx(t) ? .status,
        r;
    return (typeof n == "number" && Number.isSafeInteger(n) && n >= 100 && n <= 599 || typeof n == "string" && Wx.has(n)) && (r = n), {
        reason: e,
        ...r === void 0 ? {} : {
            status: r
        }
    };
}

function Kx(e, t) {
    let n = e[wt];
    return n == null ? t : {
        [wt]: n,
        ...t
    };
}

function qx(e, t) {
    return e !== null && Object.hasOwn(e, t);
}

function Jx(e, t) {
    if (!qx(e, "greeting")) return t || void 0;
}

function Yx(e) {
    if (qx(e, "greetingResponseId")) return $(e.greetingResponseId) || null;
    if (qx(e, "greeting")) return $(e.greeting) || null;
}

function Xx(e) {
    let t = Vx(e);
    return t ? Vx(t.sensitiveMetaFields) ? ? t : null;
}

function Zx(e) {
    let t = Vx(e);
    if (!t) return;
    let n = {};
    for (let [e, r] of Object.entries(t)) typeof r == "string" && (n[e] = r);
    return Object.keys(n).length > 0 ? n : void 0;
}

function Qx(e) {
    let t = Vx(e);
    if (!t) return;
    let n = {};
    for (let [e, r] of Object.entries(t)) e && (typeof r == "string" || typeof r == "number" || typeof r == "boolean" || r === null) && (n[e] = r);
    return n;
}

function $x(e) {
    let t = Qx(e);
    return t ? ai(t) : void 0;
}

function eS(e) {
    let t = Vx(e);
    if (!t) return null;
    let n = {};
    return typeof t.initialURL == "string" && t.initialURL && (n.initialURL = t.initialURL), typeof t.introShown == "boolean" && (n.introShown = t.introShown), Object.keys(n).length > 0 ? n : null;
}

function tS(e) {
    let t = Vx(e),
        n = $(t ? .key);
    return n ? {
        key: n,
        params: Zx(t ? .params),
        triggerMethod: t ? .triggerMethod === "url" ? "url" : "programmatic",
        ...typeof t ? .intentId == "number" && Number.isSafeInteger(t.intentId) && t.intentId > 0 ? {
            intentId: t.intentId
        } : {}
    } : null;
}

function nS(e) {
    let t = Vx(e);
    return t ? {
        handle: $(t.handle) || void 0,
        responseId: $(t.responseId) || void 0
    } : {};
}

function rS(e) {
    let t = Vx(e);
    return !t || typeof t.transcript != "string" || typeof t.isFinal != "boolean" ? null : {
        transcript: t.transcript,
        isFinal: t.isFinal
    };
}

function iS(e) {
    let t = Vx(e),
        n = typeof t ? .key == "string" ? t.key.trim() : "";
    return n ? {
        key: n,
        value: typeof t ? .value == "number" ? t.value : void 0,
        meta: Vx(t ? .meta) ? ? void 0
    } : null;
}
var aS = "ProgrammaticControlNotEnabled: this API requires `start({ enableProgrammaticControl: true })`.",
    oS = 60,
    sS = 3,
    cS = "ada-custom-app-transparent";

function lS(e) {
    let t = /* @__PURE__ */ new Map(),
        n = 0,
        r = /* @__PURE__ */ new Map(),
        {
            instance: i,
            orchestrator: a,
            activateChat: o,
            sendToParent: s,
            logger: c,
            getRuntimeInfo: l,
            setChatVisible: u,
            resetRuntimeSession: d,
            hasPersistedChatter: f,
            getExistingChatterCandidate: p,
            resumeExistingChatter: m,
            showRestoredChat: h
        } = e,
        g = /* @__PURE__ */ new Map(),
        _ = null,
        y = null,
        b = null,
        x = 0,
        S = null,
        C = null,
        w = null,
        T = /* @__PURE__ */ new WeakMap(),
        E = /* @__PURE__ */ new WeakSet(),
        D = (e, t = 0) => {
            let n = i.store.getState();
            return !e.aborted && !n.greeting.isSkippedForPage && n.greeting.isSkipped && !n.chat.userHasSentInCurrentConversation && !E.has(e) && (T.get(e) ? ? 0) <= t ? (i.store.dispatch(ke()), !0) : !1;
        },
        O = i.store.getState().session._appFrameIsCustom,
        ee = () => {
            document.documentElement.classList.remove(cS);
        };
    O || ee();
    let k = i.store.subscribe(() => {
        let e = i.store.getState().session._appFrameIsCustom;
        e !== O && (O = e, O || ee());
    });
    i.lifecycle.teardownSignal.addEventListener("abort", () => {
        k(), ee();
    }, {
        once: !0
    });

    function A() {
        return C ? ? Promise.resolve();
    }

    function j(e, t) {
        let n = g.get(e);
        return n || (n = /* @__PURE__ */ new Set(), g.set(e, n)), n.add(t), () => {
            n.delete(t), n.size === 0 && g.delete(e);
        };
    }
    let te = !1;

    function ne(e, t, n, r, i) {
        n || te || !r && !i || (te = !0, c.warn("allowMetaFieldsInReset opt-out dropped metaFields", {
            handle: e,
            source: t,
            hasMetaFields: r,
            hasSensitiveMetaFields: i
        }));
    }

    function M(e, t, n = "reset") {
        let r = i.store.getState().session,
            o = a.getStorageMode(),
            c = o === "private" ? ["private"] : ["normal", "session"],
            l = $(e ? .language),
            u = !!l || r.hostLanguage !== null,
            f = l || r.hostLanguage || Ol(),
            p = Jx(e, r.greeting),
            m = Yx(e),
            h = $(e ? .identityToken),
            g = r.allowMetaFieldsInReset,
            _ = sr(v(g ? $x(e ? .metaFields) ? ? r.metaFields : r.metaFieldsBaseline), r.metaFields),
            y = $n(r.deviceToken, r.deviceOs ? ? void 0),
            b = qt(g ? $x(e ? .sensitiveMetaFields) ? ? {} : {}, y),
            x = $x(e ? .metaFields) ? ? {},
            S = $x(e ? .sensitiveMetaFields) ? ? {};
        ne(r.handle, n, g, Ux(x, _) || Ux(r.metaFields, _), Ux(S, b) || Ux(r.sensitiveMetaFields, b));
        let C = r._themeSetBySdk ? r.theme : void 0;
        i.store.dispatch(vn()), i.lifecycle.supersede(), d({
            resetChatHistory: !0
        }), a.resetFeatureFlags(), i.store.dispatch(ot()), i.store.dispatch(fe()), i.store.dispatch(aa()), i.store.dispatch(An()), i.store.dispatch(Go({
            keepPageLatch: !1
        })), i.store.dispatch(tn()), i.store.dispatch(pe()), r.handle && r.endpoint && i.store.dispatch(kr({
            handle: r.handle,
            cluster: r.cluster,
            endpoint: r.endpoint,
            language: f,
            languageFromHost: u,
            hostLanguage: l || r.hostLanguage || null,
            greeting: p,
            configuredGreetingResponseId: void 0,
            identityToken: h,
            metaFields: _,
            theme: C,
            mode: r.mode ? ? void 0,
            isParentElementMode: r.isParentElementMode,
            isMobileViewport: r.isMobileViewport,
            hideDefaultHeader: r.hideDefaultHeader,
            hostBranding: r.hostBranding,
            allowMetaFieldsInReset: r.allowMetaFieldsInReset,
            enableProgrammaticControl: r.enableProgrammaticControl,
            clearPersistenceOnPrepare: !0,
            clearPersistenceAckRequestId: t ? .requestId,
            clearPersistenceAckResponseType: t ? .responseType,
            clearPersistenceStorageModes: c,
            clearPersistenceOutgoingStorageMode: r.clearPersistenceOnPrepare && r.clearPersistenceOutgoingStorageMode === "normal" ? "normal" : o
        })), Object.keys(b).length > 0 && i.store.dispatch(Vo(b)), r.deviceToken && i.store.dispatch(To({
            token: r.deviceToken,
            deviceOs: r.deviceOs
        })), m !== void 0 && (i.store.dispatch(Gt(m)), m && i.store.dispatch(fs())), e ? .skipGreeting === !0 && i.store.dispatch(Rn()), i.store.dispatch(xn(I()));
        let w = i.lifecycle.signal;
        a.clearPersistenceDurably(t ? .requestId).then((e) => {
            e && !w.aborted && t && s(t.responseType, {
                requestId: t.requestId
            });
        });
    }

    function re(e, t) {
        let n = $(t ? .language) || e.language,
            r = !!$(t ? .language) || e.languageFromHost,
            a = Jx(t, e.greeting),
            o = Yx(t),
            s = sr($x(t ? .metaFields) ? ? e.metaFields, e.metaFields),
            c = Kx(e.metaFields, s),
            l = $x(t ? .sensitiveMetaFields),
            u = e._themeSetBySdk ? e.theme : void 0;
        return e.handle && e.endpoint && i.store.dispatch(kr({
            handle: e.handle,
            cluster: e.cluster,
            endpoint: e.endpoint,
            language: n,
            languageFromHost: r,
            hostLanguage: $(t ? .language) || e.hostLanguage,
            greeting: a,
            configuredGreetingResponseId: void 0,
            metaFields: c,
            identityToken: e.identityToken ? ? void 0,
            theme: u,
            mode: e.mode ? ? void 0,
            isParentElementMode: e.isParentElementMode,
            isMobileViewport: e.isMobileViewport,
            hideDefaultHeader: e.hideDefaultHeader,
            hostBranding: e.hostBranding,
            allowMetaFieldsInReset: e.allowMetaFieldsInReset,
            enableProgrammaticControl: e.enableProgrammaticControl,
            clearPersistenceOnPrepare: e.clearPersistenceOnPrepare,
            clearPersistenceAckRequestId: e.clearPersistenceAckRequestId ? ? void 0,
            clearPersistenceAckResponseType: e.clearPersistenceAckResponseType ? ? void 0,
            clearPersistenceStorageModes: e.clearPersistenceStorageModes,
            clearPersistenceOutgoingStorageMode: e.clearPersistenceOutgoingStorageMode ? ? void 0
        })), l && Object.keys(l).length > 0 && i.store.dispatch(Vo(l)), o !== void 0 && (i.store.dispatch(Gt(o)), o && i.store.dispatch(fs())), {
            language: n,
            metaFields: s,
            sensitiveMetaFields: l
        };
    }

    function ie(e) {
        let t = tS(e);
        if (!t) return;
        let n = a.getStartupConfig() ? .proactiveConversations ? .[t.key];
        if (!n) return;
        let r = n.modality_config ? .chat;
        if (t.triggerMethod === "programmatic") {
            if (r && !r.active) {
                c.warn("proactive inject: message is not active", {
                    key: t.key
                });
                return;
            }
            if (!xa(r ? .schedule_start, r ? .schedule_end)) {
                c.warn("proactive inject: message is outside its scheduled window", {
                    key: t.key
                });
                return;
            }
        }
        let o = i.store.getState().session.language,
            s = n.messages[o] ? .[0] ? ? n.messages.en ? .[0] ? ? "";
        if (!s) return;
        let l = s;
        if (n.is_template) {
            let e = t.params;
            if (!e || Object.keys(e).length === 0) {
                c.warn("proactive inject: template message has no parameters", {
                    key: t.key
                });
                return;
            }
            let n = Mn(s).filter((t) => !Object.hasOwn(e, t));
            if (n.length > 0) {
                c.warn("proactive inject: template message is missing parameters", {
                    key: t.key,
                    missingParams: n
                });
                return;
            }
            l = je(s, e);
        }
        let {
            images: u
        } = n, d = u ? .[o] ? .[0] ? ? (u ? u[Object.keys(u).sort()[0]] ? .[0] : void 0), f = n.ctas ? .[0];
        i.store.dispatch(lt({
            messages: [{
                id: t.key,
                body: l,
                campaignKey: t.key,
                timestamp: Date.now(),
                ...d ? {
                    imageUrl: d.url,
                    imageAlt: d.alt
                } : {},
                ...f ? {
                    cta: f
                } : {}
            }],
            duration: r ? .duration ? ? null,
            triggerMethod: t.triggerMethod,
            displayDelay: t.triggerMethod === "programmatic" && typeof r ? .delay == "number" && Number.isFinite(r.delay) ? r.delay : 0,
            frequency: r ? .frequency ? ? "session",
            ...t.intentId === void 0 ? {} : {
                intentId: t.intentId
            },
            pending: {
                key: t.key,
                params: t.params ? ? null,
                playbookId: n.playbook_id ? ? null
            }
        }));
    }

    function N() {
        let {
            proactive: e
        } = i.store.getState();
        e.messages.length === 0 || e.isHidden || i.store.dispatch(Bt());
    }

    function ae() {
        let {
            signal: e
        } = i.lifecycle;
        N(), A().then(() => e.aborted ? void 0 : o()).then(() => {
            e.aborted;
        }).catch((e) => {
            c.error("Chat activation failed:", e);
        });
    }

    function oe(e) {
        let w = g.get(e.type);
        if (w && w.size > 0) {
            for (let t of w) t(e.payload);
            return;
        }
        let O = Vx(e.payload);
        switch ((e.type === "sdk.config.set" || e.type === "sdk.reset" || e.type === "sdk.metaFields.set" || e.type === "sdk.sensitiveMetaFields.set" || e.type === "sdk.playbook.trigger") && en(O ? .metaFieldCounts), e.type) {
            case "sdk.session.prepare":
                if (!a.waitsForEngagement) {
                    ae();
                    return;
                }
                se();
                return;
            case "sdk.activate":
                ae();
                return;
            case "sdk.session.candidate.request":
                {
                    let e = O ? .requestId;
                    if (typeof e != "number" || !Number.isSafeInteger(e) || e <= 0 || !p) return;
                    y = e,
                    p(e).then((t) => {
                        y === e && (y = null, t && s("core.chatter.candidate", {
                            chatterToken: t,
                            requestId: e
                        }));
                    }).catch((t) => {
                        y === e && (y = null), c.warn("Existing chatter candidate warm-up failed:", t);
                    });
                    return;
                }
            case "sdk.session.resume":
                {
                    let e = $(O ? .chatterToken),
                        t = O ? .requestId;
                    if (!e || typeof t != "number" || !Number.isSafeInteger(t) || t <= 0 || !m) return;
                    x += 1,
                    S = null,
                    _ = {
                        chatterToken: e,
                        requestId: t
                    },
                    b = null,
                    m(e, t).then((n) => {
                        n && _ ? .chatterToken === e && _.requestId === t && (b = {
                            chatterToken: e,
                            requestId: t
                        }), s("core.session.resume.result", {
                            chatterToken: e,
                            requestId: t,
                            resumed: n
                        });
                    }).catch((n) => {
                        c.warn("Existing chatter resume failed:", n), s("core.session.resume.result", {
                            chatterToken: e,
                            requestId: t,
                            resumed: !1
                        });
                    });
                    return;
                }
            case "sdk.session.resume.visibility":
                {
                    let e = $(O ? .chatterToken),
                        t = O ? .requestId;
                    if (O ? .isVisible !== !0 || !e || typeof t != "number" || !Number.isSafeInteger(t) || t <= 0 || !h || S ? .chatterToken === e && S.requestId === t) return;
                    if (b ? .chatterToken !== e || b.requestId !== t) {
                        s("core.session.resume.visibility.result", {
                            chatterToken: e,
                            requestId: t,
                            visible: !1
                        });
                        return;
                    }
                    b = null,
                    S = {
                        chatterToken: e,
                        requestId: t
                    };
                    let n = x;
                    h(e, t).then((r) => {
                        s("core.session.resume.visibility.result", {
                            chatterToken: e,
                            requestId: t,
                            visible: r === !0 && n === x
                        });
                    }).catch((n) => {
                        c.warn("Restored chatter visibility failed:", n), s("core.session.resume.visibility.result", {
                            chatterToken: e,
                            requestId: t,
                            visible: !1
                        });
                    }).finally(() => {
                        S ? .chatterToken === e && S.requestId === t && (S = null);
                    });
                    return;
                }
            case "sdk.notifications.permission":
                {
                    let e = O ? .permission;
                    (e === "default" || e === "granted" || e === "denied") && i.store.dispatch(Yo({
                        permission: e,
                        supported: O ? .supported === !0
                    }));
                    return;
                }
            case "sdk.visibility.set":
                {
                    let e = O ? .isVisible === !0,
                        t = l().chatVisible;
                    u(e),
                    e ? O ? .historyPreservingReset !== !0 && ae() : t && (O ? .reason === "close" || O ? .reason === "minimize") && s("core.event.publish", {
                        key: O ? .reason === "close" ? "ada:close_chat" : "ada:minimize_chat",
                        data: fc(i.store.getState())
                    });
                    return;
                }
            case "sdk.hostViewport.set":
                {
                    if (!O) return;
                    let e = Object.keys(O);
                    e.length === 1 && O.viewport === null ? i.store.dispatch($r(null)) : e.length === 2 && typeof O.width == "number" && Number.isFinite(O.width) && O.width >= 0 && typeof O.height == "number" && Number.isFinite(O.height) && O.height >= 0 && i.store.dispatch($r({
                        width: O.width,
                        height: O.height
                    }));
                    return;
                }
            case "sdk.frameStyles.applied":
                document.documentElement.classList.toggle(cS, O ? .transparentBackground === !0 && i.store.getState().session._appFrameIsCustom);
                return;
            case "sdk.proactive.inject":
                ie(e.payload);
                return;
            case "sdk.proactive.shown":
                {
                    let e = $(O ? .campaignKey),
                        t = Number(O ? .surfaceId);
                    if (e && Number.isSafeInteger(t) && t > 0) {
                        i.store.dispatch(ge({
                            campaignKey: e,
                            surfaceId: t
                        }));
                        let {
                            displayed: n
                        } = i.store.getState().proactive;
                        n ? .surfaceId === t && R("proactive_shown", {
                            campaignKey: e,
                            proactiveKey: n.pending ? .key ? ? null
                        });
                    }
                    return;
                }
            case "sdk.proactive.replaced":
                {
                    let e = Number(O ? .surfaceId);
                    Number.isSafeInteger(e) && e > 0 && i.store.dispatch(ss({
                        surfaceId: e
                    }));
                    return;
                }
            case "sdk.proactive.clear":
                {
                    let e = Number(O ? .requestId);
                    if (!Number.isSafeInteger(e) || e <= 0) return;
                    i.store.dispatch(Bt()),
                    s("core.proactive.cleared", {
                        requestId: e
                    });
                    return;
                }
            case "sdk.proactive.engaged":
                {
                    let e = Number(O ? .surfaceId),
                        t = $(O ? .campaignKey),
                        {
                            displayed: n
                        } = i.store.getState().proactive;
                    if (!Number.isSafeInteger(e) || e <= 0 || !t || n ? .surfaceId !== e || n.campaignKey !== t) return;
                    let r = n.pending;
                    i.store.dispatch(tn()),
                    r ? .key && i.store.dispatch(Ge(e));
                    let {
                        signal: s
                    } = i.lifecycle,
                    l = () => i.store.getState().greeting.heldForProactive === e,
                    u = (e) => {
                        R("proactive_conversation_injection_failed", {
                            ...e,
                            proactiveKey: r ? .key ? ? null
                        });
                    },
                    d = () => {
                        u(Gx("superseded_by_later_engagement"));
                    },
                    f = async (t) => {
                        i.store.dispatch(sn(e)), await a.sendGreeting(void 0, void 0, {
                            automatic: !0,
                            ...t
                        });
                    };
                    A().then(() => s.aborted ? void 0 : o()).then(async () => {
                        if (!r ? .key || s.aborted) return;
                        if (!l()) {
                            d();
                            return;
                        }
                        if (Ui(i.store.getState())) {
                            u(Gx("blocked_active_conversation")), D(s), await f();
                            return;
                        }
                        a.session.setMetaFields({
                            [wt]: r.key
                        }, {
                            bypassQueue: !0
                        }), r.playbookId && i.store.dispatch(Rn());
                        let t = i.store.getState(),
                            n = t.session.conversationId,
                            o = t.liveAgent.hasConversationEnded && n !== null,
                            p = t.session.conversationGeneration;
                        o && i.store.dispatch(Di({
                            conversationId: n,
                            surfaceId: e,
                            afterCursor: ei(i.store)
                        }));
                        let m = Gx("not_injected"),
                            h = await a.injectProactiveConversation(r.key, r.params ? ? void 0).catch((e) => (m = Gx("exception", e), c.error("Proactive injection failed:", e), !1));
                        if (o && (!h || s.aborted) && i.store.dispatch(fa({
                                conversationId: n,
                                surfaceId: e
                            })), s.aborted) return;
                        let g = i.store.getState();
                        if (h) {
                            if (g.session.conversationGeneration !== p) {
                                u(Gx("superseded_by_conversation_change"));
                                return;
                            }
                            if (!l()) {
                                d();
                                return;
                            }
                        } else {
                            if (u(m), !l()) return;
                            let t = a.getQueuedProactiveConversationStart();
                            if (t) {
                                let n = await t;
                                if (s.aborted || !l()) return;
                                if (!n) {
                                    i.store.dispatch(sn(e));
                                    return;
                                }
                                if (g = i.store.getState(), g.session.conversationGeneration !== p) return;
                            }
                        }
                        if (g.chat.userHasSentInCurrentConversation) {
                            i.store.dispatch(sn(e));
                            return;
                        }
                        if (h && r.playbookId) {
                            i.store.dispatch(sn(e));
                            return;
                        }
                        D(s), await f(h ? {
                            afterProactiveInjection: n === null
                        } : void 0);
                    }).catch(async (e) => {
                        if (c.error("Proactive engagement failed:", e), !s.aborted) {
                            if (r ? .key) {
                                if (!l()) return;
                                u(Gx("exception", e)), D(s);
                            } else {
                                i.store.getState().greeting.heldForProactive === null && D(s);
                                return;
                            }
                            await f().catch((e) => {
                                c.error("Proactive fallback greeting failed:", e);
                            });
                        }
                    }).finally(() => {
                        i.store.dispatch(sn(e));
                    });
                    return;
                }
            case "sdk.proactive.dismissed":
                {
                    let e = Number(O ? .surfaceId),
                        t = $(O ? .campaignKey),
                        n = i.store.getState().proactive;
                    if (!Number.isSafeInteger(e) || e <= 0 || !t || n.displayed ? .surfaceId !== e || n.displayed.campaignKey !== t) return;
                    n.currentSurfaceId === e ? i.store.dispatch(Be()) : i.store.dispatch(ss({
                        surfaceId: e
                    }));
                    return;
                }
            case "sdk.greeting.trigger":
                {
                    let t = nS(e.payload),
                        {
                            signal: n
                        } = i.lifecycle;
                    A().then(() => n.aborted ? void 0 : o()).then(() => {
                        n.aborted || a.sendGreeting(t ? .handle, t ? .responseId);
                    }).catch((e) => {
                        c.error("Chat activation failed:", e);
                    });
                    return;
                }
            case "sdk.integration.result":
                a.handleIntegrationResult(e.payload, s);
                return;
            case "sdk.integration.event":
                a.handleIntegrationEvent(e.payload);
                return;
            case "sdk.voice.transcript":
                {
                    let t = rS(e.payload);
                    t && a.voice.handleVoiceTranscript(t.transcript, t.isFinal);
                    return;
                }
            case "sdk.voice.error":
                {
                    let e = O ? .error;
                    typeof e == "string" && a.voice.handleVoiceError(e);
                    return;
                }
            case "sdk.voice.audioLevel":
                typeof O ? .level == "number" && a.voice.handleVoiceAudioLevel(O.level);
                return;
            case "sdk.reset":
                {
                    x += 1,
                    S = null,
                    y = null,
                    _ = null,
                    b = null;
                    let e = $(O ? .identityToken),
                        t = $(O ? .requestId),
                        n = t ? {
                            requestId: t,
                            responseType: "core.reset.response"
                        } : void 0;
                    if (O ? .resetChatHistory === !1 && !e) {
                        let e = C,
                            t = i.store.getState().session,
                            r = t._chatterAnnouncementSuppressed ? t.chatterToken : null,
                            u = $(O ? .expectedChatterToken) || (r ? null : t.chatterToken),
                            f = !!u && O ? .expectedIdentitySession === !0,
                            p = l(),
                            m = !!u || O ? .reactivate === !0 || !a.waitsForEngagement && !r && (!!t.chatterToken || p.chatActivated || p.chatVisible || p.isParentElementMode);
                        i.lifecycle.supersede(), r && a.parkProvisionalChatterForReset(r), d({
                            preservePreparedSession: !0
                        }), i.store.dispatch(mt()), m && a.beginHistoryPreservingReset();
                        let h = i.lifecycle.signal,
                            g = re(t, O),
                            _ = (e = {}) => {
                                let t = [];
                                return O ? .language && (!e.skipUnchangedLanguage || i.store.getState().session.language !== g.language) && t.push(a.session.setLanguage(g.language, {
                                    throwOnError: !0
                                }).catch((e) => {
                                    throw c.error("setLanguage during reset failed:", e), e;
                                })), e.skipStartupDataStorage || t.push(a.session.syncChatterDataStorage({
                                    metaFields: Hx(O ? .metaFields) ? g.metaFields : void 0,
                                    sensitiveMetaFields: Hx(O ? .sensitiveMetaFields) ? g.sensitiveMetaFields : void 0
                                }, {
                                    throwOnError: !0
                                }).catch((e) => {
                                    throw c.error("Metadata sync during reset failed:", e), e;
                                })), Promise.all(t);
                            },
                            v = () => {
                                if (h.aborted) throw Error("History-preserving reset was superseded");
                                let e = l(),
                                    t = i.store.getState().session;
                                if (!e.chatActivated || !t.chatterToken || t._chatterAnnouncementSuppressed || u !== null && (t.chatterToken !== u || e.lastChatterToken !== u || f && !t.identitySession)) throw Error("History-preserving reset did not restore the expected chatter");
                            },
                            y = u,
                            b = async () => {
                                if (!u) {
                                    if (O ? .reactivate !== !0) throw Error("History-preserving reset has no accepted chatter to restore");
                                    return await o({
                                        engagementAuthorized: !0,
                                        throwOnStartupDataSyncError: !0,
                                        deferAppInteractionReady: !0,
                                        deferGreeting: !0
                                    }), y = i.store.getState().session.chatterToken, v(), "ordinary";
                                }
                                return O ? .reactivate === !0 && he("engaged"), await o({
                                    expectedChatterToken: u,
                                    expectedIdentitySession: f,
                                    engagementAuthorized: O ? .reactivate === !0
                                }), v(), "exact";
                            },
                            x = O ? .reactivate === !0,
                            S = async () => {
                                if (!m) {
                                    await _();
                                    return;
                                }
                                if (await b() === "ordinary") {
                                    await _({
                                        skipStartupDataStorage: !0,
                                        skipUnchangedLanguage: !i.store.getState().session.identitySession
                                    }), v();
                                    let e = i.store.getState().session.chatterToken;
                                    if (!e || !a.completeHistoryPreservingReset(e, {
                                            engagementAuthorized: !0
                                        })) throw Error("History-preserving reset lost its activated chatter before completion");
                                    a.sendGreeting();
                                    return;
                                }
                                if (await _({
                                        skipStartupDataStorage: await a.completeHistoryPreservingResetPreparation(u, {
                                            engagementAuthorized: x
                                        })
                                    }), v(), !a.completeHistoryPreservingReset(u, {
                                        engagementAuthorized: x
                                    })) throw Error("History-preserving reset lost its exact chatter before completion");
                                x && a.sendGreeting();
                            },
                            w = e ? e.catch(() => void 0).then(S) : S(),
                            T = Promise.resolve(w).then(() => void 0);
                        C = T, T.then(() => {
                            !h.aborted && C === T && n && (m && v(), s(n.responseType, {
                                requestId: n.requestId
                            }));
                        }).catch((e) => {
                            !h.aborted && C === T && a.releaseHistoryPreservingResetAfterFailure(y ? ? u ? ? "") && x && a.sendGreeting(), c.error("History-preserving reset failed:", e);
                        }).finally(() => {
                            C === T && (C = null);
                        });
                    } else C = null,
                    M(O, n);
                    c.info("Core reset initiated");
                    return;
                }
            case "sdk.language.set":
                {
                    let e = $(O ? .language);
                    if (e) {
                        let {
                            signal: t
                        } = i.lifecycle;
                        A().then(() => t.aborted ? void 0 : a.session.setLanguage(e)).catch((e) => {
                            c.error("setLanguage failed:", e);
                        });
                    }
                    return;
                }
            case "sdk.state.query":
                return;
            case "sdk.theme.set":
                {
                    let e = $(O ? .theme);
                    (e === "light" || e === "dark" || e === "auto") && a.setTheme(e);
                    return;
                }
            case "sdk.metaFields.set":
                if (Hx(O ? .metaFields)) {
                    let {
                        signal: e
                    } = i.lifecycle, t = ai(O.metaFields);
                    A().then(() => e.aborted ? void 0 : a.session.setMetaFields(t)).catch((e) => {
                        c.error("setMetaFields failed:", e);
                    });
                }
                return;
            case "sdk.runtimeMeta.set":
                {
                    let t = eS(e.payload);
                    if (t) {
                        let {
                            signal: e
                        } = i.lifecycle;
                        A().then(() => e.aborted ? void 0 : a.session.setSdkOwnedMetaFields(t)).catch((e) => {
                            c.error("setSdkOwnedMetaFields failed:", e);
                        });
                    }
                    return;
                }
            case "sdk.testModeBanner.set":
                (typeof O ? .label == "string" || O ? .label === null) && i.store.dispatch(It(O.label));
                return;
            case "sdk.sensitiveMetaFields.set":
                {
                    let t = Xx(e.payload);
                    if (t) {
                        let {
                            signal: e
                        } = i.lifecycle, n = ai(t);
                        A().then(() => e.aborted ? void 0 : a.session.setSensitiveMetaFields(n)).catch((e) => {
                            c.error("setSensitiveMetaFields failed:", e);
                        });
                    }
                    return;
                }
            case "sdk.history.delete":
                {
                    C = null,
                    x += 1,
                    S = null,
                    y = null,
                    _ = null,
                    b = null;
                    let e = $(O ? .requestId);
                    M({
                        skipGreeting: O ? .skipGreeting === !0
                    }, e ? {
                        requestId: e,
                        responseType: "core.history.delete.response"
                    } : void 0, "deleteHistory"),
                    c.info("History deletion initiated");
                    return;
                }
            case "sdk.notifications.deviceToken.set":
                {
                    let e = $(O ? .token);
                    if (e) {
                        let t = O ? .deviceOs,
                            n = t === "WEB" || t === "ANDROID" || t === "IOS" || t === null ? t : void 0;
                        a.session.setDeviceToken(e, n).catch((e) => {
                            c.error("setDeviceToken failed:", e);
                        });
                    }
                    return;
                }
            case "sdk.analytics.trackEvent":
                {
                    let t = iS(e.payload);
                    if (!t) return;
                    s("core.analytics.event", {
                        event: t.key,
                        data: {
                            ...t.meta ? ? {},
                            value : t.value ? ? 0
                        }
                    }),
                    dc(i.store.getState().session, t);
                    return;
                }
            case "sdk.info.get":
                {
                    let e = O ? .requestId;
                    if (typeof e != "string") return;
                    let t = (t = !1) => {
                            let n = l(),
                                r = i.store.getState(),
                                a = r.session._chatterAnnouncementSuppressed;
                            s("core.info.response", {
                                requestId: e,
                                isChatOpen: n.chatVisible,
                                isDrawerOpen: n.isParentElementMode === !0 ? !1 : n.chatVisible,
                                hasActiveChatter: !a && r.session.chatterId !== null || !n.chatActivated && t,
                                hasClosedChat: !1
                            });
                        },
                        n = l();!n.chatActivated && !n.isParentElementMode ? f().then(t, () => t()) : t();
                    return;
                }
            case "sdk.metaFields.get":
                {
                    let e = O ? .requestId;
                    if (typeof e != "string") return;
                    s("core.metaFields.response", {
                        requestId: e,
                        metaFields: v(i.store.getState().session.metaFields)
                    });
                    return;
                }
            case "sdk.conversation.get":
                {
                    let e = O ? .requestId;
                    if (typeof e != "string") return;
                    let t = i.store.getState();
                    if (!t.session.enableProgrammaticControl) {
                        s("core.conversation.response", {
                            requestId: e,
                            error: aS
                        });
                        return;
                    }
                    let n = Fx(t);
                    if (t.session._chatterAnnouncementSuppressed) {
                        s("core.conversation.response", {
                            requestId: e,
                            id: null,
                            handoff: {
                                inLiveChat: !1
                            }
                        });
                        return;
                    }
                    s("core.conversation.response", {
                        requestId: e,
                        id: t.session.conversationId,
                        handoff: {
                            inLiveChat: t.liveAgent.inLiveChat,
                            ...n ? {
                                agent: n
                            } : {}
                        }
                    });
                    return;
                }
            case "sdk.messages.get":
                {
                    let e = O ? .requestId;
                    if (typeof e != "string") return;
                    let t = i.store.getState();
                    if (!t.session.enableProgrammaticControl) {
                        s("core.messages.response", {
                            requestId: e,
                            error: aS
                        });
                        return;
                    }
                    if (t.session._chatterAnnouncementSuppressed) {
                        s("core.messages.response", {
                            requestId: e,
                            messages: []
                        });
                        return;
                    }
                    s("core.messages.response", {
                        requestId: e,
                        messages: t.chat.messages.filter(Bx).map((e) => Rx(e, t))
                    });
                    return;
                }
            case "sdk.composerText.set":
                {
                    let e = O ? .requestId;
                    if (typeof e != "string") return;
                    if (!i.store.getState().session.enableProgrammaticControl) {
                        s("core.composerText.response", {
                            requestId: e,
                            error: aS
                        });
                        return;
                    }
                    if (typeof O ? .text != "string") {
                        s("core.composerText.response", {
                            requestId: e,
                            error: "setComposerText rejected by chat: INVALID_PAYLOAD"
                        });
                        return;
                    }
                    if (O.text.length > 500) {
                        s("core.composerText.response", {
                            requestId: e,
                            error: "setComposerText rejected by chat: TOO_LONG"
                        });
                        return;
                    }
                    i.store.dispatch(Zi(O.text)),
                    s("core.composerText.response", {
                        requestId: e,
                        ok: !0
                    });
                    return;
                }
            case "sdk.proactive.custom":
                {
                    let e = $(O ? .responseId);
                    e && i.store.dispatch(Gt(e));
                    return;
                }
            case "sdk.playbook.trigger":
                {
                    let e = $(O ? .requestId);
                    if (!e) return;
                    let t = (t) => s("core.playbook.response", {
                        requestId: e,
                        error: t
                    });
                    if (!i.store.getState().session.enableProgrammaticControl) {
                        c.warn("sdk.playbook.trigger rejected: enableProgrammaticControl is off"), t(aS);
                        return;
                    }
                    let n = O ? .playbookId;
                    if (typeof n != "string" || !/^[a-f\d]{24}$/i.test(n) || O ? .metaFields !== void 0 && !Hx(O.metaFields) || O ? .sensitiveMetaFields !== void 0 && !Hx(O.sensitiveMetaFields)) {
                        t("triggerPlaybook rejected: INVALID_PAYLOAD");
                        return;
                    }
                    let r = Vx(O ? .metaFields),
                        l = Vx(O ? .sensitiveMetaFields),
                        {
                            signal: u
                        } = i.lifecycle,
                        d = () => {
                            if (u.aborted) throw Error("triggerPlaybook cancelled: the session changed");
                        };
                    i.store.dispatch(Rn()),
                    T.set(u, (T.get(u) ? ? 0) + 1);
                    let f = !1;
                    A().then(async () => {
                        d(), a.grantEngagement(), await o(), d();
                        let t = $x(r) ? ? {},
                            c = $x(l) ? ? {};
                        i.store.dispatch(Lr(t)), i.store.dispatch(Vo(c)), f = !0, await a.triggerPlaybook(n, t, c), E.add(u), s("core.playbook.response", {
                            requestId: e,
                            accepted: !0
                        });
                    }).catch((e) => {
                        throw f && !(e instanceof Cx) && E.add(u), e;
                    }).finally(() => {
                        let e = (T.get(u) ? ? 0) - 1;
                        e > 0 ? T.set(u, e) : T.delete(u);
                    }).catch((e) => {
                        e instanceof Cx || u.aborted ? c.warn("sdk.playbook.trigger failed:", e) : c.error("sdk.playbook.trigger failed:", e), (e instanceof Cx || !f) && D(u) && !u.aborted && a.sendGreeting(void 0, void 0, {
                            automatic: !0
                        }), t(e instanceof Error ? e.message : "triggerPlaybook failed");
                    });
                    return;
                }
            case "sdk.quickReply.select":
                {
                    let e = typeof O ? .requestId == "string" ? O.requestId : null;
                    if (!e) return;
                    let t = (t) => s("core.quickReply.response", {
                        requestId: e,
                        error: t
                    });
                    if (!i.store.getState().session.enableProgrammaticControl) {
                        c.warn("sdk.quickReply.select rejected: enableProgrammaticControl is off"), t(aS);
                        return;
                    }
                    let n = O ? .messageId,
                        r = O ? .index;
                    if (typeof n != "string" || !n.trim() || typeof r != "number" || !Number.isInteger(r) || r < 0) {
                        t("selectQuickReply rejected by chat: INVALID_PAYLOAD");
                        return;
                    }
                    let {
                        signal: l
                    } = i.lifecycle,
                    u = () => {
                        let e = i.store.getState();
                        if (js(e.session.chatEnabled, e.outage.type, e.chat.error) === "CHAT_OUTAGE_MID_CONVERSATION") {
                            t("selectQuickReply rejected by chat: CHAT_OUTAGE");
                            return;
                        }
                        if (e.liveAgent.file.isUploading) {
                            t("selectQuickReply rejected by chat: UPLOAD_IN_PROGRESS");
                            return;
                        }
                        return !0;
                    },
                    d = () => {
                        if (!u()) return;
                        let e = i.store.getState(),
                            a = e.chat.messages.find((e) => e.id === n);
                        if (a ? .sender !== "bot" || a.type !== "quick_replies") {
                            t("selectQuickReply rejected by chat: MESSAGE_NOT_FOUND_OR_NOT_QUICK_REPLIES");
                            return;
                        }
                        if (a.conversationId != null && a.conversationId !== e.session.conversationId) {
                            t("selectQuickReply rejected by chat: HISTORICAL_MESSAGE");
                            return;
                        }
                        if (Ns(e.chat.messages, e.chat.answeredInteractiveMessageIds, e.chat.withdrawnAnswerMessageIds).includes(n)) {
                            t("selectQuickReply rejected by chat: ALREADY_ANSWERED");
                            return;
                        }
                        let o = a.quickReplies[r];
                        if (!o) {
                            t("selectQuickReply rejected by chat: INDEX_OUT_OF_RANGE");
                            return;
                        }
                        let s = o.buttonType === "accepted_value";
                        if (!o.label && (!s || !o.value) || !o.target && !s) {
                            t("selectQuickReply rejected by chat: INVALID_QUICK_REPLY");
                            return;
                        }
                        return o;
                    };
                    if (!u()) return;
                    let f = !1;
                    A().then(async () => {
                        if (l.aborted) {
                            t("selectQuickReply cancelled: the session changed before it could be sent");
                            return;
                        }
                        if (a.grantEngagement(), await o(), l.aborted) {
                            t("selectQuickReply cancelled: the session changed before it could be sent");
                            return;
                        }
                        let r = d();
                        if (!r) return;
                        let i = await a.sendQuickReply(r.label, r.target, r.buttonType, n, r.value, "programmatic").catch((e) => {
                            throw f = !0, e;
                        });
                        if (f = i, !i) {
                            t("selectQuickReply rejected by chat: SEND_DROPPED");
                            return;
                        }
                        s("core.quickReply.response", {
                            requestId: e
                        });
                    }).catch((e) => {
                        if (l.aborted && !f) {
                            t("selectQuickReply cancelled: the session changed before it could be sent");
                            return;
                        }
                        c.error("sdk.quickReply.select failed:", e), t(e instanceof Error ? e.message : "selectQuickReply rejected by chat: DISPATCH_FAILED");
                    });
                    return;
                }
            case "sdk.message.send":
                {
                    let e = typeof O ? .requestId == "string" ? O.requestId : null;
                    if (!i.store.getState().session.enableProgrammaticControl) {
                        c.warn("sdk.message.send rejected: enableProgrammaticControl is off"), e && s("core.message.response", {
                            requestId: e,
                            error: aS
                        });
                        return;
                    }
                    let t = $(O ? .body);
                    if (!t) {
                        e && s("core.message.response", {
                            requestId: e,
                            error: "sendMessage rejected by chat: EMPTY_TEXT"
                        });
                        return;
                    }
                    let n = i.store.getState().liveAgent;
                    if (n.inLiveChat && n.platformName === "zendesk_liveagent") {
                        let n = Uc(i.store, s, t, {
                            requestId: e ? ? void 0,
                            origin: "programmatic"
                        });
                        e && !n && s("core.message.response", {
                            requestId: e,
                            error: "sendMessage rejected by chat: MESSAGE_TOO_LONG"
                        });
                        return;
                    }
                    let {
                        signal: r
                    } = i.lifecycle;
                    i.store.dispatch(Rn()),
                    T.set(r, (T.get(r) ? ? 0) + 1),
                    A().then(() => {
                        if (!r.aborted) return a.grantEngagement(), o();
                    }).then(() => r.aborted ? (e && s("core.message.response", {
                        requestId: e,
                        error: "sendMessage cancelled: the session changed before it could be sent"
                    }), null) : e ? a.sendProgrammaticMessage(t) : a.sendMessage(t).then(() => null)).then((t) => {
                        !e || !t || s("core.message.response", {
                            requestId: e,
                            id: t.id
                        });
                    }).catch((t) => {
                        c.error("sdk.message.send failed:", t), e && s("core.message.response", {
                            requestId: e,
                            error: t instanceof Error ? t.message : "sendMessage rejected by chat: DISPATCH_FAILED"
                        });
                    }).finally(() => {
                        let e = (T.get(r) ? ? 0) - 1;
                        e > 0 ? T.set(r, e) : T.delete(r);
                    });
                    return;
                }
            case "sdk.sessionMirror.clearAck":
                {
                    let e = $(O ? .requestId);
                    e && $e(e);
                    return;
                }
            case "sdk.sessionMirror.seed":
                {
                    let e = $(O ? .requestId);
                    e && Ke(e, O ? .seed ? ? void 0);
                    return;
                }
            case "sdk.hostCallback.error":
                {
                    let e = so($(O ? .callbackName)),
                        r = O ? .eventName,
                        a = typeof r == "string" ? r : "",
                        o = ka(e === "eventCallbacks" ? a : a.trim(), e),
                        s = `${e}|${o}`,
                        c = t.get(s) ? ? 0;
                    if (c >= 3 || n >= oS) return;
                    t.set(s, c + 1),
                    n += 1;
                    let l = Ur($(O ? .errorName)),
                        u = Dr;
                    R("host_callback_error", {
                        callbackName: e,
                        eventName: o,
                        errorName: l,
                        errorMessage: u
                    });
                    let d = /* @__PURE__ */ Error(`${e} for "${o}" threw ${l}: ${u}`);
                    d.name = "HostCallbackError";
                    let f = i.store.getState().session.handle ? ? "unknown";
                    P(d, {
                        source: "host_callback",
                        callbackName: e,
                        eventName: o,
                        errorName: l
                    }, {
                        tags: {
                            source: "host_callback",
                            callback_name: e,
                            event_name: o
                        },
                        fingerprint: [
                            "host_callback",
                            f,
                            e,
                            o,
                            l
                        ]
                    });
                    return;
                }
            case "sdk.error.report":
                {
                    let e = $(O ? .message) || "Unknown SDK error",
                        t = typeof O ? .stack == "string" ? O.stack : "",
                        n = {
                            source: "sdk"
                        },
                        i = Vx(O ? .adaErrorDetail);
                    i && (n.adaErrorDetail = i);
                    let a = Error(e);
                    t && (a.stack = t);
                    let o = i ? .type;
                    if (i && o !== void 0 && Ha.includes(o)) {
                        let e;
                        if (o === "frame.load.timeout") {
                            let t = i.frame;
                            e = et.includes(t) ? t : "unknown";
                        }
                        let t = `${o}|${e ?? ""}`,
                            s = r.get(t) ? ? 0;
                        if (s >= sS) return;
                        r.set(t, s + 1), R("sdk_startup_timeout", {
                            timeoutType: o,
                            ...e === void 0 ? {} : {
                                frame: e
                            },
                            ...typeof i.timeoutMs == "number" && Number.isFinite(i.timeoutMs) ? {
                                timeoutMs: i.timeoutMs
                            } : {}
                        }), P(a, n, {
                            tags: {
                                source: "sdk",
                                sdk_timeout_type: o,
                                ...e === void 0 ? {} : {
                                    frame: e
                                }
                            },
                            fingerprint: [
                                "{{ default }}",
                                o,
                                ...e === void 0 ? [] : [e]
                            ]
                        });
                        return;
                    }
                    P(a, n);
                    return;
                }
            default:
                c.warn("sdk-message-router: unhandled message type", {
                    type: e.type
                });
                return;
        }
    }

    function se() {
        let {
            signal: e
        } = i.lifecycle, t = a.preparePassiveSession();
        t !== w && (w = t, t.then(() => {
            e.aborted || s("core.storage.persistence", {
                mode: a.getStorageMode()
            });
        }).catch((t) => {
            e.aborted || H(t) || c.error("Passive session preparation failed:", t);
        }));
    }
    return {
        handleMessage: oe,
        onSdkMessage: j,
        startPassiveSession: se
    };
}
//#endregion
//#region ../../node_modules/react-aria/dist/private/i18n/utils.mjs
var uS = new Set([
        "Arab",
        "Syrc",
        "Samr",
        "Mand",
        "Thaa",
        "Mend",
        "Nkoo",
        "Adlm",
        "Rohg",
        "Hebr"
    ]),
    dS = new Set([
        "ae",
        "ar",
        "arc",
        "bcc",
        "bqi",
        "ckb",
        "dv",
        "fa",
        "glk",
        "he",
        "ku",
        "mzn",
        "nqo",
        "pnb",
        "ps",
        "sd",
        "ug",
        "ur",
        "yi"
    ]);

function fS(e) {
    if (Intl.Locale) {
        let t = new Intl.Locale(e).maximize(),
            n = typeof t.getTextInfo == "function" ? t.getTextInfo() : t.textInfo;
        if (n) return n.direction === "rtl";
        if (t.script) return uS.has(t.script);
    }
    let t = e.split("-")[0];
    return dS.has(t);
}
//#endregion
//#region src/dashboard-localized-text.ts
function pS({
    textByLanguage: e,
    sessionLanguage: t,
    botDefaultLanguage: n
}) {
    if (!e) return null;
    let r = new Map(Object.entries(e).map(([e, t]) => [e.trim().toLowerCase(), t])),
        i = t.trim().toLowerCase();
    for (let e of [
            i,
            i.split("-")[0],
            n.trim().toLowerCase(),
            "en"
        ]) {
        let t = r.get(e);
        if (typeof t == "string" && t) return t;
    }
    return null;
}
//#endregion
//#region src/sdk-store-watchers.ts
var mS = B("store-watchers"),
    hS = "NEW_AGENT_MESSAGE",
    gS = "AGENT_ARRIVE",
    _S = "AGENT_LEAVE",
    vS = 500 * 2;

function yS(e) {
    try {
        return fS(e) ? "rtl" : "ltr";
    } catch {
        return "ltr";
    }
}

function bS(e, t, n, r) {
    let i = er(e, t, {
        agent_name: n ? ? ""
    });
    return i === t ? r : i;
}

function xS(e = 0) {
    return {
        lastIdentityTokenConsumedChatterId: null,
        lastIdentityTokenFailureSeq: e
    };
}

function SS({
    session: e,
    cursor: t,
    sendToParent: n
}) {
    let {
        identityTokenFailureSeq: r,
        identityTokenFailureReason: i
    } = e;
    r < t.lastIdentityTokenFailureSeq ? t.lastIdentityTokenFailureSeq = r : r > t.lastIdentityTokenFailureSeq && i && (t.lastIdentityTokenFailureSeq = r, n("core.identityToken.failed", {
        reason: i
    }));
    let {
        identityTokenConsumedChatterId: a
    } = e;
    a && a !== t.lastIdentityTokenConsumedChatterId && (t.lastIdentityTokenConsumedChatterId = a, e.chatterToken && n("core.identityToken.consumed", {
        chatterToken: e.chatterToken
    }));
}

function CS(e) {
    return e === "connected" ? "connected" : e === "connecting" ? "reconnecting" : "disconnected";
}

function wS(e) {
    return new Set(Object.entries(e).filter(([, e]) => e.isTyping).map(([e]) => e));
}

function TS(e) {
    return e.sender !== "user" && Bx(e);
}

function ES(e) {
    let {
        instance: t,
        sendToParent: n
    } = e, r = [], i = !1, a = !1, o = null, s, c, l = !1, u = !1, d = [], f = 0, p = 0, m = !1, h = "toggle", g = !1;

    function _(e) {
        return {
            lastChatterToken: e.session.chatterToken,
            lastTtsMessageAppendSeq: e.chat.messageAppendSeq,
            lastEventMessageAppendSeq: e.chat.messageAppendSeq,
            lastReceivedMessageAppendSeq: e.chat.messageAppendSeq,
            emittedReceivedMessageIds: /* @__PURE__ */ new Set(),
            lastEventCaughtUpAppendSeq: e.chat.caughtUpAppendSeq,
            lastReceivedCaughtUpAppendSeq: e.chat.caughtUpAppendSeq,
            lastSentMessageAckSeq: e.chat.sentMessageAck ? .seq ? ? 0,
            lastCustomJsEventSeq: e.chat.customJsEventSeq,
            lastIntegrationCommandSeq: e.liveAgent.integrationCommandSeq,
            lastAgentsInactiveByChatterSeq: e.liveAgent.agentsInactiveByChatterSeq,
            lastActiveAgentIds: new Set(Object.entries(e.liveAgent.agents).filter(([, e]) => e.isActive).map(([e]) => e)),
            campaignShowSeq: 0,
            lastShownCampaign: null,
            lastEngagedCampaignSeq: 0,
            lastEngagedMessageId: null,
            lastTypingAgentIds: wS(e.liveAgent.agents),
            lastConnectionState: CS(e.connection.transportStatus),
            lastConversationId: e.session.conversationId,
            lastActivationProgressTick: e.activation.progressTick
        };
    }
    let v = {
            ..._(t.store.getState()),
            lastChatterToken: null,
            lastActiveAgentIds: /* @__PURE__ */ new Set()
        },
        y = null,
        b = null,
        x = t.store.getState().chat.messageAppendSeq,
        S = [],
        C = [],
        w = (e) => {
            b = null, x = e, S = [], C = [];
        },
        T = (e) => {
            S.length === 0 && C.length === 0 && e.session.chatterToken === b && (b = null, x = e.chat.messageAppendSeq);
        },
        E = (e) => {
            let {
                chatterToken: t
            } = e.session, {
                messageAppendSeq: n,
                lastAppendedMessage: r
            } = e.chat;
            if (b && t !== b && w(n), b = t, n < x && (w(n), b = t), n > x && r && TS(r)) {
                let t = {
                    message: r,
                    conversationId: e.session.conversationId
                };
                S.push(t), C.push(t);
            }
            x = n, v.lastTtsMessageAppendSeq = n;
        },
        D = (e) => e.session._chatterAnnouncementSuppressed ? (e.session.chatterToken && (y = e.session.chatterToken), E(e), !0) : y === null ? (b && e.session.chatterToken !== b && w(e.chat.messageAppendSeq), !1) : (e.session.chatterToken || w(e.chat.messageAppendSeq), !0),
        O = xS();
    k(), ee(), r.push(t.store.subscribe(() => {
        k(), ee();
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let {
            inPending: r,
            inLiveChat: d,
            queuePosition: f,
            platformName: p
        } = e.liveAgent, m = e.session.features ? ? {}, h = e.liveAgent.zendesk ? .sessionId ? ? null, g = e.liveAgent.zendesk ? .previousTags ? .join(",") ? ? null, _ = e.liveAgent.zendesk ? .reconnecting ? ? !1, y = e.liveAgent.zendesk ? .disconnected ? ? !1;
        if (r && !i && m.afmHandoffEvents && n("core.liveChat.platformEvent", {
                event: "LIVE_CHAT_PLATFORM_CONNECTING",
                payload: {
                    platform: p ? ? "unknown"
                }
            }), d && !a && (m.afmHandoffEvents && n("core.liveChat.platformEvent", {
                event: "LIVE_CHAT_PLATFORM_CONNECTED",
                payload: {
                    platform: p ? ? "unknown"
                }
            }), n("core.liveChat.started", {
                platform: p ? ? "unknown"
            })), !d && a && m.afmHandoffEvents && n("core.liveChat.platformEvent", {
                event: "LIVE_CHAT_PLATFORM_ENDED",
                payload: {
                    platform: p ? ? "unknown"
                }
            }), f !== o && f !== null && m.afmHandoffEvents && n("core.liveChat.platformEvent", {
                event: "LIVE_CHAT_QUEUE_POSITION",
                payload: {
                    queuePosition: f
                }
            }), (h !== s || g !== c) && (s = h, c = g, n("core.zd.session", {
                zdSessionId: h,
                ...g ? {
                    zdPreviousTags: g
                } : {}
            })), l && !_ && d && m.afmHandoffEvents && n("core.liveChat.platformEvent", {
                event: "LIVE_CHAT_PLATFORM_RECONNECTED",
                payload: {
                    platform: p ? ? "unknown"
                }
            }), y && !u && m.afmHandoffEvents && n("core.liveChat.platformEvent", {
                event: "LIVE_CHAT_PLATFORM_CONNECTION_FAILURE",
                payload: {
                    platform: p ? ? "unknown"
                }
            }), e.liveAgent.integrationCommandSeq > v.lastIntegrationCommandSeq && e.liveAgent.lastIntegrationCommand) {
            v.lastIntegrationCommandSeq = e.liveAgent.integrationCommandSeq;
            let t = e.liveAgent.lastIntegrationCommand;
            n("core.integration.command", t), m.afmHandoffEvents && t.integration === "zendesk" && t.action === "transcript.send" && n("core.liveChat.platformEvent", {
                event: "LIVE_CHAT_SEND_TRANSCRIPT",
                payload: {
                    platform: p ? ? "unknown"
                }
            });
        }
        i = r, a = d, o = f, l = _, u = y;
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState(),
            {
                messages: r,
                isHidden: i,
                triggerMethod: a,
                currentSurfaceId: o,
                displaySeq: s,
                displayed: c,
                clearSeq: l
            } = e.proactive,
            u = r !== d,
            m = l !== p;
        u && (d = r, r.length > 0 && !i && o !== null && n("core.proactive.show", {
            messages: r,
            duration: e.proactive.messageDuration,
            surfaceId: o,
            ...a ? {
                triggerMethod: a,
                displayDelay: e.proactive.messageDisplayDelay,
                frequency: e.proactive.messageFrequency ? ? "session",
                ...e.proactive.intentId === null ? {} : {
                    intentId: e.proactive.intentId
                }
            } : {}
        })), s !== f && (f = s, c && (v.lastShownCampaign = {
            key: c.campaignKey,
            seq: ++v.campaignShowSeq
        })), m && (p = l, v.lastShownCampaign = null);
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let {
            isRecording: r,
            mode: i,
            shouldUseTTS: a,
            ttsEnabled: o
        } = e.voice, s = e.session.alertSoundEnabled, {
            messageAppendSeq: c,
            lastAppendedMessage: l
        } = e.chat;
        r !== m && (m = r, n(r ? "core.voice.start" : "core.voice.stop", {})), i !== h && (h = i, n("core.voice.setMode", {
            mode: i
        })), c > v.lastTtsMessageAppendSeq ? (v.lastTtsMessageAppendSeq = c, a && o && s && l ? .type === "text" && l ? .sender === "bot" && l ? .body && n("core.tts.speak", {
            text: l.body
        })) : c < v.lastTtsMessageAppendSeq && (v.lastTtsMessageAppendSeq = c), a && !g ? (g = !0, t.store.dispatch(is())) : a || (g = !1);
    }));

    function ee() {
        let e = t.store.getState(),
            {
                chatterId: r,
                chatterToken: i
            } = e.session;
        if (e.session._chatterAnnouncementSuppressed) {
            i && (y = i);
            return;
        }
        i && i !== v.lastChatterToken && (v.lastChatterToken = i, n("core.chatter.created", {
            chatterId: r,
            chatterToken: i
        })), i && (y = null);
    }

    function k() {
        SS({
            session: t.store.getState().session,
            cursor: O,
            sendToParent: n
        });
    }
    r.push(t.store.subscribe(() => {
        let e = t.store.getState().activation.progressTick;
        if (e === v.lastActivationProgressTick) return;
        v.lastActivationProgressTick = e;
        let {
            waitingForVisible: r
        } = t.store.getState().activation;
        n("core.event.publish", {
            key: "ada.activation.progress",
            data: {
                waitingForVisible: r
            }
        });
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let r = CS(e.connection.transportStatus);
        r !== v.lastConnectionState && (v.lastConnectionState = r, n("core.event.publish", {
            key: "ada:connection:change",
            data: {
                state: r
            }
        }));
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let r = e.session.conversationId;
        r !== v.lastConversationId && (v.lastConversationId && r && n("core.event.publish", {
            key: "ada:conversation:change",
            data: {
                id: r
            }
        }), v.lastConversationId = r);
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let r = wS(e.liveAgent.agents);
        for (let e of r) v.lastTypingAgentIds.has(e) || n("core.event.publish", {
            key: "ada:typing:start",
            data: {
                agentId: e
            }
        });
        for (let e of v.lastTypingAgentIds) r.has(e) || n("core.event.publish", {
            key: "ada:typing:stop",
            data: {
                agentId: e
            }
        });
        v.lastTypingAgentIds = r;
    }));
    let A = () => {},
        j = () => {
            let e = t.store.getState();
            !e.session.isConfigured || !e.session.hasHydratedClientConfig || (n("core.rollout", {
                value: e.session.rollout
            }), A());
        };
    A = t.store.subscribe(j), r.push(A), j();
    let te = !1,
        ne = () => {},
        M = () => {
            let {
                session: e
            } = t.store.getState();
            if (!e.hasHydratedClientConfig || te) return;
            te = !0, ne(), Qa(e) && n("core.event.publish", {
                key: "ada.branding.headerTextColorWithheld"
            });
            let r = oa(e.hostBranding, e.clientDefaultLanguage);
            r.length !== 0 && n("core.event.publish", {
                key: "ada.branding.dropped",
                data: {
                    fields: r,
                    defaultLanguage: e.clientDefaultLanguage
                }
            });
        };
    ne = t.store.subscribe(M), r.push(ne), M();
    let re = (e, t) => {
            n("core.event.publish", {
                key: "ada:conversation:message",
                data: {
                    author: e.sender,
                    message_id: e.id,
                    conversation_id: t
                }
            });
        },
        ie = (e, t, r) => {
            if (re(e, t), e.sender === "agent" && e.type === "text" && e.body) {
                let i = Fx(r);
                n("frame.notification.create", {
                    title: bS(r.localization.translations, hS, i ? .name, i ? .name ? `New message from ${i.name}` : "New message"),
                    body: e.body,
                    ...i ? .avatarUrl ? {
                        icon: i.avatarUrl
                    } : {},
                    ...t ? {
                        conversationId: t
                    } : {},
                    messageId : e.id
                });
            }
        };
    r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let {
            messageAppendSeq: n,
            lastAppendedMessage: r,
            caughtUpAppendSeq: i
        } = e.chat, a = e.session.conversationId;
        if (S.length > 0) {
            for (let t of S) ie(t.message, t.conversationId, e);
            S = [], v.lastEventMessageAppendSeq = n;
        } else n > v.lastEventMessageAppendSeq ? (v.lastEventMessageAppendSeq = n, r && TS(r) && ie(r, a, e)) : n < v.lastEventMessageAppendSeq && (v.lastEventMessageAppendSeq = n);
        if (i > v.lastEventCaughtUpAppendSeq) {
            v.lastEventCaughtUpAppendSeq = i;
            for (let t of e.chat.lastCaughtUpMessages) TS(t) && re(t, a);
        } else i < v.lastEventCaughtUpAppendSeq && (v.lastEventCaughtUpAppendSeq = i);
    }));
    let N = (e, t) => {
        let r = v.emittedReceivedMessageIds;
        if (r.has(e.id)) {
            r.delete(e.id), r.add(e.id);
            return;
        }
        for (r.add(e.id); r.size > vS;) {
            let e = r.values().next().value;
            if (e === void 0) break;
            r.delete(e);
        }
        n("core.event.publish", {
            key: "ada:message:received",
            data: {
                message: Rx(e, t)
            }
        });
    };
    r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let {
            messageAppendSeq: n,
            lastAppendedMessage: r,
            caughtUpAppendSeq: i
        } = e.chat;
        if (!e.session.enableProgrammaticControl) {
            C = [], v.lastReceivedMessageAppendSeq = n, v.lastReceivedCaughtUpAppendSeq = i, T(e);
            return;
        }
        if (C.length > 0) {
            for (let t of C) N(t.message, e);
            C = [], v.lastReceivedMessageAppendSeq = n;
        } else n > v.lastReceivedMessageAppendSeq ? (v.lastReceivedMessageAppendSeq = n, r && TS(r) && N(r, e)) : n < v.lastReceivedMessageAppendSeq && (v.lastReceivedMessageAppendSeq = n);
        if (i > v.lastReceivedCaughtUpAppendSeq) {
            v.lastReceivedCaughtUpAppendSeq = i;
            for (let t of e.chat.lastCaughtUpMessages) TS(t) && N(t, e);
        } else i < v.lastReceivedCaughtUpAppendSeq && (v.lastReceivedCaughtUpAppendSeq = i);
        T(e);
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let r = e.chat.sentMessageAck,
            i = r ? .seq ? ? 0;
        if (i === v.lastSentMessageAckSeq) return;
        if (i < v.lastSentMessageAckSeq) {
            v.lastSentMessageAckSeq = i;
            return;
        }
        if (v.lastSentMessageAckSeq = i, !r ? .id) return;
        let a = e.chat.messages.find((e) => e.id === r.id || e.clientKey === r.id || e.tempMessageUuid === r.id);
        !a || a.sender !== "user" || !Bx(a) || (v.lastShownCampaign && v.lastShownCampaign.seq > v.lastEngagedCampaignSeq && r.id !== v.lastEngagedMessageId && (v.lastEngagedCampaignSeq = v.lastShownCampaign.seq, v.lastEngagedMessageId = r.id, n("core.event.publish", {
            key: "ada:campaigns:engaged",
            data: {
                campaignKey: v.lastShownCampaign.key
            }
        })), e.session.enableProgrammaticControl && n("core.event.publish", {
            key: "ada:message:sent",
            data: {
                message: r.eventMessage ? ? Rx(a, e)
            }
        }));
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let {
            customJsEventSeq: r,
            customJsEventPayload: i
        } = e.chat;
        r > v.lastCustomJsEventSeq ? (v.lastCustomJsEventSeq = r, n("core.customJavascript", {
            payload: i
        })) : r < v.lastCustomJsEventSeq && (v.lastCustomJsEventSeq = r);
    })), r.push(t.store.subscribe(() => {
        let e = t.store.getState();
        if (D(e)) return;
        let r = e.liveAgent.agents,
            i = new Set(Object.entries(r).filter(([, e]) => e.isActive).map(([e]) => e)),
            a = e.session.conversationId ? ? void 0;
        for (let t of i)
            if (!v.lastActiveAgentIds.has(t) && !e.liveAgent.restoredAgentIds[t]) {
                n("core.event.publish", {
                    key: "ada:agent:joined",
                    data: {
                        conversation_id: a
                    }
                });
                let i = r[t];
                if (i ? .isColleague) continue;
                n("frame.notification.create", {
                    title: bS(e.localization.translations, gS, i ? .name, i ? .name ? `${i.name} joined the chat` : "An agent joined the chat"),
                    ...i ? .imageUrl ? {
                        icon: i.imageUrl
                    } : {},
                    ...a ? {
                        conversationId: a
                    } : {}
                });
            }
        let o = e.liveAgent.agentsInactiveByChatterSeq !== v.lastAgentsInactiveByChatterSeq;
        for (let t of v.lastActiveAgentIds)
            if (!i.has(t)) {
                if (n("core.event.publish", {
                        key: "ada:agent:left",
                        data: {
                            conversation_id: a
                        }
                    }), o) continue;
                let i = r[t];
                if (i ? .isColleague) continue;
                n("frame.notification.create", {
                    title: bS(e.localization.translations, _S, i ? .name, i ? .name ? `${i.name} left the chat` : "An agent left the chat"),
                    ...i ? .imageUrl ? {
                        icon: i.imageUrl
                    } : {},
                    ...a ? {
                        conversationId: a
                    } : {}
                });
            }
        v.lastActiveAgentIds = i, v.lastAgentsInactiveByChatterSeq = e.liveAgent.agentsInactiveByChatterSeq;
    }));

    function ae(e) {
        let n = t.store.getState(),
            r = v.emittedReceivedMessageIds;
        v = _(n), e && (v.emittedReceivedMessageIds = r), O.lastIdentityTokenConsumedChatterId = n.session.identityTokenConsumedChatterId, O.lastIdentityTokenFailureSeq = n.session.identityTokenFailureSeq;
    }

    function oe() {
        return v.lastChatterToken;
    }

    function se() {
        let e = r.splice(0),
            t = [];
        for (let n of e) try {
            n();
        } catch (e) {
            t.push(e);
        }
        t.length > 0 && mS.error(`store watcher teardown: ${t.length} unsubscriber(s) threw`, t);
    }
    let ce = null,
        le = null,
        ue = null,
        de = null;

    function fe() {
        let {
            localization: e,
            session: r
        } = t.store.getState();
        if (e === ce && r === le || !e.isLoaded || e.isLoading || !r.hasHydratedClientConfig) return;
        ce = e, le = r;
        let i = (Co(Li(r) ? .aiAgentName, r.language, r.clientDefaultLanguage) ? ? pS({
                textByLanguage: r.botNameTranslations,
                sessionLanguage: e.language,
                botDefaultLanguage: r.clientDefaultLanguage
            }) ? ? r.botName) ? .trim() || null,
            a = i ? "main_title" : "default_title",
            o = e.fallbackKeys.includes(a) ? "en" : e.language,
            s = er(e.translations, a, {
                client_name: i ? ? ""
            });
        s === a || s === ue && o === de || (ue = s, de = o, n("core.host.documentTitle.set", {
            title: s,
            language: o,
            dir: yS(o)
        }));
    }
    fe();
    let pe = !1,
        me = !0,
        he = t.store.subscribe(() => {
            pe || (pe = !0, queueMicrotask(() => {
                pe = !1, me && fe();
            }));
        });
    r.push(() => {
        me = !1, he();
    });

    function ge(e) {
        let i = t.store.getState().session.language,
            a = e() ? .button ? ? null;
        r.push(t.store.subscribe(() => {
            let {
                language: r,
                hasHydratedClientConfig: o
            } = t.store.getState().session;
            if (!o || r === i) return;
            let s = e();
            if (!s) return;
            i = r;
            let c = s.button ? ? null;
            c && (c ? .text === a ? .text && c ? .textLanguage === a ? .textLanguage || (a = c, n("core.button.config", {
                button: c
            })));
        }));
    }
    return {
        destroy: se,
        getLastChatterToken: oe,
        resetRuntimeSessionTracking: ae,
        watchButtonConfig: ge
    };
}
//#endregion
export {
    nc as AppBridge, oc as CUSTOM_APP_ALLOWLIST_UNAVAILABLE_REASON, ac as CUSTOM_APP_ORIGIN_NOT_ALLOWLISTED_REASON, Px as CoreOrchestrator, rc as CustomAppMountError, ho as FEATURE_FLAG_DEFINITIONS, Ut as HANDOFF_INTEGRATION_PREFIX, ye as INFLUX_GLASS_NAME, Ue as LIVE_CHAT_PENDING_STATE, ft as LIVE_CHAT_STATE, Gh as MockTransport, dg as PusherTransport, an as SALESFORCE_GLASS_NAME, us as ZAW_LIVEAGENT_NAME, x as ZENDESK_GLASS_NAME, In as ZENDESK_SUPPORT_LIVEAGENT_NAME, l as addBreadcrumb, R as addRUMAction, Jn as alertSoundChanged, Ev as bootstrapCoreFrame, Os as buildAppFrameUrl, On as bytesToMB, P as captureException, zt as captureMessage, oo as channelConnected, Hr as channelDisconnected, vn as chatCleared, le as chatErrorCleared, M as chatErrorSet, vo as chatterCreated, we as clearLocaleCache, kr as configReceived, aa as connectionReset, lo as conversationStarted, G as coreApi, bs as createActivationOutageRaiser, Dl as createCoreAppEventRouter, lS as createCoreSdkMessageRouter, ES as createCoreSdkStoreWatchers, Ba as createCoreStore, xS as createIdentityTokenLifecycleCursor, B as createLogger, ob as createOutageMonitor, Qb as createZendeskChatAuthRuntime, Tt as csatAutoTriggerSet, Vt as csatBotSettingsLoaded, nn as csatIsOpenSet, y as csatSubmitErrorSet, Pn as csatSubmitSucceeded, ca as deviceNotificationsChanged, To as deviceTokenSet, SS as emitIdentityTokenLifecycleEvents, Hn as fileTransferUpdated, De as fileUploadCompleted, it as fileUploadErrorCleared, U as fileUploadFailed, Xe as fileUploadReset, rr as fileUploadStarted, Gt as followUpResponseIdSet, Zn as getAppVisibleFeatureFlags, pr as getFeatureFlagDefaults, xe as greetingConfigured, Ge as greetingHeldForProactive, mt as greetingHoldCleared, sn as greetingHoldReleased, fs as greetingMarkedExplicitlyRequested, C as greetingMarkedSent, Rn as greetingMarkedSkipped, An as greetingReset, ke as greetingSkipCleared, fv as initCore, Rm as initFeatureFlags, ze as initMonitoring, Ye as interactiveBlockAnswerReverted, tr as interactiveBlockAnswered, Qt as isFeatureFlagKey, Yn as isFileUploadEnabled, dr as isFileUploadVisible, Xt as isHandoffIntegrationPlatform, ct as isMonitoringEnabled, Jg as isPermanentPublicClientStartupError, a as isRecognizedLiveAgentPlatform, qg as isStartupRequestFailure, Gb as isZendeskChatAuthEnabled, ma as languageChanged, ri as liveAgentAgentInactive, mo as liveAgentAgentRemoved, ya as liveAgentAgentTypingSet, Za as liveAgentAgentUpserted, Ii as liveAgentAgentsInactive, Tr as liveAgentConversationEndedByServer, Da as liveAgentConversationEndedByUserSet, ao as liveAgentConversationStateChanged, xo as liveAgentHandoffEventReceived, Yr as liveAgentHandoffRetryRequested, Fa as liveAgentInactiveRetryPendingSet, fa as liveAgentInjectionCandidateCleared, Di as liveAgentInjectionPostedPastEndedConversation, yi as liveAgentIntegrationCommandRequested, gr as liveAgentPlatformUpdated, ko as liveAgentQueueCancelPendingSet, $o as liveAgentQueuePositionUpdated, Nr as liveAgentQueueWaitUpdated, Go as liveAgentReset, un as liveAgentRetryDialogHidden, E as liveAgentRetryDialogPendingSet, tt as loadLocale, Ua as loadTranslations, r as messageDeliveryFailed, _o as messageReceived, eo as messageRetryStarted, zi as messageSendAcknowledged, Aa as messageSent, Lr as metaFieldsUpdated, uc as mountAppFrame, s as normalizeFeatureFlagChange, ii as normalizeFeatureFlags, ae as outageReset, h as outageTypeSet, wo as playbookStepExecutingSet, Be as proactiveMessagesHidden, lt as proactiveMessagesReceived, tn as proactiveReset, Is as selectDerivedDisplayState, V as sendingFailed, Ai as sendingStarted, Vo as sensitiveMetaFieldsUpdated, xn as sessionIdSet, fe as sessionReset, t as setSessionMirrorParentSink, N as smsNotificationsChanged, er as t, zm as teardownFeatureFlags, m as transcriptDownloadRequestFailed, qi as transcriptDownloadRequestStarted, xt as transcriptDownloadRequestSucceeded, Wt as transcriptEmailRequestFailed, be as transcriptEmailRequestStarted, We as transcriptEmailRequestSucceeded, St as translationsLoaded, Ia as transportStatusChanged, pa as transportTeardownStarted, Ir as typingStarted, Jo as typingStopped, _n as validateLiveAgentFileUpload, is as voiceShouldUseTTSCleared, ce as zendeskMessagingStatePatched, Mt as zendeskStatePatched
};

//# sourceMappingURL=index.js.map