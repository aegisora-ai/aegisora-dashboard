var e;

function t(e) {
    return o(e).segments_count;
}

function n(e) {
    o(e).segments_count += 1;
}

function r(e) {
    o(e).records_count += 1;
}

function i(e, t) {
    o(e).segments_total_raw_size += t;
}

function a(t) {
    return e ? .get(t);
}

function o(t) {
    e || = /* @__PURE__ */ new Map();
    let n;
    return e.has(t) ? n = e.get(t) : (n = {
        records_count: 0,
        segments_count: 0,
        segments_total_raw_size: 0
    }, e.set(t, n), e.size > 1e3 && s()), n;
}

function s() {
    if (!e) return;
    let t = e.keys().next().value;
    t && e.delete(t);
}
//#endregion
export {
    t as a, a as i, n, i as r, r as t
};

//# sourceMappingURL=replayStats-BN_uKRUf.js.map