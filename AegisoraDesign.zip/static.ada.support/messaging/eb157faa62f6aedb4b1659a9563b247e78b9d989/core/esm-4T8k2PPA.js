//#region ../../node_modules/@datadog/browser-core/esm/tools/display.js
var e = {
        log: "log",
        debug: "debug",
        info: "info",
        warn: "warn",
        error: "error"
    },
    t = console,
    n = {};
Object.keys(e).forEach((e) => {
    n[e] = t[e];
});
var r = "Datadog Browser SDK:",
    i = {
        debug: n.debug.bind(t, r),
        log: n.log.bind(t, r),
        info: n.info.bind(t, r),
        warn: n.warn.bind(t, r),
        error: n.error.bind(t, r)
    },
    a = "https://docs.datadoghq.com",
    o = `${a}/real_user_monitoring/browser/troubleshooting`,
    s = "More details:";
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/catchUserErrors.js
function c(e, t) {
    return (...n) => {
        try {
            return e(...n);
        } catch (e) {
            i.error(t, e);
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/numberUtils.js
function l(e) {
    return e !== 0 && Math.random() * 100 <= e;
}

function u(e, t) {
    return +e.toFixed(t);
}

function d(e) {
    return f(e) && e >= 0 && e <= 100;
}

function f(e) {
    return typeof e == "number";
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/objectUtils.js
function p(e) {
    try {
        return JSON.parse(e);
    } catch {}
}

function m(e) {
    return { ...e
    };
}

function h(e, t) {
    return Object.keys(e).some((n) => e[n] === t);
}

function g(e) {
    return Object.keys(e).length === 0;
}

function _(e, t) {
    let n = {};
    for (let r of Object.keys(e)) n[r] = t(e[r]);
    return n;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/globalObject.js
function v() {
    if (typeof globalThis == "object") return globalThis;
    Object.defineProperty(Object.prototype, "_dd_temp_", {
        get() {
            return this;
        },
        configurable: !0
    });
    let e = _dd_temp_;
    return delete Object.prototype._dd_temp_, typeof e != "object" && (e = typeof self == "object" ? self : typeof window == "object" ? window : {}), e;
}
var y = v(),
    b = "WorkerGlobalScope" in y;
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/getZoneJsOriginalValue.js
function x(e, t) {
    let n = v(),
        r;
    return n.Zone && typeof n.Zone.__symbol__ == "function" && (r = e[n.Zone.__symbol__(t)]), r || = e[t], r;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/monitor.js
var S, ee = !1;

function te(e) {
    S = e;
}

function ne(e) {
    ee = e;
}

function re(e, t, n) {
    let r = n.value;
    n.value = function(...e) {
        return (S ? C(r) : r).apply(this, e);
    };
}

function C(e) {
    return function(...t) {
        return w(e, this, t);
    };
}

function w(e, t, n) {
    try {
        return e.apply(t, n);
    } catch (e) {
        ie(e);
    }
}

function ie(e) {
    if (ae(e), S) try {
        S(e);
    } catch (e) {
        ae(e);
    }
}

function ae(...e) {
    ee && i.error("[MONITOR]", ...e);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/timer.js
function T(e, t) {
    return x(v(), "setTimeout")(C(e), t);
}

function E(e) {
    x(v(), "clearTimeout")(e);
}

function oe(e, t) {
    return x(v(), "setInterval")(C(e), t);
}

function se(e) {
    x(v(), "clearInterval")(e);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/queueMicrotask.js
function ce(e) {
    let t = y.queueMicrotask;
    typeof t == "function" ? t(C(e)) : Promise.resolve().then(C(e));
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/observable.js
var D = class {
    constructor(e) {
        this.onFirstSubscribe = e, this.observers = [];
    }
    subscribe(e) {
        return this.addObserver(e), {
            unsubscribe: () => this.removeObserver(e)
        };
    }
    notify(e) {
        this.observers.forEach((t) => t(e));
    }
    addObserver(e) {
        this.observers.push(e), this.observers.length === 1 && this.onFirstSubscribe && (this.onLastUnsubscribe = this.onFirstSubscribe(this) || void 0);
    }
    removeObserver(e) {
        this.observers = this.observers.filter((t) => e !== t), !this.observers.length && this.onLastUnsubscribe && this.onLastUnsubscribe();
    }
};

function le(...e) {
    return new D((t) => {
        let n = e.map((e) => e.subscribe((e) => t.notify(e)));
        return () => n.forEach((e) => e.unsubscribe());
    });
}
var ue = class extends D {
        constructor(e) {
            super(), this.maxBufferSize = e, this.buffer = [];
        }
        notify(e) {
            this.buffer.push(e), this.buffer.length > this.maxBufferSize && this.buffer.shift(), super.notify(e);
        }
        subscribe(e) {
            let t = !1;
            return ce(() => {
                for (let n of this.buffer) {
                    if (t) return;
                    e(n);
                }
                t || this.addObserver(e);
            }), {
                unsubscribe: () => {
                    t = !0, this.removeObserver(e);
                }
            };
        }
        unbuffer() {
            ce(() => {
                this.maxBufferSize = this.buffer.length = 0;
            });
        }
    },
    O = 1e3,
    k = 60 * O,
    de = 60 * k,
    fe = 24 * de * 365;

function pe(e) {
    return {
        relative: e,
        timeStamp: he(e)
    };
}

function me(e) {
    return {
        relative: ye(e),
        timeStamp: e
    };
}

function he(e) {
    let t = j() - performance.now();
    return t > Ce() ? Math.round(ve(t, e)) : be(e);
}

function ge() {
    return Math.round(j() - ve(Ce(), performance.now()));
}

function A(e) {
    return f(e) ? u(e * 1e6, 0) : e;
}

function j() {
    return ( /* @__PURE__ */ new Date()).getTime();
}

function M() {
    return j();
}

function N() {
    return performance.now();
}

function P() {
    return {
        relative: N(),
        timeStamp: M()
    };
}

function _e() {
    return {
        relative: 0,
        timeStamp: Ce()
    };
}

function F(e, t) {
    return t - e;
}

function ve(e, t) {
    return e + t;
}

function ye(e) {
    return e - Ce();
}

function be(e) {
    return Math.round(ve(Ce(), e));
}

function xe(e) {
    return e < fe;
}
var Se;

function Ce() {
    return Se === void 0 && (Se = performance.timing ? .navigationStart ? ? performance.timeOrigin), Se;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/functionUtils.js
function we(e, t, n) {
    let r = n && n.leading !== void 0 ? n.leading : !0,
        i = n && n.trailing !== void 0 ? n.trailing : !0,
        a = !1,
        o, s;
    return {
        throttled: (...n) => {
            if (a) {
                o = n;
                return;
            }
            r ? e(...n) : o = n, a = !0, s = T(() => {
                i && o && e(...o), a = !1, o = void 0;
            }, t);
        },
        cancel: () => {
            E(s), a = !1, o = void 0;
        }
    };
}

function I() {}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/stringUtils.js
function L(e) {
    return e ? (parseInt(e, 10) ^ Math.random() * 16 >> parseInt(e, 10) / 4).toString(16) : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, L);
}
var Te = /(\S+?)\s*=\s*(.+?)(?:;|$)/g;

function Ee(e, t) {
    for (Te.lastIndex = 0;;) {
        let n = Te.exec(e);
        if (n) {
            if (n[1] === t) return n[2];
        } else break;
    }
}

function De(e) {
    let t = /* @__PURE__ */ new Map();
    for (Te.lastIndex = 0;;) {
        let n = Te.exec(e);
        if (n) {
            let e = n[1],
                r = n[2];
            t.has(e) ? t.get(e).push(r) : t.set(e, [r]);
        } else break;
    }
    return t;
}

function Oe(e) {
    let t = /* @__PURE__ */ new Map();
    for (Te.lastIndex = 0;;) {
        let n = Te.exec(e);
        if (n) t.set(n[1], n[2]);
        else break;
    }
    return t;
}

function ke(e, t, n = "") {
    let r = e.charCodeAt(t - 1),
        i = r >= 55296 && r <= 56319 ? t + 1 : t;
    return e.length <= i ? e : `${e.slice(0, i)}${n}`;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/browserDetection.js
function Ae() {
    return Ne() === 0;
}

function je() {
    return Ne() === 1;
}
var Me;

function Ne() {
    return Me ? ? = Pe();
}

function Pe(e = window) {
    let t = e.navigator.userAgent;
    return e.chrome || /HeadlessChrome/.test(t) ? 0 : e.navigator.vendor ? .indexOf("Apple") === 0 || /safari/i.test(t) && !/chrome|android/i.test(t) ? 1 : 2;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/urlPolyfill.js
function Fe(e) {
    return Re(e, location.href).href;
}

function Ie(e) {
    try {
        return !!Re(e);
    } catch {
        return !1;
    }
}

function Le(e) {
    let t = Re(e).pathname;
    return t[0] === "/" ? t : `/${t}`;
}

function Re(e, t) {
    let {
        URL: n
    } = Be();
    try {
        return t === void 0 ? new n(e) : new n(e, t);
    } catch (e) {
        throw Error(`Failed to construct URL: ${String(e)}`);
    }
}
var ze;

function Be() {
    if (!ze) {
        let e, t;
        try {
            e = document.createElement("iframe"), e.style.display = "none", document.body.appendChild(e), t = e.contentWindow;
        } catch {
            t = y;
        }
        ze = {
            URL: t.URL
        }, e ? .remove();
    }
    return ze;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/browser/cookie.js
function Ve(e, t, n = 0, r) {
    let i = /* @__PURE__ */ new Date();
    i.setTime(i.getTime() + n);
    let a = `expires=${i.toUTCString()}`,
        o = r && r.crossSite ? "none" : "strict",
        s = r && r.domain ? `;domain=${r.domain}` : "",
        c = r && r.secure ? ";secure" : "",
        l = r && r.partitioned ? ";partitioned" : "";
    document.cookie = `${e}=${t};${a};path=/;samesite=${o}${s}${c}${l}`;
}

function He(e) {
    return Ee(document.cookie, e);
}

function Ue(e) {
    return De(document.cookie).get(e) || [];
}
var We;

function Ge(e) {
    return We || = Oe(document.cookie), We.get(e);
}

function Ke(e, t) {
    Ve(e, "", 0, t);
}

function qe(e) {
    if (document.cookie === void 0 || document.cookie === null) return !1;
    try {
        let t = `dd_cookie_test_${L()}`,
            n = "test";
        Ve(t, n, k, e);
        let r = He(t) === n;
        return Ke(t, e), r;
    } catch (e) {
        return i.error(e), !1;
    }
}
var Je;

function Ye(e = location.hostname, t = document.referrer) {
    if (Je === void 0) {
        let n = Xe(e, t);
        if (n) {
            let e = `dd_site_test_${L()}`,
                t = n.split("."),
                r = t.pop();
            for (; t.length && !He(e);) r = `${t.pop()}.${r}`, Ve(e, "test", O, {
                domain: r
            });
            Ke(e, {
                domain: r
            }), Je = r;
        }
    }
    return Je;
}

function Xe(e, t) {
    try {
        return e || Re(t).hostname;
    } catch {}
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/session/storeStrategies/sessionStoreStrategy.js
var Ze = "_dd_s";
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/polyfills.js
function Qe(e, t) {
    for (let n = e.length - 1; n >= 0; --n) {
        let r = e[n];
        if (t(r, n, e)) return r;
    }
}

function $e(e) {
    return Object.values(e);
}

function et(e) {
    return Object.entries(e);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/session/sessionConstants.js
var tt = 4 * de,
    nt = 15 * k,
    rt = fe,
    R = {
        COOKIE: "cookie",
        MEMORY: "memory",
        LOCAL_STORAGE: "local-storage"
    },
    it = /^([a-zA-Z]+)=([a-z0-9-]+)$/;

function at(e) {
    return !!e && (e.indexOf("&") !== -1 || it.test(e));
}

function ot(e, t) {
    let n = {
        isExpired: "1"
    };
    return t.trackAnonymousUser && e ? .anonymousId && (n.anonymousId = e ? .anonymousId), n;
}

function st(e) {
    return g(e);
}

function ct(e) {
    return !st(e);
}

function lt(e) {
    return e.isExpired !== void 0 || !ut(e);
}

function ut(e) {
    return (e.created === void 0 || j() - Number(e.created) < tt) && (e.expire === void 0 || j() < Number(e.expire));
}

function dt(e) {
    e.expire = String(j() + nt);
}

function ft(e) {
    return et(e).map(([e, t]) => e === "anonymousId" ? `aid=${t}` : `${e}=${t}`).join("&");
}

function pt(e) {
    let t = {};
    return at(e) && e.split("&").forEach((e) => {
        let n = it.exec(e);
        if (n !== null) {
            let [, e, r] = n;
            e === "aid" ? t.anonymousId = r : t[e] = r;
        }
    }), t;
}
var mt = "_dd_r",
    ht = "_dd_l",
    gt = "logs";

function _t(e) {
    if (!Ge("_dd_s")) {
        let t = Ge("_dd"),
            n = Ge(mt),
            r = Ge(ht),
            i = {};
        t && (i.id = t), r && /^[01]$/.test(r) && (i[gt] = r), n && /^[012]$/.test(n) && (i.rum = n), ct(i) && (dt(i), e.persistSession(i));
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/session/storeStrategies/sessionInCookie.js
var vt = 0;

function yt(e) {
    let t = Ct(e);
    return t && qe(t) ? {
        type: R.COOKIE,
        cookieOptions: t
    } : void 0;
}

function bt(e, t) {
    let n = {
        isLockEnabled: Ae(),
        persistSession: (n) => xt(t, e, n, nt),
        retrieveSession: () => St(t, e),
        expireSession: (n) => xt(t, e, ot(n, e), tt)
    };
    return _t(n), n;
}

function xt(e, t, n, r) {
    let i = ft(n);
    t.betaEncodeCookieOptions && (i = ft({
        ...n,
        ...g(n) ? {} : {
            c: wt(e)
        }
    })), Ve(Ze, i, t.trackAnonymousUser ? rt : r, e);
}

function St(e, t) {
    return t.betaEncodeCookieOptions ? Tt(e) : pt(He(Ze));
}

function Ct(e) {
    let t = {};
    if (t.secure = !!e.useSecureSessionCookie || !!e.usePartitionedCrossSiteSessionCookie, t.crossSite = !!e.usePartitionedCrossSiteSessionCookie, t.partitioned = !!e.usePartitionedCrossSiteSessionCookie, e.trackSessionAcrossSubdomains) {
        let e = Ye();
        if (!e) return;
        t.domain = e;
    }
    return t;
}

function wt(e) {
    let t = e.domain ? e.domain.split(".").length - 1 : 0,
        n = 0;
    return n |= vt << 5, n |= t << 1, n |= e.crossSite ? 1 : 0, n.toString(16);
}

function Tt(e) {
    let t = Ue(Ze),
        n = wt(e),
        r;
    for (let e of t.reverse())
        if (r = pt(e), r.c === n) break;
    return r == null || delete r.c, r ? ? {};
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/session/storeStrategies/sessionInLocalStorage.js
var Et = "_dd_test_";

function Dt() {
    try {
        let e = L(),
            t = `${Et}${e}`;
        localStorage.setItem(t, e);
        let n = localStorage.getItem(t);
        return localStorage.removeItem(t), e === n ? {
            type: R.LOCAL_STORAGE
        } : void 0;
    } catch {
        return;
    }
}

function Ot(e) {
    return {
        isLockEnabled: !1,
        persistSession: kt,
        retrieveSession: At,
        expireSession: (t) => jt(t, e)
    };
}

function kt(e) {
    localStorage.setItem(Ze, ft(e));
}

function At() {
    return pt(localStorage.getItem(Ze));
}

function jt(e, t) {
    kt(ot(e, t));
}
var Mt = O,
    Nt = "--",
    Pt = [],
    Ft;

function It(e, t, n = 0) {
    var r;
    let {
        isLockEnabled: i,
        persistSession: a,
        expireSession: o
    } = t, s = (e) => a({
        ...e,
        lock: l
    }), c = () => {
        let {
            lock: e,
            ...n
        } = t.retrieveSession();
        return {
            session: n,
            lock: e && !Bt(e) ? e : void 0
        };
    };
    if (Ft || = e, e !== Ft) {
        Pt.push(e);
        return;
    }
    if (i && n >= 100) {
        Rt(t);
        return;
    }
    let l, u = c();
    if (i) {
        if (u.lock) {
            Lt(e, t, n);
            return;
        }
        if (l = zt(), s(u.session), u = c(), u.lock !== l) {
            Lt(e, t, n);
            return;
        }
    }
    let d = e.process(u.session);
    if (i && (u = c(), u.lock !== l)) {
        Lt(e, t, n);
        return;
    }
    if (d && (lt(d) ? o(d) : (dt(d), i ? s(d) : a(d))), i && !(d && lt(d))) {
        if (u = c(), u.lock !== l) {
            Lt(e, t, n);
            return;
        }
        a(u.session), d = u.session;
    }
    (r = e.after) == null || r.call(e, d || u.session), Rt(t);
}

function Lt(e, t, n) {
    T(() => {
        It(e, t, n + 1);
    }, 10);
}

function Rt(e) {
    Ft = void 0;
    let t = Pt.shift();
    t && It(t, e);
}

function zt() {
    return L() + Nt + M();
}

function Bt(e) {
    let [, t] = e.split(Nt);
    return !t || F(Number(t), M()) > Mt;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/session/storeStrategies/sessionInMemory.js
var Vt = "_DD_SESSION";

function Ht() {
    return {
        type: R.MEMORY
    };
}

function Ut(e) {
    return {
        expireSession: (t) => Kt(t, e),
        isLockEnabled: !1,
        persistSession: Gt,
        retrieveSession: Wt
    };
}

function Wt() {
    let e = v();
    return e._DD_SESSION || (e[Vt] = {}), m(e[Vt]);
}

function Gt(e) {
    let t = v();
    t[Vt] = m(e);
}

function Kt(e, t) {
    Gt(ot(e, t));
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/session/sessionStore.js
var qt = O;

function Jt(e) {
    let {
        sessionPersistence: t
    } = e, n = Yt(t, e);
    for (let t of n) {
        let n = Xt(t, e);
        if (n !== void 0) return n;
    }
}

function Yt(e, t) {
    return Array.isArray(e) ? e : e === void 0 ? t.allowFallbackToLocalStorage ? [R.COOKIE, R.LOCAL_STORAGE] : [R.COOKIE] : [e];
}

function Xt(e, t) {
    switch (e) {
        case R.COOKIE:
            return yt(t);
        case R.LOCAL_STORAGE:
            return Dt();
        case R.MEMORY:
            return Ht();
        default:
            i.error(`Invalid session persistence '${String(e)}'`);
            return;
    }
}

function Zt(e, t) {
    return e.type === R.COOKIE ? bt(t, e.cookieOptions) : e.type === R.LOCAL_STORAGE ? Ot(t) : Ut(t);
}

function Qt(e, t, n, r, i = Zt(e, t)) {
    let a = new D(),
        o = new D(),
        s = new D(),
        c = oe(p, qt),
        l;
    h();
    let {
        throttled: u,
        cancel: d
    } = we(() => {
        It({
            process: (e) => {
                if (st(e)) return;
                let t = m(e);
                return g(t), t;
            },
            after: (e) => {
                ct(e) && !_() && b(e), l = e;
            }
        }, i);
    }, qt);

    function f() {
        It({
            process: (e) => _() ? m(e) : void 0
        }, i);
    }

    function p() {
        let e = i.retrieveSession();
        lt(e) ? It({
            process: (e) => lt(e) ? ot(e, t) : void 0,
            after: m
        }, i) : m(e);
    }

    function m(e) {
        return lt(e) && (e = ot(e, t)), _() && (v(e) ? y() : (s.notify({
            previousState: l,
            newState: e
        }), l = e)), e;
    }

    function h() {
        It({
            process: (e) => {
                if (st(e)) return e.anonymousId = L(), ot(e, t);
            },
            after: (e) => {
                l = e;
            }
        }, i);
    }

    function g(e) {
        if (st(e)) return !1;
        let i = r(e[n]);
        e[n] = i, delete e.isExpired, i !== "0" && !e.id && (e.id = L(), e.created = String(j())), t.trackAnonymousUser && !e.anonymousId && (e.anonymousId = L());
    }

    function _() {
        return l ? .[n] !== void 0;
    }

    function v(e) {
        return l.id !== e.id || l[n] !== e[n];
    }

    function y() {
        l = ot(l, t), o.notify();
    }

    function b(e) {
        l = e, a.notify();
    }

    function x(e) {
        It({
            process: (t) => ({
                ...t,
                ...e
            }),
            after: m
        }, i);
    }
    return {
        expandOrRenewSession: u,
        expandSession: f,
        getSession: () => l,
        renewObservable: a,
        expireObservable: o,
        sessionStateUpdateObservable: s,
        restartSession: h,
        expire: (e) => {
            d(), e === !1 && l && delete l.anonymousId, i.expireSession(l), m(ot(l, t));
        },
        stop: () => {
            se(c);
        },
        updateSessionState: x
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/trackingConsent.js
var $t = {
    GRANTED: "granted",
    NOT_GRANTED: "not-granted"
};

function en(e) {
    let t = new D();
    return {
        tryToInit(t) {
            e || = t;
        },
        update(n) {
            e = n, t.notify();
        },
        isGranted() {
            return e === $t.GRANTED;
        },
        observable: t
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/typeUtils.js
function tn(e) {
    return e === null ? "null" : Array.isArray(e) ? "array" : typeof e;
}

function nn(e) {
    return tn(e) === "object";
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/matchOption.js
function rn(e) {
    let t = tn(e);
    return t === "string" || t === "function" || e instanceof RegExp;
}

function an(e, t, n = !1) {
    return e.some((e) => {
        try {
            if (typeof e == "function") return e(t);
            if (e instanceof RegExp) return e.test(t);
            if (typeof e == "string") return n ? t.startsWith(e) : e === t;
        } catch (e) {
            i.error(e);
        }
        return !1;
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/mockable.js
function z(e) {
    return e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/extension/extensionUtils.js
var on = ["chrome-extension://", "moz-extension://"];

function sn(e) {
    return on.some((t) => e.includes(t));
}

function cn(e, t = "") {
    return sn(e) ? !1 : sn(t.split("\n").filter((e) => {
        let t = e.trim();
        return t.length && /^at\s+|@/.test(t);
    })[1] || "");
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/allowedTrackingOrigins.js
var ln = "Running the Browser SDK in a Web extension content script is forbidden unless the `allowedTrackingOrigins` option is provided.",
    un = "SDK initialized on a non-allowed domain.";

function dn(e, t) {
    let n = z(v().location),
        r = n ? n.origin : "",
        a = e.allowedTrackingOrigins;
    if (!a) return cn(r, t) ? (i.error(ln), !1) : !0;
    let o = an(a, r);
    return o || i.error(un), o;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/intakeSites.js
var fn = "datad0g.com",
    pn = "datadoghq.com",
    mn = "datadoghq.eu",
    hn = "ddog-gov.com",
    gn = "pci.browser-intake-datadoghq.com",
    _n = [
        "ddsource",
        "dd-api-key",
        "dd-request-id"
    ];
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/configuration/endpointBuilder.js
function vn(e, t, n) {
    let r = yn(e, t);
    return {
        build(i, a) {
            return r(xn(e, t, i, a, n));
        },
        trackType: t
    };
}

function yn(e, t) {
    let n = `/api/v2/${t}`,
        r = e.proxy;
    if (typeof r == "string") {
        let e = Fe(r);
        return (t) => `${e}?ddforward=${encodeURIComponent(`${n}?${t}`)}`;
    }
    if (typeof r == "function") return (e) => r({
        path: n,
        parameters: e
    });
    let i = bn(t, e);
    return (e) => `https://${i}${n}?${e}`;
}

function bn(e, t) {
    let {
        site: n = pn,
        internalAnalyticsSubdomain: r
    } = t;
    if (e === "logs" && t.usePciIntake && n === "datadoghq.com") return gn;
    if (r && n === "datadoghq.com") return `${r}.${pn}`;
    if (n === "dd0g-gov.com") return `http-intake.logs.${n}`;
    let i = n.split("."),
        a = i.pop();
    return `browser-intake-${i.join("-")}.${a}`;
}

function xn({
    clientToken: e,
    internalAnalyticsSubdomain: t,
    source: n = "browser"
}, r, i, {
    retry: a,
    encoding: o
}, s = []) {
    let c = [
        `ddsource=${n}`,
        `dd-api-key=${e}`,
        "dd-evp-origin-version=6.31.0",
        "dd-evp-origin=browser",
        `dd-request-id=${L()}`
    ].concat(s);
    return o && c.push(`dd-evp-encoding=${o}`), r === "rum" && (c.push(`batch_time=${M()}`, `_dd.api=${i}`), a && c.push(`_dd.retry_count=${a.count}`, `_dd.retry_after=${a.lastFailureStatus}`)), t && c.reverse(), c.join("&");
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/configuration/transportConfiguration.js
function Sn(e) {
    let t = e.site || "datadoghq.com",
        n = Cn(e.source),
        r = wn({
            ...e,
            site: t,
            source: n
        });
    return {
        replica: Tn({
            ...e,
            site: t,
            source: n
        }),
        site: t,
        source: n,
        ...r
    };
}

function Cn(e) {
    return e === "flutter" || e === "unity" ? e : "browser";
}

function wn(e) {
    return {
        logsEndpointBuilder: vn(e, "logs"),
        rumEndpointBuilder: vn(e, "rum"),
        profilingEndpointBuilder: vn(e, "profile"),
        sessionReplayEndpointBuilder: vn(e, "replay"),
        exposuresEndpointBuilder: vn(e, "exposures"),
        flagEvaluationEndpointBuilder: vn(e, "flagevaluation")
    };
}

function Tn(e) {
    if (!e.replica) return;
    let t = {
        ...e,
        site: pn,
        clientToken: e.replica.clientToken
    };
    return {
        logsEndpointBuilder: vn(t, "logs"),
        rumEndpointBuilder: vn(t, "rum", [`application.id=${e.replica.applicationId}`])
    };
}

function En(e) {
    return _n.every((t) => e.includes(t));
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/configuration/configuration.js
var Dn = {
        ALLOW: "allow",
        MASK: "mask",
        MASK_USER_INPUT: "mask-user-input",
        MASK_UNLESS_ALLOWLISTED: "mask-unless-allowlisted"
    },
    On = {
        ALL: "all",
        SAMPLED: "sampled"
    };

function kn(e, t) {
    return e != null && typeof e != "string" ? (i.error(`${t} must be defined as a string`), !1) : !0;
}

function An(e) {
    return e && typeof e == "string" && !/(datadog|ddog|datad0g|dd0g)/.test(e) ? (i.error(`Site should be a valid Datadog site. ${s} ${a}/getting_started/site/.`), !1) : !0;
}

function jn(e, t) {
    return e !== void 0 && !d(e) ? (i.error(`${t} Sample Rate should be a number between 0 and 100`), !1) : !0;
}

function Mn(e, t) {
    if (!e || !e.clientToken) {
        i.error("Client Token is not configured, we will not send any data.");
        return;
    }
    if (e.allowedTrackingOrigins !== void 0 && !Array.isArray(e.allowedTrackingOrigins)) {
        i.error("Allowed Tracking Origins must be an array");
        return;
    }
    if (!(!An(e.site) || !jn(e.sessionSampleRate, "Session") || !jn(e.telemetrySampleRate, "Telemetry") || !jn(e.telemetryConfigurationSampleRate, "Telemetry Configuration") || !jn(e.telemetryUsageSampleRate, "Telemetry Usage") || !kn(e.version, "Version") || !kn(e.env, "Env") || !kn(e.service, "Service") || !dn(e, t ? ? ""))) {
        if (e.trackingConsent !== void 0 && !h($t, e.trackingConsent)) {
            i.error("Tracking Consent should be either \"granted\" or \"not-granted\"");
            return;
        }
        return {
            beforeSend: e.beforeSend && c(e.beforeSend, "beforeSend threw an error:"),
            sessionStoreStrategyType: b ? void 0 : Jt(e),
            sessionSampleRate: e.sessionSampleRate ? ? 100,
            telemetrySampleRate: e.telemetrySampleRate ? ? 20,
            telemetryConfigurationSampleRate: e.telemetryConfigurationSampleRate ? ? 5,
            telemetryUsageSampleRate: e.telemetryUsageSampleRate ? ? 5,
            service: e.service ? ? void 0,
            env: e.env ? ? void 0,
            version: e.version ? ? void 0,
            datacenter: e.datacenter ? ? void 0,
            silentMultipleInit: !!e.silentMultipleInit,
            allowUntrustedEvents: !!e.allowUntrustedEvents,
            trackingConsent: e.trackingConsent ? ? $t.GRANTED,
            trackAnonymousUser: e.trackAnonymousUser ? ? !0,
            storeContextsAcrossPages: !!e.storeContextsAcrossPages,
            betaEncodeCookieOptions: !!e.betaEncodeCookieOptions,
            variant: e.variant,
            sdkVersion: e.sdkVersion,
            ...Sn(e)
        };
    }
}

function Nn(e) {
    return {
        session_sample_rate: e.sessionSampleRate,
        telemetry_sample_rate: e.telemetrySampleRate,
        telemetry_configuration_sample_rate: e.telemetryConfigurationSampleRate,
        telemetry_usage_sample_rate: e.telemetryUsageSampleRate,
        use_before_send: !!e.beforeSend,
        use_partitioned_cross_site_session_cookie: e.usePartitionedCrossSiteSessionCookie,
        use_secure_session_cookie: e.useSecureSessionCookie,
        use_proxy: !!e.proxy,
        silent_multiple_init: e.silentMultipleInit,
        track_session_across_subdomains: e.trackSessionAcrossSubdomains,
        track_anonymous_user: e.trackAnonymousUser,
        session_persistence: Array.isArray(e.sessionPersistence) ? e.sessionPersistence[0] : e.sessionPersistence,
        allow_fallback_to_local_storage: !!e.allowFallbackToLocalStorage,
        store_contexts_across_pages: !!e.storeContextsAcrossPages,
        allow_untrusted_events: !!e.allowUntrustedEvents,
        tracking_consent: e.trackingConsent,
        use_allowed_tracking_origins: Array.isArray(e.allowedTrackingOrigins),
        beta_encode_cookie_options: e.betaEncodeCookieOptions,
        source: e.source,
        sdk_version: e.sdkVersion,
        variant: e.variant
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/experimentalFeatures.js
var B;
(function(e) {
    e.TRACK_INTAKE_REQUESTS = "track_intake_requests", e.USE_TREE_WALKER_FOR_ACTION_NAME = "use_tree_walker_for_action_name", e.FEATURE_OPERATION_VITAL = "feature_operation_vital", e.SHORT_SESSION_INVESTIGATION = "short_session_investigation", e.START_STOP_ACTION = "start_stop_action", e.START_STOP_RESOURCE = "start_stop_resource", e.USE_CHANGE_RECORDS = "use_change_records", e.USE_INCREMENTAL_CHANGE_RECORDS = "use_incremental_change_records", e.LCP_SUBPARTS = "lcp_subparts", e.INP_SUBPARTS = "inp_subparts", e.TOO_MANY_REQUESTS_INVESTIGATION = "too_many_requests_investigation";
})(B || = {});
var Pn = /* @__PURE__ */ new Set();

function Fn(e) {
    Array.isArray(e) && In(e.filter((e) => h(B, e)));
}

function In(e) {
    e.forEach((e) => {
        Pn.add(e);
    });
}

function V(e) {
    return Pn.has(e);
}

function Ln() {
    return Pn;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/stackTrace/computeStackTrace.js
var Rn = "?";

function zn(e) {
    let t = [],
        n = Qn(e, "stack"),
        r = String(e);
    if (n && n.startsWith(r) && (n = n.slice(r.length)), n && n.split("\n").forEach((e) => {
            let n = Wn(e) || Kn(e) || Jn(e) || Zn(e);
            n && (!n.func && n.line && (n.func = Rn), t.push(n));
        }), t.length > 0 && ir() && e instanceof Error) {
        let n = [],
            r = e;
        for (;
            (r = Object.getPrototypeOf(r)) && nr(r);) {
            let e = r.constructor ? .name || Rn;
            n.push(e);
        }
        for (let e = n.length - 1; e >= 0 && t[0] ? .func === n[e]; e--) t.shift();
    }
    return {
        message: Qn(e, "message"),
        name: Qn(e, "name"),
        stack: t
    };
}
var Bn = "((?:file|https?|blob|chrome-extension|electron|native|eval|webpack|snippet|<anonymous>|\\w+\\.|\\/).*?)",
    Vn = "(?::(\\d+))",
    Hn = RegExp(`^\\s*at (.*?) ?\\(${Bn}${Vn}?${Vn}?\\)?\\s*$`, "i"),
    Un = RegExp(`\\((\\S*)${Vn}${Vn}\\)`);

function Wn(e) {
    let t = Hn.exec(e);
    if (!t) return;
    let n = t[2] && t[2].indexOf("native") === 0,
        r = t[2] && t[2].indexOf("eval") === 0,
        i = Un.exec(t[2]);
    return r && i && (t[2] = i[1], t[3] = i[2], t[4] = i[3]), {
        args: n ? [t[2]] : [],
        column: t[4] ? +t[4] : void 0,
        func: t[1] || Rn,
        line: t[3] ? +t[3] : void 0,
        url: n ? void 0 : t[2]
    };
}
var Gn = RegExp(`^\\s*at\\s*(?:(.*)?(?: @))?\\s*${Bn}${Vn}?${Vn}??\\s*$`, "i");

function Kn(e) {
    let t = Gn.exec(e);
    if (t) return {
        args: [],
        column: t[4] ? +t[4] : void 0,
        func: t[1] || Rn,
        line: t[3] ? +t[3] : void 0,
        url: t[2]
    };
}
var qn = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;

function Jn(e) {
    let t = qn.exec(e);
    if (t) return {
        args: [],
        column: t[4] ? +t[4] : void 0,
        func: t[1] || Rn,
        line: +t[3],
        url: t[2]
    };
}
var Yn = /^\s*(.*?)(?:\((.*?)\))?(?:(?:(?:^|@)((?:file|https?|blob|chrome|webpack|resource|capacitor|\[native).*?|[^@]*bundle|\[wasm code\])(?::(\d+))?(?::(\d+))?)|@)\s*$/i,
    Xn = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;

function Zn(e) {
    let t = Yn.exec(e);
    if (!t) return;
    let n = t[3] && t[3].indexOf(" > eval") > -1,
        r = Xn.exec(t[3]);
    return n && r && (t[3] = r[1], t[4] = r[2], t[5] = void 0), {
        args: t[2] ? t[2].split(",") : [],
        column: t[5] ? +t[5] : void 0,
        func: t[1] || Rn,
        line: t[4] ? +t[4] : void 0,
        url: t[3]
    };
}

function Qn(e, t) {
    return nn(e) && typeof e[t] == "string" ? e[t] : void 0;
}

function $n(e, t, n, r) {
    if (t === void 0) return;
    let {
        name: i,
        message: a
    } = tr(e);
    return {
        name: i,
        message: a,
        stack: [{
            url: t,
            column: r,
            line: n
        }]
    };
}
var er = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?([\s\S]*)$/;

function tr(e) {
    let t, n;
    return {}.toString.call(e) === "[object String]" && ([, t, n] = er.exec(e)), {
        name: t,
        message: n
    };
}

function nr(e) {
    return String(e.constructor).startsWith("class ");
}
var rr;

function ir() {
    if (rr !== void 0) return rr;
    class e extends Error {
        constructor() {
            super(), this.name = "Error";
        }
    }
    let [t, n] = [e, Error].map((e) => new e());
    return rr = nr(Object.getPrototypeOf(t)) && n.stack !== t.stack, rr;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/stackTrace/handlingStack.js
function ar(e) {
    let t = Error(e);
    t.name = "HandlingStack";
    let n;
    return w(() => {
        let e = zn(t);
        e.stack = e.stack.slice(2), n = or(e);
    }), n;
}

function or(e) {
    let t = sr(e);
    return e.stack.forEach((e) => {
        let n = e.func === "?" ? "<anonymous>" : e.func,
            r = e.args && e.args.length > 0 ? `(${e.args.join(", ")})` : "",
            i = e.line ? `:${e.line}` : "",
            a = e.line && e.column ? `:${e.column}` : "";
        t += `\n  at ${n}${r} @ ${e.url}${i}${a}`;
    }), t;
}

function sr(e) {
    return `${e.name || "Error"}: ${e.message}`;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/instrumentMethod.js
function H(e, t, n, {
    computeHandlingStack: r
} = {}) {
    let i = e[t];
    if (typeof i != "function")
        if (t in e && typeof t == "string" && t.startsWith("on")) i = I;
        else return {
            stop: I
        };
    let a = !1,
        o = function() {
            if (a) return i.apply(this, arguments);
            let e = Array.from(arguments),
                t;
            w(n, null, [{
                target: this,
                parameters: e,
                onPostCall: (e) => {
                    t = e;
                },
                handlingStack: r ? ar("instrumented method") : void 0
            }]);
            let o = i.apply(this, e);
            return t && w(t, null, [o]), o;
        };
    return e[t] = o, {
        stop: () => {
            a = !0, e[t] === o && (e[t] = i);
        }
    };
}

function cr(e, t, n) {
    let r = Object.getOwnPropertyDescriptor(e, t);
    if (!r || !r.set || !r.configurable) return {
        stop: I
    };
    let i = I,
        a = (e, t) => {
            T(() => {
                a !== i && n(e, t);
            }, 0);
        },
        o = function(e) {
            r.set.call(this, e), a(this, e);
        };
    return Object.defineProperty(e, t, {
        set: o
    }), {
        stop: () => {
            Object.getOwnPropertyDescriptor(e, t) ? .set === o && Object.defineProperty(e, t, r), a = i;
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/byteUtils.js
var lr = 1024,
    ur = 1024 * lr,
    dr = /[^\u0000-\u007F]/;

function fr(e) {
    return dr.test(e) ? window.TextEncoder === void 0 ? new Blob([e]).size : new TextEncoder().encode(e).length : e.length;
}

function pr(e) {
    if (e.length === 1) return e[0];
    let t = e.reduce((e, t) => e + t.length, 0),
        n = new Uint8Array(t),
        r = 0;
    for (let t of e) n.set(t, r), r += t.length;
    return n;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/serialisation/jsonStringify.js
function mr(e, t, n) {
    if (typeof e != "object" || !e) return JSON.stringify(e);
    let r = hr(Object.prototype),
        i = hr(Array.prototype),
        a = hr(Object.getPrototypeOf(e)),
        o = hr(e);
    try {
        return JSON.stringify(e, t, n);
    } catch {
        return "<error: unable to serialize object>";
    } finally {
        r(), i(), a(), o();
    }
}

function hr(e) {
    let t = e,
        n = t.toJSON;
    return n ? (delete t.toJSON, () => {
        t.toJSON = n;
    }) : I;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/serialisation/sanitize.js
var gr = 220 * lr,
    _r = "$",
    vr = 3;

function U(e, t = gr) {
    let n = hr(Object.prototype),
        r = hr(Array.prototype),
        i = [],
        a = /* @__PURE__ */ new WeakMap(),
        o = yr(e, _r, void 0, i, a),
        s = JSON.stringify(o),
        c = s ? s.length : 0;
    if (c > t) {
        wr(t, "discarded", e);
        return;
    }
    for (; i.length > 0 && c < t;) {
        let n = i.shift(),
            r = 0;
        if (Array.isArray(n.source))
            for (let o = 0; o < n.source.length; o++) {
                let s = yr(n.source[o], n.path, o, i, a);
                if (s === void 0 ? c += 4 : c += JSON.stringify(s).length, c += r, r = 1, c > t) {
                    wr(t, "truncated", e);
                    break;
                }
                n.target[o] = s;
            }
        else
            for (let o in n.source)
                if (Object.prototype.hasOwnProperty.call(n.source, o)) {
                    let s = yr(n.source[o], n.path, o, i, a);
                    if (s !== void 0 && (c += JSON.stringify(s).length + r + o.length + vr, r = 1), c > t) {
                        wr(t, "truncated", e);
                        break;
                    }
                    n.target[o] = s;
                }
    }
    return n(), r(), o;
}

function yr(e, t, n, r, i) {
    let a = Cr(e);
    if (!a || typeof a != "object") return br(a);
    let o = xr(a);
    if (o !== "[Object]" && o !== "[Array]" && o !== "[Error]") return o;
    let s = e;
    if (i.has(s)) return `[Reference seen at ${i.get(s)}]`;
    let c = n === void 0 ? t : `${t}.${n}`,
        l = Array.isArray(a) ? [] : {};
    return i.set(s, c), r.push({
        source: a,
        target: l,
        path: c
    }), l;
}

function br(e) {
    return typeof e == "bigint" ? `[BigInt] ${e.toString()}` : typeof e == "function" ? `[Function] ${e.name || "unknown"}` : typeof e == "symbol" ? `[Symbol] ${e.description || e.toString()}` : e;
}

function xr(e) {
    try {
        if (e instanceof Event) return Sr(e);
        if (e instanceof RegExp) return `[RegExp] ${e.toString()}`;
        let t = Object.prototype.toString.call(e).match(/\[object (.*)\]/);
        if (t && t[1]) return `[${t[1]}]`;
    } catch {}
    return "[Unserializable]";
}

function Sr(e) {
    return {
        type: e.type,
        isTrusted: e.isTrusted,
        currentTarget: e.currentTarget ? xr(e.currentTarget) : null,
        target: e.target ? xr(e.target) : null
    };
}

function Cr(e) {
    let t = e;
    if (t && typeof t.toJSON == "function") try {
        return t.toJSON();
    } catch {}
    return e;
}

function wr(e, t, n) {
    i.warn(`The data provided has been ${t} as it is over the limit of ${e} characters:`, n);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/error/error.js
var Tr = "No stack, consider using an instance of Error";

function Er({
    originalError: e,
    stackTrace: t,
    source: n,
    useFallbackStack: r = !0,
    nonErrorPrefix: i
}) {
    let a = Mr(e);
    return !t && a && (t = zn(e)), {
        source: n,
        type: t ? t.name : void 0,
        message: Or(t, a, i, e),
        stack: t ? or(t) : r ? Tr : void 0
    };
}

function Dr({
    stackTrace: e,
    originalError: t,
    handlingStack: n,
    componentStack: r,
    startClocks: i,
    nonErrorPrefix: a,
    useFallbackStack: o = !0,
    source: s,
    handling: c
}) {
    return {
        startClocks: i,
        handling: c,
        handlingStack: n,
        componentStack: r,
        originalError: t,
        ...Er({
            originalError: t,
            stackTrace: e,
            source: s,
            useFallbackStack: o,
            nonErrorPrefix: a
        }),
        causes: Mr(t) ? Nr(t, s) : void 0,
        fingerprint: kr(t),
        context: Ar(t)
    };
}

function Or(e, t, n, r) {
    return e ? .message && e ? .name ? e.message : t ? "Empty message" : n ? `${n} ${mr(U(r))}` : mr(U(r));
}

function kr(e) {
    return Mr(e) && "dd_fingerprint" in e ? String(e.dd_fingerprint) : void 0;
}

function Ar(e) {
    if (nn(e)) return e.dd_context;
}

function jr(e) {
    return /@ (.+)/.exec(e) ? .[1];
}

function Mr(e) {
    return e instanceof Error || Object.prototype.toString.call(e) === "[object Error]";
}

function Nr(e, t) {
    let n = [],
        r = e.cause;
    for (; r != null && n.length < 10;) {
        let e = Er({
            originalError: r,
            source: t,
            useFallbackStack: !1
        });
        n.push(e), r = Mr(r) ? r.cause : void 0;
    }
    return n.length ? n : void 0;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/error/error.types.js
var Pr = {
    AGENT: "agent",
    CONSOLE: "console",
    CUSTOM: "custom",
    LOGGER: "logger",
    NETWORK: "network",
    SOURCE: "source",
    REPORT: "report"
};
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/error/trackRuntimeError.js
function Fr() {
    return new D((e) => {
        let t = (t, n) => {
                let r = Dr({
                    stackTrace: n,
                    originalError: t,
                    startClocks: P(),
                    nonErrorPrefix: "Uncaught",
                    source: Pr.SOURCE,
                    handling: "unhandled"
                });
                e.notify(r);
            },
            {
                stop: n
            } = Ir(t),
            {
                stop: r
            } = Lr(t);
        return () => {
            n(), r();
        };
    });
}

function Ir(e) {
    return H(v(), "onerror", ({
        parameters: [t, n, r, i, a]
    }) => {
        let o;
        Mr(a) || (o = $n(t, n, r, i)), e(a ? ? t, o);
    });
}

function Lr(e) {
    return H(v(), "onunhandledrejection", ({
        parameters: [t]
    }) => {
        e(t.reason || "Empty reason");
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/boot/init.js
function Rr(e) {
    let t = {
        version: "6.31.0",
        onReady(e) {
            e();
        },
        ...e
    };
    return Object.defineProperty(t, "_setDebug", {
        get() {
            return ne;
        },
        enumerable: !1
    }), t;
}

function zr(e, t, n) {
    let r = e[t];
    r && !r.q && r.version && i.warn("SDK is loaded more than once. This is unsupported and might have unexpected behavior."), e[t] = n, r && r.q && r.q.forEach((e) => c(e, "onReady callback threw an error:")());
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/boot/displayAlreadyInitializedError.js
function Br(e, t) {
    t.silentMultipleInit || i.error(`${e} is already initialized.`);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/browser/addEventListener.js
function W(e, t, n, r, i) {
    return Vr(e, t, [n], r, i);
}

function Vr(e, t, n, r, {
    once: i,
    capture: a,
    passive: o
} = {}) {
    let s = C((t) => {
            !t.isTrusted && !t.__ddIsTrusted && !e.allowUntrustedEvents || (i && d(), r(t));
        }),
        c = o ? {
            capture: a,
            passive: o
        } : a,
        l = window.EventTarget && t instanceof EventTarget ? window.EventTarget.prototype : t,
        u = x(l, "addEventListener");
    n.forEach((e) => u.call(t, e, s, c));

    function d() {
        let e = x(l, "removeEventListener");
        n.forEach((n) => e.call(t, n, s, c));
    }
    return {
        stop: d
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/report/reportObservable.js
var Hr = {
    intervention: "intervention",
    deprecation: "deprecation",
    cspViolation: "csp_violation"
};

function Ur(e, t) {
    let n = [];
    t.includes(Hr.cspViolation) && n.push(Gr(e));
    let r = t.filter((e) => e !== Hr.cspViolation);
    return r.length && n.push(Wr(r)), le(...n);
}

function Wr(e) {
    return new D((t) => {
        if (!window.ReportingObserver) return;
        let n = C((e, n) => e.forEach((e) => t.notify(Kr(e)))),
            r = new window.ReportingObserver(n, {
                types: e,
                buffered: !0
            });
        return r.observe(), () => {
            r.disconnect();
        };
    });
}

function Gr(e) {
    return new D((t) => {
        let {
            stop: n
        } = W(e, document, "securitypolicyviolation", (e) => {
            t.notify(qr(e));
        });
        return n;
    });
}

function Kr(e) {
    let {
        type: t,
        body: n
    } = e;
    return Jr({
        type: n.id,
        message: `${t}: ${n.message}`,
        originalError: e,
        stack: Yr(n.id, n.message, n.sourceFile, n.lineNumber, n.columnNumber)
    });
}

function qr(e) {
    let t = `'${e.blockedURI}' blocked by '${e.effectiveDirective}' directive`;
    return Jr({
        type: e.effectiveDirective,
        message: `${Hr.cspViolation}: ${t}`,
        originalError: e,
        csp: {
            disposition: e.disposition
        },
        stack: Yr(e.effectiveDirective, e.originalPolicy ? `${t} of the policy "${ke(e.originalPolicy, 100, "...")}"` : "no policy", e.sourceFile, e.lineNumber, e.columnNumber)
    });
}

function Jr(e) {
    return {
        startClocks: P(),
        source: Pr.REPORT,
        handling: "unhandled",
        ...e
    };
}

function Yr(e, t, n, r, i) {
    return n ? or({
        name: e,
        message: t,
        stack: [{
            func: "?",
            url: n,
            line: r ? ? void 0,
            column: i ? ? void 0
        }]
    }) : void 0;
}

function Xr(e) {
    let {
        env: t,
        service: n,
        version: r,
        datacenter: i,
        sdkVersion: a,
        variant: o
    } = e, s = [Zr("sdk_version", a ? ? "6.31.0")];
    return t && s.push(Zr("env", t)), n && s.push(Zr("service", n)), r && s.push(Zr("version", r)), i && s.push(Zr("datacenter", i)), o && s.push(Zr("variant", o)), s;
}

function Zr(e, t) {
    let n = t ? `${e}:${t}` : e;
    return (n.length > 200 || $r(n)) && i.warn(`Tag ${n} doesn't meet tag requirements and will be sanitized. ${s} ${a}/getting_started/tagging/#defining-tags`), Qr(n);
}

function Qr(e) {
    return e.replace(/,/g, "_");
}

function $r(e) {
    return ei() ? ( /* @__PURE__ */ RegExp("[^\\p{Ll}\\p{Lo}0-9_:./-]", "u")).test(e) : !1;
}

function ei() {
    try {
        return !0;
    } catch {
        return !1;
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/sendToExtension.js
function ti(e, t) {
    let n = y.__ddBrowserSdkExtensionCallback;
    n && n({
        type: e,
        payload: t
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/mergeInto.js
function ni(e, t, n = ai()) {
    if (t === void 0) return e;
    if (typeof t != "object" || !t) return t;
    if (t instanceof Date) return new Date(t.getTime());
    if (t instanceof RegExp) {
        let e = t.flags || [
            t.global ? "g" : "",
            t.ignoreCase ? "i" : "",
            t.multiline ? "m" : "",
            t.sticky ? "y" : "",
            t.unicode ? "u" : ""
        ].join("");
        return new RegExp(t.source, e);
    }
    if (n.hasAlreadyBeenSeen(t)) return;
    if (Array.isArray(t)) {
        let r = Array.isArray(e) ? e : [];
        for (let e = 0; e < t.length; ++e) r[e] = ni(r[e], t[e], n);
        return r;
    }
    let r = tn(e) === "object" ? e : {};
    for (let e in t) Object.prototype.hasOwnProperty.call(t, e) && (r[e] = ni(r[e], t[e], n));
    return r;
}

function ri(e) {
    return ni(void 0, e);
}

function ii(...e) {
    let t;
    for (let n of e) n != null && (t = ni(t, n));
    return t;
}

function ai() {
    if (typeof WeakSet < "u") {
        let e = /* @__PURE__ */ new WeakSet();
        return {
            hasAlreadyBeenSeen(t) {
                let n = e.has(t);
                return n || e.add(t), n;
            }
        };
    }
    let e = [];
    return {
        hasAlreadyBeenSeen(t) {
            let n = e.indexOf(t) >= 0;
            return n || e.push(t), n;
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/connectivity/connectivity.js
function oi() {
    let e = y.navigator;
    return {
        status: e.onLine ? "connected" : "not_connected",
        interfaces: e.connection && e.connection.type ? [e.connection.type] : void 0,
        effective_type: e.connection ? .effectiveType
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/browser/fetch.js
function si(e, t) {
    return x(v(), "fetch")(e, t);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/responseUtils.js
function ci(e) {
    return e >= 500;
}

function li(e) {
    try {
        return e.clone();
    } catch {
        return;
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/transport/sendWithRetryStrategy.js
var ui = 80 * lr,
    di = 20 * ur,
    fi = k,
    pi = O;

function mi(e, t, n, r, i, a) {
    t.transportStatus === 0 && t.queuedPayloads.size() === 0 && t.bandwidthMonitor.canHandle(e) ? gi(e, t, n, a, {
        onSuccess: () => _i(0, t, n, r, i, a),
        onFailure: () => {
            t.queuedPayloads.enqueue(e) || a.notify({
                type: "queue-full",
                bandwidth: t.bandwidthMonitor.stats(),
                payload: e
            }), hi(t, n, r, i, a);
        }
    }) : t.queuedPayloads.enqueue(e) || a.notify({
        type: "queue-full",
        bandwidth: t.bandwidthMonitor.stats(),
        payload: e
    });
}

function hi(e, t, n, r, i) {
    e.transportStatus === 2 && T(() => {
        gi(e.queuedPayloads.first(), e, t, i, {
            onSuccess: () => {
                e.queuedPayloads.dequeue(), e.currentBackoffTime = pi, _i(1, e, t, n, r, i);
            },
            onFailure: () => {
                e.currentBackoffTime = Math.min(fi, e.currentBackoffTime * 2), hi(e, t, n, r, i);
            }
        });
    }, e.currentBackoffTime);
}

function gi(e, t, n, r, {
    onSuccess: i,
    onFailure: a
}) {
    t.bandwidthMonitor.add(e), n(e, (n) => {
        t.bandwidthMonitor.remove(e), vi(n) ? (t.transportStatus = t.bandwidthMonitor.ongoingRequestCount > 0 ? 1 : 2, e.retry = {
            count: e.retry ? e.retry.count + 1 : 1,
            lastFailureStatus: n.status
        }, r.notify({
            type: "failure",
            bandwidth: t.bandwidthMonitor.stats(),
            payload: e
        }), a()) : (t.transportStatus = 0, r.notify({
            type: "success",
            bandwidth: t.bandwidthMonitor.stats(),
            payload: e
        }), i());
    });
}

function _i(e, t, n, r, i, a) {
    e === 0 && t.queuedPayloads.isFull() && !t.queueFullReported && (i({
        message: `Reached max ${r} events size queued for upload: ${di / ur}MiB`,
        source: Pr.AGENT,
        startClocks: P()
    }), t.queueFullReported = !0);
    let o = t.queuedPayloads;
    for (t.queuedPayloads = bi(); o.size() > 0;) mi(o.dequeue(), t, n, r, i, a);
}

function vi(e) {
    return e.type !== "opaque" && (e.status === 0 && !navigator.onLine || e.status === 408 || e.status === 429 || ci(e.status));
}

function yi() {
    return {
        transportStatus: 0,
        currentBackoffTime: pi,
        bandwidthMonitor: xi(),
        queuedPayloads: bi(),
        queueFullReported: !1
    };
}

function bi() {
    let e = [];
    return {
        bytesCount: 0,
        enqueue(t) {
            return this.isFull() ? !1 : (e.push(t), this.bytesCount += t.bytesCount, !0);
        },
        first() {
            return e[0];
        },
        dequeue() {
            let t = e.shift();
            return t && (this.bytesCount -= t.bytesCount), t;
        },
        size() {
            return e.length;
        },
        isFull() {
            return this.bytesCount >= di;
        }
    };
}

function xi() {
    return {
        ongoingRequestCount: 0,
        ongoingByteCount: 0,
        canHandle(e) {
            return this.ongoingRequestCount === 0 || this.ongoingByteCount + e.bytesCount <= ui && this.ongoingRequestCount < 32;
        },
        add(e) {
            this.ongoingRequestCount += 1, this.ongoingByteCount += e.bytesCount;
        },
        remove(e) {
            --this.ongoingRequestCount, this.ongoingByteCount -= e.bytesCount;
        },
        stats() {
            return {
                ongoingByteCount: this.ongoingByteCount,
                ongoingRequestCount: this.ongoingRequestCount
            };
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/transport/httpRequest.js
var Si = 16 * lr;

function Ci(e, t, n = Si) {
    let r = new D(),
        i = yi();
    return {
        observable: r,
        send: (n) => {
            for (let a of e) mi(n, i, (e, t) => {
                Di(a, e, t);
            }, a.trackType, t, r);
        },
        sendOnExit: (t) => {
            for (let r of e) wi(r, n, t);
        }
    };
}

function wi(e, t, n) {
    if (navigator.sendBeacon && n.bytesCount < t) try {
        let t = e.build("beacon", n);
        if (navigator.sendBeacon(t, n.data)) return;
    } catch (e) {
        Ei(e);
    }
    Di(e, n);
}
var Ti = !1;

function Ei(e) {
    Ti || (Ti = !0, ie(e));
}

function Di(e, t, n) {
    si(e.build("fetch", t), {
        method: "POST",
        body: t.data,
        mode: "cors"
    }).then(C((e) => n ? .({
        status: e.status,
        type: e.type
    }))).catch(C(() => n ? .({
        status: 0
    })));
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/transport/eventBridge.js
function Oi() {
    let e = ji();
    if (e) return {
        getCapabilities() {
            return JSON.parse(e.getCapabilities ? .call(e) || "[]");
        },
        getPrivacyLevel() {
            return e.getPrivacyLevel ? .call(e);
        },
        getAllowedWebViewHosts() {
            return JSON.parse(e.getAllowedWebViewHosts());
        },
        send(t, n, r) {
            let i = r ? {
                id: r
            } : void 0;
            e.send(JSON.stringify({
                eventType: t,
                event: n,
                view: i
            }));
        }
    };
}

function ki(e) {
    let t = Oi();
    return !!t && t.getCapabilities().includes(e);
}

function Ai(e) {
    e === void 0 && (e = v().location ? .hostname);
    let t = Oi();
    return !!t && t.getAllowedWebViewHosts().some((t) => e === t || e.endsWith(`.${t}`));
}

function ji() {
    return v().DatadogEventBridge;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/browser/pageMayExitObservable.js
var Mi = {
    HIDDEN: "visibility_hidden",
    UNLOADING: "before_unload",
    PAGEHIDE: "page_hide",
    FROZEN: "page_frozen"
};

function Ni(e) {
    return new D((t) => {
        if (b) return;
        let {
            stop: n
        } = Vr(e, window, ["visibilitychange", "freeze"], (e) => {
            e.type === "visibilitychange" && document.visibilityState === "hidden" ? t.notify({
                reason: Mi.HIDDEN
            }) : e.type === "freeze" && t.notify({
                reason: Mi.FROZEN
            });
        }, {
            capture: !0
        }), r = W(e, window, "beforeunload", () => {
            t.notify({
                reason: Mi.UNLOADING
            });
        }).stop;
        return () => {
            n(), r();
        };
    });
}

function Pi(e) {
    return $e(Mi).includes(e);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/transport/batch.js
var Fi = 256 * lr;

function Ii({
    encoder: e,
    request: t,
    flushController: n
}) {
    let r = {},
        a = n.flushObservable.subscribe((e) => f(e));

    function c(t, i, a) {
        n.notifyBeforeAddMessage(i), a === void 0 ? e.write(e.isEmpty ? t : `\n${t}`, (e) => {
            n.notifyAfterAddMessage(e - i);
        }) : (r[a] = t, n.notifyAfterAddMessage());
    }

    function l(e) {
        return e !== void 0 && r[e] !== void 0;
    }

    function u(t) {
        let i = r[t];
        delete r[t];
        let a = e.estimateEncodedBytesCount(i);
        n.notifyAfterRemoveMessage(a);
    }

    function d(t, n) {
        let r = mr(t),
            a = e.estimateEncodedBytesCount(r);
        if (a >= Fi) {
            i.warn(`Discarded a message whose size was bigger than the maximum allowed size ${Fi / lr}KiB. ${s} ${o}/#technical-limitations`);
            return;
        }
        l(n) && u(n), c(r, a, n);
    }

    function f(n) {
        let i = $e(r).join("\n");
        r = {};
        let a = Pi(n.reason),
            o = a ? t.sendOnExit : t.send;
        if (a && e.isAsync) {
            let t = e.finishSync();
            t.outputBytesCount && o(Li(t));
            let n = [t.pendingData, i].filter(Boolean).join("\n");
            n && o({
                data: n,
                bytesCount: fr(n)
            });
        } else i && e.write(e.isEmpty ? i : `\n${i}`), e.finish((e) => {
            o(Li(e));
        });
    }
    return {
        flushController: n,
        add: d,
        upsert: d,
        stop: a.unsubscribe
    };
}

function Li(e) {
    let t;
    return t = typeof e.output == "string" ? e.output : new Blob([e.output], {
        type: "text/plain"
    }), {
        data: t,
        bytesCount: e.outputBytesCount,
        encoding: e.encoding
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/transport/flushController.js
var Ri = 30 * O,
    zi = b ? 1 : 50;

function Bi({
    pageMayExitObservable: e,
    sessionExpireObservable: t
}) {
    let n = e.subscribe((e) => s(e.reason)),
        r = t.subscribe(() => s("session_expire")),
        i = new D(() => () => {
            n.unsubscribe(), r.unsubscribe();
        }),
        a = 0,
        o = 0;

    function s(e) {
        if (o === 0) return;
        let t = o,
            n = a;
        o = 0, a = 0, u(), i.notify({
            reason: e,
            messagesCount: t,
            bytesCount: n
        });
    }
    let c;

    function l() {
        c === void 0 && (c = T(() => {
            s("duration_limit");
        }, Ri));
    }

    function u() {
        E(c), c = void 0;
    }
    return {
        flushObservable: i,
        get messagesCount() {
            return o;
        },
        notifyBeforeAddMessage(e) {
            a + e >= Si && s("bytes_limit"), o += 1, a += e, l();
        },
        notifyAfterAddMessage(e = 0) {
            a += e, o >= zi ? s("messages_limit") : a >= Si && s("bytes_limit");
        },
        notifyAfterRemoveMessage(e) {
            a -= e, --o, o === 0 && u();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/encoder.js
function Vi() {
    let e = "",
        t = 0;
    return {
        isAsync: !1,
        get isEmpty() {
            return !e;
        },
        write(n, r) {
            let i = fr(n);
            t += i, e += n, r && r(i);
        },
        finish(e) {
            e(this.finishSync());
        },
        finishSync() {
            let n = {
                output: e,
                outputBytesCount: t,
                rawBytesCount: t,
                pendingData: ""
            };
            return e = "", t = 0, n;
        },
        estimateEncodedBytesCount(e) {
            return e.length;
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/abstractHooks.js
var Hi = "DISCARDED",
    G = "SKIPPED";

function Ui() {
    let e = {};
    return {
        register(t, n) {
            return e[t] || (e[t] = []), e[t].push(n), {
                unregister: () => {
                    e[t] = e[t].filter((e) => e !== n);
                }
            };
        },
        triggerHook(t, n) {
            let r = e[t] || [],
                i = [];
            for (let e of r) {
                let t = e(n);
                if (t === "DISCARDED") return Hi;
                t !== "SKIPPED" && i.push(t);
            }
            return ii(...i);
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/telemetry/rawTelemetryEvent.types.js
var Wi = {
        LOG: "log",
        CONFIGURATION: "configuration",
        USAGE: "usage"
    },
    Gi = [
        "https://www.datadoghq-browser-agent.com",
        "https://www.datad0g-browser-agent.com",
        "https://d3uc069fcn7uxw.cloudfront.net",
        "https://d20xtzwzcl0ceb.cloudfront.net",
        "http://localhost",
        "<anonymous>"
    ],
    Ki = 1,
    qi = [hn],
    Ji = 15,
    Yi;

function Xi() {
    return Yi || = new ue(100), Yi;
}

function Zi(e, t, n) {
    let r = new D(),
        {
            enabled: i,
            metricsEnabled: a
        } = Qi(e, t, n, r),
        {
            stop: o
        } = $i(t, r);
    return {
        stop: o,
        enabled: i,
        metricsEnabled: a
    };
}

function Qi(e, t, n, r, i = Ki, a = Ji) {
    let o = {},
        s = !qi.includes(t.site) && l(t.telemetrySampleRate),
        c = {
            [Wi.LOG]: s,
            [Wi.CONFIGURATION]: s && l(t.telemetryConfigurationSampleRate),
            [Wi.USAGE]: s && l(t.telemetryUsageSampleRate),
            metric: s && l(i)
        },
        u = ea(),
        d = Xi();
    return d.subscribe(({
        rawEvent: t,
        metricName: i
    }) => {
        if (i && !c.metric || !c[t.type]) return;
        let s = i || t.status || t.type,
            l = o[s];
        if (l || = o[s] = /* @__PURE__ */ new Set(), l.size >= a) return;
        let d = mr(t);
        if (l.has(d)) return;
        let p = n.triggerHook(1, {
            startTime: P().relative
        });
        if (p === "DISCARDED") return;
        let m = f(p, e, t, u);
        r.notify(m), ti("telemetry", m), l.add(d);
    }), d.unbuffer(), te(ra), {
        enabled: s,
        metricsEnabled: c.metric
    };

    function f(e, n, r, i) {
        return ii({
            type: "telemetry",
            date: P().timeStamp,
            service: n,
            version: "6.31.0",
            source: "browser",
            _dd: {
                format_version: 2
            },
            telemetry: ii(r, {
                runtime_env: i,
                connectivity: oi(),
                sdk_setup: "npm"
            }),
            ddtags: Xr(t).join(","),
            experimental_features: Array.from(Ln())
        }, e);
    }
}

function $i(e, t) {
    let n = [];
    if (Ai()) {
        let e = Oi(),
            r = t.subscribe((t) => e.send("internal_telemetry", t));
        n.push(r.unsubscribe);
    } else {
        let r = [e.rumEndpointBuilder];
        e.replica && ta(e) && r.push(e.replica.rumEndpointBuilder);
        let i = Ii({
            encoder: Vi(),
            request: Ci(r, I),
            flushController: Bi({
                pageMayExitObservable: Ni(e),
                sessionExpireObservable: new D()
            })
        });
        n.push(i.stop);
        let a = t.subscribe(i.add);
        n.push(a.unsubscribe);
    }
    return {
        stop: () => n.forEach((e) => e())
    };
}

function ea() {
    return {
        is_local_file: y.location ? .protocol === "file:",
        is_worker: b
    };
}

function ta(e) {
    return e.site === fn;
}

function na(t, n) {
    ae(e.debug, t, n), Xi().notify({
        rawEvent: {
            type: Wi.LOG,
            message: t,
            status: "debug",
            ...n
        }
    });
}

function ra(e, t) {
    Xi().notify({
        rawEvent: {
            type: Wi.LOG,
            status: "error",
            ...oa(e),
            ...t
        }
    });
}

function ia(e) {
    Xi().notify({
        rawEvent: {
            type: Wi.CONFIGURATION,
            configuration: e
        }
    });
}

function aa(e, t) {
    Xi().notify({
        rawEvent: {
            type: Wi.LOG,
            message: e,
            status: "debug",
            ...t
        },
        metricName: e
    });
}

function K(e) {
    Xi().notify({
        rawEvent: {
            type: Wi.USAGE,
            usage: e
        }
    });
}

function oa(e) {
    if (Mr(e)) {
        let t = zn(e);
        return {
            error: {
                kind: t.name,
                stack: or(sa(t))
            },
            message: t.message
        };
    }
    return {
        error: {
            stack: Tr
        },
        message: `Uncaught ${mr(e)}`
    };
}

function sa(e) {
    return e.stack = e.stack.filter((e) => !e.url || Gi.some((t) => e.url.startsWith(t))), e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/arrayUtils.js
function ca(e) {
    let t = /* @__PURE__ */ new Set();
    return e.forEach((e) => t.add(e)), Array.from(t);
}

function la(e, t) {
    let n = e.indexOf(t);
    n >= 0 && e.splice(n, 1);
}

function ua(e) {
    return Array.isArray(e) && e.length > 0;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/valueHistory.js
var da = Infinity,
    fa = k,
    pa, ma = /* @__PURE__ */ new Set();

function ha() {
    ma.forEach((e) => e());
}

function ga({
    expireDelay: e,
    maxEntries: t
}) {
    let n = [];
    pa || = oe(() => ha(), fa);
    let r = () => {
        let t = N() - e;
        for (; n.length > 0 && n[n.length - 1].endTime < t;) n.pop();
    };
    ma.add(r);

    function i(e, r) {
        let i = {
            value: e,
            startTime: r,
            endTime: da,
            remove: () => {
                la(n, i);
            },
            close: (e) => {
                i.endTime = e;
            }
        };
        return t && n.length >= t && n.pop(), n.unshift(i), i;
    }

    function a(e = da, t = {
        returnInactive: !1
    }) {
        for (let r of n)
            if (r.startTime <= e) {
                if (t.returnInactive || e <= r.endTime) return r.value;
                break;
            }
    }

    function o(e) {
        let t = n[0];
        t && t.endTime === da && t.close(e);
    }

    function s(e = da, t = 0) {
        let r = ve(e, t);
        return n.filter((t) => t.startTime <= r && e <= t.endTime).map((e) => e.value);
    }

    function c(e) {
        return n.filter((t) => t.startTime === e);
    }

    function l() {
        n = [];
    }

    function u() {
        ma.delete(r), ma.size === 0 && pa && (se(pa), pa = void 0);
    }
    return {
        add: i,
        find: a,
        closeActive: o,
        findAll: s,
        getEntries: c,
        reset: l,
        stop: u
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/synthetics/syntheticsWorkerValues.js
var _a = "datadog-synthetics-",
    va = `${_a}public-id`,
    ya = `${_a}result-id`,
    ba = `${_a}injects-rum`,
    xa = `${_a}rum-context`;

function Sa() {
    return b ? !1 : !!(y._DATADOG_SYNTHETICS_INJECTS_RUM || Ge(ba));
}

function Ca() {
    let e = Ta();
    return Ea(e) ? e : void 0;
}

function wa() {
    return !!Ca();
}

function Ta() {
    let e = y._DATADOG_SYNTHETICS_RUM_CONTEXT;
    if (e) return e;
    let t = Ge(xa);
    return t ? p(decodeURIComponent(t)) : {
        test_id: window._DATADOG_SYNTHETICS_PUBLIC_ID || Ge(va),
        result_id: window._DATADOG_SYNTHETICS_RESULT_ID || Ge(ya)
    };
}

function Ea(e) {
    return typeof e == "object" && !!e && typeof e.test_id == "string" && typeof e.result_id == "string";
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/session/sessionManager.js
var Da = k,
    Oa = tt,
    ka = [];

function Aa(e, t, n, r) {
    let i = new D(),
        a = new D(),
        o = Qt(e.sessionStoreStrategyType, e, t, n);
    ka.push(() => o.stop());
    let s = ga({
        expireDelay: Oa
    });
    if (ka.push(() => s.stop()), o.renewObservable.subscribe(() => {
            s.add(c(), N()), i.notify();
        }), o.expireObservable.subscribe(() => {
            a.notify(), s.closeActive(N());
        }), o.expandOrRenewSession(), s.add(c(), _e().relative), V(B.SHORT_SESSION_INVESTIGATION)) {
        let t = o.getSession();
        t && Fa(e, t);
    }
    r.observable.subscribe(() => {
        r.isGranted() ? o.expandOrRenewSession() : o.expire(!1);
    }), ja(e, () => {
        r.isGranted() && o.expandOrRenewSession();
    }), Ma(e, () => o.expandSession()), Na(e, () => o.restartSession());

    function c() {
        let n = o.getSession();
        return n ? {
            id: n.id,
            trackingType: n[t],
            isReplayForced: !!n.forcedReplay,
            anonymousId: n.anonymousId
        } : (Pa(e).catch(() => void 0), {
            id: "invalid",
            trackingType: "0",
            isReplayForced: !1,
            anonymousId: void 0
        });
    }
    return {
        findSession: (e, t) => s.find(e, t),
        renewObservable: i,
        expireObservable: a,
        sessionStateUpdateObservable: o.sessionStateUpdateObservable,
        expire: o.expire,
        updateSessionState: o.updateSessionState
    };
}

function ja(e, t) {
    let {
        stop: n
    } = Vr(e, window, [
        "click",
        "touchstart",
        "keydown",
        "scroll"
    ], t, {
        capture: !0,
        passive: !0
    });
    ka.push(n);
}

function Ma(e, t) {
    let n = () => {
            document.visibilityState === "visible" && t();
        },
        {
            stop: r
        } = W(e, document, "visibilitychange", n);
    ka.push(r);
    let i = oe(n, Da);
    ka.push(() => {
        se(i);
    });
}

function Na(e, t) {
    let {
        stop: n
    } = W(e, window, "resume", t, {
        capture: !0
    });
    ka.push(n);
}
async function Pa(e) {
    let t = e.sessionStoreStrategyType;
    if (!t) return;
    let n, r;
    t.type === R.COOKIE ? (n = St(t.cookieOptions, e), r = {
        cookie: await Ia(),
        currentDomain: `${window.location.protocol}//${window.location.hostname}`
    }) : n = At(), na("Unexpected session state", {
        sessionStoreStrategyType: t.type,
        session: n,
        isSyntheticsTest: wa(),
        createdTimestamp: n ? .created,
        expireTimestamp: n ? .expire,
        ...r
    });
}

function Fa(e, t) {
    if (!window.cookieStore || !t.created) return;
    let n = Number(t.created),
        r = j(),
        {
            stop: i
        } = W(e, cookieStore, "change", a);
    ka.push(i);

    function a(e) {
        let a = Qe(e.changed, (e) => e.name === Ze);
        if (!a) return;
        let o = j() - n;
        if (o > 14 * 6e4) i();
        else {
            let e = pt(a.value);
            if (e.id && e.id !== t.id) {
                i();
                let n = j() - r;
                Ia().then((r) => {
                    na("Session cookie changed", {
                        time: n,
                        session_age: o,
                        old: t,
                        new: e,
                        cookie: r
                    });
                }).catch(ie);
            }
        }
    }
}
async function Ia() {
    let e;
    return e = "cookieStore" in window ? await window.cookieStore.getAll(Ze) : document.cookie.split(/\s*;\s*/).filter((e) => e.startsWith(Ze)), {
        count: e.length,
        domain: Ye() || "undefined",
        ...e
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/abstractLifeCycle.js
var La = class {
        constructor() {
            this.callbacks = {};
        }
        notify(e, t) {
            let n = this.callbacks[e];
            n && n.forEach((e) => e(t));
        }
        subscribe(e, t) {
            return this.callbacks[e] || (this.callbacks[e] = []), this.callbacks[e].push(t), {
                unsubscribe: () => {
                    this.callbacks[e] = this.callbacks[e].filter((e) => t !== e);
                }
            };
        }
    },
    Ra = 3e3;

function za(e, t, n = Ra) {
    let r = 0,
        i = !1;
    return {
        isLimitReached() {
            if (r === 0 && T(() => {
                    r = 0;
                }, k), r += 1, r <= n || i) return i = !1, !1;
            if (r === n + 1) {
                i = !0;
                try {
                    t({
                        message: `Reached max number of ${e}s by minute: ${n}`,
                        source: Pr.AGENT,
                        startClocks: P()
                    });
                } finally {
                    i = !1;
                }
            }
            return !0;
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/browser/runOnReadyState.js
function Ba(e, t, n) {
    return document.readyState === t || document.readyState === "complete" ? (n(), {
        stop: I
    }) : W(e, window, t === "complete" ? "load" : "DOMContentLoaded", n, {
        once: !0
    });
}

function Va(e, t) {
    return new Promise((n) => {
        Ba(e, t, n);
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/browser/xhrObservable.js
var Ha, Ua = /* @__PURE__ */ new WeakMap();

function Wa(e) {
    return Ha || = Ga(e), Ha;
}

function Ga(e) {
    return new D((t) => {
        let {
            stop: n
        } = H(XMLHttpRequest.prototype, "open", Ka), {
            stop: r
        } = H(XMLHttpRequest.prototype, "send", (n) => {
            qa(n, e, t);
        }, {
            computeHandlingStack: !0
        }), {
            stop: i
        } = H(XMLHttpRequest.prototype, "abort", Ja);
        return () => {
            n(), r(), i();
        };
    });
}

function Ka({
    target: e,
    parameters: [t, n]
}) {
    Ua.set(e, {
        state: "open",
        method: String(t).toUpperCase(),
        url: Fe(String(n))
    });
}

function qa({
    target: e,
    parameters: [t],
    handlingStack: n
}, r, i) {
    let a = Ua.get(e);
    if (!a) return;
    let o = a;
    o.state = "start", o.startClocks = P(), o.isAborted = !1, o.xhr = e, o.handlingStack = n, o.requestBody = t;
    let s = !1,
        {
            stop: c
        } = H(e, "onreadystatechange", () => {
            e.readyState === XMLHttpRequest.DONE && l();
        }),
        l = () => {
            if (u(), c(), s) return;
            s = !0;
            let t = a;
            t.state = "complete", t.duration = F(o.startClocks.timeStamp, M()), t.status = e.status, typeof e.response == "string" && (t.responseBody = e.response), i.notify(m(t));
        },
        {
            stop: u
        } = W(r, e, "loadend", l);
    i.notify(o);
}

function Ja({
    target: e
}) {
    let t = Ua.get(e);
    t && (t.isAborted = !0);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/readBytesFromStream.js
async function Ya(e, t) {
    let n = e.getReader(),
        r = [];
    for (;;) {
        let e = await n.read();
        if (e.done) break;
        t.collectStreamBody && r.push(e.value);
    }
    return n.cancel().catch(I), t.collectStreamBody ? pr(r) : void 0;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/browser/fetchObservable.js
var Xa, Za = [];

function Qa({
    responseBodyAction: e
} = {}) {
    return e && Za.push(e), Xa || = $a(), Xa;
}

function $a() {
    return new D((e) => {
        if (!y.fetch) return;
        let {
            stop: t
        } = H(y, "fetch", (t) => eo(t, e), {
            computeHandlingStack: !0
        });
        return t;
    });
}

function eo({
    parameters: e,
    onPostCall: t,
    handlingStack: n
}, r) {
    let [i, a] = e, o = a && a.method;
    o === void 0 && i instanceof Request && (o = i.method);
    let s = o === void 0 ? "GET" : String(o).toUpperCase(),
        c = i instanceof Request ? i.url : Fe(String(i)),
        l = {
            state: "start",
            init: a,
            input: i,
            method: s,
            startClocks: P(),
            url: c,
            handlingStack: n,
            isAbortedOnStart: i instanceof Request && i.signal ? .aborted || a ? .signal ? .aborted || !1
        };
    r.notify(l), e[0] = l.input, e[1] = l.init, t((e) => {
        to(r, e, l).catch(ie);
    });
}
async function to(e, t, n) {
    let r = n;
    r.state = "resolve";
    let i;
    try {
        i = await t;
    } catch (t) {
        r.status = 0, r.isAborted = r.init ? .signal ? .aborted || t instanceof DOMException && t.code === DOMException.ABORT_ERR, r.error = t, e.notify(r);
        return;
    }
    r.response = i, r.status = i.status, r.responseType = i.type, r.isAborted = !1;
    let a = Za.reduce((e, t) => Math.max(e, t(r)), 0);
    if (a !== 0) {
        let e = li(i);
        if (e && e.body) try {
            let t = await Ya(e.body, {
                collectStreamBody: a === 2
            });
            r.responseBody = t && new TextDecoder().decode(t);
        } catch {}
    }
    e.notify(r);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/requestIdleCallback.js
function no(e, t) {
    if (window.requestIdleCallback && window.cancelIdleCallback) {
        let n = window.requestIdleCallback(C(e), t);
        return () => window.cancelIdleCallback(n);
    }
    return ro(e);
}

function ro(e) {
    let t = j(),
        n = T(() => {
            e({
                didTimeout: !1,
                timeRemaining: () => Math.max(0, 50 - (j() - t))
            });
        }, 0);
    return () => E(n);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/taskQueue.js
var io = O;

function ao() {
    let e = [];

    function t(t) {
        let r;
        if (t.didTimeout) {
            let e = performance.now();
            r = () => 30 - (performance.now() - e);
        } else r = t.timeRemaining.bind(t);
        for (; r() > 0 && e.length;) e.shift()();
        e.length && n();
    }

    function n() {
        no(t, {
            timeout: io
        });
    }
    return {
        push(t) {
            e.push(t) === 1 && n();
        },
        stop() {
            e.length = 0;
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/console/consoleObservable.js
var oo = {};

function so(e) {
    return le(...e.map((e) => (oo[e] || (oo[e] = co(e)), oo[e])));
}

function co(e) {
    return new D((n) => {
        let r = t[e];
        return t[e] = (...t) => {
            r.apply(console, t);
            let i = ar("console error");
            w(() => {
                n.notify(lo(t, e, i));
            });
        }, () => {
            t[e] = r;
        };
    });
}

function lo(t, n, r) {
    let i = t.map((e) => uo(e)).join(" ");
    if (n === e.error) {
        let e = Dr({
            originalError: t.find(Mr),
            handlingStack: r,
            startClocks: P(),
            source: Pr.CONSOLE,
            handling: "handled",
            nonErrorPrefix: "Provided",
            useFallbackStack: !1
        });
        return e.message = i, {
            api: n,
            message: i,
            handlingStack: r,
            error: e
        };
    }
    return {
        api: n,
        message: i,
        error: void 0,
        handlingStack: r
    };
}

function uo(e) {
    return typeof e == "string" ? U(e) : Mr(e) ? sr(zn(e)) : mr(U(e), void 0, 2);
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/boundedBuffer.js
var fo = 500;

function po() {
    let e = [];
    return {
        add: (t) => {
            e.push(t) > fo && e.splice(0, 1);
        },
        remove: (t) => {
            la(e, t);
        },
        drain: (t) => {
            e.forEach((e) => e(t)), e.length = 0;
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/context/contextUtils.js
function mo(e) {
    let t = tn(e) === "object";
    return t || i.error("Unsupported context:", e), t;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/context/contextManager.js
function ho(e, t, n) {
    let r = { ...e
    };
    for (let [e, {
            required: a,
            type: o
        }] of Object.entries(t)) o === "string" && !go(r[e]) && (r[e] = String(r[e])), a && go(r[e]) && i.warn(`The property ${e} of ${n} is required; context will not be sent to the intake.`);
    return r;
}

function go(e) {
    return e == null || e === "";
}

function _o(e = "", {
    propertiesConfig: t = {}
} = {}) {
    let n = {},
        r = new D(),
        i = {
            getContext: () => ri(n),
            setContext: (a) => {
                mo(a) ? n = U(ho(a, t, e)) : i.clearContext(), r.notify();
            },
            setContextProperty: (i, a) => {
                n = U(ho({
                    ...n,
                    [i]: a
                }, t, e)), r.notify();
            },
            removeContextProperty: (i) => {
                delete n[i], ho(n, t, e), r.notify();
            },
            clearContext: () => {
                n = {}, r.notify();
            },
            changeObservable: r
        };
    return i;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/context/defineContextMethod.js
function q(e, t, n, r) {
    return C((...i) => (r && K({
        feature: r
    }), e()[t][n](...i)));
}

function vo(e, t, n) {
    e.changeObservable.subscribe(() => {
        let r = e.getContext();
        n.add((e) => e[t].setContext(r));
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/context/storeContextManager.js
var yo = "_dd_c",
    bo = [];

function xo(e, t, n, r) {
    let i = So(n, r);
    bo.push(W(e, window, "storage", ({
        key: e
    }) => {
        i === e && o();
    })), t.changeObservable.subscribe(s);
    let a = ii(c(), t.getContext());
    g(a) || t.setContext(a);

    function o() {
        t.setContext(c());
    }

    function s() {
        localStorage.setItem(i, JSON.stringify(t.getContext()));
    }

    function c() {
        let e = localStorage.getItem(i);
        return e ? JSON.parse(e) : {};
    }
}

function So(e, t) {
    return `${yo}_${e}_${t}`;
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/contexts/accountContext.js
function Co(e, t, n) {
    let r = wo();
    return t.storeContextsAcrossPages && xo(t, r, n, 4), e.register(0, () => {
        let e = r.getContext();
        return g(e) || !e.id ? G : {
            account: e
        };
    }), r;
}

function wo() {
    return _o("account", {
        propertiesConfig: {
            id: {
                type: "string",
                required: !0
            },
            name: {
                type: "string"
            }
        }
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/contexts/globalContext.js
function To(e, t, n, r) {
    let i = Eo();
    return t.storeContextsAcrossPages && xo(t, i, n, 2), e.register(0, () => {
        let e = i.getContext();
        return r ? {
            context: e
        } : e;
    }), i;
}

function Eo() {
    return _o("global context");
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/contexts/userContext.js
function Do(e, t, n, r) {
    let i = Oo();
    return t.storeContextsAcrossPages && xo(t, i, r, 1), e.register(0, ({
        eventType: e,
        startTime: r
    }) => {
        let a = i.getContext(),
            o = n.findTrackedSession(r);
        return o && o.anonymousId && !a.anonymous_id && t.trackAnonymousUser && (a.anonymous_id = o.anonymousId), g(a) ? G : {
            type: e,
            usr: a
        };
    }), e.register(1, ({
        startTime: e
    }) => ({
        anonymous_id: n.findTrackedSession(e) ? .anonymousId
    })), i;
}

function Oo() {
    return _o("user", {
        propertiesConfig: {
            id: {
                type: "string"
            },
            name: {
                type: "string"
            },
            email: {
                type: "string"
            }
        }
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/domain/context/contextConstants.js
var J = {
        userContext: "userContext",
        globalContext: "globalContext",
        accountContext: "accountContext"
    },
    Y = {
        getContext: "getContext",
        setContext: "setContext",
        setContextProperty: "setContextProperty",
        removeContextProperty: "removeContextProperty",
        clearContext: "clearContext"
    },
    X = {
        DOCUMENT: "document",
        XHR: "xhr",
        BEACON: "beacon",
        FETCH: "fetch",
        CSS: "css",
        JS: "js",
        IMAGE: "image",
        FONT: "font",
        MEDIA: "media",
        OTHER: "other"
    },
    ko = {
        FETCH: X.FETCH,
        XHR: X.XHR
    },
    Ao = 500;

function jo() {
    let e = new ue(Ao),
        t = z(Fr)().subscribe((t) => {
            e.notify({
                type: 0,
                error: t
            });
        });
    return {
        observable: e,
        stop: () => {
            t.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-core/esm/tools/utils/timezone.js
function Mo() {
    try {
        return new Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch {
        return;
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/rawRumEvent.types.js
var Z = {
        ACTION: "action",
        ERROR: "error",
        LONG_TASK: "long_task",
        VIEW: "view",
        RESOURCE: "resource",
        VITAL: "vital"
    },
    No = {
        LONG_TASK: "long-task",
        LONG_ANIMATION_FRAME: "long-animation-frame"
    },
    Po = {
        INITIAL_LOAD: "initial_load",
        ROUTE_CHANGE: "route_change",
        BF_CACHE: "bf_cache"
    },
    Fo = {
        CLICK: "click",
        CUSTOM: "custom",
        TAP: "tap",
        SCROLL: "scroll",
        SWIPE: "swipe",
        APPLICATION_START: "application_start",
        BACK: "back"
    },
    Io = {
        RAGE_CLICK: "rage_click",
        ERROR_CLICK: "error_click",
        DEAD_CLICK: "dead_click"
    },
    Lo = {
        DURATION: "duration",
        OPERATION_STEP: "operation_step"
    };
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/vital/vitalCollection.js
function Ro() {
    return {
        vitalsByName: /* @__PURE__ */ new Map(),
        vitalsByReference: /* @__PURE__ */ new WeakMap()
    };
}

function zo(e, t, n) {
    function r(e) {
        return !t.wasInPageStateDuringPeriod("frozen", e.startClocks.relative, e.duration);
    }

    function i(t) {
        r(t) && e.notify(12, Uo(t));
    }

    function a(t, n, r, i) {
        if (!V(B.FEATURE_OPERATION_VITAL)) return;
        let {
            operationKey: a,
            context: o,
            description: s,
            handlingStack: c
        } = r || {}, l = {
            name: t,
            type: Lo.OPERATION_STEP,
            operationKey: a,
            failureReason: i,
            stepType: n,
            startClocks: P(),
            context: U(o),
            description: s,
            handlingStack: c
        };
        e.notify(12, Uo(l));
    }
    return {
        addOperationStepVital: a,
        addDurationVital: i,
        startDurationVital: (t, r = {}) => {
            let i = Bo(n, t, r),
                a = n.vitalsByReference.get(i);
            return a && e.notify(16, a), i;
        },
        stopDurationVital: (e, t = {}) => {
            Vo(i, n, e, t);
        }
    };
}

function Bo({
    vitalsByName: e,
    vitalsByReference: t
}, n, r = {}) {
    let i = {
            id: L(),
            name: n,
            startClocks: P(),
            ...r
        },
        a = {
            __dd_vital_reference: !0
        };
    return e.set(n, i), t.set(a, i), a;
}

function Vo(e, {
    vitalsByName: t,
    vitalsByReference: n
}, r, i = {}) {
    let a = typeof r == "string" ? t.get(r) : n.get(r);
    a && (e(Ho(a, a.startClocks, i, P())), typeof r == "string" ? t.delete(r) : n.delete(r));
}

function Ho(e, t, n, r) {
    return {
        id: e.id,
        name: e.name,
        type: Lo.DURATION,
        startClocks: t,
        duration: F(t.timeStamp, r.timeStamp),
        context: ii(e.context, n.context),
        description: n.description ? ? e.description,
        handlingStack: e.handlingStack
    };
}

function Uo(e) {
    let {
        startClocks: t,
        type: n,
        name: r,
        description: i,
        context: a,
        handlingStack: o
    } = e, s = {
        id: (e.type === Lo.DURATION ? e.id : void 0) ? ? L(),
        type: n,
        name: r,
        description: i,
        ...n === Lo.DURATION ? {
            duration: A(e.duration)
        } : {
            step_type: e.stepType,
            operation_key: e.operationKey,
            failure_reason: e.failureReason
        }
    };
    return {
        rawRumEvent: {
            date: t.timeStamp,
            vital: s,
            type: Z.VITAL,
            context: a
        },
        startClocks: t,
        duration: n === Lo.DURATION ? e.duration : void 0,
        domainContext: o ? {
            handlingStack: o
        } : {}
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/plugins.js
function Wo(e, t, n) {
    if (e)
        for (let r of e) {
            let e = r[t];
            e && e(n);
        }
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/hooks.js
var Go = Ui,
    Ko = ["tracecontext", "datadog"];

function qo(e, t) {
    if (e.trackFeatureFlagsForEvents !== void 0 && !Array.isArray(e.trackFeatureFlagsForEvents) && i.warn("trackFeatureFlagsForEvents should be an array"), !e.applicationId) {
        i.error("Application ID is not configured, no RUM data will be collected.");
        return;
    }
    if (!jn(e.sessionReplaySampleRate, "Session Replay") || !jn(e.traceSampleRate, "Trace")) return;
    if (e.excludedActivityUrls !== void 0 && !Array.isArray(e.excludedActivityUrls)) {
        i.error("Excluded Activity Urls should be an array");
        return;
    }
    let n = Jo(e);
    if (!n) return;
    let r = Mn(e, t),
        a = Zo(e);
    if (!r) return;
    let o = e.sessionReplaySampleRate ? ? 0;
    return {
        applicationId: e.applicationId,
        actionNameAttribute: e.actionNameAttribute,
        betaTrackActionsInShadowDom: !!e.betaTrackActionsInShadowDom,
        sessionReplaySampleRate: o,
        startSessionReplayRecordingManually: e.startSessionReplayRecordingManually === void 0 ? o === 0 : !!e.startSessionReplayRecordingManually,
        traceSampleRate: e.traceSampleRate ? ? 100,
        rulePsr: f(e.traceSampleRate) ? e.traceSampleRate / 100 : void 0,
        allowedTracingUrls: n,
        excludedActivityUrls: e.excludedActivityUrls ? ? [],
        workerUrl: e.workerUrl,
        compressIntakeRequests: !!e.compressIntakeRequests,
        trackUserInteractions: !!(e.trackUserInteractions ? ? !0),
        trackViewsManually: !!e.trackViewsManually,
        trackResources: !!(e.trackResources ? ? !0),
        trackLongTasks: !!(e.trackLongTasks ? ? !0),
        trackBfcacheViews: !!e.trackBfcacheViews,
        trackEarlyRequests: !!e.trackEarlyRequests,
        subdomain: e.subdomain,
        defaultPrivacyLevel: h(Dn, e.defaultPrivacyLevel) ? e.defaultPrivacyLevel : Dn.MASK,
        enablePrivacyForActionName: !!e.enablePrivacyForActionName,
        traceContextInjection: h(On, e.traceContextInjection) ? e.traceContextInjection : On.SAMPLED,
        plugins: e.plugins || [],
        trackFeatureFlagsForEvents: e.trackFeatureFlagsForEvents || [],
        profilingSampleRate: e.profilingSampleRate ? ? 0,
        propagateTraceBaggage: !!e.propagateTraceBaggage,
        allowedGraphQlUrls: a,
        ...r
    };
}

function Jo(e) {
    if (e.allowedTracingUrls === void 0) return [];
    if (!Array.isArray(e.allowedTracingUrls)) {
        i.error("Allowed Tracing URLs should be an array");
        return;
    }
    if (e.allowedTracingUrls.length !== 0 && e.service === void 0) {
        i.error("Service needs to be configured when tracing is enabled");
        return;
    }
    let t = [];
    return e.allowedTracingUrls.forEach((e) => {
        let n = Xo(e);
        n ? t.push(n) : i.warn("Allowed Tracing Urls parameters should be a string, RegExp, function, or an object. Ignoring parameter", e);
    }), t;
}

function Yo(e) {
    let t = /* @__PURE__ */ new Set();
    return ua(e.allowedTracingUrls) && e.allowedTracingUrls.forEach((e) => {
        var n;
        (n = Xo(e)) == null || n.propagatorTypes.forEach((e) => t.add(e));
    }), Array.from(t);
}

function Xo(e) {
    if (rn(e)) return {
        match: e,
        propagatorTypes: Ko
    };
    if (nn(e) && rn(e.match) && (e.propagatorTypes === null || e.propagatorTypes === void 0 || Array.isArray(e.propagatorTypes))) return {
        match: e.match,
        propagatorTypes: e.propagatorTypes || Ko
    };
}

function Zo(e) {
    if (!e.allowedGraphQlUrls) return [];
    if (!Array.isArray(e.allowedGraphQlUrls)) return i.warn("allowedGraphQlUrls should be an array"), [];
    let t = [];
    return e.allowedGraphQlUrls.forEach((e) => {
        rn(e) ? t.push({
            match: e,
            trackPayload: !1,
            trackResponseErrors: !1
        }) : nn(e) && rn(e.match) && t.push({
            match: e.match,
            trackPayload: !!e.trackPayload,
            trackResponseErrors: !!e.trackResponseErrors
        });
    }), t;
}

function Qo(e) {
    return ua(e) && e.some((e) => nn(e) && e.trackPayload);
}

function $o(e) {
    return ua(e) && e.some((e) => nn(e) && e.trackResponseErrors);
}

function es(e) {
    let t = Nn(e);
    return {
        session_replay_sample_rate: e.sessionReplaySampleRate,
        start_session_replay_recording_manually: e.startSessionReplayRecordingManually,
        trace_sample_rate: e.traceSampleRate,
        trace_context_injection: e.traceContextInjection,
        propagate_trace_baggage: e.propagateTraceBaggage,
        action_name_attribute: e.actionNameAttribute,
        use_allowed_tracing_urls: ua(e.allowedTracingUrls),
        use_allowed_graph_ql_urls: ua(e.allowedGraphQlUrls),
        use_track_graph_ql_payload: Qo(e.allowedGraphQlUrls),
        use_track_graph_ql_response_errors: $o(e.allowedGraphQlUrls),
        selected_tracing_propagators: Yo(e),
        default_privacy_level: e.defaultPrivacyLevel,
        enable_privacy_for_action_name: e.enablePrivacyForActionName,
        use_excluded_activity_urls: ua(e.excludedActivityUrls),
        use_worker_url: !!e.workerUrl,
        compress_intake_requests: e.compressIntakeRequests,
        track_views_manually: e.trackViewsManually,
        track_user_interactions: e.trackUserInteractions,
        track_resources: e.trackResources,
        track_long_task: e.trackLongTasks,
        track_bfcache_views: e.trackBfcacheViews,
        track_early_requests: e.trackEarlyRequests,
        plugins: e.plugins ? .map((e) => ({
            name: e.name,
            ...e.getConfigurationTelemetry ? .call(e)
        })),
        track_feature_flags_for_events: e.trackFeatureFlagsForEvents,
        remote_configuration_id: e.remoteConfigurationId,
        profiling_sample_rate: e.profilingSampleRate,
        use_remote_configuration_proxy: !!e.remoteConfigurationProxy,
        ...t
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/configuration/jsonPathParser.js
function ts(e) {
    let t = [],
        n = 0,
        r, i = {
            quote: void 0,
            escapeSequence: void 0
        },
        a = "";
    for (let o of e) {
        if (r = cs[n].find((e) => ss[e](o, i)), !r) return [];
        if (i.escapeSequence !== void 0 && r !== 12) {
            if (!ds(i.escapeSequence)) return [];
            a += ps(i.escapeSequence), i.escapeSequence = void 0;
        }
        ls.includes(r) ? a += o : us.includes(r) && a !== "" ? (t.push(a), a = "") : r === 12 ? i.escapeSequence = i.escapeSequence ? `${i.escapeSequence}${o}` : o : r === 8 ? i.quote = o : r === 9 && (i.quote = void 0), n = r;
    }
    return cs[n].includes(1) ? (a !== "" && t.push(a), t) : [];
}
var ns = /[a-zA-Z_$]/,
    rs = /[a-zA-Z0-9_$]/,
    is = /[0-9]/,
    as = /[a-fA-F0-9]/,
    os = "'\"",
    ss = {
        0: () => !1,
        1: () => !1,
        2: (e) => ns.test(e),
        3: (e) => rs.test(e),
        4: (e) => e === ".",
        5: (e) => e === "[",
        6: (e) => e === "]",
        7: (e) => is.test(e),
        8: (e) => os.includes(e),
        9: (e, t) => e === t.quote,
        10: () => !0,
        11: (e) => e === "\\",
        12: (e, t) => t.escapeSequence === void 0 ? `${t.quote}/\\bfnrtu`.includes(e) : t.escapeSequence.startsWith("u") && t.escapeSequence.length < 5 ? as.test(e) : !1
    },
    cs = {
        0: [2, 5],
        1: [],
        2: [
            3,
            4,
            5,
            1
        ],
        3: [
            3,
            4,
            5,
            1
        ],
        4: [2],
        5: [8, 7],
        6: [
            4,
            5,
            1
        ],
        7: [7, 6],
        8: [
            11,
            9,
            10
        ],
        9: [6],
        10: [
            11,
            9,
            10
        ],
        11: [12],
        12: [
            12,
            11,
            9,
            10
        ]
    },
    ls = [
        2,
        3,
        7,
        10
    ],
    us = [
        4,
        5,
        6
    ];

function ds(e) {
    return "\"'/\\bfnrt".includes(e) || e.startsWith("u") && e.length === 5;
}
var fs = {
    "\"": "\"",
    "'": "'",
    "/": "/",
    "\\": "\\",
    b: "\b",
    f: "\f",
    n: "\n",
    r: "\r",
    t: "	"
};

function ps(e) {
    return e.startsWith("u") ? String.fromCharCode(parseInt(e.slice(1), 16)) : fs[e];
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/configuration/remoteConfiguration.js
var ms = "v1",
    hs = [
        "applicationId",
        "service",
        "env",
        "version",
        "sessionSampleRate",
        "sessionReplaySampleRate",
        "defaultPrivacyLevel",
        "enablePrivacyForActionName",
        "traceSampleRate",
        "trackSessionAcrossSubdomains",
        "allowedTracingUrls",
        "allowedTrackingOrigins"
    ];
async function gs(e, t) {
    let n, r = vs(),
        a = await Ss(e);
    return a.ok ? (r.increment("fetch", "success"), n = _s(e, a.value, t, r)) : (r.increment("fetch", "failure"), i.error(a.error)), aa("remote configuration metrics", {
        metrics: r.get()
    }), n;
}

function _s(e, t, n, r) {
    let a = { ...e
    };
    return hs.forEach((e) => {
        e in t && (a[e] = o(t[e]));
    }), Object.keys(n).forEach((e) => {
        t[e] !== void 0 && s(n[e], t[e]);
    }), a;

    function o(e) {
        if (Array.isArray(e)) return e.map(o);
        if (nn(e)) {
            if (ys(e)) {
                let t = e.rcSerializedType;
                switch (t) {
                    case "string":
                        return e.value;
                    case "regex":
                        return bs(e.value);
                    case "dynamic":
                        return c(e);
                    default:
                        i.error(`Unsupported remote configuration: "rcSerializedType": "${t}"`);
                        return;
                }
            }
            return _(e, o);
        }
        return e;
    }

    function s(e, t) {
        t.forEach(({
            key: t,
            value: n
        }) => {
            e.setContextProperty(t, o(n));
        });
    }

    function c(e) {
        let t = e.strategy,
            n;
        switch (t) {
            case "cookie":
                n = l(e);
                break;
            case "dom":
                n = d(e);
                break;
            case "js":
                n = p(e);
                break;
            case "localStorage":
                n = u(e);
                break;
            default:
                i.error(`Unsupported remote configuration: "strategy": "${t}"`);
                return;
        }
        let r = e.extractor;
        return r !== void 0 && typeof n == "string" ? xs(r, n) : n;
    }

    function l({
        name: e
    }) {
        let t = He(e);
        return r.increment("cookie", t === void 0 ? "missing" : "success"), t;
    }

    function u({
        key: e
    }) {
        let t;
        try {
            t = localStorage.getItem(e);
        } catch {
            r.increment("localStorage", "failure");
            return;
        }
        return r.increment("localStorage", t === null ? "missing" : "success"), t ? ? void 0;
    }

    function d({
        selector: e,
        attribute: t
    }) {
        let n;
        try {
            n = document.querySelector(e);
        } catch {
            i.error(`Invalid selector in the remote configuration: '${e}'`), r.increment("dom", "failure");
            return;
        }
        if (!n) {
            r.increment("dom", "missing");
            return;
        }
        if (f(n, t)) {
            i.error(`Forbidden element selected by the remote configuration: '${e}'`), r.increment("dom", "failure");
            return;
        }
        let a = t === void 0 ? n.textContent : n.getAttribute(t);
        if (a === null) {
            r.increment("dom", "missing");
            return;
        }
        return r.increment("dom", "success"), a;
    }

    function f(e, t) {
        return e.getAttribute("type") === "password" && t === "value";
    }

    function p({
        path: e
    }) {
        let t = window,
            n = ts(e);
        if (n.length === 0) {
            i.error(`Invalid JSON path in the remote configuration: '${e}'`), r.increment("js", "failure");
            return;
        }
        for (let a of n) {
            if (!(a in t)) {
                r.increment("js", "missing");
                return;
            }
            try {
                t = t[a];
            } catch (t) {
                i.error(`Error accessing: '${e}'`, t), r.increment("js", "failure");
                return;
            }
        }
        return r.increment("js", "success"), t;
    }
}

function vs() {
    let e = {
        fetch: {}
    };
    return {
        get: () => e,
        increment: (t, n) => {
            e[t] || (e[t] = {}), e[t][n] || (e[t][n] = 0), e[t][n] = e[t][n] + 1;
        }
    };
}

function ys(e) {
    return "rcSerializedType" in e;
}

function bs(e) {
    try {
        return new RegExp(e);
    } catch {
        i.error(`Invalid regex in the remote configuration: '${e}'`);
    }
}

function xs(e, t) {
    let n = bs(e.value);
    if (n === void 0) return;
    let r = n.exec(t);
    if (r === null) return;
    let [i, a] = r;
    return a || i;
}
async function Ss(e) {
    let t;
    try {
        t = await si(Cs(e));
    } catch {
        t = void 0;
    }
    if (!t || !t.ok) return {
        ok: !1,
        error: /* @__PURE__ */ Error("Error fetching the remote configuration.")
    };
    let n = await t.json();
    return n.rum ? {
        ok: !0,
        value: n.rum
    } : {
        ok: !1,
        error: /* @__PURE__ */ Error("No remote configuration for RUM.")
    };
}

function Cs(e) {
    return e.remoteConfigurationProxy ? e.remoteConfigurationProxy : `https://sdk-configuration.${bn("rum", e)}/${ms}/${encodeURIComponent(e.remoteConfigurationId)}.json`;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/boot/preStartRum.js
function ws({
    ignoreInitIfSyntheticsWillInjectRum: e = !0,
    startDeflateWorker: t
}, n, r, a) {
    let o = po(),
        s = Eo();
    Es(s, J.globalContext, o);
    let c = Oo();
    Es(c, J.userContext, o);
    let l = wo();
    Es(l, J.accountContext, o);
    let u, d, f, p, m, h = Go(),
        g = n.observable.subscribe(v),
        _ = {};

    function v() {
        if (!f || !p || !n.isGranted()) return;
        m || = z(Zi)("browser-rum-sdk", p, h), g.unsubscribe();
        let e;
        if (p.trackViewsManually) {
            if (!u) return;
            o.remove(u.callback), e = u.options;
        }
        let t = a(p, d, e, m, h);
        o.drain(t);
    }

    function y(e, r) {
        let a = Ai();
        if (a && (e = Ts(e)), f = e, ia(es(e)), p) {
            Br("DD_RUM", e);
            return;
        }
        let o = qo(e, r);
        if (o) {
            if (!a && !o.sessionStoreStrategyType) {
                i.warn("No storage available for session. We will not send any data.");
                return;
            }
            o.compressIntakeRequests && !a && t && (d = t(o, "Datadog RUM", I), !d) || (p = o, Qa().subscribe(I), n.tryToInit(o.trackingConsent), v());
        }
    }
    let b = (e) => {
        o.add((t) => t.addDurationVital(e));
    };
    return {
        init(t, n, r) {
            if (!t) {
                i.error("Missing configuration");
                return;
            }
            Fn(t.enableExperimentalFeatures), f = t, !(e && Sa()) && (Wo(t.plugins, "onInit", {
                initConfiguration: t,
                publicApi: n
            }), t.remoteConfigurationId ? gs(t, {
                user: c,
                context: s
            }).then((e) => {
                e && y(e, r);
            }).catch(ie) : y(t, r));
        },
        get initConfiguration() {
            return f;
        },
        getInternalContext: I,
        stopSession: I,
        addTiming(e, t = M()) {
            o.add((n) => n.addTiming(e, t));
        },
        setLoadingTime: ((e) => {
            o.add((t) => t.setLoadingTime(e));
        }),
        startView(e, t = P()) {
            let n = (n) => {
                n.startView(e, t);
            };
            o.add(n), u || (u = {
                options: e,
                callback: n
            }, v());
        },
        setViewName(e) {
            o.add((t) => t.setViewName(e));
        },
        setViewContext(e) {
            o.add((t) => t.setViewContext(e));
        },
        setViewContextProperty(e, t) {
            o.add((n) => n.setViewContextProperty(e, t));
        },
        getViewContext: () => _,
        globalContext: s,
        userContext: c,
        accountContext: l,
        addAction(e) {
            o.add((t) => t.addAction(e));
        },
        startAction(e, t) {
            let n = P();
            o.add((r) => r.startAction(e, t, n));
        },
        stopAction(e, t) {
            let n = P();
            o.add((r) => r.stopAction(e, t, n));
        },
        startResource(e, t) {
            let n = P();
            o.add((r) => r.startResource(e, t, n));
        },
        stopResource(e, t) {
            let n = P();
            o.add((r) => r.stopResource(e, t, n));
        },
        addError(e) {
            o.add((t) => t.addError(e));
        },
        addFeatureFlagEvaluation(e, t) {
            o.add((n) => n.addFeatureFlagEvaluation(e, t));
        },
        startDurationVital(e, t) {
            return Bo(r, e, t);
        },
        stopDurationVital(e, t) {
            Vo(b, r, e, t);
        },
        addDurationVital: b,
        addOperationStepVital: (e, t, n, r) => {
            o.add((i) => i.addOperationStepVital(U(e), t, U(n), U(r)));
        }
    };
}

function Ts(e) {
    return {
        ...e,
        applicationId: "00000000-aaaa-0000-aaaa-000000000000",
        clientToken: "empty",
        sessionSampleRate: 100,
        defaultPrivacyLevel: e.defaultPrivacyLevel ? ? Oi() ? .getPrivacyLevel()
    };
}

function Es(e, t, n) {
    e.changeObservable.subscribe(() => {
        let r = e.getContext();
        n.add((e) => e[t].setContext(r));
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/domMutationObservable.js
function Ds() {
    let e = Os();
    return new D((t) => {
        if (!e) return;
        let n = new e(C((e) => t.notify(e)));
        return n.observe(document, {
            attributes: !0,
            characterData: !0,
            childList: !0,
            subtree: !0
        }), () => n.disconnect();
    });
}

function Os() {
    let e, t = window;
    if (t.Zone && (e = x(t, "MutationObserver"), t.MutationObserver && e === t.MutationObserver)) {
        let n = x(new t.MutationObserver(I), "originalInstance");
        e = n && n.constructor;
    }
    return e || = t.MutationObserver, e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/windowOpenObservable.js
function ks() {
    let e = new D(),
        {
            stop: t
        } = H(window, "open", () => e.notify());
    return {
        observable: e,
        stop: t
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/internalContext.js
function As(e, t, n, r, i) {
    return {
        get: (a) => {
            let o = n.findView(a),
                s = i.findUrl(a),
                c = t.findTrackedSession(a);
            if (c && o && s) {
                let t = r.findActionId(a);
                return {
                    application_id: e,
                    session_id: c.id,
                    user_action: t ? {
                        id: t
                    } : void 0,
                    view: {
                        id: o.id,
                        name: o.name,
                        referrer: s.referrer,
                        url: s.url
                    }
                };
            }
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/lifeCycle.js
var js = La,
    Ms = tt;

function Ns(e) {
    let t = ga({
        expireDelay: Ms
    });
    e.subscribe(1, (e) => {
        t.add(n(e), e.startClocks.relative);
    }), e.subscribe(6, ({
        endClocks: e
    }) => {
        t.closeActive(e.relative);
    }), e.subscribe(3, (e) => {
        let n = t.find(e.startClocks.relative);
        n && (e.name && (n.name = e.name), e.context && (n.context = e.context), n.sessionIsActive = e.sessionIsActive);
    }), e.subscribe(10, () => {
        t.reset();
    });

    function n(e) {
        return {
            service: e.service,
            version: e.version,
            context: e.context,
            id: e.id,
            name: e.name,
            startClocks: e.startClocks
        };
    }
    return {
        findView: (e) => t.find(e),
        stop: () => {
            t.stop();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/resource/resourceUtils.js
var Ps = "initial_document",
    Fs = [
        [X.DOCUMENT, (e) => Ps === e],
        [X.XHR, (e) => e === "xmlhttprequest"],
        [X.FETCH, (e) => e === "fetch"],
        [X.BEACON, (e) => e === "beacon"],
        [X.CSS, (e, t) => /\.css$/i.test(t)],
        [X.JS, (e, t) => /\.js$/i.test(t)],
        [X.IMAGE, (e, t) => [
            "image",
            "img",
            "icon"
        ].includes(e) || /\.(gif|jpg|jpeg|tiff|png|svg|ico)$/i.exec(t) !== null],
        [X.FONT, (e, t) => /\.(woff|eot|woff2|ttf)$/i.exec(t) !== null],
        [X.MEDIA, (e, t) => ["audio", "video"].includes(e) || /\.(mp3|mp4)$/i.exec(t) !== null]
    ];

function Is(e) {
    let t = e.name;
    if (!Ie(t)) return X.OTHER;
    let n = Le(t);
    for (let [t, r] of Fs)
        if (r(e.initiatorType, n)) return t;
    return X.OTHER;
}

function Ls(...e) {
    for (let t = 1; t < e.length; t += 1)
        if (e[t - 1] > e[t]) return !1;
    return !0;
}

function Rs(e) {
    return e.initiatorType === "xmlhttprequest" || e.initiatorType === "fetch";
}

function zs(e) {
    let {
        duration: t,
        startTime: n,
        responseEnd: r
    } = e;
    return t === 0 && n < r ? F(n, r) : t;
}

function Bs(e) {
    if (!Hs(e)) return;
    let {
        startTime: t,
        fetchStart: n,
        workerStart: r,
        redirectStart: i,
        redirectEnd: a,
        domainLookupStart: o,
        domainLookupEnd: s,
        connectStart: c,
        secureConnectionStart: l,
        connectEnd: u,
        requestStart: d,
        responseStart: f,
        responseEnd: p
    } = e, m = {
        download: Ws(t, f, p),
        first_byte: Ws(t, d, f)
    };
    return 0 < r && r < n && (m.worker = Ws(t, r, n)), n < u && (m.connect = Ws(t, c, u), c <= l && l <= u && (m.ssl = Ws(t, l, u))), n < s && (m.dns = Ws(t, o, s)), t < a && (m.redirect = Ws(t, i, a)), m;
}

function Vs(e) {
    return e.duration >= 0;
}

function Hs(e) {
    let t = Ls(e.startTime, e.fetchStart, e.domainLookupStart, e.domainLookupEnd, e.connectStart, e.connectEnd, e.requestStart, e.responseStart, e.responseEnd),
        n = Us(e) ? Ls(e.startTime, e.redirectStart, e.redirectEnd, e.fetchStart) : !0;
    return t && n;
}

function Us(e) {
    return e.redirectEnd > e.startTime;
}

function Ws(e, t, n) {
    if (e <= t && t <= n) return {
        duration: A(F(t, n)),
        start: A(F(e, t))
    };
}

function Gs(e) {
    return e.nextHopProtocol === "" ? void 0 : e.nextHopProtocol;
}

function Ks(e) {
    return e.deliveryType === "" ? "other" : e.deliveryType;
}

function qs(e) {
    if (e.startTime < e.responseStart) {
        let {
            encodedBodySize: t,
            decodedBodySize: n,
            transferSize: r
        } = e;
        return {
            size: n,
            encoded_body_size: t,
            decoded_body_size: n,
            transfer_size: r
        };
    }
    return {
        size: void 0,
        encoded_body_size: void 0,
        decoded_body_size: void 0,
        transfer_size: void 0
    };
}

function Js(e) {
    return e && (!En(e) || V(B.TRACK_INTAKE_REQUESTS));
}
var Ys = /data:(.+)?(;base64)?,/g,
    Xs = 24e3;

function Zs(e, t = Xs) {
    if (e.length <= t || !e.startsWith("data:")) return e;
    let n = e.substring(0, 100).match(Ys);
    return n ? `${n[0]}[...]` : e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/sampler/sampler.js
var Qs = /* @__PURE__ */ new Map();

function $s(e, t) {
    if (t === 100) return !0;
    if (t === 0) return !1;
    let n = Qs.get(t);
    if (n && e === n.sessionId) return n.decision;
    let r;
    return r = window.BigInt ? ec(BigInt(`0x${e.split("-")[4]}`), t) : l(t), Qs.set(t, {
        sessionId: e,
        decision: r
    }), r;
}

function ec(e, t) {
    let n = BigInt("1111111111111111111"),
        r = BigInt("0x10000000000000000"),
        i = e * n % r;
    return Number(i) <= t / 100 * Number(r);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/tracing/identifier.js
function tc() {
    return rc(64);
}

function nc() {
    return rc(63);
}

function rc(e) {
    let t = crypto.getRandomValues(new Uint32Array(2));
    return e === 63 && (t[t.length - 1] >>>= 1), {
        toString(e = 10) {
            let n = t[1],
                r = t[0],
                i = "";
            do {
                let t = n % e * 4294967296 + r;
                n = Math.floor(n / e), r = Math.floor(t / e), i = (t % e).toString(e) + i;
            } while (n || r);
            return i;
        }
    };
}

function ic(e) {
    return e.toString(16).padStart(16, "0");
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/tracing/tracer.js
function ac(e) {
    e.status === 0 && !e.isAborted && (e.traceId = void 0, e.spanId = void 0, e.traceSampled = void 0);
}

function oc(e, t, n, r) {
    return {
        clearTracingIfNeeded: ac,
        traceFetch: (i) => sc(e, i, t, n, r, (e) => {
            if (i.input instanceof Request && !i.init ? .headers) i.input = new Request(i.input), Object.keys(e).forEach((t) => {
                i.input.headers.append(t, e[t]);
            });
            else {
                i.init = m(i.init);
                let t = [];
                i.init.headers instanceof Headers ? i.init.headers.forEach((e, n) => {
                    t.push([n, e]);
                }) : Array.isArray(i.init.headers) ? i.init.headers.forEach((e) => {
                    t.push(e);
                }) : i.init.headers && Object.keys(i.init.headers).forEach((e) => {
                    t.push([e, i.init.headers[e]]);
                }), i.init.headers = t.concat(et(e));
            }
        }),
        traceXhr: (i, a) => sc(e, i, t, n, r, (e) => {
            Object.keys(e).forEach((t) => {
                a.setRequestHeader(t, e[t]);
            });
        })
    };
}

function sc(e, t, n, r, i, a) {
    let o = n.findTrackedSession();
    if (!o) return;
    let s = e.allowedTracingUrls.find((e) => an([e.match], t.url, !0));
    if (!s) return;
    let c = $s(o.id, e.traceSampleRate);
    (c || e.traceContextInjection === On.ALL) && (t.traceSampled = c, t.traceId = tc(), t.spanId = nc(), a(cc(t.traceId, t.spanId, t.traceSampled, o.id, s.propagatorTypes, r, i, e)));
}

function cc(e, t, n, r, i, a, o, s) {
    let c = {};
    if (i.forEach((r) => {
            switch (r) {
                case "datadog":
                    Object.assign(c, {
                        "x-datadog-origin": "rum",
                        "x-datadog-parent-id": t.toString(),
                        "x-datadog-sampling-priority": n ? "1" : "0",
                        "x-datadog-trace-id": e.toString()
                    });
                    break;
                case "tracecontext":
                    Object.assign(c, {
                        traceparent: `00-0000000000000000${ic(e)}-${ic(t)}-0${n ? "1" : "0"}`,
                        tracestate: `dd=s:${n ? "1" : "0"};o:rum`
                    });
                    break;
                case "b3":
                    Object.assign(c, {
                        b3: `${ic(e)}-${ic(t)}-${n ? "1" : "0"}`
                    });
                    break;
                case "b3multi":
                    Object.assign(c, {
                        "X-B3-TraceId": ic(e),
                        "X-B3-SpanId": ic(t),
                        "X-B3-Sampled": n ? "1" : "0"
                    });
                    break;
            }
        }), s.propagateTraceBaggage) {
        let e = {
                "session.id": r
            },
            t = a.getContext().id;
        typeof t == "string" && (e["user.id"] = t);
        let n = o.getContext().id;
        typeof n == "string" && (e["account.id"] = n);
        let i = Object.entries(e).map(([e, t]) => `${e}=${encodeURIComponent(t)}`).join(",");
        i && (c.baggage = i);
    }
    return c;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/resource/graphql.js
var lc = 32 * lr;

function uc(e, t) {
    let n = pc(e, t.trackPayload);
    if (n) {
        if (t.trackResponseErrors && e.responseBody) {
            let t = dc(e.responseBody);
            t && (n.error_count = t.length, n.errors = t);
        }
        return n;
    }
}

function dc(e) {
    let t = p(e);
    if (!t || typeof t != "object") return;
    let n = t;
    if (ua(n.errors)) return n.errors.map((e) => ({
        message: e.message,
        path: e.path,
        locations: e.locations,
        code: e.extensions ? .code
    }));
}

function fc(e, t) {
    return t.allowedGraphQlUrls.find((t) => an([t.match], e));
}

function pc(e, t = !1) {
    let n;
    if (e.method === "POST" ? n = mc(e.requestBody) : e.method === "GET" && (n = hc(e.url)), n) return gc(n, t);
}

function mc(e) {
    if (!e || typeof e != "string") return;
    let t = p(e);
    if (t) return {
        query: t.query,
        operationName: t.operationName,
        variables: t.variables ? JSON.stringify(t.variables) : void 0
    };
}

function hc(e) {
    let t = Re(e).searchParams,
        n = t.get("variables"),
        r = n && p(n) !== void 0 ? n : void 0;
    return {
        query: t.get("query") || void 0,
        operationName: t.get("operationName") || void 0,
        variables: r
    };
}

function gc(e, t) {
    let n, r, i;
    if (e.query) {
        let i = e.query.trim();
        n = _c(i), t && (r = ke(i, lc, "..."));
    }
    return e.variables && (i = e.variables), {
        operationType: n,
        operationName: e.operationName,
        variables: i,
        payload: r
    };
}

function _c(e) {
    return e.match(/^\s*(query|mutation|subscription)\b/i) ? .[1];
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/requestCollection.js
var vc = 1;

function yc(e, t, n, r, i) {
    let a = oc(t, n, r, i);
    bc(e, t, a), xc(e, t, a);
}

function bc(e, t, n) {
    let r = Wa(t).subscribe((t) => {
        let r = t;
        if (Js(r.url)) switch (r.state) {
            case "start":
                n.traceXhr(r, r.xhr), r.requestIndex = Sc(), e.notify(7, {
                    requestIndex: r.requestIndex,
                    url: r.url
                });
                break;
            case "complete":
                n.clearTracingIfNeeded(r), e.notify(8, {
                    ...r,
                    type: ko.XHR,
                    isAbortedOnStart: !1
                });
                break;
        }
    });
    return {
        stop: () => r.unsubscribe()
    };
}

function xc(e, t, n) {
    let r = Qa({
        responseBodyAction: (e) => fc(e.url, t) ? .trackResponseErrors ? 2 : 1
    }).subscribe((t) => {
        let r = t;
        if (Js(r.url)) switch (r.state) {
            case "start":
                n.traceFetch(r), r.requestIndex = Sc(), e.notify(7, {
                    requestIndex: r.requestIndex,
                    url: r.url
                });
                break;
            case "resolve":
                n.clearTracingIfNeeded(r), e.notify(8, {
                    ...r,
                    duration: F(r.startClocks.timeStamp, M()),
                    type: ko.FETCH,
                    requestBody: r.init ? .body
                });
                break;
        }
    });
    return {
        stop: () => r.unsubscribe()
    };
}

function Sc() {
    let e = vc;
    return vc += 1, e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/discardNegativeDuration.js
function Cc(e) {
    return f(e) && e < 0 ? void 0 : e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/htmlDomUtils.js
function wc(e) {
    return e.nodeType === Node.TEXT_NODE;
}

function Tc(e) {
    return e.nodeType === Node.COMMENT_NODE;
}

function Ec(e) {
    return e.nodeType === Node.ELEMENT_NODE;
}

function Dc(e) {
    return Ec(e) && !!e.shadowRoot;
}

function Oc(e) {
    let t = e;
    return !!t.host && t.nodeType === Node.DOCUMENT_FRAGMENT_NODE && Ec(t.host);
}

function kc(e) {
    return e.childNodes.length > 0 || Dc(e);
}

function Ac(e, t) {
    let n = e.firstChild;
    for (; n;) t(n), n = n.nextSibling;
    Dc(e) && t(e.shadowRoot);
}

function jc(e) {
    return Oc(e) ? e.host : e.parentNode;
}

function Mc(e) {
    if (e.parentElement) return e.parentElement;
    let t = e.parentNode;
    return t && Oc(t) ? t.host : null;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/firstInputPolyfill.js
function Nc(e, t) {
    let n = j(),
        r = !1,
        {
            stop: i
        } = Vr(e, window, [
            "click",
            "mousedown",
            "keydown",
            "touchstart",
            "pointerdown"
        ], (t) => {
            if (!t.cancelable) return;
            let n = {
                entryType: "first-input",
                processingStart: N(),
                processingEnd: N(),
                startTime: t.timeStamp,
                duration: 0,
                name: "",
                cancelable: !1,
                target: null,
                toJSON: () => ({})
            };
            t.type === "pointerdown" ? a(e, n) : o(n);
        }, {
            passive: !0,
            capture: !0
        });
    return {
        stop: i
    };

    function a(e, t) {
        Vr(e, window, ["pointerup", "pointercancel"], (e) => {
            e.type === "pointerup" && o(t);
        }, {
            once: !0
        });
    }

    function o(e) {
        if (!r) {
            r = !0, i();
            let a = e.processingStart - e.startTime;
            a >= 0 && a < j() - n && t(e);
        }
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/performanceObservable.js
var Q;
(function(e) {
    e.EVENT = "event", e.FIRST_INPUT = "first-input", e.LARGEST_CONTENTFUL_PAINT = "largest-contentful-paint", e.LAYOUT_SHIFT = "layout-shift", e.LONG_TASK = "longtask", e.LONG_ANIMATION_FRAME = "long-animation-frame", e.NAVIGATION = "navigation", e.PAINT = "paint", e.RESOURCE = "resource", e.VISIBILITY_STATE = "visibility-state";
})(Q || = {});

function Pc(e, t) {
    return new D((n) => {
        if (!window.PerformanceObserver) return;
        let r = (e) => {
                let t = zc(e);
                t.length > 0 && n.notify(t);
            },
            i, a = !0,
            o = new PerformanceObserver(C((e) => {
                a ? i = T(() => r(e.getEntries())) : r(e.getEntries());
            }));
        try {
            o.observe(t);
        } catch {
            if ([
                    Q.RESOURCE,
                    Q.NAVIGATION,
                    Q.LONG_TASK,
                    Q.PAINT
                ].includes(t.type)) {
                t.buffered && (i = T(() => r(performance.getEntriesByType(t.type))));
                try {
                    o.observe({
                        entryTypes: [t.type]
                    });
                } catch {
                    return;
                }
            }
        }
        a = !1, Ic(e);
        let s;
        return !Rc(Q.FIRST_INPUT) && t.type === Q.FIRST_INPUT && ({
            stop: s
        } = Nc(e, (e) => {
            r([e]);
        })), () => {
            o.disconnect(), s && s(), E(i);
        };
    });
}
var Fc;

function Ic(e) {
    return !Fc && Lc() && "addEventListener" in performance && (Fc = W(e, performance, "resourcetimingbufferfull", () => {
        performance.clearResourceTimings();
    })), () => {
        Fc ? .stop();
    };
}

function Lc() {
    return window.performance !== void 0 && "getEntries" in performance;
}

function Rc(e) {
    return window.PerformanceObserver && PerformanceObserver.supportedEntryTypes !== void 0 && PerformanceObserver.supportedEntryTypes.includes(e);
}

function zc(e) {
    return e.filter((e) => !Bc(e));
}

function Bc(e) {
    return e.entryType === Q.RESOURCE && (!Js(e.name) || !Vs(e));
}

function Vc(e, t, n, r, i, a) {
    let o = z(Hc)(e, t, n, r),
        s, c = !1,
        l = T(C(() => p({
            hadActivity: !1
        })), 100),
        u = a === void 0 ? void 0 : T(C(() => p({
            hadActivity: !0,
            end: M()
        })), a),
        d = o.subscribe(({
            isBusy: e
        }) => {
            E(l), E(s);
            let t = M();
            e || (s = T(C(() => p({
                hadActivity: !0,
                end: t
            })), 100));
        }),
        f = () => {
            c = !0, E(l), E(s), E(u), d.unsubscribe();
        };

    function p(e) {
        c || (f(), i(e));
    }
    return {
        stop: f
    };
}

function Hc(e, t, n, r) {
    return new D((i) => {
        let a = [],
            o, s = 0;
        return a.push(t.subscribe((e) => {
            e.every(Wc) || c();
        }), n.subscribe(c), Pc(r, {
            type: Q.RESOURCE
        }).subscribe((e) => {
            e.some((e) => !Uc(r, e.name)) && c();
        }), e.subscribe(7, (e) => {
            Uc(r, e.url) || (o === void 0 && (o = e.requestIndex), s += 1, c());
        }), e.subscribe(8, (e) => {
            Uc(r, e.url) || o === void 0 || e.requestIndex < o || (--s, c());
        })), () => {
            a.forEach((e) => e.unsubscribe());
        };

        function c() {
            i.notify({
                isBusy: s > 0
            });
        }
    });
}

function Uc(e, t) {
    return an(e.excludedActivityUrls, t);
}

function Wc(e) {
    let t = e.type === "characterData" ? e.target.parentElement : e.target;
    return !!(t && Ec(t) && t.matches("[data-dd-excluded-activity-mutations], [data-dd-excluded-activity-mutations] *"));
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/actionNameConstants.js
var Gc = "data-dd-action-name",
    Kc = "Masked Element",
    qc = "::shadow ",
    Jc = [
        Gc,
        "data-testid",
        "data-test",
        "data-qa",
        "data-cy",
        "data-test-id",
        "data-qa-id",
        "data-testing",
        "data-component",
        "data-element",
        "data-source-file"
    ],
    Yc = [il, tl],
    Xc = [
        il,
        nl,
        rl
    ];

function Zc(e, t) {
    if (!e.isConnected) return;
    let n = Qc(e),
        r = [];
    for (let {
            rootNode: e,
            target: i
        } of n) {
        let n = $c(i, e, t);
        if (!n) return;
        r.push(n);
    }
    return r.join(qc);
}

function Qc(e) {
    let t = [],
        n = e;
    for (; n;) {
        let e = n.getRootNode();
        if (t.push({
                rootNode: e,
                target: n
            }), Oc(e)) n = e.host;
        else break;
    }
    return t.reverse();
}

function $c(e, t, n) {
    let r, i = e;
    for (; i && i.nodeName !== "HTML";) {
        let e = ol(i, t, Yc, sl, n, r);
        if (e) return ll(e, r);
        r = ll(ol(i, t, Xc, cl, n, r) || al(i), r), i = i.parentElement;
    }
    return r;
}

function el(e) {
    return /[0-9]/.test(e);
}

function tl(e) {
    if (e.id && !el(e.id)) return `#${CSS.escape(e.id)}`;
}

function nl(e) {
    if (e.tagName === "BODY") return;
    let t = e.classList;
    for (let n = 0; n < t.length; n += 1) {
        let r = t[n];
        if (!el(r)) return `${CSS.escape(e.tagName)}.${CSS.escape(r)}`;
    }
}

function rl(e) {
    return CSS.escape(e.tagName);
}

function il(e, t) {
    if (t) {
        let e = n(t);
        if (e) return e;
    }
    for (let e of Jc) {
        let t = n(e);
        if (t) return t;
    }

    function n(t) {
        if (e.hasAttribute(t)) return `${CSS.escape(e.tagName)}[${t}="${CSS.escape(e.getAttribute(t))}"]`;
    }
}

function al(e) {
    let t = e.parentNode.firstElementChild,
        n = 1;
    for (; t && t !== e;) t.tagName === e.tagName && (n += 1), t = t.nextElementSibling;
    return `${CSS.escape(e.tagName)}:nth-of-type(${n})`;
}

function ol(e, t, n, r, i, a) {
    for (let o of n) {
        let n = o(e, i);
        if (n && r(e, t, n, a)) return n;
    }
}

function sl(e, t, n, r) {
    return t.querySelectorAll(ll(n, r)).length === 1;
}

function cl(e, t, n, r) {
    let i;
    if (r === void 0) i = (e) => e.matches(n);
    else {
        let e = ll(`${n}:scope`, r);
        i = (t) => t.querySelector(e) !== null;
    }
    let a = e.previousElementSibling;
    for (; a;) {
        if (i(a)) return !1;
        a = a.previousElementSibling;
    }
    for (a = e.nextElementSibling; a;) {
        if (i(a)) return !1;
        a = a.nextElementSibling;
    }
    return !0;
}

function ll(e, t) {
    return t ? `${e}>${t}` : e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/privacyConstants.js
var $ = {
        IGNORE: "ignore",
        HIDDEN: "hidden",
        ALLOW: Dn.ALLOW,
        MASK: Dn.MASK,
        MASK_USER_INPUT: Dn.MASK_USER_INPUT,
        MASK_UNLESS_ALLOWLISTED: Dn.MASK_UNLESS_ALLOWLISTED
    },
    ul = "data-dd-privacy",
    dl = "hidden",
    fl = "dd-privacy-",
    pl = "data:image/gif;base64,R0lGODlhAQABAIAAAMLCwgAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==",
    ml = {
        INPUT: !0,
        OUTPUT: !0,
        TEXTAREA: !0,
        SELECT: !0,
        OPTION: !0,
        DATALIST: !0,
        OPTGROUP: !0
    };

function hl(e) {
    return `[${ul}="${e}"], .${fl}${e}`;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/privacy.js
function gl(e, t, n) {
    if (n && n.has(e)) return n.get(e);
    let r = jc(e),
        i = r ? gl(r, t, n) : t,
        a = _l(vl(e), i);
    return n && n.set(e, a), a;
}

function _l(e, t) {
    switch (t) {
        case $.HIDDEN:
        case $.IGNORE:
            return t;
    }
    switch (e) {
        case $.ALLOW:
        case $.MASK:
        case $.MASK_USER_INPUT:
        case $.MASK_UNLESS_ALLOWLISTED:
        case $.HIDDEN:
        case $.IGNORE:
            return e;
        default:
            return t;
    }
}

function vl(e) {
    if (Ec(e)) {
        if (e.tagName === "BASE") return $.ALLOW;
        if (e.tagName === "INPUT") {
            let t = e;
            if (t.type === "password" || t.type === "email" || t.type === "tel" || t.type === "hidden") return $.MASK;
            let n = t.getAttribute("autocomplete");
            if (n && (n.startsWith("cc-") || n.endsWith("-password"))) return $.MASK;
        }
        if (e.matches(hl($.HIDDEN))) return $.HIDDEN;
        if (e.matches(hl($.MASK))) return $.MASK;
        if (e.matches(hl($.MASK_UNLESS_ALLOWLISTED))) return $.MASK_UNLESS_ALLOWLISTED;
        if (e.matches(hl($.MASK_USER_INPUT))) return $.MASK_USER_INPUT;
        if (e.matches(hl($.ALLOW))) return $.ALLOW;
        if (wl(e)) return $.IGNORE;
    }
}

function yl(e, t) {
    switch (t) {
        case $.MASK:
        case $.HIDDEN:
        case $.IGNORE:
            return !0;
        case $.MASK_UNLESS_ALLOWLISTED:
            return wc(e) ? xl(e.parentNode) ? !0 : !Tl(e.textContent || "") : xl(e);
        case $.MASK_USER_INPUT:
            return wc(e) ? xl(e.parentNode) : xl(e);
        default:
            return !1;
    }
}

function bl(e, t, n, r, i) {
    if (r !== $.MASK && r !== $.MASK_UNLESS_ALLOWLISTED || t === "data-dd-privacy" || Jc.includes(t) || t === i.actionNameAttribute) return !1;
    switch (t) {
        case "title":
        case "alt":
        case "placeholder":
        case "aria-label":
        case "name":
            return !0;
    }
    return !!(e === "A" && t === "href" || e === "IFRAME" && t === "srcdoc" || n && t.startsWith("data-") || (e === "IMG" || e === "SOURCE") && (t === "src" || t === "srcset"));
}

function xl(e) {
    if (!e || e.nodeType !== e.ELEMENT_NODE) return !1;
    let t = e;
    if (t.tagName === "INPUT") switch (t.type) {
        case "button":
        case "color":
        case "reset":
        case "submit":
            return !1;
    }
    return !!ml[t.tagName];
}
var Sl = (e) => e.replace(/\S/g, "x");

function Cl(e, t) {
    let n = e.parentElement ? .tagName,
        r = e.textContent || "";
    if (n === "HEAD" && !r.trim()) return;
    let i = t;
    if (n === "SCRIPT") r = "***";
    else if (i === $.HIDDEN) r = "***";
    else if (yl(e, i))
        if (n === "DATALIST" || n === "SELECT" || n === "OPTGROUP") {
            if (!r.trim()) return;
        } else r = n === "OPTION" ? "***" : i === $.MASK_UNLESS_ALLOWLISTED ? El(r) : Sl(r);
    return r;
}

function wl(e) {
    if (e.nodeName === "SCRIPT") return !0;
    if (e.nodeName === "LINK") {
        let e = t("rel");
        return /preload|prefetch/i.test(e) && t("as") === "script" || e === "shortcut icon" || e === "icon";
    }
    if (e.nodeName === "META") {
        let n = t("name"),
            r = t("rel"),
            i = t("property");
        return /^msapplication-tile(image|color)$/.test(n) || n === "application-name" || r === "icon" || r === "apple-touch-icon" || r === "shortcut icon" || n === "keywords" || n === "description" || /^(og|twitter|fb):/.test(i) || /^(og|twitter):/.test(n) || n === "pinterest" || n === "robots" || n === "googlebot" || n === "bingbot" || e.hasAttribute("http-equiv") || n === "author" || n === "generator" || n === "framework" || n === "publisher" || n === "progid" || /^article:/.test(i) || /^product:/.test(i) || n === "google-site-verification" || n === "yandex-verification" || n === "csrf-token" || n === "p:domain_verify" || n === "verify-v1" || n === "verification" || n === "shopify-checkout-api-token";
    }

    function t(t) {
        return (e.getAttribute(t) || "").toLowerCase();
    }
    return !1;
}

function Tl(e) {
    return !e || !e.trim() ? !0 : window.$DD_ALLOW ? .has(e.toLocaleLowerCase()) || !1;
}

function El(e, t) {
    return Tl(e) ? e : t || Sl(e);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/trackEventCounts.js
function Dl({
    lifeCycle: e,
    isChildEvent: t,
    onChange: n = I
}) {
    let r = {
            errorCount: 0,
            longTaskCount: 0,
            resourceCount: 0,
            actionCount: 0,
            frustrationCount: 0
        },
        i = e.subscribe(13, (e) => {
            if (!(e.type === "view" || e.type === "vital" || !t(e))) switch (e.type) {
                case Z.ERROR:
                    r.errorCount += 1, n();
                    break;
                case Z.ACTION:
                    r.actionCount += 1, e.action.frustration && (r.frustrationCount += e.action.frustration.type.length), n();
                    break;
                case Z.LONG_TASK:
                    r.longTaskCount += 1, n();
                    break;
                case Z.RESOURCE:
                    e._dd ? .discarded || (r.resourceCount += 1, n());
                    break;
            }
        });
    return {
        stop: () => {
            i.unsubscribe();
        },
        eventCounts: r
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/eventTracker.js
var Ol = 5 * k;

function kl(e) {
    let t = ga({
            expireDelay: Ol
        }),
        n = /* @__PURE__ */ new Map();

    function r(e) {
        var t;
        n.delete(e.key), (t = e.eventCounts) == null || t.stop();
    }

    function i() {
        n.forEach((e) => {
            r(e);
        }), t.reset();
    }
    let a = e.subscribe(10, i);

    function o(i, a, o, s) {
        let c = L(),
            l = t.add(c, a.relative),
            u = n.get(i);
        u && r(u);
        let d = {
            id: c,
            key: i,
            startClocks: a,
            data: o,
            historyEntry: l,
            eventCounts: s ? .isChildEvent ? Dl({
                lifeCycle: e,
                isChildEvent: s.isChildEvent(c)
            }) : void 0
        };
        return n.set(i, d), d;
    }

    function s(e, t, i) {
        let a = n.get(e);
        if (!a) return;
        let o = i ? ii(a.data, i) : a.data;
        a.historyEntry.close(t.relative);
        let s = F(a.startClocks.timeStamp, t.timeStamp),
            c = a.eventCounts ? .eventCounts;
        return r(a), {
            ...o,
            id: a.id,
            startClocks: a.startClocks,
            duration: s,
            counts: c
        };
    }

    function c(e) {
        let t = n.get(e);
        if (!t) return;
        let i = t.eventCounts ? .eventCounts;
        return r(t), t.historyEntry.remove(), {
            ...t.data,
            id: t.id,
            startClocks: t.startClocks,
            counts: i
        };
    }

    function l(e) {
        return t.findAll(e);
    }

    function u(e) {
        return n.get(e) ? .eventCounts ? .eventCounts;
    }

    function d() {
        a.unsubscribe(), i(), t.stop();
    }
    return {
        start: o,
        stop: s,
        discard: c,
        getCounts: u,
        findId: l,
        stopAll: d
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/clickChain.js
var Al = O;

function jl(e, t) {
    let n = [],
        r = 0,
        i;
    a(e);

    function a(e) {
        e.stopObservable.subscribe(o), n.push(e), E(i), i = T(s, Al);
    }

    function o() {
        r === 1 && n.every((e) => e.isStopped()) && (r = 2, t(n));
    }

    function s() {
        E(i), r === 0 && (r = 1, o());
    }
    return {
        tryAppend: (e) => r === 0 ? n.length > 0 && !Ml(n[n.length - 1].event, e.event) ? (s(), !1) : (a(e), !0) : !1,
        stop: () => {
            s();
        }
    };
}

function Ml(e, t) {
    return e.target === t.target && Nl(e, t) <= 100 && e.timeStamp - t.timeStamp <= Al;
}

function Nl(e, t) {
    return Math.sqrt((e.clientX - t.clientX) ** 2 + (e.clientY - t.clientY) ** 2);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/getActionNameFromElement.js
function Pl(e, t, n = $.ALLOW) {
    let r = /* @__PURE__ */ new Map(),
        {
            actionNameAttribute: i
        } = t,
        a = Fl(e, "data-dd-action-name") || i && Fl(e, i);
    return a ? {
        name: a,
        nameSource: "custom_attribute"
    } : n === $.MASK ? {
        name: Kc,
        nameSource: "mask_placeholder"
    } : Bl(e, Ll, t, r) || Bl(e, Rl, t, r) || {
        name: "",
        nameSource: "blank"
    };
}

function Fl(e, t) {
    let n = Il(e, `[${t}]`);
    if (n) return Hl(Vl(n.getAttribute(t).trim()));
}

function Il(e, t) {
    let n = e;
    for (; n;) {
        if (n.matches(t)) return n;
        n = Mc(n);
    }
    return null;
}
var Ll = [
        (e, t, n) => {
            if ("labels" in e && e.labels && e.labels.length > 0) return Gl(e.labels[0], t, n);
        },
        (e) => {
            if (e.nodeName === "INPUT") {
                let t = e,
                    n = t.getAttribute("type");
                if (n === "button" || n === "submit" || n === "reset") return {
                    name: t.value,
                    nameSource: "text_content"
                };
            }
        },
        (e, t, n) => {
            if (e.nodeName === "BUTTON" || e.nodeName === "LABEL" || e.getAttribute("role") === "button") return Gl(e, t, n);
        },
        (e, t, n) => Wl(e, "aria-label", t, n),
        (e, t, n) => {
            let r = e.getAttribute("aria-labelledby");
            if (r) return {
                name: r.split(/\s+/).map((t) => Ul(e, t)).filter((e) => !!e).map((e) => Kl(e, t, n)).join(" "),
                nameSource: "text_content"
            };
        },
        (e, t, n) => Wl(e, "alt", t, n),
        (e, t, n) => Wl(e, "name", t, n),
        (e, t, n) => Wl(e, "title", t, n),
        (e, t, n) => Wl(e, "placeholder", t, n),
        (e, t, n) => {
            if ("options" in e && e.options.length > 0) return Gl(e.options[0], t, n);
        }
    ],
    Rl = [(e, t, n) => Gl(e, t, n)],
    zl = 10;

function Bl(e, t, n, r) {
    let i = e,
        a = 0;
    for (; a <= zl && i && i.nodeName !== "BODY" && i.nodeName !== "HTML" && i.nodeName !== "HEAD";) {
        for (let e of t) {
            let t = e(i, n, r);
            if (t) {
                let {
                    name: e,
                    nameSource: n
                } = t, r = e && e.trim();
                if (r) return {
                    name: Hl(Vl(r)),
                    nameSource: n
                };
            }
        }
        if (i.nodeName === "FORM") break;
        i = Mc(i), a += 1;
    }
}

function Vl(e) {
    return e.replace(/\s+/g, " ");
}

function Hl(e) {
    return e.length > 100 ? `${ke(e, 100)} [...]` : e;
}

function Ul(e, t) {
    let n = e.getRootNode();
    if (n instanceof ShadowRoot) {
        let e = n.getElementById(t);
        if (e) return e;
    }
    return e.ownerDocument ? e.ownerDocument.getElementById(t) : null;
}

function Wl(e, t, n, r) {
    let {
        enablePrivacyForActionName: i,
        defaultPrivacyLevel: a
    } = n, o = e.getAttribute(t);
    if (o && i) {
        let i = gl(e, a, r);
        bl(e.tagName, t, o, i, n) && (o = El(o, Kc));
    } else o || = "";
    return {
        name: o,
        nameSource: "standard_attribute"
    };
}

function Gl(e, t, n) {
    return {
        name: Kl(e, t, n) || "",
        nameSource: "text_content"
    };
}

function Kl(e, t, n) {
    if (e.isContentEditable) return;
    let {
        enablePrivacyForActionName: r,
        actionNameAttribute: i,
        defaultPrivacyLevel: a
    } = t;
    if (V(B.USE_TREE_WALKER_FOR_ACTION_NAME)) return ql(e, i, r, a, n);
    if ("innerText" in e) {
        let t = e.innerText,
            n = (n) => {
                let r = e.querySelectorAll(n);
                for (let e = 0; e < r.length; e += 1) {
                    let n = r[e];
                    if ("innerText" in n) {
                        let e = n.innerText;
                        e && e.trim().length > 0 && (t = t.replace(e, ""));
                    }
                }
            };
        return n(`[${Gc}]`), i && n(`[${i}]`), r && n(`${hl($.HIDDEN)}, ${hl($.MASK)}`), t;
    }
    return e.textContent;
}

function ql(e, t, n, r, i) {
    let a = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, s),
        o = "";
    for (; a.nextNode();) {
        let e = a.currentNode;
        if (Ec(e)) {
            (e.nodeName === "BR" || e.nodeName === "P" || [
                "block",
                "flex",
                "grid",
                "list-item",
                "table",
                "table-caption"
            ].includes(getComputedStyle(e).display)) && (o += " ");
            continue;
        }
        o += e.textContent || "";
    }
    return o.replace(/\s+/g, " ").trim();

    function s(e) {
        let a = gl(e, r, i);
        if (n && a && yl(e, a)) return NodeFilter.FILTER_REJECT;
        if (Ec(e)) {
            if (e.hasAttribute("data-dd-action-name") || t && e.hasAttribute(t)) return NodeFilter.FILTER_REJECT;
            let n = getComputedStyle(e);
            if (n.visibility !== "visible" || n.display === "none" || n.contentVisibility && n.contentVisibility !== "visible") return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/listenActionEvents.js
function Jl(e, {
    onPointerDown: t,
    onPointerUp: n
}) {
    let r, i = {
            selection: !1,
            input: !1,
            scroll: !1
        },
        a, o = [
            W(e, window, "pointerdown", (e) => {
                Xl(e) && (r = Yl(), i = {
                    selection: !1,
                    input: !1,
                    scroll: !1
                }, a = t(e));
            }, {
                capture: !0
            }),
            W(e, window, "selectionchange", () => {
                (!r || !Yl()) && (i.selection = !0);
            }, {
                capture: !0
            }),
            W(e, window, "scroll", () => {
                i.scroll = !0;
            }, {
                capture: !0,
                passive: !0
            }),
            W(e, window, "pointerup", (e) => {
                if (Xl(e) && a) {
                    let t = i;
                    n(a, e, () => t), a = void 0;
                }
            }, {
                capture: !0
            }),
            W(e, window, "input", () => {
                i.input = !0;
            }, {
                capture: !0
            })
        ];
    return {
        stop: () => {
            o.forEach((e) => e.stop());
        }
    };
}

function Yl() {
    let e = window.getSelection();
    return !e || e.isCollapsed;
}

function Xl(e) {
    return e.target instanceof Element && e.isPrimary !== !1;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/computeFrustration.js
var Zl = 3;

function Ql(e, t) {
    if ($l(e)) return t.addFrustration(Io.RAGE_CLICK), e.some(tu) && t.addFrustration(Io.DEAD_CLICK), t.hasError && t.addFrustration(Io.ERROR_CLICK), {
        isRage: !0
    };
    let n = e.some((e) => e.getUserActivity().selection);
    return e.forEach((e) => {
        e.hasError && e.addFrustration(Io.ERROR_CLICK), tu(e) && !n && e.addFrustration(Io.DEAD_CLICK);
    }), {
        isRage: !1
    };
}

function $l(e) {
    if (e.some((e) => e.getUserActivity().selection || e.getUserActivity().scroll)) return !1;
    for (let t = 0; t < e.length - (Zl - 1); t += 1)
        if (e[t + Zl - 1].event.timeStamp - e[t].event.timeStamp <= 1e3) return !0;
    return !1;
}
var eu = "input:not([type=\"checkbox\"]):not([type=\"radio\"]):not([type=\"button\"]):not([type=\"submit\"]):not([type=\"reset\"]):not([type=\"range\"]),textarea,select,[contenteditable],[contenteditable] *,canvas,a[href],a[href] *";

function tu(e) {
    if (e.hasPageActivity || e.getUserActivity().input || e.getUserActivity().scroll) return !1;
    let t = e.event.target;
    return t.tagName === "LABEL" && t.hasAttribute("for") && (t = document.getElementById(t.getAttribute("for"))), !t || !t.matches(eu);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/interactionSelectorCache.js
var nu = 10 * O,
    ru = /* @__PURE__ */ new Map();

function iu(e) {
    let t = ru.get(e);
    return ru.delete(e), t;
}

function au(e, t) {
    ru.set(e, t), ru.forEach((e, t) => {
        F(t, N()) > nu && ru.delete(t);
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/isActionChildEvent.js
function ou(e) {
    return (t) => t.action !== void 0 && t.action.id !== void 0 && t.action.id.includes(e);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/trackClickActions.js
function su(e, t, n, r) {
    let i = kl(e),
        a = new D(),
        o;
    e.subscribe(5, l), e.subscribe(11, l);
    let {
        stop: s
    } = Jl(r, {
        onPointerDown: (i) => cu(r, e, t, i, n),
        onPointerUp: ({
            clickActionBase: o,
            hadActivityOnPointerDown: s
        }, l, u) => {
            lu(r, e, t, n, i, a, c, o, l, u, s);
        }
    });
    return {
        stop: () => {
            l(), a.notify(), s(), i.stopAll();
        },
        findActionId: i.findId
    };

    function c(e) {
        if (!o || !o.tryAppend(e)) {
            let t = e.clone();
            o = jl(e, (e) => {
                pu(e, t), o = void 0;
            });
        }
    }

    function l() {
        o && o.stop();
    }
}

function cu(e, t, n, r, i) {
    let a = e.betaTrackActionsInShadowDom ? du(r) : r.target,
        o;
    if (o = e.enablePrivacyForActionName ? gl(a, e.defaultPrivacyLevel) : $.ALLOW, o === $.HIDDEN) return;
    let s = uu(r, o, e),
        c = !1;
    return Vc(t, n, i, e, (e) => {
        c = e.hadActivity;
    }, 100), {
        clickActionBase: s,
        hadActivityOnPointerDown: () => c
    };
}

function lu(e, t, n, r, i, a, o, s, c, l, u) {
    let d = fu(t, i, l, s, c);
    o(d);
    let f = s ? .target ? .selector;
    f && au(c.timeStamp, f);
    let {
        stop: p
    } = Vc(t, n, r, e, (e) => {
        e.hadActivity && e.end < d.startClocks.timeStamp ? d.discard() : e.hadActivity ? d.stop(e.end) : u() ? d.stop(d.startClocks.timeStamp) : d.stop();
    }, nu), m = t.subscribe(5, ({
        endClocks: e
    }) => {
        d.stop(e.timeStamp);
    }), h = t.subscribe(11, () => {
        d.stop(M());
    }), g = a.subscribe(() => {
        d.stop();
    });
    d.stopObservable.subscribe(() => {
        h.unsubscribe(), m.unsubscribe(), p(), g.unsubscribe();
    });
}

function uu(e, t, n) {
    let r = n.betaTrackActionsInShadowDom ? du(e) : e.target,
        i = r.getBoundingClientRect(),
        a = Zc(r, n.actionNameAttribute);
    a && au(e.timeStamp, a);
    let {
        name: o,
        nameSource: s
    } = Pl(r, n, t);
    return {
        type: Fo.CLICK,
        target: {
            width: Math.round(i.width),
            height: Math.round(i.height),
            selector: a
        },
        position: {
            x: Math.round(e.clientX - i.left),
            y: Math.round(e.clientY - i.top)
        },
        name: o,
        nameSource: s
    };
}

function du(e) {
    if (e.composed && Dc(e.target) && typeof e.composedPath == "function") {
        let t = e.composedPath();
        if (t.length > 0 && t[0] instanceof Element) return t[0];
    }
    return e.target;
}

function fu(e, t, n, r, i) {
    let a = L(),
        o = pe(i.timeStamp),
        s = t.start(a, o, r, {
            isChildEvent: ou
        });
    e.notify(15, s);
    let c = 0,
        l, u = [],
        d = new D();

    function f(e) {
        c === 0 && (c = 1, l = e ? t.stop(a, me(e)) : t.discard(a), d.notify());
    }
    return {
        event: i,
        stop: f,
        stopObservable: d,
        get hasError() {
            let e = l ? .counts ? ? t.getCounts(a);
            return e ? e.errorCount > 0 : !1;
        },
        get hasPageActivity() {
            return l && "duration" in l;
        },
        getUserActivity: n,
        addFrustration: (e) => {
            u.push(e);
        },
        get startClocks() {
            return o;
        },
        isStopped: () => c === 1 || c === 2,
        clone: () => fu(e, t, n, r, i),
        validate: (t) => {
            if (f(), c !== 1 || !l) return;
            let n = {
                frustrationTypes: u,
                events: t ? ? [i],
                event: i,
                ...l,
                counts: l.counts
            };
            e.notify(0, n), c = 2;
        },
        discard: () => {
            f(), c = 2;
        }
    };
}

function pu(e, t) {
    let {
        isRage: n
    } = Ql(e, t);
    n ? (e.forEach((e) => e.discard()), t.stop(M()), t.validate(e.map((e) => e.event))) : (t.discard(), e.forEach((e) => e.validate()));
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/action/trackManualActions.js
function mu(e, t) {
    let n = kl(e);

    function r(t, r = {}, i = P()) {
        let a = r.actionKey ? ? t,
            o = n.start(a, i, {
                name: t,
                ...r
            }, {
                isChildEvent: ou
            });
        e.notify(15, o);
    }

    function i(e, r = {}, i = P()) {
        let a = r.actionKey ? ? e,
            o = n.stop(a, i, r);
        if (!o) return;
        let s = [];
        o.counts && o.counts.errorCount > 0 && s.push(Io.ERROR_CLICK), t({
            ...o,
            type: o.type || Fo.CUSTOM,
            frustrationTypes: s
        });
    }

    function a(e) {
        t({
            id: L(),
            frustrationTypes: [],
            ...e
        });
    }
    return {
        addAction: a,
        startAction: r,
        stopAction: i,
        findActionId: n.findId,
        stop: n.stopAll
    };
}

function hu(e, t, n, r, i) {
    let {
        unsubscribe: a
    } = e.subscribe(0, (t) => {
        e.notify(12, gu(t));
    }), o = I, s;
    i.trackUserInteractions && (s = su(e, n, r, i));
    let c = mu(e, (t) => {
            e.notify(12, gu(t));
        }),
        l = {
            findActionId: (e) => {
                let t = c.findActionId(e),
                    n = s ? .findActionId(e) ? ? [];
                return t.concat(n);
            }
        };
    return t.register(0, ({
        startTime: e,
        eventType: t
    }) => {
        if (t !== Z.ERROR && t !== Z.RESOURCE && t !== Z.LONG_TASK) return G;
        let n = t === Z.LONG_TASK ? ve(e, 1) : e,
            r = l.findActionId(n);
        return r.length ? {
            type: t,
            action: {
                id: r
            }
        } : G;
    }), t.register(1, ({
        startTime: e
    }) => ({
        action: {
            id: l.findActionId(e)
        }
    })), {
        addAction: c.addAction,
        startAction: c.startAction,
        stopAction: c.stopAction,
        actionContexts: l,
        stop: () => {
            a(), o(), c.stop(), s ? .stop();
        }
    };
}

function gu(e) {
    let t = _u(e),
        n = Cc(A(e.duration));
    return {
        rawRumEvent: {
            type: Z.ACTION,
            date: e.startClocks.timeStamp,
            action: {
                id: e.id,
                target: {
                    name: e.name
                },
                type: e.type,
                ...n !== void 0 && {
                    loading_time: n
                },
                ...e.counts && {
                    error: {
                        count: e.counts.errorCount
                    },
                    long_task: {
                        count: e.counts.longTaskCount
                    },
                    resource: {
                        count: e.counts.resourceCount
                    }
                },
                frustration: {
                    type: e.frustrationTypes
                }
            },
            ...t ? {
                _dd: {
                    action: {
                        target: e.target,
                        position: e.position,
                        name_source: e.nameSource
                    }
                }
            } : {
                context: e.context
            }
        },
        duration: e.duration,
        startClocks: e.startClocks,
        domainContext: t ? {
            events: e.events
        } : {
            handlingStack: e.handlingStack
        }
    };
}

function _u(e) {
    return "events" in e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/error/trackConsoleError.js
function vu(t) {
    let n = so([e.error]).subscribe((e) => t.notify(e.error));
    return {
        stop: () => {
            n.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/error/trackReportError.js
function yu(e, t) {
    let n = Ur(e, [Hr.cspViolation, Hr.intervention]).subscribe((e) => t.notify(e));
    return {
        stop: () => {
            n.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/error/errorCollection.js
function bu(e, t, n) {
    let r = new D();
    return n.subscribe((e) => {
        e.type === 0 && r.notify(e.error);
    }), vu(r), yu(t, r), r.subscribe((t) => e.notify(14, {
        error: t
    })), xu(e);
}

function xu(e) {
    return e.subscribe(14, ({
        error: t
    }) => {
        e.notify(12, Su(t));
    }), {
        addError: ({
            error: t,
            handlingStack: n,
            componentStack: r,
            startClocks: i,
            context: a
        }) => {
            let o = Dr({
                originalError: t,
                handlingStack: n,
                componentStack: r,
                startClocks: i,
                nonErrorPrefix: "Provided",
                source: Pr.CUSTOM,
                handling: "handled"
            });
            o.context = ii(o.context, a), e.notify(14, {
                error: o
            });
        }
    };
}

function Su(e) {
    let t = {
            date: e.startClocks.timeStamp,
            error: {
                id: L(),
                message: e.message,
                source: e.source,
                stack: e.stack,
                handling_stack: e.handlingStack,
                component_stack: e.componentStack,
                type: e.type,
                handling: e.handling,
                causes: e.causes,
                source_type: "browser",
                fingerprint: e.fingerprint,
                csp: e.csp
            },
            type: Z.ERROR,
            context: e.context
        },
        n = {
            error: e.originalError,
            handlingStack: e.handlingStack
        };
    return {
        rawRumEvent: t,
        startClocks: e.startClocks,
        domainContext: n
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/resource/matchRequestResourceEntry.js
var Cu = /* @__PURE__ */ new WeakSet();

function wu(e) {
    if (!performance || !("getEntriesByName" in performance)) return;
    let t = performance.getEntriesByName(e.url, "resource");
    if (!t.length || !("toJSON" in t[0])) return;
    let n = t.filter((e) => !Cu.has(e)).filter((e) => Vs(e) && Hs(e)).filter((t) => Eu(t, e.startClocks.relative, Tu({
        startTime: e.startClocks.relative,
        duration: e.duration
    })));
    if (n.length === 1) return Cu.add(n[0]), n[0].toJSON();
}

function Tu(e) {
    return ve(e.startTime, e.duration);
}

function Eu(e, t, n) {
    return e.startTime >= t - 1 && Tu(e) <= ve(n, 1);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/tracing/getDocumentTraceId.js
var Du = 2 * k;

function Ou(e) {
    let t = ku(e) || Au(e);
    if (!(!t || t.traceTime <= j() - Du)) return t.traceId;
}

function ku(e) {
    let t = e.querySelector("meta[name=dd-trace-id]"),
        n = e.querySelector("meta[name=dd-trace-time]");
    return ju(t && t.content, n && n.content);
}

function Au(e) {
    let t = Mu(e);
    if (t) return ju(Ee(t, "trace-id"), Ee(t, "trace-time"));
}

function ju(e, t) {
    let n = t && Number(t);
    if (!(!e || !n)) return {
        traceId: e,
        traceTime: n
    };
}

function Mu(e) {
    for (let t = 0; t < e.childNodes.length; t += 1) {
        let n = Nu(e.childNodes[t]);
        if (n) return n;
    }
    if (e.body)
        for (let t = e.body.childNodes.length - 1; t >= 0; --t) {
            let n = e.body.childNodes[t],
                r = Nu(n);
            if (r) return r;
            if (!wc(n)) break;
        }
}

function Nu(e) {
    if (e && Tc(e)) {
        let t = /^\s*DATADOG;(.*?)\s*$/.exec(e.data);
        if (t) return t[1];
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/performanceUtils.js
function Pu() {
    if (Rc(Q.NAVIGATION)) {
        let e = performance.getEntriesByType(Q.NAVIGATION)[0];
        if (e) return e;
    }
    let e = Fu(),
        t = {
            entryType: Q.NAVIGATION,
            initiatorType: "navigation",
            name: window.location.href,
            startTime: 0,
            duration: e.loadEventEnd,
            decodedBodySize: 0,
            encodedBodySize: 0,
            transferSize: 0,
            workerStart: 0,
            toJSON: () => ({
                ...t,
                toJSON: void 0
            }),
            ...e
        };
    return t;
}

function Fu() {
    let e = {},
        t = performance.timing;
    for (let n in t)
        if (f(t[n])) {
            let r = n,
                i = t[r];
            e[r] = i === 0 ? 0 : ye(i);
        }
    return e;
}

function Iu(e) {
    return e.responseStart >= 0 && e.responseStart <= N() ? e.responseStart : void 0;
}

function Lu() {
    if (Rc(Q.RESOURCE)) return performance.getEntriesByType(Q.RESOURCE);
}

function Ru(e, t) {
    let n = Lu();
    if (n) return Qe(n, (n) => n.name === e && n.startTime <= t);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/resource/retrieveInitialDocumentResourceTiming.js
function zu(e, t) {
    Ba(e, "interactive", () => {
        let e = z(Pu)(),
            n = Object.assign(e.toJSON(), {
                entryType: Q.RESOURCE,
                initiatorType: Ps,
                duration: e.responseEnd,
                traceId: Ou(document),
                toJSON: () => ({
                    ...n,
                    toJSON: void 0
                })
            });
        t(n);
    });
}

function Bu(e) {
    let t = /* @__PURE__ */ new Set(),
        n = !1,
        r = e.subscribe(8, (e) => {
            if (t.add(e), t.size > 1e3) {
                let e = t.values().next().value;
                if (!n) {
                    n = !0;
                    let r;
                    if (V(B.TOO_MANY_REQUESTS_INVESTIGATION)) {
                        let n = 0,
                            i = 0,
                            a = 0,
                            o = 0;
                        for (let e of t) e.isAborted && n++, e.isAbortedOnStart && i++, e.type === ko.XHR && a++, performance.getEntriesByName(e.url, "resource").some((t) => t.startTime >= e.startClocks.relative) || o++;
                        let s = M() - e.startClocks.timeStamp;
                        r = {
                            abortedCount: n,
                            abortedOnStartCount: i,
                            xhrCount: a,
                            fetchCount: t.size - a,
                            oldestRequestAge: s,
                            oldestRequestEndAge: s - e.duration,
                            withoutMatchingEntryCount: o
                        };
                    }
                    na("Too many requests", r);
                }
                t.delete(e);
            }
        });
    return {
        getMatchingRequest(e) {
            let n = Infinity,
                r;
            for (let i of t) {
                let t = e.startTime - i.startClocks.relative;
                0 <= t && t < n && i.url === e.name && (n = Math.abs(t), r = i);
            }
            return r && t.delete(r), r;
        },
        stop() {
            r.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/resource/trackManualResources.js
function Vu(e, t) {
    function n(e, n = {}, r = P()) {
        let i = n.resourceKey ? ? e;
        t.start(i, r, {
            url: e,
            ...n
        });
    }

    function r(n, r = {}, i = P()) {
        let a = r.resourceKey ? ? n,
            o = t.stop(a, i, {
                context: r.context,
                type: r.type
            });
        if (!o) return;
        let s = F(o.startClocks.relative, i.relative),
            c = {
                date: o.startClocks.timeStamp,
                type: Z.RESOURCE,
                resource: {
                    id: o.id,
                    type: o.type || X.OTHER,
                    url: Zs(o.url),
                    duration: A(s),
                    method: o.method,
                    status_code: r.statusCode,
                    size: r.size
                },
                _dd: {},
                context: o.context
            };
        e.notify(12, {
            rawRumEvent: c,
            startClocks: o.startClocks,
            duration: s,
            domainContext: {
                isManual: !0
            }
        });
    }
    return {
        startResource: n,
        stopResource: r
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/resource/resourceCollection.js
function Hu(e, t, n) {
    let r = z(ao)(),
        i, a = t.trackEarlyRequests;
    a ? i = Bu(e) : e.subscribe(8, (e) => {
        s(() => Uu(e, t, n));
    });
    let o = Pc(t, {
        type: Q.RESOURCE,
        buffered: !0
    }).subscribe((e) => {
        for (let r of e)(a || !Rs(r)) && s(() => Wu(r, t, n, i));
    });
    z(zu)(t, (e) => {
        s(() => Wu(e, t, n, i));
    });

    function s(t) {
        r.push(() => {
            let n = t();
            n && e.notify(12, n);
        });
    }
    let c = kl(e),
        l = Vu(e, c);
    return {
        startResource: l.startResource,
        stopResource: l.stopResource,
        stop: () => {
            r.stop(), o.unsubscribe(), c.stopAll();
        }
    };
}

function Uu(e, t, n) {
    return Gu(wu(e), e, n, t);
}

function Wu(e, t, n, r) {
    return Gu(e, Rs(e) && r ? r.getMatchingRequest(e) : void 0, n, t);
}

function Gu(e, t, n, r) {
    if (!e && !t) return;
    let i = t ? Xu(t, r) : Zu(e, r);
    if (!r.trackResources && !i) return;
    let a = e ? pe(e.startTime) : t.startClocks,
        o = e ? zs(e) : Qu(n, a, t.duration),
        s = t && Ku(t, r),
        c = e && qu(e);
    return {
        startClocks: a,
        duration: o,
        rawRumEvent: ii({
            date: a.timeStamp,
            resource: {
                id: L(),
                duration: A(o),
                type: t ? t.type === ko.XHR ? X.XHR : X.FETCH : Is(e),
                method: t ? t.method : void 0,
                status_code: t ? t.status : $u(e.responseStatus),
                url: t ? Zs(t.url) : e.name,
                protocol: e && Gs(e),
                delivery_type: e && Ks(e),
                graphql: s,
                response: c
            },
            type: Z.RESOURCE,
            _dd: {
                discarded: !r.trackResources
            }
        }, i, e && Yu(e)),
        domainContext: Ju(e, t)
    };
}

function Ku(e, t) {
    let n = fc(e.url, t);
    if (n) return uc(e, n);
}

function qu(e) {
    let t = e.contentType;
    if (t) return {
        headers: {
            "content-type": t
        }
    };
}

function Ju(e, t) {
    if (t) {
        let n = {
            performanceEntry: e,
            isAborted: t.isAborted,
            handlingStack: t.handlingStack
        };
        return t.type === ko.XHR ? {
            xhr: t.xhr,
            ...n
        } : {
            requestInput: t.input,
            requestInit: t.init,
            response: t.response,
            error: t.error,
            ...n
        };
    }
    return {
        performanceEntry: e
    };
}

function Yu(e) {
    let {
        renderBlockingStatus: t
    } = e;
    return {
        resource: {
            render_blocking_status: t,
            ...qs(e),
            ...Bs(e)
        }
    };
}

function Xu(e, t) {
    if (e.traceSampled && e.traceId && e.spanId) return {
        _dd: {
            span_id: e.spanId.toString(),
            trace_id: e.traceId.toString(),
            rule_psr: t.rulePsr
        }
    };
}

function Zu(e, t) {
    if (e.traceId) return {
        _dd: {
            trace_id: e.traceId,
            span_id: nc().toString(),
            rule_psr: t.rulePsr
        }
    };
}

function Qu(e, t, n) {
    return e.wasInPageStateDuringPeriod("frozen", t.relative, n) ? void 0 : n;
}

function $u(e) {
    return e === 0 ? void 0 : e;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/trackViewEventCounts.js
function ed(e, t, n) {
    let {
        stop: r,
        eventCounts: i
    } = Dl({
        lifeCycle: e,
        isChildEvent: (e) => e.view.id === t,
        onChange: n
    });
    return {
        stop: r,
        eventCounts: i
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackFirstContentfulPaint.js
var td = 10 * k;

function nd(e, t, n) {
    return {
        stop: Pc(e, {
            type: Q.PAINT,
            buffered: !0
        }).subscribe((e) => {
            let r = e.find((e) => e.name === "first-contentful-paint" && e.startTime < t.timeStamp && e.startTime < td);
            r && n(r.startTime);
        }).unsubscribe
    };
}

function rd(e, t) {
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            t(F(e, N()));
        });
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackFirstInput.js
function id(e, t, n) {
    let r = Pc(e, {
        type: Q.FIRST_INPUT,
        buffered: !0
    }).subscribe((r) => {
        let i = r.find((e) => e.startTime < t.timeStamp);
        if (i) {
            let t = F(i.startTime, i.processingStart),
                r;
            i.target && Ec(i.target) && (r = Zc(i.target, e.actionNameAttribute)), n({
                delay: t >= 0 ? t : 0,
                time: i.startTime,
                targetSelector: r
            });
        }
    });
    return {
        stop: () => {
            r.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackNavigationTimings.js
function ad(e, t) {
    return cd(e, () => {
        let e = z(Pu)();
        sd(e) || t(od(e));
    });
}

function od(e) {
    return {
        domComplete: e.domComplete,
        domContentLoaded: e.domContentLoadedEventEnd,
        domInteractive: e.domInteractive,
        loadEvent: e.loadEventEnd,
        firstByte: Iu(e)
    };
}

function sd(e) {
    return e.loadEventEnd <= 0;
}

function cd(e, t) {
    let n, {
        stop: r
    } = Ba(e, "complete", () => {
        n = T(() => t());
    });
    return {
        stop: () => {
            r(), E(n);
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackLargestContentfulPaint.js
var ld = 10 * k;

function ud(e, t, n, r) {
    let i = Infinity,
        {
            stop: a
        } = Vr(e, n, ["pointerdown", "keydown"], (e) => {
            i = e.timeStamp;
        }, {
            capture: !0,
            once: !0
        }),
        o = 0,
        s = Pc(e, {
            type: Q.LARGEST_CONTENTFUL_PAINT,
            buffered: !0
        }).subscribe((n) => {
            let a = Qe(n, (e) => e.entryType === Q.LARGEST_CONTENTFUL_PAINT && e.startTime < i && e.startTime < t.timeStamp && e.startTime < ld && e.size > o);
            if (a) {
                let t;
                a.element && (t = Zc(a.element, e.actionNameAttribute));
                let n = dd(a),
                    i = a.startTime,
                    s = V(B.LCP_SUBPARTS) ? fd(n, i) : void 0;
                r({
                    value: i,
                    targetSelector: t,
                    resourceUrl: n,
                    subParts: s
                }), o = a.size;
            }
        });
    return {
        stop: () => {
            a(), s.unsubscribe();
        }
    };
}

function dd(e) {
    return e.url === "" ? void 0 : e.url;
}

function fd(e, t) {
    let n = Iu(Pu());
    if (n === void 0) return;
    let r = e ? Ru(e, t) : void 0,
        i = r ? Math.max(n, r.requestStart || r.startTime) : n,
        a = Math.min(t, Math.max(i, r ? .responseEnd || 0));
    return {
        loadDelay: i - n,
        loadTime: a - i,
        renderDelay: t - a
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackFirstHidden.js
function pd(e, t, n = window) {
    if (document.visibilityState === "hidden") return {
        timeStamp: 0,
        stop: I
    };
    if (Rc(Q.VISIBILITY_STATE)) {
        let e = performance.getEntriesByType(Q.VISIBILITY_STATE).filter((e) => e.name === "hidden").find((e) => e.startTime >= t.relative);
        if (e) return {
            timeStamp: e.startTime,
            stop: I
        };
    }
    let r = Infinity,
        {
            stop: i
        } = Vr(e, n, ["pagehide", "visibilitychange"], (e) => {
            (e.type === "pagehide" || document.visibilityState === "hidden") && (r = e.timeStamp, i());
        }, {
            capture: !0
        });
    return {
        get timeStamp() {
            return r;
        },
        stop: i
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackInitialViewMetrics.js
function md(e, t, n, r) {
    let i = {},
        {
            stop: a
        } = ad(e, (e) => {
            n(e.loadEvent), i.navigationTimings = e, r();
        }),
        o = pd(e, t),
        {
            stop: s
        } = nd(e, o, (e) => {
            i.firstContentfulPaint = e, r();
        }),
        {
            stop: c
        } = ud(e, o, window, (e) => {
            i.largestContentfulPaint = e, r();
        }),
        {
            stop: l
        } = id(e, o, (e) => {
            i.firstInput = e, r();
        });

    function u() {
        a(), s(), c(), l(), o.stop();
    }
    return {
        stop: u,
        initialViewMetrics: i
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/getClsAttributionImpactedArea.js
var hd = (e, t) => e * t,
    gd = (e, t) => {
        let n = Math.max(e.left, t.left),
            r = Math.max(e.top, t.top),
            i = Math.min(e.right, t.right),
            a = Math.min(e.bottom, t.bottom);
        return n >= i || r >= a ? 0 : hd(i - n, a - r);
    },
    _d = (e) => {
        let t = hd(e.previousRect.width, e.previousRect.height),
            n = hd(e.currentRect.width, e.currentRect.height),
            r = gd(e.previousRect, e.currentRect);
        return t + n - r;
    };
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackCumulativeLayoutShift.js
function vd(e, t, n) {
    if (!wd()) return {
        stop: I
    };
    let r = 0,
        i;
    n({
        value: 0
    });
    let a = Cd(),
        o = Pc(e, {
            type: Q.LAYOUT_SHIFT,
            buffered: !0
        }).subscribe((o) => {
            for (let s of o) {
                if (s.hadRecentInput || s.startTime < t) continue;
                let {
                    cumulatedValue: o,
                    isMaxValue: c
                } = a.update(s);
                if (c) {
                    let e = yd(s.sources);
                    i = {
                        target: e ? .node ? new WeakRef(e.node) : void 0,
                        time: F(t, s.startTime),
                        previousRect: e ? .previousRect,
                        currentRect: e ? .currentRect,
                        devicePixelRatio: window.devicePixelRatio
                    };
                }
                if (o > r) {
                    r = o;
                    let t = (i ? .target) ? .deref();
                    n({
                        value: u(r, 4),
                        targetSelector: t && Zc(t, e.actionNameAttribute),
                        time: i ? .time,
                        previousRect: i ? .previousRect ? bd(i.previousRect) : void 0,
                        currentRect: i ? .currentRect ? bd(i.currentRect) : void 0,
                        devicePixelRatio: i ? .devicePixelRatio
                    });
                }
            }
        });
    return {
        stop: () => {
            o.unsubscribe();
        }
    };
}

function yd(e) {
    let t;
    for (let n of e)
        if (n.node && Ec(n.node)) {
            let e = _d(n);
            (!t || _d(t) < e) && (t = n);
        }
    return t;
}

function bd({
    x: e,
    y: t,
    width: n,
    height: r
}) {
    return {
        x: e,
        y: t,
        width: n,
        height: r
    };
}
var xd = 5 * O,
    Sd = O;

function Cd() {
    let e = 0,
        t, n, r = 0;
    return {
        update: (i) => {
            let a = t === void 0 || i.startTime - n >= Sd || i.startTime - t >= xd,
                o;
            return a ? (t = n = i.startTime, r = e = i.value, o = !0) : (e += i.value, n = i.startTime, o = i.value > r, o && (r = i.value)), {
                cumulatedValue: e,
                isMaxValue: o
            };
        }
    };
}

function wd() {
    return Rc(Q.LAYOUT_SHIFT) && "WeakRef" in window;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/interactionCountPolyfill.js
var Td, Ed = 0,
    Dd = Infinity,
    Od = 0;

function kd() {
    "interactionCount" in performance || Td || (Td = new window.PerformanceObserver(C((e) => {
        e.getEntries().forEach((e) => {
            let t = e;
            t.interactionId && (Dd = Math.min(Dd, t.interactionId), Od = Math.max(Od, t.interactionId), Ed = (Od - Dd) / 7 + 1);
        });
    })), Td.observe({
        type: "event",
        buffered: !0,
        durationThreshold: 0
    }));
}
var Ad = () => Td ? Ed : window.performance.interactionCount || 0,
    jd = 10,
    Md = 1 * k,
    Nd = 8;

function Pd(e, t, n) {
    if (!Rd()) return {
        getInteractionToNextPaint: () => void 0,
        setViewEnd: I,
        stop: I
    };
    let r = Infinity,
        i, {
            getViewInteractionCount: a,
            stopViewInteractionCount: o
        } = Id(n),
        s = Fd(a),
        c = V(B.INP_SUBPARTS) ? Ld(s) : null,
        l = Pc(e, {
            type: Q.FIRST_INPUT,
            buffered: !0
        }).subscribe(d),
        u = Pc(e, {
            type: Q.EVENT,
            durationThreshold: 40,
            buffered: !0
        }).subscribe(d);

    function d(e) {
        for (let n of e) n.interactionId && n.startTime >= t && n.startTime <= r && (s.process(n), c ? .process(n));
        c ? .pruneUntracked();
        let n = s.estimateP98Interaction();
        n && f(n);
    }

    function f(n) {
        let r = F(t, n.startTime);
        if (!i || n.duration !== i.duration || r !== i.startTime) {
            let t = iu(n.startTime);
            !t && n.target && Ec(n.target) && (t = Zc(n.target, e.actionNameAttribute)), i = {
                duration: n.duration,
                startTime: r,
                targetSelector: t
            };
        }
        c && (i.subParts = c.computeSubParts(n, zd(i.duration)));
    }
    return {
        getInteractionToNextPaint: () => {
            if (i) return {
                value: zd(i.duration),
                targetSelector: i.targetSelector,
                time: i.startTime,
                subParts: i.subParts
            };
            if (a()) return {
                value: 0
            };
        },
        setViewEnd: (e) => {
            r = e, o();
        },
        stop: () => {
            u.unsubscribe(), l.unsubscribe(), c ? .stop();
        }
    };
}

function Fd(e) {
    let t = [];

    function n() {
        t.sort((e, t) => t.duration - e.duration).splice(jd);
    }
    return {
        process(e) {
            let r = t.findIndex((t) => e.interactionId === t.interactionId),
                i = t[t.length - 1];
            r === -1 ? (t.length < jd || e.duration > i.duration) && (t.push(e), n()) : e.duration > t[r].duration && (t[r] = e, n());
        },
        estimateP98Interaction() {
            return t[Math.min(t.length - 1, Math.floor(e() / 50))];
        },
        isTracked(e) {
            return t.some((t) => t.interactionId === e);
        }
    };
}

function Id(e) {
    kd();
    let t = e === Po.INITIAL_LOAD ? 0 : Ad(),
        n = {
            stopped: !1
        };

    function r() {
        return Ad() - t;
    }
    return {
        getViewInteractionCount: () => n.stopped ? n.interactionCount : r(),
        stopViewInteractionCount: () => {
            n = {
                stopped: !0,
                interactionCount: r()
            };
        }
    };
}

function Ld(e) {
    let t = /* @__PURE__ */ new Map();

    function n(e, t) {
        e.startTime = Math.min(t.startTime, e.startTime), e.processingStart = Math.min(t.processingStart, e.processingStart), e.processingEnd = Math.max(t.processingEnd, e.processingEnd);
    }
    return {
        process(e) {
            if (e.interactionId === void 0 || !e.processingStart || !e.processingEnd) return;
            let r = e.startTime + e.duration,
                i = t.get(e.interactionId);
            if (i) {
                n(i, e);
                return;
            }
            for (let [, i] of t.entries())
                if (Math.abs(r - i.referenceRenderTime) <= Nd) {
                    n(i, e), t.set(e.interactionId, i);
                    return;
                }
            t.set(e.interactionId, {
                startTime: e.startTime,
                processingStart: e.processingStart,
                processingEnd: e.processingEnd,
                referenceRenderTime: r
            });
        },
        pruneUntracked() {
            for (let [n] of t) e.isTracked(n) || t.delete(n);
        },
        computeSubParts(e, n) {
            if (!e.processingStart || !e.processingEnd || e.interactionId === void 0) return;
            let r = t.get(e.interactionId);
            if (!r) return;
            let i = Math.max(r.startTime + n, r.processingStart),
                a = Math.min(r.processingEnd, i);
            return {
                inputDelay: F(r.startTime, r.processingStart),
                processingDuration: F(r.processingStart, a),
                presentationDelay: F(a, i)
            };
        },
        stop() {
            t.clear();
        }
    };
}

function Rd() {
    return Rc(Q.EVENT) && window.PerformanceEventTiming && "interactionId" in PerformanceEventTiming.prototype;
}

function zd(e) {
    return Math.min(e, Md);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackLoadingTime.js
function Bd(e, t, n, r, i, a, o) {
    let s = i === Po.INITIAL_LOAD,
        c = !0,
        l = [],
        u = pd(r, a);

    function d() {
        if (!c && !s && l.length > 0) {
            let e = Math.max(...l);
            e < u.timeStamp - a.relative && o(e);
        }
    }
    let {
        stop: f
    } = Vc(e, t, n, r, (e) => {
        c && (c = !1, e.hadActivity && l.push(F(a.timeStamp, e.end)), d());
    });
    return {
        stop: () => {
            f(), u.stop();
        },
        setLoadEvent: (e) => {
            s && (s = !1, l.push(e), d());
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/scroll.js
function Vd() {
    let e, t = window.visualViewport;
    return e = t ? t.pageLeft - t.offsetLeft : window.scrollX === void 0 ? window.pageXOffset || 0 : window.scrollX, Math.round(e);
}

function Hd() {
    let e, t = window.visualViewport;
    return e = t ? t.pageTop - t.offsetTop : window.scrollY === void 0 ? window.pageYOffset || 0 : window.scrollY, Math.round(e);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/viewportObservable.js
var Ud;

function Wd(e) {
    return Ud || = Gd(e), Ud;
}

function Gd(e) {
    return new D((t) => {
        let {
            throttled: n
        } = we(() => {
            t.notify(Kd());
        }, 200);
        return W(e, window, "resize", n, {
            capture: !0,
            passive: !0
        }).stop;
    });
}

function Kd() {
    let e = window.visualViewport;
    return e ? {
        width: Number(e.width * e.scale),
        height: Number(e.height * e.scale)
    } : {
        width: Number(window.innerWidth || 0),
        height: Number(window.innerHeight || 0)
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackScrollMetrics.js
var qd = O;

function Jd(e, t, n, r = Xd(e)) {
    let i = 0,
        a = 0,
        o = 0,
        s = r.subscribe(({
            scrollDepth: e,
            scrollTop: r,
            scrollHeight: s
        }) => {
            let c = !1;
            if (e > i && (i = e, c = !0), s > a) {
                a = s;
                let e = N();
                o = F(t.relative, e), c = !0;
            }
            c && n({
                maxDepth: Math.min(i, a),
                maxDepthScrollTop: r,
                maxScrollHeight: a,
                maxScrollHeightTime: o
            });
        });
    return {
        stop: () => s.unsubscribe()
    };
}

function Yd() {
    let e = Hd(),
        {
            height: t
        } = Kd();
    return {
        scrollHeight: Math.round((document.scrollingElement || document.documentElement).scrollHeight),
        scrollDepth: Math.round(t + e),
        scrollTop: e
    };
}

function Xd(e, t = qd) {
    return new D((n) => {
        function r() {
            n.notify(Yd());
        }
        if (window.ResizeObserver) {
            let n = we(r, t, {
                    leading: !1,
                    trailing: !0
                }),
                i = document.scrollingElement || document.documentElement,
                a = new ResizeObserver(C(n.throttled));
            i && a.observe(i);
            let o = W(e, window, "scroll", n.throttled, {
                passive: !0
            });
            return () => {
                n.cancel(), a.disconnect(), o.stop();
            };
        }
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackCommonViewMetrics.js
function Zd(e, t, n, r, i, a, o) {
    let s = {},
        c = !1,
        l = !1,
        {
            stop: u,
            setLoadEvent: d
        } = Bd(e, t, n, r, a, o, (e) => {
            c || (s.loadingTime = e, i());
        }),
        {
            stop: f
        } = Jd(r, o, (e) => {
            s.scroll = e;
        }),
        {
            stop: p
        } = vd(r, o.relative, (e) => {
            s.cumulativeLayoutShift = e, i();
        }),
        {
            stop: m,
            getInteractionToNextPaint: h,
            setViewEnd: g
        } = Pd(r, o.relative, a);
    return {
        stop: () => {
            u(), p(), f();
        },
        stopINPTracking: m,
        setLoadEvent: d,
        setViewEnd: (e) => {
            l = !0, g(e);
        },
        getCommonViewMetrics: () => (s.interactionToNextPaint = h(), s),
        setLoadingTime: (e) => {
            if (l) return;
            let t = F(o.timeStamp, e ? ? M());
            c || u(), c = !0, s.loadingTime = t, i();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/bfCacheSupport.js
function Qd(e, t) {
    let {
        stop: n
    } = W(e, window, "pageshow", (e) => {
        e.persisted && t(e);
    }, {
        capture: !0
    });
    return n;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/trackBfcacheMetrics.js
function $d(e, t, n) {
    rd(e.relative, (e) => {
        t.firstContentfulPaint = e, t.largestContentfulPaint = {
            value: e
        }, n();
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/trackViews.js
var ef = 3e3,
    tf = 5 * k,
    nf = 5 * k;

function rf(e, t, n, r, i, a, o) {
    let s = /* @__PURE__ */ new Set(),
        c = d(Po.INITIAL_LOAD, _e(), o),
        l;
    f();
    let u;
    a && (u = p(i), r.trackBfcacheViews && (l = Qd(r, (e) => {
        c.end();
        let t = pe(e.timeStamp);
        c = d(Po.BF_CACHE, t, void 0);
    })));

    function d(i, a, o) {
        let c = af(e, t, n, r, i, a, o);
        return s.add(c), c.stopObservable.subscribe(() => {
            s.delete(c);
        }), c;
    }

    function f() {
        e.subscribe(10, () => {
            c = d(Po.ROUTE_CHANGE, void 0, {
                name: c.name,
                service: c.service,
                version: c.version,
                context: c.contextManager.getContext()
            });
        }), e.subscribe(9, () => {
            c.end({
                sessionIsActive: !1
            });
        });
    }

    function p(e) {
        return e.subscribe(({
            oldLocation: e,
            newLocation: t
        }) => {
            sf(e, t) && (c.end(), c = d(Po.ROUTE_CHANGE));
        });
    }
    return {
        addTiming: (e, t = M()) => {
            c.addTiming(e, t);
        },
        setLoadingTime: (e) => c.setLoadingTime(e),
        startView: (e, t) => {
            c.end({
                endClocks: t
            }), c = d(Po.ROUTE_CHANGE, t, e);
        },
        setViewContext: (e) => {
            c.contextManager.setContext(e);
        },
        setViewContextProperty: (e, t) => {
            c.contextManager.setContextProperty(e, t);
        },
        setViewName: (e) => {
            c.setViewName(e);
        },
        getViewContext: () => c.contextManager.getContext(),
        stop: () => {
            u && u.unsubscribe(), l && l(), c.end(), s.forEach((e) => e.stop());
        }
    };
}

function af(e, t, n, r, i, a = P(), o) {
    let s = L(),
        c = new D(),
        l = {},
        u = 0,
        d, f = m(z(window.location)),
        p = _o(),
        h = !0,
        g = o ? .name,
        _ = o ? .service || r.service,
        v = o ? .version || r.version,
        y = o ? .context,
        b = o ? .handlingStack;
    y && p.setContext(y);
    let x = {
        id: s,
        name: g,
        startClocks: a,
        service: _,
        version: v,
        context: y,
        url: o ? .url
    };
    e.notify(1, x), e.notify(2, x);
    let {
        throttled: S,
        cancel: ee
    } = we(fe, ef, {
        leading: !1
    }), {
        setLoadEvent: te,
        setViewEnd: ne,
        stop: re,
        stopINPTracking: C,
        getCommonViewMetrics: w,
        setLoadingTime: ie
    } = Zd(e, t, n, r, de, i, a), {
        stop: ae,
        initialViewMetrics: E
    } = i === Po.INITIAL_LOAD ? md(r, a, te, de) : {
        stop: I,
        initialViewMetrics: {}
    };
    i === Po.BF_CACHE && $d(a, E, de);
    let {
        stop: ce,
        eventCounts: le
    } = ed(e, s, de), ue = oe(fe, tf), O = e.subscribe(11, (e) => {
        e.reason === Mi.UNLOADING && fe();
    });
    fe(), p.changeObservable.subscribe(de);

    function k() {
        e.notify(3, {
            id: s,
            name: g,
            context: p.getContext(),
            startClocks: a,
            sessionIsActive: h
        });
    }

    function de() {
        k(), S();
    }

    function fe() {
        ee(), k(), u += 1;
        let t = d === void 0 ? M() : d.timeStamp;
        e.notify(4, {
            customTimings: l,
            documentVersion: u,
            id: s,
            name: g,
            service: _,
            version: v,
            context: p.getContext(),
            loadingType: i,
            location: f,
            handlingStack: b,
            startClocks: a,
            commonViewMetrics: w(),
            initialViewMetrics: E,
            duration: F(a.timeStamp, t),
            isActive: d === void 0,
            sessionIsActive: h,
            eventCounts: le
        });
    }
    return {
        get name() {
            return g;
        },
        service: _,
        version: v,
        contextManager: p,
        stopObservable: c,
        end(t = {}) {
            d || (d = t.endClocks ? ? P(), h = t.sessionIsActive ? ? !0, e.notify(5, {
                endClocks: d
            }), e.notify(6, {
                endClocks: d
            }), se(ue), ne(d.relative), re(), O.unsubscribe(), fe(), T(() => {
                this.stop();
            }, nf));
        },
        stop() {
            ae(), ce(), C(), c.notify();
        },
        addTiming(e, t) {
            if (d) return;
            let n = xe(t) ? t : F(a.timeStamp, t);
            l[ of (e)] = n, de();
        },
        setLoadingTime: ie,
        setViewName(e) {
            g = e, fe();
        }
    };
}

function of (e) {
    let t = e.replace(/[^a-zA-Z0-9-_.@$]/g, "_");
    return t !== e && i.warn(`Invalid timing name: ${e}, sanitized to: ${t}`), t;
}

function sf(e, t) {
    return e.pathname !== t.pathname || !cf(t.hash) && lf(t.hash) !== lf(e.hash);
}

function cf(e) {
    let t = e.substring(1);
    return t !== "" && !!document.getElementById(t);
}

function lf(e) {
    let t = e.indexOf("?");
    return t < 0 ? e : e.slice(0, t);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewCollection.js
function uf(e, t, n, r, i, a, o, s, c) {
    return e.subscribe(4, (t) => e.notify(12, df(t, n, o))), t.register(0, ({
        startTime: e,
        eventType: t
    }) => {
        let n = s.findView(e);
        return n ? {
            type: t,
            service: n.service,
            version: n.version,
            context: n.context,
            view: {
                id: n.id,
                name: n.name
            }
        } : Hi;
    }), t.register(1, ({
        startTime: e
    }) => ({
        view: {
            id: s.findView(e) ? .id
        }
    })), rf(e, r, i, n, a, !n.trackViewsManually, c);
}

function df(e, t, n) {
    let r = n.getReplayStats(e.id),
        i = e.commonViewMetrics ? .cumulativeLayoutShift ? .devicePixelRatio,
        a = {
            _dd: {
                document_version: e.documentVersion,
                replay_stats: r,
                cls: i ? {
                    device_pixel_ratio: i
                } : void 0,
                configuration: {
                    start_session_replay_recording_manually: t.startSessionReplayRecordingManually
                }
            },
            date: e.startClocks.timeStamp,
            type: Z.VIEW,
            view: {
                action: {
                    count: e.eventCounts.actionCount
                },
                frustration: {
                    count: e.eventCounts.frustrationCount
                },
                cumulative_layout_shift: e.commonViewMetrics.cumulativeLayoutShift ? .value,
                cumulative_layout_shift_time: A(e.commonViewMetrics.cumulativeLayoutShift ? .time),
                cumulative_layout_shift_target_selector: e.commonViewMetrics.cumulativeLayoutShift ? .targetSelector,
                first_byte: A(e.initialViewMetrics.navigationTimings ? .firstByte),
                dom_complete: A(e.initialViewMetrics.navigationTimings ? .domComplete),
                dom_content_loaded: A(e.initialViewMetrics.navigationTimings ? .domContentLoaded),
                dom_interactive: A(e.initialViewMetrics.navigationTimings ? .domInteractive),
                error: {
                    count: e.eventCounts.errorCount
                },
                first_contentful_paint: A(e.initialViewMetrics.firstContentfulPaint),
                first_input_delay: A(e.initialViewMetrics.firstInput ? .delay),
                first_input_time: A(e.initialViewMetrics.firstInput ? .time),
                first_input_target_selector: e.initialViewMetrics.firstInput ? .targetSelector,
                interaction_to_next_paint: A(e.commonViewMetrics.interactionToNextPaint ? .value),
                interaction_to_next_paint_time: A(e.commonViewMetrics.interactionToNextPaint ? .time),
                interaction_to_next_paint_target_selector: e.commonViewMetrics.interactionToNextPaint ? .targetSelector,
                is_active: e.isActive,
                name: e.name,
                largest_contentful_paint: A(e.initialViewMetrics.largestContentfulPaint ? .value),
                largest_contentful_paint_target_selector: e.initialViewMetrics.largestContentfulPaint ? .targetSelector,
                load_event: A(e.initialViewMetrics.navigationTimings ? .loadEvent),
                loading_time: Cc(A(e.commonViewMetrics.loadingTime)),
                loading_type: e.loadingType,
                long_task: {
                    count: e.eventCounts.longTaskCount
                },
                performance: ff(e.commonViewMetrics, e.initialViewMetrics),
                resource: {
                    count: e.eventCounts.resourceCount
                },
                time_spent: A(e.duration)
            },
            display: e.commonViewMetrics.scroll ? {
                scroll: {
                    max_depth: e.commonViewMetrics.scroll.maxDepth,
                    max_depth_scroll_top: e.commonViewMetrics.scroll.maxDepthScrollTop,
                    max_scroll_height: e.commonViewMetrics.scroll.maxScrollHeight,
                    max_scroll_height_time: A(e.commonViewMetrics.scroll.maxScrollHeightTime)
                }
            } : void 0,
            privacy: {
                replay_level: t.defaultPrivacyLevel
            },
            device: {
                locale: navigator.language,
                locales: navigator.languages,
                time_zone: Mo()
            }
        };
    return g(e.customTimings) || (a.view.custom_timings = _(e.customTimings, A)), {
        rawRumEvent: a,
        startClocks: e.startClocks,
        duration: e.duration,
        domainContext: {
            location: e.location,
            handlingStack: e.handlingStack
        }
    };
}

function ff({
    cumulativeLayoutShift: e,
    interactionToNextPaint: t
}, {
    firstContentfulPaint: n,
    firstInput: r,
    largestContentfulPaint: i
}) {
    return {
        cls: e && {
            score: e.value,
            timestamp: A(e.time),
            target_selector: e.targetSelector,
            previous_rect: e.previousRect,
            current_rect: e.currentRect
        },
        fcp: n && {
            timestamp: A(n)
        },
        fid: r && {
            duration: A(r.delay),
            timestamp: A(r.time),
            target_selector: r.targetSelector
        },
        inp: t && {
            duration: A(t.value),
            timestamp: A(t.time),
            target_selector: t.targetSelector,
            sub_parts: t.subParts ? {
                input_delay: A(t.subParts.inputDelay),
                processing_duration: A(t.subParts.processingDuration),
                presentation_delay: A(t.subParts.presentationDelay)
            } : void 0
        },
        lcp: i && {
            timestamp: A(i.value),
            target_selector: i.targetSelector,
            resource_url: i.resourceUrl,
            sub_parts: i.subParts ? {
                load_delay: A(i.subParts.loadDelay),
                load_time: A(i.subParts.loadTime),
                render_delay: A(i.subParts.renderDelay)
            } : void 0
        }
    };
}

function pf(e, t, n) {
    let r = Aa(e, "rum", (t) => hf(e, t), n);
    return r.expireObservable.subscribe(() => {
        t.notify(9);
    }), r.renewObservable.subscribe(() => {
        t.notify(10);
    }), r.sessionStateUpdateObservable.subscribe(({
        previousState: e,
        newState: t
    }) => {
        if (!e.forcedReplay && t.forcedReplay) {
            let e = r.findSession();
            e && (e.isReplayForced = !0);
        }
    }), {
        findTrackedSession: (e) => {
            let t = r.findSession(e);
            if (!(!t || t.trackingType === "0")) return {
                id: t.id,
                sessionReplay: t.trackingType === "1" ? 1 : t.isReplayForced ? 2 : 0,
                anonymousId: t.anonymousId
            };
        },
        expire: r.expire,
        expireObservable: r.expireObservable,
        setForcedReplay: () => r.updateSessionState({
            forcedReplay: "1"
        })
    };
}

function mf() {
    let e = {
        id: "00000000-aaaa-0000-aaaa-000000000000",
        sessionReplay: ki("records") ? 1 : 0
    };
    return {
        findTrackedSession: () => e,
        expire: I,
        expireObservable: new D(),
        setForcedReplay: I
    };
}

function hf(e, t) {
    return gf(t) ? t : l(e.sessionSampleRate) ? l(e.sessionReplaySampleRate) ? "1" : "2" : "0";
}

function gf(e) {
    return e === "0" || e === "1" || e === "2";
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/transport/startRumBatch.js
function _f(e, t, n, r, i, a) {
    let o = [e.rumEndpointBuilder];
    e.replica && o.push(e.replica.rumEndpointBuilder);
    let s = Ii({
        encoder: a(2),
        request: Ci(o, n),
        flushController: Bi({
            pageMayExitObservable: r,
            sessionExpireObservable: i
        })
    });
    return t.subscribe(13, (e) => {
        e.type === Z.VIEW ? s.upsert(e, e.view.id) : s.add(e);
    }), s;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/transport/startRumEventBridge.js
function vf(e) {
    let t = Oi();
    e.subscribe(13, (e) => {
        t.send("rum", e);
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/urlContexts.js
var yf = tt;

function bf(e, t, n) {
    let r = ga({
            expireDelay: yf
        }),
        i;
    e.subscribe(1, ({
        startClocks: e,
        url: t
    }) => {
        let n = z(location).href,
            a = t === void 0 ? n : Re(t, n).href;
        r.add(o({
            url: a,
            referrer: i || document.referrer
        }), e.relative), i = a;
    }), e.subscribe(6, ({
        endClocks: e
    }) => {
        r.closeActive(e.relative);
    });
    let a = n.subscribe(({
        newLocation: e
    }) => {
        let t = r.find();
        if (t) {
            let n = N();
            r.closeActive(n), r.add(o({
                url: e.href,
                referrer: t.referrer
            }), n);
        }
    });

    function o({
        url: e,
        referrer: t
    }) {
        return {
            url: e,
            referrer: t
        };
    }
    return t.register(0, ({
        startTime: e,
        eventType: t
    }) => {
        let n = r.find(e);
        return n ? {
            type: t,
            view: {
                url: n.url,
                referrer: n.referrer
            }
        } : Hi;
    }), {
        findUrl: (e) => r.find(e),
        stop: () => {
            a.unsubscribe(), r.stop();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/locationChangeObservable.js
function xf(e) {
    let t = m(location);
    return new D((n) => {
        let {
            stop: r
        } = Sf(e, a), {
            stop: i
        } = Cf(e, a);

        function a() {
            if (t.href === location.href) return;
            let e = m(location);
            n.notify({
                newLocation: e,
                oldLocation: t
            }), t = e;
        }
        return () => {
            r(), i();
        };
    });
}

function Sf(e, t) {
    let {
        stop: n
    } = H(wf("pushState"), "pushState", ({
        onPostCall: e
    }) => {
        e(t);
    }), {
        stop: r
    } = H(wf("replaceState"), "replaceState", ({
        onPostCall: e
    }) => {
        e(t);
    }), {
        stop: i
    } = W(e, window, "popstate", t);
    return {
        stop: () => {
            n(), r(), i();
        }
    };
}

function Cf(e, t) {
    return W(e, window, "hashchange", t);
}

function wf(e) {
    return Object.prototype.hasOwnProperty.call(history, e) ? history : History.prototype;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/featureFlagContext.js
var Tf = tt;

function Ef(e, t, n) {
    let r = ga({
        expireDelay: Tf
    });
    return e.subscribe(1, ({
        startClocks: e
    }) => {
        r.add({}, e.relative);
    }), e.subscribe(6, ({
        endClocks: e
    }) => {
        r.closeActive(e.relative);
    }), t.register(0, ({
        startTime: e,
        eventType: t
    }) => {
        if (!n.trackFeatureFlagsForEvents.concat([Z.VIEW, Z.ERROR]).includes(t)) return G;
        let i = r.find(e);
        return !i || g(i) ? G : {
            type: t,
            feature_flags: i
        };
    }), {
        addFeatureFlagEvaluation: (e, t) => {
            let n = r.find();
            n && (n[e] = t);
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/startCustomerDataTelemetry.js
var Df = 10 * O,
    Of, kf;

function Af(e, t, n) {
    e.metricsEnabled && (Pf(), kf = !1, t.subscribe(13, () => {
        kf = !0;
    }), n.subscribe(({
        bytesCount: e,
        messagesCount: t
    }) => {
        kf && (kf = !1, Of.batchCount += 1, Nf(Of.batchBytesCount, e), Nf(Of.batchMessagesCount, t));
    }), oe(jf, Df));
}

function jf() {
    Of.batchCount !== 0 && (aa("Customer data measures", Of), Pf());
}

function Mf() {
    return {
        min: Infinity,
        max: 0,
        sum: 0
    };
}

function Nf(e, t) {
    e.sum += t, e.min = Math.min(e.min, t), e.max = Math.max(e.max, t);
}

function Pf() {
    Of = {
        batchCount: 0,
        batchBytesCount: Mf(),
        batchMessagesCount: Mf()
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/pageStateHistory.js
var Ff = 4e3,
    If = tt;

function Lf(e, t, n = 500) {
    let r = ga({
            expireDelay: If,
            maxEntries: Ff
        }),
        i;
    Rc(Q.VISIBILITY_STATE) && performance.getEntriesByType(Q.VISIBILITY_STATE).forEach((e) => {
        o(e.name === "hidden" ? "hidden" : "active", e.startTime);
    }), o(Bf(), N());
    let {
        stop: a
    } = Vr(t, window, [
        "pageshow",
        "focus",
        "blur",
        "visibilitychange",
        "resume",
        "freeze",
        "pagehide"
    ], (e) => {
        o(zf(e), e.timeStamp);
    }, {
        capture: !0
    });

    function o(e, t = N()) {
        e !== i && (i = e, r.closeActive(t), r.add({
            state: i,
            startTime: t
        }, t));
    }

    function s(e, t, n) {
        return r.findAll(t, n).some((t) => t.state === e);
    }
    return e.register(0, ({
        startTime: e,
        duration: t = 0,
        eventType: i
    }) => i === Z.VIEW ? {
        type: i,
        _dd: {
            page_states: Rf(r.findAll(e, t), e, n)
        }
    } : i === Z.ACTION || i === Z.ERROR ? {
        type: i,
        view: {
            in_foreground: s("active", e, 0)
        }
    } : G), {
        wasInPageStateDuringPeriod: s,
        addPageState: o,
        stop: () => {
            a(), r.stop();
        }
    };
}

function Rf(e, t, n) {
    if (e.length !== 0) return e.slice(-n).reverse().map(({
        state: e,
        startTime: n
    }) => ({
        state: e,
        start: A(F(t, n))
    }));
}

function zf(e) {
    return e.type === "freeze" ? "frozen" : e.type === "pagehide" ? e.persisted ? "frozen" : "terminated" : Bf();
}

function Bf() {
    return document.visibilityState === "hidden" ? "hidden" : document.hasFocus() ? "active" : "passive";
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/displayContext.js
function Vf(e, t) {
    let n, r = requestAnimationFrame(C(() => {
            n = Kd();
        })),
        i = Wd(t).subscribe((e) => {
            n = e;
        }).unsubscribe;
    return e.register(0, ({
        eventType: e
    }) => ({
        type: e,
        display: n ? {
            viewport: n
        } : void 0
    })), {
        stop: () => {
            i(), r && cancelAnimationFrame(r);
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/browser/cookieObservable.js
function Hf(e, t) {
    let n = window.cookieStore ? Uf(e) : Gf;
    return new D((e) => n(t, (t) => e.notify(t)));
}

function Uf(e) {
    return (t, n) => W(e, window.cookieStore, "change", (e) => {
        let r = e.changed.find((e) => e.name === t) || e.deleted.find((e) => e.name === t);
        r && n(r.value);
    }).stop;
}
var Wf = O;

function Gf(e, t) {
    let n = Ee(document.cookie, e),
        r = oe(() => {
            let r = Ee(document.cookie, e);
            r !== n && (n = r, t(r));
        }, Wf);
    return () => {
        se(r);
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/ciVisibilityContext.js
var Kf = "datadog-ci-visibility-test-execution-id";

function qf(e, t, n = Hf(e, Kf)) {
    let r = Ge("datadog-ci-visibility-test-execution-id") || window.Cypress ? .env("traceId"),
        i = n.subscribe((e) => {
            r = e;
        });
    return t.register(0, ({
        eventType: e
    }) => typeof r == "string" ? {
        type: e,
        session: {
            type: "ci_test"
        },
        ci_test: {
            test_execution_id: r
        }
    } : G), {
        stop: () => {
            i.unsubscribe();
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/longTask/longTaskCollection.js
function Jf(e, t) {
    let n = Pc(t, {
        type: Rc(Q.LONG_ANIMATION_FRAME) ? Q.LONG_ANIMATION_FRAME : Q.LONG_TASK,
        buffered: !0
    }).subscribe((n) => {
        for (let r of n) {
            if (!t.trackLongTasks) break;
            let n = pe(r.startTime),
                i = Yf(r, n);
            e.notify(12, {
                rawRumEvent: i,
                startClocks: n,
                duration: r.duration,
                domainContext: {
                    performanceEntry: r
                }
            });
        }
    });
    return {
        stop: () => n.unsubscribe()
    };
}

function Yf(e, t) {
    let n = L(),
        r = A(e.duration),
        i = {
            date: t.timeStamp,
            type: Z.LONG_TASK,
            _dd: {
                discarded: !1
            }
        };
    return e.entryType === Q.LONG_TASK ? {
        ...i,
        long_task: {
            id: n,
            entry_type: No.LONG_TASK,
            duration: r
        }
    } : {
        ...i,
        long_task: {
            id: n,
            entry_type: No.LONG_ANIMATION_FRAME,
            duration: r,
            blocking_duration: A(e.blockingDuration),
            first_ui_event_timestamp: A(e.firstUIEventTimestamp),
            render_start: A(e.renderStart),
            style_and_layout_start: A(e.styleAndLayoutStart),
            start_time: A(e.startTime),
            scripts: e.scripts.map((e) => ({
                duration: A(e.duration),
                pause_duration: A(e.pauseDuration),
                forced_style_and_layout_duration: A(e.forcedStyleAndLayoutDuration),
                start_time: A(e.startTime),
                execution_start: A(e.executionStart),
                source_url: e.sourceURL,
                source_function_name: e.sourceFunctionName,
                source_char_position: e.sourceCharPosition,
                invoker: e.invoker,
                invoker_type: e.invokerType,
                window_attribution: e.windowAttribution
            }))
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/syntheticsContext.js
function Xf(e) {
    e.register(0, ({
        eventType: e
    }) => wa() ? {
        type: e,
        session: {
            type: "synthetics"
        },
        synthetics: {
            ...Ca(),
            injected: Sa()
        }
    } : G);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/limitModification.js
function Zf(e, t, n) {
    let r = ri(e),
        i = n(r);
    return et(t).forEach(([t, n]) => Qf(e, r, t.split(/\.|(?=\[\])/), n)), i;
}

function Qf(e, t, n, r) {
    let [i, ...a] = n;
    if (i === "[]") {
        Array.isArray(e) && Array.isArray(t) && e.forEach((e, n) => Qf(e, t[n], a, r));
        return;
    }
    if (!(!ep(e) || !ep(t))) {
        if (a.length > 0) return Qf(e[i], t[i], a, r);
        $f(e, i, t[i], r);
    }
}

function $f(e, t, n, r) {
    if (e[t] === n) return;
    let i = tn(n);
    i === r ? e[t] = U(n) : r === "object" && (i === "undefined" || i === "null") && (e[t] = {});
}

function ep(e) {
    return tn(e) === "object";
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/assembly.js
var tp = {
        "view.name": "string",
        "view.url": "string",
        "view.referrer": "string"
    },
    np = {
        context: "object"
    },
    rp = {
        service: "string",
        version: "string"
    },
    ip;

function ap(e, t, n, r, i) {
    ip = {
        [Z.VIEW]: {
            "view.performance.lcp.resource_url": "string",
            ...np,
            ...tp,
            ...rp
        },
        [Z.ERROR]: {
            "error.message": "string",
            "error.stack": "string",
            "error.resource.url": "string",
            "error.fingerprint": "string",
            ...np,
            ...tp,
            ...rp
        },
        [Z.RESOURCE]: {
            "resource.url": "string",
            "resource.graphql.variables": "string",
            ...np,
            ...tp,
            ...rp
        },
        [Z.ACTION]: {
            "action.target.name": "string",
            ...np,
            ...tp,
            ...rp
        },
        [Z.LONG_TASK]: {
            "long_task.scripts[].source_url": "string",
            "long_task.scripts[].invoker": "string",
            ...np,
            ...tp,
            ...rp
        },
        [Z.VITAL]: {
            ...np,
            ...tp,
            ...rp
        }
    };
    let a = {
        [Z.ERROR]: za(Z.ERROR, r, i),
        [Z.ACTION]: za(Z.ACTION, r, i),
        [Z.VITAL]: za(Z.VITAL, r, i)
    };
    t.subscribe(12, ({
        startClocks: r,
        duration: i,
        rawRumEvent: o,
        domainContext: s
    }) => {
        let c = n.triggerHook(0, {
            eventType: o.type,
            rawRumEvent: o,
            domainContext: s,
            startTime: r.relative,
            duration: i
        });
        if (c === "DISCARDED") return;
        let l = ii(c, o, {
            ddtags: Xr(e).join(",")
        });
        op(l, e.beforeSend, s, a) && (g(l.context) && delete l.context, t.notify(13, l));
    });
}

function op(e, t, n, r) {
    if (t) {
        let r = Zf(e, ip[e.type], (e) => t(e, n));
        if (r === !1 && e.type !== Z.VIEW) return !1;
        r === !1 && i.warn("Can't dismiss view events using beforeSend!");
    }
    return !r[e.type] ? .isLimitReached();
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/sessionContext.js
function sp(e, t, n, r) {
    e.register(0, ({
        eventType: e,
        startTime: i
    }) => {
        let a = t.findTrackedSession(i),
            o = r.findView(i);
        if (!a || !o) return Hi;
        let s, c, l;
        return e === Z.VIEW ? (s = n.getReplayStats(o.id) ? !0 : void 0, c = a.sessionReplay === 1, l = o.sessionIsActive ? void 0 : !1) : s = n.isRecording() ? !0 : void 0, {
            type: e,
            session: {
                id: a.id,
                type: "user",
                has_replay: s,
                sampled_for_replay: c,
                is_active: l
            }
        };
    }), e.register(1, ({
        startTime: e
    }) => {
        let n = t.findTrackedSession(e);
        return n ? {
            session: {
                id: n.id
            }
        } : G;
    });
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/connectivityContext.js
function cp(e) {
    e.register(0, ({
        eventType: e
    }) => ({
        type: e,
        connectivity: oi()
    }));
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/defaultContext.js
function lp(e, t, n) {
    e.register(0, ({
        eventType: e
    }) => {
        let r = t.source;
        return {
            type: e,
            _dd: {
                format_version: 2,
                drift: ge(),
                configuration: {
                    session_sample_rate: u(t.sessionSampleRate, 3),
                    session_replay_sample_rate: u(t.sessionReplaySampleRate, 3),
                    profiling_sample_rate: u(t.profilingSampleRate, 3),
                    trace_sample_rate: u(t.traceSampleRate, 3),
                    beta_encode_cookie_options: t.betaEncodeCookieOptions
                },
                browser_sdk_version: Ai() ? "6.31.0" : void 0,
                sdk_name: n
            },
            application: {
                id: t.applicationId
            },
            date: M(),
            source: r
        };
    }), e.register(1, () => ({
        application: {
            id: t.applicationId
        }
    }));
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/trackingConsentContext.js
function up(e, t) {
    e.register(1, () => t.isGranted() ? G : Hi);
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/event/eventCollection.js
var dp = [
    Z.ACTION,
    Z.ERROR,
    Z.LONG_TASK,
    Z.RESOURCE,
    Z.VITAL
];

function fp(e) {
    return {
        addEvent: (t, n, r, i) => {
            dp.includes(n.type) && e.notify(12, {
                startClocks: pe(t),
                rawRumEvent: n,
                domainContext: r,
                duration: i
            });
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/view/viewMetrics/startInitialViewMetricsTelemetry.js
function pp(e, t) {
    if (!t.metricsEnabled) return {
        stop: I
    };
    let {
        unsubscribe: n
    } = e.subscribe(4, ({
        initialViewMetrics: e
    }) => {
        !e.largestContentfulPaint || !e.navigationTimings || (aa("Initial view metrics", {
            metrics: mp(e.largestContentfulPaint, e.navigationTimings)
        }), n());
    });
    return {
        stop: n
    };
}

function mp(e, t) {
    return {
        lcp: {
            value: e.value
        },
        navigation: {
            domComplete: t.domComplete,
            domContentLoaded: t.domContentLoaded,
            domInteractive: t.domInteractive,
            firstByte: t.firstByte,
            loadEvent: t.loadEvent
        }
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/contexts/sourceCodeContext.js
function hp(e) {
    let t = window,
        n = /* @__PURE__ */ new Map();

    function r() {
        t.DD_SOURCE_CODE_CONTEXT && = (et(t.DD_SOURCE_CODE_CONTEXT).forEach(([e, t]) => {
            let r = zn({
                stack: e
            }).stack[0];
            if (!r.url) {
                ra("Source code context: missing frame url", {
                    stack: e
                });
                return;
            }
            n.has(r.url) || n.set(r.url, t);
        }), {});
    }
    r(), e.register(0, ({
        domainContext: e,
        rawRumEvent: t
    }) => {
        if (r(), n.size === 0) return G;
        let i = gp(e, t),
            a = i && n.get(i);
        return a ? {
            type: t.type,
            service: a.service,
            version: a.version
        } : G;
    });
}

function gp(e, t) {
    if (t.type === "long_task" && t.long_task.entry_type === "long-animation-frame") return t.long_task.scripts[0] ? .source_url;
    let n;
    return "handlingStack" in e && (n = e.handlingStack), t.type === "error" && t.error.stack && (n = t.error.stack), zn({
        stack: n
    }).stack[0] ? .url;
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/boot/startRum.js
function _p(e, t, n, r, i, a, o, s, c, l, u) {
    let d = [],
        f = new js();
    f.subscribe(13, (e) => ti("rum", e));
    let p = (e) => {
            f.notify(14, {
                error: e
            }), na("Error reported to customer", {
                "error.message": e.message
            });
        },
        m = Ni(e),
        h = m.subscribe((e) => {
            f.notify(11, e);
        });
    d.push(() => h.unsubscribe());
    let g = Ai() ? mf() : pf(e, f, a);
    if (Ai()) vf(f);
    else {
        let t = _f(e, f, p, m, g.expireObservable, i);
        d.push(() => t.stop()), Af(c, f, t.flushController.flushObservable);
    }
    up(l, a);
    let {
        stop: _
    } = pp(f, c);
    d.push(_);
    let {
        stop: v,
        ...y
    } = vp(f, l, e, g, t, r, o, s, u, p);
    return d.push(v), s.unbuffer(), d.push(() => n.stop()), {
        ...y,
        lifeCycle: f,
        session: g,
        stopSession: () => g.expire(),
        telemetry: c,
        stop: () => {
            d.forEach((e) => e());
        },
        hooks: l
    };
}

function vp(e, t, n, r, i, a, o, s, c, l) {
    let u = [],
        d = Ds(),
        f = xf(n),
        {
            observable: p,
            stop: m
        } = ks();
    u.push(m), lp(t, n, c);
    let h = Lf(t, n);
    u.push(() => h.stop());
    let g = Ns(e);
    u.push(() => g.stop());
    let _ = bf(e, t, f);
    u.push(() => _.stop());
    let v = Ef(e, t, n);
    sp(t, r, i, g), cp(t);
    let y = To(t, n, "rum", !0),
        b = Do(t, n, r, "rum"),
        x = Co(t, n, "rum"),
        S = hu(e, t, d, p, n);
    u.push(S.stop);
    let ee = fp(e),
        te = Vf(t, n);
    u.push(te.stop);
    let ne = qf(n, t);
    u.push(ne.stop), Xf(t), ap(n, e, t, l);
    let {
        addTiming: re,
        setLoadingTime: C,
        startView: w,
        setViewName: ie,
        setViewContext: ae,
        setViewContextProperty: T,
        getViewContext: E,
        stop: oe
    } = uf(e, t, n, d, p, f, i, g, a);
    hp(t), u.push(oe);
    let se = Hu(e, n, h);
    u.push(se.stop);
    let {
        stop: ce
    } = Jf(e, n);
    u.push(ce);
    let {
        addError: D
    } = bu(e, n, s);
    yc(e, n, r, b, x);
    let le = zo(e, h, o),
        ue = As(n.applicationId, r, g, S.actionContexts, _);
    return {
        addAction: S.addAction,
        startAction: S.startAction,
        stopAction: S.stopAction,
        startResource: se.startResource,
        stopResource: se.stopResource,
        addEvent: ee.addEvent,
        addError: D,
        addTiming: re,
        setLoadingTime: C,
        addFeatureFlagEvaluation: v.addFeatureFlagEvaluation,
        startView: w,
        setViewContext: ae,
        setViewContextProperty: T,
        getViewContext: E,
        setViewName: ie,
        viewHistory: g,
        getInternalContext: ue.get,
        startDurationVital: le.startDurationVital,
        stopDurationVital: le.stopDurationVital,
        addDurationVital: le.addDurationVital,
        addOperationStepVital: le.addOperationStepVital,
        globalContext: y,
        userContext: b,
        accountContext: x,
        stop: () => u.forEach((e) => e())
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/boot/rumPublicApi.js
function yp(e, t, n = {}) {
    let r = en(),
        i = Ro(),
        a = jo().observable,
        o = ws(n, r, i, (s, c, l, u, d) => {
            let f = c && n.createDeflateEncoder ? (e) => n.createDeflateEncoder(s, c, e) : Vi,
                p = z(_p)(s, e, t, l, f, r, i, a, u, d, n.sdkName);
            return e.onRumStart(p.lifeCycle, s, p.session, p.viewHistory, c, p.telemetry), t.onRumStart(p.lifeCycle, p.hooks, s, p.session, p.viewHistory, f), o = bp(o, p), Wo(s.plugins, "onRumStart", {
                strategy: o,
                addEvent: p.addEvent
            }), p;
        }),
        s = () => o,
        c = Rr({
            init: (e) => {
                let t = ( /* @__PURE__ */ Error()).stack;
                w(() => o.init(e, c, t));
            },
            setTrackingConsent: C((e) => {
                r.update(e), K({
                    feature: "set-tracking-consent",
                    tracking_consent: e
                });
            }),
            setViewName: C((e) => {
                o.setViewName(e), K({
                    feature: "set-view-name"
                });
            }),
            setViewContext: C((e) => {
                o.setViewContext(e), K({
                    feature: "set-view-context"
                });
            }),
            setViewContextProperty: C((e, t) => {
                o.setViewContextProperty(e, t), K({
                    feature: "set-view-context-property"
                });
            }),
            getViewContext: C(() => (K({
                feature: "set-view-context-property"
            }), o.getViewContext())),
            getInternalContext: C((e) => o.getInternalContext(e)),
            getInitConfiguration: C(() => ri(o.initConfiguration)),
            addAction: (e, t) => {
                let n = ar("action");
                w(() => {
                    o.addAction({
                        name: U(e),
                        context: U(t),
                        startClocks: P(),
                        type: Fo.CUSTOM,
                        handlingStack: n
                    }), K({
                        feature: "add-action"
                    });
                });
            },
            startAction: C((e, t) => {
                o.initConfiguration && !V(B.START_STOP_ACTION) || o.startAction(U(e), {
                    type: U(t && t.type),
                    context: U(t && t.context),
                    actionKey: t && t.actionKey
                });
            }),
            stopAction: C((e, t) => {
                o.initConfiguration && !V(B.START_STOP_ACTION) || o.stopAction(U(e), {
                    type: U(t && t.type),
                    context: U(t && t.context),
                    actionKey: t && t.actionKey
                });
            }),
            startResource: C((e, t) => {
                o.initConfiguration && !V(B.START_STOP_RESOURCE) || o.startResource(U(e), {
                    type: U(t && t.type),
                    method: U(t && t.method),
                    context: U(t && t.context),
                    resourceKey: t && t.resourceKey
                });
            }),
            stopResource: C((e, t) => {
                o.initConfiguration && !V(B.START_STOP_RESOURCE) || o.stopResource(U(e), {
                    type: U(t && t.type),
                    statusCode: t && t.statusCode,
                    size: t && t.size,
                    context: U(t && t.context),
                    resourceKey: t && t.resourceKey
                });
            }),
            addError: (e, t) => {
                let n = ar("error");
                w(() => {
                    o.addError({
                        error: e,
                        handlingStack: n,
                        context: U(t),
                        startClocks: P()
                    }), K({
                        feature: "add-error"
                    });
                });
            },
            addTiming: C((e, t) => {
                o.addTiming(U(e), t);
            }),
            setViewLoadingTime: C(() => {
                let e = M();
                o.setLoadingTime(e), K({
                    feature: "addViewLoadingTime"
                });
            }),
            setGlobalContext: q(s, J.globalContext, Y.setContext, "set-global-context"),
            getGlobalContext: q(s, J.globalContext, Y.getContext, "get-global-context"),
            setGlobalContextProperty: q(s, J.globalContext, Y.setContextProperty, "set-global-context-property"),
            removeGlobalContextProperty: q(s, J.globalContext, Y.removeContextProperty, "remove-global-context-property"),
            clearGlobalContext: q(s, J.globalContext, Y.clearContext, "clear-global-context"),
            setUser: q(s, J.userContext, Y.setContext, "set-user"),
            getUser: q(s, J.userContext, Y.getContext, "get-user"),
            setUserProperty: q(s, J.userContext, Y.setContextProperty, "set-user-property"),
            removeUserProperty: q(s, J.userContext, Y.removeContextProperty, "remove-user-property"),
            clearUser: q(s, J.userContext, Y.clearContext, "clear-user"),
            setAccount: q(s, J.accountContext, Y.setContext, "set-account"),
            getAccount: q(s, J.accountContext, Y.getContext, "get-account"),
            setAccountProperty: q(s, J.accountContext, Y.setContextProperty, "set-account-property"),
            removeAccountProperty: q(s, J.accountContext, Y.removeContextProperty, "remove-account-property"),
            clearAccount: q(s, J.accountContext, Y.clearContext, "clear-account"),
            startView: (e) => {
                let t = ar("view");
                w(() => {
                    let n = typeof e == "object" ? e : {
                        name: e
                    };
                    o.startView({
                        ...n,
                        handlingStack: t
                    }), K({
                        feature: "start-view"
                    });
                });
            },
            stopSession: C(() => {
                o.stopSession(), K({
                    feature: "stop-session"
                });
            }),
            addFeatureFlagEvaluation: C((e, t) => {
                o.addFeatureFlagEvaluation(U(e), U(t)), K({
                    feature: "add-feature-flag-evaluation"
                });
            }),
            getSessionReplayLink: C(() => e.getSessionReplayLink()),
            startSessionReplayRecording: C((t) => {
                e.start(t), K({
                    feature: "start-session-replay-recording",
                    force: t && t.force
                });
            }),
            stopSessionReplayRecording: C(() => e.stop()),
            addDurationVital: (e, t) => {
                let n = ar("vital");
                w(() => {
                    K({
                        feature: "add-duration-vital"
                    }), o.addDurationVital({
                        id: L(),
                        name: U(e),
                        type: Lo.DURATION,
                        startClocks: me(t.startTime),
                        duration: t.duration,
                        context: U(t && t.context),
                        description: U(t && t.description),
                        handlingStack: n
                    });
                });
            },
            startDurationVital: (e, t) => {
                let n = ar("vital");
                return w(() => (K({
                    feature: "start-duration-vital"
                }), o.startDurationVital(U(e), {
                    context: U(t && t.context),
                    description: U(t && t.description),
                    handlingStack: n
                })));
            },
            stopDurationVital: C((e, t) => {
                K({
                    feature: "stop-duration-vital"
                }), o.stopDurationVital(typeof e == "string" ? U(e) : e, {
                    context: U(t && t.context),
                    description: U(t && t.description)
                });
            }),
            startFeatureOperation: (e, t) => {
                let n = ar("vital");
                w(() => {
                    K({
                        feature: "add-operation-step-vital",
                        action_type: "start"
                    }), o.addOperationStepVital(e, "start", {
                        ...t,
                        handlingStack: n
                    });
                });
            },
            succeedFeatureOperation: C((e, t) => {
                K({
                    feature: "add-operation-step-vital",
                    action_type: "succeed"
                }), o.addOperationStepVital(e, "end", t);
            }),
            failFeatureOperation: C((e, t, n) => {
                K({
                    feature: "add-operation-step-vital",
                    action_type: "fail"
                }), o.addOperationStepVital(e, "end", n, t);
            })
        });
    return c;
}

function bp(e, t) {
    return {
        init: (e) => {
            Br("DD_RUM", e);
        },
        initConfiguration: e.initConfiguration,
        ...t
    };
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/domain/getSessionReplayUrl.js
function xp(e, {
    session: t,
    viewContext: n,
    errorType: r
}) {
    let i = t ? t.id : "no-session-id",
        a = [];
    return r !== void 0 && a.push(`error-type=${r}`), n && (a.push(`seed=${n.id}`), a.push(`from=${n.startClocks.timeStamp}`)), `${Sp(e)}${`/rum/replay/sessions/${i}`}?${a.join("&")}`;
}

function Sp(e) {
    let t = e.site,
        n = e.subdomain || Cp(e);
    return `https://${n ? `${n}.` : ""}${t}`;
}

function Cp(e) {
    switch (e.site) {
        case pn:
        case mn:
            return "app";
        case fn:
            return "dd";
        default:
            return;
    }
}
//#endregion
//#region ../../node_modules/@datadog/browser-rum-core/esm/transport/formDataTransport.js
function wp(e, t, n, r) {
    let i = Ci([e.profilingEndpointBuilder], (e) => {
            t.notify(14, {
                error: e
            }), na("Error reported to customer", {
                "error.message": e.message
            });
        }),
        a = n(r);
    return {
        async send({
            event: e,
            ...t
        }) {
            let n = new FormData(),
                r = mr(e);
            if (!r) throw Error("Failed to serialize event");
            n.append("event", new Blob([r], {
                type: "application/json"
            }), "event.json");
            let o = r.length;
            for (let [e, r] of et(t)) {
                let t = mr(r);
                if (!t) throw Error("Failed to serialize attachment");
                let i = await Tp(a, t);
                o += i.outputBytesCount, n.append(e, new Blob([i.output]), e);
            }
            i.send({
                data: n,
                bytesCount: o
            });
        }
    };
}

function Tp(e, t) {
    return new Promise((n) => {
        e.write(t), e.finish((e) => {
            n(e);
        });
    });
}
//#endregion
export {
    Sa as $, tt as $t, No as A, Vr as At, Co as B, H as Bt, Dc as C, b as Cn, ti as Ct, Os as D, i as Dn, Hr as Dt, Zs as E, a as En, Qr as Et, Oo as F, Dr as Ft, so as G, B as Gt, q as H, ar as Ht, Do as I, jr as It, Wa as J, Nn as Jt, no as K, Fn as Kt, Eo as L, U as Lt, ko as M, zr as Mt, Y as N, Rr as Nt, Fo as O, t as On, Ur as Ot, J as P, Pr as Pt, Aa as Q, en as Qt, To as R, lr as Rt, Ec as S, y as Sn, ri as St, $s as T, e as Tn, Xr as Tt, _o as U, or as Ut, vo as V, cr as Vt, po as W, zn as Wt, za as X, En as Xt, Va as Y, Mn as Yt, La as Z, z as Zt, dl as _, w as _n, Ai as _t, Wd as a, we as an, aa as at, jc as b, re as bn, ci as bt, gl as c, P as cn, Hi as ct, _l as d, F as dn, Vi as dt, $e as en, ga as et, bl as f, ye as fn, Bi as ft, ul as g, T as gn, ki as gt, $ as h, E as hn, Pi as ht, Kd as i, I as in , ra as it, jo as j, Br as jt, Z as k, n as kn, W as kt, vl as l, _e as ln, G as lt, pl as m, D as mn, Ni as mt, xp as n, je as nn, ia as nt, Vd as o, O as on, K as ot, yl as p, M as pn, Ii as pt, Qa as q, V as qt, yp as r, ke as rn, na as rt, Hd as s, ve as sn, Zi as st, wp as t, Re as tn, ca as tt, Cl as u, ge as un, Ui as ut, Q as v, C as vn, Oi as vt, Oc as w, l as wn, Zr as wt, kc as x, v as xn, ii as xt, Ac as y, ie as yn, Ci as yt, wo as z, pr as zt
};

//# sourceMappingURL=esm-4T8k2PPA.js.map