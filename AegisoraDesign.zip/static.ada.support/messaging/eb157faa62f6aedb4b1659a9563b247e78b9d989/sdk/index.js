//#region ../../shared/utils/src/browser-polyfills.ts
var e = Object.prototype.hasOwnProperty;

function t(e, t, n) {
    Object.defineProperty(e, t, {
        value: n,
        configurable: !0,
        writable: !0
    });
}
Object.hasOwn || t(Object, "hasOwn", (t, n) => {
    if (t == null) throw TypeError("ada browser-polyfills: Cannot convert undefined or null to object");
    return e.call(Object(t), n);
});

function n(e) {
    let t = Math.trunc(Number(this.length)) || 0,
        n = Math.trunc(Number(e)) || 0;
    return n < 0 && (n += t), n < 0 || n >= t ? void 0 : this[n];
}

function r(e) {
    let t = String(this),
        n = t.length,
        r = Math.trunc(Number(e)) || 0;
    return r < 0 && (r += n), r < 0 || r >= n ? void 0 : t.charAt(r);
}
var i = [
    globalThis.Int8Array,
    globalThis.Uint8Array,
    globalThis.Uint8ClampedArray,
    globalThis.Int16Array,
    globalThis.Uint16Array,
    globalThis.Int32Array,
    globalThis.Uint32Array,
    globalThis.Float32Array,
    globalThis.Float64Array,
    globalThis.BigInt64Array,
    globalThis.BigUint64Array
].filter(Boolean);
Array.prototype.at || t(Array.prototype, "at", n), String.prototype.at || t(String.prototype, "at", r);
for (let e of i) {
    let r = e.prototype;
    r.at || t(r, "at", n);
}
//#endregion
//#region ../../shared/utils/src/clusters.ts
var a = new Set([
        "ada.support",
        "us2.ada.support",
        "eu.ada.support",
        "maple.ada.support",
        "ada-dev.support",
        "ada-dev2.support",
        "ada-stage.support",
        "dev2-ada.support",
        "localhost"
    ]),
    o = new Set([
        "ada-dev.support",
        "ada-dev2.support",
        "ada-stage.support",
        "dev2-ada.support"
    ]),
    s = new Set([...a].filter((e) => e.split(".").length === 2)),
    c = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/;

function l(e, t) {
    let n = e.toLowerCase(),
        r = n.split(".");
    return (r.length === 3 || r.length === 4) && r[0] === t.toLowerCase() && c.test(n) && s.has(r.slice(-2).join("."));
}

function u(e) {
    if (!e) return;
    let t = e.trim();
    for (/^https?:\/\//i.test(t) && (t = t.slice(t.indexOf("//") + 2)); t.endsWith("/");) t = t.slice(0, -1);
    if (t = t.trim().toLowerCase(), !t) return;
    if (t === "localhost") return t;
    let n = t.includes(".") ? t : `${t}.ada.support`;
    return c.test(n) ? n : void 0;
}

function d(e) {
    let t = u(e);
    return t !== void 0 && o.has(t);
}
//#endregion
//#region ../../shared/utils/src/url.ts
var f = new Set([
        "localhost",
        "127.0.0.1",
        "[::1]",
        "::1"
    ]),
    p = ["messaging-assets.net", "messaging-demo.net"],
    m = new Set([
        "http",
        "https",
        "ftp",
        "ftps",
        "mailto",
        "tel",
        "sms",
        "callto",
        "cid",
        "xmpp"
    ]),
    h = new Set([
        "javascript",
        "data",
        "vbscript",
        "about",
        "blob",
        "file",
        "filesystem"
    ]),
    g = /^[A-Za-z0-9._+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/,
    _ = 254,
    v = RegExp("•|%E2%80%A2", "gi");

function y(e, t) {
    let n = e.replace(v, "a");
    if (n === e) return !1;
    if (t.hostname === "") return !0;
    try {
        return new URL(n).hostname !== t.hostname;
    } catch {
        return !0;
    }
}

function b(e) {
    return e.endsWith("/") ? e : `${e}/`;
}

function x(e) {
    let t = e.length;
    for (; t > 0 && e[t - 1] === "/";) --t;
    return e.slice(0, t);
}

function S(e) {
    return e.trim().toLowerCase().replace(/:$/, "");
}

function ee(e, t) {
    try {
        let n = new URL(e);
        if (n.username || n.password || y(e, n)) return !1;
        let r = S(n.protocol);
        if (h.has(r)) return !1;
        let i = new Set(t.map(S).filter(Boolean));
        return m.has(r) || i.has(r);
    } catch {
        return !1;
    }
}

function te(e, t = []) {
    if (typeof e != "string") return null;
    let n = e.trim();
    if (!n) return null;
    let r = n.length <= _ && g.test(n) ? `mailto:${n}` : n;
    return ee(r, t) ? r : null;
}

function ne(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    if (!t) return null;
    try {
        let e = new URL(t);
        if (e.username || e.password || y(t, e)) return null;
        let n = e.protocol === "https:",
            r = e.protocol === "http:" && C(e.hostname);
        return n || r ? e.toString() : null;
    } catch {
        return null;
    }
}

function C(e, t = {}) {
    let n = e.trim().toLowerCase();
    return n ? f.has(n) || n.endsWith(".localhost") ? !0 : t.additionalHosts ? t.additionalHosts.some((e) => e.trim().toLowerCase() === n) : !1 : !1;
}

function re(e, t) {
    let n = e.trim();
    if (!n) return null;
    if (n.startsWith("/")) {
        if (n.startsWith("//")) return null;
        try {
            let e = new URL(n, t);
            return e.search || e.hash || e.username || e.password ? null : b(e.pathname);
        } catch {
            return null;
        }
    }
    try {
        let e = new URL(n);
        if (e.origin === "null" || e.search || e.hash || e.username || e.password) return null;
        let r = e.protocol === "https:",
            i = e.protocol === "http:" && C(e.hostname),
            a = e.protocol === "http:" && e.origin === t;
        return !r && !i && !a ? null : b(e.toString());
    } catch {
        return null;
    }
}
var ie = new Set([...a].filter((e) => e !== "localhost").map((e) => e.split(".").slice(-2).join(".")));

function ae(e) {
    let t;
    try {
        t = new URL(e);
    } catch {
        return !1;
    }
    let n = t.hostname;
    for (let e of ie)
        if (n === e || n.endsWith(`.${e}`)) return !0;
    return !1;
}

function w(e, t = {}) {
    if (typeof e != "string") return;
    let n = e.trim();
    if (!n) return;
    let r;
    try {
        r = new URL(n);
    } catch {
        return;
    }
    let i = r.protocol === "https:",
        a = r.protocol === "http:" && C(r.hostname);
    if (!i && !a || r.origin === "null" || r.username !== "" || r.password !== "" || ae(r.origin)) return;
    let o = t.currentOrigin ? T(t.currentOrigin) : null;
    if (!(o && r.origin === o)) return r.toString();
}
var oe = "local-network-access; loopback-network";

function se(e) {
    try {
        return C(new URL(e).hostname);
    } catch {
        return !1;
    }
}

function T(e, t = {}) {
    if (!e) return null;
    let n = e.trim();
    if (!n) return null;
    try {
        let e = t.baseUrl ? .trim() ? new URL(n, t.baseUrl) : new URL(n);
        return e.origin === "null" || e.protocol !== "http:" && e.protocol !== "https:" ? null : e.origin;
    } catch {
        return null;
    }
}

function ce(e) {
    return e === "file://" || e === "null" ? e : T(e);
}

function le(e) {
    return e === "file://" || e === "null" ? "*" : e;
}
//#endregion
//#region ../../shared/utils/src/webview-privilege.ts
var ue = new Set([
        "messaging-assets.ada.support",
        "static.ada.support",
        "messaging-assets.ada-dev2.support"
    ]),
    de = "/sdk/webview.html",
    fe = "10.0.2.2";

function pe(e) {
    try {
        if (!e) return !1;
        let t = e.protocol.toLowerCase(),
            n = e.hostname.toLowerCase();
        return e.pathname.toLowerCase().endsWith("/sdk/webview.html") ? t === "https:" && ue.has(n) ? !0 : t !== "https:" && t !== "http:" ? !1 : C(n, {
            additionalHosts: [...p, fe]
        }) : !1;
    } catch {
        return !1;
    }
}
//#endregion
//#region ../../shared/utils/src/android-webview.ts
function me(e, t) {
    return pe(e) ? !0 : e.protocol === "file:" ? e.pathname.startsWith("/android_asset/") : e.protocol === "https:" && (e.pathname === "/mobile-sdk-webview" || e.pathname.startsWith("/mobile-sdk-webview/")) && l(e.hostname, t);
}
//#endregion
//#region ../../shared/utils/src/guards.ts
var he = Object.prototype.hasOwnProperty;

function E(e) {
    return typeof e == "object" && e ? e : null;
}

function D(e, t = {}) {
    return typeof e != "string" || !e.trim() ? null : t.trimOutput === !1 ? e : e.trim();
}

function ge(e) {
    return typeof e == "boolean" ? e : null;
}

function _e(e) {
    return typeof e == "number" && Number.isFinite(e) ? e : null;
}

function ve(e, t) {
    return he.call(e, t);
}
//#endregion
//#region ../../shared/utils/src/chat-availability.ts
function ye(e) {
    return ge(e.chat_enabled ? ? e.chatEnabled ? ? E(e.chat) ? .enabled ? ? e.chat);
}
var be = "survey.submit",
    O = 1e3;

function xe(e) {
    return e === "survey.submitted" ? be : e;
}
var Se = new Set([
    "NUMERIC",
    "NUMERIC_TEN",
    "THUMBS",
    "EMOJI"
]);

function Ce(e) {
    return e ? .style === "NUMERIC_TEN" ? e.score / 2 : e ? .style === "THUMBS" ? e.score * 4 + 1 : e ? .score;
}

function k(e, t) {
    if (!Number.isInteger(t)) return !1;
    switch (e) {
        case "NUMERIC":
        case "EMOJI":
            return t >= 1 && t <= 5;
        case "NUMERIC_TEN":
            return t >= 1 && t <= 10;
        case "THUMBS":
            return t === 0 || t === 1;
    }
}

function we(e, t) {
    if (!Number.isInteger(e) || typeof t != "string" || !t.trim()) return null;
    let n = t.trim();
    if (Se.has(n)) {
        let t = n;
        return k(t, e) ? {
            score: e,
            style: t
        } : null;
    }
    switch (n.toLowerCase()) {
        case "1-5":
            return k("NUMERIC", e) ? {
                score: e,
                style: "NUMERIC"
            } : null;
        case "1-10":
            return k("NUMERIC_TEN", e) ? {
                score: e,
                style: "NUMERIC_TEN"
            } : null;
        case "emoji":
            return k("EMOJI", e) ? {
                score: e,
                style: "EMOJI"
            } : null;
        case "thumbs":
            return e === 1 ? {
                score: 0,
                style: "THUMBS"
            } : e === 5 ? {
                score: 1,
                style: "THUMBS"
            } : null;
        case "1-7":
        case "0-10":
            return null;
        default:
            return null;
    }
}
//#endregion
//#region ../../shared/utils/src/custom-app-frame-styles.ts
var Te = [
        "origin_not_allowlisted",
        "allowlist_unavailable",
        "frame_load_failed",
        "handshake_timeout"
    ],
    Ee = /^#(?:[\da-f]{3}|[\da-f]{4}|[\da-f]{6}|[\da-f]{8})$/i,
    De = /^(-?(?:\d+(?:\.\d+)?|\.\d+))px$/,
    Oe = /^-?\d+(\.\d+)?%$/,
    ke = {
        borderRadius: [0, 2048],
        borderWidth: [0, 32]
    };

function Ae(e, t = !1) {
    if (typeof e == "number") return Number.isFinite(e) && e >= (t ? -4096 : 0) && e <= 4096;
    if (typeof e != "string" || Oe.exec(e) ? .[0] !== e) return !1;
    let n = Number(e.slice(0, -1));
    return n >= (t ? -100 : 0) && n <= 100;
}

function je(e) {
    if (e === "none") return !0;
    let t = e.split(/\s+/);
    t[0] === "inset" && t.shift();
    let n = t.pop();
    return !n || !Ee.test(n) || t.length < 2 || t.length > 4 ? !1 : t.every((e, t) => {
        let n = De.exec(e),
            r = NaN;
        return e === "0" ? r = 0 : n && (r = Number(n[1])), Number.isFinite(r) && Math.abs(r) <= 256 && (t !== 2 || r >= 0);
    });
}

function Me(e) {
    if (typeof e != "object" || !e || Array.isArray(e)) return null;
    let t = Object.getPrototypeOf(e);
    if (t !== Object.prototype && t !== null) return null;
    let n = Reflect.ownKeys(e);
    if (n.length > 15) return null;
    let r = {};
    for (let t of n) {
        if (typeof t != "string") return null;
        let n = Object.getOwnPropertyDescriptor(e, t);
        if (!n || !("value" in n)) return null;
        let i = n.value;
        switch (t) {
            case "top":
            case "right":
            case "bottom":
            case "left":
                if (i !== "auto" && !Ae(i, !0)) return null;
                r[t] = i;
                break;
            case "width":
            case "height":
            case "minWidth":
            case "minHeight":
            case "maxWidth":
            case "maxHeight":
                if (!Ae(i)) return null;
                r[t] = i;
                break;
            case "borderRadius":
            case "borderWidth":
                {
                    let [e, n] = ke[t];
                    if (typeof i != "number" || !Number.isFinite(i) || i < e || i > n) return null;
                    r[t] = i;
                    break;
                }
            case "backgroundColor":
            case "borderColor":
                if (typeof i != "string" || i !== "transparent" && (i.length > 9 || Ee.exec(i) ? .[0] !== i)) return null;
                r[t] = i;
                break;
            case "boxShadow":
                if (typeof i != "string" || i.length > 256 || !je(i.trim())) return null;
                r.boxShadow = i.trim();
                break;
            default:
                return null;
        }
    }
    return r;
}
[
    ...[
        "image/png",
        "image/jpeg",
        "image/gif",
        "image/webp",
        "image/heic",
        "image/heif"
    ],
    ".heic",
    ".heif"
].join(",");
//#endregion
//#region ../../shared/utils/src/frame-instance.ts
var Ne = "ada-instance-id";

function Pe(e, t) {
    let n = new TextEncoder().encode(JSON.stringify([e, t])),
        r = 2166136261;
    for (let e of n) r = Math.imul(r ^ e, 16777619);
    return (r >>> 0).toString(16).padStart(8, "0");
}

function Fe(e, t) {
    let n = new URL(e.href);
    return t !== null && !n.searchParams.has("ada-instance-id") && n.searchParams.set(Ne, t), n;
}
//#endregion
//#region ../../shared/utils/src/host-theme.ts
var Ie = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

function Le(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    return Ie.test(t) ? t : null;
}
//#endregion
//#region ../../shared/utils/src/host-branding.ts
var Re = {
        aiAgentName: 100,
        aiAgentDescription: 300,
        "launcher.text": 40
    },
    ze = {
        min: 32,
        max: 120
    },
    Be = new Set([
        "aiAgentName",
        "aiAgentDescription",
        "avatarUrl",
        "tintColor",
        "headerColor",
        "headerTextColor",
        "cornerStyle",
        "textSize",
        "launcher"
    ]),
    Ve = new Set([
        "backgroundColor",
        "iconUrl",
        "size",
        "text"
    ]),
    He = /^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$/i;

function Ue(e) {
    for (let t of e) {
        let e = t.codePointAt(0) ? ? 0;
        if (e < 32 || e >= 127 && e <= 159) return !0;
    }
    return !1;
}

function We(e) {
    return typeof e == "object" && !!e && !Array.isArray(e);
}

function Ge(e, t) {
    if (typeof e != "string" || Ue(e)) return null;
    let n = e.trim();
    return !n || n.length > t ? null : n;
}

function Ke(e, t) {
    if (!We(e)) return null;
    let n = Object.entries(e);
    if (n.length === 0) return null;
    let r = {};
    for (let [e, i] of n) {
        let n = e.trim();
        if (!He.test(n)) return null;
        let a = Ge(i, t);
        if (a === null) return null;
        r[n.toLowerCase()] = a;
    }
    return r;
}

function qe(e) {
    if (typeof e != "string") return null;
    let t = e.trim();
    if (!t) return null;
    try {
        let e = new URL(t);
        return e.protocol !== "https:" || e.username || e.password ? null : e.toString();
    } catch {
        return null;
    }
}

function Je(e) {
    return typeof e != "number" || !Number.isInteger(e) || e < ze.min || e > ze.max ? null : e;
}

function Ye(e, t, n) {
    let r = {};
    for (let t of Object.keys(e)) Ve.has(t) || n.push(`launcher.${t}`);
    if (e.backgroundColor !== void 0) {
        let n = Le(e.backgroundColor);
        n ? r.backgroundColor = n : t.push("launcher.backgroundColor");
    }
    if (e.iconUrl !== void 0) {
        let n = qe(e.iconUrl);
        n ? r.iconUrl = n : t.push("launcher.iconUrl");
    }
    if (e.size !== void 0) {
        let n = Je(e.size);
        n === null ? t.push("launcher.size") : r.size = n;
    }
    if (e.text !== void 0) {
        let n = Ke(e.text, Re["launcher.text"]);
        n ? r.text = n : t.push("launcher.text");
    }
    return Object.keys(r).length > 0 ? r : void 0;
}

function Xe(e) {
    let t = [],
        n = [];
    if (!We(e)) return {
        branding: void 0,
        dropped: t,
        unknown: n
    };
    let r = {};
    for (let t of Object.keys(e)) Be.has(t) || n.push(t);
    if (e.aiAgentName !== void 0) {
        let n = Ke(e.aiAgentName, Re.aiAgentName);
        n ? r.aiAgentName = n : t.push("aiAgentName");
    }
    if (e.aiAgentDescription !== void 0) {
        let n = Ke(e.aiAgentDescription, Re.aiAgentDescription);
        n ? r.aiAgentDescription = n : t.push("aiAgentDescription");
    }
    if (e.avatarUrl !== void 0) {
        let n = qe(e.avatarUrl);
        n ? r.avatarUrl = n : t.push("avatarUrl");
    }
    if (e.tintColor !== void 0) {
        let n = Le(e.tintColor);
        n ? r.tintColor = n : t.push("tintColor");
    }
    if (e.headerColor !== void 0) {
        let n = Le(e.headerColor);
        n ? r.headerColor = n : t.push("headerColor");
    }
    if (e.headerTextColor !== void 0) {
        let n = Le(e.headerTextColor);
        n ? r.headerTextColor = n : t.push("headerTextColor");
    }
    if (e.cornerStyle !== void 0 && (e.cornerStyle === "round" || e.cornerStyle === "rectangular" ? r.cornerStyle = e.cornerStyle : t.push("cornerStyle")), e.textSize !== void 0 && (e.textSize === "small" || e.textSize === "default" || e.textSize === "large" ? r.textSize = e.textSize : t.push("textSize")), e.launcher !== void 0)
        if (We(e.launcher)) {
            let i = Ye(e.launcher, t, n);
            i && (r.launcher = i);
        } else t.push("launcher");
    return {
        branding: Object.keys(r).length > 0 ? r : void 0,
        dropped: t,
        unknown: n
    };
}
//#endregion
//#region ../../shared/utils/src/host-callback-error-redaction.ts
var Ze = "[redacted: host callback error]",
    Qe = "^[A-Za-z][A-Za-z0-9]{0,40}(?:Error|Exception)$",
    $e = "^(?:(?:ada[:.]|core\\.)[\\w:.-]{1,60}|LIVE_CHAT_(?:PLATFORM_[A-Z_]{1,40}|QUEUE_POSITION|SEND_TRANSCRIPT))$",
    et = "^[\\w:.-]{1,64}$",
    tt = 1024;

function nt(e) {
    let t = 14695981039346656037 n;
    for (let n = 0; n < e.length; n += 1) t = BigInt.asUintN(64, (t ^ BigInt(e.charCodeAt(n))) * 1099511628211 n);
    return `custom:${t.toString(16).padStart(16, "0")}`;
}

function rt(e) {
    return new RegExp(Qe).test(e) ? e : "Error";
}

function it(e, t) {
    return t === "eventCallbacks" ? e === "*" || new RegExp(et).test(e) ? e : e.length <= tt && e.trim() ? nt(e) : "unknown" : new RegExp($e).test(e) ? e : "unknown";
}
//#endregion
//#region ../../shared/utils/src/host-telemetry.ts
function at(e) {
    return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}

function ot(e) {
    if (typeof e == "string") switch (e.trim().toLowerCase()) {
        case "ios":
            return "ios";
        case "android":
            return "android";
        case "react-native":
        case "react_native":
        case "reactnative":
            return "react-native";
        case "web":
            return "web";
        case "unknown":
            return "unknown";
        default:
            return;
    }
}

function st(e) {
    if (typeof e == "string") switch (e.trim().toLowerCase()) {
        case "mobile":
            return "mobile";
        case "browser":
            return "browser";
        default:
            return;
    }
}

function ct(e) {
    if (typeof e == "string") switch (e.trim().toLowerCase()) {
        case "legacy":
            return "legacy";
        case "messaging":
            return "messaging";
        default:
            return;
    }
}
var lt = 100,
    ut = /^[a-z0-9_-]+$/;

function dt(e) {
    if (typeof e != "string") return;
    let t = e.trim().toLowerCase();
    if (!(!t || t.length > lt || !ut.test(t))) return t;
}

function ft(e) {
    if (typeof e == "string") switch (e.trim().toLowerCase()) {
        case "messaging_sdk":
        case "messaging-sdk":
            return "messaging-sdk";
        case "legacy_sdk":
        case "legacy-sdk":
            return "legacy-sdk";
        default:
            return;
    }
}
var pt = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

function mt(e) {
    if (typeof e != "string") return;
    let t = e.trim();
    if (!(t.length > lt || !pt.test(t))) return t;
}

function ht(e) {
    return e ? "messaging-sdk" : void 0;
}

function gt(e) {
    let t = at(e);
    if (!t) return;
    let n = st(t.surface),
        r = ot(t.hostPlatform),
        i = ct(t.webSdkOrigin),
        a = dt(t.mobilePackage),
        o = mt(t.mobileVersion);
    if (!n || !r || !i) return;
    let s = ht(a) ? ? ft(t.mobileShell);
    return {
        surface: n,
        hostPlatform: r,
        webSdkOrigin: i,
        ...s ? {
            mobileShell: s
        } : {},
        ...a ? {
            mobilePackage: a
        } : {},
        ...o ? {
            mobileVersion: o
        } : {},
        ...t.nativeViewVisibilitySupported === !0 ? {
            nativeViewVisibilitySupported: !0
        } : {}
    };
}

function _t(e, {
    defaultOrigin: t,
    defaultSurface: n,
    defaultPlatform: r
}) {
    let i = e,
        a = ct(i ? .webSdkOrigin) ? ? t,
        o = ot(i ? .hostPlatform) ? ? r ? ? (n === "browser" ? "web" : "unknown"),
        s = st(i ? .surface) ? ? (o === "web" ? "browser" : n),
        c = dt(i ? .mobilePackage),
        l = mt(i ? .mobileVersion),
        u = ht(c) ? ? ft(i ? .mobileShell);
    return {
        surface: s,
        hostPlatform: o,
        webSdkOrigin: a,
        ...u ? {
            mobileShell: u
        } : {},
        ...c ? {
            mobilePackage: c
        } : {},
        ...l ? {
            mobileVersion: l
        } : {},
        ...i ? .nativeViewVisibilitySupported === !0 ? {
            nativeViewVisibilitySupported: !0
        } : {}
    };
}
//#endregion
//#region \0@oxc-project+runtime@0.122.0/helpers/typeof.js
function vt(e) {
    "@babel/helpers - typeof";
    return vt = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e;
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
    }, vt(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.122.0/helpers/toPrimitive.js
function yt(e, t) {
    if (vt(e) != "object" || !e) return e;
    var n = e[Symbol.toPrimitive];
    if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (vt(r) != "object") return r;
        throw TypeError("@@toPrimitive must return a primitive value.");
    }
    return (t === "string" ? String : Number)(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.122.0/helpers/toPropertyKey.js
function bt(e) {
    var t = yt(e, "string");
    return vt(t) == "symbol" ? t : t + "";
}
//#endregion
//#region \0@oxc-project+runtime@0.122.0/helpers/defineProperty.js
function A(e, t, n) {
    return (t = bt(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}
//#endregion
//#region ../../shared/utils/src/proactive-schedule.ts
function xt(e, t) {
    let n = Date.now();
    return !(e && !(n >= new Date(e).getTime()) || t && !(n < new Date(t).getTime()));
}
//#endregion
//#region ../../shared/utils/src/runtime-assets.ts
var St = /^[0-9a-f]{40}$/i,
    Ct = /^pr-\d+$/;

function wt(e) {
    return e ? St.test(e) ? e.toLowerCase() : Ct.test(e) ? e : null : null;
}

function Tt(e) {
    return wt(e.split("/").filter(Boolean).at(-1));
}

function Et(e, t, n, r) {
    let i = wt(t);
    try {
        let r = new URL(e);
        if (r.protocol === "https:" || r.protocol === "http:") {
            let e = t ? `/${t}/` : "",
                a = e ? r.pathname.indexOf(e) : -1;
            if (a >= 0) return {
                assetsBase: `${r.origin}${r.pathname.slice(0, a + 1)}`,
                buildSha: i
            };
            let o = n.replace(/^\/+/, "");
            if (r.pathname.endsWith(`/${o}`)) {
                let e = r.pathname.slice(0, r.pathname.length - o.length);
                return {
                    assetsBase: `${r.origin}${e}`,
                    buildSha: i ? ? Tt(e)
                };
            }
            return {
                assetsBase: r.origin,
                buildSha: i
            };
        }
    } catch {}
    return {
        assetsBase: r,
        buildSha: i
    };
}
//#endregion
//#region ../../shared/utils/src/sdk-owned-meta-fields.ts
var Dt = [
        "initialURL",
        "introShown",
        "test_user"
    ],
    Ot = new Set(Dt);

function kt(e) {
    return Ot.has(e);
}

function At(e) {
    return e == null ? {} : Object.fromEntries(Object.entries(e).filter(([e]) => !kt(e)));
}
var jt = ["device_token", "device_os"];

function Mt(e, t) {
    let n = { ...e
    };
    if (Object.hasOwn(t, "device_token"))
        for (let e of jt) delete n[e], Object.hasOwn(t, e) && (n[e] = t[e]);
    return n;
}

function Nt(e, t) {
    let n = {};
    return e && (n.device_token = e, t && (n.device_os = t)), n;
}
var Pt = new Set([
    "REACTNATIVE",
    "REACT-NATIVE",
    "REACT_NATIVE"
]);

function Ft(e) {
    return Pt.has(e);
}

function It(e) {
    let t = e ? .sdkType;
    if (typeof t != "string") return "WEB";
    let n = t.trim().toUpperCase();
    return Ft(n) || n === "ANDROID" ? "ANDROID" : n === "IOS" ? "IOS" : n === "" || n === "WEB" ? "WEB" : void 0;
}
//#endregion
//#region ../../shared/utils/src/sdk-startup-timeout.ts
var Lt = 35e3,
    Rt = 15e3,
    zt = 1e3;

function Bt(e = {}) {
    let t = e.now ? ? (() => Date.now()),
        n = t(),
        r = n,
        i = () => {
            let e = t();
            return r += Math.max(0, e - n), n = e, r;
        },
        a = e.setTimeout ? ? ((e, t) => setTimeout(e, t)),
        o = e.clearTimeout ? ? ((e) => clearTimeout(e)),
        s = [],
        c = new AbortController(),
        l = /* @__PURE__ */ new Set(),
        u = !1,
        d = !1,
        f = !1,
        p = 0,
        m = "activation",
        h, g;

    function _() {
        let t = !d && (u || l.size > 0);
        t !== f && (f = t, f ? (p = i() + zt, v(), g = e.subscribeLifecycle ? .(y)) : (h !== void 0 && o(h), h = void 0, g ? .(), g = void 0));
    }

    function v() {
        f && (h !== void 0 && o(h), h = a(() => {
            h = void 0, y(), f && h === void 0 && v();
        }, Math.max(0, p - i())));
    }

    function y(t = "timer") {
        if (!f) return;
        let n = i();
        if (n < p) return;
        let r = n - p;
        if (p = n + zt, r >= 5e3) {
            let i = {
                gap: r,
                at: n,
                lastStep: m,
                source: t
            };
            s.push(i), e.onSuspension ? .(i);
        }
        v();
    }

    function b(e) {
        return y(), s.reduce((t, {
            at: n,
            gap: r
        }) => t + Math.max(0, n - Math.max(e, n - r)), 0);
    }

    function x(e) {
        return Math.max(0, i() - e - b(e));
    }
    return {
        start() {
            d || (u = !0, _());
        },
        stop() {
            y(), u = !1, _();
        },
        dispose() {
            d = !0, u = !1;
            for (let e of l) e();
            _(), c.abort();
        },
        now: i,
        sample: y,
        setLastStep(e) {
            d || (y(), m = e);
        },
        suspendedMsSince: b,
        activeElapsed: x,
        armActiveDeadline(e, t) {
            if (y(), d) throw Error("Cannot arm a deadline on a disposed startup clock");
            let n = i(),
                r, s = () => {
                    o(r), l.delete(s), _();
                },
                c = () => {
                    if (!l.has(s)) return;
                    let i = e - x(n);
                    if (l.has(s)) {
                        if (i > 0) {
                            r = a(c, i);
                            return;
                        }
                        l.delete(s), _(), t();
                    }
                };
            return l.add(s), _(), r = a(c, e), s;
        },
        signal: c.signal,
        get lastSuspension() {
            return s.at(-1) ? ? null;
        }
    };
}
//#endregion
//#region ../../shared/utils/src/startup-page-lifecycle.ts
function Vt(e, t) {
    return (n) => {
        let r = () => n("visibility"),
            i = () => n("pageshow");
        return e.addEventListener("visibilitychange", r), t.addEventListener("pageshow", i), () => {
            e.removeEventListener("visibilitychange", r), t.removeEventListener("pageshow", i);
        };
    };
}
//#endregion
//#region ../../shared/utils/src/zendesk-chat-auth.ts
var Ht = 1e4;
Ht + 5e3;
//#endregion
//#region ../../shared/utils/src/zendesk-tab-coordinator.ts
var Ut = "zendesk_delivery_unknown",
    Wt = "ada_host_telemetry",
    Gt = "hostTelemetry",
    Kt = Symbol.for("ada.sdk.internal.hostTelemetry");

function qt(e) {
    return gt(e);
}

function Jt(e, t) {
    return t && Object.defineProperty(e, Kt, {
        value: t,
        enumerable: !1,
        configurable: !0
    }), e;
}

function Yt(e) {
    if (!(typeof e != "object" || !e || Array.isArray(e))) return qt(e[Kt]);
}

function Xt(e) {
    let t = e;
    if (!ve(t, Gt)) return e;
    let {
        [Gt]: n, ...r
    } = t;
    return r;
}

function Zt(e, {
    defaultOrigin: t,
    defaultSurface: n,
    defaultPlatform: r
}) {
    return _t(qt(e.hostTelemetry), {
        defaultOrigin: t,
        defaultSurface: n,
        defaultPlatform: r
    });
}
//#endregion
//#region src/logger.ts
var Qt = "[Ada]",
    $t = "ada.debug";

function en() {
    try {
        if (window.adaSettings ? .debug === !0) return !0;
    } catch {}
    try {
        return window.localStorage.getItem($t) === "1";
    } catch {
        return !1;
    }
}

function tn(e, t = en) {
    return e === "prod" ? t() : !0;
}

function nn(e, t) {
    try {
        console[e](Qt, ...t);
    } catch {}
}
var j = {
        debug: (...e) => {
            tn("prod") && nn("debug", e);
        },
        warn: (...e) => {
            tn("prod") && nn("warn", e);
        },
        dataLoss: (...e) => {
            nn("warn", e);
        },
        error: (...e) => {
            nn("error", e);
        }
    },
    rn = new Set([
        "network",
        "audio-capture",
        "not-allowed",
        "service-not-allowed"
    ]),
    an = class e {
        constructor(e) {
            A(this, "recognition", null), A(this, "audioContext", null), A(this, "analyser", null), A(this, "audioSource", null), A(this, "mediaStream", null), A(this, "audioLevelRafId", null), A(this, "_hadFatalError", !1), A(this, "config", void 0), this.config = e;
        }
        static isSupported() {
            return typeof window < "u" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window);
        }
        async startRecording() {
            if (this._hadFatalError = !1, !e.isSupported()) return this.config.callbacks.onError("Speech recognition not supported in this browser"), !1;
            try {
                if (navigator.permissions && (await navigator.permissions.query({
                        name: "microphone"
                    })).state === "denied") throw Error("Microphone access denied. Please allow access in browser settings.");
                return this.mediaStream = await navigator.mediaDevices.getUserMedia({
                    audio: !0
                }), this.recognition = new(window.SpeechRecognition || window.webkitSpeechRecognition)(), this.recognition.continuous = !0, this.recognition.interimResults = !0, this.recognition.lang = this.config.language, this.recognition.onresult = (e) => {
                    let t = "",
                        n = "";
                    for (let r = e.resultIndex; r < e.results.length; r++) {
                        let i = e.results[r];
                        i.isFinal ? n += i[0].transcript : t += i[0].transcript;
                    }
                    n ? this.config.callbacks.onTranscriptUpdate(n, !0) : t && this.config.callbacks.onTranscriptUpdate(t, !1);
                }, this.recognition.onerror = (e) => {
                    rn.has(e.error) && (this._hadFatalError = !0);
                    let t = "Speech recognition error";
                    switch (e.error) {
                        case "no-speech":
                            t = "No speech detected";
                            break;
                        case "audio-capture":
                            t = "Microphone access denied";
                            break;
                        case "not-allowed":
                            t = "Microphone access denied. Please allow access in browser settings.";
                            break;
                        case "network":
                            t = "Network error during speech recognition";
                            break;
                        default:
                            t = `Speech recognition error: ${e.error}`;
                    }
                    this.config.callbacks.onError(t);
                }, this.recognition.onend = () => {
                    if (this.recognition && this.mediaStream && !this._hadFatalError) try {
                        this.recognition.start();
                    } catch {}
                }, this.startAudioLevelMonitoring(), this.recognition.start(), !0;
            } catch (e) {
                if (this.mediaStream) {
                    for (let e of this.mediaStream.getTracks()) e.stop();
                    this.mediaStream = null;
                }
                if (this.recognition) {
                    try {
                        this.recognition.stop();
                    } catch {}
                    this.recognition = null;
                }
                let t = e instanceof Error ? e.message : "Unknown error";
                return this.config.callbacks.onError(`Failed to start recording: ${t}`), !1;
            }
        }
        stopRecording() {
            this.recognition && = (this.recognition.stop(), null), this.stopAudioLevelMonitoring(), this.mediaStream && = (this.mediaStream.getTracks().forEach((e) => {
                e.stop();
            }), null), this.audioContext && = (this.audioContext.close(), null);
        }
        setLanguage(e) {
            this.config.language = e, this.recognition && (this.recognition.lang = e);
        }
        setMode(e) {
            this.config.mode = e;
        }
        startAudioLevelMonitoring() {
            if (this.mediaStream) try {
                this.audioContext = new AudioContext(), this.analyser = this.audioContext.createAnalyser(), this.analyser.fftSize = 256, this.audioSource = this.audioContext.createMediaStreamSource(this.mediaStream), this.audioSource.connect(this.analyser);
                let e = this.analyser.frequencyBinCount,
                    t = new Uint8Array(e),
                    n = () => {
                        if (this.analyser) {
                            if (!document.hidden) {
                                this.analyser.getByteFrequencyData(t);
                                let n = t.reduce((e, t) => e + t, 0) / e / 255;
                                this.config.callbacks.onAudioLevel(n);
                            }
                            this.audioLevelRafId = requestAnimationFrame(n);
                        }
                    };
                this.audioLevelRafId = requestAnimationFrame(n);
            } catch (e) {
                j.warn("Failed to start audio level monitoring:", e);
            }
        }
        stopAudioLevelMonitoring() {
            this.audioLevelRafId !== null && (cancelAnimationFrame(this.audioLevelRafId), this.audioLevelRafId = null), this.audioSource ? .disconnect(), this.audioSource = null, this.analyser = null;
        }
        destroy() {
            this.stopRecording();
        }
    };

function on(e, t) {
    if (!("speechSynthesis" in window)) {
        j.warn("Text-to-speech not supported in this browser");
        return;
    }
    window.speechSynthesis.cancel();
    let n = new DOMParser().parseFromString(e, "text/html").body.textContent ? ? e;
    if (!n.trim()) return;
    let r = new SpeechSynthesisUtterance(n);
    r.lang = t, window.speechSynthesis.speak(r);
}
//#endregion
//#region src/client/config-helpers.ts
var sn = "localhost",
    cn = new Set(Array.from(a).filter((e) => e !== sn)),
    ln = /^[a-z0-9](?:[a-z0-9-]{0,62})$/i,
    un = "https://messaging-demo.net:5040/api",
    dn = 5040,
    fn = 8e3;

function pn(e, t = window.location.hostname) {
    try {
        let t = new URL(e, window.location.href);
        if (C(t.hostname)) return new URL("/api", `${t.protocol}//${t.host.replace(/:\d+$/, `:${dn}`)}`).toString().replace(/\/$/, "");
        if (t.hostname === "messaging-assets.net") return un;
    } catch {}
    return t.endsWith(".localhost") ? `http://${t}:${fn}` : un;
}

function mn(e) {
    return typeof e == "string" && e.trim() || void 0;
}
var hn = !1;

function gn(e) {
    if (typeof e == "boolean") return e;
    if (typeof e == "object" && e && !Array.isArray(e) && "enabled" in e && typeof e.enabled == "boolean") return e.enabled;
    e !== void 0 && !hn && (hn = !0, j.dataLoss("crossWindowPersistence must be a boolean or { enabled: boolean }; other forms are ignored and the value already in effect, or the default (on), stays."));
}

function _n(e) {
    if (e == null) return;
    let t = w(e);
    return t === void 0 && j.dataLoss("appUrl must be an absolute https: URL (http: is allowed only on loopback hosts for local development); ignoring it and using Ada's default app."), t;
}

function vn(e) {
    if (!(!e || !se(e))) return oe;
}

function yn(e) {
    let t = e.trim();
    if (!t) throw Error("AdaMessagingClient: endpoint override must not be empty.");
    let n = re(t, window.location.origin);
    if (n === null) throw Error(`AdaMessagingClient: invalid endpoint override "${e}".`);
    return n;
}

function bn(e) {
    let t = x(e);
    if (t.endsWith("/api") || t === "/api") return b(e);
    try {
        if (new URL(t).hostname.endsWith(".localhost")) return b(e);
    } catch {}
    try {
        return new URL("api/", b(e)).toString();
    } catch {
        return `${t}/api/`;
    }
}

function xn(e) {
    return typeof e == "string" && e.trim().toLowerCase() || null;
}

function Sn(e, t) {
    let n = e.trim().toLowerCase();
    if (!n) throw Error(`AdaMessagingClient: ${t} cannot be empty.`);
    if (!a.has(n)) {
        let n = Array.from(a).sort().join(", ");
        throw Error(`AdaMessagingClient: unsupported ${t} "${e}". Supported values: ${n}.`);
    }
    return n;
}

function Cn(e, t) {
    return e ? e === "localhost" || e.includes(".") ? e : `${e}.${t ?? "ada"}.support` : t ? `${t}.support` : null;
}

function wn(e, t, n) {
    if (typeof e != "string") throw Error("AdaMessagingClient: handle must be a string.");
    let r = e.trim().toLowerCase();
    if (!r) throw Error("AdaMessagingClient: handle is required.");
    let i = r,
        a = null;
    if (r.includes(".")) {
        let t = r.split(".");
        if (t.some((e) => e.length === 0)) throw Error(`AdaMessagingClient: invalid handle "${e}". Domain labels must be non-empty.`);
        i = t[0], a = t.slice(1).join(".");
    }
    if (!ln.test(i)) throw Error(`AdaMessagingClient: invalid handle "${i}". Expected 1-63 alphanumeric characters or hyphens.`);
    let o = xn(t),
        s = xn(n);
    if (o && a && Cn(o, s) !== Cn(a, s)) throw Error(`AdaMessagingClient: handle "${e}" implies cluster "${a}", which conflicts with supplied cluster "${t}".`);
    let c = Cn(a ? ? o, s),
        l = c ? Sn(c, "cluster") : null;
    return {
        handle: i,
        cluster: l
    };
}

function Tn(e) {
    let t;
    try {
        t = new URL(e, window.location.href).hostname.toLowerCase();
    } catch {
        return null;
    }
    let n = t.split(".");
    if (n.length < 2) return null;
    for (let e = 0; e < n.length - 1; e++) {
        let t = n.slice(e).join(".");
        if (cn.has(t)) return t;
    }
    return null;
}

function En(e, t, n) {
    let r = xn(n);
    if (r) {
        let n = Sn(r, "cluster");
        return n === "localhost" ? pn(t) : `https://${e}.${n}`;
    }
    let i = Tn(t);
    return i ? `https://${e}.${i}` : `https://${e}.ada.support`;
}
var Dn = 256,
    On = 1e5,
    kn = /* @__PURE__ */ new WeakMap();

function An(...e) {
    return e.flatMap((e) => {
        let t = e && kn.get(e);
        return t ? [{ ...t
        }] : [];
    });
}

function jn(e, t) {
    let n = e && kn.get(e);
    return n && kn.set(t, n), t;
}

function M(e) {
    return jn(e, At(e));
}
var Mn = new Set([
    "__proto__",
    "constructor",
    "prototype"
]);

function Nn(e) {
    return Mn.has(e);
}

function N(e, t = {}) {
    let n = [],
        r = new Set([...Dt, ...t.sensitive ? jt : []]),
        i = 0,
        a = {
            emptyKeys: 0,
            reservedKeys: 0,
            oversizedKeys: 0,
            truncatedValues: 0,
            unsupportedValues: 0
        },
        o = Object.entries(e);
    for (let [e, t] of o) {
        if (!e) {
            a.emptyKeys++;
            continue;
        }
        if (Nn(e)) {
            a.reservedKeys++;
            continue;
        }
        if (e.length > Dn) {
            a.oversizedKeys++;
            continue;
        }
        if (typeof t == "string" || typeof t == "number" || typeof t == "boolean" || t === null) {
            let o = typeof t == "string" && t.length > On ? t.slice(0, On) : t;
            typeof t == "string" && t.length > On && (a.truncatedValues++, r.has(e) || i++), n.push([e, o]);
        } else a.unsupportedValues++;
    }
    let s = t.sensitive ? "sensitive meta fields" : "meta fields",
        c = [
            a.emptyKeys > 0 ? `${s} with empty keys dropped: ${a.emptyKeys}` : null,
            a.reservedKeys > 0 ? `${s} with reserved keys dropped: ${a.reservedKeys}` : null,
            a.oversizedKeys > 0 ? `${s} with keys over ${Dn} chars dropped: ${a.oversizedKeys}` : null,
            a.truncatedValues > 0 ? `${s} with values truncated to ${On} chars: ${a.truncatedValues}` : null,
            a.unsupportedValues > 0 ? `${s} with unsupported value types dropped: ${a.unsupportedValues}` : null
        ].filter((e) => e !== null);
    c.length > 0 && j.dataLoss(c.join("; "));
    let l = Object.fromEntries(n),
        u = kn.get(e),
        d = o.filter(([e]) => !r.has(e)).length,
        f = n.filter(([e]) => !r.has(e)).length;
    return kn.set(l, {
        received: u ? .received ? ? d,
        kept: f,
        dropped: (u ? .dropped ? ? 0) + d - f,
        truncatedValues: (u ? .truncatedValues ? ? 0) + i,
        sensitive: t.sensitive === !0
    }), l;
}

function Pn(e, t, n, r) {
    let i = new URL(En(t, n, r)).hostname.split(".").slice(1).join(".").toLowerCase();
    return e.protocol === "https:" && r !== "localhost" && (e.pathname === "/chat/" || e.pathname === "/chat") && e.port === "" && e.hostname.toLowerCase().endsWith(`.${i}`);
}
var Fn = Symbol.for("ada.sdk.internal.standaloneChatPage"),
    In = Symbol.for("ada.sdk.internal.chatHtmlPage");

function Ln(e) {
    return Object.defineProperty(e, Fn, {
        value: !0,
        enumerable: !0,
        configurable: !0
    }), e;
}

function Rn(e) {
    return typeof e == "object" && !!e && e[Fn] === !0;
}

function zn(e) {
    return typeof e == "object" && !!e && e[In] === !0;
}

function Bn(e, t) {
    if (!e || e === "null") return !1;
    try {
        return new URL(t).origin === e;
    } catch {
        return !1;
    }
}

function Vn(e) {
    let t = typeof e == "string" || e instanceof URLSearchParams ? e : e.search,
        n = typeof e == "string" || e instanceof URLSearchParams ? "" : e.hash,
        r = typeof t == "string" ? new URLSearchParams(t) : t,
        i = (r.get("ada_handle") ? ? "").trim();
    if (!i) return null;
    let a = [];
    for (let [e, t] of r) {
        let n = e.slice(3);
        e.startsWith("mf_") && n && !Nn(n) && a.push([n, t]);
    }
    let o = {
            handle: i,
            metaFields: N(Object.fromEntries(a))
        },
        s = (r.get("ada_cluster") ? ? "").trim();
    s && (o.cluster = s);
    let c = (r.get("language") ? ? "").trim();
    c && (o.language = c);
    let l = (r.get("greeting") ? ? "").trim();
    l && (o.greeting = l);
    let u = (r.get("ada_test_mode") ? ? "").trim();
    return (u === "1" || u === "true") && (o.testMode = !0), Yn({
        search: r.toString(),
        hash: n
    }) && (o.privateMode = !0), Object.defineProperty(o, In, {
        value: !0,
        enumerable: !0
    }), Ln(o);
}

function Hn(e) {
    j.dataLoss(`${e} is not supported and was ignored. Set branding.tintColor to change the chat accent colour.`);
}
var Un = /* @__PURE__ */ new Set();

function Wn(e) {
    Un.has(e) || (Un.add(e), j.dataLoss(`${e} is not supported by Messaging and was ignored.`));
}

function Gn(e) {
    if (e === void 0) return;
    let {
        branding: t,
        dropped: n,
        unknown: r
    } = Xe(e);
    return n.length > 0 && j.dataLoss(`adaSettings.branding (${n.join(", ")}) failed validation and was ignored. Colours are 3- or 6-digit hex, URLs are absolute https, text fields are a map of language code to string within the length limit, and launcher.size is an integer from 32 to 120.`), r.length > 0 && j.dataLoss(`adaSettings.branding (${r.join(", ")}) is not a recognised key and was ignored.`), t;
}

function Kn(e, t) {
    if (e.integration === "liveAgent" && e.action === "handoff.request") {
        let n = typeof e.payload ? .platformData == "object" && e.payload.platformData !== null ? e.payload.platformData : null;
        return (typeof n ? .platform == "string" ? n.platform : null) ? ? t;
    }
    return e.integration === "zendesk" && e.action === "handoff.initialize" ? "zendesk_liveagent" : e.integration === "fileUpload" ? (typeof e.payload ? .platform == "string" ? e.payload.platform : null) ? ? t : t;
}

function qn(e, t) {
    return e === "csat" ? xe(t) : t;
}

function Jn(e, t) {
    let n = Kn(e, t);
    if (e.integration === "zendesk") return {
        frameId: "zendesk",
        nextActivePlatform: n
    };
    if (e.integration === "zendeskMessaging") return {
        frameId: "zendeskMessaging",
        nextActivePlatform: n
    };
    if (e.integration === "oauth") return {
        frameId: "oauth",
        nextActivePlatform: n
    };
    if (e.integration === "csat") return {
        frameId: "csat",
        nextActivePlatform: n
    };
    let r = n;
    return r ? r === "zendesk_liveagent" || r === "zendesk_support_liveagent" || r === "salesforce_liveagent" || r.startsWith("handoff_integration_") ? {
        frameId: "zendesk",
        nextActivePlatform: n
    } : r === "zaw_liveagent" ? {
        frameId: "zendeskMessaging",
        nextActivePlatform: n
    } : {
        frameId: null,
        nextActivePlatform: n
    } : {
        frameId: null,
        nextActivePlatform: n
    };
}

function Yn(e) {
    try {
        let t = new URLSearchParams(e.search);
        if (t.get("private") === "true" || t.get("private") === "1" || e.hash === "#private") return !0;
    } catch {}
    return !1;
}
//#endregion
//#region src/client/ada-settings-reader.ts
var Xn = Symbol("ada.messaging.skipWindowSettings");

function Zn() {
    if (typeof window > "u") return {};
    let e = window.adaSettings;
    if (typeof e != "object" || !e || Array.isArray(e)) return {};
    let t = e,
        n = {};
    typeof t.deviceToken == "string" && (n.deviceToken = t.deviceToken), typeof t.handle == "string" && (n.handle = t.handle), typeof t.cluster == "string" && (n.cluster = t.cluster), typeof t.language == "string" && (n.language = t.language), typeof t.greeting == "string" && (n.greeting = t.greeting);
    let r = mn(t.identityToken);
    r && (n.identityToken = r), typeof t.endpoint == "string" && t.endpoint.trim() !== "" && (n.endpoint = t.endpoint.trim()), typeof t.domain == "string" && t.domain.trim() !== "" && (n.domain = t.domain.trim()), typeof t.lazy == "boolean" && (n.lazy = t.lazy), typeof t.privateMode == "boolean" && (n.privateMode = t.privateMode), typeof t.testMode == "boolean" && (n.testMode = t.testMode), typeof t.skipGreeting == "boolean" ? n.skipGreeting = t.skipGreeting : t.skipGreeting !== void 0 && j.dataLoss("adaSettings.skipGreeting must be a boolean; other forms are ignored."), typeof t.hideMask == "boolean" && (n.hideMask = t.hideMask), typeof t.headless == "boolean" && (n.headless = t.headless), typeof t.showFallbackOnTimeout == "boolean" && (n.showFallbackOnTimeout = t.showFallbackOnTimeout);
    let i = gn(t.crossWindowPersistence);
    if (i !== void 0 && (n.crossWindowPersistence = i), typeof t.allowMetaFieldsInReset == "boolean" ? n.allowMetaFieldsInReset = t.allowMetaFieldsInReset : t.allowMetaFieldsInReset !== void 0 && j.dataLoss("adaSettings.allowMetaFieldsInReset must be a boolean; other forms are ignored and reset() will continue to apply caller meta fields."), typeof t.enableProgrammaticControl == "boolean" && (n.enableProgrammaticControl = t.enableProgrammaticControl), t.metaFields !== null && typeof t.metaFields == "object" && !Array.isArray(t.metaFields) && (n.metaFields = N(t.metaFields)), t.sensitiveMetaFields !== null && typeof t.sensitiveMetaFields == "object" && !Array.isArray(t.sensitiveMetaFields) && (n.sensitiveMetaFields = N(t.sensitiveMetaFields, {
            sensitive: !0
        })), (typeof t.parentElement == "string" || typeof window < "u" && t.parentElement instanceof HTMLElement) && (n.parentElement = t.parentElement), (t.align === "right" || t.align === "left" || t.align === "auto") && (n.align = t.align), typeof t.rolloutOverride == "number" && Number.isFinite(t.rolloutOverride)) {
        let e = t.rolloutOverride;
        n.rolloutOverride = e > 1 ? e / 100 : e;
    }
    "styles" in t && Hn("adaSettings.styles"), "embedStyles" in t && Hn("adaSettings.embedStyles"), typeof t.branding == "object" && t.branding !== null && !Array.isArray(t.branding) ? n.branding = t.branding : "branding" in t && j.dataLoss("adaSettings.branding must be an object of overrides (e.g. { aiAgentName: { en: 'Acme Assistant' } }); other forms are ignored.");
    let a = Qn(t.eventCallbacks);
    return a && (n.eventCallbacks = a), n;
}

function Qn(e) {
    if (typeof e != "object" || !e || Array.isArray(e)) return;
    let t = {};
    for (let [n, r] of Object.entries(e)) typeof r == "function" && (t[n] = r);
    return Object.keys(t).length > 0 ? t : void 0;
}
//#endregion
//#region src/helpers/rollout.ts
var $n = "ada-rollout-";

function er(e) {
    let t = e.lastIndexOf(":");
    if (t <= 0) return null;
    let n = e.slice(0, t),
        r = Number.parseFloat(e.slice(t + 1));
    return !Number.isFinite(r) || r <= 0 || r >= 1 ? null : n === "show" ? Math.random() * r : n === "hide" ? r + Math.random() * (1 - r) : null;
}

function tr(e) {
    let t = typeof e == "string" ? e.trim() : "";
    if (!t) return null;
    let n = Number(t);
    return Number.isFinite(n) && n >= 0 && n < 1 ? n : er(t);
}

function nr(e, t) {
    if (t == null || !Number.isFinite(t) || t >= 1) return !0;
    if (t <= 0) return !1;
    let n = `${$n}${e}`;
    try {
        let e = localStorage.getItem(n),
            r = tr(e) ? ? Math.random(),
            i = String(r);
        return e !== i && localStorage.setItem(n, i), r < t;
    } catch {
        return !0;
    }
}
//#endregion
//#region src/client/frame-visibility.ts
var rr = /(?:^|;)\s*display\s*:/,
    ir = /(?:^|;)\s*(?:(?:width|height)\s*:\s*0(?:px)?|opacity\s*:\s*0|visibility\s*:\s*hidden)\s*(?:;|$)/;

function ar(e) {
    return ir.test(e);
}

function or(e) {
    let t = Number.parseFloat(e ? .style.width ? ? ""),
        n = Number.parseFloat(e ? .style.height ? ? "");
    return t > 0 && n > 0;
}

function sr() {
    return typeof HTMLElement < "u" && "inert" in HTMLElement.prototype;
}

function cr(e, t) {
    if (!e) return;
    let n = !sr();
    if (t) {
        e.setAttribute("aria-hidden", "true"), e.setAttribute("inert", ""), n && (e.style.visibility = "hidden");
        return;
    }
    e.removeAttribute("aria-hidden"), e.removeAttribute("inert"), n && e.style.visibility === "hidden" && (e.style.visibility = "");
}

function lr(e, t) {
    for (let t of Array.from(e.style)) e.style.removeProperty(t);
    for (let n of t.split(";")) {
        let t = n.indexOf(":");
        if (t < 0) continue;
        let r = n.slice(0, t).trim();
        if (!r) continue;
        let i = n.slice(t + 1).trim(),
            a = /!important$/i.test(i);
        e.style.setProperty(r, a ? i.replace(/!important$/i, "").trim() : i, a ? "important" : "");
    }
}

function P(e, t) {
    if (!e) return;
    let n = e.style.getPropertyValue("display"),
        r = e.style.getPropertyPriority("display");
    lr(e, t), n && !rr.test(t) && e.style.setProperty("display", n, r), cr(e, ar(t));
}
//#endregion
//#region src/client/host-callback-error.ts
var ur = "sdk.hostCallback.error",
    dr = 3,
    fr = 20,
    pr = 40,
    mr = null,
    hr = /* @__PURE__ */ new Map(),
    gr = 0,
    _r = Symbol.for("ada.messaging.hostCallbackRejection"),
    vr = Object.getPrototypeOf((async () => void 0)()).then;

function yr(e) {
    return Object.getOwnPropertyDescriptor(e, _r) ? .value === !0;
}

function br(e) {
    mr = e;
}

function xr(e) {
    mr === e && (mr = null);
}

function Sr(e) {
    if (typeof e != "object" || !e) return "Error";
    try {
        if (!(e instanceof Error)) {
            let t = Object.prototype.toString.call(e);
            if (t !== "[object Error]" && t !== "[object DOMException]") return "Error";
        }
        let t = e.name;
        return typeof t == "string" ? rt(t) : "Error";
    } catch {
        return "Error";
    }
}

function Cr(e) {
    return {
        errorName: Sr(e),
        errorMessage: Ze
    };
}

function F(e, t, n) {
    try {
        if (!mr) return;
        let r = e === "eventCallbacks" ? it(t, e) : t,
            i = `${e}|${r}`,
            a = hr.get(i) ? ? 0;
        if (a >= dr) return;
        if (a === 0) {
            if (hr.size >= pr) return;
        } else if (gr >= fr) return;
        hr.set(i, a + 1), a > 0 && (gr += 1);
        let o = {
            callbackName: e,
            eventName: r,
            ...Cr(n)
        };
        mr(ur, o);
    } catch {}
}

function I(e, t, n, r, i) {
    if (e === null || typeof e != "object" && typeof e != "function") return;
    let a = (a, o) => {
        j.error(`${r} rejected:`, a), F(t, n, a);
        try {
            i ? .(a);
        } catch {}
        o && wr(e, a);
    };
    try {
        vr.call(e, void 0, (e) => {
            a(e, !0);
        });
        return;
    } catch {}
    try {
        let t = e,
            n = t.then;
        typeof n == "function" && n.call(t, void 0, (e) => a(e, !1));
    } catch {}
}

function wr(e, t) {
    try {
        if (typeof PromiseRejectionEvent != "function") return;
        let n = new PromiseRejectionEvent("unhandledrejection", {
            promise: e,
            reason: t,
            cancelable: !0
        });
        Object.defineProperty(n, _r, {
            value: !0
        }), window.dispatchEvent(n);
    } catch {}
}
//#endregion
//#region src/client/frame-styles.ts
var L = "position:absolute;width:0;height:0;border:0;overflow:hidden;visibility:hidden;",
    Tr = 356,
    R = 0;

function Er(e) {
    let t = e.compatMode === "BackCompat" ? e.body : e.documentElement;
    return {
        width: t.clientWidth,
        height: t.clientHeight
    };
}

function Dr(e, t, n, r) {
    let i = e ? .ownerDocument.defaultView,
        a = e && i ? .getComputedStyle(e),
        o = kr(e);
    if (a ? .display === "none") return {
        height: o,
        bottom: R,
        side: R
    };
    let s = (e) => {
            let t = Number.parseFloat(e ? ? "");
            return e ? .endsWith("px") && Number.isFinite(t) && t > R ? t : R;
        },
        c = s(a ? .bottom),
        l = s(t === "left" ? a ? .left : a ? .right),
        u = Or({
            height: o,
            bottom: c,
            side: l
        });
    return {
        height: o,
        bottom: u.bottom + n <= r.height ? c : R,
        side: u.side + Tr <= r.width ? l : R
    };
}

function Or(e) {
    return {
        bottom: e.bottom + e.height - 24 + 8 - 52,
        side: e.side + 24 - 24
    };
}

function kr(e) {
    let t = Number.parseFloat(e ? .style.height ? ? "");
    return Number.isFinite(t) && t > 0 ? t : 112;
}
var z = "--ada-messaging-viewport-height",
    Ar = 100,
    jr = `${L}opacity:0;transform:translateY(${Ar}px);`,
    B = {
        scrim: 9998,
        proactive: 9999,
        launcher: 1e4,
        chat: 10010,
        chatMobile: 10010,
        hostViewport: 10020
    };

function V() {
    return typeof navigator > "u" ? !1 : /(iPhone)|(iPod)|(android)|(webOS)/i.test(navigator.userAgent);
}

function Mr() {
    return typeof navigator > "u" ? !1 : /(iPad)|(iPhone)|(iPod)|(android)|(webOS)/i.test(navigator.userAgent);
}

function Nr() {
    return typeof window > "u" || !window.matchMedia ? !1 : window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function Pr() {
    let e = window.visualViewport ? .height;
    return typeof e == "number" && Number.isFinite(e) && e > 0 ? `${Math.round(e)}px` : typeof window.innerHeight == "number" && Number.isFinite(window.innerHeight) && window.innerHeight > 0 ? `${Math.round(window.innerHeight)}px` : "100vh";
}

function Fr(e) {
    let t = () => {
        e.style.setProperty(z, Pr());
    };
    t();
    let n = window.visualViewport;
    return n ? .addEventListener("resize", t), n ? .addEventListener("scroll", t), window.addEventListener("resize", t), window.addEventListener("orientationchange", t), () => {
        n ? .removeEventListener("resize", t), n ? .removeEventListener("scroll", t), window.removeEventListener("resize", t), window.removeEventListener("orientationchange", t);
    };
}

function Ir(e, t, n) {
    let r = e === "left" ? "left" : "right";
    return [
        `position:${n ? "absolute" : "fixed"}`,
        `bottom:${R}px`,
        `${r}:${R}px`,
        "width:0",
        "height:0",
        "border:0",
        `z-index:${B.launcher}`,
        "background:transparent",
        "overflow:hidden",
        "clip-path:inset(16px)",
        "opacity:0",
        "transition:opacity 200ms ease"
    ].join(";");
}

function Lr(e, t, n = !1, r = !1, i = {}) {
    if (t) return [
        "position:absolute",
        "inset:0",
        "width:100%",
        "height:100%",
        "border:0",
        `z-index:${B.chat}`,
        "overflow:hidden"
    ].join(";");
    let a = r ? [
        "opacity:1",
        "transform:none",
        "visibility:visible",
        "transition:transform 300ms ease,opacity 300ms ease"
    ] : [];
    if (n) return [
        "position:fixed",
        "top:0",
        "left:0",
        "width:100%",
        `height:var(${z}, 100%)`,
        "border:0",
        "background-color:#fff",
        `z-index:${B.chatMobile}`,
        "overflow:hidden",
        ...a
    ].join(";");
    let o = [
            "top",
            "right",
            "bottom",
            "left"
        ],
        s = (e) => typeof e == "number" ? `${e}px` : e,
        c = [
            "width",
            "height",
            "maxWidth",
            "maxHeight"
        ].some((e) => i[e] !== void 0),
        l = c || [
            ...o,
            "minWidth",
            "minHeight"
        ].some((e) => i[e] !== void 0),
        u = l ? "375px" : "100%",
        d = l ? "720px" : `calc(var(${z}, 100vh) - 48px)`,
        f = "min(375px, calc(100vw - 48px))",
        p = "720px";
    l && (f = c ? "100%" : "calc(100vw - 48px)", p = c ? `var(${z}, 100vh)` : `calc(var(${z}, 100vh) - 48px)`);
    let m = [
        "width",
        "height",
        "minWidth",
        "minHeight",
        "maxWidth",
        "maxHeight",
        "borderWidth",
        "borderRadius",
        "borderColor"
    ].some((e) => i[e] !== void 0);
    return [
        "position:fixed",
        ...o.flatMap((t) => {
            let n = i[t] ? ? (t === "bottom" || t === e ? 24 : void 0);
            return n === void 0 ? [] : [`${t}:${s(n)}`];
        }),
        ...o.every((e) => i[e] !== void 0) ? ["margin:auto"] : [],
        `width:${i.width === void 0 ? u : s(i.width)}`,
        `max-width:${i.maxWidth === void 0 ? f : s(i.maxWidth)}`,
        `height:${i.height === void 0 ? d : s(i.height)}`,
        `max-height:${i.maxHeight === void 0 ? p : s(i.maxHeight)}`,
        ...i.minWidth === void 0 ? [] : [`min-width:${s(i.minWidth)}`],
        ...i.minHeight === void 0 ? [] : [`min-height:${s(i.minHeight)}`],
        ...m ? ["box-sizing:border-box"] : [],
        "border:0",
        `border-radius:${i.borderRadius ?? 16}px`,
        `box-shadow:${i.boxShadow ?? "0 8px 32px rgba(0,0,0,0.18)"}`,
        ...i.backgroundColor === void 0 ? [] : [`background-color:${i.backgroundColor}`, "color-scheme:light"],
        ...i.borderWidth === void 0 ? [] : [
            `border-width:${i.borderWidth}px`,
            "border-style:solid",
            `border-color:${i.borderColor ?? "transparent"}`
        ],
        `z-index:${B.chat}`,
        "overflow:hidden",
        ...a
    ].join(";");
}

function Rr() {
    return [
        "position:fixed",
        "top:0",
        "left:0",
        "width:100%",
        `height:var(${z}, 100%)`,
        "max-width:none",
        "max-height:none",
        "border:0",
        "border-radius:0",
        "box-shadow:none",
        `z-index:${B.hostViewport}`,
        "overflow:hidden",
        "opacity:1",
        "transform:none",
        "visibility:visible",
        "pointer-events:auto",
        "transition:none"
    ].join(";");
}

function zr(e, t = !1, n = {}) {
    return [
        Lr(e, !1, t, !1, n),
        "opacity:0",
        `transform:translateY(${Ar}px)`,
        "visibility:hidden",
        "pointer-events:none",
        "transition:transform 200ms ease,opacity 200ms ease,visibility 0ms linear 200ms"
    ].join(";");
}

function Br(e, t, n = {
    height: 112,
    bottom: R,
    side: R
}) {
    if (t) return L;
    let r = e === "left" ? "left" : "right",
        i = Or(n);
    return [
        "position:fixed",
        `bottom:${i.bottom}px`,
        `${r}:${i.side}px`,
        `width:${Tr}px`,
        "height:300px",
        "border:0",
        `z-index:${B.proactive}`,
        "background:transparent",
        "overflow:visible",
        "clip-path:inset(0 0 28px 0)"
    ].join(";");
}
//#endregion
//#region src/client/proactive/proactive-frame.ts
function Vr(e, t, {
    show: n = !1,
    isParentElement: r = !1
} = {}) {
    let i = e.intro,
        a = i ? .style.width;
    if (!i || !n && (!a || a === "0px")) return;
    let o = i.style.height,
        s = Number.parseFloat(o),
        c = Number.isFinite(s) && s > 0,
        l = i.ownerDocument.defaultView,
        u = Er(i.ownerDocument),
        d = Br(t, r, Dr(e.button, t, c ? s : 300, {
            width: u.width || (l ? .innerWidth ? ? 0),
            height: u.height || (l ? .innerHeight ? ? 0)
        }));
    P(i, c ? `${d};height:${o}` : d);
}
//#endregion
//#region src/client/client-channel-handlers.ts
var Hr = 6e4,
    Ur = /^[A-Za-z]{2,8}(-[A-Za-z0-9]{1,8})*$/,
    Wr = 0;
async function Gr(e) {
    let t = typeof e == "string" ? ne(e) : null;
    if (!t) return;
    let n = null,
        r = null,
        i = null,
        a = null,
        o = !1,
        s = !1,
        c = () => {
            s || (s = !0, globalThis.window.removeEventListener("afterprint", c), a !== null && globalThis.clearTimeout(a), r ? .remove(), i ? .remove(), n && = (URL.revokeObjectURL(n), null));
        };
    try {
        let e = await fetch(t, {
            credentials: "omit",
            referrerPolicy: "no-referrer"
        });
        if (!e.ok) throw Error(`Image request failed with status ${e.status}`);
        let s = URL.createObjectURL(await e.blob());
        n = s;
        let l = document.createElement("img");
        await new Promise((e, t) => {
            l.onload = () => e(), l.onerror = () => t( /* @__PURE__ */ Error("Image could not be decoded")), l.src = s;
        });
        let u;
        do
            u = `ada-lightbox-print-${++Wr}`;
        while (document.getElementById(u));
        r = document.createElement("style"), r.textContent = `@media print{body>*{display:none!important}#${u}{display:block!important;position:fixed;inset:0;width:100%;height:100%;text-align:center}#${u} img{max-width:100%;max-height:100vh;object-fit:contain}}`, i = document.createElement("div"), i.id = u, i.style.display = "none", i.appendChild(l), document.head.appendChild(r), document.body.appendChild(i), globalThis.window.addEventListener("afterprint", c, {
            once: !0
        }), a = globalThis.setTimeout(c, Hr), o = !0, globalThis.window.print();
    } catch {
        o = !1, c(), globalThis.window.open(t, "_blank", "noopener,noreferrer");
    } finally {
        o || c();
    }
}

function Kr() {
    if (typeof Notification > "u") return !1;
    let e = typeof navigator > "u" ? "" : navigator.userAgent;
    return !(/Safari\//.test(e) && !/(?:Chrome|Chromium|CriOS|FxiOS|EdgiOS|EdgA|Edg|OPiOS|OPR|Opera|SamsungBrowser)\//.test(e));
}

function qr(e) {
    let {
        channel: t,
        channels: n,
        config: r,
        deliverConfig: i,
        frames: a,
        getAlign: o,
        getIsChatOpen: s,
        getWindowInfo: c,
        incrementUnreadCount: l,
        infoRequestCallbacks: u,
        infoRequestTimers: d,
        resolveDataRequest: f,
        rejectDataRequest: p,
        flushDataRequests: m,
        invokeWindowCallback: h,
        open: g,
        parentElement: _,
        routePublishedEvent: v,
        scheduleIntro: y,
        evaluateProactive: b,
        showProactive: x,
        beginProactiveDisplay: S,
        isProactiveClearPending: ee,
        acknowledgeProactiveClear: ne,
        clearProactiveFromCore: C,
        setHasActiveChatter: re,
        setChatterToken: ie,
        setChatterCandidate: ae,
        handleSessionResumeResult: w,
        handleSessionResumeVisibilityResult: oe,
        clearIdentityToken: se,
        markIdentityTokenConsumed: T = () => void 0,
        markIdentityTokenFailed: ce = () => void 0,
        setPersistenceMode: le = () => void 0,
        setCrossWindowLiveChatActive: ue,
        setSensitiveMetaFields: de,
        hasHostSentSensitiveMetaFields: fe = () => !1,
        setHostViewportExpanded: pe,
        setCustomAppFrameStyles: me,
        setDocumentTitle: he = () => void 0,
        onCoreReady: D,
        onCoreError: ge,
        onCoreStartupFailed: _e,
        onCoreProtocolReady: ve,
        setStartupConfig: ye,
        getStartupConfig: be
    } = e;
    i(t), t.on("core.visibility.request", (t) => {
        let n = t.payload;
        n ? .isVisible === !1 ? e.close(n.reason === "close" || n.reason === "minimize" ? n.reason : void 0) : n ? .isVisible === !0 && g();
    }), t.on("core.host.navigate", (e) => {
        let t = e.payload;
        if (typeof t.url != "string") return;
        let n = be() ? .allowedProtocols,
            r = Array.isArray(n) && n.every((e) => typeof e == "string") ? n : [],
            i = te(t.url, r);
        if (i) {
            let e = globalThis.document.createElement("a");
            e.href = i, e.target = "_self", e.rel = "noopener noreferrer", e.hidden = !0, globalThis.document.body.append(e);
            try {
                e.click();
            } finally {
                e.remove();
            }
        }
    }), t.on("core.host.printImage", (e) => {
        let t = e.payload;
        Gr(t ? .url);
    }), t.on("core.host.viewport.set", (e) => {
        let t = e.payload;
        typeof t ? .expanded == "boolean" && pe(t.expanded);
    }), t.on("core.host.frameStyles.set", (e) => {
        let t = Me(E(e.payload) ? .styles);
        t && me(t);
    }), t.on("core.host.documentTitle.set", (e) => {
        let t = E(e.payload),
            n = t ? .title;
        if (typeof n == "string" && n) {
            let e = t ? .language,
                r = typeof e == "string" && Ur.test(e);
            he(n, r ? e : "en", r && t ? .dir === "rtl" ? "rtl" : "ltr");
        }
    }), t.on("core.proactive.show", (e) => {
        let r = e.payload;
        if (ee()) return;
        let i = (Array.isArray(r.messages) ? r.messages : [])[0] ? .campaignKey;
        if (typeof i != "string" || !i.trim()) return;
        let c = i;
        x({
            campaignKey: c,
            surfaceId: r.surfaceId,
            triggerMethod: r.triggerMethod,
            displayDelay: r.displayDelay,
            frequency: r.frequency,
            intentId: r.intentId
        }, () => {
            if (s()) {
                t.send("sdk.proactive.replaced", {
                    surfaceId: r.surfaceId
                }), C();
                return;
            }
            let e = n.get("intro");
            if (!e) return;
            let i = o();
            S(c, r.surfaceId, r.intentId), e.send("intro.proactive.display", {
                messages: r.messages,
                duration: r.duration,
                surfaceId: r.surfaceId,
                align: i
            }), Vr(a, i, {
                show: !0,
                isParentElement: !!_
            });
        });
    }), t.on("core.proactive.cleared", (e) => {
        let t = Number(e.payload ? .requestId);
        Number.isSafeInteger(t) && t > 0 && ne(t);
    }), t.on("core.proactive.clear", (e) => {
        (e.payload === void 0 || e.payload === null) && C();
    }), t.on("core.rollout", (t) => {
        let n = t.payload,
            i = (typeof r.rolloutOverride == "number" && Number.isFinite(r.rolloutOverride) ? Math.max(0, Math.min(1, r.rolloutOverride)) : null) ? ? (typeof n ? .value == "number" ? n.value : null);
        nr(r.handle, i) || (v("ada:start", {
            isRolledOut: !1
        }), h("adaReadyCallback", {
            isRolledOut: !1
        }), e.destroy());
    }), t.on("core.integration.command", (t) => {
        e.dispatchIntegrationCommand(t.payload);
    }), t.on("core.customJavascript", (e) => {
        let t = r.eventCallbacks;
        if (!t) return;
        let n = e.payload,
            i = n ? .payload ? ? n,
            a = i && typeof i.event_data == "object" && i.event_data !== null ? i.event_data : i,
            o = a && typeof a.event_name == "string" ? a.event_name : null,
            s = [
                [o ? ? "*", o ? t[o] : void 0],
                ["*", t["*"]]
            ];
        for (let [e, t] of s)
            if (typeof t == "function") try {
                I(t(a, {
                    eventKey: o ? ? "*"
                }), "eventCallbacks", e, "eventCallbacks handler for custom JS event");
            } catch (t) {
                j.error("eventCallbacks handler error for custom JS event:", t), F("eventCallbacks", e, t);
            }
    }), t.on("core.voice.start", () => {
        e.startVoiceRecording();
    }), t.on("core.voice.stop", () => {
        e.stopVoiceRecording();
    }), t.on("core.voice.setLanguage", (t) => {
        let n = t.payload,
            r = typeof n ? .language == "string" ? n.language : "en-US";
        e.setVoiceLanguage(r);
    }), t.on("core.voice.setMode", (t) => {
        let n = t.payload ? .mode === "push-to-talk" ? "push-to-talk" : "toggle";
        e.setVoiceMode(n);
    }), t.on("core.tts.speak", (e) => {
        let t = e.payload,
            n = typeof t ? .text == "string" ? t.text : "",
            i = r.language || "en-US";
        n && on(n, i);
    }), t.on("core.startup.config", (e) => {
        let t = e.payload;
        ye(t);
        let r = n.get("button");
        r && r.send("sdk.button.config", {
            ...t,
            align: o()
        }), t.intro && t.chatEnabled !== !1 && y(t.intro), b(), v("core.startup.config", t);
    }), t.on("core.button.config", (e) => {
        let t = be();
        if (!t) return;
        let {
            button: r
        } = e.payload;
        t.button = r, r ? .textEnabled && n.get("button") ? .send("sdk.button.text", {
            text: r.text,
            textLanguage: r.textLanguage ? ? "en"
        });
    }), t.on("core.protocol.ready", () => {
        ve ? .();
    }), t.on("core.ready", () => {
        D ? .(), v("ada:start", {
            isRolledOut: !0
        }), v("ada:ready", {
            mode: r.headless ? "headless" : "visible"
        }), h("adaReadyCallback", {
            isRolledOut: !0
        }), r.sensitiveMetaFields && Object.keys(r.sensitiveMetaFields).length > 0 && !fe() && n.get("core") === t && de(r.sensitiveMetaFields);
    }), t.on("core.event.publish", (e) => {
        let t = e.payload,
            r = typeof t ? .key == "string" ? t.key : null;
        if (!r) return;
        if (r === "ada:conversation:message" && !s()) {
            let e = l();
            n.get("button") ? .send("sdk.unread.count", {
                count: e
            });
        }
        if (r === "ada.customApp.fallback") {
            me({});
            let e = t.data,
                n = typeof e ? .appUrl == "string" ? e.appUrl : "the configured appUrl",
                r = typeof e ? .reason == "string" ? e.reason : "unknown reason",
                i = typeof e ? .code == "string" ? e.code : "unknown";
            j.dataLoss(`Custom app ${n} was not mounted; Ada's default app was used instead. Reason: ${r} (code: ${i})`);
        }
        if (r === "ada.branding.headerTextColorWithheld" && j.dataLoss("adaSettings.branding (headerTextColor) was ignored because the header has no background colour to measure it against. Set branding.headerColor as well, or turn on header colouring with a header colour in the dashboard."), r === "ada.branding.dropped") {
            let e = t.data,
                n = Array.isArray(e ? .fields) ? e.fields.filter((e) => typeof e == "string") : [],
                r = typeof e ? .defaultLanguage == "string" ? e.defaultLanguage : "the bot's default language";
            n.length > 0 && j.dataLoss(`adaSettings.branding (${n.join(", ")}) has no entry for ${r}, the bot's default language, and was ignored.`);
        }
        let i = E(t.afterEndChatMinimize) ? .endChatSeq;
        r === "ada:end_conversation" && typeof i == "number" && Number.isFinite(i) ? v(r, t.data, void 0, {
            endChatSeq: i
        }) : typeof t.activationId == "number" ? v(r, t.data, t.activationId) : v(r, t.data);
    }), t.on("core.liveChat.platformEvent", (e) => {
        let t = e.payload,
            n = typeof t ? .event == "string" ? t.event : null;
        n === "LIVE_CHAT_PLATFORM_CONNECTING" && ue(!0), n === "LIVE_CHAT_PLATFORM_ENDED" && ue(!1), n && v(n, t.payload);
    }), t.on("core.liveChat.started", () => {
        ue(!0);
    });
    let O = () => {
        let e = typeof Notification < "u";
        t.send("sdk.notifications.permission", {
            permission: e ? Notification.permission : "default",
            supported: Kr()
        });
    };
    O();
    let xe = null,
        Se = !0,
        Ce = () => {
            O();
        };
    typeof navigator < "u" && "permissions" in navigator && navigator.permissions.query({
        name: "notifications"
    }).then((e) => {
        Se && (xe = e, e.addEventListener("change", Ce), O());
    }).catch(() => {}), t.on("core.requestNotifications", () => {
        if (typeof Notification > "u") {
            O();
            return;
        }
        Notification.requestPermission().catch(() => {}).finally(O);
    }), t.on("core.chatter.created", (e) => {
        let t = e.payload;
        if (typeof t ? .chatterToken == "string") {
            if (ie(t.chatterToken) === !1) return;
            re(!0), h("chatterTokenCallback", t.chatterToken), v("ada:chatter_token", t.chatterToken);
        }
    }), t.on("core.chatter.candidate", (e) => {
        let t = e.payload;
        typeof t ? .chatterToken == "string" && t.chatterToken.trim() && Number.isSafeInteger(t.requestId) && Number(t.requestId) > 0 && ae(t);
    }), t.on("core.session.resume.result", (e) => {
        let t = e.payload;
        typeof t ? .chatterToken != "string" || !t.chatterToken.trim() || !Number.isSafeInteger(t.requestId) || Number(t.requestId) <= 0 || typeof t.resumed != "boolean" || w(t);
    }), t.on("core.session.resume.visibility.result", (e) => {
        let t = e.payload;
        typeof t ? .chatterToken != "string" || !t.chatterToken.trim() || !Number.isSafeInteger(t.requestId) || Number(t.requestId) <= 0 || typeof t.visible != "boolean" || oe(t);
    }), t.on("core.identityToken.consumed", (e) => {
        let t = e.payload;
        T(typeof t ? .chatterToken == "string" && t.chatterToken.trim() ? t.chatterToken : void 0), se();
    }), t.on("core.identityToken.failed", (e) => {
        ce(), se();
        let t = e.payload,
            n = typeof t ? .reason == "string" ? t.reason : "identity_token_exchange_failed";
        v("ada:identity_token:error", {
            reason: n
        }), n === "identity_token_expired" && v("ada:identity_token:expired", {});
    }), t.on("core.storage.persistence", (e) => {
        let t = e.payload ? .mode;
        (t === "normal" || t === "session" || t === "private") && le(t);
    }), t.on("core.analytics.event", (e) => {
        let t = e.payload;
        v("ada:analytics", t);
    }), t.on("core.info.response", (e) => {
        let t = e.payload,
            n = typeof t ? .requestId == "string" ? t.requestId : null;
        if (!n) return;
        let r = u.get(n);
        if (!r) return;
        u.delete(n);
        let i = d.get(n);
        i && (clearTimeout(i), d.delete(n));
        let a = c();
        re(!!t.hasActiveChatter), r({
            isChatOpen: a.isChatOpen,
            isDrawerOpen: a.isDrawerOpen,
            hasActiveChatter: !!t.hasActiveChatter,
            hasClosedChat: a.hasClosedChat
        });
    }), t.on("core.metaFields.response", (e) => {
        let t = e.payload,
            n = typeof t ? .requestId == "string" ? t.requestId : null;
        n && f(n, t.metaFields && typeof t.metaFields == "object" ? t.metaFields : {});
    }), t.on("core.conversation.response", (e) => {
        let t = e.payload,
            n = typeof t ? .requestId == "string" ? t.requestId : null;
        if (!n) return;
        if (typeof t.error == "string") {
            p(n, t.error);
            return;
        }
        let r = typeof t.handoff == "object" && t.handoff !== null ? t.handoff : {},
            i = typeof r.agent == "object" && r.agent !== null ? r.agent : null;
        f(n, {
            id: typeof t.id == "string" ? t.id : null,
            handoff: {
                inLiveChat: r.inLiveChat === !0,
                ...i && typeof i.id == "string" && typeof i.name == "string" ? {
                    agent: {
                        id: i.id,
                        name: i.name,
                        ...typeof i.avatarUrl == "string" ? {
                            avatarUrl: i.avatarUrl
                        } : {}
                    }
                } : {}
            }
        });
    }), t.on("core.messages.response", (e) => {
        let t = e.payload,
            n = typeof t ? .requestId == "string" ? t.requestId : null;
        if (n) {
            if (typeof t.error == "string") {
                p(n, t.error);
                return;
            }
            f(n, Array.isArray(t.messages) ? t.messages : []);
        }
    }), t.on("core.composerText.response", (e) => {
        let t = e.payload,
            n = typeof t ? .requestId == "string" ? t.requestId : null;
        if (n) {
            if (typeof t.error == "string") {
                p(n, t.error);
                return;
            }
            f(n, {
                ok: !0
            });
        }
    }), t.on("core.playbook.response", (e) => {
        let t = e.payload;
        typeof t ? .requestId == "string" && (typeof t.error == "string" ? p(t.requestId, t.error) : t.accepted === !0 ? f(t.requestId, void 0) : p(t.requestId, "triggerPlaybook returned an invalid response"));
    }), t.on("core.quickReply.response", (e) => {
        let t = e.payload,
            n = typeof t ? .requestId == "string" ? t.requestId : null;
        if (n) {
            if (typeof t.error == "string") {
                p(n, t.error);
                return;
            }
            f(n, void 0);
        }
    }), t.on("core.message.response", (e) => {
        let t = e.payload,
            n = typeof t ? .requestId == "string" ? t.requestId : null;
        if (n) {
            if (typeof t.error == "string") {
                p(n, t.error);
                return;
            }
            if (typeof t.id != "string" || !t.id) {
                p(n, "sendMessage rejected by chat: INVALID_RESPONSE");
                return;
            }
            f(n, {
                id: t.id
            });
        }
    });
    let k = (e) => {
        let t = e.payload,
            n = typeof t ? .requestId == "string" ? t.requestId : null;
        n && f(n, void 0);
    };
    t.on("core.reset.response", k), t.on("core.history.delete.response", k);
    let we = () => {
        for (let [e, t] of u) {
            let n = d.get(e);
            n && clearTimeout(n), d.delete(e), u.delete(e), t(c());
        }
    };
    return t.on("core.startup.failed", () => {
        _e ? .(), we();
    }), t.on("frame.error", () => {
        ge ? .(), me({}), pe(!1), we(), m({
            preserveForCoreReplacement: !0
        });
    }), t.on("frame.notification.create", (e) => {
        let t = e.payload,
            n = typeof t ? .title == "string" ? t.title : "";
        if (!n || typeof Notification > "u" || Notification.permission !== "granted" || (typeof document > "u" || document.hidden !== !0) && s()) return;
        let r = typeof t.body == "string" ? t.body : void 0,
            i = typeof t.icon == "string" ? t.icon : void 0,
            a = typeof t.conversationId == "string" ? t.conversationId : void 0,
            o = typeof t.messageId == "string" ? t.messageId : void 0;
        try {
            let e = new Notification(n, {
                body: r,
                icon: i
            });
            e.onclick = () => {
                try {
                    window.focus();
                } catch {}
                s() || g(), v("ada:web_notification:click", {
                    conversation_id: a,
                    message_id: o
                }), e.close();
            };
        } catch {}
    }), t.on("core.zd.auth.request", (n) => {
        let r = E(n.payload) ? .requestId,
            i = typeof r == "string" ? {
                requestId: r
            } : {},
            a = e.getZdChatterAuthCallback();
        if (!a) {
            t.send("sdk.zd.auth.response", {
                ...i,
                token: null,
                error: "no_callback"
            });
            return;
        }
        let o = !1,
            s = (e) => {
                o || (o = !0, clearTimeout(c), t.send("sdk.zd.auth.response", {
                    ...e,
                    ...i
                }));
            },
            c = setTimeout(() => {
                s({
                    token: null,
                    error: "timeout"
                });
            }, Ht),
            l = () => {
                s({
                    token: null,
                    error: "callback_error"
                });
            };
        try {
            I(a((e) => {
                s({
                    token: typeof e == "string" ? e : null,
                    error: typeof e == "string" ? void 0 : "invalid_token"
                });
            }), "zdChatterAuthCallback", "core.zd.auth.request", "zdChatterAuthCallback", l);
        } catch (e) {
            j.error("zdChatterAuthCallback threw:", e), F("zdChatterAuthCallback", "core.zd.auth.request", e), l();
        }
    }), () => {
        me({}), pe(!1), Se = !1, xe ? .removeEventListener("change", Ce), xe = null;
    };
}

function Jr(e) {
    let {
        channel: t,
        frames: n,
        deliverConfig: r,
        open: i,
        setLastOpenedViaKeyboard: a,
        getAlign: o,
        getIsChatOpen: s
    } = e;
    r(t), t.on("button.click", () => {
        i();
    }), t.on("button.click.keyboard", () => {
        a(!0), i();
    }), t.on("button.resize", (e) => {
        let {
            width: t,
            height: r
        } = e.payload, i = n.button;
        if (i && t > 0 && r > 0) {
            i.style.width = `${t}px`, i.style.height = `${r}px`;
            let e = s();
            e || (i.style.opacity = "1"), cr(i, e), Vr(n, o());
        }
    });
}
//#endregion
//#region src/client/client-errors.ts
var Yr = new Set([
        "start_already_active",
        "start_interrupted",
        "start_owner_conflict"
    ]),
    H = class extends Error {
        constructor(e, t) {
            super(e), A(this, "code", void 0), this.name = "AdaEmbedError", this.code = t;
        }
    },
    U = [];
for (let e = 0; e < 256; ++e) U.push((e + 256).toString(16).slice(1));

function Xr(e, t = 0) {
    return (U[e[t + 0]] + U[e[t + 1]] + U[e[t + 2]] + U[e[t + 3]] + "-" + U[e[t + 4]] + U[e[t + 5]] + "-" + U[e[t + 6]] + U[e[t + 7]] + "-" + U[e[t + 8]] + U[e[t + 9]] + "-" + U[e[t + 10]] + U[e[t + 11]] + U[e[t + 12]] + U[e[t + 13]] + U[e[t + 14]] + U[e[t + 15]]).toLowerCase();
}
//#endregion
//#region ../../node_modules/uuid/dist/rng.js
var Zr, Qr = new Uint8Array(16);

function $r() {
    if (!Zr) {
        if (typeof crypto > "u" || !crypto.getRandomValues) throw Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
        Zr = crypto.getRandomValues.bind(crypto);
    }
    return Zr(Qr);
}
var ei = {
    randomUUID: typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto)
};
//#endregion
//#region ../../node_modules/uuid/dist/v4.js
function ti(e, t, n) {
    e || = {};
    let r = e.random ? ? e.rng ? .() ? ? $r();
    if (r.length < 16) throw Error("Random bytes length must be >= 16");
    if (r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, t) {
        if (n || = 0, n < 0 || n + 16 > t.length) throw RangeError(`UUID byte range ${n}:${n + 15} is out of buffer bounds`);
        for (let e = 0; e < 16; ++e) t[n + e] = r[e];
        return t;
    }
    return Xr(r);
}

function ni(e, t, n) {
    return ei.randomUUID && !t && !e ? ei.randomUUID() : ti(e, t, n);
}
//#endregion
//#region src/frame-channel/frame-channel.ts
var ri = 64,
    ii = class {
        constructor(e) {
            A(this, "_name", void 0), A(this, "_target", null), A(this, "_targetOrigin", null), A(this, "_expectedIncomingName", null), A(this, "_pendingMessages", []), A(this, "_handlers", /* @__PURE__ */ new Map()), A(this, "_pendingRequests", /* @__PURE__ */ new Map()), A(this, "_boundListener", null), A(this, "_lastOverflowEventMs", 0), this._name = e;
        }
        _normalizeMessageName(e) {
            return typeof e == "string" && e.trim() ? e.trim() : null;
        }
        connect(e, t, n) {
            if (this._boundListener && window.removeEventListener("message", this._boundListener), this._target = e, this._pendingMessages = [], this._targetOrigin = null, this._expectedIncomingName = null, t) {
                let e = T(t);
                e && (this._targetOrigin = e);
            }
            this._expectedIncomingName = this._normalizeMessageName(n), this._boundListener = (e) => {
                this._handleMessage(e);
            }, window.addEventListener("message", this._boundListener);
        }
        disconnect() {
            this._boundListener && = (window.removeEventListener("message", this._boundListener), null), this._target = null, this._targetOrigin = null, this._pendingMessages = [];
            for (let [e, t] of this._pendingRequests) clearTimeout(t.timer), t.cleanup(), t.reject( /* @__PURE__ */ Error("FrameChannel: disconnected")), this._pendingRequests.delete(e);
            this._handlers.clear();
        }
        setTargetOrigin(e) {
            let t = T(e);
            t && (this._targetOrigin = t, this._flushPendingMessages());
        }
        send(e, t) {
            if (!this._target) return;
            let n = {
                name: this._name,
                type: e,
                payload: t
            };
            if (!this._targetOrigin) {
                this._queuePendingMessage(n);
                return;
            }
            this._target.postMessage(n, this._targetOrigin);
        }
        request(e, t, n, r = 5e3) {
            return new Promise((i, a) => {
                if (!this._target) {
                    a( /* @__PURE__ */ Error("FrameChannel: not connected"));
                    return;
                }
                let o = ni(),
                    s = (e) => {
                        if (e.type === t && e.id === o) {
                            let t = this._pendingRequests.get(o);
                            t && (clearTimeout(t.timer), t.cleanup(), this._pendingRequests.delete(o), t.resolve(e));
                        }
                    },
                    c = () => {
                        this.off(t, s);
                    },
                    l = setTimeout(() => {
                        c(), this._pendingRequests.delete(o), a( /* @__PURE__ */ Error(`FrameChannel: request "${e}" timed out after ${r}ms`));
                    }, r);
                this._pendingRequests.set(o, {
                    resolve: i,
                    reject: a,
                    timer: l,
                    cleanup: c
                });
                let u = {
                    name: this._name,
                    type: e,
                    payload: n,
                    id: o
                };
                this._targetOrigin ? this._target.postMessage(u, this._targetOrigin) : this._queuePendingMessage(u), this.on(t, s);
            });
        }
        on(e, t) {
            let n = this._handlers.get(e);
            n || (n = /* @__PURE__ */ new Set(), this._handlers.set(e, n)), n.add(t);
        }
        off(e, t) {
            let n = this._handlers.get(e);
            n && (n.delete(t), n.size === 0 && this._handlers.delete(e));
        }
        once(e, t) {
            let n = (r) => {
                this.off(e, n), t(r);
            };
            this.on(e, n);
        }
        _handleMessage(e) {
            if (this._target && e.source !== this._target) return;
            if (!this._targetOrigin) {
                if (!e.origin || e.origin === "null") return;
                let t = T(e.origin);
                if (!t) return;
                this._targetOrigin = t, this._flushPendingMessages();
            } else if (e.origin !== this._targetOrigin) return;
            let t;
            try {
                t = typeof e.data == "string" ? JSON.parse(e.data) : e.data;
            } catch (t) {
                this._target && e.source === this._target && j.debug(`FrameChannel(${this._name}): failed to parse message:`, t instanceof Error ? t.message : String(t));
                return;
            }
            if (!t || typeof t.name != "string" || typeof t.type != "string" || this._expectedIncomingName && t.name !== this._expectedIncomingName) return;
            let n = this._handlers.get(t.type);
            if (n)
                for (let e of n) e(t);
        }
        _queuePendingMessage(e) {
            if (this._pendingMessages.length >= ri) {
                let e = this._pendingMessages.shift(),
                    t = Date.now();
                typeof window < "u" && t - this._lastOverflowEventMs >= 1e3 && (this._lastOverflowEventMs = t, window.dispatchEvent(new CustomEvent("ada:error", {
                    detail: {
                        type: "frame.message.dropped",
                        frame: this._name,
                        message: `Message queue full (${ri}), dropped oldest message`,
                        droppedMessageType: e ? .type
                    }
                })));
            }
            this._pendingMessages.push(e);
        }
        _flushPendingMessages() {
            if (!(!this._target || !this._targetOrigin)) {
                for (let e of this._pendingMessages) this._target.postMessage(e, this._targetOrigin);
                this._pendingMessages = [];
            }
        }
    },
    ai = 64,
    oi = class e {
        constructor(t, n = "sdk") {
            A(this, "_name", void 0), A(this, "_parentOrigin", void 0), A(this, "_expectedParentName", void 0), A(this, "_handlers", /* @__PURE__ */ new Map()), A(this, "_boundListener", null), A(this, "_pendingMessages", []), this._name = t, this._expectedParentName = e._normalizeName(n), this._parentOrigin = T(document.referrer), this._boundListener = (e) => {
                this._handleMessage(e);
            }, window.addEventListener("message", this._boundListener);
        }
        reportOrigin() {
            this.send("frame.origin.report", {
                origin: window.location.origin
            });
        }
        signalReady() {
            this.send("frame.ready", {
                name: this._name
            });
        }
        reportError(e) {
            this.send("frame.error", {
                name: this._name,
                error: e
            });
        }
        send(e, t, n) {
            if (!window.parent || window.parent === window) return;
            let r = {
                name: this._name,
                type: e,
                payload: t,
                id: n
            };
            if (!this._parentOrigin) {
                this._pendingMessages.length >= ai && this._pendingMessages.shift(), this._pendingMessages.push(r);
                return;
            }
            window.parent.postMessage(r, le(this._parentOrigin));
        }
        reply(e, t, n) {
            this.send(t, n, e.id);
        }
        on(e, t) {
            let n = this._handlers.get(e);
            n || (n = /* @__PURE__ */ new Set(), this._handlers.set(e, n)), n.add(t);
        }
        off(e, t) {
            let n = this._handlers.get(e);
            n && (n.delete(t), n.size === 0 && this._handlers.delete(e));
        }
        setParentOrigin(e) {
            let t = T(e);
            t && (this._parentOrigin = t, this._flushPendingMessages());
        }
        static _normalizeName(e) {
            return typeof e == "string" && e.trim() ? e.trim() : null;
        }
        destroy() {
            this._boundListener && = (window.removeEventListener("message", this._boundListener), null), this._handlers.clear(), this._pendingMessages = [];
        }
        _flushPendingMessages() {
            if (!(!this._parentOrigin || !window.parent || window.parent === window)) {
                for (let e of this._pendingMessages) window.parent.postMessage(e, le(this._parentOrigin));
                this._pendingMessages = [];
            }
        }
        _handleMessage(e) {
            if (e.source !== window.parent) return;
            if (!this._parentOrigin) {
                let t = ce(e.origin);
                if (!t) return;
                j.debug(`FrameChild(${this._name}): parent origin locked to ${t}`), this._parentOrigin = t, this._flushPendingMessages();
            } else if (e.origin !== this._parentOrigin) return;
            let t;
            try {
                t = typeof e.data == "string" ? JSON.parse(e.data) : e.data;
            } catch {
                return;
            }
            if (!t || typeof t.name != "string" || typeof t.type != "string" || this._expectedParentName && t.name !== this._expectedParentName) return;
            let n = this._handlers.get(t.type);
            if (n)
                for (let e of n) e(t);
        }
    },
    W = 1e4,
    si = 5e3,
    ci = 15e3,
    li = 3e4,
    ui = 12e4,
    di = 3e3,
    fi = 2e4,
    pi = 3e4,
    mi = ui + 5e3,
    hi = 3e4,
    gi = 12e4,
    _i = {
        core: "core.html",
        button: "button.html",
        intro: "intro.html"
    },
    vi = {
        core: "sdk",
        button: "sdk",
        intro: "integrations"
    },
    yi = {
        core: "Ada Chat",
        button: "Ada Chat Button",
        intro: "Ada Chat Message"
    },
    bi = {
        button: "ada-button-frame",
        core: "ada-chat-frame",
        intro: "ada-intro-frame"
    },
    xi = "Ada Chat Integration",
    Si = {
        core: "allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads",
        button: "allow-scripts allow-same-origin",
        intro: "allow-scripts allow-same-origin"
    };
//#endregion
//#region src/client/client-frame-runtime.ts
function Ci(e) {
    let t = e.commitSha ? `/${e.commitSha}` : "",
        n = x(e.assetsOrigin),
        r = new URL(`${n}${t}/${e.packageName}/${e.path}`);
    return r.searchParams.set("ada_handle", e.handle), r.searchParams.set("ada_cluster", e.cluster), Fe(r, Pe(e.handle, e.cluster)).toString();
}
var wi = "sdk/index.js";

function Ti(e, t, n) {
    return Et(e, t, wi, n).assetsBase;
}

function Ei(e) {
    let {
        name: t
    } = e, n = document.createElement("iframe");
    n.src = e.buildAssetUrl(vi[t], _i[t]), P(n, e.options.style), n.setAttribute("data-ada-frame", t), n.setAttribute("allow", e.options.additionalAllow ? `clipboard-write; ${e.options.additionalAllow}` : "clipboard-write"), n.setAttribute("sandbox", Si[t]), n.title = yi[t];
    let r = bi[t];
    r && (n.id = r, n.classList.add(r), n.name = r), n.lang = "en";
    let i = setTimeout(() => {
        e.loadTimers.delete(t);
        let n = `Frame "${t}" failed to load within ${W}ms`;
        e.onFrameTimeout(t, n);
    }, W);
    e.loadTimers.set(t, i), n.addEventListener("load", () => {
        let r = e.loadTimers.get(t);
        r && (clearTimeout(r), e.loadTimers.delete(t)), e.onFrameLoaded(t, n);
    }, {
        once: !0
    }), e.frames[t] = n;
    try {
        e.container ? .appendChild(n);
    } catch (n) {
        let r = e.loadTimers.get(t);
        throw r && (clearTimeout(r), e.loadTimers.delete(t)), delete e.frames[t], n;
    }
}

function Di(e) {
    let t = e.iframe.contentWindow;
    if (!t) return;
    let n = e.getFrameOrigin(e.iframe),
        r = new ii("sdk");
    r.connect(t, n ? ? void 0, e.name);
    let i = !1,
        a = setTimeout(() => {
            i || j.warn(`Frame "${e.name}" did not report its origin within ${di}ms`);
        }, di);
    r.on("frame.origin.report", (t) => {
        i = !0, clearTimeout(a);
        let o = t.payload,
            s = typeof o ? .origin == "string" ? o.origin : null;
        if (s && s !== "null") {
            if (n && s !== n) {
                j.error(`Frame "${e.name}" reported unexpected origin "${s}" (expected "${n}")`);
                return;
            }
            r.setTargetOrigin(s);
        }
    }), r.on("frame.error", (e) => {
        let t = e.payload;
        j.error(`Frame "${t?.name}" error:`, t ? .error);
    }), e.channels.set(e.name, r), e.name === "core" && e.setupCoreChannel(r), e.name === "button" && e.setupButtonChannel(r), e.name === "intro" && e.setupIntroChannel(r);
}
//#endregion
//#region src/client/client-host-runtime.ts
function Oi(e, t, n, r) {
    let i = N(M(e ? ? {}));
    return jn(i, {
        ...i,
        initialURL: r,
        introShown: n,
        ...t ? {
            test_user: 1
        } : {}
    });
}
var ki = /* @__PURE__ */ new Set();

function Ai(e, t) {
    let n = N(M(t.sensitiveMetaFields ? ? {}), {
        sensitive: !0
    });
    !ki.has(t.handle) && t.allowMetaFieldsInReset !== void 0 && typeof t.allowMetaFieldsInReset != "boolean" && (ki.add(t.handle), j.dataLoss("allowMetaFieldsInReset ignored: expected a boolean; reset() will apply caller meta fields"));
    let r = Oi(t.metaFields, t.testMode === !0, t.introShown === !0, t.initialURL === void 0 ? window.location.href : t.initialURL);
    e.send("sdk.config.set", {
        handle: t.handle,
        cluster: t.cluster,
        endpoint: t.endpoint,
        ...t.language ? {
            language: t.language
        } : {},
        greeting: t.greeting,
        ...t.configuredGreetingResponseId ? {
            configuredGreetingResponseId: t.configuredGreetingResponseId
        } : {},
        ...t.identityToken ? {
            identityToken: t.identityToken
        } : {},
        ...t.skipGreeting === !0 ? {
            skipGreeting: !0
        } : {},
        ...t.skipGreetingOnce === !0 ? {
            skipGreetingOnce: !0
        } : {},
        ...t.greetingResponseId === void 0 ? {} : {
            greetingResponseId: t.greetingResponseId
        },
        metaFields: r,
        metaFieldCounts: An(r, n),
        ...(() => {
            let e = N(M(t.metaFieldsBaseline ? ? {}));
            return Object.keys(e).length > 0 ? {
                metaFieldsBaseline: e
            } : {};
        })(),
        ...Object.keys(n).length > 0 ? {
            sensitiveMetaFields: n
        } : {},
        ...typeof t.allowMetaFieldsInReset == "boolean" ? {
            allowMetaFieldsInReset: t.allowMetaFieldsInReset
        } : {},
        ...t.enableProgrammaticControl ? {
            enableProgrammaticControl: !0
        } : {},
        ...t.appUrl ? {
            appUrl: t.appUrl
        } : {},
        ...t.appUrl && t.appUrlFallback === !1 ? {
            appUrlFallback: !1
        } : {},
        ...t.hostTelemetry ? {
            hostTelemetry: t.hostTelemetry
        } : {},
        androidHostNavigation: t.androidHostNavigation === !0,
        ...t.branding ? {
            branding: t.branding
        } : {},
        ...t.theme ? {
            theme: t.theme
        } : {},
        mode: "prod",
        ...t.privateMode ? {
            privateMode: !0
        } : {},
        ...t.isParentElementMode ? {
            isParentElementMode: !0
        } : {},
        ...t.headless ? {
            headless: !0
        } : {},
        isMobileViewport: t.isMobileViewport === !0,
        ...t.hideDefaultHeader ? {
            hideDefaultHeader: !0
        } : {},
        ...t.nativeSessionMirror ? {
            nativeSessionMirror: !0
        } : {},
        ...t.clearPersistenceOnPrepare ? {
            clearPersistenceOnPrepare: !0
        } : {},
        ...t.clearPersistenceAckRequestId && t.clearPersistenceAckResponseType ? {
            clearPersistenceAckRequestId: t.clearPersistenceAckRequestId,
            clearPersistenceAckResponseType: t.clearPersistenceAckResponseType,
            ...t.clearPersistenceOutgoingStorageMode ? {
                clearPersistenceOutgoingStorageMode: t.clearPersistenceOutgoingStorageMode
            } : {},
            ...t.clearPersistenceStorageModes ? .length ? {
                clearPersistenceStorageModes: t.clearPersistenceStorageModes
            } : {}
        } : {}
    });
}

function ji(e, ...t) {
    let n = window[e];
    if (typeof n != "function") return;
    let r = Mi[e] ? ? e;
    try {
        I(n(...t), e, r, `Window callback "${e}"`);
    } catch (t) {
        j.error(`Window callback "${e}" threw:`, t), F(e, r, t);
    }
}
var Mi = {
        adaReadyCallback: "ada:start",
        chatterTokenCallback: "ada:chatter_token",
        toggleCallback: "ada:toggle",
        adaEmbedLoadedCallback: "ada:embed_loaded"
    },
    Ni = new Set([
        "ada:message:sent",
        "ada:message:received",
        "core.session.mirror",
        "core.session.mirrorClear",
        "core.session.mirrorRequest"
    ]);

function Pi(e, t) {
    return Ni.has(t) ? e.wildcard !== !0 && e.key === t : e.wildcard === !0 ? !0 : e.key === t || t.startsWith(e.key);
}

function Fi(e, t, n) {
    let r = {
        eventKey: t
    };
    for (let [, i] of e) {
        if (!Pi(i, t)) continue;
        if (i.wildcard === !0) {
            try {
                I(i.callback(t, n), "subscribeAll", t, `subscribeAll callback for "${t}"`);
            } catch (e) {
                j.error(`subscribeAll callback error for "${t}":`, e), F("subscribeAll", t, e);
            }
            continue;
        }
        let {
            callback: e
        } = i;
        try {
            I(e(n, r), "subscribeEvent", t, `subscribeEvent callback for "${t}"`);
        } catch (e) {
            j.error(`subscribeEvent callback error for "${t}":`, e), F("subscribeEvent", t, e);
        }
    }
}
var Ii = {
        origPushState: null,
        origReplaceState: null,
        locationChangeHandler: null,
        popstateHandler: null
    },
    Li = 0,
    Ri = null;

function zi() {
    if (Li === 0) {
        let e = document.body,
            t = document.documentElement;
        Ri = {
            body: e,
            bodyOverflowX: e.style.overflowX,
            bodyOverflowY: e.style.overflowY,
            root: t,
            rootOverflowX: t.style.overflowX,
            rootOverflowY: t.style.overflowY
        }, e.style.overflowX = "hidden", e.style.overflowY = "hidden", t.style.overflowX = "hidden", t.style.overflowY = "hidden";
    }
    Li += 1;
}

function Bi() {
    if (Li === 0 || (--Li, Li !== 0)) return;
    let e = Ri;
    Ri = null, e && (e.body.style.overflowX = e.bodyOverflowX, e.body.style.overflowY = e.bodyOverflowY, e.root.style.overflowX = e.rootOverflowX, e.root.style.overflowY = e.rootOverflowY);
}
var Vi = 0,
    G = 0,
    Hi = null,
    Ui = null,
    K = null;

function Wi(e, t, n = !1) {
    if (Vi === 0) {
        Hi = history.pushState.bind(history), Ui = history.replaceState.bind(history), K = () => {
            window.dispatchEvent(new Event("ada:locationchange")), G > 0 && window.dispatchEvent(new Event("locationchange"));
        };
        let e = Hi,
            t = Ui;
        history.pushState = (...t) => {
            e(...t), G > 0 && window.dispatchEvent(new Event("pushstate")), K ? .();
        }, history.replaceState = (...e) => {
            t(...e), G > 0 && window.dispatchEvent(new Event("replacestate")), K ? .();
        }, window.addEventListener("popstate", K);
    }
    Vi++, n && G++;
    let r = { ...e
    };
    return r.isLegacyLoader = n, r.origPushState = Hi, r.origReplaceState = Ui, r.popstateHandler = K, r.locationChangeHandler = t, window.addEventListener("ada:locationchange", r.locationChangeHandler), r;
}

function Gi(e) {
    let t = { ...e
    };
    return t.origPushState && (t.isLegacyLoader && = (G = Math.max(0, G - 1), !1), Vi = Math.max(0, Vi - 1), Vi === 0 && Hi && (history.pushState = Hi, history.replaceState = Ui, K && window.removeEventListener("popstate", K), Hi = null, Ui = null, K = null), t.origPushState = null, t.origReplaceState = null), t.locationChangeHandler && = (window.removeEventListener("ada:locationchange", t.locationChangeHandler), null), t.popstateHandler = null, t;
}
//#endregion
//#region src/client/fallback-html.ts
var Ki = "<!DOCTYPE html>\n<html lang=\"en\" data-ada-instance-id=\"\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, height=device-height\">\n  <meta http-equiv=\"x-ua-compatible\" content=\"IE=edge\">\n  <title>Chat - Technical Difficulties</title>\n  <style>\n    * {\n      box-sizing: border-box;\n    }\n    body {\n      margin: 0;\n      font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif;\n      -webkit-font-smoothing: antialiased;\n      -moz-osx-font-smoothing: grayscale;\n    }\n    .container {\n      display: flex;\n      flex-direction: column;\n      height: 100vh;\n      background-color: #ffffff;\n    }\n    .content-area {\n      flex: 1;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      padding: 24px 16px;\n    }\n    .message-container {\n      width: 100%;\n      max-width: 351px;\n    }\n    .message-card {\n      display: flex;\n      flex-direction: column;\n      align-items: center;\n      justify-content: center;\n      padding: 24px 16px;\n      border: 1px solid #e8e8eb;\n      border-radius: 16px;\n      background-color: #ffffff;\n      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.06);\n    }\n    .icon-container {\n      margin-bottom: 8px;\n    }\n    .icon-container svg {\n      fill: rgba(0, 0, 0, 0.65);\n      display: block;\n    }\n    .message-text {\n      margin: 8px 0 0;\n      line-height: 20px;\n      font-size: 1rem;\n      text-align: center;\n      color: rgba(0, 0, 0, 0.95);\n    }\n    .close-button {\n      margin-top: 16px;\n      padding: 12px 24px;\n      font-size: 14px;\n      font-weight: 500;\n      color: #ffffff;\n      background-color: #000000;\n      border: none;\n      border-radius: 8px;\n      cursor: pointer;\n      transition: background-color 0.2s ease;\n      font-family: inherit;\n    }\n    .close-button:hover {\n      background-color: #333333;\n    }\n    .close-button:active {\n      background-color: #1a1a1a;\n    }\n    .close-button:focus {\n      outline: 2px solid #4d90fe;\n      outline-offset: 2px;\n    }\n  </style>\n</head>\n<body style=\"margin:0\">\n  <div id=\"app\">\n    <div class=\"container\">\n      <div class=\"content-area\">\n        <div class=\"message-container\">\n          <div class=\"message-card\">\n            <div class=\"icon-container\">\n              <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"42\" height=\"42\" viewBox=\"0 0 24 24\" fill=\"currentColor\">\n                <path d=\"M12,9a1,1,0,0,0-1,1v3a1,1,0,0,0,2,0V10A1,1,0,0,0,12,9Zm7-7H5A3,3,0,0,0,2,5V15a3,3,0,0,0,3,3H16.59l3.7,3.71A1,1,0,0,0,21,22a.84.84,0,0,0,.38-.08A1,1,0,0,0,22,21V5A3,3,0,0,0,19,2Zm1,16.59-2.29-2.3A1,1,0,0,0,17,16H5a1,1,0,0,1-1-1V5A1,1,0,0,1,5,4H19a1,1,0,0,1,1,1ZM12,6a1,1,0,1,0,1,1A1,1,0,0,0,12,6Z\"></path>\n              </svg>\n            </div>\n            <p role=\"alert\" data-testid=\"default-outage-message\" class=\"message-text\">\n              The chat is experiencing technical difficulties and we're working to fix them as soon as possible. Please check back for an update in a few minutes.\n            </p>\n            <button class=\"close-button\" id=\"closeButton\" aria-label=\"Close chat window\">Close</button>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n  <script>\n    document.getElementById('closeButton').addEventListener('click', function() {\n      window.parent.postMessage('ADA_FALLBACK_CLOSE', '*');\n    });\n  <\/script>\n</body>\n</html>";

function qi() {
    return `data:text/html;charset=utf-8,${encodeURIComponent(Ki)}`;
}
//#endregion
//#region src/client/frame-manager.ts
var Ji = class {
        constructor(e) {
            A(this, "_frames", {}), A(this, "_channels", /* @__PURE__ */ new Map()), A(this, "_loadTimers", /* @__PURE__ */ new Map()), A(this, "_options", void 0), this._options = e;
        }
        get container() {
            return this._options.container;
        }
        get frames() {
            return this._frames;
        }
        get channels() {
            return this._channels;
        }
        buildAssetUrl(e, t) {
            return Ci({
                packageName: e,
                path: t,
                handle: this._options.handle,
                cluster: this._options.cluster,
                assetsOrigin: this._options.assetsOrigin,
                commitSha: this._options.commitSha
            });
        }
        mountFrame(e, t) {
            Ei({
                name: e,
                options: t,
                container: this._options.container,
                frames: this._frames,
                loadTimers: this._loadTimers,
                buildAssetUrl: (e, t) => this.buildAssetUrl(e, t),
                onFrameTimeout: this._options.onFrameTimeout,
                onFrameLoaded: (e, t) => this._onFrameLoaded(e, t)
            });
        }
        sendToCore(e, t) {
            let n = this._channels.get("core");
            n && n.send(e, t);
        }
        getFrameOrigin(e) {
            try {
                return T(new URL(e.src, window.location.href).href);
            } catch {
                return null;
            }
        }
        teardown() {
            for (let [, e] of this._channels) e.disconnect();
            this._channels.clear();
            for (let [, e] of this._loadTimers) clearTimeout(e);
            this._loadTimers.clear(), this._options.container.remove();
        }
        _onFrameLoaded(e, t) {
            Di({
                name: e,
                iframe: t,
                channels: this._channels,
                getFrameOrigin: (e) => this.getFrameOrigin(e),
                setupCoreChannel: this._options.setupCoreChannel,
                setupButtonChannel: this._options.setupButtonChannel,
                setupIntroChannel: this._options.setupIntroChannel
            });
        }
    },
    Yi = {
        zendesk: "zendesk.html",
        zendeskMessaging: "zendesk-messaging.html",
        oauth: "oauth.html",
        csat: "csat.html"
    },
    Xi = {
        zendesk: "allow-scripts allow-same-origin allow-forms allow-popups allow-downloads",
        zendeskMessaging: "allow-scripts allow-same-origin allow-forms allow-popups allow-downloads",
        oauth: "allow-scripts allow-same-origin allow-forms allow-popups",
        csat: "allow-scripts allow-same-origin allow-forms"
    };

function Zi(e, t) {
    return e === "zendesk" && t === "cross_tab.fatal";
}

function Qi(e) {
    if (Zi(e.integration, e.action)) return !0;
    if (e.integration !== "integration" || e.action !== "result.timeout" && e.action !== "result.validation") return !1;
    let t = e.error ? .details;
    return t ? Zi(D(t.integration) ? ? "", D(t.action) ? ? "") || Zi(D(t.expectedIntegration) ? ? "", D(t.expectedAction) ? ? "") : !1;
}

function $i(e) {
    let t = D(e.messageId),
        n = D(e.requestId),
        r = _e(e.zendeskOperationSeq);
    return {
        ...t ? {
            messageId: t
        } : {},
        ...n ? {
            requestId: n
        } : {},
        ...r === null ? {} : {
            zendeskOperationSeq: r
        }
    };
}

function ea(e) {
    return e.integration === "liveAgent" && e.action === "message.send";
}

function ta(e, t, n) {
    let r = { ...e
    };
    return delete r.id, delete r.messageId, delete r.requestId, delete r.zendeskOperationSeq, t.messageId !== void 0 && (r[n] = t.messageId), t.requestId !== void 0 && (r.requestId = t.requestId), t.zendeskOperationSeq !== void 0 && (r.zendeskOperationSeq = t.zendeskOperationSeq), r;
}
var na = class {
        constructor(e) {
            A(this, "_deps", void 0), A(this, "_frames", /* @__PURE__ */ new Map()), A(this, "_channels", /* @__PURE__ */ new Map()), A(this, "_ready", /* @__PURE__ */ new Set()), A(this, "_loadTimers", /* @__PURE__ */ new Map()), A(this, "_pendingCommands", /* @__PURE__ */ new Map()), A(this, "_trackedCommands", /* @__PURE__ */ new Map()), A(this, "_trackedCommandTimers", /* @__PURE__ */ new Map()), A(this, "_settledCommandIds", /* @__PURE__ */ new Set()), A(this, "_commandCounter", 0), A(this, "_activePlatform", null), A(this, "_destroyed", !1), A(this, "_loadHandlers", /* @__PURE__ */ new Map()), this._deps = e;
        }
        dispatch(e) {
            let t = E(e);
            if (!t) return;
            let n = D(t.integration),
                r = D(t.action),
                i = E(t.payload) ? ? {};
            if (!n || !r) return;
            let a = {
                    integration: n,
                    action: qn(n, r),
                    payload: i,
                    commandId: D(t.commandId) ? ? `cmd_${Date.now()}_${++this._commandCounter}`
                },
                {
                    frameId: o,
                    nextActivePlatform: s
                } = Jn(a, this._activePlatform);
            if (this._activePlatform = s, Zi(n, a.action) || window.dispatchEvent(new CustomEvent("ada:integration:command", {
                    detail: a
                })), !o) {
                this._emitResult({
                    commandId: a.commandId,
                    integration: a.integration,
                    action: a.action,
                    status: "error",
                    error: {
                        code: "integration_not_available",
                        message: "No integration iframe was resolved for this command and platform context.",
                        details: {
                            platform: this._activePlatform ? ? void 0,
                            ...$i(a.payload ? ? {})
                        }
                    }
                });
                return;
            }
            this._trackCommand(o, a), this._ensureFrame(o), this._queueCommand(o, a), this._flush(o);
        }
        onFrameLoaded(e, t) {
            let n = t.contentWindow;
            if (!n) return;
            let r = this._deps.getFrameOrigin(t),
                i = new ii("sdk");
            i.connect(n, r ? ? void 0, `integration.${e}`), i.on("frame.origin.report", (t) => {
                let n = t.payload,
                    a = typeof n ? .origin == "string" ? n.origin : null;
                if (!(!a || a === "null")) {
                    if (r && a !== r) {
                        j.error(`Integration frame "${e}" reported unexpected origin "${a}" (expected "${r}")`);
                        return;
                    }
                    i.setTargetOrigin(a);
                }
            }), i.on("frame.error", (t) => {
                let n = t.payload;
                this._emitResult({
                    integration: e,
                    action: "frame.error",
                    status: "error",
                    error: {
                        code: "integration_frame_error",
                        message: typeof n ? .error == "string" ? n.error : "Integration frame reported an unknown error."
                    }
                });
            }), i.on("frame.ready", () => {
                this._ready.add(e), this._flush(e);
            }), i.on("integration.result", (t) => {
                this._handleResult(e, t.payload);
            }), i.on("integration.event", (t) => {
                this._handleEvent(e, t.payload);
            }), this._channels.set(e, i), this._deps.deliverConfig(i);
        }
        teardown() {
            this._destroyed = !0, this._clearRuntimeState("sdk_teardown", !1);
        }
        resetForIdentityChange() {
            this._clearRuntimeState("identity_reset", !0);
        }
        _clearRuntimeState(e, t) {
            for (let [t] of [...this._trackedCommands]) {
                let n = this._clearTracked(t);
                if (!n) continue;
                this._rememberSettledCommandId(t);
                let r = n.dispatched && ea(n);
                this._emitResult({
                    commandId: t,
                    integration: n.integration,
                    action: n.action,
                    status: "error",
                    error: {
                        code: r ? Ut : "integration_not_available",
                        message: r ? "The integration lifecycle ended before Zendesk returned a delivery receipt; delivery status is unknown." : "The integration lifecycle ended before the command completed.",
                        details: {
                            frameId: n.frameId,
                            dispatched: n.dispatched,
                            reason: e,
                            ...n.messageId ? {
                                messageId: n.messageId
                            } : {},
                            ...n.requestId ? {
                                requestId: n.requestId
                            } : {},
                            ...n.zendeskOperationSeq === void 0 ? {} : {
                                zendeskOperationSeq: n.zendeskOperationSeq
                            }
                        }
                    }
                });
            }
            for (let [e, t] of this._loadHandlers) e.removeEventListener("load", t);
            this._loadHandlers.clear();
            for (let [, e] of this._channels) e.disconnect();
            this._channels.clear();
            for (let [, e] of this._frames) e.remove();
            this._frames.clear(), this._ready.clear(), this._pendingCommands.clear(), this._trackedCommands.clear();
            for (let [, e] of this._trackedCommandTimers) clearTimeout(e);
            this._trackedCommandTimers.clear();
            for (let [, e] of this._loadTimers) clearTimeout(e);
            this._loadTimers.clear(), this._activePlatform = null, t || this._settledCommandIds.clear();
        }
        _ensureFrame(e) {
            this._frames.has(e) || this._mountFrame(e);
        }
        _mountFrame(e) {
            let t = document.createElement("iframe");
            t.src = this._deps.buildAssetUrl("integrations", Yi[e]), P(t, L), t.setAttribute("title", xi), t.setAttribute("data-ada-integration", e), t.setAttribute("allow", "clipboard-write"), t.setAttribute("sandbox", Xi[e]);
            let n = `integration:${e}`,
                r = setTimeout(() => {
                    this._loadTimers.delete(n);
                    let r = `Integration frame "${e}" failed to load within ${W}ms`;
                    j.warn(r), this._emitResult({
                        integration: "integration",
                        action: "frame.load",
                        status: "error",
                        error: {
                            code: "integration_frame_load_timeout",
                            message: r,
                            details: {
                                frameId: e
                            }
                        }
                    }), this._failPendingCommandsForFrame(e);
                    let i = this._loadHandlers.get(t);
                    i && (t.removeEventListener("load", i), this._loadHandlers.delete(t)), this._frames.get(e) === t && this._frames.delete(e), t.remove();
                }, W);
            this._loadTimers.set(n, r);
            let i = () => {
                if (this._loadHandlers.delete(t), this._destroyed) return;
                let r = this._loadTimers.get(n);
                r && (clearTimeout(r), this._loadTimers.delete(n)), this.onFrameLoaded(e, t);
            };
            this._loadHandlers.set(t, i), t.addEventListener("load", i, {
                once: !0
            }), this._frames.set(e, t), this._deps.container.appendChild(t);
        }
        _failPendingCommandsForFrame(e) {
            let t = this._pendingCommands.get(e) ? ? [];
            this._pendingCommands.set(e, []);
            for (let n of t) n.commandId && this._clearTracked(n.commandId), this._emitResult({
                commandId: n.commandId,
                integration: n.integration,
                action: n.action,
                status: "error",
                error: {
                    code: "integration_not_available",
                    message: "The integration frame did not become ready, so the command was not sent.",
                    details: {
                        frameId: e,
                        reason: "frame_load_timeout",
                        dispatched: !1,
                        ...$i(n.payload ? ? {})
                    }
                }
            });
        }
        _queueCommand(e, t) {
            let n = this._pendingCommands.get(e) ? ? [];
            if (n.length >= 64) {
                let t = n.shift();
                t && (t.commandId && this._clearTracked(t.commandId), this._emitResult({
                    commandId: t.commandId,
                    integration: t.integration,
                    action: t.action,
                    status: "error",
                    error: {
                        code: "integration_command_dropped",
                        message: "Integration command was dropped before frame readiness because the pending command buffer reached its limit.",
                        details: {
                            frameId: e,
                            bufferLimit: 64,
                            ...$i(t.payload ? ? {})
                        }
                    }
                }));
            }
            n.push(t), this._pendingCommands.set(e, n);
        }
        _removePending(e, t) {
            let n = this._pendingCommands.get(t);
            if (!n || n.length === 0) return;
            let r = n.filter((t) => t.commandId !== e);
            r.length !== n.length && this._pendingCommands.set(t, r);
        }
        _clearTracked(e) {
            let t = this._trackedCommands.get(e) ? ? null;
            this._trackedCommands.delete(e);
            let n = this._trackedCommandTimers.get(e);
            return n && clearTimeout(n), this._trackedCommandTimers.delete(e), t && this._removePending(e, t.frameId), t;
        }
        _rememberSettledCommandId(e) {
            if (this._settledCommandIds.size >= 256) {
                let e = this._settledCommandIds.values().next().value;
                e && this._settledCommandIds.delete(e);
            }
            this._settledCommandIds.add(e);
        }
        _trackCommand(e, t) {
            if (!t.commandId) return;
            let n = t.commandId;
            if (this._settledCommandIds.delete(n), this._trackedCommands.size >= 256) {
                let e = this._trackedCommands.entries().next().value;
                if (e) {
                    let [t, n] = e;
                    this._clearTracked(t), this._rememberSettledCommandId(t);
                    let r = n.dispatched && ea(n);
                    this._emitResult({
                        commandId: t,
                        integration: n.integration,
                        action: n.action,
                        status: "error",
                        error: {
                            code: r ? Ut : "integration_command_evicted",
                            message: r ? "Zendesk did not return a delivery receipt before command tracking capacity was exhausted; delivery status is unknown." : "Integration command tracking capacity was exceeded before a result was received.",
                            details: {
                                frameId: n.frameId,
                                bufferLimit: 256,
                                dispatched: n.dispatched,
                                ...n.messageId ? {
                                    messageId: n.messageId
                                } : {},
                                ...n.requestId ? {
                                    requestId: n.requestId
                                } : {},
                                ...n.zendeskOperationSeq === void 0 ? {} : {
                                    zendeskOperationSeq: n.zendeskOperationSeq
                                }
                            }
                        }
                    });
                }
            }
            let r = $i(t.payload ? ? {});
            this._trackedCommands.set(n, {
                frameId: e,
                integration: t.integration,
                action: t.action,
                dispatched: !1,
                ...r
            });
            let i = t.integration === "fileUpload" && (t.action === "upload.start" || t.action === "upload.retry") ? 12e4 : fi,
                a = setTimeout(() => {
                    let e = this._clearTracked(n);
                    if (!e) return;
                    this._rememberSettledCommandId(n);
                    let t = ea(e),
                        r = e.dispatched && t,
                        a = !e.dispatched && t,
                        o = "Integration command timed out before a result was received.";
                    r ? o = "Zendesk did not return a delivery receipt before the local command deadline; delivery status is unknown." : a && (o = "The integration frame never became ready, so the message was not sent."), this._emitResult({
                        commandId: n,
                        integration: "integration",
                        action: "result.timeout",
                        status: "error",
                        error: {
                            code: r ? Ut : "integration_command_timeout",
                            message: o,
                            details: {
                                frameId: e.frameId,
                                integration: e.integration,
                                action: e.action,
                                dispatched: e.dispatched,
                                timeoutMs: i,
                                ...e.messageId ? {
                                    messageId: e.messageId
                                } : {},
                                ...e.requestId ? {
                                    requestId: e.requestId
                                } : {},
                                ...e.zendeskOperationSeq === void 0 ? {} : {
                                    zendeskOperationSeq: e.zendeskOperationSeq
                                }
                            }
                        }
                    });
                }, i);
            this._trackedCommandTimers.set(n, a);
        }
        _flush(e) {
            if (!this._ready.has(e)) return;
            let t = this._channels.get(e);
            if (!t) return;
            let n = this._pendingCommands.get(e) ? ? [];
            if (n.length !== 0) {
                this._pendingCommands.set(e, []);
                for (let e of n)
                    if (t.send("integration.command", e), e.commandId) {
                        let t = this._trackedCommands.get(e.commandId);
                        t && (t.dispatched = !0);
                    }
            }
        }
        _handleResult(e, t) {
            let n = E(t);
            if (!n) return;
            let r = D(n.integration),
                i = D(n.action),
                a = D(n.status),
                o = D(n.commandId);
            if (!r || !i || a !== "success" && a !== "error") return;
            if (!o) {
                this._emitResult({
                    integration: "integration",
                    action: "result.validation",
                    status: "error",
                    error: {
                        code: "integration_result_missing_command_id",
                        message: "Integration result was ignored because it did not include a command id.",
                        details: {
                            frameId: e,
                            integration: r,
                            action: i
                        }
                    }
                });
                return;
            }
            let s = this._trackedCommands.get(o);
            if (!s) {
                if (this._settledCommandIds.has(o)) return;
                this._emitResult({
                    commandId: o,
                    integration: "integration",
                    action: "result.validation",
                    status: "error",
                    error: {
                        code: "integration_result_unsolicited",
                        message: "Integration result was ignored because no matching in-flight command was tracked.",
                        details: {
                            frameId: e,
                            integration: r,
                            action: i
                        }
                    }
                });
                return;
            }
            if (s.frameId !== e || s.integration !== r || s.action !== i) {
                this._emitResult({
                    commandId: o,
                    integration: "integration",
                    action: "result.validation",
                    status: "error",
                    error: {
                        code: "integration_result_mismatch",
                        message: "Integration result was ignored because it did not match the tracked command binding.",
                        details: {
                            frameId: e,
                            integration: r,
                            action: i,
                            expectedFrameId: s.frameId,
                            expectedIntegration: s.integration,
                            expectedAction: s.action
                        }
                    }
                });
                return;
            }
            let c = ea(s);
            this._clearTracked(o), c && this._rememberSettledCommandId(o);
            let l = E(n.data),
                u = c && (a === "success" || l) ? ta(l ? ? {}, s, "id") : l ? ? void 0,
                d = E(n.error),
                f = E(d ? .details),
                p = d || a === "error" && c ? {
                    code: D(d ? .code) ? ? "integration_error",
                    message: D(d ? .message) ? ? "Integration command failed.",
                    details: c ? ta(f ? ? {}, s, "messageId") : f ? ? void 0
                } : void 0;
            if (r === "csat" && xe(i) === "survey.submit" && a === "success" && u ? .submitted === !0 && D(u.conversationId)) {
                let e = _e(u.score),
                    t = Ce(e === null ? null : we(e, D(u.style)));
                this._deps.routePublishedEvent("ada:csat_submitted", {
                    conversation_id: u.conversationId,
                    ...t === void 0 ? {} : {
                        csat_score: t
                    }
                });
            }
            this._emitResult({
                commandId: o,
                integration: r,
                action: i,
                status: a,
                data: u,
                error: p
            });
        }
        _emitResult(e) {
            Qi(e) || window.dispatchEvent(new CustomEvent("ada:integration:result", {
                detail: e
            })), this._deps.sendToCore("sdk.integration.result", e);
        }
        _handleEvent(e, t) {
            let n = E(t);
            if (!n) return;
            let r = D(n.integration),
                i = D(n.event),
                a = n.source === "cross_tab_relay" ? "cross_tab_relay" : void 0;
            if (!r || !i) return;
            let o = {
                integration: r,
                event: i,
                payload: E(n.payload) ? ? void 0
            };
            r === "zendesk" && (i === "cross_tab.failure" || i === "cross_tab.fatal") || window.dispatchEvent(new CustomEvent("ada:integration:event", {
                detail: {
                    ...o,
                    frameId: e
                }
            })), this._deps.sendToCore("sdk.integration.event", {
                ...o,
                frameId: e,
                ...a ? {
                    source: a
                } : {}
            });
        }
        get _integrationPendingCommands() {
            return this._pendingCommands;
        }
        get _trackedIntegrationCommands() {
            return this._trackedCommands;
        }
    },
    ra = Symbol.for("ada.messaging.internalSessionMirrorGrant");

function ia() {
    return typeof window < "u" ? window : void 0;
}

function aa(e) {
    let t = ia();
    t && Reflect.set(t, ra, e);
}

function oa() {
    let e = ia();
    e && Reflect.deleteProperty(e, ra);
}

function sa() {
    let e = ia();
    if (!e) return null;
    let t = Reflect.get(e, ra);
    return Reflect.deleteProperty(e, ra), pe(e.location) ? t ? ? null : null;
}

function ca(e) {
    let t = null;
    for (let n of Object.keys(e)) n.startsWith("ada.sdk.internal.") && (t || = { ...e
    }, delete t[n]);
    return t ? ? e;
}
//#endregion
//#region src/client/legacy-callback-adapter.ts
var la = [{
            callbackProp: "adaReadyCallback",
            eventKey: "ada:start"
        },
        {
            callbackProp: "chatterTokenCallback",
            eventKey: "ada:chatter_token"
        },
        {
            callbackProp: "conversationEndCallback",
            eventKey: "ada:end_conversation"
        },
        {
            callbackProp: "toggleCallback",
            eventKey: "ada:toggle"
        },
        {
            callbackProp: "onAdaEmbedLoaded",
            eventKey: "ada:embed_loaded"
        },
        {
            callbackProp: "analyticsCallback",
            eventKey: "ada:analytics"
        }
    ],
    ua = new Set([
        "adaReadyCallback",
        "chatterTokenCallback",
        "toggleCallback"
    ]);

function da(e) {
    let {
        adaSettings: t,
        constructorEventCallbacks: n,
        subscribeEvent: r
    } = e, i = new Set(n ? Object.keys(n) : []), a = typeof window < "u" ? window : {};
    for (let {
            callbackProp: e,
            eventKey: n
        } of la) {
        if (i.has(n)) continue;
        let o = t[e];
        if (typeof o != "function") continue;
        let s = a[e];
        ua.has(e) && o === s || r(n, o);
    }
    let o = t.zdChatterAuthCallback;
    return {
        zdChatterAuthCallback: typeof o == "function" ? o : null,
        chatFrameTimeoutCallback: !i.has("ada:chat_frame_timeout") && typeof t.chatFrameTimeoutCallback == "function" ? t.chatFrameTimeoutCallback : null
    };
}
//#endregion
//#region src/client/mask-element.ts
var fa = "rgba(0, 0, 0, 0.16)",
    pa = 200,
    ma = `opacity ${pa}ms ease`,
    ha = `${ma}, visibility 0s linear ${pa}ms`;

function ga() {
    return typeof window > "u" || !window.matchMedia ? !1 : window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function _a(e) {
    let t = document.createElement("div");
    t.setAttribute("data-ada-mask", ""), t.id = "ada-drawer-mask-frame", t.setAttribute("aria-hidden", "true");
    let n = {
        position: "fixed",
        top: "0",
        right: "0",
        bottom: "0",
        left: "0",
        "background-color": fa,
        visibility: "hidden",
        opacity: "0",
        "pointer-events": "none",
        transition: ga() ? "none" : ha,
        "z-index": String(B.scrim),
        cursor: "pointer"
    };
    for (let [e, r] of Object.entries(n)) t.style.setProperty(e, r);
    let r = (t) => {
        t.stopPropagation(), e.onDismiss();
    };
    t.addEventListener("click", r);
    let i = (t) => {
        t.key === "Escape" && a && e.onDismiss();
    };
    e.container.appendChild(t), t.offsetWidth;
    let a = !1,
        o = !1;

    function s() {
        let e = o && !V();
        if (e === a) return;
        a = e;
        let n = ga();
        if (e) {
            t.style.transition = n ? "none" : ma, t.style.visibility = "visible", t.style.opacity = "1", t.style.pointerEvents = "auto";
            return;
        }
        t.style.transition = n ? "none" : ha, t.style.visibility = "hidden", t.style.opacity = "0", t.style.pointerEvents = "none";
    }
    return document.addEventListener("keydown", i), {
        setOpen(e) {
            o = e, s();
        },
        destroy() {
            t.removeEventListener("click", r), document.removeEventListener("keydown", i), t.remove();
        }
    };
}
//#endregion
//#region src/client/proactive/proactive-channel.ts
function va(e) {
    let t = () => {
        let t = e.frames.intro;
        t && P(t, L);
    };
    e.channel.on("intro.proactive.clicked", (n) => {
        let r = n.payload,
            i = typeof r ? .campaignKey == "string" ? r.campaignKey : null,
            a = Number(r ? .surfaceId),
            o = e.getCurrentIntroSurface ? .();
        !i || !Number.isSafeInteger(a) || o ? .kind !== "proactive" || o.campaignKey !== i || o.surfaceId !== a || (e.sendToCore("sdk.proactive.engaged", {
            campaignKey: i,
            surfaceId: a
        }), e.markIntroShown ? .(), t(), e.setIntroShowing(null), e.clearCurrentIntroSurface ? .(), e.openFromProactiveEngagement ? e.openFromProactiveEngagement() : e.open());
    }), e.channel.on("intro.proactive.shown", (t) => {
        let n = t.payload,
            r = typeof n ? .campaignKey == "string" ? n.campaignKey : null,
            i = Number(n ? .surfaceId);
        !r || !Number.isSafeInteger(i) || i <= 0 || !e.acknowledgeProactiveShown ? .(r, i) || (e.sendToCore("sdk.proactive.shown", {
            campaignKey: r,
            surfaceId: i
        }), e.routePublishedEvent("ada:campaigns:shown", {
            campaignKey: r
        }));
    }), e.channel.on("intro.resize", (t) => {
        let n = t.payload,
            r = Number(n ? .height),
            i = e.frames.intro;
        if (!i || !Number.isFinite(r) || r <= 0) return;
        let a = i.style.width;
        !a || a === "0px" || (i.style.height = `${r}px`, Vr(e.frames, e.getAlign()));
    }), e.channel.on("intro.proactive.cta.clicked", (t) => {
        let n = t.payload,
            r = typeof n ? .url == "string" ? n.url : null,
            i = Number(n ? .displayId),
            a = Number(n ? .surfaceId),
            o = e.getCurrentIntroSurface ? .(),
            s = n ? .kind === "greeting" && Number.isSafeInteger(i) && o ? .kind === "greeting" && o.displayId === i || n ? .kind === "proactive" && Number.isSafeInteger(a) && o ? .kind === "proactive" && o.surfaceId === a && n ? .campaignKey === o.campaignKey;
        if (!r || !s) return;
        let c = n ? .openInNewTab !== !1;
        e.openCtaUrl ? .(r, c);
    }), e.channel.on("intro.proactive.dismissed", (n) => {
        let r = n.payload,
            i = typeof r ? .campaignKey == "string" ? r.campaignKey : null,
            a = Number(r ? .surfaceId),
            o = e.getCurrentIntroSurface ? .();
        !i || !Number.isSafeInteger(a) || o ? .kind !== "proactive" || o.campaignKey !== i || o.surfaceId !== a || (e.sendToCore("sdk.proactive.dismissed", {
            campaignKey: i,
            surfaceId: a
        }), e.markIntroShown ? .(), t(), e.setIntroShowing(null), e.clearCurrentIntroSurface ? .(), e.clearShownCampaign ? .(), e.routePublishedEvent("ada:campaigns:dismissed", {
            campaignKey: i
        }));
    }), e.channel.on("intro.greeting.clicked", (n) => {
        let r = n.payload,
            i = Number(r ? .displayId),
            a = e.getCurrentIntroSurface ? .();
        if (!Number.isSafeInteger(i) || a ? .kind !== "greeting" || a.displayId !== i) return;
        let o = e.getStartupConfig() ? .intro;
        o ? .responseId && e.sendToCore("sdk.proactive.custom", {
            id: `greeting_${Date.now()}`,
            body: o.responseId,
            responseId: o.responseId
        }), t(), e.setIntroShowing(null), e.clearCurrentIntroSurface ? .(), e.open();
    }), e.channel.on("intro.greeting.dismissed", (n) => {
        let r = n.payload,
            i = Number(r ? .displayId),
            a = e.getCurrentIntroSurface ? .();
        !Number.isSafeInteger(i) || a ? .kind !== "greeting" || a.displayId !== i || (t(), e.setIntroShowing(null), e.clearCurrentIntroSurface ? .());
    }), e.channel.on("frame.error", () => {
        t(), e.setIntroShowing(null);
    });
}
//#endregion
//#region src/client/proactive/proactive-utils.ts
var ya = (e) => e.endsWith("/") ? e.slice(0, -1) : e,
    ba = /^http(s)?:\/\/(www.)?/,
    xa = 256,
    Sa = 128,
    Ca = 8,
    wa = /* @__PURE__ */ new Map(),
    Ta = "ada-functional-storage";

function Ea(e) {
    return e.trim().replace(ba, "");
}

function Da(e, t) {
    let n = 0,
        r = 0,
        i = -1,
        a = -1;
    for (; n < e.length;) {
        if (t[r] === e[n]) {
            n += 1, r += 1;
            continue;
        }
        if (t[r] === "*") {
            i = r, a = n, r += 1;
            continue;
        }
        if (i !== -1) {
            r = i + 1, a += 1, n = a;
            continue;
        }
        return !1;
    }
    for (; t[r] === "*";) r += 1;
    return r === t.length;
}

function Oa(e, t) {
    let n = ya(Ea(t)),
        r = ya(Ea(e));
    if (n.includes("?")) return !1;
    if (n.endsWith("/*")) {
        let e = n.slice(0, -2);
        return Da(r, e) || Da(r, `${e}/*`);
    }
    return Da(r, n);
}

function ka(e, t) {
    let n = e[t];
    if (n === "*" || n === "+") return {
        end: e[t + 1] === "?" ? t + 2 : t + 1,
        maximum: Infinity,
        repeats: !0,
        variable: !0
    };
    if (n === "?") return {
        end: e[t + 1] === "?" ? t + 2 : t + 1,
        maximum: 1,
        repeats: !1,
        variable: !0
    };
    if (n !== "{") return null;
    let r = e.slice(t).match(/^\{(\d+)(?:,(\d*)?)?\}(?:\?)?/);
    if (!r) return null;
    let i = Number(r[1]),
        a = r[2] === void 0 ? i : Number(r[2] || Infinity);
    return {
        end: t + r[0].length,
        maximum: a,
        repeats: a > 1,
        variable: a !== i
    };
}

function Aa(e) {
    let t = [{
            variableQuantifierCount: 0,
            hasRepeatingQuantifier: !1,
            hasVariableRepeatingQuantifier: !1,
            hasAlternation: !1,
            hasNestedGroup: !1
        }],
        n = 0,
        r = !1;
    for (let i = 0; i < e.length; i += 1) {
        let a = e[i];
        if (a === "\\") {
            i += 1;
            continue;
        }
        if (a === "[") {
            r = !0;
            continue;
        }
        if (a === "]" && r) {
            r = !1;
            continue;
        }
        if (r) continue;
        if (a === "(") {
            t[t.length - 1].hasNestedGroup = !0, t.push({
                variableQuantifierCount: 0,
                hasRepeatingQuantifier: !1,
                hasVariableRepeatingQuantifier: !1,
                hasAlternation: !1,
                hasNestedGroup: !1
            });
            continue;
        }
        if (a === "|") {
            t[t.length - 1].hasAlternation = !0;
            continue;
        }
        if (a === ")" && t.length > 1) {
            let r = t.pop();
            if (!r) continue;
            let a = ka(e, i + 1),
                o = t[t.length - 1];
            if (a) {
                let e = !a.variable && !r.hasRepeatingQuantifier && !r.hasAlternation && !r.hasNestedGroup;
                if (a.repeats && r.hasAlternation || a.repeats && r.variableQuantifierCount > 0 && !e) return !0;
                a.repeats && r.variableQuantifierCount > 0 && (n += (a.maximum - 1) * r.variableQuantifierCount), o.variableQuantifierCount += r.variableQuantifierCount + (a.variable ? 1 : 0), o.hasRepeatingQuantifier || = r.hasRepeatingQuantifier || a.repeats, o.hasVariableRepeatingQuantifier || = r.hasVariableRepeatingQuantifier || a.repeats && a.variable, o.hasAlternation || = r.hasAlternation, i = a.end - 1;
            } else o.variableQuantifierCount += r.variableQuantifierCount, o.hasRepeatingQuantifier || = r.hasRepeatingQuantifier, o.hasVariableRepeatingQuantifier || = r.hasVariableRepeatingQuantifier, o.hasAlternation || = r.hasAlternation;
            continue;
        }
        if (a === "?" && e[i - 1] === "(") continue;
        let o = ka(e, i);
        if (o) {
            let e = t[t.length - 1];
            e.variableQuantifierCount += o.variable ? 1 : 0, e.hasRepeatingQuantifier || = o.repeats, e.hasVariableRepeatingQuantifier || = o.repeats && o.variable, i = o.end - 1;
        }
    }
    let i = t[0];
    return n > 0 && (i.variableQuantifierCount + n > Ca || i.hasVariableRepeatingQuantifier || i.hasAlternation);
}

function ja(e) {
    if (wa.has(e)) return wa.get(e) ? ? null;
    let t = null,
        n = null;
    if (e.length > xa) n = `exceeds ${xa} characters`;
    else if (Aa(e)) n = "contains potentially unsafe repetition";
    else try {
        t = new RegExp(e);
    } catch {
        n = "has invalid syntax";
    }
    if (n && j.dataLoss(`proactive URL regex rejected: ${n}`), wa.size >= Sa) {
        let e = wa.keys().next().value;
        e !== void 0 && wa.delete(e);
    }
    return wa.set(e, t), t;
}

function Ma(e, t, n) {
    let r = n.split("?")[0];
    switch (e) {
        case "ends-with":
            return r.endsWith(t) || ya(r).endsWith(t);
        case "contains":
            return n.includes(t);
        case "equals":
            return Oa(r, t);
        case "regex":
            return ja(t) ? .test(n) ? ? !1;
        default:
            return !1;
    }
}

function Na(e, t, n, r) {
    if (t.is_template) return !1;
    let i = t.modality_config ? .chat;
    if (!i ? .active || !xt(i.schedule_start, i.schedule_end)) return !1;
    let a = i.url_trigger_conditions;
    if (!a ? .length || !a.some((e) => Ma(e.type, e.value, n))) return !1;
    let o = i.frequency ? ? "session";
    return !(o === "session" && qa(e, r) || o === "user" && Ya(e, r));
}

function Pa(e) {
    try {
        return e === "local" ? window.localStorage : window.sessionStorage;
    } catch {
        return null;
    }
}

function Fa(e, t, n) {
    if (!e) return [];
    let r = Object.entries(e).filter(([e, r]) => Na(e, r, t, n));
    if (r.length === 0) return [];
    if (!r.some(([, e]) => typeof e.order == "number")) {
        let [e, t] = r[r.length - 1];
        return [{
            key: e,
            entry: t
        }];
    }
    let i = Pa("local"),
        a = Wa(i, Ra(n), "proactive_conversations_shown", n),
        o = r.filter(([e]) => !a.has(e));
    if (o.length === 0) {
        let e = new Set(r.map(([e]) => e));
        for (let t of e) a.delete(t);
        Ga(i, Ra(n), "proactive_conversations_shown", n, a), o = r;
    }
    let [s, c] = [...o].sort(([, e], [, t]) => (e.order ? ? Infinity) - (t.order ? ? Infinity))[0];
    return [{
        key: s,
        entry: c
    }];
}

function Ia(e) {
    return `ada_proactive_seen_${e}`;
}

function La(e) {
    return `ada_proactive_seen_user_${e}`;
}

function Ra(e) {
    return `ada_proactive_ranked_seen_${e}`;
}

function za(e, t) {
    if (!e) return /* @__PURE__ */ new Set();
    try {
        let n = e.getItem(t);
        if (!n) return /* @__PURE__ */ new Set();
        let r = JSON.parse(n);
        return Array.isArray(r) ? new Set(r.filter((e) => typeof e == "string").map((e) => e.trim()).filter(Boolean)) : /* @__PURE__ */ new Set();
    } catch {
        return /* @__PURE__ */ new Set();
    }
}

function Ba(e) {
    return typeof e == "object" && !!e && !Array.isArray(e);
}

function Va(e, t, n) {
    if (!e) return /* @__PURE__ */ new Set();
    try {
        let r = e.getItem(Ta);
        if (!r) return /* @__PURE__ */ new Set();
        let i = JSON.parse(r);
        if (!Ba(i) || !Ba(i[t])) return /* @__PURE__ */ new Set();
        let a = i[t][n];
        return typeof a == "string" ? new Set(a.split(",").map((e) => e.trim()).filter(Boolean)) : /* @__PURE__ */ new Set();
    } catch {
        return /* @__PURE__ */ new Set();
    }
}

function Ha(e, t, n, r) {
    if (e) try {
        let i = e.getItem(Ta),
            a = i ? JSON.parse(i) : {};
        if (!Ba(a)) return;
        let o = a[t];
        if (o !== void 0 && !Ba(o)) return;
        e.setItem(Ta, JSON.stringify({
            ...a,
            [t]: {
                ...o ? ? {},
                [n] : [...r].join(",")
            }
        }));
    } catch {}
}

function Ua(e, t) {
    return e.size === t.size && [...e].every((e) => t.has(e));
}

function Wa(e, t, n, r) {
    let i = za(e, t),
        a = Va(e, n, r),
        o = new Set([...i, ...a]);
    return Ua(i, o) || Ka(e, t, o), Ua(a, o) || Ha(e, n, r, o), o;
}

function Ga(e, t, n, r, i) {
    Ka(e, t, i), Ha(e, n, r, i);
}

function Ka(e, t, n) {
    if (e) try {
        e.setItem(t, JSON.stringify([...n]));
    } catch {}
}

function qa(e, t) {
    return Wa(Pa("session"), Ia(t), "proactive_conversations_shown", t).has(e);
}

function Ja(e, t) {
    let n = Pa("session"),
        r = Wa(n, Ia(t), "proactive_conversations_shown", t);
    r.add(e), Ga(n, Ia(t), "proactive_conversations_shown", t, r);
}

function Ya(e, t) {
    return Wa(Pa("local"), La(t), "proactive_conversations_shown_user", t).has(e);
}

function Xa(e, t) {
    let n = Pa("local"),
        r = Wa(n, La(t), "proactive_conversations_shown_user", t);
    r.add(e), Ga(n, La(t), "proactive_conversations_shown_user", t, r);
}

function Za(e, t) {
    let n = Pa("local"),
        r = Wa(n, Ra(t), "proactive_conversations_shown", t);
    r.add(e), Ga(n, Ra(t), "proactive_conversations_shown", t, r);
}
//#endregion
//#region src/client/proactive/proactive-runtime.ts
function Qa(e, t, n) {
    let r = te(e);
    r && n(r, t ? "_blank" : "_self", "noopener,noreferrer");
}

function $a(e, t) {
    return e.endsWith("*") ? t.startsWith(e.slice(0, -1)) : t === e;
}

function eo(e, t) {
    if (!e.hasFloatingWidgetChrome || e.getHasChatOpened() || e.getHasIntroShown()) return;
    if (t.paths.length > 0) {
        let e = window.location.pathname;
        if (!t.paths.some((t) => $a(t, e))) return;
    }
    t.style !== "Emoji" && e.ensureIntroFrame();
    let n = e.getIntroTimer();
    n && clearTimeout(n);
    let r = (t.style === "Emoji" ? t.delay || 1 : t.delay ? ? 0) * 1e3;
    e.setIntroTimer(setTimeout(() => {
        if (e.setIntroTimer(null), !e.getIsChatOpen()) {
            if (t.style === "Emoji") {
                e.showOrQueueEmojiDisplay(() => {
                    if (e.getIsChatOpen() || e.getHasChatOpened()) return;
                    let n = e.channels.get("button");
                    n && (n.send("sdk.button.emoji.show", {
                        emojiUrl: t.body
                    }), e.setHasIntroShown(!0));
                });
                return;
            }
            e.showOrQueueIntroDisplay("greeting", () => {
                if (e.getIsChatOpen() || e.getHasChatOpened()) return;
                let n = e.channels.get("intro");
                if (!n) return;
                let r = e.beginGreetingDisplay();
                n.send("intro.greeting.show", {
                    body: t.body,
                    duration: t.duration ? ? null,
                    style: t.style,
                    displayId: r,
                    align: e.getAlign(),
                    ...t.image ? {
                        image: t.image
                    } : {},
                    ...t.cta ? {
                        cta: t.cta
                    } : {}
                }), Vr(e.frames, e.getAlign(), {
                    show: !0,
                    isParentElement: !!e.parentElement
                }), e.setIntroShowing("greeting"), e.setHasIntroShown(!0), e.markIntroShown();
            });
        }
    }, r));
}

function to(e) {
    if (e.retirePreChatSurface(), e.resetIntroShownForNavigation(), no(e, !1, !0)) return;
    let t = e.getStartupConfig(),
        n = t ? .intro;
    if (n && t.chatEnabled !== !1) {
        let t = window.location.pathname;
        (n.paths.length === 0 || n.paths.some((e) => $a(e, t))) && !e.getIsChatOpen() && eo(e, n);
    }
}

function no(e, t = !1, n = !1) {
    let r = e.getStartupConfig(),
        i = window.location.href,
        a = t || i !== e.getLastEvaluatedUrl(),
        o = e.getProactiveTimers();
    if (a) {
        for (let e of o) clearTimeout(e);
        o.clear();
    }
    if (!r || e.getIsChatOpen() || e.getHasChatOpened() || r.chatEnabled === !1 || !e.hasFloatingWidgetChrome || !a) return !1;
    e.setLastEvaluatedUrl(i);
    let s = Fa(r.proactiveConversations, i, e.handle);
    s.length > 0 && (n || e.retirePreChatSurface());
    for (let t of s) {
        let n = e.beginProactiveIntent(),
            r = t.entry.modality_config ? .chat ? .frequency ? ? "session";
        r === "user" ? Xa(t.key, e.handle) : r === "session" && Ja(t.key, e.handle), Za(t.key, e.handle);
        let i = (t.entry.modality_config ? .chat ? .delay ? ? 0) * 1e3,
            a = setTimeout(() => {
                o.delete(a), !(e.getIsChatOpen() || !e.isCurrentProactiveIntent(n)) && e.sendToCore("sdk.proactive.inject", {
                    key: t.key,
                    params: t.entry.params,
                    triggerMethod: "url",
                    intentId: n
                });
            }, i);
        o.add(a);
    }
    return s.length > 0;
}
//#endregion
//#region src/client/sdk-error-reporter.ts
var ro = (() => {
    try {
        return Ti(
            import.meta.url, "eb157faa62f6aedb4b1659a9563b247e78b9d989", "https://static.ada.support/messaging/");
    } catch {
        return null;
    }
})();

function io(e) {
    return ro !== null && e.startsWith(ro);
}

function ao(e) {
    return ro !== null && e.includes(ro);
}

function oo(e) {
    try {
        if (!(e instanceof Error) || e.name !== "AdaEmbedError") return !1;
        let t = "code" in e ? e.code : void 0;
        return typeof t == "string" && Yr.has(t);
    } catch {
        return !1;
    }
}

function so(e) {
    function t(t) {
        let n = t.error;
        if (oo(n)) return;
        let r = n instanceof Error ? n.stack ? ? "" : "";
        (t.filename ? !io(t.filename) : !ao(r)) || e("sdk.error.report", {
            message: n instanceof Error ? n.message : t.message || "Unknown SDK error",
            stack: r
        });
    }

    function n(t) {
        if (yr(t)) return;
        let n = t.reason;
        if (oo(n)) return;
        let r = n instanceof Error ? n.stack ? ? "" : "";
        !r || !ao(r) || e("sdk.error.report", {
            message: n instanceof Error ? n.message : "Unhandled promise rejection",
            stack: r
        });
    }

    function r(t) {
        let n = t.detail ? ? {},
            r;
        r = typeof n.message == "string" ? n.message : typeof n.type == "string" ? n.type : "ada:error event", e("sdk.error.report", {
            message: r,
            stack: "",
            adaErrorDetail: n
        });
    }
    return window.addEventListener("error", t), window.addEventListener("unhandledrejection", n), window.addEventListener("ada:error", r), () => {
        window.removeEventListener("error", t), window.removeEventListener("unhandledrejection", n), window.removeEventListener("ada:error", r);
    };
}
//#endregion
//#region src/client/sdk-event-bus.ts
var co = 5e3,
    lo = 10 * 6e4,
    uo = ni(),
    fo = 0,
    po = class {
        constructor() {
            A(this, "_eventSubscribers", /* @__PURE__ */ new Map()), A(this, "_nextSubscriberId", 0), A(this, "_infoRequestCallbacks", /* @__PURE__ */ new Map()), A(this, "_infoRequestTimers", /* @__PURE__ */ new Map()), A(this, "_infoRequestCounter", 0), A(this, "_activationWaitStartedAt", null), A(this, "_dataRequests", /* @__PURE__ */ new Map());
        }
        subscribe(e, t) {
            let n = ++this._nextSubscriberId;
            return this._eventSubscribers.set(n, {
                key: e,
                callback: t
            }), n;
        }
        subscribeAll(e) {
            let t = ++this._nextSubscriberId;
            return this._eventSubscribers.set(t, {
                key: "*",
                wildcard: !0,
                callback: e
            }), t;
        }
        unsubscribe(e) {
            this._eventSubscribers.delete(e);
        }
        routePublishedEvent(e, t) {
            Fi(this._eventSubscribers, e, t);
        }
        hasSubscribersFor(e) {
            for (let [, t] of this._eventSubscribers)
                if (Pi(t, e)) return !0;
            return !1;
        }
        hasExactSubscriberFor(e) {
            for (let [, t] of this._eventSubscribers)
                if (t.wildcard !== !0 && t.key === e) return !0;
            return !1;
        }
        requestInfo(e, t, n, r, i) {
            return new Promise((a) => {
                let o = `info_${++this._infoRequestCounter}`;
                this._infoRequestCallbacks.set(o, (e) => {
                    i ? .(o), a(e);
                });
                let s = () => {
                        let e = this._infoRequestCallbacks.get(o);
                        e && (this._infoRequestCallbacks.delete(o), this._infoRequestTimers.delete(o), e(t()));
                    },
                    c = n ? Lt : co,
                    l = Date.now() + c,
                    u = setTimeout(s, c);
                this._infoRequestTimers.set(o, u);
                try {
                    e("sdk.info.get", {
                        requestId: o
                    }, () => {
                        if (!this._infoRequestCallbacks.has(o)) return;
                        clearTimeout(this._infoRequestTimers.get(o));
                        let e = Date.now();
                        l = r ? Math.max(l, e + Rt) : e + co, this._infoRequestTimers.set(o, setTimeout(s, l - e));
                    });
                } catch {}
            });
        }
        get infoRequestCallbacks() {
            return this._infoRequestCallbacks;
        }
        get infoRequestTimers() {
            return this._infoRequestTimers;
        }
        requestData(e, t, n, r = {}) {
            let {
                requestId: i,
                promise: a
            } = this.registerAckRequest(n, r);
            try {
                e(t, {
                    requestId: i,
                    ...r.payload ? ? {}
                });
            } catch {}
            return a;
        }
        registerAckRequest(e, t = {}) {
            let n = `seqreq_${uo}_${++fo}`,
                r = t.timeoutMs ? ? co,
                i = Date.now(),
                a = Math.min(r, t.maxTotalMs ? ? r),
                o = new Promise((o, s) => {
                    this._dataRequests.set(n, {
                        resolve: o,
                        reject: s,
                        fallback: e,
                        timeoutErrorMessage: t.timeoutErrorMessage,
                        timer: setTimeout(() => this._settleOnTimeout(n), a),
                        timeoutMs: r,
                        ...t.reArmOnProgress ? {
                            reArmOnProgress: !0,
                            maxTotalMs: t.maxTotalMs
                        } : {
                            reArmOnProgress: !1
                        },
                        registeredAt: i,
                        suspendedMs: 0,
                        preserveForCoreReplacement: t.preserveForCoreReplacement === !0
                    });
                });
            return this._activationWaitStartedAt !== null && t.reArmOnProgress && this.reArmPendingRequests(), {
                requestId: n,
                promise: o
            };
        }
        settleUnconfirmed(e) {
            this._settleOnTimeout(e);
        }
        _settleOnTimeout(e) {
            let t = this._dataRequests.get(e);
            t && (clearTimeout(t.timer), this._dataRequests.delete(e), t.timeoutErrorMessage ? t.reject(Error(t.timeoutErrorMessage)) : t.resolve(t.fallback()));
        }
        setActivationWaitingForVisible(e) {
            if (e) this._activationWaitStartedAt ? ? = Date.now(), this.reArmPendingRequests();
            else if (this._activationWaitStartedAt !== null) {
                for (let e of this._dataRequests.values()) e.reArmOnProgress && (e.suspendedMs = Math.min(lo, e.suspendedMs + Math.max(0, Date.now() - Math.max(this._activationWaitStartedAt, e.registeredAt))));
                this._activationWaitStartedAt = null, this.reArmPendingRequests();
            }
        }
        reArmPendingRequests() {
            let e = this._activationWaitStartedAt !== null,
                t = Date.now();
            for (let [n, r] of this._dataRequests) {
                if (!r.reArmOnProgress) continue;
                clearTimeout(r.timer);
                let i = r.maxTotalMs + (e ? lo : r.suspendedMs) - (t - r.registeredAt);
                if (i <= 0) {
                    this._settleOnTimeout(n);
                    continue;
                }
                r.timer = setTimeout(() => this._settleOnTimeout(n), e ? i : Math.min(r.timeoutMs, i));
            }
        }
        resolveDataRequest(e, t) {
            let n = this._dataRequests.get(e);
            n && (clearTimeout(n.timer), this._dataRequests.delete(e), n.resolve(t));
        }
        rejectDataRequest(e, t) {
            let n = this._dataRequests.get(e);
            n && (clearTimeout(n.timer), this._dataRequests.delete(e), n.reject(Error(t)));
        }
        flushDataRequests(e = {}) {
            let t = Array.from(this._dataRequests.entries());
            for (let [n, r] of t) e.preserveForCoreReplacement === !0 && r.preserveForCoreReplacement || (this._dataRequests.delete(n), clearTimeout(r.timer), r.timeoutErrorMessage ? r.reject(Error(r.timeoutErrorMessage)) : r.resolve(r.fallback()));
        }
        flushInfoRequests(e) {
            for (let [, e] of this._infoRequestTimers) clearTimeout(e);
            this._infoRequestTimers.clear();
            for (let [, t] of this._infoRequestCallbacks) t(e);
            this._infoRequestCallbacks.clear();
        }
        teardown(e) {
            this._eventSubscribers.clear(), this.flushInfoRequests(e), this.flushDataRequests(), this._activationWaitStartedAt = null;
        }
    },
    mo = "ada:web_notification:click";

function ho(e) {
    return typeof e == "object" && !!e && "type" in e && e.type === mo;
}

function go(e) {
    if (typeof navigator > "u" || !("serviceWorker" in navigator) || !navigator.serviceWorker) return null;
    let t = navigator.serviceWorker;
    if (typeof t.addEventListener != "function" || typeof t.removeEventListener != "function") return null;
    let n = /* @__PURE__ */ new Set(),
        r = (t) => {
            if (!ho(t.data)) return;
            let r = setTimeout(() => {
                n.delete(r), e();
            }, 0);
            n.add(r);
        };
    return t.addEventListener("message", r), () => {
        t.removeEventListener("message", r);
        for (let e of n) clearTimeout(e);
        n.clear();
    };
}
//#endregion
//#region src/client/client.ts
var _o = "ProgrammaticControlNotEnabled: this API requires `start({ enableProgrammaticControl: true })`.",
    vo = O + 500,
    yo = 5e3,
    bo = 15e3,
    xo = "setComposerText timed out — chat frame did not respond in time.",
    So = "sendMessage timed out — chat frame did not respond in time.",
    Co = "Messaging supports only generative features; scripted/declarative campaigns and Answers are ignored.",
    wo = Symbol.for("ada.messaging.activeClientOwner"),
    To = "Ada Embed has already been started.";

function Eo(e) {
    let t = Reflect.get(window, wo);
    if (t !== void 0 && t !== e) throw new H(To, "start_owner_conflict");
    if (!Reflect.set(window, wo, e)) throw new H("Ada Embed could not claim the host page lifecycle.");
}

function Do(e) {
    Reflect.get(window, wo) === e && Reflect.deleteProperty(window, wo);
}
var Oo = class {
        get zdChatterAuthCallback() {
            return this._zdChatterAuthCallback;
        }
        get _channels() {
            return this._frameManager ? .channels ? ? /* @__PURE__ */ new Map();
        }
        get _frames() {
            return this._frameManager ? .frames ? ? {};
        }
        constructor(e) {
            A(this, "_config", void 0), A(this, "_assetRolloutCluster", void 0), A(this, "_hostMetaFieldsBaseline", {}), A(this, "_androidHostNavigation", !1), A(this, "_frameManager", null), A(this, "MAX_PENDING_MESSAGES", 64), A(this, "_pendingCoreMessages", []), A(this, "_pendingInfoMessages", /* @__PURE__ */ new Map()), A(this, "_eventBus", new po()), A(this, "_isInitialized", !1), A(this, "_warnedUndelegatedLoopbackAppUrl", !1), A(this, "_integrationManager", null), A(this, "_voiceManager", null), A(this, "_startupConfig", null), A(this, "_pendingHostProactive", null), A(this, "_lastOpenedViaKeyboard", !1), A(this, "_introTimer", null), A(this, "_proactiveTimers", /* @__PURE__ */ new Set()), A(this, "_programmaticProactiveTimer", null), A(this, "_activeProactiveSurfaceId", null), A(this, "_proactiveClearRequestSeq", 0), A(this, "_pendingProactiveClearRequestId", null), A(this, "_pendingIntroDisplay", null), A(this, "_introChannelReady", !1), A(this, "_introChannelSetupStarted", !1), A(this, "_introChannelFailed", !1), A(this, "_introChannelUnlockAttempts", 0), A(this, "_introChannelHandshakeTimer", null), A(this, "_introChannelDisplayTimer", null), A(this, "_pendingEmojiDisplay", null), A(this, "_proactiveIntentSeq", 0), A(this, "_currentProactiveIntentId", 0), A(this, "_introShowing", null), A(this, "_hasIntroShown", !1), A(this, "_wasIntroShown", !1), A(this, "_introShown", !1), A(this, "_runtimeMetaSyncScheduled", !1), A(this, "_runtimeMetaGeneration", 0), A(this, "_locationHistoryState", { ...Ii
            }), A(this, "_lastEvaluatedUrl", ""), A(this, "_cachedEndpoint", ""), A(this, "_unreadCount", 0), A(this, "_seededUnread", 0), A(this, "_seededUnreadToken", null), A(this, "_chatterToken", null), A(this, "_identitySessionChatterToken", null), A(this, "_identityTokenConsumedAwaitingChatter", !1), A(this, "_ignoredChatterAnnouncementToken", null), A(this, "_persistedChatterCandidate", null), A(this, "_coreReadyForCandidateDiscovery", !1), A(this, "_coreStartupFailed", !1), A(this, "_candidateDiscoveryBlockedForCore", !1), A(this, "_candidateDiscoveryRequestedForCore", !1), A(this, "_candidateDiscoveryGeneration", 0), A(this, "_scheduledCandidateDiscoveryGeneration", null), A(this, "_candidateDiscoveryRequestSeq", 0), A(this, "_pendingCandidateDiscoveryRequestId", null), A(this, "_candidateGeneration", 0), A(this, "_notificationStatusAbortController", null), A(this, "_notificationStatusTimeout", null), A(this, "_notificationStatusRequestSeq", 0), A(this, "_notificationStatusRequest", null), A(this, "_notificationStatusCache", null), A(this, "_sessionResumeRequestSeq", 0), A(this, "_pendingSessionResume", null), A(this, "_pendingSessionResumeVisibility", null), A(this, "_resumedChatterAwaitingAnnouncement", null), A(this, "_pendingCrossWindowDrawerRestore", !1), A(this, "_deviceToken", null), A(this, "_deviceOs", null), A(this, "_acknowledgedUnreadToken", null), A(this, "_pendingUnreadAcknowledgement", !1), A(this, "_isChatOpen", !1), A(this, "_runtimeGeneration", 0), A(this, "_resetGeneration", 0), A(this, "_visibilityGeneration", 0), A(this, "_endChatMinimizeTimer", null), A(this, "_pendingEndChatMinimizeSeq", null), A(this, "_lastEndedEndChatMinimizeSeq", null), A(this, "_heldEndChatEvent", null), A(this, "_endChatEventTimer", null), A(this, "_hasChatOpened", !1), A(this, "_hasExplicitlyEngaged", !1), A(this, "_nativeViewVisible", !1), A(this, "_nativeVisibilityReported", !1), A(this, "_sessionPreparationSent", !1), A(this, "_parentElement", null), A(this, "_parentElementResolved", !1), A(this, "_maskElement", null), A(this, "_hasActiveChatter", !1), A(this, "_hostSentSensitiveMetaFields", !1), A(this, "_hasPublishedEmbedLoaded", !1), A(this, "_registeredInternalEventCallbacks", /* @__PURE__ */ new Map()), A(this, "_crossWindowLiveChatActive", !1), A(this, "_cleanupErrorReporter", null), A(this, "MAX_PENDING_HOST_CALLBACK_ERRORS", 8), A(this, "_pendingHostCallbackErrors", []), A(this, "_hostCallbackErrorSink", (e, t) => {
                let n = this._channels.get("core");
                if (this._frameManager && n && (this._coreReadyForResetDelivery || this._historyPreservingResetAfterCoreReload === null)) {
                    n.send(e, t);
                    return;
                }
                this._pendingHostCallbackErrors.length >= this.MAX_PENDING_HOST_CALLBACK_ERRORS || this._pendingHostCallbackErrors.push({
                    type: e,
                    payload: t
                });
            }), A(this, "_cleanupCoreChannelHandlers", null), A(this, "_restoreStandaloneDocument", null), A(this, "_cleanupServiceWorkerNotificationClick", null), A(this, "_activationId", void 0), A(this, "_chatActivationDiagnosticSent", !1), A(this, "_startupClock", Bt({
                subscribeLifecycle: Vt(document, window)
            })), A(this, "_chatActivationEventTimer", null), A(this, "_chatFallbackTimer", null), A(this, "_chatFallbackArmedAt", null), A(this, "_chatFallbackElapsedBeforeWait", null), A(this, "_coreFrameReloadTimer", null), A(this, "_chatHideTimer", null), A(this, "_chatViewportCleanup", null), A(this, "_pageScrollLocked", !1), A(this, "_hostViewportRequested", !1), A(this, "_customAppFrameStyles", {}), A(this, "_customAppFrameFallback", !1), A(this, "_lastCustomFrameTransparentBackground", !1), A(this, "_hostViewportCleanup", null), A(this, "_lastHostViewport", void 0), A(this, "_hasCompletedActivation", !1), A(this, "_activationWorkObserved", !1), A(this, "_activationWaitingForVisible", !1), A(this, "_cleanupActivationVisibilityWait", null), A(this, "_showingTimeoutFallback", !1), A(this, "_handleFallbackMessage", (e) => {
                let t = this._frames.core;
                e.data === "ADA_FALLBACK_CLOSE" && e.origin === "null" && t ? .contentWindow && e.source === t.contentWindow && (window.removeEventListener("message", this._handleFallbackMessage), this.close());
            }), A(this, "_clearPersistenceOnNextCoreConfig", !1), A(this, "_historyPreservingResetAfterCoreReload", null), A(this, "_pendingClearAckRequestId", null), A(this, "_pendingClearAckResponseType", null), A(this, "_pendingClearPersistenceScope", null), A(this, "_resolvedPersistenceMode", null), A(this, "_coreReadyForResetDelivery", !1), A(this, "_pendingClearPersistenceModes", []), A(this, "_pendingClearOutgoingStorageMode", null), A(this, "_pendingDestructiveOps", []), A(this, "_greetingResponseIdOnNextCoreConfig", void 0), A(this, "_skipGreetingOnNextCoreConfig", !1), A(this, "_configuredGreetingResponseId", void 0), A(this, "_campaignShowSeq", 0), A(this, "_shownCampaign", null), A(this, "_openedCampaignSeq", 0), A(this, "_introSurfaceSeq", 0), A(this, "_currentIntroSurface", null), A(this, "_internalHostTelemetry", void 0), A(this, "_isStandaloneChatPage", !1), A(this, "_isChatHtmlPage", !1), A(this, "_isBotHostedChatPage", !1), A(this, "_nativeSessionMirror", !1), A(this, "_onIdentityTokenConsumed", void 0), A(this, "_isEmbedLoadedPublicationActive", void 0), A(this, "_chatFrameTimeoutCallback", null), A(this, "_zdChatterAuthCallback", null), A(this, "_delegate", {}), Eo(this);
            try {
                this._initializeClient(e);
            } catch (e) {
                try {
                    this._destroyRuntime();
                } catch (e) {
                    j.error("Failed to clean up partial SDK startup:", e);
                }
                throw Do(this), e;
            }
        }
        _initializeClient(e) {
            this._internalHostTelemetry = Yt(e), this._isStandaloneChatPage = Rn(e) && Bn(window.location.origin, this._sdkAssetsBase()), this._isChatHtmlPage = this._isStandaloneChatPage && zn(e), sa() && (this._nativeSessionMirror = !0);
            let t = e[Xn] === !0,
                n = t ? {} : Zn(),
                r = { ...e
                },
                i = gn(r.crossWindowPersistence);
            i === void 0 ? delete r.crossWindowPersistence : r.crossWindowPersistence = i, "styles" in r && (Hn("styles"), delete r.styles);
            let a = {
                ...n,
                ...r
            };
            if (this._onIdentityTokenConsumed = a.onIdentityTokenConsumed, this._isEmbedLoadedPublicationActive = a.isEmbedLoadedPublicationActive, this._setConfig(a), this._updateHostedChatPage(), this._config.branding !== void 0 && this._setConfig({
                    ...this._config,
                    branding: Gn(this._config.branding)
                }), this._captureHostMetaFieldsBaseline(a.metaFields), this._captureAndroidHostNavigation(a.metaFields), typeof this._config.greeting == "string" && this._config.greeting.trim()) {
                this._configuredGreetingResponseId = this._config.greeting.trim();
                let e = { ...this._config
                };
                delete e.greeting, this._setConfig(e);
            }
            a.eventCallbacks && this._registerInternalEventCallbacks(a.eventCallbacks);
            let o = !t && typeof window < "u" ? window.adaSettings ? ? {} : {};
            this._warnAboutLegacySettings({
                ...o,
                ...e
            }, e);
            let {
                zdChatterAuthCallback: s,
                chatFrameTimeoutCallback: c
            } = da({
                adaSettings: {
                    ...o,
                    ...e
                },
                constructorEventCallbacks: a.eventCallbacks,
                subscribeEvent: (e, t) => this._subscribeInternalEvent(e, t)
            });
            this._zdChatterAuthCallback = s, this._chatFrameTimeoutCallback = c, Object.defineProperty(this, Symbol.for("ada.messaging.nativeViewVisibility"), {
                value: (e) => this._reportNativeViewVisibility(e)
            }), br(this._hostCallbackErrorSink), this._config.lazy || this._init(), this._setupServiceWorkerNotificationClickHandler(), queueMicrotask(() => {
                this._isEmbedLoadedPublicationActive ? .() !== !1 && this._publishEmbedLoaded();
            });
        }
        open() {
            this._parentElement && this._isInitialized && !this._showingTimeoutFallback || this._openChat();
        }
        _openFromProactiveEngagement() {
            this._openChat({
                preserveProactiveEngagement: !0
            });
        }
        _openChat({
            preserveProactiveEngagement: e = !1,
            markExplicitEngagement: t = !0,
            confirmedRestoredVisibility: n = !1
        } = {}) {
            if (this._config.lazy && !this._isInitialized && this._init(), this._isHeadless || (this._cancelEndChatMinimize(), !this._showingTimeoutFallback && !this._parentElement && this._isChatOpen)) return;
            if (t && this._beginExplicitEngagement(), this._currentIntroSurface ? .kind === "proactive" && this._markProactiveIntroShown(), this._retirePreChatSurface(e ? {
                    notifyCore: !1,
                    preserveShownCampaign: !0
                } : {
                    preserveShownCampaign: !0
                }), this._showingTimeoutFallback && (this._reloadCoreFrame(), this._waitsForEngagement)) {
                this._parentElement && this._showEmbeddedChat(), this._requestActivationAfterCoreReload({
                    forceActivate: !0
                });
                return;
            }
            if (this._parentElement) {
                this._showEmbeddedChat(), this._sendToCore("sdk.activate", void 0);
                return;
            }
            this._isChatOpen = !0, this._visibilityGeneration += 1, this._hasChatOpened = !0, t && this._activationWorkObserved && this._startChatActivationTimeouts(), this._clearUnreadCount(), n || this._sendToCore("sdk.visibility.set", {
                isVisible: !0
            });
            let r = this._frames.core;
            if (r) {
                let e = !!this._parentElement,
                    t = V();
                this._clearChatHideTimer(), r.offsetHeight, P(r, this._hostViewportRequested ? Rr() : Lr(this._align, e, t, !Nr(), this._customFrameStylesApply() ? this._customAppFrameStyles : void 0)), this._syncChatViewportHeight(r);
            }
            this._syncCustomFrameStylesApplied(), this._syncPageScrollLock(), this._maskElement ? .setOpen(!0);
            let i = this._frames.button;
            i && (i.style.opacity = "0", i.style.pointerEvents = "none", cr(i, !0), this._lastOpenedViaKeyboard && r && r.focus({
                preventScroll: !0
            })), this._introTimer && = (clearTimeout(this._introTimer), null);
            for (let e of this._proactiveTimers) clearTimeout(e);
            this._proactiveTimers.clear();
            let a = this._frames.intro;
            a && (this._introShowing === "greeting" && this._channels.get("intro") ? .send("intro.greeting.hide", void 0), this._channels.get("intro") ? .send("intro.proactive.clear", void 0), P(a, L)), this._introShowing = null, this._persistCrossWindowDrawerState(), this._invokeWindowCallback("toggleCallback", !0), this._routePublishedEvent("ada:toggle", !0), this._publishShownCampaignOpened();
        }
        _clearEndChatMinimizeTimer() {
            this._endChatMinimizeTimer !== null && (clearTimeout(this._endChatMinimizeTimer), this._endChatMinimizeTimer = null);
        }
        _clearEndChatEventTimer() {
            this._endChatEventTimer !== null && (clearTimeout(this._endChatEventTimer), this._endChatEventTimer = null);
        }
        _resolveHeldEndChatEventPayload(e) {
            if (!e.payloadResolved) {
                if (e.resetGeneration !== this._resetGeneration) {
                    let t = E(e.data),
                        n = E(t ? .event_data) ? .event_name;
                    e.data = {
                        ...typeof t ? .chatter_id == "string" ? {
                            chatter_id: t.chatter_id
                        } : {},
                        event_data : {
                            event_name: typeof n == "string" ? n : "END_CONVERSATION"
                        }
                    };
                }
                e.payloadResolved = !0;
            }
        }
        _deliverHeldEndChatEvent() {
            let e = this._heldEndChatEvent;
            this._heldEndChatEvent = null, this._clearEndChatEventTimer(), e && (this._resolveHeldEndChatEventPayload(e), this._routePublishedEvent("ada:end_conversation", e.data));
        }
        _deliverHeldEndChatEventAfterCall(e) {
            this._clearEndChatEventTimer(), queueMicrotask(() => {
                this._heldEndChatEvent === e && this._deliverHeldEndChatEvent();
            });
        }
        _holdEndChatEvent(e, t) {
            let n = this._runtimeGeneration;
            if (this._deliverHeldEndChatEvent(), this._runtimeGeneration === n) {
                if (t === this._lastEndedEndChatMinimizeSeq || !this._isInitialized || this._parentElement || this._isHeadless || !this._isChatOpen) {
                    this._routePublishedEvent("ada:end_conversation", e);
                    return;
                }
                this._heldEndChatEvent = {
                    data: e,
                    payloadResolved: !1,
                    resetGeneration: this._resetGeneration,
                    endChatSeq: t
                }, this._endChatEventTimer = setTimeout(() => this._deliverHeldEndChatEvent(), vo);
            }
        }
        _cancelEndChatMinimize() {
            let e = this._pendingEndChatMinimizeSeq;
            this._pendingEndChatMinimizeSeq = null, this._clearEndChatMinimizeTimer(), e !== null && (this._lastEndedEndChatMinimizeSeq = e);
            let t = this._heldEndChatEvent;
            t && t.endChatSeq === e && this._deliverHeldEndChatEventAfterCall(t);
        }
        _minimizeAfterThanks(e) {
            this._cancelEndChatMinimize();
            let t = () => {
                this._heldEndChatEvent && this._heldEndChatEvent.endChatSeq === e && this._deliverHeldEndChatEvent();
            };
            if (!this._isInitialized || this._parentElement || this._isHeadless || !this._isChatOpen) {
                e !== null && (this._lastEndedEndChatMinimizeSeq = e), t();
                return;
            }
            this._pendingEndChatMinimizeSeq = e;
            let n = this._visibilityGeneration,
                r = this._runtimeGeneration;
            this._endChatMinimizeTimer = setTimeout(() => {
                this._endChatMinimizeTimer = null, this._pendingEndChatMinimizeSeq = null, e !== null && (this._lastEndedEndChatMinimizeSeq = e);
                try {
                    if (this._isChatOpen && this._visibilityGeneration === n) {
                        let t = this._heldEndChatEvent;
                        t && t.endChatSeq === e && this._resolveHeldEndChatEventPayload(t), this._channels.get("button") ? .send("sdk.button.focus", void 0), this.close();
                    }
                } finally {
                    this._runtimeGeneration === r && t();
                }
            }, O), this._heldEndChatEvent ? .endChatSeq === e && this._clearEndChatEventTimer();
        }
        close(e) {
            if (this._isHeadless || this._parentElement || !this._isChatOpen) return;
            this._isChatOpen = !1, this._visibilityGeneration += 1, this._cancelEndChatMinimize(), this._lastEvaluatedUrl = "", this._clearChatActivationTimeouts(!1), this._chatActivationDiagnosticSent = !1, this._chatFallbackArmedAt = null, this._chatFallbackElapsedBeforeWait = null, this._startupClock.stop(), this._sendToCore("sdk.visibility.set", {
                isVisible: !1,
                ...e ? {
                    reason: e
                } : {}
            });
            let t = this._frames.core;
            t && (this._clearChatHideTimer(), Nr() ? P(t, jr) : this._startChatCloseAnimation(t)), this._stopChatViewportHeightSync(), this._syncCustomFrameStylesApplied(), this._syncPageScrollLock(), this._maskElement ? .setOpen(!1);
            let n = this._frames.button;
            if (n) {
                let e = or(n);
                e && (n.style.opacity = "1"), n.style.pointerEvents = "", cr(n, !e);
            }
            this._lastOpenedViaKeyboard && (this._lastOpenedViaKeyboard = !1, this._channels.get("button") ? .send("sdk.button.focus", void 0)), this._persistCrossWindowDrawerState(), this._invokeWindowCallback("toggleCallback", !1), this._routePublishedEvent("ada:toggle", !1);
        }
        reset(e) {
            let t = mn(e ? .identityToken);
            (e ? .resetChatHistory !== !1 || t) && (this._resetGeneration += 1), this._cancelEndChatMinimize(), this._isLegacyLoader && e && "activeModality" in e && Wn("reset.activeModality"), this._setHostViewportExpanded(!1);
            let n = e ? {
                ...e,
                ...e.metaFields ? {
                    metaFields: N(M(e.metaFields))
                } : {},
                ...e.sensitiveMetaFields ? {
                    sensitiveMetaFields: N(M(e.sensitiveMetaFields), {
                        sensitive: !0
                    })
                } : {}
            } : void 0;
            this._config.skipGreeting === !0 && (n = {
                ...n,
                skipGreeting: !0
            }), n && Object.assign(n, {
                metaFieldCounts: An(n.metaFields, n.sensitiveMetaFields)
            });
            let r = this._outgoingPersistenceMode(),
                i = () => this._registerDurableClearAck("core.reset.response", {
                    persistenceMode: r
                }),
                a = this._hasExplicitlyEngaged || !this._waitsForEngagement && !!this._parentElement;
            this._discardPersistedChatterCandidate(), this._historyPreservingResetAfterCoreReload = null, this._configuredGreetingResponseId = typeof n ? .greeting == "string" && n.greeting.trim() ? n.greeting.trim() : void 0;
            let o = n ? .resetChatHistory === !1 && !t,
                s = null;
            o && (s = this._identityTokenConsumedAwaitingChatter ? this._identitySessionChatterToken : this._chatterToken ? ? this._identitySessionChatterToken);
            let c = !!(s && this._identitySessionChatterToken === s);
            if (n ? .resetChatHistory !== !1 && !t && this._clearIdentityToken(), this._applyResetOverridesToConfig(t ? {
                    ...n,
                    identityToken: t
                } : n, {
                    historyPreserving: o
                }), t && this._integrationManager ? .resetForIdentityChange(), this._showingTimeoutFallback) {
                if (o) {
                    this._abandonDurableClearIntent();
                    let {
                        requestId: e,
                        promise: t
                    } = this._registerDestructiveAck("reconfigure");
                    return this._historyPreservingResetAfterCoreReload = {
                        params: {
                            ...n,
                            ...n ? .metaFields ? {
                                metaFields: { ...n.metaFields
                                }
                            } : {},
                            ...n ? .sensitiveMetaFields ? {
                                sensitiveMetaFields: { ...n.sensitiveMetaFields
                                }
                            } : {}
                        },
                        requestId: e,
                        expectedChatterToken: s,
                        expectedIdentitySession: c,
                        reactivate: this._hasExplicitlyEngaged,
                        persistenceScope: this._persistenceScopeKey()
                    }, this._prepareForSessionReset({
                        keepChatter: !0
                    }), this._reloadCoreFrame(), t;
                }
                let {
                    promise: e
                } = i();
                return this._reloadCoreFrame(), this._clearCrossWindowPersistenceState(), this._prepareForSessionReset(), this._requestActivationAfterCoreReload({
                    forceActivate: !!t && a
                }), e;
            }
            if (t) {
                if (this._clearCrossWindowPersistenceState(), this._prepareForSessionReset(), this._hasNoFrameToAck()) {
                    this._invalidateStartupConfigForCoreReplacement();
                    let {
                        promise: e
                    } = i();
                    return this._ensurePublicCoreFrameForDestructiveClear(), e;
                }
                let {
                    promise: e
                } = i();
                return this._channels.has("core") && this._reloadCoreFrame(), this._requestActivationAfterCoreReload({
                    forceActivate: a
                }), e;
            }
            if (this._clearCrossWindowPersistenceState(), this._prepareForSessionReset({
                    keepChatter: n ? .resetChatHistory === !1
                }), this._hasNoFrameToAck()) {
                if (n ? .resetChatHistory === !1) return Promise.resolve();
                let {
                    promise: e
                } = i();
                return this._ensurePublicCoreFrameForDestructiveClear(), e;
            }
            let l = n ? .resetChatHistory === !1,
                {
                    requestId: u,
                    promise: d
                } = l ? this._registerDestructiveAck("reconfigure") : i();
            if (l) this._historyPreservingResetAfterCoreReload = {
                params: {
                    ...n,
                    ...n ? .metaFields ? {
                        metaFields: { ...n.metaFields
                        }
                    } : {},
                    ...n ? .sensitiveMetaFields ? {
                        sensitiveMetaFields: { ...n.sensitiveMetaFields
                        }
                    } : {}
                },
                requestId: u,
                expectedChatterToken: s,
                expectedIdentitySession: c,
                reactivate: this._hasExplicitlyEngaged,
                persistenceScope: this._persistenceScopeKey()
            }, this._sendPendingHistoryPreservingReset();
            else {
                if (this._hasReadyCoreChannel()) {
                    let e = this._channels.get("core");
                    e && (this._skipGreetingOnNextCoreConfig = !1, e.send("sdk.reset", {
                        ...n,
                        requestId: u
                    }), this._sendAuthoritativeRuntimeMeta(e));
                } else this._reloadCoreFrame();
                this._isChatVisible() && this._sendToCore("sdk.visibility.set", {
                    isVisible: !this._waitsForEngagement || this._nativeViewVisible
                });
            }
            return d;
        }
        _registerDestructiveAck(e, t = {}) {
            let n = "",
                r = this._eventBus.registerAckRequest(() => {
                    this._pruneDestructiveOp(n), e === "reconfigure" && this._historyPreservingResetAfterCoreReload ? .requestId === n && (this._historyPreservingResetAfterCoreReload = null);
                }, {
                    timeoutMs: pi,
                    reArmOnProgress: !0,
                    maxTotalMs: mi,
                    preserveForCoreReplacement: !0
                });
            return n = r.requestId, this._pendingDestructiveOps.push({
                requestId: n,
                kind: e,
                ...t
            }), r;
        }
        _registerDurableClearAck(e, t = {}) {
            let n = this._persistenceScopeKey(),
                r = t.persistenceMode ? ? this._resolvedPersistenceMode ? ? void 0,
                i = r === "private" || this._isPrivateMode ? ["private"] : ["normal", "session"],
                a = this._pendingClearPersistenceScope === n ? this._pendingClearPersistenceModes : [],
                o = this._pendingClearPersistenceScope === n && this._pendingClearOutgoingStorageMode === "normal" ? "normal" : r ? ? null,
                s = this._clearPersistenceOnNextCoreConfig && this._pendingClearPersistenceScope === n && a.length === 0 ? [] : [...new Set([...a, ...i])],
                c = this._registerDestructiveAck("clear", {
                    persistenceScope: n,
                    ...s.length > 0 ? {
                        persistenceModes: s
                    } : {}
                }),
                {
                    requestId: l
                } = c;
            return this._clearPersistenceOnNextCoreConfig = !0, this._pendingClearAckRequestId = l, this._pendingClearAckResponseType = e, this._pendingClearPersistenceScope = n, this._pendingClearPersistenceModes = s, this._pendingClearOutgoingStorageMode = o, c;
        }
        _acknowledgeDurableClearIntent(e) {
            e === this._pendingClearAckRequestId && this._clearDurableClearIntent();
        }
        _clearDurableClearIntent() {
            this._clearPersistenceOnNextCoreConfig = !1, this._pendingClearAckRequestId = null, this._pendingClearAckResponseType = null, this._pendingClearPersistenceScope = null, this._pendingClearPersistenceModes = [], this._pendingClearOutgoingStorageMode = null;
        }
        _abandonDurableClearIntent() {
            let e = this._pendingClearAckRequestId;
            this._clearDurableClearIntent(), e && (this._pruneDestructiveOp(e), this._eventBus.settleUnconfirmed(e));
        }
        get _isPrivateMode() {
            return this._config.privateMode === !0;
        }
        _persistenceScopeKey() {
            return JSON.stringify({
                handle: this._config.handle,
                endpoint: this._cachedEndpoint,
                privateMode: this._isPrivateMode,
                headless: this._isHeadless
            });
        }
        _outgoingPersistenceMode() {
            if (this._isPrivateMode) return "private";
            if (this._resolvedPersistenceMode) return this._resolvedPersistenceMode;
            if (this._config.identityToken || this._chatterToken && this._identitySessionChatterToken === this._chatterToken || this._identityTokenConsumedAwaitingChatter) return "session";
            if (!this._chatterToken && this._clearPersistenceOnNextCoreConfig && this._pendingClearPersistenceScope === this._persistenceScopeKey()) return this._pendingClearPersistenceModes.length === 1 ? this._pendingClearPersistenceModes[0] : void 0;
        }
        _abandonDestructiveWorkForPersistenceScopeChange() {
            this._historyPreservingResetAfterCoreReload = null, this._clearDurableClearIntent(), this._pendingDestructiveOps = [], this._greetingResponseIdOnNextCoreConfig = void 0, this._skipGreetingOnNextCoreConfig = !1, this._resolvedPersistenceMode = null, this._prepareForSessionReset();
        }
        _hasNoFrameToAck() {
            return !this._isInitialized && !this._channels.has("core");
        }
        _hasReadyCoreChannel() {
            return this._coreReadyForResetDelivery && this._channels.has("core");
        }
        _warnAboutLegacySettings(e, t) {
            this._isLegacyLoader && ("preload" in e && Wn("preload"), "embedStyles" in t && Wn("embedStyles"));
        }
        get _isLegacyLoader() {
            return this._internalHostTelemetry ? .surface === "browser" && this._internalHostTelemetry.webSdkOrigin === "legacy";
        }
        _createContainer(e = null) {
            let t = document.createElement("div");
            return t.id = "ada-entry", (e ? ? document.body).appendChild(t), t;
        }
        _ensurePublicCoreFrameForDestructiveClear() {
            if (this._frames.core) return;
            let e = this._frameManager;
            if (!e) {
                let t = this._createContainer();
                e = this._createFrameManager(t), this._frameManager = e;
            }
            e.mountFrame("core", {
                style: jr,
                additionalAllow: vn(this._config.appUrl)
            });
        }
        _pruneDestructiveOp(e) {
            this._pendingDestructiveOps = this._pendingDestructiveOps.filter((t) => t.requestId !== e);
        }
        _settleDestructiveOpFamily(e, t) {
            let n = this._pendingDestructiveOps.findIndex((t) => t.requestId === e);
            if (n === -1) return;
            let r = this._pendingDestructiveOps[n],
                i = r ? .kind;
            if (i !== "clear") {
                this._pruneDestructiveOp(e);
                return;
            }
            let a = r ? .persistenceModes,
                o = r ? .persistenceScope && a ? .length ? this._pendingDestructiveOps.slice(0, n + 1).filter((e) => e.kind === i && e.persistenceScope === r ? .persistenceScope && !!e.persistenceModes ? .length && e.persistenceModes ? .every((e) => a ? .includes(e))) : [r],
                s = new Set(o.map((e) => e ? .requestId));
            this._pendingDestructiveOps = this._pendingDestructiveOps.filter((e) => !s.has(e.requestId));
            for (let n of o) n && n.requestId !== e && n.kind === i && this._eventBus.resolveDataRequest(n.requestId, t);
        }
        toggle() {
            if (this._config.parentElement) throw new H("Cannot toggle when using parentElement.");
            this._isHeadless || (this._isChatOpen ? this.close() : this.open());
        }
        getInfo() {
            return this._coreStartupFailed ? Promise.resolve(this._getWindowInfo()) : this._eventBus.requestInfo((e, t, n) => this._sendToCore(e, t, !1, n), () => this._getWindowInfo(), this._hasFloatingWidgetChrome, this._isHeadless || !this._config.parentElement, (e) => this._pendingInfoMessages.delete(e));
        }
        isOpen() {
            return Promise.resolve(this._isNativeViewVisible());
        }
        getMetaFields() {
            return this._eventBus.requestData((e, t) => this._sendToCore(e, t), "sdk.metaFields.get", () => ({}));
        }
        async getConversation() {
            return this._requireProgrammaticControl(), this._eventBus.requestData((e, t) => this._sendToCore(e, t), "sdk.conversation.get", () => ({
                id: null,
                handoff: {
                    inLiveChat: !1
                }
            }), {
                timeoutErrorMessage: "getConversation timed out — chat frame did not respond in time."
            });
        }
        async getMessages() {
            return this._requireProgrammaticControl(), this._eventBus.requestData((e, t) => this._sendToCore(e, t), "sdk.messages.get", () => [], {
                timeoutErrorMessage: "getMessages timed out — chat frame did not respond in time."
            });
        }
        async setComposerText(e) {
            if (this._requireProgrammaticControl(), this._isHeadless) throw Error("HeadlessModeError: setComposerText is not available in headless mode");
            return this._eventBus.requestData((e, t) => this._sendToCore(e, t), "sdk.composerText.set", () => ({
                ok: !0
            }), {
                timeoutErrorMessage: xo,
                payload: {
                    text: e
                }
            }).then(() => void 0);
        }
        setDelegate(e) {
            this._requireProgrammaticControl(), this._delegate = e ? ? {};
        }
        async _applyBeforeSend(e) {
            let t = this._delegate.beforeSend;
            if (!t) return e;
            let n = await new Promise((n, r) => {
                let i = setTimeout(() => {
                    r( /* @__PURE__ */ Error("DelegateTimeout"));
                }, yo);
                Promise.resolve().then(() => t({
                    text: e
                })).then((e) => {
                    clearTimeout(i), n(e);
                }).catch((e) => {
                    clearTimeout(i), r(e);
                });
            });
            if (n === !1) throw Error("DelegateRejected");
            if (!n || typeof n != "object" || typeof n.text != "string") throw Error("Delegate beforeSend must return `{ text: string }`, `false`, or a Promise resolving to one of these.");
            if (n.text.trim().length === 0) throw Error("sendMessage requires non-empty text after delegate transform");
            return n.text;
        }
        deleteHistory() {
            this._resetGeneration += 1, this._setHostViewportExpanded(!1);
            let e = this._outgoingPersistenceMode(),
                t = () => this._registerDurableClearAck("core.history.delete.response", {
                    persistenceMode: e
                });
            if (this._historyPreservingResetAfterCoreReload = null, this._clearIdentityToken(), this._applyResetOverridesToConfig(), this._showingTimeoutFallback) {
                let {
                    promise: e
                } = t();
                return this._reloadCoreFrame(), this._clearCrossWindowPersistenceState(), this._prepareForSessionReset(), this._requestActivationAfterCoreReload(), e;
            }
            if (this._clearCrossWindowPersistenceState(), this._prepareForSessionReset(), this._hasNoFrameToAck()) {
                let {
                    promise: e
                } = t();
                return this._ensurePublicCoreFrameForDestructiveClear(), e;
            }
            let {
                requestId: n,
                promise: r
            } = t();
            if (this._hasReadyCoreChannel()) {
                let e = this._channels.get("core");
                e && (e.send("sdk.history.delete", {
                    requestId: n,
                    ...this._config.skipGreeting === !0 ? {
                        skipGreeting: !0
                    } : {}
                }), this._sendAuthoritativeRuntimeMeta(e));
            } else this._reloadCoreFrame();
            return this._isChatVisible() && this._sendToCore("sdk.visibility.set", {
                isVisible: !this._waitsForEngagement || this._nativeViewVisible
            }), r;
        }
        setLanguage(e) {
            this._sendToCore("sdk.language.set", {
                language: e
            });
        }
        setTheme(e) {
            this._sendToCore("sdk.theme.set", {
                theme: e
            });
        }
        setMetaFields(e) {
            if (e == null) {
                j.dataLoss("setMetaFields() ignored: value is not a meta-field object; use reset() to clear history and create a new end user");
                return;
            }
            let t = N(M(e)),
                n = An(t);
            if (Object.keys(t).length === 0) {
                n.some(({
                    dropped: e
                }) => e > 0) && this._sendToCore("sdk.metaFields.set", {
                    metaFields: t,
                    metaFieldCounts: n
                });
                return;
            }
            this._retainMetaFields(t), this._sendToCore("sdk.metaFields.set", {
                metaFields: t,
                metaFieldCounts: n
            });
        }
        _retainMetaFields(e) {
            this._setConfig({
                ...this._config,
                metaFields: {
                    ...this._config.metaFields,
                    ...e
                }
            });
        }
        setTestModeBanner(e) {
            this._sendToCore("sdk.testModeBanner.set", {
                label: e
            });
        }
        setSensitiveMetaFields(e) {
            if (e == null) {
                j.dataLoss("setSensitiveMetaFields() ignored: value is not a meta-field object; use reset() to clear history and create a new end user");
                return;
            }
            this._sendSensitiveMetaFieldsToCore(e, !0) === "sent" && (this._hostSentSensitiveMetaFields = !0);
        }
        _sendSensitiveMetaFieldsToCore(e, t) {
            let n = N(M(e), {
                    sensitive: !0
                }),
                r = An(n);
            return Object.keys(n).length === 0 ? (r.some(({
                dropped: e
            }) => e > 0) && this._sendToCore("sdk.sensitiveMetaFields.set", {
                sensitiveMetaFields: n,
                metaFieldCounts: r
            }, t), "skipped") : this._sendToCore("sdk.sensitiveMetaFields.set", {
                sensitiveMetaFields: n,
                metaFieldCounts: r
            }, t) ? "sent" : "queued";
        }
        setDeviceToken(e) {
            let t = e.trim();
            t && (this._deviceToken = t, this._deviceOs = It(this._config.metaFields) ? ? null, this._sendToCore("sdk.notifications.deviceToken.set", {
                token: t,
                deviceOs: this._deviceOs
            }));
        }
        _replayDeviceToken() {
            this._deviceToken && this._sendToCore("sdk.notifications.deviceToken.set", {
                token: this._deviceToken,
                deviceOs: this._deviceOs
            });
        }
        async sendMessage(e) {
            this._requireProgrammaticControl();
            let t = typeof e == "string" ? e.trim() : "";
            if (!t) throw Error("sendMessage requires non-empty text");
            let n = await this._applyBeforeSend(t);
            return this._beginExplicitEngagement(), this._isInitialized ? !this._isHeadless && (!this._isChatVisible() || this._showingTimeoutFallback) && this.open() : this._isHeadless ? this.start() : this.open(), this._eventBus.requestData((e, t) => this._sendToCore(e, t), "sdk.message.send", () => ({
                id: ""
            }), {
                timeoutErrorMessage: So,
                timeoutMs: hi,
                reArmOnProgress: !0,
                maxTotalMs: gi,
                payload: {
                    body: n
                }
            });
        }
        async triggerPlaybook(e, t) {
            if (this._requireProgrammaticControl(), typeof e != "string" || !/^[a-f\d]{24}$/i.test(e)) throw Error("triggerPlaybook requires a valid Playbook ID");
            if (t !== void 0 && (typeof t != "object" || !t || Array.isArray(t))) throw Error("triggerPlaybook requires an options object");
            for (let e of [t ? .metaFields, t ? .sensitiveMetaFields])
                if (e !== void 0 && (typeof e != "object" || !e || Array.isArray(e))) throw Error("triggerPlaybook requires metadata objects");
            let n = t ? .metaFields && N(M(t.metaFields)),
                r = t ? .sensitiveMetaFields && N(M(t.sensitiveMetaFields), {
                    sensitive: !0
                });
            n && this._retainMetaFields(n);
            let i = r !== void 0 && Object.keys(r).length > 0;
            this._beginExplicitEngagement(), this._isInitialized ? !this._isHeadless && (!this._isChatVisible() || this._showingTimeoutFallback) && this.open() : this._isHeadless ? this.start() : this.open(), await this._eventBus.requestData((e, t) => {
                this._sendToCore(e, t, i) && i && (this._hostSentSensitiveMetaFields = !0);
            }, "sdk.playbook.trigger", () => void 0, {
                timeoutErrorMessage: "triggerPlaybook timed out",
                timeoutMs: hi,
                reArmOnProgress: !0,
                maxTotalMs: gi,
                payload: {
                    playbookId: e,
                    ...n || r ? {
                        metaFieldCounts: An(n, r)
                    } : {},
                    ...n && {
                        metaFields: n
                    },
                    ...r && {
                        sensitiveMetaFields: r
                    }
                }
            });
        }
        async selectQuickReply(e, t) {
            if (this._requireProgrammaticControl(), typeof e != "string" || !e.trim()) throw Error("selectQuickReply requires a non-empty messageId");
            if (!Number.isInteger(t) || t < 0) throw Error("selectQuickReply requires a non-negative integer index");
            return this._beginExplicitEngagement(), this._isInitialized ? !this._isHeadless && (!this._isChatVisible() || this._showingTimeoutFallback) && this.open() : this._isHeadless ? this.start() : this.open(), this._eventBus.requestData((e, t) => this._sendToCore(e, t), "sdk.quickReply.select", () => void 0, {
                timeoutErrorMessage: "selectQuickReply timed out — chat frame did not respond in time.",
                timeoutMs: hi,
                reArmOnProgress: !0,
                maxTotalMs: gi,
                payload: {
                    messageId: e,
                    index: t
                }
            });
        }
        handleNotification() {
            this.open();
        }
        requestNotifications() {
            return typeof Notification > "u" ? null : Notification.requestPermission();
        }
        trackEvent(e, t, n) {
            this._sendToCore("sdk.analytics.trackEvent", {
                key: e,
                ...t === void 0 ? {} : {
                    value: t
                },
                meta: {
                    ...n ? ? {},
                    _ada_url : window.location.href.split("?")[0]
                }
            });
        }
        subscribeEvent(e, t) {
            return this._eventBus.subscribe(e, t);
        }
        unsubscribeEvent(e) {
            this._eventBus.unsubscribe(e);
        }
        subscribeAll(e) {
            return this._eventBus.subscribeAll(e);
        }
        triggerProactive(e, t) {
            let n = typeof e == "string" ? e : e.messageKey,
                r = typeof e == "string" ? t : e.params;
            if (!n || this._isChatOpen) return;
            this._config.lazy && !this._isInitialized && this._init();
            let i = {
                key: n,
                params: r,
                triggerMethod: "programmatic",
                intentId: this._nextProactiveIntentId()
            };
            if (!this._startupConfig) {
                this._pendingHostProactive = i;
                return;
            }
            this._sendToCore("sdk.proactive.inject", i);
        }
        triggerProactiveConversation(e, t) {
            this.triggerProactive(e, t);
        }
        createProactive(...e) {
            this._warnDeclarativeOnlyMethod("createProactive");
        }
        triggerCampaign(...e) {
            this._warnDeclarativeOnlyMethod("triggerCampaign");
        }
        evaluateCampaignConditions(...e) {
            this._warnDeclarativeOnlyMethod("evaluateCampaignConditions");
        }
        closeCampaign() {
            let e = this._currentIntroSurface;
            if (e ? .kind === "proactive") {
                this._markProactiveIntroShown(), this._sendToCore("sdk.proactive.dismissed", {
                    campaignKey: e.campaignKey,
                    surfaceId: e.surfaceId
                }), this._retirePreChatSurface({
                    notifyCore: !1
                });
                return;
            }
            this._activeProactiveSurfaceId !== null && (this._sendToCore("sdk.proactive.replaced", {
                surfaceId: this._activeProactiveSurfaceId
            }), this._retirePreChatSurface({
                notifyCore: !1
            }));
        }
        triggerAnswer(e) {
            this._triggerGreeting({
                responseId: e
            });
        }
        start(e) {
            if (this._isInitialized ? e && j.warn("start(options) only applies overrides before initialization.") : (this._applyStartOverrides(e), this._init()), this._waitsForEngagement) {
                this._prepareSessionForChannel();
                return;
            }
            this._parentElement && (this._beginExplicitEngagement(), this._showEmbeddedChat(), this._sendToCore("sdk.activate", void 0));
        }
        stop() {
            this.destroy();
        }
        triggerGreeting(e) {
            this._triggerGreeting({
                handle: e
            });
        }
        _triggerGreeting(e) {
            this._beginExplicitEngagement(), this._sendToCore("sdk.greeting.trigger", e);
        }
        destroy() {
            let e = this._runtimeGeneration;
            if (this._deliverHeldEndChatEvent(), this._runtimeGeneration === e) try {
                this._destroyRuntime();
            } finally {
                Do(this);
            }
        }
        _destroyRuntime() {
            this._runtimeGeneration += 1, this._heldEndChatEvent = null, this._clearEndChatEventTimer(), this._restoreStandaloneDocument ? .(), this._restoreStandaloneDocument = null, this._skipGreetingOnNextCoreConfig = !1, this._stopHostViewportSync(), this._setCustomAppFrameStyles({}), this._setHostViewportExpanded(!1), window.removeEventListener("message", this._handleFallbackMessage), this._cleanupServiceWorkerNotificationClick ? .(), this._cleanupServiceWorkerNotificationClick = null, this._clearProgrammaticProactiveTimer(), this._clearPendingIntroDisplay(), this._stopIntroChannelReadiness(), this._introChannelReady = !1, this._introChannelSetupStarted = !1, this._introChannelFailed = !1, this._introChannelUnlockAttempts = 0, this._pendingHostProactive = null, this._cleanupErrorReporter ? .(), this._cleanupErrorReporter = null, xr(this._hostCallbackErrorSink), this._cleanupActivationVisibilityWait ? .(), this._cleanupActivationVisibilityWait = null, this._clearChatActivationTimeouts(), this._activationWaitingForVisible = !1, this._eventBus.setActivationWaitingForVisible(!1), this._activationId = void 0, this._chatActivationDiagnosticSent = !1, this._chatFallbackArmedAt = null, this._clearChatHideTimer(), this._stopChatViewportHeightSync(), this._setPageScrollLocked(!1), this._coreFrameReloadTimer && = (clearTimeout(this._coreFrameReloadTimer), null), this._maskElement ? .destroy(), this._maskElement = null, this._cleanupCoreChannelHandlers ? .(), this._cleanupCoreChannelHandlers = null, this._frameManager ? .teardown(), this._frameManager = null, this._integrationManager ? .teardown(), this._integrationManager = null, this._introTimer && = (clearTimeout(this._introTimer), null);
            for (let e of this._proactiveTimers) clearTimeout(e);
            this._proactiveTimers.clear(), this._introShowing = null, this._unpatchLocationHistory(), this._voiceManager && = (this._voiceManager.destroy(), null), this._eventBus.teardown({
                isChatOpen: !1,
                isDrawerOpen: !1,
                hasActiveChatter: !1,
                hasClosedChat: !1
            }), this._unreadCount = 0, this._seededUnread = 0, this._seededUnreadToken = null, this._chatterToken = null, this._identitySessionChatterToken = null, this._identityTokenConsumedAwaitingChatter = !1, this._ignoredChatterAnnouncementToken = null, this._discardPersistedChatterCandidate(), this._resetCandidateDiscoveryForCoreReplacement(), this._acknowledgedUnreadToken = null, this._pendingUnreadAcknowledgement = !1, this._isChatOpen = !1, this._visibilityGeneration += 1, this._cancelEndChatMinimize(), this._lastEndedEndChatMinimizeSeq = null, this._hasChatOpened = !1, this._hasExplicitlyEngaged = !1, this._nativeViewVisible = !1, this._nativeVisibilityReported = !1, this._sessionPreparationSent = !1, this._hasIntroShown = !1, this._wasIntroShown = !1, this._introShown = !1, this._runtimeMetaGeneration += 1, this._runtimeMetaSyncScheduled = !1, this._hasCompletedActivation = !1, this._activationWorkObserved = !1, this._showingTimeoutFallback = !1, this._historyPreservingResetAfterCoreReload = null, this._pendingDestructiveOps = [], this._clearDurableClearIntent(), this._coreReadyForResetDelivery = !1, this._resolvedPersistenceMode = null, this._campaignShowSeq = 0, this._shownCampaign = null, this._openedCampaignSeq = 0, this._introSurfaceSeq = 0, this._currentIntroSurface = null, this._activeProactiveSurfaceId = null, this._proactiveClearRequestSeq = 0, this._pendingProactiveClearRequestId = null, this._pendingEmojiDisplay = null, this._proactiveIntentSeq = 0, this._currentProactiveIntentId = 0, this._hasActiveChatter = !1, this._crossWindowLiveChatActive = !1, this._pendingCrossWindowDrawerRestore = !1, this._delegate = {}, this._registeredInternalEventCallbacks.clear(), this._lastEvaluatedUrl = "", this._startupConfig = null, this._isInitialized = !1, this._hostSentSensitiveMetaFields = !1, this._warnedUndelegatedLoopbackAppUrl = !1, this._parentElementResolved = !1, this._pendingCoreMessages = [], this._pendingInfoMessages.clear(), this._pendingHostCallbackErrors = [];
        }
        _init() {
            if (!this._isInitialized) {
                Eo(this);
                try {
                    this._initializeFrames();
                } catch (e) {
                    throw this.destroy(), e;
                }
            }
        }
        _initializeFrames() {
            this._parentElement = null, this._cleanupErrorReporter = so((e, t) => this._sendToCore(e, t)), br(this._hostCallbackErrorSink);
            let e = this._config.parentElement;
            if (e) {
                let t = null;
                if (typeof e == "string" ? t = document.getElementById(e) : e instanceof HTMLElement && (t = e), !t) throw new H("parentElement requires a string or HTMLElement.");
                this._isHeadless || (this._parentElement = t, getComputedStyle(t).position === "static" && (t.style.position = "relative"));
            }
            this._parentElementResolved = !0;
            let t = this._frameManager,
                n, r;
            if (t !== null) n = t, r = n.container, this._parentElement && this._parentElement.appendChild(r);
            else {
                let e = this._createContainer(this._parentElement);
                r = e, n = this._createFrameManager(e), this._frameManager = n;
            }
            this._parentElement && (r.style.position = "absolute", r.style.inset = "0"), this._integrationManager = new na({
                buildAssetUrl: (e, t) => n.buildAssetUrl(e, t),
                container: r,
                sendToCore: (e, t) => this._sendToCore(e, t),
                routePublishedEvent: (e, t) => this._routePublishedEvent(e, t),
                deliverConfig: (e) => this._deliverConfig(e),
                getFrameOrigin: (e) => n.getFrameOrigin(e)
            }), this._hasFloatingWidgetChrome && n.mountFrame("button", {
                style: Ir(this._align, this._isTextButton, !!this._parentElement)
            }), this._hasFloatingWidgetChrome && this._config.hideMask === !1 && (this._maskElement = _a({
                container: r,
                onDismiss: () => this.close()
            })), t === null && n.mountFrame("core", {
                style: jr,
                additionalAllow: vn(this._config.appUrl)
            }), an.isSupported() && (this._voiceManager = new an({
                language: this._config.language || "en-US",
                mode: "toggle",
                callbacks: {
                    onTranscriptUpdate: (e, t) => {
                        this._sendToCore("sdk.voice.transcript", {
                            transcript: e,
                            isFinal: t
                        });
                    },
                    onError: (e) => {
                        this._sendToCore("sdk.voice.error", {
                            error: e
                        });
                    },
                    onAudioLevel: (e) => {
                        this._sendToCore("sdk.voice.audioLevel", {
                            level: e
                        });
                    }
                }
            })), this._patchLocationHistory(), this._isInitialized = !0, typeof this._config.deviceToken == "string" && this.setDeviceToken(this._config.deviceToken), t !== null && this._scheduleRuntimeMetaSync(), this._historyPreservingResetAfterCoreReload || this._flushPendingCoreMessages(), this._startupConfig ? .intro && this._startupConfig.chatEnabled !== !1 && this._scheduleIntro(this._startupConfig.intro), this._evaluateProactiveConditions(), this._config.identityToken && this._clearCrossWindowPersistenceState(), this._armCrossWindowDrawerRestore(), this._scheduleCandidateDiscovery(), this._waitsForEngagement && this._parentElement && !this._isHeadless && !this._config.lazy ? this._prepareSessionForChannel() : this._parentElement && !this._config.lazy && !this._isHeadless && (this._beginExplicitEngagement(), this._showEmbeddedChat(), this._sendToCore("sdk.activate", void 0)), this._setupServiceWorkerNotificationClickHandler();
        }
        _setupCoreChannel(e) {
            this._nativeVisibilityReported = !1, this._sessionPreparationSent = !1, e.on("core.endChat.minimizeAfterThanks", ({
                payload: e
            }) => {
                let t = E(e) ? .endChatSeq;
                this._minimizeAfterThanks(typeof t == "number" && Number.isFinite(t) ? t : null);
            }), e.on("core.endChat.cancelMinimize", () => this._cancelEndChatMinimize()), this._stopHostViewportSync(), this._cleanupCoreChannelHandlers ? .(), this._customAppFrameFallback = !1, this._lastCustomFrameTransparentBackground = !1, this._coreReadyForResetDelivery = !1, this._candidateDiscoveryBlockedForCore = !!(this._config.identityToken || this._isPrivateMode);
            let t = qr({
                channel: e,
                config: {
                    handle: this._config.handle,
                    language: this._config.language,
                    headless: this._config.headless,
                    rolloutOverride: this._isBotHostedChatPage ? 1 : this._config.rolloutOverride,
                    sensitiveMetaFields: this._config.sensitiveMetaFields,
                    eventCallbacks: this._config.eventCallbacks
                },
                channels: this._channels,
                frames: this._frames,
                parentElement: this._parentElement,
                deliverConfig: (e) => this._deliverConfig(e, {
                    includeCoreBootstrapFlags: !0
                }),
                open: () => this.open(),
                close: (e) => this.close(e),
                destroy: () => this.destroy(),
                routePublishedEvent: (e, t, n, r) => {
                    e === "ada:end_conversation" && r ? this._holdEndChatEvent(t, r.endChatSeq) : this._routePublishedEvent(e, t, n);
                },
                invokeWindowCallback: (e, ...t) => this._invokeWindowCallback(e, ...t),
                dispatchIntegrationCommand: (e) => this._integrationManager ? .dispatch(e),
                startVoiceRecording: () => {
                    this._voiceManager ? .startRecording();
                },
                stopVoiceRecording: () => this._voiceManager ? .stopRecording(),
                setVoiceLanguage: (e) => this._voiceManager ? .setLanguage(e),
                setVoiceMode: (e) => this._voiceManager ? .setMode(e),
                setStartupConfig: (e) => this._acceptStartupConfig(e),
                getStartupConfig: () => this._startupConfig,
                getIsChatOpen: () => this._isChatVisible(),
                getWindowInfo: () => this._getWindowInfo(),
                getAlign: () => this._align,
                scheduleIntro: (e) => this._scheduleIntro(e),
                evaluateProactive: () => this._evaluateProactiveConditions(),
                showProactive: (e, t) => this._showProactive(e, t),
                beginProactiveDisplay: (e, t, n) => this._beginProactiveDisplay(e, t, n),
                isProactiveClearPending: () => this._pendingProactiveClearRequestId !== null,
                acknowledgeProactiveClear: (e) => {
                    this._pendingProactiveClearRequestId === e && (this._pendingProactiveClearRequestId = null);
                },
                clearProactiveFromCore: () => this._clearProactiveFromCore(),
                incrementUnreadCount: () => (this._unreadCount++, this._unreadCount),
                setHasActiveChatter: (e) => {
                    this._hasActiveChatter = e;
                },
                setChatterToken: (e) => this._setChatterToken(e),
                setChatterCandidate: (e) => this._setPersistedChatterCandidate(e),
                handleSessionResumeResult: (e) => this._handleSessionResumeResult(e),
                handleSessionResumeVisibilityResult: (e) => this._handleSessionResumeVisibilityResult(e),
                clearIdentityToken: () => this._clearIdentityToken(),
                markIdentityTokenConsumed: (e) => {
                    this._identityTokenConsumedAwaitingChatter = !0, e && (this._identitySessionChatterToken = e);
                },
                markIdentityTokenFailed: () => {
                    this._identityTokenConsumedAwaitingChatter && (this._identitySessionChatterToken = null), this._identityTokenConsumedAwaitingChatter = !1;
                },
                setPersistenceMode: (e) => {
                    this._resolvedPersistenceMode = e;
                },
                setCrossWindowLiveChatActive: (e) => {
                    this._setCrossWindowLiveChatActive(e);
                },
                setSensitiveMetaFields: (e) => this._sendSensitiveMetaFieldsToCore(e, !1),
                hasHostSentSensitiveMetaFields: () => this._hostSentSensitiveMetaFields,
                setHostViewportExpanded: (e) => this._setHostViewportExpanded(e),
                setCustomAppFrameStyles: (e) => this._setCustomAppFrameStyles(e),
                setDocumentTitle: (e, t, n) => {
                    if (this._isChatHtmlPage || this._isBotHostedChatPage) {
                        let r = document.documentElement;
                        if (!this._restoreStandaloneDocument) {
                            let e = document.title,
                                t = r.getAttribute("lang"),
                                n = r.getAttribute("dir");
                            this._restoreStandaloneDocument = () => {
                                document.title = e, t === null ? r.removeAttribute("lang") : r.setAttribute("lang", t), n === null ? r.removeAttribute("dir") : r.setAttribute("dir", n);
                            };
                        }
                        document.title = e, r.lang = t, r.dir = n;
                    }
                },
                onCoreProtocolReady: () => this._markCoreProtocolReady(),
                onCoreStartupFailed: () => {
                    this._coreStartupFailed = !0;
                },
                onCoreError: () => {
                    this._setActivationWaitingForVisible(!1), this._coreStartupFailed = !0, this._stopHostViewportSync();
                },
                onCoreReady: () => {
                    this._coreStartupFailed = !1, this._startHostViewportSync(), this._lastCustomFrameTransparentBackground = !1, this._syncCustomFrameStylesApplied(), this._hasExplicitlyEngaged || (this._activationWorkObserved = !1), this._markCoreProtocolReady(), this._replayDeviceToken(), this._coreReadyForCandidateDiscovery = !0, this._flushPendingCoreMessages(), this._scheduleCandidateDiscovery();
                },
                infoRequestCallbacks: this._eventBus.infoRequestCallbacks,
                infoRequestTimers: this._eventBus.infoRequestTimers,
                resolveDataRequest: (e, t) => {
                    this._acknowledgeDurableClearIntent(e), this._historyPreservingResetAfterCoreReload ? .requestId === e && (this._historyPreservingResetAfterCoreReload = null), this._eventBus.resolveDataRequest(e, t), this._settleDestructiveOpFamily(e, t);
                },
                rejectDataRequest: (e, t) => this._eventBus.rejectDataRequest(e, t),
                flushDataRequests: (e) => this._eventBus.flushDataRequests(e),
                getZdChatterAuthCallback: () => this._zdChatterAuthCallback
            });
            this._cleanupCoreChannelHandlers = typeof t == "function" ? t : null, this._historyPreservingResetAfterCoreReload || this._flushPendingCoreMessages();
        }
        _setupButtonChannel(e) {
            Jr({
                channel: e,
                frames: this._frames,
                deliverConfig: (e) => this._deliverConfig(e),
                open: () => this.open(),
                setLastOpenedViaKeyboard: (e) => {
                    this._lastOpenedViaKeyboard = e;
                },
                getAlign: () => this._align,
                getIsChatOpen: () => this._isChatVisible()
            }), this._syncButtonStartupConfig(), this._syncButtonUnreadCount(), this._drainPendingEmojiDisplay();
        }
        _clearIntroChannelHandshakeTimer() {
            this._introChannelHandshakeTimer && = (clearTimeout(this._introChannelHandshakeTimer), null);
        }
        _clearIntroChannelDisplayTimer() {
            this._introChannelDisplayTimer && = (clearTimeout(this._introChannelDisplayTimer), null);
        }
        _stopIntroChannelReadiness() {
            this._clearIntroChannelHandshakeTimer(), this._clearIntroChannelDisplayTimer();
        }
        _armIntroChannelDisplayTimeout() {
            this._clearIntroChannelDisplayTimer(), !(this._introChannelReady || this._introChannelFailed || !this._pendingIntroDisplay) && (this._introChannelDisplayTimer = setTimeout(() => {
                this._introChannelDisplayTimer = null, this._introChannelReady || this._dropPendingIntroDisplay();
            }, W));
        }
        _attemptIntroChannelUnlock(e) {
            if (this._introChannelHandshakeTimer = null, !(this._introChannelReady || this._introChannelFailed || this._channels.get("intro") !== e)) {
                if (this._introChannelUnlockAttempts >= 20) {
                    j.warn("Intro frame did not become ready after repeated handshake attempts.");
                    return;
                }
                this._introChannelUnlockAttempts += 1, e.send("intro.handshake", void 0), this._introChannelHandshakeTimer = setTimeout(() => this._attemptIntroChannelUnlock(e), di);
            }
        }
        _setupIntroChannel(e) {
            if (this._channels.get("intro") !== e) {
                e.disconnect();
                return;
            }
            this._stopIntroChannelReadiness(), this._introChannelReady = !1, this._introChannelSetupStarted = !0, this._introChannelUnlockAttempts = 0, !this._introChannelFailed && (va({
                channel: e,
                frames: this._frames,
                getAlign: () => this._align,
                getStartupConfig: () => this._startupConfig,
                sendToCore: (e, t) => this._sendToCore(e, t),
                routePublishedEvent: (e, t) => this._routePublishedEvent(e, t),
                open: () => this.open(),
                openFromProactiveEngagement: () => this._openFromProactiveEngagement(),
                setIntroShowing: (e) => {
                    this._introShowing = e;
                },
                getCurrentIntroSurface: () => this._currentIntroSurface,
                clearCurrentIntroSurface: () => {
                    this._currentIntroSurface ? .kind === "proactive" && (this._activeProactiveSurfaceId = null), this._currentIntroSurface = null;
                },
                acknowledgeProactiveShown: (e, t) => this._acknowledgeProactiveShown(e, t),
                markIntroShown: () => this._markProactiveIntroShown(),
                clearShownCampaign: () => {
                    this._shownCampaign = null;
                },
                openCtaUrl: (e, t) => this._openProactiveCtaUrl(e, t)
            }), e.on("frame.ready", () => {
                this._channels.get("intro") === e && (this._introChannelReady = !0, this._stopIntroChannelReadiness(), this._drainPendingIntroDisplay());
            }), e.on("frame.error", () => {
                this._channels.get("intro") === e && (this._introChannelFailed = !0, this._introChannelReady = !1, this._stopIntroChannelReadiness(), this._dropPendingIntroDisplay());
            }), this._pendingIntroDisplay && this._armIntroChannelDisplayTimeout(), this._attemptIntroChannelUnlock(e));
        }
        _openProactiveCtaUrl(e, t) {
            Qa(e, t, (e, t, n) => globalThis.window.open(e, t, n));
        }
        _deliverConfig(e, t = {}) {
            let n = this._pendingClearPersistenceScope === null || this._pendingClearPersistenceScope === this._persistenceScopeKey(),
                r = t.includeCoreBootstrapFlags && this._clearPersistenceOnNextCoreConfig === !0 && n,
                i = r ? this._pendingClearAckRequestId : null,
                a = r ? this._pendingClearAckResponseType : null,
                o = t.includeCoreBootstrapFlags ? this._greetingResponseIdOnNextCoreConfig : void 0;
            o !== void 0 && (this._greetingResponseIdOnNextCoreConfig = void 0);
            let s = t.includeCoreBootstrapFlags ? this._skipGreetingOnNextCoreConfig : void 0;
            t.includeCoreBootstrapFlags && (this._skipGreetingOnNextCoreConfig = !1), Ai(e, {
                handle: this._config.handle,
                cluster: this._config.cluster,
                endpoint: this._cachedEndpoint,
                language: this._config.language,
                greeting: this._config.greeting,
                configuredGreetingResponseId: this._configuredGreetingResponseId,
                identityToken: t.includeCoreBootstrapFlags ? this._config.identityToken : void 0,
                greetingResponseId: o,
                skipGreeting: this._config.skipGreeting,
                skipGreetingOnce: s,
                metaFields: this._config.metaFields,
                metaFieldsBaseline: this._hostMetaFieldsBaseline,
                sensitiveMetaFields: this._config.sensitiveMetaFields,
                allowMetaFieldsInReset: this._config.allowMetaFieldsInReset,
                enableProgrammaticControl: this._config.enableProgrammaticControl,
                appUrl: this._config.appUrl,
                appUrlFallback: this._config.appUrlFallback,
                androidHostNavigation: this._androidHostNavigation,
                hostTelemetry: Zt({
                    hostTelemetry: this._internalHostTelemetry
                }, {
                    defaultOrigin: "messaging",
                    defaultSurface: "browser"
                }),
                branding: this._config.branding,
                theme: this._config.theme,
                testMode: this._config.testMode,
                privateMode: this._isPrivateMode,
                headless: this._isHeadless,
                isParentElementMode: !this._isHeadless && !!this._config.parentElement,
                isMobileViewport: Mr(),
                hideDefaultHeader: this._config.hideDefaultHeader === !0,
                clearPersistenceOnPrepare: r,
                clearPersistenceAckRequestId: i ? ? void 0,
                clearPersistenceAckResponseType: a ? ? void 0,
                clearPersistenceStorageModes: r ? this._pendingClearPersistenceModes : void 0,
                clearPersistenceOutgoingStorageMode: r ? this._pendingClearOutgoingStorageMode ? ? void 0 : void 0,
                introShown: this._introShown,
                initialURL: this._initialUrlMetaField(),
                nativeSessionMirror: t.includeCoreBootstrapFlags ? this._nativeSessionMirror : !1
            });
        }
        acknowledgeSessionMirrorClear(e) {
            typeof e != "string" || e === "" || this._sendToCore("sdk.sessionMirror.clearAck", {
                requestId: e
            });
        }
        deliverSessionMirrorSeed(e, t) {
            typeof e != "string" || e === "" || this._sendToCore("sdk.sessionMirror.seed", {
                requestId: e,
                seed: t
            });
        }
        _invokeWindowCallback(e, ...t) {
            ji(e, ...t);
        }
        _isEligibleForActivationTimeouts() {
            return (this._isChatVisible() || this._isHeadless) && (!this._waitsForEngagement || this._hasExplicitlyEngaged) && !this._activationWaitingForVisible && !this._showingTimeoutFallback;
        }
        _setActivationWaitingForVisible(e) {
            let t = this._activationWaitingForVisible;
            if (this._activationWaitingForVisible = e, this._eventBus.setActivationWaitingForVisible(e), e) t || (this._cleanupActivationVisibilityWait = Vt(document, window)(() => {
                document.visibilityState !== "hidden" && this._setActivationWaitingForVisible(!1);
            }), this._chatFallbackElapsedBeforeWait = this._chatFallbackArmedAt === null ? null : this._startupClock.activeElapsed(this._chatFallbackArmedAt)), this._clearChatActivationTimeouts(!1), this._startupClock.stop(), this._chatFallbackArmedAt = null;
            else if (t) {
                this._cleanupActivationVisibilityWait ? .(), this._cleanupActivationVisibilityWait = null;
                let e = this._chatFallbackElapsedBeforeWait;
                this._clearChatActivationTimeouts(), e !== null && (this._chatFallbackArmedAt = this._startupClock.now() - e), this._isEligibleForActivationTimeouts() && this._startChatActivationTimeouts();
            }
        }
        _routePublishedEvent(e, t, n) {
            if (e === "ada.app.frame.loaded" && (typeof t == "object" && t && "isCustomApp" in t && t.isCustomApp === !0 && (this._customAppFrameFallback = !1, this._syncHostViewport()), this._lastCustomFrameTransparentBackground = !1, this._syncCustomFrameStylesApplied()), (e === "ada.customApp.fallback" || e === "ada.activation.error" && typeof t == "object" && t && "code" in t && typeof t.code == "string" && Te.some((e) => e === t.code)) && (this._customAppFrameFallback = !0, this._setCustomAppFrameStyles({}), this._syncHostViewport(), this._syncCustomFrameStylesApplied()), e.startsWith("ada.activation.")) {
                if (n !== void 0 && this._activationId !== void 0 && n < this._activationId) {
                    this._eventBus.routePublishedEvent(e, t);
                    return;
                }
                if (e === "ada.activation.started" && (n === void 0 || n !== this._activationId)) {
                    let e = this._chatFallbackArmedAt === null ? null : this._startupClock.activeElapsed(this._chatFallbackArmedAt);
                    this._startupClock.dispose(), this._clearChatActivationTimeouts(!1), this._startupClock = Bt({
                        subscribeLifecycle: Vt(document, window)
                    }), this._activationId = n, this._chatActivationDiagnosticSent = !1, e !== null && (this._chatFallbackArmedAt = this._startupClock.now() - e);
                }
                this._startupClock.setLastStep(e);
            }
            if (e === "ada.activation.started" && (this._startupClock.start(), this._hasCompletedActivation = !1, this._activationWorkObserved = !0, this._isEligibleForActivationTimeouts() && this._chatActivationEventTimer === null && this._chatFallbackTimer === null && this._startChatActivationTimeouts()), e === "ada.activation.prepared" && (this._activationWorkObserved = !0, this._isEligibleForActivationTimeouts() && (this._chatActivationEventTimer === null ? this._startChatActivationTimeouts() : this._rearmChatFallbackTimeout())), e === "ada.activation.progress") {
                this._setActivationWaitingForVisible(!!t && typeof t == "object" && "waitingForVisible" in t && t.waitingForVisible === !0), this._activationWorkObserved = !0, this._eventBus.reArmPendingRequests(), this._isEligibleForActivationTimeouts() && (this._chatActivationEventTimer === null ? this._startChatActivationTimeouts() : this._rearmChatFallbackTimeout());
                return;
            }
            e === "ada.activation.error" && this._startupClock.stop(), e === "ada.activation.complete" && (this._hasCompletedActivation = !0, this._coreStartupFailed = !1, this._activationWorkObserved = !1, this._clearChatActivationTimeouts(), this._chatFallbackArmedAt = null), e === "ada.activation.outage" && (this._activationWorkObserved = !1, this._clearChatActivationTimeouts(), this._chatFallbackArmedAt = null);
            let r = this._chatFrameTimeoutCallback;
            if (this._isLegacyLoader && e === "ada:chat_frame_timeout" && r) try {
                I(r(t, {
                    eventKey: e
                }), "chatFrameTimeoutCallback", e, "chatFrameTimeoutCallback");
            } catch (t) {
                j.error("chatFrameTimeoutCallback threw:", t), F("chatFrameTimeoutCallback", e, t);
            }
            this._eventBus.routePublishedEvent(e, t);
        }
        _beginProactiveDisplay(e, t, n) {
            this._currentIntroSurface = {
                kind: "proactive",
                campaignKey: e,
                surfaceId: t,
                ...n === void 0 ? {} : {
                    intentId: n
                }
            }, this._introShowing = "proactive";
        }
        _acknowledgeProactiveShown(e, t) {
            let n = this._currentIntroSurface;
            return n ? .kind !== "proactive" || n.campaignKey !== e || n.surfaceId !== t ? !1 : (this._shownCampaign = {
                key: e,
                seq: ++this._campaignShowSeq
            }, !0);
        }
        _beginGreetingDisplay() {
            let e = ++this._introSurfaceSeq;
            return this._currentIntroSurface = {
                kind: "greeting",
                displayId: e
            }, e;
        }
        _publishShownCampaignOpened() {
            !this._shownCampaign || this._shownCampaign.seq <= this._openedCampaignSeq || (this._openedCampaignSeq = this._shownCampaign.seq, this._routePublishedEvent("ada:campaigns:opened", {
                campaignKey: this._shownCampaign.key
            }));
        }
        _warnDeclarativeOnlyMethod(e) {
            j.warn(`${e}() is deprecated and not supported. ${Co}`);
        }
        _queuePendingCoreMessage(e, t, n = !1, r) {
            if (e === "sdk.info.get") {
                let {
                    requestId: e
                } = t;
                this._pendingInfoMessages.set(e, {
                    payload: t,
                    onSent: r
                });
                return;
            }
            if (e === "sdk.runtimeMeta.set") {
                let n = this._pendingCoreMessages.findIndex((t) => t.type === e);
                if (n !== -1) {
                    this._pendingCoreMessages[n] = {
                        type: e,
                        payload: t
                    };
                    return;
                }
            }
            if (this._waitsForEngagement && e === "sdk.visibility.set") {
                let n = this._pendingCoreMessages.findIndex((n) => n.type === e && n.payload.isVisible === t.isVisible);
                n !== -1 && this._pendingCoreMessages.splice(n, 1);
            }
            if (this._pendingCoreMessages.length >= this.MAX_PENDING_MESSAGES) {
                let t = (e) => e === "sdk.session.prepare" || this._waitsForEngagement && e === "sdk.visibility.set",
                    n = this._pendingCoreMessages.findIndex((e) => !t(e.type));
                if (n === -1 && e === "sdk.error.report") return;
                if (n !== -1 || !t(e)) {
                    let t = n === -1 ? {
                        type: e
                    } : this._pendingCoreMessages.splice(n, 1)[0];
                    if (window.dispatchEvent(new CustomEvent("ada:error", {
                            detail: {
                                type: "pending.message.dropped",
                                message: `Pending core message queue full; dropped: ${t?.type ?? "unknown"}`
                            }
                        })), n === -1) return;
                }
            }
            this._pendingCoreMessages.push({
                type: e,
                payload: t,
                ...n ? {
                    latchSensitiveOnFlush: n
                } : {},
                ...r ? {
                    onSent: r
                } : {}
            });
        }
        _flushPendingCoreMessages() {
            let e = this._channels.get("core");
            if (e) {
                for (let t of this._pendingCoreMessages.splice(0)) t.type === "sdk.sensitiveMetaFields.set" && !t.latchSensitiveOnFlush && this._hostSentSensitiveMetaFields || (t.latchSensitiveOnFlush && (t.type !== "sdk.sensitiveMetaFields.set" || Object.keys(t.payload.sensitiveMetaFields).length > 0) && (this._hostSentSensitiveMetaFields = !0), e.send(t.type, t.payload), t.onSent ? .());
                if (this._coreReadyForCandidateDiscovery)
                    for (let [t, n] of this._pendingInfoMessages) this._pendingInfoMessages.delete(t), e.send("sdk.info.get", n.payload), n.onSent ? .();
                for (let t of this._pendingHostCallbackErrors.splice(0)) e.send(t.type, t.payload);
            }
        }
        _acceptStartupConfig(e) {
            this._startupConfig = e;
            let t = this._pendingHostProactive;
            this._pendingHostProactive = null, t && this._sendToCore("sdk.proactive.inject", t);
        }
        _syncButtonStartupConfig() {
            let e = this._channels.get("button");
            !this._hasFloatingWidgetChrome || !e || !this._startupConfig || e.send("sdk.button.config", {
                ...this._startupConfig,
                align: this._align
            });
        }
        _syncButtonUnreadCount() {
            let e = this._channels.get("button");
            if (!(!this._hasFloatingWidgetChrome || !e)) {
                if (this._unreadCount > 0) {
                    e.send("sdk.unread.count", {
                        count: this._unreadCount
                    });
                    return;
                }
                if (this._seededUnread > 0) {
                    e.send("sdk.unread.count", {
                        count: this._seededUnread,
                        display: "dot"
                    });
                    return;
                }
                e.send("sdk.unread.count", {
                    count: 0
                });
            }
        }
        _showOrQueueIntroDisplay(e, t, n) {
            if (!this._hasFloatingWidgetChrome) {
                this._dropPendingIntroDisplay(), n ? .();
                return;
            }
            if (this._isChatOpen) {
                this._clearPendingIntroDisplay();
                return;
            }
            if (e === "greeting" && (this._pendingIntroDisplay ? .kind === "proactive" || this._currentIntroSurface ? .kind === "proactive" || this._introShowing === "proactive")) return;
            if (this._introChannelFailed) {
                this._clearPendingIntroDisplay(), n ? .();
                return;
            }
            if (this._channels.has("intro") && this._introChannelReady) {
                this._clearPendingIntroDisplay(), t();
                return;
            }
            let r = this._pendingIntroDisplay;
            this._pendingIntroDisplay = {
                kind: e,
                display: t,
                onDropped: n
            }, r ? .onDropped ? .(), this._ensureIntroFrame(), this._introChannelSetupStarted && this._armIntroChannelDisplayTimeout();
        }
        _ensureIntroFrame() {
            !this._hasFloatingWidgetChrome || !this._frameManager || this._frames.intro || (this._frameManager.mountFrame("intro", {
                style: L
            }), this._startHostViewportSync());
        }
        _showOrQueueEmojiDisplay(e) {
            if (!this._hasFloatingWidgetChrome) {
                this._pendingEmojiDisplay = null;
                return;
            }
            if (this._channels.has("button")) {
                this._pendingEmojiDisplay = null, e();
                return;
            }
            this._pendingEmojiDisplay = e;
        }
        _drainPendingEmojiDisplay() {
            let e = this._pendingEmojiDisplay;
            this._pendingEmojiDisplay = null, e ? .();
        }
        _drainPendingIntroDisplay() {
            if (!this._introChannelReady) return;
            let e = this._pendingIntroDisplay;
            this._clearPendingIntroDisplay(), e ? .display();
        }
        _clearPendingIntroDisplay(e) {
            (!e || this._pendingIntroDisplay ? .kind === e) && (this._pendingIntroDisplay = null, this._clearIntroChannelDisplayTimer());
        }
        _dropPendingIntroDisplay(e) {
            if (e && this._pendingIntroDisplay ? .kind !== e) return;
            let t = this._pendingIntroDisplay;
            this._clearPendingIntroDisplay(e), t ? .onDropped ? .();
        }
        _clearProgrammaticProactiveTimer() {
            this._programmaticProactiveTimer !== null && (clearTimeout(this._programmaticProactiveTimer), this._programmaticProactiveTimer = null);
        }
        _clearProactive() {
            this._clearProgrammaticProactiveTimer();
            for (let e of this._proactiveTimers) clearTimeout(e);
            this._proactiveTimers.clear(), this._clearPendingIntroDisplay("proactive");
        }
        _clearProactiveFromCore() {
            if (this._beginProactiveIntent(), this._clearProactive(), this._pendingHostProactive = null, this._activeProactiveSurfaceId = null, this._shownCampaign = null, this._currentIntroSurface ? .kind !== "proactive") return;
            this._channels.get("intro") ? .send("intro.proactive.clear", void 0);
            let e = this._frames.intro;
            e && P(e, L), this._currentIntroSurface = null, this._introShowing = null;
        }
        _beginProactiveIntent() {
            return this._currentProactiveIntentId = this._nextProactiveIntentId(), this._currentProactiveIntentId;
        }
        _retireDroppedProactiveSurface(e, t) {
            this._activeProactiveSurfaceId !== e || typeof t == "number" && t !== this._currentProactiveIntentId || (this._sendToCore("sdk.proactive.replaced", {
                surfaceId: e
            }), this._activeProactiveSurfaceId = null);
        }
        _nextProactiveIntentId() {
            return ++this._proactiveIntentSeq;
        }
        _retirePreChatSurface({
            notifyCore: e = !0,
            notifyReplacement: t = !1,
            invalidateIntent: n = !0,
            preserveShownCampaign: r = !1
        } = {}) {
            n && this._beginProactiveIntent();
            let i = this._activeProactiveSurfaceId;
            if (e && this._channels.has("core")) {
                let e = ++this._proactiveClearRequestSeq;
                this._pendingProactiveClearRequestId = e, this._sendToCore("sdk.proactive.clear", {
                    requestId: e
                });
            } else t && i !== null && this._sendToCore("sdk.proactive.replaced", {
                surfaceId: i
            });
            this._clearProactive(), this._introTimer && = (clearTimeout(this._introTimer), null), this._clearPendingIntroDisplay(), this._pendingEmojiDisplay = null, this._pendingHostProactive = null, this._channels.get("button") ? .send("sdk.button.emoji.hide", void 0);
            let a = this._channels.get("intro");
            a ? .send("intro.greeting.hide", void 0), a ? .send("intro.proactive.clear", void 0);
            let o = this._frames.intro;
            o && P(o, L), this._introShowing = null, this._currentIntroSurface = null, this._activeProactiveSurfaceId = null, r || (this._shownCampaign = null);
        }
        _showProactive(e, t) {
            if (typeof e.intentId == "number" && e.intentId < this._currentProactiveIntentId) return;
            if (typeof e.intentId == "number" && (this._currentProactiveIntentId = e.intentId), this._retirePreChatSurface({
                    notifyCore: !1,
                    notifyReplacement: !0,
                    invalidateIntent: !1
                }), this._activeProactiveSurfaceId = e.surfaceId, this._hasChatOpened || !this._hasFloatingWidgetChrome) {
                let e = ++this._proactiveClearRequestSeq;
                this._pendingProactiveClearRequestId = e, this._sendToCore("sdk.proactive.clear", {
                    requestId: e
                }), this._activeProactiveSurfaceId = null;
                return;
            }
            if (this._ensureIntroFrame(), e.triggerMethod === "programmatic" && e.campaignKey) {
                let t = e.frequency ? ? "session";
                t === "user" ? Xa(e.campaignKey, this._config.handle) : t === "session" && Ja(e.campaignKey, this._config.handle);
            }
            if (e.triggerMethod !== "programmatic") {
                this._showOrQueueIntroDisplay("proactive", t, () => this._retireDroppedProactiveSurface(e.surfaceId, e.intentId));
                return;
            }
            let n = typeof e.displayDelay == "number" && Number.isFinite(e.displayDelay) ? Math.max(0, e.displayDelay) : 0;
            this._programmaticProactiveTimer = setTimeout(() => {
                this._programmaticProactiveTimer = null, !(typeof e.intentId == "number" && e.intentId !== this._currentProactiveIntentId) && this._showOrQueueIntroDisplay("proactive", t, () => this._retireDroppedProactiveSurface(e.surfaceId, e.intentId));
            }, n * 1e3);
        }
        _prepareForSessionReset({
            keepChatter: e = !1
        } = {}) {
            this._cancelEndChatMinimize(), this._cancelScheduledRuntimeMetaSync(), this._introShown = this._wasIntroShown, this._pendingCoreMessages = this._isInitialized ? [{
                type: "sdk.runtimeMeta.set",
                payload: this._currentRuntimeMeta()
            }] : [], this._retirePreChatSurface(), this._pendingHostProactive = null, this._hasActiveChatter = e && this._hasActiveChatter, this._hasCompletedActivation = !1, this._activationWorkObserved = !1, this._showingTimeoutFallback = !1, e || (this._identityTokenConsumedAwaitingChatter && this._identitySessionChatterToken && (this._ignoredChatterAnnouncementToken = this._identitySessionChatterToken), this._discardPersistedChatterCandidate(), this._unreadCount = 0, this._seededUnread = 0, this._seededUnreadToken = null, this._chatterToken = null, this._identitySessionChatterToken = null, this._identityTokenConsumedAwaitingChatter = !1, this._resolvedPersistenceMode = null), this._pendingUnreadAcknowledgement = !this._chatterToken && this._isChatVisible(), this._clearChatActivationTimeouts(), this._activationId = void 0, this._chatActivationDiagnosticSent = !1, this._chatFallbackArmedAt = null, e || this._syncButtonUnreadCount();
        }
        _clearChatActivationTimeouts(e = !0) {
            e && (this._chatFallbackElapsedBeforeWait = null, this._startupClock.dispose(), this._startupClock = Bt({
                subscribeLifecycle: Vt(document, window)
            })), this._chatActivationEventTimer && = (this._chatActivationEventTimer(), null), this._chatFallbackTimer && = (this._chatFallbackTimer(), null);
        }
        _startChatCloseAnimation(e) {
            let t = e.style.getPropertyValue(z);
            P(e, zr(this._align, V(), this._customAppFrameStyles)), cr(e, !1), t && e.style.setProperty(z, t), this._chatHideTimer = setTimeout(() => {
                this._chatHideTimer = null, P(e, jr), this._syncCustomFrameStylesApplied();
            }, 200);
        }
        _clearChatHideTimer() {
            this._chatHideTimer && = (clearTimeout(this._chatHideTimer), null);
        }
        _syncChatViewportHeight(e) {
            this._stopChatViewportHeightSync();
            let t = Fr(e),
                n = () => this._syncPageScrollLock();
            e.addEventListener("transitionend", n), this._chatViewportCleanup = () => {
                t(), e.removeEventListener("transitionend", n);
            };
        }
        _stopChatViewportHeightSync() {
            this._chatViewportCleanup ? .(), this._chatViewportCleanup = null;
        }
        _customFrameStylesApply() {
            return this._hasFloatingWidgetChrome && !!this._config.appUrl && !this._customAppFrameFallback && !V() && !this._showingTimeoutFallback;
        }
        _startHostViewportSync() {
            if (!this._hostViewportCleanup) {
                let e = window.visualViewport,
                    t = null,
                    n = () => {
                        t === null && (t = window.requestAnimationFrame(() => {
                            t = null, this._syncHostViewport(), Vr(this._frames, this._align), this._syncPageScrollLock();
                        }));
                    };
                window.addEventListener("resize", n), window.addEventListener("orientationchange", n), e ? .addEventListener("resize", n), this._hostViewportCleanup = () => {
                    window.removeEventListener("resize", n), window.removeEventListener("orientationchange", n), e ? .removeEventListener("resize", n), t !== null && window.cancelAnimationFrame(t);
                };
            }
            this._syncHostViewport();
        }
        _stopHostViewportSync() {
            this._hostViewportCleanup ? .(), this._hostViewportCleanup = null, this._lastHostViewport = void 0;
        }
        _layoutViewport() {
            return Er(document);
        }
        _syncHostViewport() {
            let e = this._channels.get("core");
            if (!e || !this._hostViewportCleanup) return;
            let t = this._customFrameStylesApply() ? {
                width: Math.round(this._layoutViewport().width),
                height: Math.round(window.visualViewport ? .height ? ? window.innerHeight)
            } : null;
            this._lastHostViewport !== void 0 && t ? .width === this._lastHostViewport ? .width && t ? .height === this._lastHostViewport ? .height || (e.send("sdk.hostViewport.set", t ? ? {
                viewport: null
            }), this._lastHostViewport = t);
        }
        _syncCustomFrameStylesApplied() {
            let e = this._channels.get("core");
            if (!e) return;
            let t = this._customFrameStylesApply() && !this._hostViewportRequested && this._customAppFrameStyles.backgroundColor !== void 0;
            t !== this._lastCustomFrameTransparentBackground && (e.send("sdk.frameStyles.applied", {
                transparentBackground: t
            }), this._lastCustomFrameTransparentBackground = t);
        }
        _setCustomAppFrameStyles(e) {
            let t = Object.keys(e).length > 0;
            if (t && !this._customFrameStylesApply() || !t && Object.keys(this._customAppFrameStyles).length === 0) return;
            this._customAppFrameStyles = e;
            let n = this._frames.core;
            n && !t && !this._isChatOpen && (this._clearChatHideTimer(), P(n, jr)), n && this._isChatOpen && !this._hostViewportRequested && (P(n, Lr(this._align, !1, V(), !1, e)), this._syncChatViewportHeight(n)), this._syncCustomFrameStylesApplied(), this._syncPageScrollLock();
        }
        _setHostViewportExpanded(e) {
            let t = e && this._hasFloatingWidgetChrome && !this._showingTimeoutFallback;
            if (t === this._hostViewportRequested) return;
            this._hostViewportRequested = t;
            let n = this._frames.core;
            n && this._isChatOpen && (P(n, t ? Rr() : Lr(this._align, !1, V(), !1, this._customAppFrameStyles)), this._syncChatViewportHeight(n)), this._syncCustomFrameStylesApplied(), this._syncPageScrollLock();
        }
        _customFrameCoversViewport() {
            if (!this._customFrameStylesApply() || Object.keys(this._customAppFrameStyles).length === 0) return !1;
            let e = this._frames.core ? .getBoundingClientRect(),
                t = this._layoutViewport();
            return !!e && e.left <= 1 && e.top <= 1 && e.right >= t.width - 1 && e.bottom >= t.height - 1;
        }
        _syncPageScrollLock() {
            this._setPageScrollLocked(this._hasFloatingWidgetChrome && this._isChatOpen && (V() || this._hostViewportRequested || this._customFrameCoversViewport()));
        }
        _setPageScrollLocked(e) {
            e !== this._pageScrollLocked && (e ? zi() : Bi(), this._pageScrollLocked = e);
        }
        get _hasFloatingWidgetChrome() {
            return (this._isInitialized || this._parentElementResolved) && !this._parentElement && !this._isHeadless;
        }
        _startChatActivationTimeouts() {
            if (this._hasCompletedActivation || this._activationWaitingForVisible) return;
            this._clearChatActivationTimeouts(!1), this._startupClock.start(), this._chatFallbackArmedAt === null && (this._chatFallbackArmedAt = this._startupClock.now());
            let e = this._parentElement || this._isHeadless ? ci : si,
                t = `Chat activation exceeded ${e}ms`;
            this._chatActivationDiagnosticSent || (this._chatActivationEventTimer = this._startupClock.armActiveDeadline(e, () => {
                this._chatActivationEventTimer = null, !(!this._isEligibleForActivationTimeouts() || this._hasCompletedActivation) && (this._chatActivationDiagnosticSent = !0, window.dispatchEvent(new CustomEvent("ada:error", {
                    detail: {
                        type: "chat.activation.timeout",
                        message: t,
                        timeoutMs: e
                    }
                })), this._routePublishedEvent("ada:chat_frame_timeout", {
                    phase: "activation",
                    message: t,
                    timeoutMs: e
                }));
            })), this._rearmChatFallbackTimeout();
        }
        _rearmChatFallbackTimeout() {
            if (this._hasCompletedActivation) return;
            this._chatFallbackTimer && = (this._chatFallbackTimer(), null);
            let e = this._chatFallbackArmedAt === null ? li : ui - this._startupClock.activeElapsed(this._chatFallbackArmedAt);
            if (e <= 0) {
                this._maybeShowChatTimeoutFallback();
                return;
            }
            this._chatFallbackTimer = this._startupClock.armActiveDeadline(Math.min(li, e), () => {
                this._chatFallbackTimer = null, this._maybeShowChatTimeoutFallback();
            });
        }
        _maybeShowChatTimeoutFallback() {
            !this._isChatVisible() || this._hasCompletedActivation || this._config.showFallbackOnTimeout !== !1 && (this._eventBus.hasExactSubscriberFor("ada:chat_frame_timeout") || this._showChatTimeoutFallback());
        }
        _disconnectCoreChannel() {
            this._nativeVisibilityReported = !1, this._sessionPreparationSent = !1, this._cancelEndChatMinimize(), this._lastEndedEndChatMinimizeSeq = null, this._heldEndChatEvent && this._deliverHeldEndChatEventAfterCall(this._heldEndChatEvent), this._restoreStandaloneDocument ? .(), this._restoreStandaloneDocument = null, this._stopHostViewportSync(), this._setCustomAppFrameStyles({}), this._setHostViewportExpanded(!1), this._coreReadyForResetDelivery = !1, this._cleanupCoreChannelHandlers ? .(), this._cleanupCoreChannelHandlers = null, this._channels.get("core") ? .disconnect(), this._channels.delete("core");
        }
        _showChatTimeoutFallback() {
            let e = this._frames.core;
            e && (this._clearChatActivationTimeouts(), this._activationId = void 0, this._chatActivationDiagnosticSent = !1, this._chatFallbackArmedAt = null, this._coreFrameReloadTimer && = (clearTimeout(this._coreFrameReloadTimer), null), this._hasCompletedActivation = !1, this._showingTimeoutFallback = !0, this._setActivationWaitingForVisible(!1), this._coreStartupFailed = !0, this._eventBus.flushInfoRequests(this._getWindowInfo()), this._syncHostViewport(), this._disconnectCoreChannel(), window.removeEventListener("message", this._handleFallbackMessage), window.addEventListener("message", this._handleFallbackMessage), e.src = qi());
        }
        _reloadCoreFrame() {
            this._cancelEndChatMinimize();
            let e = this._frameManager,
                t = this._frames.core;
            if (!e || !t) return;
            window.removeEventListener("message", this._handleFallbackMessage), this._showingTimeoutFallback = !1, this._hasCompletedActivation = !1, this._activationWorkObserved = !1, this._setActivationWaitingForVisible(!1), this._invalidateStartupConfigForCoreReplacement(), this._disconnectCoreChannel();
            let n = `Frame "core" failed to load within ${W}ms`;
            this._coreFrameReloadTimer && clearTimeout(this._coreFrameReloadTimer), this._coreFrameReloadTimer = setTimeout(() => {
                this._handleFrameTimeout("core", n);
            }, W), t.addEventListener("load", () => {
                this._coreFrameReloadTimer && = (clearTimeout(this._coreFrameReloadTimer), null), Di({
                    name: "core",
                    iframe: t,
                    channels: this._channels,
                    getFrameOrigin: (t) => e.getFrameOrigin(t),
                    setupCoreChannel: (e) => this._setupCoreChannel(e),
                    setupButtonChannel: (e) => this._setupButtonChannel(e),
                    setupIntroChannel: (e) => this._setupIntroChannel(e)
                });
            }, {
                once: !0
            }), t.src = e.buildAssetUrl("sdk", "core.html");
        }
        _invalidateStartupConfigForCoreReplacement() {
            this._nativeVisibilityReported = !1, this._sessionPreparationSent = !1, this._coreReadyForResetDelivery = !1, this._startupConfig = null, this._pendingProactiveClearRequestId = null, this._retirePreChatSurface({
                notifyCore: !1
            }), this._lastEvaluatedUrl = "", this._discardPersistedChatterCandidate(), this._resetCandidateDiscoveryForCoreReplacement();
        }
        _prepareSessionForChannel() {
            this._sessionPreparationSent || this._pendingCoreMessages.some(({
                type: e
            }) => e === "sdk.session.prepare") || (this._parentElement && !this._isHeadless && this._showEmbeddedChat(), this._sendToCore("sdk.session.prepare", void 0, !1, () => {
                this._sessionPreparationSent = !0;
            }));
        }
        _requestActivationAfterCoreReload(e = {}) {
            if (this._waitsForEngagement) {
                this._prepareSessionForChannel(), this._isHeadless || this._reportNativeViewVisibility(this._nativeViewVisible), (this._hasExplicitlyEngaged || e.forceActivate) && this._sendToCore("sdk.activate", void 0);
                return;
            }
            if (this._parentElement) {
                this._showEmbeddedChat(), this._sendToCore("sdk.activate", void 0);
                return;
            }
            if (e.forceActivate && this._isInitialized) {
                this._sendToCore("sdk.activate", void 0);
                return;
            }
            this._isChatOpen && this._sendToCore("sdk.visibility.set", {
                isVisible: !0
            });
        }
        _handleFrameTimeout(e, t) {
            e === "intro" && (this._introChannelFailed = !0, this._introChannelReady = !1, this._stopIntroChannelReadiness(), this._dropPendingIntroDisplay()), j.warn(t), window.dispatchEvent(new CustomEvent("ada:error", {
                detail: {
                    type: "frame.load.timeout",
                    frame: e,
                    message: t
                }
            })), this._routePublishedEvent("ada:chat_frame_timeout", {
                frame: e,
                message: t
            });
        }
        _setConfig(e) {
            let t = { ...ca(Xt(e))
            };
            t.metaFields && = M(t.metaFields), t.sensitiveMetaFields && = M(t.sensitiveMetaFields), delete t.onIdentityTokenConsumed, delete t.isEmbedLoadedPublicationActive;
            let n = mn(t.identityToken);
            delete t.identityToken;
            let r = _n(t.appUrl);
            delete t.appUrl;
            let {
                handle: i,
                cluster: a
            } = wn(t.handle, t.cluster, t.domain), o = typeof t.endpoint == "string" ? yn(t.endpoint) : void 0;
            this._config = Object.freeze({
                ...t,
                crossWindowPersistence: t.crossWindowPersistence !== !1,
                privateMode: !!t.privateMode,
                ...o ? {
                    endpoint: o
                } : {},
                ...n ? {
                    identityToken: n
                } : {},
                ...r ? {
                    appUrl: r
                } : {},
                handle: i,
                cluster: a
            }), this._warnOnUndelegatedLoopbackAppUrl(r), this._assetRolloutCluster = a ? ? Tn(
                import.meta.url) ? ? "ada.support", this._cachedEndpoint = this._config.endpoint ? b(this._config.endpoint) : bn(En(this._config.handle,
                import.meta.url, this._config.cluster));
        }
        _warnOnUndelegatedLoopbackAppUrl(e) {
            if (this._warnedUndelegatedLoopbackAppUrl || !this._isInitialized) return;
            let t = vn(e),
                n = this._frames.core;
            !t || !n || (n.getAttribute("allow") ? ? "").includes(t) || (this._warnedUndelegatedLoopbackAppUrl = !0, j.warn("appUrl points at a loopback host, but the chat frames mounted without the Local Network Access delegation, so the browser cannot prompt for the permission. Set appUrl in the settings the page starts with, then reload the page (or stop() then start())."));
        }
        _clearIdentityToken() {
            if (this._config.identityToken) {
                let e = { ...this._config
                };
                delete e.identityToken, this._setConfig(e);
            }
            this._clearGlobalIdentityToken(), this._onIdentityTokenConsumed ? .();
        }
        _clearGlobalIdentityToken() {
            if (!(typeof window > "u")) try {
                let e = window.adaSettings;
                typeof e == "object" && e && !Array.isArray(e) && "identityToken" in e && delete e.identityToken;
            } catch {}
        }
        _applyResetOverridesToConfig(e, t = {}) {
            let n = t.historyPreserving === !0 || this._config.allowMetaFieldsInReset !== !1,
                r = !n,
                i = n ? e ? .metaFields : void 0,
                a = n ? e ? .sensitiveMetaFields : void 0,
                o = mn(e ? .identityToken);
            this._skipGreetingOnNextCoreConfig = e ? .skipGreeting === !0;
            let s = e !== void 0 && Object.hasOwn(e, "greetingResponseId");
            if (e ? .language || o || i || a || this._config.sensitiveMetaFields !== void 0 || r || !t.historyPreserving && this._deviceToken) {
                let n = {
                    ...this._config,
                    ...e ? .language ? {
                        language: e.language
                    } : {},
                    ...o ? {
                        identityToken: o
                    } : {},
                    ...i ? {
                        metaFields: i
                    } : {},
                    ...a ? {
                        sensitiveMetaFields: a
                    } : {}
                };
                if (!t.historyPreserving) {
                    let e = Mt(a ? ? {}, Nt(this._deviceToken, this._deviceOs ? ? void 0));
                    r && (n.metaFields = M(this._hostMetaFieldsBaseline)), Object.keys(e).length > 0 ? n.sensitiveMetaFields = jn(a, e) : delete n.sensitiveMetaFields;
                }
                o && !i && !r && delete n.metaFields, this._setConfig(n);
            }
            s && (this._greetingResponseIdOnNextCoreConfig = typeof e ? .greetingResponseId == "string" ? e.greetingResponseId : null);
        }
        _sendPendingHistoryPreservingReset() {
            let e = this._historyPreservingResetAfterCoreReload;
            if (!e) return;
            if (e.persistenceScope !== this._persistenceScopeKey()) {
                this._historyPreservingResetAfterCoreReload = null, this._pruneDestructiveOp(e.requestId);
                return;
            }
            let t = this._channels.get("core");
            !t || !this._coreReadyForResetDelivery || (t.send("sdk.reset", {
                ...e.params,
                requestId: e.requestId,
                reactivate: e.reactivate || void 0,
                expectedChatterToken: e.expectedChatterToken ? ? void 0,
                expectedIdentitySession: e.expectedIdentitySession || void 0
            }), this._sendAuthoritativeRuntimeMeta(t), this._isChatVisible() && t.send("sdk.visibility.set", {
                isVisible: !this._waitsForEngagement || this._nativeViewVisible,
                historyPreservingReset: !0
            }));
        }
        _markCoreProtocolReady() {
            this._coreReadyForResetDelivery || (this._coreReadyForResetDelivery = !0, this._sendPendingHistoryPreservingReset(), this._flushPendingCoreMessages());
        }
        _captureHostMetaFieldsBaseline(e) {
            this._hostMetaFieldsBaseline = Object.freeze(jn(e, { ...e ? ? {}
            }));
        }
        _captureAndroidHostNavigation(e) {
            this._androidHostNavigation || = me(window.location, this._config.handle) && typeof e ? .sdkType == "string" && e.sdkType.trim().toUpperCase() === "ANDROID";
        }
        _updateHostedChatPage() {
            this._isBotHostedChatPage || = Pn(window.location, this._config.handle,
                import.meta.url, this._config.cluster), this._isStandaloneChatPage || = this._isBotHostedChatPage;
        }
        _applyStartOverrides(e) {
            if (!e) return;
            let t = this._frameManager !== null && !this._isInitialized,
                n = Object.keys(e).length > 0;
            this._internalHostTelemetry = Yt(e) ? ? this._internalHostTelemetry;
            let r = this._config.handle,
                i = this._config.cluster,
                a = this._config.identityToken,
                o = this._persistenceScopeKey(),
                s = mn(e.identityToken),
                c = s !== void 0 && s !== a,
                l = { ...e
                };
            this._warnAboutLegacySettings(l, l), Object.hasOwn(l, "greeting") && (this._configuredGreetingResponseId = typeof l.greeting == "string" && l.greeting.trim() ? l.greeting.trim() : void 0, delete l.greeting), Object.hasOwn(l, "branding") && (l.branding = Gn(l.branding)), Object.hasOwn(l, "styles") && (Hn("styles"), delete l.styles), "identityToken" in l && (s ? l.identityToken = s : delete l.identityToken);
            let u = { ...this._config
            };
            c && (delete u.sensitiveMetaFields, delete u.metaFields);
            let d = {
                ...u,
                ...l,
                handle: l.handle ? ? this._config.handle,
                cluster: l.cluster === void 0 ? this._config.cluster : l.cluster
            };
            this._setConfig(d), Object.hasOwn(l, "metaFields") ? (this._captureHostMetaFieldsBaseline(l.metaFields), this._captureAndroidHostNavigation(l.metaFields)) : c && this._captureHostMetaFieldsBaseline(void 0);
            let f = o !== this._persistenceScopeKey();
            if (f) {
                if (this._abandonDestructiveWorkForPersistenceScopeChange(), !s && this._config.identityToken) {
                    let e = { ...this._config
                    };
                    delete e.identityToken, this._setConfig(e), this._clearGlobalIdentityToken();
                }
                if (!Object.hasOwn(l, "sensitiveMetaFields")) {
                    let e = { ...this._config
                    };
                    delete e.sensitiveMetaFields, this._setConfig(e);
                }
            }
            c && (this._discardPersistedChatterCandidate(), this._clearCrossWindowPersistenceState(), this._integrationManager ? .resetForIdentityChange()), this._frameManager && (t && n || r !== this._config.handle || i !== this._config.cluster || f || c) && (this._invalidateStartupConfigForCoreReplacement(), this._cleanupCoreChannelHandlers ? .(), this._cleanupCoreChannelHandlers = null, this._frameManager.teardown(), this._frameManager = null), l.eventCallbacks && this._registerInternalEventCallbacks(l.eventCallbacks);
            let {
                zdChatterAuthCallback: p,
                chatFrameTimeoutCallback: m
            } = da({
                adaSettings: l,
                constructorEventCallbacks: l.eventCallbacks,
                subscribeEvent: (e, t) => this._subscribeInternalEvent(e, t)
            });
            p && (this._zdChatterAuthCallback = p), m && (this._chatFrameTimeoutCallback = m), this._updateHostedChatPage();
        }
        _subscribeInternalEvent(e, t) {
            let n = this._registeredInternalEventCallbacks.get(e);
            if (n || (n = /* @__PURE__ */ new Set(), this._registeredInternalEventCallbacks.set(e, n)), n.has(t)) return -1;
            n.add(t);
            let r = this.subscribeEvent(e, t);
            return this._hasPublishedEmbedLoaded && e === "ada:embed_loaded" && queueMicrotask(() => {
                try {
                    I(t(void 0, {
                        eventKey: "ada:embed_loaded"
                    }), "subscribeEvent", "ada:embed_loaded", "subscribeEvent callback for \"ada:embed_loaded\"");
                } catch (e) {
                    j.error("subscribeEvent callback error for \"ada:embed_loaded\":", e), F("subscribeEvent", "ada:embed_loaded", e);
                }
            }), r;
        }
        _registerInternalEventCallbacks(e) {
            for (let [t, n] of Object.entries(e)) typeof n == "function" && this._subscribeInternalEvent(t, n);
        }
        _publishEmbedLoaded() {
            this._hasPublishedEmbedLoaded || (this._hasPublishedEmbedLoaded = !0, this._routePublishedEvent("ada:embed_loaded", void 0), this._isEmbedLoadedPublicationActive ? .() !== !1 && this._invokeWindowCallback("adaEmbedLoadedCallback"));
        }
        _setupServiceWorkerNotificationClickHandler() {
            this._cleanupServiceWorkerNotificationClick || = go(() => this.handleNotification());
        }
        _crossWindowDrawerStorageKey() {
            return `ada_embed_cross_window_drawer_open_${this._config.handle}`;
        }
        _crossWindowLiveChatStorageKey() {
            return `ada_embed_cross_window_live_chat_${this._config.handle}`;
        }
        _safeSessionStorageGet(e) {
            try {
                return window.sessionStorage.getItem(e);
            } catch {
                return null;
            }
        }
        _safeSessionStorageSet(e, t) {
            try {
                window.sessionStorage.setItem(e, t);
            } catch {}
        }
        _safeSessionStorageRemove(e) {
            try {
                window.sessionStorage.removeItem(e);
            } catch {}
        }
        _persistCrossWindowDrawerState() {
            if (!(!this._config.crossWindowPersistence || this._parentElement || this._isHeadless)) {
                if (!this._crossWindowLiveChatActive) {
                    this._safeSessionStorageRemove(this._crossWindowDrawerStorageKey());
                    return;
                }
                this._pendingCrossWindowDrawerRestore || this._safeSessionStorageSet(this._crossWindowDrawerStorageKey(), this._isChatOpen ? "1" : "0");
            }
        }
        _setCrossWindowLiveChatActive(e) {
            if (e || (this._pendingCrossWindowDrawerRestore = !1, this._candidateDiscoveryRequestedForCore = !0, (this._pendingCandidateDiscoveryRequestId !== null || this._scheduledCandidateDiscoveryGeneration !== null || this._persistedChatterCandidate !== null || this._pendingSessionResume !== null || this._pendingSessionResumeVisibility !== null || this._resumedChatterAwaitingAnnouncement !== null) && this._discardPersistedChatterCandidate({
                    preserveSeed: !0
                })), this._crossWindowLiveChatActive = e, !this._config.crossWindowPersistence) return;
            let t = this._crossWindowDrawerStorageKey(),
                n = this._crossWindowLiveChatStorageKey();
            if (e) {
                this._safeSessionStorageSet(n, "1"), this._persistCrossWindowDrawerState();
                return;
            }
            this._safeSessionStorageRemove(n), this._safeSessionStorageRemove(t);
        }
        _clearCrossWindowPersistenceState() {
            this._crossWindowLiveChatActive = !1, this._pendingCrossWindowDrawerRestore = !1, this._safeSessionStorageRemove(this._crossWindowDrawerStorageKey()), this._safeSessionStorageRemove(this._crossWindowLiveChatStorageKey());
        }
        _armCrossWindowDrawerRestore() {
            if (!this._config.crossWindowPersistence || this._parentElement || this._isHeadless) {
                this._pendingCrossWindowDrawerRestore = !1;
                return;
            }
            this._pendingCrossWindowDrawerRestore = this._safeSessionStorageGet(this._crossWindowDrawerStorageKey()) === "1" && this._safeSessionStorageGet(this._crossWindowLiveChatStorageKey()) === "1";
        }
        _clearUnreadCount() {
            this._resetServerUnreadCount(), this._acknowledgedUnreadToken = this._chatterToken, !(this._unreadCount === 0 && this._seededUnread === 0) && (this._unreadCount = 0, this._seededUnread = 0, this._seededUnreadToken = null, this._syncButtonUnreadCount());
        }
        _chatterApiUrl(e, t) {
            let n = new URL(`${this._cachedEndpoint}chatters/${encodeURIComponent(e)}/${t}`, window.location.href);
            return n.searchParams.set("ada_request_origin", "messaging"), n.toString();
        }
        _resetServerUnreadCount() {
            let e = this._chatterToken;
            if (!e) {
                this._pendingUnreadAcknowledgement = !0;
                return;
            }
            this._pendingUnreadAcknowledgement = !1, fetch(this._chatterApiUrl(e, "live_chat_unread_amount"), {
                method: "DELETE"
            }).catch(() => {});
        }
        _setChatterToken(e) {
            if (this._ignoredChatterAnnouncementToken === e) return this._ignoredChatterAnnouncementToken = null, !1;
            this._ignoredChatterAnnouncementToken = null;
            let t = this._identityTokenConsumedAwaitingChatter || this._identitySessionChatterToken === e;
            this._identityTokenConsumedAwaitingChatter ? this._identitySessionChatterToken = e : this._identitySessionChatterToken !== e && (this._identitySessionChatterToken = null), this._identityTokenConsumedAwaitingChatter = !1;
            let n = this._historyPreservingResetAfterCoreReload;
            return n ? .expectedChatterToken && n.expectedChatterToken !== e ? this._historyPreservingResetAfterCoreReload = null : n ? .expectedChatterToken === null && (n.reactivate ? (n.expectedChatterToken = e, n.expectedIdentitySession = t) : this._historyPreservingResetAfterCoreReload = null), this._chatterToken === e ? !1 : (this._persistedChatterCandidate === e || this._resumedChatterAwaitingAnnouncement === e ? (this._persistedChatterCandidate = null, this._resumedChatterAwaitingAnnouncement = null, this._candidateGeneration = this._nextPositiveSafeInteger(this._candidateGeneration)) : (this._discardPersistedChatterCandidate(), this._invalidateNotificationStatusLookup()), this._seededUnreadToken !== null && this._seededUnreadToken !== e && (this._seededUnread = 0, this._seededUnreadToken = null, this._unreadCount === 0 && this._syncButtonUnreadCount()), this._chatterToken !== null && (this._resetGeneration += 1), this._chatterToken = e, this._pendingUnreadAcknowledgement ? (this._clearUnreadCount(), !0) : (this._seedUnreadCountFromServer(e), !0));
        }
        _scheduleCandidateDiscovery() {
            if (this._isHeadless || !this._coreReadyForCandidateDiscovery || !this._isInitialized || this._candidateDiscoveryRequestedForCore || this._candidateDiscoveryBlockedForCore || this._scheduledCandidateDiscoveryGeneration !== null || this._hasExplicitlyEngaged || this._config.identityToken || this._isPrivateMode || this._chatterToken !== null) return;
            let e = this._candidateDiscoveryGeneration;
            this._scheduledCandidateDiscoveryGeneration = e, queueMicrotask(() => {
                if (this._scheduledCandidateDiscoveryGeneration !== e || (this._scheduledCandidateDiscoveryGeneration = null, this._isHeadless || this._candidateDiscoveryGeneration !== e || !this._coreReadyForCandidateDiscovery || !this._isInitialized || this._candidateDiscoveryRequestedForCore || this._candidateDiscoveryBlockedForCore || this._hasExplicitlyEngaged || this._config.identityToken || this._isPrivateMode || this._chatterToken !== null)) return;
                this._candidateDiscoveryRequestSeq = this._nextPositiveSafeInteger(this._candidateDiscoveryRequestSeq);
                let t = this._candidateDiscoveryRequestSeq;
                this._candidateDiscoveryRequestedForCore = !0, this._pendingCandidateDiscoveryRequestId = t, this._sendToCore("sdk.session.candidate.request", {
                    requestId: t
                });
            });
        }
        _setPersistedChatterCandidate({
            chatterToken: e,
            requestId: t
        }) {
            if (t !== this._pendingCandidateDiscoveryRequestId || !this._isInitialized || !e || this._hasExplicitlyEngaged || this._chatterToken !== null || (this._pendingCandidateDiscoveryRequestId = null, this._resumedChatterAwaitingAnnouncement === e || this._persistedChatterCandidate === e && (this._notificationStatusRequest ? .chatterToken === e || this._notificationStatusCache ? .chatterToken === e || this._pendingSessionResume ? .chatterToken === e))) return;
            this._discardPersistedChatterCandidate(), this._persistedChatterCandidate = e, this._candidateGeneration = this._nextPositiveSafeInteger(this._candidateGeneration);
            let n = this._candidateGeneration;
            this._inspectPersistedChatterCandidate(e, n);
        }
        get _waitsForEngagement() {
            return this._isHeadless || this._internalHostTelemetry ? .mobileShell === "messaging-sdk" && this._internalHostTelemetry.nativeViewVisibilitySupported === !0;
        }
        _reportNativeViewVisibility(e) {
            this._isHeadless || !this._waitsForEngagement || this._nativeVisibilityReported && e === this._nativeViewVisible || (this._nativeViewVisible = e, e && this._beginExplicitEngagement(), this._sendToCore("sdk.visibility.set", {
                isVisible: e
            }, !1, () => {
                this._nativeVisibilityReported = !0;
            }));
        }
        _beginExplicitEngagement() {
            this._hasExplicitlyEngaged = !0, this._pendingCrossWindowDrawerRestore = !1, this._persistCrossWindowDrawerState(), this._discardPersistedChatterCandidate({
                preserveSeed: !0
            });
        }
        async _inspectPersistedChatterCandidate(e, t) {
            let n = await this._getNotificationStatus(e);
            if (this._candidateGeneration !== t || this._persistedChatterCandidate !== e || this._chatterToken !== null) return;
            if (!n) {
                this._discardPersistedChatterCandidate({
                    preserveSeed: !0
                }), this._clearCrossWindowPersistenceState();
                return;
            }
            if (this._applyUnreadStatus(e, n), !n.isLiveState) {
                this._discardPersistedChatterCandidate({
                    preserveSeed: !0
                }), this._clearCrossWindowPersistenceState();
                return;
            }
            if (this._pendingSessionResume !== null) return;
            let r = this._nextSessionResumeRequestId();
            this._pendingSessionResume = {
                chatterToken: e,
                requestId: r
            }, this._sendToCore("sdk.session.resume", {
                chatterToken: e,
                requestId: r
            });
        }
        _handleSessionResumeResult(e) {
            let t = this._pendingSessionResume;
            if (!t || t.chatterToken !== e.chatterToken || t.requestId !== e.requestId || this._persistedChatterCandidate !== e.chatterToken && this._chatterToken !== e.chatterToken) return;
            if (this._pendingSessionResume = null, !e.resumed) {
                this._persistedChatterCandidate === e.chatterToken && this._discardPersistedChatterCandidate({
                    preserveSeed: !0
                }), this._clearCrossWindowPersistenceState();
                return;
            }
            this._persistedChatterCandidate === e.chatterToken && (this._persistedChatterCandidate = null, this._candidateGeneration = this._nextPositiveSafeInteger(this._candidateGeneration), this._resumedChatterAwaitingAnnouncement = e.chatterToken);
            let n = this._pendingCrossWindowDrawerRestore;
            if (this._pendingCrossWindowDrawerRestore = !1, this._crossWindowLiveChatActive = !0, n && !this._isChatOpen) {
                this._pendingSessionResumeVisibility = {
                    chatterToken: e.chatterToken,
                    requestId: e.requestId
                }, this._sendToCore("sdk.session.resume.visibility", {
                    ...this._pendingSessionResumeVisibility,
                    isVisible: !0
                });
                return;
            }
            this._persistCrossWindowDrawerState();
        }
        _handleSessionResumeVisibilityResult(e) {
            let t = this._pendingSessionResumeVisibility;
            if (!(!t || t.chatterToken !== e.chatterToken || t.requestId !== e.requestId || this._resumedChatterAwaitingAnnouncement !== e.chatterToken && this._chatterToken !== e.chatterToken)) {
                if (this._pendingSessionResumeVisibility = null, !e.visible) {
                    this._discardPersistedChatterCandidate({
                        preserveSeed: !0
                    }), this._clearCrossWindowPersistenceState();
                    return;
                }
                this._openChat({
                    markExplicitEngagement: !1,
                    confirmedRestoredVisibility: !0
                });
            }
        }
        _nextSessionResumeRequestId() {
            return this._sessionResumeRequestSeq = this._nextPositiveSafeInteger(this._sessionResumeRequestSeq), this._sessionResumeRequestSeq;
        }
        _nextPositiveSafeInteger(e) {
            return e >= 2 ** 53 - 1 ? 1 : e + 1;
        }
        _discardPersistedChatterCandidate({
            preserveSeed: e = !1
        } = {}) {
            let t = this._persistedChatterCandidate;
            this._persistedChatterCandidate = null, this._cancelCandidateDiscoveryRequest(), this._resumedChatterAwaitingAnnouncement = null, this._pendingSessionResume = null, this._pendingSessionResumeVisibility = null, this._candidateGeneration = this._nextPositiveSafeInteger(this._candidateGeneration), this._invalidateNotificationStatusLookup();
            let n = t ? ? this._seededUnreadToken;
            !e && n !== null && this._seededUnreadToken === n && this._chatterToken !== n && (this._seededUnread = 0, this._seededUnreadToken = null, this._unreadCount === 0 && this._syncButtonUnreadCount());
        }
        _cancelCandidateDiscoveryRequest() {
            this._candidateDiscoveryGeneration = this._nextPositiveSafeInteger(this._candidateDiscoveryGeneration), this._scheduledCandidateDiscoveryGeneration = null, this._pendingCandidateDiscoveryRequestId = null;
        }
        _resetCandidateDiscoveryForCoreReplacement() {
            this._cancelCandidateDiscoveryRequest(), this._coreStartupFailed = !1, this._coreReadyForCandidateDiscovery = !1, this._candidateDiscoveryBlockedForCore = !1, this._candidateDiscoveryRequestedForCore = !1;
        }
        _invalidateNotificationStatusLookup() {
            this._notificationStatusTimeout && = (clearTimeout(this._notificationStatusTimeout), null), this._notificationStatusAbortController ? .abort(), this._notificationStatusAbortController = null, this._notificationStatusRequest = null, this._notificationStatusCache = null;
        }
        _getNotificationStatus(e) {
            if (this._notificationStatusCache ? .chatterToken === e) return Promise.resolve(this._notificationStatusCache.status);
            if (this._notificationStatusRequest ? .chatterToken === e) return this._notificationStatusRequest.promise;
            this._invalidateNotificationStatusLookup();
            let t = new AbortController();
            this._notificationStatusAbortController = t, this._notificationStatusRequestSeq = this._nextPositiveSafeInteger(this._notificationStatusRequestSeq);
            let n = this._notificationStatusRequestSeq,
                r = (async () => {
                    try {
                        let r = await fetch(this._chatterApiUrl(e, "notification_status"), {
                            signal: t.signal
                        });
                        if (!r.ok) return null;
                        let i = await r.json();
                        if (typeof i.unread_amount != "number" || !Number.isFinite(i.unread_amount) || typeof i.is_live_state != "boolean") return null;
                        let a = {
                            unreadAmount: Math.max(0, i.unread_amount),
                            isLiveState: i.is_live_state
                        };
                        return this._notificationStatusRequest ? .generation === n && this._notificationStatusRequest.chatterToken === e && this._notificationStatusAbortController === t && (this._persistedChatterCandidate === e || this._chatterToken === e || this._resumedChatterAwaitingAnnouncement === e) && (this._notificationStatusCache = {
                            chatterToken: e,
                            status: a
                        }), a;
                    } catch {
                        return null;
                    } finally {
                        this._notificationStatusRequest ? .generation === n && this._notificationStatusRequest.chatterToken === e && this._notificationStatusAbortController === t && (this._notificationStatusTimeout && = (clearTimeout(this._notificationStatusTimeout), null), this._notificationStatusRequest = null, this._notificationStatusAbortController = null);
                    }
                })();
            return this._notificationStatusRequest = {
                chatterToken: e,
                generation: n,
                promise: r
            }, this._notificationStatusTimeout = setTimeout(() => {
                if (!(this._notificationStatusRequest ? .generation !== n || this._notificationStatusRequest.chatterToken !== e || this._notificationStatusAbortController !== t)) {
                    if (this._persistedChatterCandidate === e && this._chatterToken === null) {
                        this._discardPersistedChatterCandidate({
                            preserveSeed: !0
                        }), this._clearCrossWindowPersistenceState();
                        return;
                    }
                    this._invalidateNotificationStatusLookup();
                }
            }, bo), r;
        }
        async _seedUnreadCountFromServer(e) {
            let t = await this._getNotificationStatus(e);
            !t || this._chatterToken !== e || this._applyUnreadStatus(e, t);
        }
        _applyUnreadStatus(e, t) {
            t.unreadAmount <= 0 || this._chatterToken !== e && this._persistedChatterCandidate !== e || this._acknowledgedUnreadToken === e || this._unreadCount > 0 || this._isChatVisible() || this._seededUnreadToken === e && this._seededUnread === t.unreadAmount || (this._seededUnread = t.unreadAmount, this._seededUnreadToken = e, this._syncButtonUnreadCount());
        }
        _showEmbeddedChat() {
            this._clearUnreadCount();
            let e = this._frames.core;
            e && (P(e, Lr(this._align, !0)), this._syncChatViewportHeight(e));
        }
        _isChatVisible() {
            return this._isHeadless ? !1 : this._parentElement ? this._isInitialized : this._isChatOpen;
        }
        _isNativeViewVisible() {
            return this._waitsForEngagement ? !this._isHeadless && this._nativeViewVisible : this._isChatVisible();
        }
        _getWindowInfo() {
            return {
                isChatOpen: this._isNativeViewVisible(),
                isDrawerOpen: this._parentElement ? !1 : this._isChatOpen,
                hasActiveChatter: this._hasActiveChatter,
                hasClosedChat: !this._isHeadless && !this._parentElement && this._hasChatOpened && !this._isChatOpen
            };
        }
        _getProactiveRuntimeDependencies() {
            return {
                handle: this._config.handle,
                language: this._config.language,
                parentElement: this._parentElement,
                hasFloatingWidgetChrome: this._hasFloatingWidgetChrome,
                channels: this._channels,
                frames: this._frames,
                getAlign: () => this._align,
                getIsChatOpen: () => this._isChatOpen,
                getHasChatOpened: () => this._hasChatOpened,
                getHasIntroShown: () => this._hasIntroShown,
                setHasIntroShown: (e) => {
                    this._hasIntroShown = e;
                },
                markIntroShown: () => this._markGreetingIntroShown(),
                resetIntroShownForNavigation: () => {
                    this._hasIntroShown = !1;
                },
                sendToCore: (e, t) => this._sendToCore(e, t),
                routePublishedEvent: (e, t) => this._routePublishedEvent(e, t),
                getStartupConfig: () => this._startupConfig,
                getIntroTimer: () => this._introTimer,
                setIntroTimer: (e) => {
                    this._introTimer = e;
                },
                getProactiveTimers: () => this._proactiveTimers,
                retirePreChatSurface: () => this._retirePreChatSurface(),
                beginProactiveIntent: () => this._beginProactiveIntent(),
                isCurrentProactiveIntent: (e) => e === this._currentProactiveIntentId,
                setIntroShowing: (e) => {
                    this._introShowing = e;
                },
                getLastEvaluatedUrl: () => this._lastEvaluatedUrl,
                setLastEvaluatedUrl: (e) => {
                    this._lastEvaluatedUrl = e;
                },
                showOrQueueIntroDisplay: (e, t) => this._showOrQueueIntroDisplay(e, t),
                showOrQueueEmojiDisplay: (e) => this._showOrQueueEmojiDisplay(e),
                ensureIntroFrame: () => this._ensureIntroFrame(),
                beginGreetingDisplay: () => this._beginGreetingDisplay()
            };
        }
        _scheduleIntro(e) {
            !this._isInitialized || !this._hasFloatingWidgetChrome || eo(this._getProactiveRuntimeDependencies(), e);
        }
        _patchLocationHistory() {
            this._locationHistoryState = Wi(this._locationHistoryState, () => this._onLocationChange(), this._isLegacyLoader);
        }
        _unpatchLocationHistory() {
            this._locationHistoryState = Gi(this._locationHistoryState);
        }
        _markGreetingIntroShown() {
            this._wasIntroShown = !0, !this._introShown && (this._introShown = !0, this._scheduleRuntimeMetaSync());
        }
        _markProactiveIntroShown() {
            this._introShown || (this._introShown = !0, this._scheduleRuntimeMetaSync());
        }
        _initialUrlMetaField() {
            return this._isStandaloneChatPage ? null : window.location.href;
        }
        _sdkAssetsBase() {
            return Ti(
                import.meta.url, "eb157faa62f6aedb4b1659a9563b247e78b9d989", "https://static.ada.support/messaging/");
        }
        _currentRuntimeMeta() {
            let e = this._initialUrlMetaField();
            return {
                ...e === null ? {} : {
                    initialURL: e
                },
                introShown: this._introShown
            };
        }
        _cancelScheduledRuntimeMetaSync() {
            this._runtimeMetaSyncScheduled && = (this._runtimeMetaGeneration += 1, !1);
        }
        _sendAuthoritativeRuntimeMeta(e) {
            this._cancelScheduledRuntimeMetaSync(), this._pendingCoreMessages = this._pendingCoreMessages.filter((e) => e.type !== "sdk.runtimeMeta.set"), e.send("sdk.runtimeMeta.set", this._currentRuntimeMeta());
        }
        _scheduleRuntimeMetaSync() {
            if (this._runtimeMetaSyncScheduled) return;
            this._runtimeMetaSyncScheduled = !0;
            let e = this._runtimeMetaGeneration;
            queueMicrotask(() => {
                if (e !== this._runtimeMetaGeneration || (this._runtimeMetaSyncScheduled = !1, !this._isInitialized)) return;
                let t = this._currentRuntimeMeta();
                if (!this._coreReadyForResetDelivery) {
                    this._queuePendingCoreMessage("sdk.runtimeMeta.set", t);
                    return;
                }
                this._sendToCore("sdk.runtimeMeta.set", t);
            });
        }
        _onLocationChange() {
            this._scheduleRuntimeMetaSync(), to(this._getProactiveRuntimeDependencies());
        }
        _evaluateProactiveConditions() {
            no(this._getProactiveRuntimeDependencies());
        }
        get _align() {
            return this._config.align === "left" || this._config.align === "auto" && (this._config.language === "ar" || this._config.language === "he") ? "left" : "right";
        }
        get _isTextButton() {
            let e = this._startupConfig;
            return !!(e ? .button ? .textEnabled && e ? .button ? .text);
        }
        get _isHeadless() {
            return this._config.headless === !0;
        }
        _requireProgrammaticControl() {
            if (this._config.enableProgrammaticControl !== !0) throw Error(_o);
        }
        _sendToCore(e, t, n = !1, r) {
            let i = this._channels.get("core");
            return !this._frameManager || !i || e === "sdk.info.get" && !this._coreReadyForCandidateDiscovery || !this._coreReadyForResetDelivery && this._historyPreservingResetAfterCoreReload !== null ? (this._queuePendingCoreMessage(e, t, n, r), !1) : (i.send(e, t), r ? .(), !0);
        }
        _createFrameManager(e) {
            return new Ji({
                handle: this._config.handle,
                cluster: this._assetRolloutCluster,
                assetsOrigin: this._sdkAssetsBase(),
                commitSha: "eb157faa62f6aedb4b1659a9563b247e78b9d989",
                container: e,
                onFrameTimeout: (e, t) => this._handleFrameTimeout(e, t),
                setupCoreChannel: (e) => this._setupCoreChannel(e),
                setupButtonChannel: (e) => this._setupButtonChannel(e),
                setupIntroChannel: (e) => this._setupIntroChannel(e)
            });
        }
    },
    ko = "ada-functional-storage",
    Ao = "botAssignment";

function q(e) {
    return typeof e == "object" && !!e && !Array.isArray(e);
}
async function jo(e, t, n = {}) {
    let r = u(t ? ? "ada.support");
    if (!r || !a.has(r) || typeof e != "string" || !/^[a-z0-9][a-z0-9-]*$/i.test(e)) return null;
    let i = typeof AbortController == "function" ? new AbortController() : null,
        o, s = !1,
        c = new Promise((e) => {
            o = setTimeout(() => {
                s = !0, e(null), i ? .abort();
            }, n.timeoutMs ? ? 2e3);
        }),
        l = async (e) => {
            try {
                let t = await (n.fetchImpl ? ? fetch)(e, {
                    credentials: "omit",
                    signal: i ? .signal
                });
                if (t.ok) {
                    let e = await t.json(),
                        n = q(e) ? e.client ? ? e.data ? ? e : e;
                    if (q(n)) return n;
                }
            } catch {}
            return null;
        },
        f = async () => {
            let t = r === sn,
                i = () => {
                    let i = bn(En(e,
                            import.meta.url, r)),
                        a = n.endpoint ? yn(n.endpoint) : i,
                        o = t ? new URL("/api/", Ti(
                            import.meta.url, "eb157faa62f6aedb4b1659a9563b247e78b9d989", "https://static.ada.support/messaging/")) : new URL(i);
                    try {
                        let e = new URL(a);
                        (!t || C(e.hostname, {
                            additionalHosts: p
                        })) && (o = e);
                    } catch {}
                    return new URL("?ada_request_origin=embed", o).href;
                },
                a = await l(t ? i() : `https://rollout.${r}/${e}/client.json`);
            if (!a && !t && !s && (a = await l(i())), !a) return null;
            let o = a.alternative_bot,
                c = q(o) && typeof o.handle == "string" && typeof o.rollout == "number" ? {
                    handle: o.handle,
                    rollout: o.rollout
                } : null;
            return {
                chat: ye(a) ? ? void 0,
                launchControls: !t && !d(r) && typeof a.rollout == "number" && Number.isFinite(a.rollout) ? {
                    rollout: a.rollout,
                    alternativeBot: c
                } : null
            };
        };
    try {
        return await Promise.race([f().catch(() => null), c]);
    } finally {
        clearTimeout(o);
    }
}

function Mo(e, t) {
    if (!e) return null;
    try {
        let n = e.getItem(ko),
            r = n === null ? null : JSON.parse(n);
        if (!q(r) || !q(r.botAssignment)) return null;
        let i = r[Ao][t];
        return i === "primary" || i === "alternative" ? i : null;
    } catch {
        return null;
    }
}

function No(e, t, n) {
    if (e) try {
        let r = e.getItem(ko),
            i = r === null ? {} : JSON.parse(r);
        if (!q(i)) return;
        let a = i[Ao];
        if (a !== void 0 && !q(a)) return;
        e.setItem(ko, JSON.stringify({
            ...i,
            [Ao]: {
                ...a ? ? {},
                [t] : n
            }
        }));
    } catch {}
}

function Po(e) {
    return typeof e == "number" && Number.isFinite(e) ? Math.max(0, Math.min(1, e)) : null;
}

function Fo(e) {
    try {
        return new URLSearchParams(e).get("adaBotHandleOverride") ? .trim() || null;
    } catch {
        return null;
    }
}

function Io(e) {
    let {
        primaryHandle: t,
        config: n,
        storage: r
    } = e, i = e.random ? ? Math.random, a = e.isShown ? ? nr;
    if (!n) return {
        kind: "unchanged"
    };
    let o = n.alternativeBot,
        s = typeof o ? .handle == "string" ? o.handle.trim() : "",
        c = s && s !== t ? s : null,
        l = e.previewHandle ? .trim();
    if (l && (l === t || l === c)) return {
        kind: "serve",
        handle: l
    };
    if (!o || !c || !Number.isFinite(o.rollout) || o.rollout <= 0 || !a(t, Po(e.rolloutOverride) ? ? n.rollout)) return {
        kind: "unchanged"
    };
    if (o.rollout >= 1) return {
        kind: "serve",
        handle: c
    };
    let u = Mo(r, t),
        d = u ? ? (i() < o.rollout ? "alternative" : "primary");
    return u || No(r, t, d), {
        kind: "serve",
        handle: d === "alternative" ? c : t
    };
}
//#endregion
//#region src/client/embed-lifecycle.ts
var Lo = Symbol.for("ada-cx/messaging-sdk/embed-stopped");

function Ro(e, t) {
    Object.defineProperty(e, Lo, {
        get: t,
        enumerable: !1,
        configurable: !1
    });
}
//#endregion
//#region src/client/embed-interface.ts
var zo = "Actions cannot be called until Embed has been instantiated. Try running `adaEmbed.start({...})`.",
    Bo = "Ada Embed has already been started.",
    Vo = "Ada Embed start was interrupted by stop() or destroy().",
    Ho = "Messaging supports only generative features; scripted/declarative campaigns and Answers are ignored.";

function J(e) {
    return typeof e == "object" && !!e && !Array.isArray(e);
}

function Uo(e) {
    return J(e) ? Object.values(e).every((e) => typeof e == "string") : !1;
}
var Wo = {
        start: [1, (e) => e.length <= 1 && (e[0] === void 0 || J(e[0]))],
        stop: [0, (e) => e.length === 0],
        toggle: [0, (e) => e.length === 0],
        deleteHistory: [0, (e) => e.length === 0],
        reset: [1, (e) => e.length <= 1 && (e[0] === void 0 || J(e[0]))],
        setMetaFields: [1, (e) => e.length === 1 && J(e[0])],
        setSensitiveMetaFields: [1, (e) => e.length === 1 && J(e[0])],
        setTestModeBanner: [1, (e) => e.length === 1 && (e[0] === null || typeof e[0] == "string")],
        getInfo: [0, (e) => e.length === 0],
        getMetaFields: [0, (e) => e.length === 0],
        isOpen: [0, (e) => e.length === 0],
        getConversation: [0, (e) => e.length === 0],
        getMessages: [0, (e) => e.length === 0],
        setComposerText: [1, (e) => e.length === 1 && typeof e[0] == "string"],
        setDelegate: [1, (e) => e.length === 1 && (e[0] === null || e[0] === void 0 || J(e[0]))],
        trackEvent: [3, (e) => e.length >= 1 && e.length <= 3 && typeof e[0] == "string" && (e[1] === void 0 || typeof e[1] == "number") && (e[2] === void 0 || J(e[2]))],
        subscribeEvent: [2, (e) => e.length === 2 && typeof e[0] == "string" && typeof e[1] == "function"],
        unsubscribeEvent: [1, (e) => e.length === 1 && typeof e[0] == "number"],
        subscribeAll: [1, (e) => e.length === 1 && typeof e[0] == "function"],
        open: [0, (e) => e.length === 0],
        close: [0, (e) => e.length === 0],
        setLanguage: [1, (e) => e.length === 1 && typeof e[0] == "string"],
        setTheme: [1, (e) => e.length === 1 && (e[0] === "light" || e[0] === "dark" || e[0] === "auto")],
        setDeviceToken: [1, (e) => e.length === 1 && typeof e[0] == "string"],
        triggerPlaybook: [2, (e) => e.length >= 1 && e.length <= 2 && typeof e[0] == "string" && (e[1] === void 0 || J(e[1]) && (e[1].metaFields === void 0 || J(e[1].metaFields)) && (e[1].sensitiveMetaFields === void 0 || J(e[1].sensitiveMetaFields)))],
        sendMessage: [1, (e) => e.length === 1 && typeof e[0] == "string"],
        selectQuickReply: [2, (e) => e.length === 2 && typeof e[0] == "string" && e[0].trim().length > 0 && typeof e[1] == "number" && Number.isInteger(e[1]) && e[1] >= 0],
        handleNotification: [0, (e) => e.length === 0],
        requestNotifications: [0, (e) => e.length === 0],
        createProactive: [3, (e) => e.length >= 1 && e.length <= 3 && typeof e[0] == "string" && (e[1] === void 0 || typeof e[1] == "number") && (e[2] === void 0 || typeof e[2] == "string")],
        triggerCampaign: [2, (e) => e.length >= 1 && e.length <= 2 && typeof e[0] == "string" && (e[1] === void 0 || J(e[1]))],
        evaluateCampaignConditions: [1, (e) => e.length <= 1 && (e[0] === void 0 || J(e[0]))],
        closeCampaign: [0, (e) => e.length === 0],
        triggerAnswer: [1, (e) => e.length === 1 && typeof e[0] == "string"],
        triggerProactive: [2, (e) => e.length >= 1 && e.length <= 2 && (typeof e[0] == "string" || J(e[0]) && typeof e[0].messageKey == "string") && (e[1] === void 0 || Uo(e[1]))],
        triggerGreeting: [1, (e) => e.length <= 1 && (e[0] === void 0 || typeof e[0] == "string")],
        destroy: [0, (e) => e.length === 0]
    },
    Go = Object.freeze({
        ...Wo,
        start: [1, (e) => e.length <= 1 && (e.length === 0 || J(e[0]))],
        reset: [1, (e) => e.length <= 1 && (e.length === 0 || J(e[0]))],
        evaluateCampaignConditions: [1, (e) => e.length <= 1 && (e.length === 0 || J(e[0]))],
        triggerGreeting: [1, (e) => e.length <= 1 && (e.length === 0 || typeof e[0] == "string")]
    });

function Ko() {
    return Error(zo);
}

function qo(e) {
    j.warn(`${e}() is deprecated and not supported. ${Ho}`);
}

function Jo(e, t) {
    return t ? {
        ...e,
        ...t,
        eventCallbacks: {
            ...e.eventCallbacks ? ? {},
            ...t.eventCallbacks ? ? {}
        }
    } : { ...e
    };
}

function Yo(e) {
    if (!e) return;
    let t = { ...ca(Xt(e))
        },
        n = gn(t.crossWindowPersistence);
    return n === void 0 ? delete t.crossWindowPersistence : t.crossWindowPersistence = n, t;
}

function Xo(e) {
    let t = typeof e.handle == "string" ? e.handle.trim() : "";
    if (!t) throw Error("Ada Embed: start(settings) requires a handle when no client has been created yet.");
    return {
        ...e,
        handle: t
    };
}

function Zo(e) {
    let t = Zn();
    delete t.identityToken, delete t.deviceToken, delete t.metaFields, delete t.sensitiveMetaFields, delete t.greeting, delete t.eventCallbacks;
    let n = window.adaSettings ? .zdChatterAuthCallback;
    return {
        handle: e.handle,
        cluster: e.cluster,
        domain: e.domain,
        endpoint: e.endpoint,
        rolloutOverride: e.rolloutOverride,
        ...t,
        ...typeof n == "function" ? {
            zdChatterAuthCallback: n
        } : {}
    };
}

function Qo() {
    try {
        return window.localStorage;
    } catch {
        return null;
    }
}
var $o = Symbol.for("ada.messaging.legacyLoaderHandoff");

function es(e) {
    let t = e[$o];
    t ? .();
}

function ts(e) {
    let t = null,
        n = !1,
        r = 0,
        i = null,
        a = !1,
        o = !1,
        s = !1,
        c = Jo(Zn(), Yo(e)),
        l = Yt(e);

    function u() {
        let e = { ...c
        };
        delete e.identityToken, c = e;
    }
    let d = 1,
        f, p = !1,
        m = /* @__PURE__ */ new Map(),
        h = /* @__PURE__ */ new Map();

    function g() {
        if (!t) throw Ko();
        return t;
    }

    function _(e) {
        if (!i) return e(g());
        let n = t,
            a = r,
            o = new H(Vo, "start_interrupted");
        return i.then(() => {
            if (!n || t !== n) throw o;
            return e(n);
        }, (e) => {
            throw r === a ? e : o;
        });
    }

    function v(e) {
        for (let t of m.values()) t.actualId === null && (t.actualId = e.subscribeEvent(t.key, t.callback));
        for (let t of h.values()) t.actualId === null && (t.actualId = e.subscribeAll(t.callback));
    }

    function y(e) {
        if (p) try {
            e.setDelegate(f);
        } catch (e) {
            j.warn("setDelegate ignored during start():", e instanceof Error ? e.message : e);
        }
    }

    function b() {
        for (let e of m.values()) e.actualId = null;
        for (let e of h.values()) e.actualId = null;
    }

    function x() {
        m.clear(), h.clear();
    }

    function S() {
        f = void 0, p = !1;
    }
    async function ee(e) {
        if (t) throw new H(Bo, "start_already_active");
        let n = te(e);
        i = n;
        try {
            await n;
        } finally {
            i === n && (i = null);
        }
    }
    async function te(e) {
        let i = Yo(e),
            d = Yt(e) ? ? l,
            f = Jo(o ? Zo(c) : c, i),
            p = Jt(Xo({
                ...f,
                lazy: !0
            }), d ? ? (n ? {
                surface: "browser",
                hostPlatform: "web",
                webSdkOrigin: "legacy"
            } : void 0));
        s && Object.defineProperty(p, Xn, {
            value: !0
        }), p.onIdentityTokenConsumed = u;
        let m = null,
            h = () => {
                if (t !== m) throw new H(Vo, "start_interrupted");
            };
        p.isEmbedLoadedPublicationActive = () => t === m;
        try {
            let e = !s && typeof window < "u" && window.adaSettings,
                n = ("headless" in p ? p.headless : e && typeof e == "object" && !Array.isArray(e) && e.headless) === !0;
            m = new Oo(p), c = f, l = d, t = m, r++, y(m), v(m), await Promise.resolve(), h();
            let {
                handle: i,
                cluster: u
            } = wn(p.handle, p.cluster, p.domain), g = u ? ? Tn(
                import.meta.url) ? ? void 0, _ = (e) => jo(e, g, {
                endpoint: e === i ? p.endpoint : void 0
            }), x = l ? .surface === "mobile" ? null : await _(i);
            h();
            let S = Io({
                    primaryHandle: i,
                    config: p.testMode || Pn(window.location, i,
                        import.meta.url, u) ? null : x ? .launchControls ? ? null,
                    rolloutOverride: p.rolloutOverride,
                    previewHandle: Fo(window.location.search),
                    storage: Qo()
                }),
                ee = S.kind === "serve" && S.handle !== i ? await _(S.handle) : x;
            if (h(), !n && ee ? .chat === !1) {
                j.dataLoss("Sorry, please turn on the web chat integration in your bot's settings."), t = null, b();
                try {
                    m.destroy();
                } catch (e) {
                    j.error("Chat-off client teardown failed", e);
                }
                a = !1, o = !1;
                return;
            }
            await Promise.resolve(S.kind === "serve" ? m.start({
                handle: S.handle,
                rolloutOverride: 1,
                ...p.sensitiveMetaFields === void 0 ? {} : {
                    sensitiveMetaFields: p.sensitiveMetaFields
                }
            }) : m.start()), a = !1, o = !1, s = !1;
        } catch (e) {
            throw m && t === m && (m.destroy(), t = null, b()), e;
        }
    }
    async function ne() {
        try {
            let e = g(),
                i;
            try {
                i = e.stop();
            } finally {
                t === e && (n && (o = !0, s = !0), t = null, r++, b(), S());
            }
            await Promise.resolve(i);
        } finally {
            a = !0;
        }
    }
    async function C(e, n) {
        let r = d++,
            i = {
                id: r,
                key: e,
                callback: n,
                actualId: null
            };
        return m.set(r, i), t && (i.actualId = t.subscribeEvent(e, n)), r;
    }
    async function re(e) {
        let n = m.get(e);
        if (n) {
            t && n.actualId !== null && t.unsubscribeEvent(n.actualId), m.delete(e);
            return;
        }
        let r = h.get(e);
        r && (t && r.actualId !== null && t.unsubscribeEvent(r.actualId), h.delete(e));
    }
    async function ie(e) {
        let n = d++,
            r = {
                id: n,
                callback: e,
                actualId: null
            };
        return h.set(n, r), t && (r.actualId = t.subscribeAll(e)), n;
    }

    function ae(e) {
        f = e, p = !0, t && t.setDelegate(e);
    }
    let w = {
        start: ee,
        stop: ne,
        toggle: async () => Promise.resolve(_((e) => e.toggle())),
        deleteHistory: async () => Promise.resolve(_((e) => e.deleteHistory())),
        reset: async (e) => Promise.resolve(_((t) => t.reset(e))),
        setMetaFields: async (e) => Promise.resolve(_((t) => t.setMetaFields(e))),
        setSensitiveMetaFields: async (e) => Promise.resolve(_((t) => t.setSensitiveMetaFields(e))),
        setTestModeBanner: async (e) => Promise.resolve(_((t) => t.setTestModeBanner(e))),
        getInfo: async () => _((e) => e.getInfo()),
        getMetaFields: async () => _((e) => e.getMetaFields()),
        isOpen: async () => _((e) => e.isOpen()),
        getConversation: async () => _((e) => e.getConversation()),
        getMessages: async () => _((e) => e.getMessages()),
        setComposerText: async (e) => _((t) => t.setComposerText(e)),
        setDelegate: ae,
        trackEvent: async (e, t, n) => Promise.resolve(_((r) => r.trackEvent(e, t, n))),
        subscribeEvent: C,
        unsubscribeEvent: re,
        subscribeAll: ie,
        open: async () => Promise.resolve(_((e) => e.open())),
        close: async () => Promise.resolve(_((e) => e.close())),
        setLanguage: async (e) => Promise.resolve(_((t) => t.setLanguage(e))),
        setTheme: async (e) => Promise.resolve(_((t) => t.setTheme(e))),
        setDeviceToken: async (e) => Promise.resolve(_((t) => t.setDeviceToken(e))),
        acknowledgeSessionMirrorClear: async (e) => Promise.resolve(_((t) => t.acknowledgeSessionMirrorClear(e))),
        deliverSessionMirrorSeed: async (e, t) => Promise.resolve(_((n) => n.deliverSessionMirrorSeed(e, t))),
        triggerPlaybook: async (e, t) => _((n) => n.triggerPlaybook(e, t)),
        sendMessage: async (e) => _((t) => t.sendMessage(e)),
        selectQuickReply: async (e, t) => _((n) => n.selectQuickReply(e, t)),
        handleNotification: async () => Promise.resolve(_((e) => e.handleNotification())),
        requestNotifications: async () => Promise.resolve(g().requestNotifications()),
        createProactive: async () => qo("createProactive"),
        triggerCampaign: async () => qo("triggerCampaign"),
        evaluateCampaignConditions: async () => qo("evaluateCampaignConditions"),
        closeCampaign: async () => Promise.resolve(_((e) => e.closeCampaign())),
        triggerAnswer: async (e) => Promise.resolve(_((t) => t.triggerAnswer(e))),
        triggerProactive: async (e, t) => Promise.resolve(_((n) => n.triggerProactive(e, t))),
        triggerGreeting: async (e) => Promise.resolve(_((t) => t.triggerGreeting(e))),
        destroy: async () => {
            let e = t,
                n;
            try {
                n = e ? .destroy();
            } finally {
                t === e && (t = null, r++), b(), x(), S();
            }
            await Promise.resolve(n);
        }
    };
    return Object.defineProperty(w, $o, {
        value: () => {
            n = !0;
        }
    }), Object.defineProperty(w, Symbol.for("ada.messaging.nativeViewVisibility"), {
        value: (e) => _((t) => {
            Reflect.get(t, Symbol.for("ada.messaging.nativeViewVisibility"))(e);
        })
    }), Ro(w, () => a), w;
}
var ns = (e, t) => Object.prototype.hasOwnProperty.call(e, t),
    rs = (e) => typeof e == "object" && !!e || typeof e == "function",
    is = (e) => {
        try {
            return e instanceof Error ? e : Error(String(e ? ? "Unknown error"));
        } catch {
            return /* @__PURE__ */ Error("Unknown error");
        }
    },
    as = (e) => e instanceof H && Yr.has(e.code ? ? ""),
    Y = (e, t, n, r) => {
        if (!r) return;
        let i = n;
        t === "reject" && (i = n instanceof Error ? n.message : String(n ? ? "Unknown error")), window.dispatchEvent(new CustomEvent(`__ada-embed-action-${t}-${r}`, {
            detail: i
        }));
    },
    os = (e) => {
        if (!rs(e)) return {
            action: e
        };
        try {
            let t = e.method;
            return typeof t == "string" ? {
                action: e,
                method: t
            } : {
                action: e
            };
        } catch (t) {
            return {
                action: e,
                methodReadError: t
            };
        }
    },
    ss = () => {
        let e = window.__AdaEmbedLoaderInitialActionQueue;
        return Array.isArray(e) ? e : void 0;
    };
async function cs(e, t, n, r) {
    let i = !!r.onInitialStartAccepted,
        a = (e, t, n, i) => {
            try {
                r.onOutcome(e, n, i, t);
            } catch (e) {
                let n = t ? ` "${t}"` : " with no method";
                j.error(`Embed-loader outcome callback threw for action${n}`, e);
            }
        },
        o = () => {
            try {
                r.onQueueDrained ? .();
            } catch (e) {
                j.error("Embed-loader queue-drained callback threw", e);
            }
        },
        s = (e, t, n) => (a(e, t, "reject", n), t !== "start" || !i ? !1 : (i = !1, as(n) ? (r.onInitialStartAccepted ? .(), !1) : (r.onInitialStartRejected ? .(is(n)), !0))),
        c = 0;
    for (; c < t.length || n ? .length;) {
        if (c >= t.length && n ? .length) {
            let e = n.splice(0, n.length);
            for (let n of e) t.push(os(n));
        }
        let o = t[c++];
        if (!o) {
            j.warn("Rejected malformed queued embed-loader action");
            continue;
        }
        let {
            action: l,
            method: u,
            methodReadError: d
        } = o;
        if (!rs(l)) {
            j.warn("Rejected malformed queued embed-loader action");
            continue;
        }
        if (!u) {
            d ? j.error("Failed to read queued embed-loader action method", d) : j.warn("Rejected malformed queued embed-loader action"), a(l, void 0, "reject", d ? ? /* @__PURE__ */ Error("Malformed queued embed-loader action"));
            continue;
        }
        let f, p;
        try {
            f = ns(Wo, u) ? Wo[u] : void 0, p = ns(e, u) ? e[u] : void 0;
        } catch (e) {
            if (j.warn(`Failed to inspect queued embed-loader action "${u}"`, e), s(l, u, e)) return;
            continue;
        }
        if (typeof p != "function" || !f) {
            let e = /* @__PURE__ */ Error(`Unknown queued embed-loader action "${u}"`);
            if (j.warn(e.message), s(l, u, e)) return;
            continue;
        }
        let m, h;
        try {
            m = l.arguments, h = Array.isArray(m);
        } catch (e) {
            if (j.warn(`Failed to inspect arguments for queued embed-loader action "${u}"`, e), s(l, u, e)) return;
            continue;
        }
        if (!h) {
            let e = /* @__PURE__ */ Error(`Malformed arguments for queued embed-loader action "${u}"`);
            if (j.warn(e.message), s(l, u, e)) return;
            continue;
        }
        let g = m,
            _;
        try {
            let [e, t] = f;
            g = g.slice(0, e), _ = t(g);
        } catch (e) {
            if (j.warn(`Failed to validate queued embed-loader action "${u}"`, e), s(l, u, e)) return;
            continue;
        }
        if (!_) {
            let e = /* @__PURE__ */ Error(`Invalid arguments for queued embed-loader action "${u}"`);
            if (j.warn(e.message), s(l, u, e)) return;
            continue;
        }
        let v;
        try {
            v = await p.call(e, ...g);
        } catch (e) {
            if (j.warn(`Failed to replay queued embed-loader action "${u}"`, e), s(l, u, e)) return;
            continue;
        }
        u === "start" && i && (i = !1, r.onInitialStartAccepted ? .()), a(l, u, "resolve", v);
    }
    o();
}
var ls = (e) => {
    j.error("Unexpected failure while replaying embed-loader actions", e);
};

function us(e) {
    es(e);
    let t = ss();
    if (!t ? .length) return;
    let n = t.splice(0, t.length),
        r = Promise.resolve();
    for (let t of n) {
        let {
            action: n,
            method: i,
            methodReadError: a
        } = os(t);
        if (!rs(n)) {
            j.warn("Rejected malformed queued embed-loader action");
            continue;
        }
        if (!i) {
            a ? j.error("Failed to read queued embed-loader action method", a) : j.warn("Rejected malformed queued embed-loader action"), Y(n, "reject", a ? ? /* @__PURE__ */ Error("Malformed queued embed-loader action"), void 0);
            continue;
        }
        let o, s;
        try {
            o = ns(Go, i) ? Go[i] : void 0, s = ns(e, i) ? e[i] : void 0;
        } catch (e) {
            j.warn(`Failed to inspect queued embed-loader action "${i}"`, e), Y(n, "reject", e, i);
            continue;
        }
        if (typeof s != "function" || !o) {
            let e = /* @__PURE__ */ Error(`Unknown queued embed-loader action "${i}"`);
            j.warn(e.message), Y(n, "reject", e, i);
            continue;
        }
        let c, l;
        try {
            c = n.arguments, l = Array.isArray(c);
        } catch (e) {
            j.warn(`Failed to inspect arguments for queued embed-loader action "${i}"`, e), Y(n, "reject", e, i);
            continue;
        }
        if (!l) {
            let e = /* @__PURE__ */ Error(`Malformed arguments for queued embed-loader action "${i}"`);
            j.warn(e.message), Y(n, "reject", e, i);
            continue;
        }
        let u = c,
            d;
        try {
            let [e, t] = o;
            u = u.slice(0, e), d = t(u);
        } catch (e) {
            j.warn(`Failed to validate queued embed-loader action "${i}"`, e), Y(n, "reject", e, i);
            continue;
        }
        if (!d) {
            let e = /* @__PURE__ */ Error(`Invalid arguments for queued embed-loader action "${i}"`);
            j.warn(e.message), Y(n, "reject", e, i);
            continue;
        }
        let f = s,
            p = u;
        r = r.then(() => f.call(e, ...p)).then((e) => {
            Y(n, "resolve", e, i);
        }, (e) => {
            j.warn(`Failed to replay queued embed-loader action "${i}"`, e), Y(n, "reject", e, i);
        });
    }
    r.catch(ls);
}

function ds(e, t, n) {
    es(e);
    let r = (e, n, r) => {
            t(e, n, r);
        },
        i, a, o;
    try {
        i = ss(), a = i ? .length ? i.splice(0, i.length).map(os) : [], o = a.some(({
            method: e
        }) => e === "start");
    } catch (e) {
        return Promise.reject(is(e));
    }
    if (!o) return cs(e, a, i, {
        onOutcome: r,
        onQueueDrained: n
    }).catch(ls), Promise.resolve();
    let s, c, l = new Promise((e, t) => {
        s = e, c = t;
    });
    return cs(e, a, i, {
        onOutcome: r,
        onInitialStartAccepted: s,
        onInitialStartRejected: c,
        onQueueDrained: n
    }).catch((e) => {
        c(is(e)), ls(e);
    }), l;
}
//#endregion
//#region src/sdk-module-loader.ts
async function fs(e) {
    return import (
        /* @vite-ignore */
        e
    );
}
//#endregion
//#region src/mobile-webview-runtime.ts
var ps = "__ada_identity_token_consumed__",
    ms = "expectsIdentityToken",
    hs = /* @__PURE__ */ new Map(),
    gs = "ada-root",
    _s = "https://messaging-assets.net:4900",
    vs = 4900,
    ys = "__ada_handle",
    bs = new Map([
        ["messaging-assets.ada.support", ""],
        ["messaging-assets.ada-dev2.support", ""],
        ["static.ada.support", "/messaging"]
    ]),
    xs, Ss = 0,
    Cs = 3e4;

function ws(e) {
    return e === "triggerPlaybook" ? gi : Cs;
}
var Ts = new Set([
    "getInfo",
    "isOpen",
    "getMetaFields",
    "getConversation",
    "getMessages",
    "open",
    "close",
    "toggle",
    "triggerProactive",
    "triggerAnswer",
    "triggerPlaybook",
    "triggerGreeting",
    "closeCampaign",
    "setTheme"
]);

function Es(e) {
    return e.type === "ada.request";
}

function Ds(e) {
    let t = {},
        n = (t) => typeof e[t] == "function";
    return n("getInfo") && (t.getInfo = () => e.getInfo ? .()), n("isOpen") && (t.isOpen = () => e.isOpen ? .()), n("getMetaFields") && (t.getMetaFields = () => e.getMetaFields ? .()), n("getConversation") && (t.getConversation = () => e.getConversation ? .()), n("getMessages") && (t.getMessages = () => e.getMessages ? .()), n("closeCampaign") && (t.closeCampaign = () => e.closeCampaign ? .()), n("triggerAnswer") && (t.triggerAnswer = (t) => {
        let n = t ? .answerId;
        if (typeof n != "string") throw Error("triggerAnswer requires a string answerId");
        return e.triggerAnswer ? .(n);
    }), n("triggerPlaybook") && (t.triggerPlaybook = (t) => {
        let n = t ? .playbookId;
        if (typeof n != "string" || !/^[a-f\d]{24}$/i.test(n)) throw Error("triggerPlaybook requires a valid Playbook ID");
        for (let e of [t ? .metaFields, t ? .sensitiveMetaFields])
            if (e !== void 0 && !Z(e)) throw Error("triggerPlaybook requires metadata objects");
        return e.triggerPlaybook ? .(n, {
            metaFields: t ? .metaFields,
            sensitiveMetaFields: t ? .sensitiveMetaFields
        });
    }), n("triggerGreeting") && (t.triggerGreeting = (t) => {
        let n = t ? .handle;
        if (n !== void 0 && typeof n != "string") throw Error("triggerGreeting handle must be a string when provided");
        return e.triggerGreeting ? .(n);
    }), n("triggerProactive") && (t.triggerProactive = (t) => {
        let n = t ? .messageKey;
        if (typeof n != "string") throw Error("triggerProactive requires a string messageKey");
        let r = t ? .params;
        if (r !== void 0 && (typeof r != "object" || !r || Array.isArray(r) || Object.values(r).some((e) => typeof e != "string"))) throw Error("triggerProactive params must be a record of strings");
        return e.triggerProactive ? .({
            messageKey: n,
            params: r
        });
    }), n("setTheme") && (t.setTheme = (t) => {
        let n = t ? .theme;
        if (n !== "light" && n !== "dark" && n !== "auto") throw Error("setTheme requires \"light\", \"dark\", or \"auto\"");
        return e.setTheme ? .(n);
    }), t;
}

function Os(e, t, n, r) {
    e ? .({
        type: "sdk.response",
        requestId: t,
        generation: n,
        ...r
    });
}

function ks(e, t, n, r, i = ws(e.method)) {
    let a = e.requestId;
    if (typeof a != "string" || a === "") {
        X(r, "Bridge request from native is missing a string requestId");
        return;
    }
    let o = e.method;
    if (typeof o != "string" || !Ts.has(o)) {
        Os(r, a, t, {
            error: `Unknown bridge method: ${typeof o == "string" ? o : String(o)}`
        });
        return;
    }
    let s = n[o];
    if (!s) {
        Os(r, a, t, {
            unsupported: !0
        });
        return;
    }
    let c = Z(e.params) ? ? void 0,
        l = !1,
        u = (e) => {
            l || (l = !0, clearTimeout(d), Os(r, a, t, e));
        },
        d = setTimeout(() => u({
            error: "Bridge request timed out"
        }), i);
    try {
        Promise.resolve(s(c)).then((e) => u({
            result: e === void 0 ? null : e
        }), (e) => u({
            error: Zs(e)
        }));
    } catch (e) {
        u({
            error: Zs(e)
        });
    }
}

function As() {
    try {
        let e = new URL(
            import.meta.url).origin;
        if (e !== "null") return e;
    } catch {}
    return typeof window < "u" && C(window.location.hostname) ? `https://${window.location.hostname}:${vs}` : _s;
}

function js(e) {
    return new URL(e, b(As())).toString();
}

function Ms(e) {
    return e === "legacy" ? "legacy" : "messaging";
}

function Ns(e) {
    let t = Ms(e.webSdk);
    return {
        ...e,
        hostTelemetry: Zt({
            hostTelemetry: e.hostTelemetry
        }, {
            defaultOrigin: t,
            defaultSurface: "mobile"
        }),
        webSdk: t
    };
}

function Ps(e) {
    let {
        hostTelemetry: t,
        webSdk: n
    } = Ns(e);
    return {
        ...e,
        hostTelemetry: t,
        webSdk: n
    };
}

function X(e, t) {
    e ? .({
        type: "sdk.error",
        error: t
    });
}

function Z(e) {
    return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
var Fs = ["identityToken", "appUrl"];

function Is(e) {
    return pe(e);
}

function Ls(e) {
    try {
        window.sessionStorage.setItem(ps, e);
    } catch {}
}

function Rs() {
    try {
        return window.sessionStorage.getItem(ps);
    } catch {
        return null;
    }
}

function zs(e) {
    let t = window.__ADA_WEBVIEW_CONFIG__;
    try {
        delete window.__ADA_WEBVIEW_CONFIG__;
    } catch {
        window.__ADA_WEBVIEW_CONFIG__ = void 0;
    }
    if (t === void 0) return {};
    let n = Z(t);
    if (!n) return X(e, "Ignoring window.__ADA_WEBVIEW_CONFIG__: expected an object with string values"), {};
    let r = {};
    for (let t of Fs) {
        let i = n[t];
        i !== void 0 && (typeof i == "string" && i.trim() !== "" ? r[t] = i : X(e, `Ignoring window.__ADA_WEBVIEW_CONFIG__.${t}: expected a non-empty string`));
    }
    if (r.identityToken) {
        let e = n.injectionId;
        Ls(typeof e == "string" && e.trim() !== "" ? e : "1");
    }
    n.nativeViewVisibilitySupported === !0 && (r.nativeViewVisibilitySupported = !0), n.nativeSessionMirrorSupported === !0 && (r.nativeSessionMirrorSupported = !0);
    let i = Bs(n.sensitiveMetaFields, e);
    return i && (r.sensitiveMetaFields = i), r;
}

function Bs(e, t) {
    if (e === void 0) return null;
    if (typeof e != "string" || e.trim() === "") return X(t, "Ignoring window.__ADA_WEBVIEW_CONFIG__.sensitiveMetaFields: expected a JSON-encoded object string"), null;
    let n;
    try {
        n = JSON.parse(e);
    } catch {
        return X(t, "Ignoring window.__ADA_WEBVIEW_CONFIG__.sensitiveMetaFields: could not parse the JSON-encoded object"), null;
    }
    let r = Gs(n);
    return !r || Object.keys(r).length === 0 ? (X(t, "Ignoring window.__ADA_WEBVIEW_CONFIG__.sensitiveMetaFields: expected a non-empty object of scalar values"), null) : r;
}

function Vs(e, t) {
    e.identityToken || new URLSearchParams(window.location.search).get(ms) === "true" && Rs() === null && X(t, "identityToken was expected via window.__ADA_WEBVIEW_CONFIG__ but none arrived; starting without identity. Mint a new token and reinitialize.");
}

function Hs(e) {
    let t = new URLSearchParams(window.location.search);
    (t.has("identityToken") || t.has("identity_token")) && X(e, "identityToken must not be passed as a query parameter and was ignored; inject it via window.__ADA_WEBVIEW_CONFIG__");
}

function Us(e, t) {
    let n = Fs.filter((t) => e[t] !== void 0);
    e.sensitiveMetaFields !== void 0 && n.push("sensitiveMetaFields"), n.length !== 0 && X(t, `window.__ADA_WEBVIEW_CONFIG__ is not supported by the legacy web SDK; ignored: ${n.join(", ")}`);
}

function Ws(e) {
    let t = Z(e),
        n = t ? .createAdaEmbedInterface,
        r = Z(t ? .default) ? .createAdaEmbedInterface,
        i = typeof n == "function" ? n : r;
    if (typeof i != "function") throw Error("Messaging SDK module did not expose createAdaEmbedInterface().");
    return i;
}

function Gs(e) {
    let t = Z(e);
    if (!t) return null;
    let n = {};
    for (let [e, r] of Object.entries(t))(r === null || typeof r == "string" || typeof r == "number" || typeof r == "boolean") && (n[e] = r);
    return n;
}

function Ks(e) {
    let t = e.metaFields.sdkType,
        n = typeof t == "string" ? t.trim().toUpperCase() : "";
    if (Ft(n)) return "ANDROID";
    if (n === "ANDROID" || n === "IOS" || n === "WEB") return n;
    switch (e.hostTelemetry.hostPlatform) {
        case "ios":
            return "IOS";
        case "android":
        case "react-native":
            return "ANDROID";
        default:
            return n === "" ? "WEB" : void 0;
    }
}

function qs(e) {
    let t = `script:${e}`,
        n = hs.get(t);
    if (n) return n;
    let r = new Promise((t, n) => {
        let r = document.createElement("script");
        r.async = !0, r.src = e, r.addEventListener("load", () => t(), {
            once: !0
        }), r.addEventListener("error", () => {
            r.remove(), n( /* @__PURE__ */ Error(`Failed to load script: ${e}`));
        }, {
            once: !0
        }), document.head.appendChild(r);
    }).catch((e) => {
        throw hs.delete(t), e;
    });
    return hs.set(t, r), r;
}

function Js(e, t) {
    let n = ++Ss;
    return (r) => {
        let i;
        try {
            i = JSON.parse(r);
        } catch {
            X(t, "Invalid command JSON from native");
            return;
        }
        if (Es(i)) {
            ks(i, n, Ds(e), t);
            return;
        }
        switch (i.type) {
            case "ada.reset":
                e.reset ? .(i.payload);
                return;
            case "ada.setLanguage":
                typeof i.payload ? .language == "string" && e.setLanguage ? .(i.payload.language);
                return;
            case "ada.sendMessage":
                typeof i.payload ? .body == "string" && e.sendMessage ? .(i.payload.body);
                return;
            case "ada.selectQuickReply":
                {
                    let n = i.payload ? .messageId,
                        r = i.payload ? .index;
                    if (typeof n != "string" || typeof r != "number" || !Number.isInteger(r) || r < 0) return;
                    if (typeof e.selectQuickReply != "function") {
                        X(t, "Legacy chat does not support selectQuickReply");
                        return;
                    }
                    Q(() => e.selectQuickReply ? .(n, r), t);
                    return;
                }
            case "ada.setMetaFields":
                {
                    let t = Z(i.payload ? .fields);
                    t && e.setMetaFields ? .(t);
                    return;
                }
            case "ada.setSensitiveMetaFields":
                {
                    let t = Z(i.payload ? .fields);
                    t && e.setSensitiveMetaFields ? .(t);
                    return;
                }
            case "ada.setDeviceToken":
                typeof i.payload ? .token == "string" && e.setDeviceToken ? .(i.payload.token);
                return;
            case "ada.deleteHistory":
                e.deleteHistory ? .();
                return;
            default:
                return;
        }
    };
}
var Ys = 2e3,
    Xs = 64;

function Zs(e) {
    return e instanceof Error ? e.message : String(e);
}

function Qs(e, t, n) {
    e.latestState = t, e.stateCacheTimer !== null && clearTimeout(e.stateCacheTimer);
    let r = () => {
        e.latestState && n ? .({
            type: "sdk.state.cache",
            state: {
                ...e.latestState,
                __ada_cached_at__: Date.now()
            }
        });
    };
    if (!e.hasCachedStartupState) {
        e.hasCachedStartupState = !0, e.stateCacheTimer = null, r();
        return;
    }
    e.stateCacheTimer = setTimeout(() => {
        e.stateCacheTimer = null, r();
    }, Ys);
}

function Q(e, t) {
    try {
        Promise.resolve(e()).catch((e) => {
            X(t, Zs(e));
        });
    } catch (e) {
        X(t, Zs(e));
    }
}

function $s(e, t, n, r, i) {
    if (Es(e)) {
        ks(e, n, Ds(t), r, i);
        return;
    }
    switch (e.type) {
        case "ada.viewVisibility.set":
            if (typeof e.payload ? .isVisible == "boolean") {
                let n = e.payload.isVisible;
                Q(() => t[Symbol.for("ada.messaging.nativeViewVisibility")] ? .(n), r);
            }
            return;
        case "ada.reset":
            Q(() => t.reset ? .(e.payload), r);
            return;
        case "ada.setLanguage":
            {
                let n = e.payload ? .language;
                if (typeof n != "string") return;
                Q(() => t.setLanguage ? .(n), r);
                return;
            }
        case "ada.sendMessage":
            {
                let n = e.payload ? .body;
                if (typeof n != "string") return;
                Q(() => t.sendMessage ? .(n), r);
                return;
            }
        case "ada.selectQuickReply":
            {
                let n = e.payload ? .messageId,
                    i = e.payload ? .index;
                if (typeof n != "string" || typeof i != "number" || !Number.isInteger(i) || i < 0) return;
                Q(() => t.selectQuickReply ? .(n, i), r);
                return;
            }
        case "ada.setMetaFields":
            {
                let n = Z(e.payload ? .fields);
                if (!n) return;
                Q(() => t.setMetaFields ? .(n), r);
                return;
            }
        case "ada.setSensitiveMetaFields":
            {
                let n = Z(e.payload ? .fields);
                if (!n) return;
                Q(() => t.setSensitiveMetaFields ? .(n), r);
                return;
            }
        case "ada.setDeviceToken":
            {
                let n = e.payload ? .token;
                if (typeof n != "string") return;
                Q(() => t.setDeviceToken ? .(n), r);
                return;
            }
        case "ada.deleteHistory":
            Q(() => t.deleteHistory ? .(), r);
            return;
        case "ada.sessionMirrorClearAck":
            {
                let n = e.requestId;
                typeof n == "string" && n !== "" && Q(() => t.acknowledgeSessionMirrorClear ? .(n), r);
                return;
            }
        case "sdk.sessionMirror.seed":
            {
                let n = e.requestId;
                typeof n == "string" && n !== "" && Q(() => t.deliverSessionMirrorSeed ? .(n, e.seed), r);
                return;
            }
        case "ada.zdChatterAuthResponse":
            {
                let t = window.__ADA_ZD_AUTH_RESOLVERS__,
                    n = e.payload ? .requestId,
                    r;
                if (typeof n == "string" ? (r = t ? .get(n), t ? .delete(n)) : n === void 0 && (r = Array.from(t ? .values() ? ? []).pop(), t ? .clear()), !r) {
                    j.debug("Ignoring unmatched native Zendesk Chat auth response");
                    return;
                }
                let i = e.payload ? .token;
                r(typeof i == "string" ? i : null);
                return;
            }
        default:
            return;
    }
}

function ec(e, t, n) {
    if (e.pendingCommands.length === 0) return;
    let r = e.pendingCommands.splice(0),
        i = Date.now();
    for (let {
            command: a,
            enqueuedAt: o
        } of r) {
        if (Es(a) && typeof a.requestId == "string" && a.requestId !== "") {
            let r = ws(a.method),
                s = Math.min(r, r - (i - o));
            if (s <= 0) {
                Os(n, a.requestId, e.generation, {
                    error: "Bridge request expired before the runtime became ready"
                });
                continue;
            }
            $s(a, t, e.generation, n, s);
            continue;
        }
        $s(a, t, e.generation, n);
    }
}

function tc(e) {
    let t = window.adaSettings ? ? {},
        n = /* @__PURE__ */ new Map();
    window.__ADA_ZD_AUTH_RESOLVERS__ = n, t.zdChatterAuthCallback = (t) => {
        let r = ni();
        n.clear(), n.set(r, t), e ? .({
            type: "sdk.zdChatterAuthRequest",
            payload: {
                requestId: r
            }
        });
    }, window.adaSettings = t;
}

function nc(e, t, n) {
    return (r) => {
        let i;
        try {
            i = JSON.parse(r);
        } catch {
            X(n, "Invalid command JSON from native");
            return;
        }
        if (!t.isReady && i.type !== "ada.zdChatterAuthResponse" && i.type !== "ada.sessionMirrorClearAck" && i.type !== "sdk.sessionMirror.seed") {
            if (t.pendingCommands.length >= Xs) {
                Es(i) && typeof i.requestId == "string" && i.requestId !== "" ? Os(n, i.requestId, t.generation, {
                    error: "Too many commands received before SDK became ready"
                }) : X(n, "Too many commands received before SDK became ready");
                return;
            }
            t.pendingCommands.push({
                command: i,
                enqueuedAt: Date.now()
            });
            return;
        }
        $s(i, e, t.generation, n);
    };
}
async function rc(e, t, n = {}) {
    if (!e.subscribeAll) throw Error("Messaging bridge runtime requires subscribeAll()");
    let r = e.subscribeEvent ? .bind(e),
        i = {
            isReady: !1,
            hasCachedStartupState: !1,
            latestState: null,
            stateCacheTimer: null,
            pendingCommands: [],
            generation: ++Ss
        };
    tc(t), window.__ADA_BRIDGE_DISPATCH__ = nc(e, i, t), await Promise.resolve(e.subscribeAll((n, r) => {
        t ? .({
            type: "sdk.event",
            key: n,
            data: r
        });
        let a = n === "core.startup.config" ? Z(r) : null,
            o = !i.isReady && !!a;
        !i.isReady && a && (i.isReady = !0), a && Qs(i, a, t), o && (ec(i, e, t), t ? .({
            type: "sdk.ready"
        }));
    }));
    let a = (e) => (n) => {
        t ? .({
            type: "sdk.event",
            key: e,
            data: n
        });
    };
    r && (await Promise.resolve(r("ada:message:sent", a("ada:message:sent"))), await Promise.resolve(r("ada:message:received", a("ada:message:received"))));
    let o = n.sessionMirrorPrivileged && typeof e.acknowledgeSessionMirrorClear == "function" && typeof e.deliverSessionMirrorSeed == "function" ? r : void 0,
        s = o !== void 0;
    if (o) {
        let e = (e) => (n) => {
            let r = Z(n);
            r && t ? .({
                ...r,
                type: e
            });
        };
        await Promise.resolve(o("core.session.mirror", e("sdk.session.mirror"))), await Promise.resolve(o("core.session.mirrorClear", e("sdk.session.mirrorClear"))), await Promise.resolve(o("core.session.mirrorRequest", e("sdk.session.mirrorRequest")));
    }
    return {
        state: i,
        sessionMirrorArmed: s
    };
}

function ic(e, t) {
    return {
        handle: e.handle,
        ...e.cluster ? {
            cluster: e.cluster
        } : {},
        ...e.language ? {
            language: e.language
        } : {},
        ...e.greeting ? {
            greeting: e.greeting
        } : {},
        ...e.headless ? {
            headless: !0
        } : {},
        ...e.enableProgrammaticControl ? {
            enableProgrammaticControl: !0
        } : {},
        ...e.metaFields ? {
            metaFields: e.metaFields
        } : {},
        hostTelemetry: e.hostTelemetry,
        parentElement: t,
        onAdaEmbedLoaded: () => {
            e.postToNative ? .({
                type: "sdk.ready"
            });
        },
        eventCallbacks: {
            "*": (t) => {
                let n = Z(t),
                    r = typeof n ? .event_name == "string" ? n.event_name : "ada.legacy.event";
                e.postToNative ? .({
                    type: "sdk.event",
                    key: r,
                    data: t
                });
            }
        }
    };
}

function ac(e, t) {
    if (t)
        for (let [n, r] of Object.entries(t)) r != null && e.set(n, String(r));
}

function oc(e, t) {
    t && e.set(Wt, JSON.stringify(t));
}

function sc(e, t) {
    let n = new URLSearchParams();
    return n.set("embed2", "1"), n.set("align", "left"), n.set(ys, e.handle), e.language && n.set("language", e.language), e.greeting && n.set("greeting", e.greeting), t ? .reset && n.set("reset", "1"), ac(n, e.metaFields), oc(n, e.hostTelemetry), `${js("/chat/")}?${n.toString()}`;
}

function cc(e) {
    document.cookie = `ada_legacy_handle=${encodeURIComponent(e)}; path=/; SameSite=Lax; Secure`;
}

function lc() {
    xs && = (window.removeEventListener("message", xs), void 0);
}

function uc(e) {
    return new URL(e.src, window.location.href).origin;
}

function $(e, t, n, r) {
    e.contentWindow ? .postMessage(JSON.stringify({
        name: "chat",
        type: t,
        ...n === void 0 ? {} : {
            payload: n
        },
        ...r ? {
            id: r
        } : {}
    }), uc(e));
}

function dc(e) {
    return {
        chatterCreated: null,
        chatterToken: e.chatterToken ? ? null,
        sessionToken: null,
        adaSettings: {
            handle: e.handle,
            ...e.language ? {
                language: e.language
            } : {},
            ...e.greeting ? {
                greeting: e.greeting
            } : {}
        },
        metaFields: e.metaFields,
        sensitiveMetaFields: e.sensitiveMetaFields,
        notificationsPermission: "default",
        browserHasNotificationSupport: !1,
        embed2Enabled: !0,
        isDrawerOpen: !0,
        preload: !1,
        parentElement: gs,
        styles: e.styles ? ? null,
        client: null,
        initialURL: null,
        wasIntroShown: !1,
        language: e.language ? ? null,
        testMode: !1,
        drawerHasBeenOpened: !0,
        wasCampaignShownButNowClosed: !1,
        isChatEmpty: !1,
        proactiveCampaignHadMessages: !1,
        deviceToken: e.deviceToken ? ? null,
        enabledLanguages: null,
        greeting: e.greeting ? ? null,
        ...e.embedStateOverrides
    };
}

function fc(e, t) {
    if (typeof t == "string") return dc(e)[t];
}

function pc(e, t) {
    let n = Z(t),
        r = n ? .actionKey;
    if (r === "setState") {
        let t = Z(n ? .payload);
        t && (e.embedStateOverrides = {
            ...e.embedStateOverrides,
            ...t
        });
    } else if (r === "toggleChat") {
        let t = dc(e).isDrawerOpen;
        e.embedStateOverrides = {
            ...e.embedStateOverrides,
            isDrawerOpen: t === !1
        };
    }
    return dc(e);
}
async function mc(e) {
    if (!e.chatterToken) return;
    let t = { ...e.sensitiveMetaFields
    };
    e.deviceToken && (t.device_token = e.deviceToken, t.device_os = Ks(e) ? ? null);
    let n = {};
    if (Object.keys(e.metaFields).length > 0 && (n.meta_variables = e.metaFields), Object.keys(t).length > 0 && (n.sensitive_meta_variables = t), !n.meta_variables && !n.sensitive_meta_variables) return;
    let r = await fetch(e.metadataUrl, {
        method: "PATCH",
        headers: {
            "Chatter-Token": e.chatterToken,
            "Content-Type": "application/json",
            Pragma: "no-cache",
            "X-Ada-Request-Origin": "chat"
        },
        body: JSON.stringify(n)
    });
    if (!r.ok && r.status >= 500) throw Error(`Failed to patch legacy chat metadata (${r.status})`);
}

function hc(e) {
    mc(e).catch((t) => {
        X(e.postToNative, String(t instanceof Error ? t.message : t));
    });
}

function gc(e, t) {
    e.chatterToken = void 0, e.readyPosted = !1, e.iframe.src = sc({
        language: e.language,
        greeting: e.greeting,
        handle: e.handle,
        hostTelemetry: e.hostTelemetry,
        metaFields: e.metaFields
    }, t);
}

function _c(e) {
    let t = ++Ss;
    return (n) => {
        let r;
        try {
            r = JSON.parse(n);
        } catch {
            X(e.postToNative, "Invalid command JSON from native");
            return;
        }
        if (Es(r)) {
            ks(r, t, {}, e.postToNative);
            return;
        }
        switch (r.type) {
            case "ada.reset":
                {
                    let t = Z(r.payload),
                        n = Gs(t ? .metaFields),
                        i = Gs(t ? .sensitiveMetaFields);
                    typeof t ? .language == "string" && (e.language = t.language),
                    typeof t ? .greeting == "string" && (e.greeting = t.greeting),
                    n && (e.metaFields = { ...n
                    }),
                    i && (e.sensitiveMetaFields = { ...i
                    }),
                    gc(e, {
                        reset: typeof t ? .resetChatHistory == "boolean" ? t.resetChatHistory : !0
                    });
                    return;
                }
            case "ada.setLanguage":
                typeof r.payload ? .language == "string" && (e.language = r.payload.language, $(e.iframe, "SET_LANGUAGE", {
                    language: r.payload.language
                }));
                return;
            case "ada.selectQuickReply":
                X(e.postToNative, "Local legacy chat iframe does not support selectQuickReply");
                return;
            case "ada.sendMessage":
                X(e.postToNative, "Local legacy chat iframe does not support sendMessage");
                return;
            case "ada.setMetaFields":
                {
                    let t = Gs(r.payload ? .fields);
                    if (!t) return;
                    e.metaFields = {
                        ...e.metaFields,
                        ...t
                    },
                    hc(e);
                    return;
                }
            case "ada.setSensitiveMetaFields":
                {
                    let t = Gs(r.payload ? .fields);
                    if (!t) return;
                    e.sensitiveMetaFields = {
                        ...e.sensitiveMetaFields,
                        ...t
                    },
                    hc(e);
                    return;
                }
            case "ada.setDeviceToken":
                if (typeof r.payload ? .token != "string") return;
                e.deviceToken = r.payload.token, hc(e);
                return;
            case "ada.deleteHistory":
                gc(e, {
                    reset: !0
                });
                return;
            default:
                return;
        }
    };
}

function vc(e) {
    let t = e.data;
    if (typeof t != "string") return null;
    try {
        let e = JSON.parse(t);
        return e && e.name === "chat" ? e : null;
    } catch {
        return null;
    }
}

function yc(e, t, n) {
    if (t === "PUBLISH_EVENT") {
        let t = Z(n);
        if (typeof t ? .eventKey == "string") {
            e ? .({
                type: "sdk.event",
                key: t.eventKey,
                data: t.data
            });
            return;
        }
    }
    if (t === "CUSTOM_JAVASCRIPT") {
        let t = Z(Z(n) ? .event_data);
        if (typeof t ? .event_name == "string") {
            e ? .({
                type: "sdk.event",
                key: t.event_name,
                data: t
            });
            return;
        }
    }
    e ? .({
        type: "sdk.event",
        key: t,
        data: n
    });
}
async function bc(e, t, n, r) {
    if (!t.scriptUrl) throw Error("Messaging webview runtime is missing a script URL");
    let i = Ws(await fs(t.scriptUrl));
    window.adaEmbed = i();
    let {
        sessionMirrorArmed: a
    } = await rc(window.adaEmbed, e.postToNative, {
        sessionMirrorPrivileged: r.privileged
    }), o = Ln(Jt({
        handle: e.handle,
        ...e.cluster ? {
            cluster: e.cluster
        } : {},
        ...e.language ? {
            language: e.language
        } : {},
        ...e.greeting ? {
            greeting: e.greeting
        } : {},
        ...e.headless ? {
            headless: !0
        } : {},
        ...e.enableProgrammaticControl ? {
            enableProgrammaticControl: !0
        } : {},
        ...e.metaFields ? {
            metaFields: e.metaFields
        } : {},
        ...e.styles ? {
            styles: e.styles
        } : {},
        ...n.sensitiveMetaFields ? {
            sensitiveMetaFields: n.sensitiveMetaFields
        } : {},
        ...n.identityToken ? {
            identityToken: n.identityToken
        } : {},
        ...n.appUrl ? {
            appUrl: n.appUrl
        } : {},
        allowMetaFieldsInReset: !0,
        parentElement: e.parentElement,
        eventCallbacks: {
            "*": (t, n) => {
                let r = Z(t),
                    i = n ? .eventKey ? ? (typeof r ? .event_name == "string" ? r.event_name : "ada.custom.event");
                e.postToNative ? .({
                    type: "sdk.event",
                    key: i,
                    data: t
                });
            }
        }
    }, e.hostTelemetry));
    a && aa({
        nativeSessionMirror: !0
    });
    try {
        await Promise.resolve(window.adaEmbed.start ? .(o));
    } finally {
        oa();
    }
}
async function xc(e, t) {
    if (!t.iframeUrl || !t.metadataUrl) throw Error("Legacy localhost runtime is missing local Chat assets");
    cc(e.handle);
    let n = document.createElement("iframe");
    n.src = t.iframeUrl, n.style.width = "100%", n.style.height = "100%", n.style.border = "0", n.allow = "clipboard-read; clipboard-write", n.allowFullscreen = !0, e.parentElement.replaceChildren(n);
    let r = {
        handle: e.handle,
        embedStateOverrides: {},
        hostTelemetry: e.hostTelemetry,
        iframe: n,
        language: e.language,
        greeting: e.greeting,
        metaFields: { ...e.metaFields ? ? {}
        },
        sensitiveMetaFields: {},
        ...e.styles ? {
            styles: e.styles
        } : {},
        metadataUrl: t.metadataUrl,
        postToNative: e.postToNative,
        readyPosted: !1
    };
    window.__ADA_BRIDGE_DISPATCH__ = _c(r), lc();
    let i = (t) => {
        if (t.source !== n.contentWindow) return;
        let i = vc(t);
        if (!(!i || typeof i.type != "string")) {
            if (i.type === "GET_WINDOW_ORIGIN") {
                $(n, "SET_WINDOW_ORIGIN", {
                    origin: window.location.origin
                }, typeof i.id == "string" ? i.id : void 0);
                return;
            }
            if (i.type === "GET") {
                $(n, "GET_RESPONSE", fc(r, Z(i.payload) ? .key), typeof i.id == "string" ? i.id : void 0);
                return;
            }
            if (i.type === "GET_STATE") {
                $(n, "GET_STATE_RESPONSE", dc(r), typeof i.id == "string" ? i.id : void 0);
                return;
            }
            if (i.type === "DISPATCH") {
                let e = pc(r, i.payload);
                $(n, "DISPATCH_RESPONSE", e, typeof i.id == "string" ? i.id : void 0), $(n, "STATE_CHANGE", e);
                return;
            }
            if (i.type === "CHAT_STARTED" && !r.readyPosted) {
                r.readyPosted = !0, e.postToNative ? .({
                    type: "sdk.ready"
                });
                return;
            }
            if (i.type === "CHATTER") {
                let e = Z(i.payload);
                typeof e ? .chatter == "string" && (r.chatterToken = e.chatter, hc(r));
            }
            yc(e.postToNative, i.type, i.payload);
        }
    };
    window.addEventListener("message", i), xs = i;
}
async function Sc(e, t) {
    if (t.legacyRuntime === "chat-iframe") {
        await xc(e, t);
        return;
    }
    if (!t.scriptUrl) throw Error("Legacy Ada Embed did not provide a script URL");
    let n = e.parentElement.id || gs;
    window.adaSettings = ic(e, n), await qs(t.scriptUrl);
    let r = window.adaEmbed;
    if (!r ? .start) throw Error("Legacy Ada Embed did not expose window.adaEmbed.start");
    window.__ADA_BRIDGE_DISPATCH__ = Js(r, e.postToNative);
}

function Cc(e) {
    try {
        if (!e) return;
        let t = e.protocol.toLowerCase();
        if (t !== "https:" && t !== "http:") return;
        let {
            pathname: n
        } = e;
        if (!n.toLowerCase().endsWith("/sdk/webview.html")) return;
        let {
            origin: r
        } = e;
        if (!r || r === "null") return;
        let i = e.hostname.toLowerCase(),
            a = x(n.slice(0, n.length - de.length));
        return C(i, {
            additionalHosts: [...p, "10.0.2.2"]
        }) ? `${r}${a}/sdk/index.js` : `${r}${bs.get(i) ?? a}/sdk.js`;
    } catch {
        return;
    }
}

function wc({
    handle: e,
    cluster: t,
    webSdk: n,
    language: r,
    greeting: i,
    hostTelemetry: a,
    metaFields: o
}, s) {
    let c = u(t),
        l = n;
    if (l === "legacy" && c === "localhost") return {
        webSdk: l,
        iframeUrl: sc({
            handle: e,
            language: r,
            greeting: i,
            hostTelemetry: a,
            metaFields: o
        }),
        metadataUrl: js("/api/chatters/data_storage/"),
        legacyRuntime: "chat-iframe"
    };
    if (l === "legacy") return {
        webSdk: l,
        scriptUrl: "https://static.ada.support/embed2.js",
        legacyRuntime: "embed2"
    };
    let f = Cc(s);
    return f ? {
        webSdk: l,
        scriptUrl: f
    } : c === "localhost" ? {
        webSdk: l,
        scriptUrl: js("/sdk/index.js")
    } : d(c) ? {
        webSdk: l,
        scriptUrl: "https://messaging-assets.ada-dev2.support/sdk.js"
    } : {
        webSdk: l,
        scriptUrl: "https://messaging-assets.ada.support/sdk.js"
    };
}

function Tc(e, t = typeof window < "u" ? window.location : void 0) {
    return wc(Ns(e), t);
}
async function Ec(e) {
    let t = zs(e.postToNative),
        n = Is(typeof window < "u" ? window.location : void 0) && t.nativeSessionMirrorSupported === !0;
    Hs(e.postToNative), Vs(t, e.postToNative);
    let r = e.handle.trim();
    if (!r) throw Error("Ada WebView runtime requires a non-empty handle");
    lc();
    let i = Ps({
            ...e,
            handle: r
        }),
        a = wc(i, typeof window < "u" ? window.location : void 0);
    if (i.webSdk === "legacy") {
        Us(t, i.postToNative), await Sc(i, a);
        return;
    }
    i.hostTelemetry = {
        ...i.hostTelemetry,
        nativeViewVisibilitySupported: Is(typeof window < "u" ? window.location : void 0) && t.nativeViewVisibilitySupported === !0 ? !0 : void 0
    }, await bc(i, a, t, {
        privileged: n
    });
}
//#endregion
export {
    Oo as AdaMessagingClient, ii as FrameChannel, oi as FrameChild, ts as createAdaEmbedInterface, us as dispatchEmbedLoaderInitialActionQueue, ds as dispatchEmbedLoaderInitialActionQueueForAtomicHandoff, Ec as mountAdaWebViewRuntime, Tc as resolveAdaWebViewRuntimeAssets, Vn as resolveChatHtmlConfig
};

//# sourceMappingURL=index.js.map