(() => {
    var e, t, n, r, a, o = {
            251(e, t) {
                "use strict";
                var n = this && this.__assign || function() {
                    return n = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }, n.apply(this, arguments)
                };
                t.__esModule = !0, t.createStorage = void 0;
                var r = "Cannot access Web Storage API";
                t.createStorage = function(e) {
                    var t;
                    try {
                        t = "local" === e ? localStorage : sessionStorage
                    } catch (e) {
                        console.warn(r)
                    }
                    var a = {
                        setItem: function(e, n) {
                            try {
                                null == t || t.setItem(e, JSON.stringify(n))
                            } catch (e) {
                                console.warn(r)
                            }
                        },
                        getItem: function(e) {
                            try {
                                var n = null == t ? void 0 : t.getItem(e);
                                return n && JSON.parse(n)
                            } catch (e) {
                                return console.warn(r), null
                            }
                        },
                        removeItem: function(e) {
                            try {
                                null == t || t.removeItem(e)
                            } catch (e) {
                                console.warn(r)
                            }
                        },
                        clear: function() {
                            try {
                                null == t || t.clear()
                            } catch (e) {
                                console.warn(r)
                            }
                        },
                        setFnItem: function(e, t) {
                            var r, o = a.getItem("ada-functional-storage") || {},
                                i = n(n({}, o), ((r = {})[e] = t, r));
                            a.setItem("ada-functional-storage", i)
                        },
                        getFnItem: function(e) {
                            var t = a.getItem("ada-functional-storage");
                            return t && t[e] || null
                        }
                    };
                    return a
                }
            },
            183(e, t, n) {
                "use strict";
                t.BB = void 0;
                var r = n(251);
                t.BB = (0, r.createStorage)("local"), (0, r.createStorage)("session")
            },
            548(e, t, n) {
                "use strict";
                n.a(e, (async (e, t) => {
                    try {
                        var r = n(104);
                        window.__AdaEmbedLoaderVersion = "7be69df7b1b588c397253da2860556a7d4692da1", await (0, r.T)(), t()
                    } catch (e) {
                        t(e)
                    }
                }), 1)
            },
            104(e, t, n) {
                "use strict";
                n.d(t, {
                    T: () => $
                });
                const r = "https://static.ada.support/embed-manifest.json",
                    a = "__ada-embed-start-queued";
                class o extends Error {
                    constructor(e, t) {
                        super(`XHR Error: ${t}`), this.status = e
                    }
                }

                function i(e) {
                    return new Promise(((t, n) => {
                        const r = e.method || "GET",
                            {
                                headers: a
                            } = e,
                            i = new XMLHttpRequest,
                            s = new URL(e.url);
                        s.searchParams.set("ada_request_origin", "embed-loader"), "withCredentials" in i && (i.open(r, s.href, !0), a && Object.keys(a).forEach((e => {
                            i.setRequestHeader(e, a[e])
                        })), i.onload = () => {
                            if (i.status >= 200 && i.status < 300) try {
                                const e = JSON.parse(i.response);
                                t(e)
                            } catch (e) {
                                n(new Error(`JSON Parse Error in XHR Request: ${e}`))
                            } else n(new o(i.status, i.statusText))
                        }, i.onerror = () => n(new Error(`XHR Error: ${i.statusText}`)), i.send(e.body))
                    }))
                }
                var s = n(654);
                const c = n.n(s)()((e => !1));
                async function d(e, t, n) {
                    c(n ? .sampleRate) && await i({
                        url: "https://browser-http-intake.logs.datadoghq.com/v1/input/?ddsource=browser&ddtags=version:1.2.4,env:production",
                        method: "POST",
                        body: JSON.stringify({
                            message: e,
                            ...t,
                            level: n ? .level || "info",
                            sampleRate: n ? .sampleRate || .01,
                            service: "embed-loader",
                            env: "production",
                            version: "1.2.4",
                            commitHash: "7be69df7b1b588c397253da2860556a7d4692da1"
                        })
                    })
                }
                const l = (e, t) => {
                        const n = t || "ada";
                        return e ? e.includes(".") ? e : `${e}.${n}.support` : `${n}.support`
                    },
                    u = ({
                        handle: e,
                        cluster: t,
                        domain: n
                    }) => `https://rollout.${l(t,n)}/${e}/client.json`,
                    f = ({
                        handle: e,
                        cluster: t,
                        domain: n
                    }) => `https://${e}.${l(t,n)}`,
                    h = e => "object" == typeof e && null !== e && !Array.isArray(e);
                class p extends Error {
                    constructor(e) {
                        super(e), this.name = "AdaEmbedLoaderError"
                    }
                }
                const m = e => e && "string" == typeof e.handle && e.handle ? {
                        handle: e.handle,
                        cluster: e.cluster,
                        domain: e.domain
                    } : null,
                    g = () => document.getElementById("__ada"),
                    w = e => {
                        const t = e.getAttribute("data-lazy");
                        return Boolean(t || "" === t)
                    },
                    v = () => {
                        const e = (() => {
                                const {
                                    adaSettings: e
                                } = window;
                                if (e && "object" == typeof e && !Array.isArray(e)) return e
                            })(),
                            t = g();
                        if (!t) return !m(e) || e ? .lazy ? null : e;
                        if (w(t)) return null;
                        const n = t.getAttribute("data-handle") || void 0,
                            r = t.getAttribute("data-domain") || void 0,
                            a = "string" == typeof e ? .handle ? e.handle : void 0,
                            o = {
                                handle: n || a,
                                domain: r,
                                ...e
                            };
                        return m(o) ? o : null
                    },
                    b = () => {
                        const e = v();
                        return e ? {
                            method: "start",
                            arguments: [e]
                        } : null
                    },
                    y = () => {
                        const e = m(window.adaSettings);
                        if (e) return e;
                        const t = window.__AdaEmbedLoaderInitialActionQueue ? .find((e => "start" === e.method));
                        return m(t ? .arguments[0]) || (() => {
                            const e = g();
                            return !e || w(e) ? null : m(v() ? ? void 0)
                        })()
                    },
                    _ = e => e ? .toLowerCase(),
                    E = e => f(e).toLowerCase(),
                    A = (e, t, n) => {
                        for (let a = t; a < n; a += 1) {
                            const t = e[a];
                            if (("object" == typeof(r = t) && null !== r || "function" == typeof r) && "start" === t.method) return !0
                        }
                        var r;
                        return !1
                    },
                    j = (e, t) => {
                        try {
                            if (t instanceof Error) return t
                        } catch {}
                        return new Error("string" == typeof t && t ? t : `adaEmbed.${e}() was rejected`)
                    },
                    L = "The format of manifest file is incorrect";
                var I = n(183);
                const S = e => {
                        try {
                            return I.BB.getItem(e)
                        } catch (t) {
                            return d("Failed to read from localStorage", {
                                key: e,
                                error: t instanceof Error ? t.message : String(t)
                            }, {
                                level: "warn",
                                sampleRate: .005
                            }), null
                        }
                    },
                    O = (e, t) => {
                        try {
                            I.BB.setItem(e, t)
                        } catch (t) {
                            d("Failed to write to localStorage", {
                                key: e,
                                error: t instanceof Error ? t.message : String(t)
                            }, {
                                level: "warn",
                                sampleRate: .005
                            })
                        }
                    },
                    P = e => {
                        const t = new RegExp(`[?&]${e}=([^&#]*)`).exec(window.location.href);
                        return t ? decodeURI(t[1]) : null
                    },
                    M = async () => {
                        const e = P("__ada-embed-version");
                        if (e) return e;
                        if (window.__AdaEmbedVersion) return window.__AdaEmbedVersion;
                        const t = await (async () => {
                            const e = await fetch(r);
                            if (!e.ok) throw await d("Failed to fetch manifest", {
                                url: r,
                                status: e.status,
                                statusText: e.statusText
                            }, {
                                level: "error",
                                sampleRate: 1
                            }), new p(`Failed to fetch manifest: ${e.status} ${e.statusText}`);
                            return e.json()
                        })();
                        let n;
                        try {
                            n = (e => {
                                if (!(e => {
                                        if ("object" != typeof e) throw new p(L);
                                        if (null === e) throw new p(L);
                                        const t = e;
                                        if (!Array.isArray(t.versions)) throw new p(L);
                                        if (!t.versions.length) throw new p(L);
                                        if ("string" != typeof t.versions[0].hash) throw new p(L);
                                        if (!t.versions[0].hash) throw new p(L);
                                        if ("number" != typeof t.versions[0].weight) throw new p(L);
                                        if (1 !== t.versions.reduce(((e, t) => e + t.weight), 0)) throw new p('The sum of version weights must be "1"');
                                        return !0
                                    })(e)) throw new p(L);
                                const t = JSON.stringify(e);
                                if (t === S("ada-embed-manifest-cache")) {
                                    const e = S("ada-embed-assigned-version");
                                    if (e) return e
                                }
                                const n = Math.random(),
                                    {
                                        versions: r
                                    } = e;
                                let {
                                    hash: a
                                } = r[r.length - 1];
                                for (const e of r)
                                    if (n <= e.weight) {
                                        a = e.hash;
                                        break
                                    }
                                return O("ada-embed-assigned-version", a), O("ada-embed-manifest-cache", t), a
                            })(t)
                        } catch (e) {
                            const n = e instanceof Error ? e.message : String(e);
                            throw await d("Manifest validation failed", {
                                manifest: t,
                                error: n
                            }, {
                                level: "error",
                                sampleRate: 1
                            }), e
                        }
                        return n
                    },
                    T = async e => {
                        if (P("__ada-embed-version") || window.__AdaEmbedVersion) return !1;
                        const t = await ((e = 2e3, t) => {
                            const n = y();
                            return n ? Promise.resolve(n) : new Promise((n => {
                                let r;
                                const o = (e = !1) => {
                                        const o = y();
                                        return !(!o && !e || (t ? .(!1), clearInterval(s), clearTimeout(r), window.removeEventListener(a, i), n(o), 0))
                                    },
                                    i = () => o(!0);
                                let s = setInterval(o, 25);
                                r = setTimeout((() => {
                                    clearInterval(s), o(window.__AdaEmbedLoaderInitialActionQueue ? .some((e => "start" === e.method))) || (s = setInterval(o, 250), t ? .(!0), r = setTimeout((() => {
                                        clearInterval(s)
                                    }), 3e4), window.addEventListener(a, i))
                                }), e)
                            }))
                        })(void 0, e);
                        if (!t) return !1;
                        const n = await (async e => {
                            try {
                                return { ...await i({
                                        url: u(e)
                                    }),
                                    source: "cdn",
                                    requestedIdentity: e
                                }
                            } catch (t) {
                                if (Promise.resolve().then((() => d("Failed to fetch client config for SDK selection", {
                                        handle: e.handle,
                                        error: t instanceof Error ? t.message : String(t)
                                    }, {
                                        level: "warn",
                                        sampleRate: .01
                                    }))).catch((() => {})), !(t instanceof o) || 404 !== t.status) return null
                            }
                            const t = new AbortController,
                                n = setTimeout((() => t.abort()), 3e3);
                            try {
                                const r = await fetch(`${f(e)}/api/?url=${encodeURIComponent(window.location.href)}&ada_request_origin=embed-loader`, {
                                    credentials: "omit",
                                    signal: t.signal
                                });
                                if (!r.ok) return null;
                                const a = await r.json(),
                                    o = h(a) ? a.client : void 0;
                                return h(o) && "string" == typeof o.handle && "string" == typeof o.product_type && h(o.features) ? {
                                    source: "api",
                                    requestedIdentity: e,
                                    handle: o.handle,
                                    productType: o.product_type,
                                    features: o.features,
                                    alternativeBotHandle: h(o.alternative_bot) ? o.alternative_bot.handle : void 0
                                } : null
                            } catch {
                                return null
                            } finally {
                                clearTimeout(n)
                            }
                        })(t).catch((() => null));
                        return !1 === n ? .features ? .legacy_chat_embed && ("api" === n.source ? n.handle !== n.requestedIdentity.handle && "generative" === n.productType && !n.alternativeBotHandle && {
                            failover: {
                                requestedIdentity: n.requestedIdentity,
                                handle: n.handle
                            }
                        } : {})
                    },
                    $ = async () => {
                        if (window.__AdaEmbedLoaderScriptLoaded) throw new Error("Ada Embed script is included more than once, skipping.");
                        window.__AdaEmbedLoaderScriptLoaded = !0;
                        const e = (() => {
                            const e = (() => {
                                    let e, t, n, r = "initial",
                                        a = !1,
                                        o = !1,
                                        i = !1,
                                        s = -1;
                                    const c = new Map,
                                        l = new Map,
                                        u = new Map,
                                        f = (e, t, n) => {
                                            const r = l.get(e);
                                            r && (l.delete(e), r.stopListening(), "resolve" === t ? r.resolve(n) : r.reject(j(r.method, n)))
                                        },
                                        h = async (r, a) => {
                                            if (c.delete(r), !e && !n) {
                                                const e = window.__AdaEmbedLoaderInitialActionQueue;
                                                e.splice(e.indexOf(a.action), 1), f(a.action, "resolve", void 0)
                                            }
                                            const o = await a.actualId;
                                            if (void 0 !== o) {
                                                const n = t ? ? e;
                                                await n.unsubscribeEvent(o)
                                            }
                                        },
                                        p = e => {
                                            if (!c.size) return e;
                                            const t = Object.getOwnPropertyDescriptors(e);
                                            return t.unsubscribeEvent = {
                                                value: t => {
                                                    const n = c.get(t);
                                                    return n ? h(t, n) : e.unsubscribeEvent(t)
                                                },
                                                enumerable: !0
                                            }, Object.create(Object.getPrototypeOf(e), t)
                                        },
                                        m = (e, t) => {
                                            const {
                                                method: n
                                            } = e;
                                            if ("start" !== n)
                                                if ("subscribeEvent" !== n)
                                                    if (t.splice(t.indexOf(e), 1), "evaluateCampaignConditions" === n) o || (o = !0, console.warn("Ada Embed - The evaluateCampaignConditions action is deprecated and no longer evaluates campaign conditions."), Promise.resolve().then((() => d("Called deprecated adaEmbed method", {
                                                        method: n
                                                    }, {
                                                        sampleRate: 1
                                                    }))).catch((() => {}))), f(e, "resolve", void 0);
                                                    else if ("unsubscribeEvent" === n) f(e, "resolve", void 0);
                                            else {
                                                const t = new Error("createProactive" !== n || e.arguments[0] ? "Actions cannot be called until Embed has been instantiated. Try running `adaEmbed.start({...})`." : "Cannot call createProactive without body set.");
                                                t.name = "AdaEmbedError", f(e, "reject", t)
                                            } else {
                                                const t = s--;
                                                f(e, "resolve", t);
                                                const r = new Promise((t => {
                                                    l.set(e, {
                                                        method: n,
                                                        resolve: e => t(e),
                                                        reject: () => t(void 0),
                                                        stopListening: () => {}
                                                    })
                                                }));
                                                c.set(t, {
                                                    action: e,
                                                    actualId: r
                                                })
                                            }
                                        };
                                    return {
                                        setWaitingForStart: e => {
                                            if (e && !a) {
                                                const e = window.__AdaEmbedLoaderInitialActionQueue ? ? [];
                                                for (const t of [...e]) m(t, e)
                                            }
                                            a = e
                                        },
                                        enqueue: (o, s) => {
                                            if ("unsubscribeEvent" === s) {
                                                const e = o.arguments[0],
                                                    t = c.get(e);
                                                if (t) return h(e, t)
                                            }
                                            const d = t ? ? (i && e);
                                            if (d) try {
                                                const e = d[o.method];
                                                return "function" != typeof e ? Promise.reject(new Error(t ? `Unknown queued embed-loader action "${o.method}"` : `adaEmbed.${o.method}() is unavailable`)) : Promise.resolve(e.call(d, ...o.arguments)).catch((e => {
                                                    throw j(s, e)
                                                }))
                                            } catch (e) {
                                                return Promise.reject(j(s, e))
                                            }
                                            Array.isArray(window.__AdaEmbedLoaderInitialActionQueue) || (window.__AdaEmbedLoaderInitialActionQueue = []);
                                            const p = n ? ? window.__AdaEmbedLoaderInitialActionQueue;
                                            return new Promise(((e, t) => {
                                                const n = `__ada-embed-action-resolve-${s}`,
                                                    i = `__ada-embed-action-reject-${s}`,
                                                    c = e => {
                                                        "initial" !== r && "legacyFallback" !== r || !l.has(o) || f(o, "resolve", e.detail)
                                                    },
                                                    d = e => {
                                                        "initial" !== r && "legacyFallback" !== r || !l.has(o) || f(o, "reject", e.detail)
                                                    },
                                                    h = () => {
                                                        try {
                                                            window.removeEventListener(n, c)
                                                        } catch {}
                                                        try {
                                                            window.removeEventListener(i, d)
                                                        } catch {}
                                                    };
                                                try {
                                                    l.set(o, {
                                                        method: s,
                                                        resolve: e,
                                                        reject: t,
                                                        stopListening: h
                                                    }), window.addEventListener(n, c), window.addEventListener(i, d), p.push(o), a && m(o, p)
                                                } catch (e) {
                                                    l.delete(o), u.delete(o), h(), t(j(s, e))
                                                }
                                            }))
                                        },
                                        beginLateLegacyHandoff: () => {
                                            const e = window.adaEmbed,
                                                r = window.__AdaEmbedLoaderInitialActionQueue ? ? [];
                                            n = r, window.__AdaEmbedLoaderInitialActionQueue = [];
                                            const a = e => {
                                                for (const t of r) f(t, "reject", e);
                                                r.length = 0
                                            };
                                            return {
                                                onLoad: () => {
                                                    const n = window.adaEmbed;
                                                    if (!n || n === e) return void a(new Error("Legacy Embed loaded without installing its API"));
                                                    window.adaEmbed = p(n);
                                                    const o = r.some((e => "start" === e.method)) ? null : b();
                                                    if (o) {
                                                        const e = async () => {
                                                            try {
                                                                await n.start(o.arguments[0])
                                                            } catch {}
                                                        };
                                                        /comp|inter|loaded/.test(document.readyState) ? e() : document.addEventListener("DOMContentLoaded", e, {
                                                            once: !0
                                                        })
                                                    }
                                                    for (const e of r) try {
                                                        const t = n[e.method];
                                                        if ("function" != typeof t) throw new Error(`Unknown queued embed-loader action "${e.method}"`);
                                                        Promise.resolve(t.apply(n, e.arguments)).then((t => f(e, "resolve", t)), (t => f(e, "reject", t)))
                                                    } catch (t) {
                                                        f(e, "reject", t)
                                                    }
                                                    r.length = 0, t = n
                                                },
                                                onError: () => a(new Error("Failed to load legacy Embed script"))
                                            }
                                        },
                                        beginMessagingHandoff: t => (r = "provisional", e = t, i = !1, p(t)),
                                        commitMessagingHandoff: () => {
                                            r = "messaging";
                                            const e = [...u.values()];
                                            u.clear();
                                            for (const t of e) t()
                                        },
                                        finishMessagingQueueDrain: () => {
                                            i = !0
                                        },
                                        rollbackToLegacy: () => {
                                            r = "legacyFallback", e = void 0, i = !1, u.clear()
                                        },
                                        reportMessagingOutcome: (e, t, n) => {
                                            "initial" !== r && "legacyFallback" !== r && l.has(e) && ("provisional" !== r ? f(e, t, n) : u.has(e) || u.set(e, (() => f(e, t, n))))
                                        }
                                    }
                                })(),
                                t = (t, ...n) => ((e, t, ...n) => {
                                    const r = {
                                        method: t,
                                        arguments: n
                                    };
                                    return e.enqueue(r, t)
                                })(e, t, ...n);
                            return window.adaEmbed = {
                                closeCampaign: (...e) => t("closeCampaign", ...e),
                                start: (...e) => {
                                    const n = t("start", ...e);
                                    return window.dispatchEvent(new Event(a)), n
                                },
                                stop: () => t("stop"),
                                toggle: () => t("toggle"),
                                deleteHistory: () => t("deleteHistory"),
                                reset: (...e) => t("reset", ...e),
                                setMetaFields: (...e) => t("setMetaFields", ...e),
                                setSensitiveMetaFields: (...e) => t("setSensitiveMetaFields", ...e),
                                getInfo: () => t("getInfo"),
                                createProactive: (...e) => t("createProactive", ...e),
                                subscribeEvent: (e, n) => t("subscribeEvent", e, n),
                                unsubscribeEvent: (...e) => t("unsubscribeEvent", ...e),
                                evaluateCampaignConditions: (...e) => t("evaluateCampaignConditions", ...e)
                            }, {
                                setWaitingForStart: e.setWaitingForStart,
                                beginLateLegacyHandoff: e.beginLateLegacyHandoff,
                                beginMessagingHandoff: e.beginMessagingHandoff,
                                commitMessagingHandoff: e.commitMessagingHandoff,
                                finishMessagingQueueDrain: e.finishMessagingQueueDrain,
                                rollbackToLegacy: e.rollbackToLegacy,
                                reportMessagingOutcome: e.reportMessagingOutcome
                            }
                        })();
                        let t = !1;
                        const n = await T((n => {
                            t || = n, e.setWaitingForStart(n)
                        }));
                        if (n) try {
                            if (await (async (e, t, n) => {
                                    const r = await
                                    import ("https://static.ada.support/messaging/sdk.js"), a = r.dispatchEmbedLoaderInitialActionQueueForAtomicHandoff;
                                    if ("function" != typeof a) return !1;
                                    const o = window.adaEmbed,
                                        i = r.createAdaEmbedInterface(),
                                        s = n ? ((e, {
                                            requestedIdentity: t,
                                            handle: n
                                        }) => {
                                            let r = { ...window.adaSettings
                                                },
                                                a = !1;
                                            const o = Object.getOwnPropertyDescriptors(e);
                                            return o.start = {
                                                value: async o => {
                                                    const i = { ...r,
                                                        ...o
                                                    };
                                                    let s = o,
                                                        c = !1;
                                                    if (_(i.handle) === _(t.handle) && E(i) === E(t)) {
                                                        if (s = { ...o,
                                                                handle: n
                                                            }, i.endpoint) try {
                                                            c = new URL(i.endpoint).origin === E(t)
                                                        } catch {}
                                                        c && (s.endpoint = `${f({...t,handle:n})}/api/`)
                                                    } else a && (s = { ...o,
                                                        endpoint: o ? .endpoint
                                                    }, i.endpoint = o ? .endpoint);
                                                    const d = {
                                                        previousOptions: r,
                                                        injectedEndpoint: a
                                                    };
                                                    r = i, a = c;
                                                    try {
                                                        return await e.start(s)
                                                    } catch (e) {
                                                        throw "start_already_active" === e ? .code && ({
                                                            previousOptions: r,
                                                            injectedEndpoint: a
                                                        } = d), e
                                                    }
                                                },
                                                enumerable: !0,
                                                configurable: !0,
                                                writable: !0
                                            }, Object.create(Object.getPrototypeOf(e), o)
                                        })(i, n) : i,
                                        c = window.__AdaEmbedLoaderInitialActionQueue,
                                        d = Array.isArray(c) ? c : [],
                                        l = d.length,
                                        u = Boolean(t && A(d, 0, l)),
                                        h = d.slice(),
                                        p = Boolean(t && !u && A(h, l, h.length)),
                                        m = !t || u || p ? [...h] : [t, ...h],
                                        g = new Set(m);
                                    try {
                                        const t = e.beginMessagingHandoff(s);
                                        return window.__AdaEmbedLoaderInitialActionQueue = m, window.adaEmbed = n && o ? { ...t,
                                            ...o
                                        } : t, await a(t, e.reportMessagingOutcome, e.finishMessagingQueueDrain), e.commitMessagingHandoff(), !0
                                    } catch (t) {
                                        e.rollbackToLegacy();
                                        const n = m.filter((e => !g.has(e))),
                                            r = [...h, ...n];
                                        try {
                                            window.__AdaEmbedLoaderInitialActionQueue = r
                                        } catch {
                                            m.splice(0, m.length, ...r)
                                        }
                                        try {
                                            window.adaEmbed = o
                                        } catch {
                                            Reflect.defineProperty(window, "adaEmbed", {
                                                configurable: !0,
                                                enumerable: !0,
                                                value: o,
                                                writable: !0
                                            })
                                        }
                                        throw t
                                    }
                                })(e, b() ? ? void 0, n.failover)) return
                        } catch (e) {
                            Promise.resolve().then((() => d("Failed to load Messaging SDK, falling back to legacy embed", {
                                error: e instanceof Error ? e.message : String(e)
                            }, {
                                level: "error",
                                sampleRate: 1
                            }))).catch((() => {}))
                        }((e, t) => {
                            const n = e.slice(0, 7),
                                r = `https://static.ada.support/embed2.${n}.js`,
                                a = document.createElement("script");
                            a.type = "text/javascript", a.async = !0;
                            const o = t ? (() => {
                                const e = document.getElementById("__ada"),
                                    t = e ? ? document.createElement("template"),
                                    n = t.getAttribute("data-lazy");
                                return t.setAttribute("data-lazy", ""), e || (t.id = "__ada", document.head.appendChild(t)), () => {
                                    e ? null === n ? t.removeAttribute("data-lazy") : t.setAttribute("data-lazy", n) : t.remove()
                                }
                            })() : () => {};
                            t && (a.onload = () => {
                                o(), t.onLoad()
                            }), a.onerror = () => {
                                o(), t ? .onError(), console.error("Chat is having technical difficulties. Configuration error detected."), d("Failed to load versioned embed script", {
                                    src: r,
                                    version: n,
                                    fullHash: e
                                }, {
                                    level: "error",
                                    sampleRate: 1
                                })
                            }, a.src = r, document.getElementsByTagName("head")[0].appendChild(a)
                        })(await M(), t ? e.beginLateLegacyHandoff() : void 0)
                    }
            },
            654(e) {
                var t, n = "__lodash_hash_undefined__",
                    r = /^\[object .+?Constructor\]$/,
                    a = "object" == typeof globalThis && globalThis && globalThis.Object === Object && globalThis,
                    o = "object" == typeof self && self && self.Object === Object && self,
                    i = a || o || Function("return this")(),
                    s = Array.prototype,
                    c = Function.prototype,
                    d = Object.prototype,
                    l = i["__core-js_shared__"],
                    u = (t = /[^.]+$/.exec(l && l.keys && l.keys.IE_PROTO || "")) ? "Symbol(src)_1." + t : "",
                    f = c.toString,
                    h = d.hasOwnProperty,
                    p = d.toString,
                    m = RegExp("^" + f.call(h).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                    g = s.splice,
                    w = j(i, "Map"),
                    v = j(Object, "create");

                function b(e) {
                    var t = -1,
                        n = e ? e.length : 0;
                    for (this.clear(); ++t < n;) {
                        var r = e[t];
                        this.set(r[0], r[1])
                    }
                }

                function y(e) {
                    var t = -1,
                        n = e ? e.length : 0;
                    for (this.clear(); ++t < n;) {
                        var r = e[t];
                        this.set(r[0], r[1])
                    }
                }

                function _(e) {
                    var t = -1,
                        n = e ? e.length : 0;
                    for (this.clear(); ++t < n;) {
                        var r = e[t];
                        this.set(r[0], r[1])
                    }
                }

                function E(e, t) {
                    for (var n, r, a = e.length; a--;)
                        if ((n = e[a][0]) === (r = t) || n != n && r != r) return a;
                    return -1
                }

                function A(e, t) {
                    var n, r, a = e.__data__;
                    return ("string" == (r = typeof(n = t)) || "number" == r || "symbol" == r || "boolean" == r ? "__proto__" !== n : null === n) ? a["string" == typeof t ? "string" : "hash"] : a.map
                }

                function j(e, t) {
                    var n = function(e, t) {
                        return null == e ? void 0 : e[t]
                    }(e, t);
                    return function(e) {
                        if (!I(e) || u && u in e) return !1;
                        var t = function(e) {
                            var t = I(e) ? p.call(e) : "";
                            return "[object Function]" == t || "[object GeneratorFunction]" == t
                        }(e) || function(e) {
                            var t = !1;
                            if (null != e && "function" != typeof e.toString) try {
                                t = !!(e + "")
                            } catch (e) {}
                            return t
                        }(e) ? m : r;
                        return t.test(function(e) {
                            if (null != e) {
                                try {
                                    return f.call(e)
                                } catch (e) {}
                                try {
                                    return e + ""
                                } catch (e) {}
                            }
                            return ""
                        }(e))
                    }(n) ? n : void 0
                }

                function L(e, t) {
                    if ("function" != typeof e || t && "function" != typeof t) throw new TypeError("Expected a function");
                    var n = function() {
                        var r = arguments,
                            a = t ? t.apply(this, r) : r[0],
                            o = n.cache;
                        if (o.has(a)) return o.get(a);
                        var i = e.apply(this, r);
                        return n.cache = o.set(a, i), i
                    };
                    return n.cache = new(L.Cache || _), n
                }

                function I(e) {
                    var t = typeof e;
                    return !!e && ("object" == t || "function" == t)
                }
                b.prototype.clear = function() {
                    this.__data__ = v ? v(null) : {}
                }, b.prototype.delete = function(e) {
                    return this.has(e) && delete this.__data__[e]
                }, b.prototype.get = function(e) {
                    var t = this.__data__;
                    if (v) {
                        var r = t[e];
                        return r === n ? void 0 : r
                    }
                    return h.call(t, e) ? t[e] : void 0
                }, b.prototype.has = function(e) {
                    var t = this.__data__;
                    return v ? void 0 !== t[e] : h.call(t, e)
                }, b.prototype.set = function(e, t) {
                    return this.__data__[e] = v && void 0 === t ? n : t, this
                }, y.prototype.clear = function() {
                    this.__data__ = []
                }, y.prototype.delete = function(e) {
                    var t = this.__data__,
                        n = E(t, e);
                    return !(n < 0 || (n == t.length - 1 ? t.pop() : g.call(t, n, 1), 0))
                }, y.prototype.get = function(e) {
                    var t = this.__data__,
                        n = E(t, e);
                    return n < 0 ? void 0 : t[n][1]
                }, y.prototype.has = function(e) {
                    return E(this.__data__, e) > -1
                }, y.prototype.set = function(e, t) {
                    var n = this.__data__,
                        r = E(n, e);
                    return r < 0 ? n.push([e, t]) : n[r][1] = t, this
                }, _.prototype.clear = function() {
                    this.__data__ = {
                        hash: new b,
                        map: new(w || y),
                        string: new b
                    }
                }, _.prototype.delete = function(e) {
                    return A(this, e).delete(e)
                }, _.prototype.get = function(e) {
                    return A(this, e).get(e)
                }, _.prototype.has = function(e) {
                    return A(this, e).has(e)
                }, _.prototype.set = function(e, t) {
                    return A(this, e).set(e, t), this
                }, L.Cache = _, e.exports = L
            }
        },
        i = {};

    function s(e) {
        var t = i[e];
        if (void 0 !== t) return t.exports;
        var n = i[e] = {
            exports: {}
        };
        return o[e].call(n.exports, n, n.exports, s), n.exports
    }
    e = "function" == typeof Symbol, t = e ? Symbol("webpack queues") : "__webpack_queues__", n = e ? Symbol("webpack exports") : "__webpack_exports__", r = e ? Symbol("webpack error") : "__webpack_error__", a = e => {
        e && e.d < 1 && (e.d = 1, e.forEach((e => e.r--)), e.forEach((e => e.r-- ? e.r++ : e())))
    }, s.a = (e, o, i) => {
        var s;
        i && ((s = []).d = -1);
        var c, d, l, u = new Set,
            f = e.exports,
            h = new Promise(((e, t) => {
                l = t, d = e
            }));
        h[n] = f, h[t] = e => (s && e(s), u.forEach(e), h.catch((e => {}))), e.exports = h, o((e => {
            var o;
            c = (e => e.map((e => {
                if (null !== e && "object" == typeof e) {
                    if (e[t]) return e;
                    if (e.then) {
                        var o = [];
                        o.d = 0, e.then((e => {
                            i[n] = e, a(o)
                        }), (e => {
                            i[r] = e, a(o)
                        }));
                        var i = {};
                        return i[t] = e => e(o), i
                    }
                }
                var s = {};
                return s[t] = e => {}, s[n] = e, s
            })))(e);
            var i = () => c.map((e => {
                    if (e[r]) throw e[r];
                    return e[n]
                })),
                d = new Promise((e => {
                    (o = () => e(i)).r = 0;
                    var n = e => e !== s && !u.has(e) && (u.add(e), e && !e.d && (o.r++, e.push(o)));
                    c.map((e => e[t](n)))
                }));
            return o.r ? d : i()
        }), (e => (e ? l(h[r] = e) : d(f), a(s)))), s && s.d < 0 && (s.d = 0)
    }, s.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return s.d(t, {
            a: t
        }), t
    }, s.d = (e, t) => {
        for (var n in t) s.o(t, n) && !s.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: t[n]
        })
    }, s.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), s(548)
})();