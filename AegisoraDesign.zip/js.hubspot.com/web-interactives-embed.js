! function() {
    "use strict";
    const e = {
        RECEIVED_ANALYTICS: "HS_CTA_PARENT_RECEIVED_ANALYTICS",
        DEVICE_TYPE: "HS_CTA_PARENT_DEVICE_TYPE",
        PROXY_ANALYTICS_FN_CALLBACK: "HS_CTA_PARENT_PROXY_ANALYTICS_FN",
        INIT: "HS_CTA_PARENT_INIT",
        SHOWING_CTA: "HS_CTA_SHOWING_CTA",
        SEND_EXTRACTED_STYLES: "HS_SEND_EXTRACTED_STYLES",
        STARTED: "HS_CTA_STARTED",
        NAVIGATE_PAGE: "HS_CTA_NAVIGATE_PAGE",
        CLICK_EVENT: "HS_CTA_CLICK_EVENT",
        CLOSE_INTERACTIVE: "HS_CTA_CLOSE_INTERACTIVE",
        HAS_CLOSED: "HS_CTA_HAS_CLOSED",
        NEW_HEIGHT: "HS_CTA_NEW_HEIGHT",
        DISPLAY_CALL_TO_ACTION: "HS_DISPLAY_CALL_TO_ACTION",
        PROXY_ANALYTICS: "HS_CTA_PROXY_ANALYTICS",
        PROXY_ANALYTICS_FN: "HS_CTA_PROXY_ANALYTICS_FN",
        SEND_FORM_DEFINITION: "HS_SEND_FORM_DEFINITION",
        SEND_CTA_CONFIG: "HS_SEND_CTA_CONFIG",
        SEND_EMBED_CONTEXT: "HS_SEND_EMBED_CONTEXT",
        RECEIVE_FILTERED_STYLESHEETS: "RECEIVE_FILTERED_STYLESHEETS",
        SEND_STYLESHEETS: "SEND_STYLESHEETS",
        TRIGGER_CTA: "HS_CTA_TRIGGER_CTA",
        CTA_FORM_SUBMITTED: "HS_CTA_FORM_SUBMITTED",
        V4_FORM_READY: "HS_V4_FORM_READY",
        V4_RECAPTCHA_RENDER: "HS_V4_RECAPTCHA_RENDER",
        V4_RECAPTCHA_EXECUTE: "HS_V4_RECAPTCHA_EXECUTE",
        V4_RECAPTCHA_RESET: "HS_V4_RECAPTCHA_RESET",
        V4_RECAPTCHA_SUCCESS: "HS_V4_RECAPTCHA_SUCCESS",
        V4_RECAPTCHA_EXPIRED: "HS_V4_RECAPTCHA_EXPIRED",
        V4_RECAPTCHA_ERROR: "HS_V4_RECAPTCHA_ERROR",
        SEND_FORM_EXTRA_SUBMISSION_METADATA: "HS_SEND_FORM_EXTRA_SUBMISSION_METADATA",
        SEND_FORM_SUBMISSION_SUCCESS_INFO: "HS_SEND_FORM_SUBMISSION_SUCCESS_INFO",
        SEND_FORM_SUBMISSION_SUCCESS: "HS_SEND_FORM_SUBMISSION_SUCCESS",
        SEND_FORM_SUBMISSION_FAILED: "HS_SEND_FORM_SUBMISSION_FAILED",
        SEND_FORM_INTERACTION_NAVIGATE: "HS_SEND_FORM_INTERACTION_NAVIGATE",
        SEND_FORM_INTERACTION_NAVIGATE_NEXT: "HS_SEND_FORM_INTERACTION_NAVIGATE_NEXT",
        SEND_FORM_INTERACTION_NAVIGATE_PREVIOUS: "HS_SEND_FORM_INTERACTION_NAVIGATE_PREVIOUS",
        GET_FORM_FIELD_VALUES: "HS_GET_FORM_FIELD_VALUES",
        SEND_FORM_FIELD_VALUES: "HS_SEND_FORM_FIELD_VALUES",
        GET_FORM_SUBMISSION_METADATA: "HS_GET_FORM_SUBMISSION_METADATA",
        SEND_FORM_SUBMISSION_METADATA: "HS_SEND_FORM_SUBMISSION_METADATA",
        GET_FIELD_VALUE: "HS_GET_FIELD_VALUE",
        SET_FIELD_VALUE: "HS_SET_FIELD_VALUE",
        SEND_FIELD_VALUE: "HS_SEND_FIELD_VALUE",
        MEETINGS_BOOKING_SUCCESS: "HS_CTA_MEETINGS_BOOKING_SUCCESS"
    };

    function t(e, t = {}) {
        for (const i in t) Object.hasOwnProperty.call(t, i) && (e.style[i] = t[i])
    }

    function i(...e) {
        if (window.location.search.indexOf("hs_debug_interactive") > -1 || window.location.host.includes("local.hsappstatic")) {
            console.log("[web-interactives-embed]", ...e);
            window.location.search.indexOf("hs_is_selenium") > -1 && console.log(...[...e].map((e => JSON.stringify(e))))
        }
    }
    class s {
        constructor() {
            this.listeners = new Map
        }
        on(e, t) {
            if (!this.listeners.has(e)) {
                this.listeners.set(e, [t]);
                return
            }
            const i = this.listeners.get(e);
            this.listeners.set(e, [...i, t])
        }
        off(e) {
            this.listeners.delete(e)
        }
        emit(e, t) {
            const i = this.listeners.get(e);
            i && i.length && i.forEach((e => e(t)))
        }
        reset() {
            this.listeners = new Map
        }
    }

    function n() {
        return new s
    }
    const o = (...e) => {
        i("[GlobalIframeCommunication]", ...e)
    };
    class r {
        constructor() {
            this.iframeCommunicators = new Map;
            this.eventEmitter = n();
            this.reset = () => {
                this.eventEmitter.reset();
                this.iframeCommunicators = new Map
            }
        }
        registerHandler(e, t) {
            this.eventEmitter.on(e, t)
        }
        registerHandlers(e) {
            o("Registering handlers", e);
            Object.keys(e).forEach((t => {
                const i = t,
                    s = e[i];
                s && this.registerHandler(i, s)
            }))
        }
        registerCommunicator(e, t) {
            o("Registering communicator", t);
            const i = this.iframeCommunicators.get(t) || [];
            this.iframeCommunicators.set(t, [...i, e])
        }
        removeCommunicator(e) {
            o("Removing Iframe Communicator from GlobalCommunication: ", e);
            this.iframeCommunicators.delete(e)
        }
        emit(e, t) {
            o("Emitting event", {
                event: e,
                messagePayload: t
            });
            this.eventEmitter.emit(e, t)
        }
        broadcast(e, t) {
            const i = this.iframeCommunicators.get(e);
            if (i) {
                o("Broadcasting", i);
                i.forEach((e => {
                    e.sendMessage(t)
                }))
            } else o("Cannot find communcators array, not broadcasting", e, t)
        }
        broadcastAll(e) {
            o("Broadcasting", e, "to all", this.iframeCommunicators);
            for (const [t, i] of this.iframeCommunicators) this.broadcast(t, e)
        }
    }
    var a = new r;

    function c() {
        return new MessageChannel
    }
    const l = (...e) => {
        i("[iframeCommunication]", ...e)
    };
    class h {
        constructor(t, i) {
            this.queue = [];
            this.initialised = !1;
            this.events = new Map;
            this.eventEmitter = n();
            this.handleMessage = e => {
                if (!e.data || !e.data.type) return;
                const {
                    type: t,
                    payload: i
                } = e.data;
                l("Handling message", {
                    type: t,
                    payload: i
                });
                this.eventEmitter.emit(t, i);
                a.emit(t, Object.assign({}, i, {
                    id: this.id
                }))
            };
            this.handleFrameLoaded = () => {
                if (this.iframe.contentWindow) {
                    l("Iframe loaded", this.iframe);
                    this.iframe.contentWindow.postMessage({
                        type: e.INIT
                    }, "*", [this.channel.port2]);
                    this.initialised = !0;
                    this.flushQueue()
                } else l("Content window not there, not loading")
            };
            this.iframe = t;
            this.id = i;
            this.channel = c();
            this.channel.port1.onmessage = this.handleMessage;
            this.iframe.addEventListener("load", this.handleFrameLoaded);
            l("Iframe communication set up", i, t)
        }
        sendMessage({
            type: e,
            payload: t
        }) {
            if (this.initialised) {
                l("Posting message", {
                    type: e,
                    payload: t
                });
                try {
                    this.channel.port1.postMessage({
                        type: e,
                        payload: t
                    })
                } catch (i) {
                    l("Dropping non-serializable message", {
                        type: e,
                        payload: t
                    }, i)
                }
            } else {
                l("Queueing message", {
                    type: e,
                    payload: t
                });
                this.queue.push({
                    type: e,
                    payload: t
                })
            }
        }
        registerHandler(e, t) {
            this.eventEmitter.on(e, t)
        }
        registerHandlers(e) {
            l("Registering handlers in IframeCommunication", e);
            Object.keys(e).forEach((t => {
                const i = t,
                    s = e[i];
                s && this.registerHandler(i, s)
            }))
        }
        removeHandler(e) {
            l("Removing handler", e);
            this.eventEmitter.off(e)
        }
        remove() {
            l("Removing frame communicator:", this.id);
            this.channel.port1.close();
            a.removeCommunicator(this.id)
        }
        flushQueue() {
            if (this.initialised) {
                l("Flushing queue", this.queue);
                this.queue.forEach((e => {
                    this.sendMessage(e)
                }))
            } else l("Not flushing queue, not initialised")
        }
    }

    function d(e, t) {
        l("Creating iframe communication");
        const i = new h(e, t);
        a.registerCommunicator(i, t);
        return i
    }

    function u(e) {
        const t = window.location.origin.startsWith("http:") ? "http://" : "https://";
        return e.startsWith(t) ? e : `${t}${e.replace(/http(s)?:\/\//,"")}`
    }

    function m(e) {
        e.style.border = "none";
        e.style.height = "100%";
        e.style.width = "100%";
        e.style.visibility = "hidden"
    }

    function g(e, t) {
        const i = document.createElement("iframe");
        i.srcdoc = e;
        Object.keys(t).forEach((e => {
            i.setAttribute(e, t[e])
        }));
        m(i);
        return i
    }

    function p(e, t) {
        const i = document.createElement("iframe");
        i.src = u(e);
        Object.keys(t).forEach((e => {
            i.setAttribute(e, t[e])
        }));
        m(i);
        return i
    }

    function f(e, t, i) {
        e.startsWith("http") || (e = `https://${e}`);
        const s = new URL(e);
        s.searchParams.set(t, i);
        return s.href
    }

    function v(e, t) {
        e.startsWith("http") || (e = `https://${e}`);
        if (0 === Object.keys(t).length) return e;
        const i = new URL(e);
        Object.keys(t).forEach((e => i.searchParams.set(e, t[e])));
        return i.href
    }

    function T(e) {
        e.startsWith("http") || (e = `https://${e}`);
        try {
            return new URL(e).searchParams.has("hs-signature")
        } catch (e) {
            return !1
        }
    }

    function C(e, t) {
        return e.replace(/#.*$/, "") === t.replace(/#.*$/, "")
    }
    const E = (...e) => {
            i("[FrameComponent]", ...e)
        },
        b = () => {};
    class S {
        constructor({
            id: e,
            container: t,
            iframeSrc: i,
            resizeHeight: s,
            onFrameReady: n,
            useResponsiveStyling: o,
            extraAttributes: r = {},
            srcdoc: a
        }) {
            this.onFrameReady = b;
            this.resizeHeight = !0;
            this.handleHeightChange = ({
                height: e
            }) => {
                if (!this.resizeHeight) return;
                const t = e + 2 * parseInt(getComputedStyle(this.iframe).borderTopWidth, 10);
                E("Handle height change", this.id, {
                    adjustedHeight: t,
                    height: e
                });
                this.setContainerStyle({
                    height: `${t}px`
                })
            };
            this.id = e;
            this.resizeHeight = s;
            if (o && i && !T(i)) {
                E("Responsive styling is enabled", e);
                i = f(i, "enableResponsiveStyles", "true")
            }
            if (i) this.iframe = p(i, r);
            else if (a) this.iframe = g(a, r);
            else {
                E("No iframeSrc or srcdoc provided, creating empty iframe", e);
                this.iframe = p("", r)
            }
            this.container = t;
            this.iframeCommunicator = d(this.iframe, e);
            n && (this.onFrameReady = n);
            t.appendChild(this.iframe);
            this.registerHandlers()
        }
        registerHandlers() {
            this.iframeCommunicator.registerHandlers({
                [e.STARTED]: this.onFrameReady,
                [e.NEW_HEIGHT]: this.handleHeightChange
            })
        }
        setStyle(e) {
            E("Set style", this.id, e);
            t(this.iframe, e)
        }
        setShouldResize(e) {
            this.resizeHeight = e
        }
        setContainerStyle(e) {
            t(this.container, e)
        }
    }

    function y(e) {
        return new S(e)
    }
    class w {
        constructor(e, t) {
            this.listeners = new Set;
            this.batching = !1;
            this.queue = [];
            this.subscribe = e => {
                this.listeners.add(e);
                let t = () => {};
                this.options && this.options.onSubscribe && (t = this.options.onSubscribe(e, this));
                return () => {
                    this.listeners.delete(e);
                    t()
                }
            };
            this.setState = e => {
                const t = this.state;
                this.options && this.options.updateFn ? this.state = this.options.updateFn(t)(e) : this.state = e(t);
                if (this.state !== t) {
                    this.queue.push((() => {
                        this.listeners.forEach((e => e(this.state, t)));
                        this.options && this.options.onUpdate && this.options.onUpdate(this.state, t)
                    }));
                    this._flush()
                }
            };
            this._flush = () => {
                if (!this.batching) {
                    this.queue.forEach((e => e()));
                    this.queue = []
                }
            };
            this.batch = e => {
                this.batching = !0;
                e();
                this.batching = !1;
                this._flush()
            };
            this.state = e;
            this.options = t
        }
    }
    class A {
        constructor() {
            this.storage = []
        }
        enqueue(e) {
            this.storage.push(e)
        }
        dequeue() {
            return this.storage.shift()
        }
        peek() {
            return this.storage[0]
        }
        size() {
            return this.storage.length
        }
    }

    function I() {
        return new A
    }

    function _(e, t = !1) {
        !window.navigator.userAgent.includes("Firefox") && t ? window.open(e, "_blank", "noopener") : window.location.assign(e)
    }
    const O = "hubspotutk",
        M = "__hstc",
        P = "__hssc",
        L = e => {
            const t = document.cookie.match(`(^|[^;]+)\\s*${e}\\s*=\\s*([^;]+)`);
            return t ? t.pop() : ""
        },
        R = () => L(O),
        N = () => L(M),
        F = () => L(P),
        k = (...e) => {
            i("[models/Analytics]", ...e)
        };
    class H {
        constructor() {
            this._handleFetchSucceded = e => {
                this.store.setState((t => {
                    const i = {};
                    i.path = e.path;
                    i.referrerPath = e.referrerPath;
                    i.referrer = "";
                    i.analyticsPageId = e.pageId;
                    i.hsfp = e._getFingerprint();
                    i.canonicalUrl = e.canonicalUrl;
                    i.contentType = e.contentType;
                    i.pageId = H.getPageId() || e.pageId;
                    e.session && (i.hssc = e.session.get());
                    if (e.utk) {
                        i.hstc = e.utk.get();
                        i.hutk = e.utk.visitor
                    }
                    return Object.assign({}, t, i, {
                        isLoaded: !0
                    })
                }))
            };
            window._hsq = window._hsq || [];
            const e = {
                isLoaded: !1,
                pageUrl: window.location.href,
                pageTitle: window.document.title,
                referrer: window.document.referrer,
                userAgent: window.navigator.userAgent,
                hutk: R(),
                hssc: F(),
                hstc: N(),
                pageId: H.getPageId()
            };
            this.store = new w(e);
            this.fetchAnalytics()
        }
        fetchAnalytics() {
            this._analyticsQueue.push(this._handleFetchSucceded)
        }
        refresh() {
            const e = new Promise((e => {
                    this._analyticsQueue.push((t => {
                        this._handleFetchSucceded(t);
                        e()
                    }))
                })),
                t = new Promise((e => setTimeout(e, 100)));
            return Promise.race([e, t])
        }
        subscribe(e) {
            return this.store.subscribe(e)
        }
        get analytics() {
            return this.store.state
        }
        track(e) {
            k("Tracking analytics", e);
            this._analyticsQueue.push(e)
        }
        get _analyticsQueue() {
            return window._hsq
        }
        static getPageId() {
            const e = window.hsVars;
            return e && e.analytics_page_id ? e.analytics_page_id : e && e.page_id ? e.page_id : null
        }
        static getLanguage() {
            const e = window.hsVars;
            return e && e.language ? e.language : null
        }
    }
    var D = new H;
    const V = (...e) => {
            i("[AnalyticsProxyController]", ...e)
        },
        B = ["trackFormView", "trackFormVisible", "trackFormInteraction"];
    class x {
        constructor({
            applicationController: e,
            analyticsStore: t
        }) {
            this.viewQueue = new Map;
            this.applicationController = e;
            this.analyticsStore = t;
            this.listenForAnalyticsUpdate();
            this.listenForProxyMessage()
        }
        listenForAnalyticsUpdate() {
            this.analyticsStore.subscribe(((t, i) => {
                !i.isLoaded && t.isLoaded && a.broadcastAll({
                    type: e.RECEIVED_ANALYTICS,
                    payload: t
                })
            }))
        }
        flushViewQueue(e) {
            const t = this.viewQueue.get(e) || [];
            for (const e of t) this.analyticsStore.track(e);
            this.viewQueue.delete(e)
        }
        handleFormView(e, t) {
            const i = this.applicationController.viewedStore;
            if (i && i.hasBeenViewed(e)) {
                this.analyticsStore.track(t);
                return
            }
            const s = this.viewQueue.get(e) || [];
            V("Adding form view to analytics queue", {
                id: e,
                analytics: t
            });
            this.viewQueue.set(e, [...s, t])
        }
        listenForProxyMessage() {
            a.registerHandlers({
                [e.PROXY_ANALYTICS]: ({
                    analytics: e,
                    id: t
                }) => {
                    x.isFormView(e) ? this.handleFormView(t, e) : this.analyticsStore.track(e)
                },
                [e.STARTED]: ({
                    id: t
                }) => {
                    this.analyticsStore.analytics.isLoaded && a.broadcast(t, {
                        type: e.RECEIVED_ANALYTICS,
                        payload: this.analyticsStore.analytics
                    })
                }
            })
        }
        static isFormView(e) {
            const [t] = e;
            return B.includes(t)
        }
    }
    class U {
        constructor({
            applicationController: e
        }) {
            this.applicationController = e;
            this.listenForNavigation()
        }
        listenForNavigation() {
            a.registerHandlers({
                [e.NAVIGATE_PAGE]: ({
                    url: e,
                    openNewTab: t,
                    id: i
                }) => {
                    const s = this.applicationController.getNavigationUrl({
                        url: e,
                        openNewTab: t
                    }, i);
                    if (t) return;
                    _(s, this.applicationController.getShouldOpenNewTab({
                        url: e,
                        openNewTab: t
                    }, i))
                }
            })
        }
    }
    class $ {
        constructor() {
            this.extractedStyles = {
                rules: {},
                keyframes: {}
            };
            this.crossOriginStyleSheets = new Set
        }
        extractStyles() {
            const e = {
                rules: {},
                keyframes: {}
            };
            for (const t of document.styleSheets)
                if (!this.crossOriginStyleSheets.has(t)) try {
                    const i = t.cssRules || t.rules;
                    for (const t of i) t instanceof CSSStyleRule ? e.rules[t.selectorText] = this.extractProperties(t.style) : t instanceof CSSKeyframesRule && (e.keyframes[t.name] = this.extractKeyframes(t))
                } catch (e) {
                    this.crossOriginStyleSheets.add(t)
                }
            this.extractedStyles = e
        }
        extractProperties(e) {
            const t = {};
            for (const i of Array.from(e)) t[i] = e.getPropertyValue(i);
            return t
        }
        extractKeyframes(e) {
            const t = [];
            for (const i of e.cssRules) {
                if (!(i instanceof CSSKeyframeRule)) continue;
                const e = this.extractProperties(i.style);
                t.push({
                    keyText: i.keyText,
                    style: e
                })
            }
            return t
        }
    }
    class G {
        constructor() {
            this.analyticsStore = D;
            this.analyticsProxyController = new x({
                analyticsStore: this.analyticsStore,
                applicationController: this
            });
            this.navigationProxyController = new U({
                applicationController: this
            });
            this.styleExtractorController = new $
        }
        getNavigationUrl(e, t) {
            return e.url
        }
        getShouldOpenNewTab(e, t) {
            return e.openNewTab
        }
    }
    class q {
        constructor() {
            this.handleIntersection = e => {
                e.forEach((e => {
                    if (e.isIntersecting) {
                        const t = e.target;
                        this.onElementAppear(t);
                        this.observedElements.delete(t);
                        this.observer.unobserve(t)
                    }
                }))
            };
            this.observer = new IntersectionObserver(this.handleIntersection, {
                threshold: .5
            });
            this.observedElements = new Map
        }
        onElementAppear(e) {
            const t = this.observedElements.get(e);
            t && t(e)
        }
        observe(e, t) {
            if ((() => {
                    const t = e.getBoundingClientRect(),
                        i = window.innerHeight;
                    return t.bottom >= 0 && t.top < i
                })()) t(e);
            else if (!this.observedElements.has(e)) {
                this.observedElements.set(e, t);
                this.observer.observe(e)
            }
        }
        unobserve(e) {
            if (this.observedElements.has(e)) {
                this.observedElements.delete(e);
                this.observer.unobserve(e)
            }
        }
    }

    function j() {
        return new q
    }

    function z(e, t) {
        const i = [...e].filter((([e, i]) => t(i, e)));
        return new Map(i)
    }

    function W(e, t) {
        const i = [...e].sort((([e, i], [s, n]) => t(i, n)));
        return new Map(i)
    }

    function Y(e, t) {
        const i = new Map(e);
        for (const [e, s] of t) i.set(e, s);
        return i
    }

    function Q(e) {
        const t = t => {
            "Escape" === t.key && e()
        };
        document.addEventListener("keydown", t);
        return () => {
            document.removeEventListener("keydown", t)
        }
    }

    function X(e, t) {
        let i, s = 0;
        return function() {
            const n = this,
                o = arguments,
                r = Date.now();
            if (r - s >= t) {
                i && window.clearTimeout(i);
                e.apply(n, o);
                s = r
            } else i || (i = window.setTimeout((() => {
                e.apply(n, o);
                s = Date.now();
                i = void 0
            }), t))
        }
    }
    const K = ["api", "local", "app", "private", "platform", "tools", "meetings", "payments", "mcp"],
        J = ["hubspotstarter", "hubspotfree", "hubspotemail"],
        Z = ["growth"],
        ee = ["breeze"],
        te = {
            com: ["hubspot", "hubteam", "grader", "getsignals", "getsidekick", "gettally", "hubspotemail", "customer-hub", "hubspotservicehub", "hubspotquote", "hubspotdocuments", "hubspotrecap", "hs-data-privacy"].join("|"),
            net: J.join("|"),
            org: Z.join("|"),
            ai: ee.join("|")
        },
        ie = function e(t) {
            const i = new RegExp(`^(?!local|test|selenium)(.*\\.)?(${Object.entries(te).map((([e,t])=>`(?:${t})(qa)?\\.${e}`)).join("|")}|(?:connect)\\.com|(?:connect)(qa)\\.co|wthubspot\\.(com|de|es|fr|jp))$`),
                s = new RegExp("^(?:[^.]+)\\.(?:preview).app(-[a-z]+[0-9])?\\.hubspotqa\\.com"),
                n = new RegExp("^(?:[^.]+)\\.(?:local)\\.(app|tools|private)(-[a-z]+[0-9])?\\.(hubspot|hubteam)(qa)?\\.com"),
                o = new RegExp("^(?:[^.]+)\\.local(-[a-z]+[0-9])?\\.(hubspot|hubteam)(qa)?\\.com"),
                r = i.test(t.hostname),
                a = n.test(t.hostname) || o.test(t.hostname),
                c = s.test(t.hostname),
                l = r && !a || c,
                h = new RegExp(`${Object.entries(te).map((([e,t])=>`(?:${t})qa\\.${e}`)).join("|")}|(?:connect)qa\\.co|wthubspot\\.(com|de|es|fr|jp)|hsqa-sales(?:crm)?-sub\\.com|(?:hubspotstarter|hubspotfree|hubspotemail)(qa)(?:-.*)\\.net|(?:hubspotemail)(qa)(?:-.*)\\.com`),
                d = [new RegExp(`^(?:${K.join("|")})-([a-z0-9]+)\\.(?:hubspot|hubteam)(?:qa)?\\.com`), new RegExp("^(.*).(?:hubspotquote)(?:qa)?.com"), new RegExp("^app-(.*).(?:hubspotdocuments)(?:qa)?.com"), new RegExp("^app-(.*).(?:hubspotrecap)(?:qa)?.com"), new RegExp("^artifacts-(.*).(?:breeze)(?:qa)?.ai"), new RegExp("^(?:[0-9]+).(.*).hs(?:qa)?-sales(?:crm)?-sub.com"), new RegExp("^(?:[a-zA-Z0-9-]+)\\.([a-z0-9]+)\\.hs(?:qa)?-sales(?:crm)?-sub\\.com"), new RegExp("^hs-(?:[0-9]+).s.(?:hubspotfree|hubspotstarter|hubspotemail)(?:qa)?-(.*).net"), new RegExp("^hs-(?:[0-9]+).s.(?:hubspotemail)(?:qa)?-(.*).com"), new RegExp("^t.sidekickopen(?:\\d)+-([a-z]+[0-9]).com"), new RegExp("^([a-z]+[0-9]).hs-data-privacy(?:qa)?.com"), new RegExp("^(?:[^.]+)\\.(?:preview|local)\\.app-([a-z]+[0-9])\\.hubspot(qa)?\\.com"), new RegExp("^(?:[^.]+)\\.local-([a-z]+[0-9])\\.(hubspot|hubteam)(qa)?\\.com")],
                u = "ENV",
                m = "Enviro error: the default argument for .get and .getShort is no longer supported",
                g = e => {
                    let t = window[e];
                    if (null == t) try {
                        t = window.sessionStorage.getItem(e)
                    } catch (e) {}
                    if (null == t) try {
                        t = window.localStorage.getItem(e)
                    } catch (e) {}
                    return t
                },
                p = () => {
                    const e = g(u);
                    return e || (h.test(t.host) ? "qa" : "prod")
                },
                f = (e, t) => {
                    window[e] = t;
                    return t
                },
                v = {
                    prod: "production",
                    qa: "development"
                },
                T = e => {
                    if ("string" == typeof e) {
                        const t = e.toLowerCase();
                        return v[t] || t
                    }
                    return e
                },
                C = e => {
                    e = "string" == typeof e ? e.toLowerCase() : void 0;
                    return Object.keys(v).find((t => e === v[t])) || e
                },
                E = (e, t) => {
                    if (null != t) throw new Error(m);
                    let i = null;
                    if (e) {
                        const t = e.split(".").reverse();
                        for (let e = 0; e < t.length; e++) {
                            const s = t[e];
                            i = g(`${s.toUpperCase()}_ENV`);
                            if (i) break
                        }
                    }
                    if (null == i) {
                        const e = p();
                        i = null != e ? e : "qa"
                    }
                    return T(i)
                },
                b = function(e, t) {
                    if (1 === arguments.length) {
                        t = e;
                        e = u
                    }
                    return f(e, t)
                },
                S = (e, t) => {
                    if (null != t) throw new Error(m);
                    return C(E(e))
                },
                y = S,
                w = e => "prod" === y(e),
                A = e => "qa" === y(e),
                I = () => {
                    const e = g("HUBLET");
                    if (e) return e;
                    for (const e of d)
                        if (e.test(t.hostname)) return e.exec(t.hostname)[1];
                    return "na1"
                };

            function _({
                isNa1: e,
                isNonNa1: t
            }, i) {
                i || (i = I());
                return "na1" === i ? "function" == typeof e ? e(i) : void 0 : "function" == typeof t ? t(i) : void 0
            }
            return {
                createEnviro: e,
                debug: (e, t = !1) => {
                    let i;
                    "string" == typeof e && (i = g(`${e.toUpperCase()}_DEBUG`));
                    null == i && (i = g("DEBUG"));
                    return null == i ? t : i
                },
                denormalize: C,
                deployed: e => {
                    let t;
                    "string" == typeof e && (t = g(`${e.toUpperCase()}_DEPLOYED`));
                    null == t && (t = g("DEPLOYED"));
                    return null == t ? l : !!t
                },
                enabled: (e, t = !1) => {
                    let i = g(`${e.toUpperCase()}_ENABLED`);
                    null == i && (i = JSON.stringify(t));
                    return "true" === `${i}`.toLowerCase()
                },
                get: E,
                getHublet: I,
                getInternal: S,
                getShort: y,
                isProd: w,
                isQa: A,
                ifHublet: _,
                normalize: T,
                set: b,
                setDebug: (e, t = !0) => {
                    if ("string" == typeof e) try {
                        t ? localStorage.setItem(`${e.toUpperCase()}_DEBUG`, JSON.stringify(!0)) : localStorage.removeItem(`${e.toUpperCase()}_DEBUG`)
                    } catch (i) {
                        f(`${e.toUpperCase()}_DEBUG`, t || void 0)
                    } else {
                        t = null == e || e;
                        try {
                            t ? localStorage.setItem("DEBUG", JSON.stringify(t)) : localStorage.removeItem("DEBUG")
                        } catch (e) {
                            f("DEBUG", t || void 0)
                        }
                    }
                }
            }
        };
    ie(document.location);
    const se = {
            BANNER: "BANNER",
            MODAL: "MODAL",
            SLIDE_IN: "SLIDE_IN",
            EMBEDDED: "EMBEDDED"
        },
        ne = "na1",
        oe = e => /^app(-[a-z1-9]{3})?.hubspot(qa)?.com$/.test(e),
        re = () => document.getElementById("hubspot-web-interactives-loader"),
        ae = (e, t) => {
            if (!t) return null;
            const i = t.getAttribute(e);
            return i || null
        },
        ce = e => {
            const t = ae("data-hsjs-portal", e);
            return t ? parseInt(t, 10) : null
        },
        le = e => {
            const t = ae("data-hsjs-env", e);
            return t || "prod"
        },
        he = e => {
            const t = ae("data-hsjs-hublet", e);
            return t || ne
        },
        de = e => {
            const t = ae("data-hsjs-local", e);
            return !!t && "true" === t
        },
        ue = e => ae("src", e),
        me = () => {
            const e = re();
            return e ? {
                portalId: ce(e),
                env: le(e),
                hublet: he(e),
                isLocal: de(e),
                src: ue(e)
            } : null
        },
        ge = () => window,
        pe = () => "about:blank" === ge().location.href || oe(window.location.hostname),
        fe = ["previewInteractiveId", "preview_web_interactive", "preview_key", "_preview", "portalId", "hs_preview", "parentPageUrl"];

    function ve() {
        const e = new URLSearchParams(ge().location.search),
            t = {};
        e.forEach(((e, i) => {
            fe.includes(i) || (t[i] = e)
        }));
        return t
    }

    function Te({
        contentId: e,
        portalId: t,
        env: i,
        hublet: s,
        useSameOrigin: n = !1
    }) {
        const o = "qa" === i ? "qa" : "",
            r = s === ne ? "" : `-${s}`,
            a = document.location.protocol;
        return n ? `${window.location.origin}/hs-web-interactive-${t}-${e}` : `${a}//${t}.hs-sites${o}${r}.com/hs-web-interactive-${t}-${e}`
    }

    function Ce(e, t, i) {
        if (T(e)) return e;
        const s = ge();
        let n = {};
        t.contactPreviewEmail && (n.email = t.contactPreviewEmail);
        const o = i.analytics;
        if (o) {
            const e = o.hutk;
            e && (n.utk = e);
            if (t.isUngatedFor("Permissions:Personalize")) {
                const e = o.hstc;
                e && (n.hstc = e)
            }
        }
        s.location.search.includes("hs_debug_interactive") && (n.hs_debug_interactive = "true");
        t.isScreenshot && (n.isScreenshot = "true");
        const r = ve();
        n = Object.assign({}, r, n);
        if (t.currentUrl && t.currentUrl.startsWith("http")) {
            const e = new URL(t.currentUrl);
            n.parentPageUrl = e.origin + e.pathname
        }
        return v(e, n)
    }

    function Ee(e, t) {
        if (null == e) return {};
        var i, s, n = {},
            o = Object.keys(e);
        for (s = 0; s < o.length; s++) {
            i = o[s];
            t.indexOf(i) >= 0 || (n[i] = e[i])
        }
        return n
    }
    const be = {
        APP: "app",
        APP_API: "app-api"
    };

    function Se(e, t) {
        const i = t && t.hubletOverride ? t.hubletOverride : e,
            s = t && !0 === t.hubletizeNa1;
        return i !== ne || s ? `-${i}` : ""
    }

    function ye(e, t, i) {
        if (i && i.hubletPostfixLocation && "domain" === i.hubletPostfixLocation) return t;
        t === be.APP_API && (t = be.APP);
        return `${t}${Se(e,i)}`
    }

    function we(e, t, i) {
        return `${Ie(i)}${Ae(t,i)}${_e(e,i)}`
    }

    function Ae(e, t) {
        return "qa" === (t && t.envOverride ? t.envOverride : e) ? "qa" : ""
    }

    function Ie(e) {
        return e && e.domainOverride ? e.domainOverride : "hubspot"
    }

    function _e(e, t) {
        return t && t.hubletPostfixLocation && "domain" === t.hubletPostfixLocation ? Se(e, t) : ""
    }

    function Oe(e) {
        return e && e.tldOverride ? e.tldOverride : "com"
    }

    function Me(e) {
        return e === be.APP_API ? "/api" : ""
    }

    function Pe(e, t, i, s) {
        return `https://${ye(t,e,s)}.${we(t,i,s)}.${Oe(s)}${Me(e)}`
    }

    function Le(e, t) {
        t.hutk && e.searchParams.set("utk", `${t.hutk}`);
        t.hstc && e.searchParams.set("__hstc", `${t.hstc}`);
        t.hssc && e.searchParams.set("__hssc", `${t.hssc}`);
        t.referrer && e.searchParams.set("referrer", `${t.referrer}`);
        t.pageId && e.searchParams.set("contentId", t.pageId)
    }

    function Re({
        contentIds: e,
        currentUrl: t,
        isPreview: i,
        portalId: s,
        env: n,
        hublet: o = ne,
        versionId: r,
        analytics: a,
        extraParams: c,
        path: l
    }) {
        let h = "";
        if (window.location.search.includes("useLocalPublicService")) h = `https://local.hubspotqa.com/web-interactives/public/v1/${l}`;
        else {
            h = Pe(o === ne ? "cta-service-cms2" : "cta", o, n, {
                tldOverride: "com",
                domainOverride: "hubspot"
            });
            h = `${h}/web-interactives/public/v1/${l}`
        }
        const d = new URL(h);
        i && d.searchParams.set("isPreview", "true");
        e && e.length && e.forEach((e => d.searchParams.append("contentIds", `${e}`)));
        s && d.searchParams.set("portalId", `${s}`);
        t && !i && d.searchParams.set("currentUrl", t);
        r && d.searchParams.set("versionId", `${r}`);
        a && !i && Le(d, a);
        c && Object.keys(c).forEach((e => d.searchParams.set(e, `${c[e]}`)));
        return d.href
    }
    const Ne = ["previewScheduled", "templatePath", "isMobile"],
        Fe = "embed/combinedConfigs",
        ke = "embed/templateConfig";

    function He(e) {
        let {
            previewScheduled: t,
            templatePath: i,
            isMobile: s
        } = e, n = Ee(e, Ne), o = "";
        o = i ? ke : Fe;
        const r = {};
        t && (r.previewScheduled = "true");
        i && (r.templatePath = i);
        s && (r.isMobile = "true");
        return Re(Object.assign({}, n, {
            extraParams: r,
            path: o
        }))
    }
    const De = {
            TOP: "TOP",
            BOTTOM: "BOTTOM",
            TOP_LEFT: "TOP_LEFT",
            TOP_RIGHT: "TOP_RIGHT",
            BOTTOM_LEFT: "BOTTOM_LEFT",
            BOTTOM_RIGHT: "BOTTOM_RIGHT"
        },
        Ve = -1,
        Be = (e, t = 1) => {
            if (!e) return {
                r: null,
                g: null,
                b: null,
                a: t
            };
            if (3 === (e = e.replace("#", "")).length) {
                const t = e.split("").reduce(((e, t) => e + t + t), "");
                e = t
            }
            return {
                r: parseInt(e.substring(0, 2), 16),
                g: parseInt(e.substring(2, 4), 16),
                b: parseInt(e.substring(4, 6), 16),
                a: t
            }
        },
        xe = (e, t = 1) => {
            const i = Be(e, t);
            return `rgba(${i.r}, ${i.g}, ${i.b}, ${i.a})`
        };
    class Ue {
        constructor() {
            this.fetchConfigs = () => {
                const e = this.store.state.configRequest;
                if (!e) return Promise.resolve(null);
                const t = He(e);
                return this.fetch(t)
            };
            this.handleFetchFailed = () => {
                this.store.setState((e => Object.assign({}, e, {
                    requestError: !0
                })))
            };
            this.handleFetchSucceded = ({
                sortedAudienceConfigs: e,
                requestedConfigs: t
            }) => {
                const i = structuredClone(this.configs);
                e && e.length && e.forEach((e => i.set(e.contentModelId, e)));
                t && t.length && t.forEach((e => {
                    i.has(e.contentModelId) || i.set(e.contentModelId, e)
                }));
                this.store.setState((e => Object.assign({}, e, {
                    configs: i,
                    isLoaded: !0
                })))
            };
            this.handleTemplateSucceded = e => {
                const t = Object.assign({}, e, {
                    contentModelId: Ve
                });
                this.store.setState((e => Object.assign({}, e, {
                    templateConfig: t,
                    isLoaded: !0
                })))
            };
            const e = {
                configs: new Map,
                configRequest: null,
                requestError: !1,
                isLoaded: !1
            };
            this.store = new w(e)
        }
        init(e) {
            this.store.setState((t => Object.assign({}, t, {
                configRequest: e
            })));
            return this.fetchConfigs()
        }
        subscribe(e) {
            return this.store.subscribe(e)
        }
        get configs() {
            return this.store.state.configs
        }
        get isLoaded() {
            return this.store.state.isLoaded
        }
        get sortedConfigsWithSpecificty() {
            return W(this.configsWithAudience, ((e, t) => t.specificity - e.specificity))
        }
        get configsWithAudience() {
            return z(this.configs, (e => e.specificity > 0))
        }
        get overlayedConfigsWithNoAudience() {
            return z(this.overlayedConfigs, (e => !e.specificity))
        }
        get overlayedConfigs() {
            return z(this.configs, (e => e.containerType !== se.EMBEDDED))
        }
        get embeddedConfigs() {
            const e = z(this.configs, (e => e.containerType === se.EMBEDDED));
            this.templateConfig && this.templateConfig.containerType === se.EMBEDDED && e.set(Ve, this.templateConfig);
            return e
        }
        get templateConfig() {
            return this.store.state.templateConfig
        }
        get previewConfig() {
            const [e] = this.store.state.configs.values();
            return e
        }
        fetch(e) {
            return window.hsWebInteractivesConfigResponseOverride && pe() ? Promise.resolve(window.hsWebInteractivesConfigResponseOverride).then((e => {
                if (!e) {
                    this.handleFetchFailed();
                    return Promise.resolve(null)
                }
                e.templatePath ? this.handleTemplateSucceded(e) : this.handleFetchSucceded(e);
                return e
            })) : fetch(e).then((e => {
                if (!e.ok) {
                    this.handleFetchFailed();
                    return Promise.resolve(null)
                }
                return e.json().then((e => {
                    e.templatePath ? this.handleTemplateSucceded(e) : this.handleFetchSucceded(e);
                    return e
                })).catch(this.handleFetchFailed)
            })).catch(this.handleFetchFailed)
        }
        fetchConfigsWithIds(e) {
            const t = this.store.state.configRequest;
            if (!t) return;
            const i = He(Object.assign({}, t, {
                contentIds: e
            }));
            this.fetch(i)
        }
        static getStylesFromContainerStyles(e) {
            let t = e.width.value || 5,
                i = e.height.value || 5;
            "px" === e.width.units && (t = Math.max(t, 5));
            "px" === e.height.units && (i = Math.max(i, 5));
            return {
                width: `${t}${e.width.units}`,
                height: `${i}${e.height.units}`
            }
        }
        static getStylesForIframe(e) {
            const t = {},
                {
                    border: i,
                    borderRadius: s,
                    boxShadow: n
                } = e;
            i && (t.border = `${i.width.value}${i.width.units} ${i.style} ${xe(i.color,i.opacity/100)}`);
            n && n.css && (t.boxShadow = n.css.split(":")[1]);
            s && (t.borderRadius = `${s.value}${s.units}`);
            return t
        }
        static isFloatingButtonLike(e) {
            return "isDismissable" in e && (e.containerType === se.SLIDE_IN && !e.isDismissable)
        }
        static isTopBannerLike(e) {
            return e.containerType === se.BANNER && e.containerStyles.position === De.TOP
        }
        static buildConfigRequest(e, t = [], i) {
            const {
                isPreview: s,
                currentUrl: n,
                portalId: o,
                env: r,
                hublet: a,
                isMobile: c,
                templatePath: l,
                versionId: h
            } = e;
            return {
                contentIds: t,
                currentUrl: n,
                portalId: o,
                env: r,
                hublet: a,
                analytics: Object.assign({}, i),
                isMobile: c,
                isPreview: s,
                templatePath: l,
                versionId: h
            }
        }
    }
    var $e = new Ue;
    const Ge = () => /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
        qe = () => {
            const e = navigator.userAgent,
                t = /iPhone/i.test(e),
                i = /iPad/i.test(e) || /Macintosh/i.test(e) && navigator.maxTouchPoints > 1,
                s = /iPod/i.test(e);
            return t || i || s
        },
        je = (...e) => {
            i("[Environment]", ...e)
        },
        ze = ["hs_preview", "preview_key"],
        We = e => ({
            bfCacheReload: [23273748, 19651225].includes(e),
            closeCTAOnNavigation: [23273748, 1854059].includes(e),
            abTestingIdMisMatch: [22812424, 44289455, 24020940].includes(e)
        });
    class Ye {
        constructor() {
            this.portalId = 0;
            this.env = "";
            this.hublet = ne;
            this.isLocal = !1;
            this.isMobile = !1;
            this.isLiveHSPage = !1;
            this.isPreview = !1;
            this.isScreenshot = !1;
            this.isTemplate = !1;
            this.previewScheduled = !1;
            this.enableResponsiveStyles = !1;
            this.isPreviewPage = !1;
            this.gates = [];
            this.patches = {
                bfCacheReload: !1,
                closeCTAOnNavigation: !1,
                abTestingIdMisMatch: !1
            };
            this.win = ge();
            this.currentUrl = this.win.location.href
        }
        init() {
            if (!this._setEnvProps()) return !1;
            this._setUrlProps();
            return !0
        }
        _setEnvProps() {
            var e, t, i;
            const s = me();
            if (!s) {
                je("Unable to resolve env params: loader script element not found. Aborting init.");
                return !1
            }
            this.portalId = s.portalId;
            this.hublet = s.hublet;
            this.env = s.env;
            this.isLocal = s.isLocal;
            this.isMobile = Ge();
            this.isPreviewPage = ze.some((e => this.win.location.search.includes(e)));
            this.pageId = (null === (e = this.win.hsVars) || void 0 === e ? void 0 : e.analytics_page_id) || (null === (t = this.win.hsVars) || void 0 === t ? void 0 : t.page_id);
            this.isLiveHSPage = Boolean(this.pageId);
            this.language = null === (i = this.win.hsVars) || void 0 === i ? void 0 : i.language;
            this.patches = We(this.portalId);
            return !0
        }
        isCosPreviewPage() {
            const e = this.win.location.toString();
            return /preview(-[^.]+)?\.hs-sites(qa)?(-[^.]+)?\.com/g.test(e) || /hubspotpreview(qa)?(-[^.]+)?/.test(e) || this.win.location.search.includes("hs_preview") || this.win.location.search.includes("preview_key")
        }
        isCos() {
            if (this.win.hsVars && this.win.hsVars.portal_id) return !0;
            return [...document.getElementsByTagName("meta")].some((e => "generator" === e.getAttribute("name") && "HubSpot" === e.getAttribute("content")))
        }
        _setUrlProps() {
            const e = new URLSearchParams(this.win.location.search);
            if (e.has("templatePath")) {
                this.templatePath = e.get("templatePath");
                this.isTemplate = !0
            }
            e.has("previewScheduled") && (this.previewScheduled = "true" === e.get("previewScheduled"));
            e.has("enableResponsiveStyles") && (this.enableResponsiveStyles = "true" === e.get("enableResponsiveStyles"));
            e.has("versionId") && (this.versionId = parseInt(e.get("versionId"), 10));
            if (e.has("screenshotBodyHeight")) {
                this.screenshotBodyHeight = parseInt(e.get("screenshotBodyHeight"), 10);
                this.isScreenshot = !0
            }
            if (e.has("publishedPreview")) {
                this.isPreview = !0;
                this.previewScheduled = !0;
                this.versionId = -1
            }
            if (e.has("previewInteractiveId")) {
                this.previewId = parseInt(e.get("previewInteractiveId"), 10);
                this.isPreview = !0
            }
            this.isPreview && e.has("email") && (this.contactPreviewEmail = e.get("email"));
            this.currentUrl = this.win.location.href
        }
        setGates(e) {
            this.gates = e
        }
        isUngatedFor(e) {
            return this.gates.includes(e)
        }
        refresh() {
            this._setUrlProps()
        }
    }
    var Qe = new Ye;
    class Xe {
        constructor() {
            this.markAsViewed = e => {
                this.store.setState((t => Object.assign({}, t, {
                    viewed: new Set([...t.viewed, e])
                })))
            };
            const e = {
                viewed: new Set
            };
            this.store = new w(e)
        }
        subscribe(e) {
            this.store.subscribe(e)
        }
        hasBeenViewed(e) {
            return this.store.state.viewed.has(e)
        }
        get viewed() {
            return this.store.state.viewed
        }
    }

    function Ke() {
        return new Xe
    }
    const Je = "hs-cta-trigger-button",
        Ze = "hs-cta-embed",
        et = "web-interactives-preview-wrapper";
    var tt = () => Array.from(document.getElementsByClassName(Je));
    var it = () => Array.from(document.getElementsByClassName(Ze));
    const st = () => {
            try {
                return Array.from(document.querySelectorAll("a[href*='HS_DISPLAY_CALL_TO_ACTION'"))
            } catch (e) {
                return []
            }
        },
        nt = e => {
            const t = e.getAttribute("href");
            if (!t) return null;
            const i = /\(([^)]+)\)/.exec(t);
            if (!i) return null;
            const s = i[1];
            return s ? JSON.parse(s.replace(/(['"])?([a-z0-9A-Z_]+)(['"])?:/g, '"$2": ').replaceAll("'", '"')).id : null
        };
    var ot = e => {
        const t = Array.from(e.classList).filter((e => e.startsWith(Je) && e !== Je || e.startsWith(Ze) && e !== Ze)).map((e => e.split("-").pop()));
        let i = Number(t);
        if (Number.isNaN(i)) {
            const t = e.dataset.hubspotWrapperCtaId;
            i = Number(t)
        }
        return i
    };

    function rt(e) {
        return Number(e.dataset.hubspotWrapperCtaId)
    }

    function at() {
        return Array.from(document.querySelectorAll(".hs-web-interactive-inline[data-hubspot-wrapper-cta-id]"))
    }
    const ct = () => {
            const e = new Map,
                t = new Map,
                i = new Map,
                s = new Set,
                n = new Set,
                o = new Set,
                r = (t, i) => {
                    const s = e.get(t);
                    s ? s.add(i) : e.set(t, new Set([i]))
                };
            tt().forEach((e => {
                const t = ot(e);
                s.add(t);
                r(t, e)
            }));
            it().forEach((e => {
                const i = ot(e);
                n.add(i);
                const s = t.get(i);
                s ? t.set(i, [...s, e]) : t.set(i, [e])
            }));
            st().forEach((e => {
                const t = nt(e);
                if (t) {
                    s.add(t);
                    r(t, e)
                }
            }));
            at().forEach(((e, t) => {
                const s = rt(e);
                if (!s) return;
                e.id = `hs-interactive-container-${s}-${t}`;
                o.add(s);
                const n = i.get(s);
                n ? i.set(s, [...n, e]) : i.set(s, [e])
            }));
            const a = [...new Set([...s, ...n, ...o])];
            return {
                clickTriggerButtons: e,
                embedContainers: t,
                nonFramedCTAContainers: i,
                clickTriggerIds: s,
                embedIds: n,
                nonFramedIds: o,
                uniqueIds: a
            }
        },
        lt = (e, t) => {
            const i = document.createElement("div");
            i.innerHTML = t;
            return i.firstElementChild
        };
    let ht = {
            data: ""
        },
        dt = e => {
            try {
                let t = e ? e.querySelector("#_goober") : self._goober;
                return t || (t = (e || document.head).appendChild(document.createElement("style")), t.innerHTML = " ", t.id = "_goober"), t.firstChild
            } catch (e) {}
            return ht
        },
        ut = /(?:([a-z0-9-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(})/gi,
        mt = /\/\*.*?\*\/|\s{2,}|\n/gm,
        gt = (e, t, i) => {
            let s = "",
                n = "",
                o = "";
            for (let r in e) {
                let a = e[r];
                if ("object" == typeof a) {
                    let e = t + " " + r;
                    /&/g.test(r) && (e = r.replace(/&/g, t)), "@" == r[0] && (e = t, "f" == r[1] && (e = r)), /@k/.test(r) ? n += r + "{" + gt(a, "", "") + "}" : n += gt(a, e, e == t ? r : i || "")
                } else /^@i/.test(r) ? s = r + " " + a + ";" : o += gt.p ? gt.p(r.replace(/[A-Z]/g, "-$&").toLowerCase(), a) : r.replace(/[A-Z]/g, "-$&").toLowerCase() + ":" + a + ";"
            }
            if (o[0]) {
                let e = t + "{" + o + "}";
                return i ? n + i + "{" + e + "}" : s + e + n
            }
            return s + n
        },
        pt = {},
        ft = (e, t, i, s) => {
            let n = e.toLowerCase ? e : function e(t) {
                    let i = "";
                    for (let s in t) "object" == typeof val ? i += s + e(t[s]) : i += s + t[s];
                    return i
                }(e),
                o = pt[n] || (pt[n] = ".go" + n.split("").reduce(((e, t) => 101 * e + t.charCodeAt(0) >>> 0), 11));
            return ((e, t, i) => {
                t.data.indexOf(e) < 0 && (t.data = i ? e + t.data : t.data + e)
            })(pt[o] || (pt[o] = gt(e[0] ? (e => {
                let t, i = [{}];
                for (; t = ut.exec(e.replace(mt, ""));) t[4] && i.shift(), t[3] ? i.unshift(i[0][t[3]] = i[0][t[3]] || {}) : t[4] || (i[0][t[1]] = t[2]);
                return i[0]
            })(e) : e, i ? "" : o)), t, s), o.slice(1)
        },
        vt = (e, t, i) => e.reduce(((e, s, n) => {
            let o = t[n];
            if (o && o.call) {
                let e = o(i),
                    t = e && e.props && e.props.className || /^go/.test(e) && e;
                o = t ? "." + t : e && e.props ? "" : e
            }
            return e + s + (null == o ? "" : o)
        }), "");

    function Tt(e) {
        let t = this || {},
            i = e.call ? e(t.p) : e;
        return ft(i.map ? vt(i, [].slice.call(arguments, 1), t.p) : i, dt(t.target), t.g, t.o)
    }
    Tt.bind({
        g: 1
    });
    const Ct = Tt(["position:fixed;display:block;width:100%;height:0px;margin:0px;padding:0px;overflow:visible;transform-style:preserve-3d;background:transparent;backface-visibility:hidden;pointer-events:none;left:0px;z-index:9998;"]),
        Et = Tt(["top:0px;z-index:9999;height:100%;width:100%;"]),
        bt = Tt(["bottom:0px;"]),
        St = Tt(["position:fixed;z-index:9989;"]),
        yt = Tt(["left:0;bottom:0;"]),
        wt = Tt(["right:0;bottom:0;"]),
        At = Tt(["left:0;top:0;"]),
        It = Tt(["right:0;top:0;"]),
        _t = Tt(["position:relative;overflow:hidden;display:none;"]),
        Ot = Tt(["display:block;"]),
        Mt = "hs-web-interactives-banner-style-element",
        Pt = "hs-web-interactives-top-banner-open",
        Lt = "hs-web-interactives-top-anchor",
        Rt = "hs-web-interactives-top-push-anchor",
        Nt = "hs-web-interactives-bottom-anchor",
        Ft = "hs-web-interactives-floating-container",
        kt = "hs-web-interactives-floating-top-left-anchor",
        Ht = "hs-web-interactives-floating-top-right-anchor",
        Dt = "hs-web-interactives-floating-bottom-left-anchor",
        Vt = "hs-web-interactives-floating-bottom-right-anchor",
        Bt = e => `\n  .${Pt} .hs-is-fixed-element {\n    translate: 0px ${e}px!important;\n  }\n`,
        xt = () => `\n<div class="${Ct} ${Et}" id="${Lt}"></div>\n<div class="${Ct} ${bt}" id="${Nt}"></div>\n<div id="${Ft}">\n  <div id="${kt}" class="${St} ${At}" >\n  </div>\n  <div id="${Ht}" class="${St} ${It}">\n  </div>\n  <div id="${Dt}" class="${St} ${yt}">\n  </div>\n  <div id="${Vt}" class="${St} ${wt}">\n  </div>\n</div>\n`;
    class Ut {
        constructor() {
            this.render();
            this.topPushAnchor = document.getElementById(Rt);
            this.topAnchor = document.getElementById(Lt);
            this.bottomAnchor = document.getElementById(Nt);
            this.floatingAnchors = {
                [De.TOP_LEFT]: document.getElementById(kt),
                [De.TOP_RIGHT]: document.getElementById(Ht),
                [De.BOTTOM_LEFT]: document.getElementById(Dt),
                [De.BOTTOM_RIGHT]: document.getElementById(Vt)
            };
            this.bottomRightFloatingButtonAnchor = this.floatingAnchors.BOTTOM_RIGHT
        }
        attachInteractiveOverlayToAnchor(e) {
            e.containerType !== se.MODAL ? e.isFloatingButtonLike ? this.attachFloatingButton(e) : e.containerType === se.SLIDE_IN && e.isActiveAbTest ? this.topAnchor.appendChild(e.container) : e.containerType !== se.BANNER && e.containerType !== se.SLIDE_IN || this.attachBanner(e) : this.attachModal(e)
        }
        attachModal(e) {
            this.topAnchor.appendChild(e.container)
        }
        attachBanner(e) {
            e.position === De.BOTTOM || e.position === De.BOTTOM_LEFT || e.position === De.BOTTOM_RIGHT ? this.bottomAnchor.appendChild(e.container) : e.position !== De.TOP && e.position !== De.TOP_RIGHT && e.position !== De.TOP_LEFT || this.topAnchor.appendChild(e.container)
        }
        attachFloatingButton(e) {
            const t = this.floatingAnchors[e.position];
            t && t.appendChild(e.container)
        }
        addMarginForConversations(e) {
            this.bottomRightFloatingButtonAnchor.style.marginBottom = `${e}px`
        }
        removeMarginForConversations() {
            this.bottomRightFloatingButtonAnchor.style.marginBottom = ""
        }
        insertPushBanner() {
            const e = document.createElement("div");
            e.id = Rt;
            e.classList.add(_t);
            document.body.prepend(e)
        }
        setTopPushHeight(e) {
            this.topPushAnchor.style.height = `${e}px`
        }
        showPushBanner(e) {
            this.setTopPushHeight(e);
            this.topPushAnchor.classList.add(Ot);
            document.body.classList.add(Pt);
            const t = document.createElement("style");
            t.id = Mt;
            t.innerHTML = Bt(e);
            document.head.appendChild(t)
        }
        hidePushBanner() {
            this.topPushAnchor.classList.remove(Ot);
            document.body.classList.remove(Pt);
            const e = document.getElementById(Mt);
            e && document.head.removeChild(e)
        }
        render() {
            this.insertPushBanner();
            document.body.insertAdjacentHTML("beforeend", xt())
        }
    }
    const $t = Tt(["position:absolute;pointer-events:none;width:101vw;height:101vh;background:rgba(0,0,0,0.7);opacity:0;z-index:-1;"]),
        Gt = Tt(["z-index:99998;opacity:0.8;visibility:visible;pointer-events:all;cursor:pointer;"]),
        qt = Tt(["overflow:hidden;"]);
    class jt {
        constructor({
            parent: e,
            handleClick: t = (() => {})
        }) {
            this.disableBodyScroll = !1;
            this.overlay = document.createElement("div");
            this.overlay.id = "hs-interactives-modal-overlay";
            this.overlay.classList.add($t);
            this.handleClick = t;
            this.render(e);
            this.listenForClick()
        }
        listenForClick() {
            this.overlay.addEventListener("click", this.handleClick)
        }
        enableDisableBodyScroll() {
            this.disableBodyScroll = !0
        }
        show() {
            this.overlay.classList.add(Gt);
            this.disableBodyScroll && document.body.classList.add(qt)
        }
        hide() {
            this.overlay.classList.remove(Gt);
            document.body.classList.remove(qt)
        }
        render(e) {
            e.appendChild(this.overlay)
        }
    }
    const zt = {
            modalPosition: null,
            bannerPositions: {
                TOP_LEFT: null,
                TOP_RIGHT: null,
                BOTTOM_LEFT: null,
                BOTTOM_RIGHT: null,
                BOTTOM: null,
                TOP: null
            },
            floatingPositions: {
                TOP_LEFT: null,
                TOP_RIGHT: null,
                BOTTOM_LEFT: null,
                BOTTOM_RIGHT: null
            }
        },
        Wt = [De.TOP, De.TOP_LEFT, De.TOP_RIGHT],
        Yt = [De.BOTTOM, De.BOTTOM_LEFT, De.BOTTOM_RIGHT];
    class Qt {
        constructor({
            isMobile: e = !1
        }) {
            this.isMobile = !1;
            this.store = new w(zt);
            this.isMobile = e
        }
        setPositionFromConfig(e) {
            const {
                contentModelId: t,
                containerType: i,
                containerStyles: {
                    position: s
                }
            } = e, n = Ue.isFloatingButtonLike(e);
            i === se.MODAL ? this.setModalPosition(t) : i !== se.BANNER && !se.SLIDE_IN || n ? n && this.setFloatingPosition(s, t) : this.setBannerPosition(s, t)
        }
        get modalPosition() {
            return this.store.state.modalPosition
        }
        get bannerPositions() {
            return this.store.state.bannerPositions
        }
        get floatingPositions() {
            return this.store.state.floatingPositions
        }
        canBeInsertedIntoPosition(e) {
            return this.isMobile ? this.canBeInsertedIntoPositionMobile(e) : this.canBeInsertedIntoPositionDesktop(e)
        }
        canBeInsertedIntoPositionMobile(e) {
            const t = Ue.isFloatingButtonLike(e);
            return e.containerType === se.MODAL ? !this.modalPosition : e.containerType === se.BANNER || e.containerType === se.SLIDE_IN && !t ? Object.keys(this.bannerPositions).reduce(((e, t) => e && !this.bannerPositions[t]), !0) : !!t && Object.keys(this.floatingPositions).reduce(((e, t) => e && !this.floatingPositions[t]), !0)
        }
        canBeInsertedIntoPositionDesktop(e) {
            const t = Ue.isFloatingButtonLike(e);
            return e.containerType === se.MODAL ? !this.modalPosition : e.containerType === se.BANNER || e.containerType === se.SLIDE_IN && !t ? Yt.includes(e.containerStyles.position) ? !this.bannerPositions[De.BOTTOM] && !this.bannerPositions[De.BOTTOM_LEFT] && !this.bannerPositions[De.BOTTOM_RIGHT] : !!Wt.includes(e.containerStyles.position) && (!this.bannerPositions[De.TOP] && !this.bannerPositions[De.TOP_LEFT] && !this.bannerPositions[De.TOP_RIGHT]) : !!t && !this.floatingPositions[e.containerStyles.position]
        }
        setModalPosition(e) {
            this.store.setState((t => Object.assign({}, t, {
                modalPosition: e
            })))
        }
        setBannerPosition(e, t) {
            this.store.setState((i => {
                const s = i.bannerPositions;
                return Object.assign({}, i, {
                    bannerPositions: Object.assign({}, s, {
                        [e]: t
                    })
                })
            }))
        }
        setFloatingPosition(e, t) {
            this.store.setState((i => {
                const s = i.floatingPositions;
                return Object.assign({}, i, {
                    floatingPositions: Object.assign({}, s, {
                        [e]: t
                    })
                })
            }))
        }
        getAllIds() {
            const e = [];
            "number" == typeof this.modalPosition && null !== this.modalPosition && e.push(this.modalPosition);
            for (const [t, i] of Object.entries(this.bannerPositions)) i && Number.isInteger(i) && e.push(i);
            for (const [t, i] of Object.entries(this.floatingPositions)) i && Number.isInteger(i) && e.push(i);
            return e
        }
        removeCTA(e) {
            this.modalPosition === e && this.store.setState((e => Object.assign({}, e, {
                modalPosition: null
            })));
            for (const [t, i] of Object.entries(this.bannerPositions)) i === e && this.store.setState((e => Object.assign({}, e, {
                bannerPositions: Object.assign({}, e.bannerPositions, {
                    [t]: null
                })
            })));
            for (const [t, i] of Object.entries(this.floatingPositions)) i === e && this.store.setState((e => Object.assign({}, e, {
                floatingPositions: Object.assign({}, e.floatingPositions, {
                    [t]: null
                })
            })))
        }
        wouldConflictWithPosition(e, t, i) {
            if (this.canBeInsertedIntoPosition(e)) return !1;
            this.removeCTA(t);
            const s = this.canBeInsertedIntoPosition(e),
                n = i.configs.get(t);
            n && this.setPositionFromConfig(n);
            return s
        }
    }

    function Xt(e) {
        return new Qt({
            isMobile: e
        })
    }
    const Kt = 6e4,
        Jt = 1440 * Kt,
        Zt = 7 * Jt,
        ei = 4 * Zt,
        ti = {
            REPEAT_ONCE: "REPEAT_ONCE",
            REPEAT_FOREVER: "REPEAT_FOREVER",
            ONCE_OFF: "ONCE_OFF"
        },
        ii = {
            DAYS: "DAYS",
            MONTHS: "MONTHS",
            WEEKS: "WEEKS",
            MINUTES: "MINUTES"
        },
        si = Object.freeze({
            DAYS: Jt,
            MONTHS: ei,
            WEEKS: Zt,
            MINUTES: Kt
        }),
        ni = "hs-cta-interactions",
        oi = "cta",
        ri = 1;
    let ai;
    const ci = async () => {
        ai || (ai = new Promise(((e, t) => {
            const s = indexedDB.open(ni, ri);
            s.onerror = e => {
                t(new Error("Failed to open IndexedDB"))
            };
            s.onupgradeneeded = e => {
                e.target.result.createObjectStore(oi, {
                    keyPath: "id"
                })
            };
            s.onsuccess = t => {
                i("db load success");
                e(t.target.result)
            }
        })));
        return await ai
    };
    let li = null;
    const hi = async () => {
            const e = (await ci()).transaction(oi, "readonly").objectStore(oi).getAll();
            return new Promise(((t, i) => {
                e.onsuccess = () => {
                    li = e.result;
                    t(e.result)
                };
                e.onerror = () => {
                    i(new Error("Failed to eagerly load saved frequency rules"))
                }
            }))
        },
        di = () => {
            if (null == li) throw new Error("[getAllEagerlyLoadedSavedFrequencyRules] Saved frequency rules were not eagerly loaded");
            return li
        },
        ui = e => {
            var t;
            if (null == li) throw new Error("[getEagerlyLoadedCtaSavedFrequencyRules] Saved frequency rules were not eagerly loaded");
            return null === (t = li.find((t => t.id === e))) || void 0 === t ? void 0 : t.savedFrequencyRules
        },
        mi = async (e, t) => {
            const i = (await ci()).transaction(oi, "readwrite").objectStore(oi).put({
                id: e,
                savedFrequencyRules: t
            });
            return new Promise(((t, s) => {
                i.onsuccess = () => {
                    t()
                };
                i.onerror = () => {
                    s(new Error(`Failed to save cta ${e} frequency rules`))
                }
            }))
        },
        gi = async e => {
            const t = (await ci()).transaction(oi, "readwrite").objectStore(oi).delete(e);
            return new Promise(((i, s) => {
                t.onsuccess = () => {
                    i()
                };
                t.onerror = () => {
                    s(new Error(`Failed to clear cta ${e} saved frequency rules`))
                }
            }))
        };
    let pi = null;
    const fi = () => {
            if (null == pi) try {
                localStorage.setItem("hs-cta-test", "test");
                const e = localStorage.getItem("hs-cta-test");
                localStorage.removeItem("hs-cta-test");
                pi = "test" === e
            } catch (e) {
                pi = !1
            }
            return pi
        },
        vi = () => "indexedDB" in window,
        Ti = "WI_FREQUENCY",
        Ci = {
            backoffTimeDuration: 2,
            backoffTimeUnit: ii.WEEKS
        },
        Ei = {
            frequency: ti.REPEAT_ONCE,
            backoff: Ci
        },
        bi = e => {
            try {
                var t, i;
                return null !== (t = null === (i = ui(e)) || void 0 === i ? void 0 : i.timeSaved) && void 0 !== t ? t : null
            } catch (e) {
                return null
            }
        },
        Si = e => {
            try {
                const t = localStorage.getItem(`${Ti}_${e}`);
                if (!t) return null;
                const i = JSON.parse(t),
                    s = Number(i.timeSaved);
                return isNaN(s) ? i.frequency === ti.ONCE_OFF ? Date.now() : null : s
            } catch (e) {
                return null
            }
        },
        yi = e => {
            const t = Si(e);
            if (null != t) return t;
            if (fi()) return null;
            if (!vi()) return null;
            return bi(e)
        },
        wi = (e, t) => {
            var i;
            if ((t = null !== (i = t) && void 0 !== i ? i : Ei).frequency === ti.REPEAT_FOREVER) return !1;
            const s = yi(e);
            if (null == s) return !1;
            if (t.frequency === ti.ONCE_OFF) return !0;
            if (t.frequency === ti.REPEAT_ONCE) {
                var n;
                const e = null !== (n = t.backoff) && void 0 !== n ? n : Ci,
                    i = e.backoffTimeDuration,
                    o = e.backoffTimeUnit,
                    r = i * si[o];
                return s > Date.now() - r
            }
            return !1
        },
        Ai = (e, t) => {
            var s, n;
            const o = (t = null !== (s = t) && void 0 !== s ? s : Ei).frequency,
                r = null !== (n = t.backoff) && void 0 !== n ? n : Ci,
                a = {
                    frequency: o,
                    timeSaved: Date.now(),
                    backoffTimeDuration: r.backoffTimeDuration,
                    backoffTimeUnit: r.backoffTimeUnit
                };
            if (o !== ti.REPEAT_FOREVER) {
                try {
                    localStorage.setItem(`${Ti}_${e}`, JSON.stringify(a))
                } catch (e) {
                    return
                }
                mi(e, a).catch((t => {
                    i(`Failed to save frequency rules for ${e} to indexedDB, error: ${t}`)
                }))
            }
        },
        Ii = e => {
            if (e.frequency === ti.ONCE_OFF) return !1;
            if (e.frequency === ti.REPEAT_FOREVER) return !0;
            if (e.frequency === ti.REPEAT_ONCE) {
                const t = e.timeSaved,
                    i = e.backoffTimeDuration,
                    s = e.backoffTimeUnit,
                    n = i * si[s];
                return Date.now() > t + n
            }
            return !1
        },
        _i = () => {
            const e = Object.keys(localStorage).filter((e => e.startsWith(Ti)));
            for (const t of e) try {
                const e = JSON.parse(localStorage.getItem(t));
                if (!Ii(e)) continue;
                localStorage.removeItem(t)
            } catch (e) {
                continue
            }
        },
        Oi = () => {
            try {
                const e = di();
                for (const t of e) Ii(t.savedFrequencyRules) && gi(t.id).catch((e => {
                    i(`Failed to clear stale frequency rules for ${t.id} from indexedDB, error: ${e}`)
                }))
            } catch (e) {
                return
            }
        },
        Mi = Tt(["display:block !important;position:static !important;box-sizing:border-box !important;background:transparent !important;border:none;min-height:0px !important;max-height:none !important;margin:0px;padding:0px !important;height:100% !important;width:1px !important;max-width:100% !important;min-width:100% !important;"]);

    function Pi(e, t = {}) {
        i("Setting style on element", t, e);
        for (const i in t) Object.hasOwnProperty.call(t, i) && (e.style[i] = t[i])
    }
    const Li = "hs-cta-embed__loaded",
        Ri = Tt(["transition:none !important;"]),
        Ni = () => {};
    class Fi {
        constructor({
            src: e,
            contentId: t,
            containerStyle: i,
            configStyle: s,
            iframeStyle: n,
            containerType: o,
            isFloatingButtonLike: r,
            isTopBanner: a,
            isActiveAbTest: c,
            srcdoc: l,
            isPersonalizationEnabled: h
        }) {
            this.isOpen = !1;
            this.onClose = Ni;
            this.handleStart = e => {
                if (!this.isActiveAbTest && !this.isPersonalizationEnabled) return;
                if (!e.containerStyles) return;
                const t = e.containerStyles;
                this.configStyle = t;
                this.iframeStyle = Ue.getStylesForIframe(t);
                this.containerStyle = Ue.getStylesFromContainerStyles(t);
                this.frameComponent.setShouldResize(t.scaleHeightToFitContent || Boolean(t.isSingleModuleOnly));
                this.applyStyleElements();
                this.onStylesUpdated()
            };
            this.setDeferredPromise();
            this.container = document.createElement("div");
            this.contentId = t;
            this.container.id = `hs-overlay-cta-${t}`;
            this.frameComponent = y({
                container: this.container,
                id: t,
                iframeSrc: e,
                onFrameReady: this.resolveFrameload,
                resizeHeight: s.scaleHeightToFitContent || Boolean(s.isSingleModuleOnly),
                useResponsiveStyling: s.useResponsiveStyling,
                extraAttributes: {
                    "aria-label": "Popup CTA",
                    title: "Popup CTA",
                    allow: "autoplay; fullscreen; clipboard-write"
                },
                srcdoc: l
            });
            this.frameComponent.iframe.setAttribute("data-test-id", "interactive-frame");
            this.frameComponent.iframe.classList.add(Mi);
            this.containerStyle = i;
            this.iframeStyle = n;
            this.configStyle = s;
            this.containerType = o;
            this.position = s.position || null;
            this.isFloatingButtonLike = r;
            this.isTopBanner = a;
            this.isActiveAbTest = c;
            this.isPersonalizationEnabled = h;
            this.applyStyleElements();
            this.render();
            this.listenForStart()
        }
        applyStyleElements() {
            this.frameComponent.setStyle(this.iframeStyle);
            Pi(this.container, this.containerStyle)
        }
        setDeferredPromise() {
            this.frameLoadPromise = new Promise((e => {
                this.resolveFrameload = e
            }))
        }
        open() {
            return this.frameLoadPromise.then((() => {
                this.frameComponent.setStyle({
                    visibility: ""
                });
                this.container.classList.add(Li);
                this.internalOpen();
                this.isOpen = !0
            })).catch((() => {}))
        }
        close() {
            this.isOpen = !1
        }
        render() {}
        skipAnimation() {
            this.container.classList.add(Ri)
        }
        setAnimationForClickTrigger() {}
        registerResizeHandler(t) {
            this.frameComponent.iframeCommunicator.registerHandlers({
                [e.NEW_HEIGHT]: t
            })
        }
        registerCloseHandler(t) {
            this.frameComponent.iframeCommunicator.registerHandlers({
                [e.CLOSE_INTERACTIVE]: t
            })
        }
        listenForStart() {
            this.frameComponent.iframeCommunicator.registerHandlers({
                [e.STARTED]: this.handleStart
            })
        }
        internalOpen() {}
        internalClose() {}
        onStylesUpdated() {}
        remove() {
            this.frameComponent.iframeCommunicator.remove();
            this.container.remove()
        }
    }
    const ki = (...e) => {
            i("[overlays/Modal]", ...e)
        },
        Hi = Tt(["z-index:99999;visibility:hidden;position:absolute;inset:50vh auto auto 50%;left:50%;top:50%;transform:translate(-50%,-50%) translateY(100vh);pointer-events:none;max-height:95%;max-width:95%;"]),
        Di = Tt(["pointer-events:auto !important;visibility:visible;transform:translate(-50%,-50%) translateY(0);transition:transform 0.75s linear(0,0.006,0.023 2.2%,0.096 4.8%,0.532 15.4%,0.72 21%,0.793,0.853 26.7%,0.902,0.941,0.968 36.2%,0.987 39.7%,1 43.7%,1.007 48.3%,1.009 55.3%,1.002 78.2%,1 );"]),
        Vi = Tt(["transition:opacity 0.3s ease-in;"]);
    class Bi extends Fi {
        internalOpen() {
            this.container.classList.add(Di);
            this.focusElement()
        }
        focusElement() {
            try {
                this.frameComponent.iframe.focus()
            } catch (e) {
                ki("Frame not defined", e)
            }
        }
        setAnimationForClickTrigger() {
            this.container.classList.add(Vi)
        }
        close() {
            super.close();
            this.container.classList.remove(Di)
        }
        render() {
            this.container.classList.add(Hi);
            this.container.setAttribute("role", "dialog");
            this.container.setAttribute("aria-modal", "true")
        }
    }
    const xi = Tt(["pointer-events:auto !important;visibility:visible !important;max-height:95vh !important;transition:max-height 1s ease-in;"]),
        Ui = Tt(["z-index:9999;width:100%;max-height:0px;position:fixed;max-height:95%;visibility:hidden;"]),
        $i = Tt(["z-index:9999;width:100%;max-height:0px;position:fixed;max-height:95%;visibility:hidden;bottom:0px;"]),
        Gi = {
            [De.TOP]: Ui,
            [De.BOTTOM]: $i
        };
    class qi extends Fi {
        internalOpen() {
            this.container.classList.add(xi)
        }
        close() {
            super.close();
            this.container.classList.remove(xi)
        }
        addPositionClass() {
            const {
                position: e
            } = this.configStyle;
            this.container.classList.add(Gi[e])
        }
        render() {
            this.addPositionClass();
            this.container.classList.add(Ui)
        }
    }
    const ji = Tt(["visibility:hidden;"]),
        zi = Tt(["visibility:visible !important;"]);
    class Wi extends Fi {
        internalOpen() {
            this.container.classList.add(zi)
        }
        close() {
            super.close();
            this.container.classList.remove(zi)
        }
        render() {
            this.container.classList.add(ji)
        }
    }
    const Yi = Tt(["pointer-events:auto !important;visibility:visible !important;max-height:95vh !important;transform:none !important;"]),
        Qi = Tt(["z-index:9999;width:100%;max-height:0px;position:fixed;max-height:95%;visibility:hidden;transition:transform 1s linear(0,0.006,0.022 2.3%,0.091 5.1%,0.18 7.6%,0.508 16.3%,0.607,0.691,0.762,0.822 28.4%,0.872,0.912 35.1%,0.944 38.9%,0.968 43%,0.985 47.6%,0.996 53.1%,1.001 58.4%,1.003 65.1%,1 );"]),
        Xi = Tt(["z-index:9999;position:fixed;left:10px;top:10px;max-height:95vh !important;max-width:95%;visibility:hidden;"]),
        Ki = Tt(["z-index:9999;position:fixed;right:10px;top:10px;max-height:95vh !important;max-width:95%;visibility:hidden;"]),
        Ji = Tt(["z-index:9999;position:fixed;left:10px;bottom:10px;max-height:95vh !important;max-width:95%;visibility:hidden;"]),
        Zi = Tt(["z-index:9999;position:fixed;right:10px;bottom:10px;max-height:95vh !important;max-width:95%;visibility:hidden;"]),
        es = {
            [De.BOTTOM_RIGHT]: Zi,
            [De.BOTTOM_LEFT]: Ji,
            [De.TOP_RIGHT]: Ki,
            [De.TOP_LEFT]: Xi
        };
    class ts extends Fi {
        internalOpen() {
            this.container.classList.add(Yi)
        }
        close() {
            super.close();
            this.container.classList.remove(Yi)
        }
        removePositionClasses() {
            Object.values(es).forEach((e => {
                this.container.classList.remove(e)
            }))
        }
        addPositionClass() {
            const {
                position: e
            } = this.configStyle;
            this.container.classList.add(es[e])
        }
        addOffset() {
            const e = this.containerStyle.width;
            if (!e) return;
            switch (this.configStyle.position) {
                case De.BOTTOM_LEFT:
                case De.TOP_LEFT:
                    this.container.style.transform = `translateX(-${e})`;
                    return;
                case De.BOTTOM_RIGHT:
                case De.TOP_RIGHT:
                    this.container.style.transform = `translateX(calc(100% + ${e}))`;
                    return
            }
        }
        onStylesUpdated() {
            this.removePositionClasses();
            this.addPositionClass();
            this.container.style.transform = "";
            this.addOffset()
        }
        render() {
            this.addPositionClass();
            this.addOffset();
            this.container.classList.add(Qi);
            this.container.setAttribute("role", "dialog")
        }
    }

    function is(e, t) {
        const i = Ue.isFloatingButtonLike(e),
            s = Ue.isTopBannerLike(e),
            n = {
                src: t,
                configStyle: e.containerStyles,
                contentId: e.contentModelId,
                containerType: e.containerType,
                containerStyle: Ue.getStylesFromContainerStyles(e.containerStyles),
                iframeStyle: Ue.getStylesForIframe(e.containerStyles),
                isFloatingButtonLike: i,
                isTopBanner: s,
                isActiveAbTest: e.isActiveAbTest,
                srcdoc: e.srcdoc,
                isPersonalizationEnabled: e.isPersonalizationEnabled
            };
        if (i) return new Wi(n);
        switch (e.containerType) {
            case se.MODAL:
                return new Bi(n);
            case se.BANNER:
                return new qi(n);
            case se.SLIDE_IN:
                return new ts(n);
            default:
                return null
        }
    }

    function ss(e) {
        return e.button < 2
    }
    const ns = (...e) => {
            i("[ClickTrigger", ...e)
        },
        os = Tt(["cursor:pointer;"]);
    class rs {
        constructor(e, t) {
            this.button = e;
            this.onClick = t;
            this.init();
            this.addA11yAttributes()
        }
        addA11yAttributes() {
            this.button.setAttribute("aria-haspopup", "dialog");
            this.button.setAttribute("tabindex", "0")
        }
        init() {
            ns("Setting up click trigger");
            this.button.removeAttribute("href");
            this.button.removeAttribute("target");
            this.button.classList.add(os);
            this.button.removeAttribute("href");
            this.button.removeAttribute("target");
            this.button.addEventListener("mouseup", (e => {
                ns("Mouse up on click trigger", e);
                ss(e) && this.onClick()
            }));
            this.button.addEventListener("keypress", (e => {
                if ("Enter" === e.key) {
                    ns("Enter on click trigger", e);
                    this.onClick()
                }
            }))
        }
    }
    class as {
        constructor({
            onTrigger: e
        }) {
            this.isExitIntent = e => {
                if (!e) return !1;
                return !e.relatedTarget && e.clientY < 100
            };
            this.handleMouseOut = e => {
                this.isExitIntent(e) && this.onTrigger(this)
            };
            this.onTrigger = e;
            this.setup()
        }
        setup() {
            document.addEventListener("mouseout", this.handleMouseOut)
        }
        remove() {
            document.removeEventListener("mouseout", this.handleMouseOut)
        }
    }
    const cs = 1e3,
        ls = ["mousedown", "mousemove", "keypress", "scroll", "touchstart"];
    class hs {
        constructor({
            onTrigger: e,
            value: t
        }) {
            this.resetTimer = () => {
                this.timeout && clearTimeout(this.timeout);
                this.timeout = setTimeout((() => this.onTrigger(this)), this.seconds)
            };
            this.onTrigger = e;
            this.seconds = t * cs;
            this.timeout = null;
            this.setup()
        }
        setup() {
            this.timeout = setTimeout((() => this.onTrigger(this)), this.seconds);
            ls.forEach((e => {
                document.addEventListener(e, this.resetTimer)
            }))
        }
        remove() {
            ls.forEach((e => {
                document.removeEventListener(e, this.resetTimer)
            }));
            this.timeout && clearTimeout(this.timeout)
        }
    }

    function ds() {
        let e = !1;
        try {
            const t = {
                get passive() {
                    e = !0
                }
            };
            window.addEventListener("test", t, t);
            window.removeEventListener("test", t, t)
        } catch (t) {
            e = !1
        }
        return e
    }

    function us() {
        return Math.max(document.body.offsetHeight, document.body.scrollHeight)
    }

    function ms() {
        return Math.max(window.innerHeight || 0, document.documentElement.clientHeight)
    }

    function gs() {
        return document.body.scrollTop || document.documentElement.scrollTop
    }
    class ps {
        constructor({
            onTrigger: e,
            value: t
        }) {
            this.handleScroll = () => {
                const e = us() - ms();
                100 * gs() / e >= this.scrollPercent && this.onTrigger(this)
            };
            this.onTrigger = e;
            this.scrollPercent = t;
            this.supportsPassiveScrolling = ds();
            this.setup()
        }
        setup() {
            this.supportsPassiveScrolling ? window.addEventListener("scroll", this.handleScroll, {
                capture: !0,
                passive: !0
            }) : window.addEventListener("scroll", this.handleScroll, !0)
        }
        remove() {
            this.supportsPassiveScrolling ? window.removeEventListener("scroll", this.handleScroll, {
                capture: !0
            }) : window.removeEventListener("scroll", this.handleScroll, !0)
        }
    }
    const fs = 1e3;

    function vs() {
        return document.timeline && document.timeline.currentTime ? document.timeline.currentTime : performance ? performance.now() : 0
    }
    class Ts {
        constructor({
            onTrigger: e,
            value: t
        }) {
            this.onTrigger = e;
            const i = vs();
            this.ms = Math.max(t * fs - i, 0);
            this.timeout = null;
            this.setup()
        }
        setup() {
            this.timeout = setTimeout((() => {
                this.onTrigger(this)
            }), this.ms)
        }
        remove() {
            this.timeout && clearTimeout(this.timeout)
        }
    }
    class Cs {
        constructor({
            onTrigger: e
        }) {
            this.heightCache = {
                portrait: 0,
                landscape: 0
            };
            this.heightIncreaseSeen = !1;
            this.lastTouchMove = 0;
            this.lastClick = 0;
            this.trigger = () => {
                this.onTrigger(this)
            };
            this.onTrigger = e;
            this.setup()
        }
        setup() {
            this.setupCloseWatcher();
            this.setupVisibilityListener();
            this.setupIOSViewportListener()
        }
        remove() {
            this.cleanup()
        }
        setupCloseWatcher() {
            if ("CloseWatcher" in window) {
                this.closeWatcher = new window.CloseWatcher;
                this.closeWatcher.oncancel = e => {
                    e.preventDefault();
                    this.trigger()
                }
            } else;
        }
        setupVisibilityListener() {
            this.visibilityListener = () => {
                "visible" === document.visibilityState && setTimeout((() => this.trigger()), 100)
            };
            document.addEventListener("visibilitychange", this.visibilityListener, {
                passive: !0
            });
            if (qe()) {
                this.blurListener = () => this.trigger();
                window.addEventListener("blur", this.blurListener, {
                    passive: !0
                })
            }
        }
        setupIOSViewportListener() {
            if (!qe() || !window.visualViewport) return;
            const e = window.visualViewport,
                t = () => e.width > e.height ? "landscape" : "portrait";
            this.heightCache[t()] = e.height;
            this.touchMoveListener = () => this.lastTouchMove = Date.now();
            this.clickListener = () => this.lastClick = Date.now();
            this.backButtonListener = () => this.lastTouchMove = Date.now();
            this.menuButtonListener = () => this.lastTouchMove = Date.now();
            this.viewportResizeListener = () => {
                const i = Date.now(),
                    s = t(),
                    n = e.height;
                if (n > this.heightCache[s]) this.heightIncreaseSeen = !0;
                else {
                    this.heightCache[s] = n;
                    const e = i - this.lastTouchMove > 500,
                        t = i - this.lastClick > 500;
                    this.heightIncreaseSeen && e && t && this.trigger()
                }
            };
            e.addEventListener("resize", this.viewportResizeListener, {
                passive: !0
            });
            document.addEventListener("touchmove", this.touchMoveListener, {
                passive: !0
            });
            document.addEventListener("click", this.clickListener, {
                passive: !0
            });
            document.addEventListener("backbutton", this.backButtonListener, !1);
            document.addEventListener("menubutton", this.menuButtonListener, !1)
        }
        cleanup() {
            var e, t;
            null === (e = this.closeWatcher) || void 0 === e || null === (t = e.destroy) || void 0 === t || t.call(e);
            if (this.visibilityListener) {
                document.removeEventListener("visibilitychange", this.visibilityListener);
                this.visibilityListener = void 0
            }
            if (this.blurListener) {
                window.removeEventListener("blur", this.blurListener);
                this.blurListener = void 0
            }
            if (this.viewportResizeListener && window.visualViewport) {
                window.visualViewport.removeEventListener("resize", this.viewportResizeListener);
                this.viewportResizeListener = void 0
            }
            if (this.touchMoveListener) {
                document.removeEventListener("touchmove", this.touchMoveListener);
                this.touchMoveListener = void 0
            }
            if (this.clickListener) {
                document.removeEventListener("click", this.clickListener);
                this.clickListener = void 0
            }
            if (this.backButtonListener) {
                document.removeEventListener("backbutton", this.backButtonListener);
                this.backButtonListener = void 0
            }
            if (this.menuButtonListener) {
                document.removeEventListener("menubutton", this.menuButtonListener);
                this.menuButtonListener = void 0
            }
        }
    }
    const Es = {
        SCROLL: "scroll",
        EXIT_INTENT: "exit-intent",
        MOBILE_EXIT_INTENT: "mobile-exit-intent",
        WAIT: "wait",
        INACTIVITY: "inactivity"
    };

    function bs(e, t) {
        const {
            showOnPageScroll: i,
            showOnExitIntent: s,
            showAfterDelay: n,
            showAfterInactivity: o,
            pageScrollPercentageTrigger: r,
            delayInSeconds: a,
            inactivityInSeconds: c
        } = e, l = [];
        i && l.push(new ps({
            onTrigger: () => t(Es.SCROLL),
            value: r || 0
        }));
        s && (Ge() ? l.push(new Cs({
            onTrigger: () => t(Es.MOBILE_EXIT_INTENT)
        })) : l.push(new as({
            onTrigger: () => t(Es.EXIT_INTENT)
        })));
        n && l.push(new Ts({
            onTrigger: () => t(Es.WAIT),
            value: a || 0
        }));
        o && l.push(new hs({
            onTrigger: () => t(Es.INACTIVITY),
            value: c || 0
        }));
        return l
    }

    function Ss(e, t) {
        const i = new ResizeObserver((i => {
            for (const s of i) s.target === e && s.contentRect && t(s.contentRect.height, s.contentRect.height)
        }));
        i.observe(e);
        return () => i.disconnect()
    }
    const ys = "hubspot-messages-iframe-container",
        ws = () => {},
        As = 220,
        Is = 400,
        _s = "userInteractedWithWidget";
    class Os {
        constructor(e) {
            this.disconnectResizeObserver = ws;
            this.conversationsFrameContainer = null;
            this.handleConversationsReady = () => {
                this.addConversationsEventListeners();
                this.pollForConversationsRendered().then((() => {
                    this.conversationsFrameContainer = document.getElementById(ys);
                    this.addConversationsStyleSheet();
                    this.listenForConversationsHeightChange();
                    this.setFloatingButtonOffset()
                })).catch((() => {}))
            };
            this.overlayContainer = e;
            this.listenForConversationsReady()
        }
        listenForConversationsReady() {
            window.HubSpotConversations ? this.handleConversationsReady() : window.hsConversationsOnReady && window.hsConversationsOnReady.length ? window.hsConversationsOnReady = [...window.hsConversationsOnReady, this.handleConversationsReady] : window.hsConversationsOnReady = [this.handleConversationsReady]
        }
        listenForConversationsHeightChange() {
            if (!this.conversationsFrameContainer) return;
            const e = Ss(this.conversationsFrameContainer, (e => {
                this.conversationsFrameContainer && e < As && this.setFloatingButtonOffset()
            }));
            this.disconnectResizeObserver = e
        }
        addConversationsEventListeners() {
            window.HubSpotConversations && window.HubSpotConversations.on(_s, (() => {
                Ge() && this.removeConversationsStyleSheet()
            }))
        }
        pollForConversationsRendered() {
            return new Promise((e => {
                const t = setInterval((() => {
                    if (document.getElementById(ys)) {
                        e();
                        clearInterval(t)
                    }
                }), Is)
            }))
        }
        setFloatingButtonOffset() {
            if (!this.overlayContainer || !this.conversationsFrameContainer) return;
            const e = this.conversationsFrameContainer.clientHeight;
            this.overlayContainer.addMarginForConversations(e)
        }
        addConversationsStyleSheet() {
            const e = document.createElement("style");
            e.id = "web-interactives-conversations-override";
            e.innerHTML = "#hubspot-messages-iframe-container { z-index: 9990!important; }";
            document.head.appendChild(e)
        }
        removeConversationsStyleSheet() {
            const e = document.getElementById("web-interactives-conversations-override");
            e && e.remove()
        }
    }

    function Ms(e) {
        return new Os(e)
    }
    class Ps {
        constructor() {
            this.eventEmitter = n()
        }
        static getInstance() {
            Ps.instance || (Ps.instance = new Ps);
            return Ps.instance
        }
        emit(e, t) {
            this.eventEmitter.emit(e, t)
        }
        on(e, t) {
            this.eventEmitter.on(e, t)
        }
        off(e) {
            this.eventEmitter.off(e)
        }
        reset() {
            this.eventEmitter.reset()
        }
    }
    const Ls = {
            REFRESH: "REFRESH",
            CLOSE: "CLOSE",
            CLOSE_ALL: "CLOSE_ALL",
            TRIGGER_OPEN: "TRIGGER_OPEN",
            REPLACED_INLINE_HTML: "REPLACED_INLINE_HTML"
        },
        Rs = {
            HAS_CLOSED: "HAS_CLOSED",
            CTA_TRIGGERED: "CTA_TRIGGERED"
        },
        Ns = a;
    class Fs {
        constructor({
            configModel: t,
            environmentModel: i,
            analyticsModel: s,
            scheduledCTAsModel: n,
            handleView: o,
            scheduleCTA: r
        }) {
            this.triggerMap = new Map;
            this.shownModal = null;
            this.triggeredCTAFromCallback = null;
            this.clickTriggerComponentMap = new Map;
            this.interactiveComponentMap = new Map;
            this.conversationsController = null;
            this.eventManager = Ps.getInstance();
            this.listenForKeypress = () => {
                Q((() => {
                    this.shownModal && this.closeOverlay(this.shownModal)
                }))
            };
            this.sendAnalyticsToCTA = t => {
                Ns.broadcast(t, {
                    type: e.RECEIVED_ANALYTICS,
                    payload: this.analyticsModel.analytics
                })
            };
            this.handleTrigger = (e, t, i) => {
                if (!wi(e, t)) {
                    this.eventManager.emit(Rs.CTA_TRIGGERED, {
                        id: e,
                        triggerType: i
                    });
                    this.openOverlay(e);
                    for (const [t, i] of this.triggerMap) t === e && i.forEach((e => e.remove()));
                    this.triggerMap.delete(e)
                }
            };
            this.handleTriggerFromCTA = ({
                triggerCTA: e,
                id: t
            }) => {
                this.interactiveComponentMap.has(t) && (this.interactiveComponentMap.has(e) ? this.shouldCloseCalloutCTA(t) && this.closeOverlay(t) : this.triggeredCTAFromCallback = [e, t]);
                this.interactiveComponentMap.has(e) ? this.handleClickOpen(e) : this.scheduledCTAsModel.scheduledCTAs.has(e) || this.scheduleCTA(e)
            };
            this.handleClickOpen = e => {
                const t = this.interactiveComponentMap.get(e);
                t && t.isOpen ? this.closeOverlay(e) : this.openOverlay(e, !0)
            };
            this.handleOverlayClick = () => {
                if (!Number.isInteger(this.shownModal)) return;
                const e = this.configModel.configs.get(this.shownModal);
                e && e.containerStyles.closeOnOverlayClick && this.closeOverlay(this.shownModal)
            };
            this.handlePageNavigation = ({
                id: e,
                openNewTab: t,
                url: i
            }) => {
                t || C(window.location.href, i) || this.shouldCloseCalloutCTA(e) && this.environmentModel.patches.closeCTAOnNavigation && this.shouldCloseCalloutCTA(e) && this.closeOverlay(e)
            };
            this.handleFormSubmission = ({
                id: e
            }) => {
                const t = this.configModel.configs.get(e);
                t && t.shouldCloseOnFormSubmission && t.isDismissable && this.closeOverlay(e)
            };
            this.closeOverlay = e => {
                const t = this.interactiveComponentMap.get(e);
                if (t) {
                    t.isTopBanner && this.overlayedInteractivesContainer.hidePushBanner();
                    t.containerType === se.MODAL && this.overlay.hide();
                    t.close();
                    e === this.shownModal && (this.shownModal = null);
                    document.activeElement instanceof HTMLElement && document.activeElement.blur();
                    this.messageCTAClosed(e)
                }
            };
            this.configModel = t;
            this.environmentModel = i;
            this.analyticsModel = s;
            this.scheduledCTAsModel = n;
            this.overlayedInteractivesContainer = null;
            this.overlay = null;
            this.handleView = o;
            this.scheduleCTA = r;
            this.listenToConfigUpdates();
            this.listenForOpenCTAMessage();
            this.listenForKeypress();
            this.registerMessageHandlers();
            this.triggerOpen = this.handleClickOpen
        }
        init({
            clickTriggerButtons: e
        }) {
            this.positionsOccupied = Xt(this.environmentModel.isMobile);
            this.overlayedInteractivesContainer = new Ut;
            this.overlay = new jt({
                parent: this.overlayedInteractivesContainer.topAnchor,
                handleClick: this.handleOverlayClick
            });
            this.conversationsController = Ms(this.overlayedInteractivesContainer);
            this.createClickTriggerComponents(e)
        }
        registerMessageHandlers() {
            Ns.registerHandlers({
                [e.TRIGGER_CTA]: this.handleTriggerFromCTA,
                [e.NAVIGATE_PAGE]: this.handlePageNavigation,
                [e.CTA_FORM_SUBMITTED]: this.handleFormSubmission
            });
            this.eventManager.on(Ls.TRIGGER_OPEN, (({
                ctaToOpen: e
            }) => this.handleClickOpen(e)))
        }
        createClickTriggerComponents(e) {
            for (const [t, i] of e) i.forEach((e => {
                const i = new rs(e, (() => this.handleClickOpen(t))),
                    s = this.clickTriggerComponentMap.get(t) || [];
                this.clickTriggerComponentMap.set(t, [...s, i])
            }))
        }
        createOverlayInteractiveFromAudience(e) {
            if (!this.shouldCreateInteractiveOverlay(e)) return !1;
            if (!this.createOverlayComponentAndSetOnMap(e)) return !1;
            this.positionsOccupied.setPositionFromConfig(e);
            const t = bs(e.triggers, (t => this.handleTrigger(e.contentModelId, e.displayFrequency, t)));
            this.triggerMap.set(e.contentModelId, t);
            return !0
        }
        createOverlayInteractivesWithAudience() {
            for (const [e, t] of this.configModel.sortedConfigsWithSpecificty) this.createOverlayInteractiveFromAudience(t)
        }
        createOverlayInteractivesWithNoAudience() {
            for (const [e, t] of this.configModel.overlayedConfigsWithNoAudience) {
                if (this.interactiveComponentMap.has(e)) continue;
                if (!this.createOverlayComponentAndSetOnMap(t)) return;
                if (this.scheduledCTAsModel.scheduledCTAs.has(e)) {
                    this.openOverlay(e, !0);
                    this.scheduledCTAsModel.removeCTA(e)
                }
                this.sendAnalyticsToCTA(e)
            }
        }
        createTemplateOverlayInteractive() {
            this.createOverlayComponentAndSetOnMap(this.configModel.templateConfig)
        }
        createPreviewOverlayInteractive() {
            this.createOverlayComponentAndSetOnMap(this.configModel.previewConfig)
        }
        createOverlayComponentAndSetOnMap(e) {
            const t = is(e, e.iframeSrc && Ce(e.iframeSrc, this.environmentModel, this.analyticsModel));
            if (!t) return null;
            const i = e.contentModelId;
            if (this.triggeredCTAFromCallback) {
                const [e] = this.triggeredCTAFromCallback;
                i === e && t.skipAnimation()
            }
            this.environmentModel.isScreenshot && t.skipAnimation();
            this.interactiveComponentMap.set(i, t);
            this.overlayedInteractivesContainer.attachInteractiveOverlayToAnchor(t);
            t.registerResizeHandler((({
                height: e
            }) => {
                t.isTopBanner && this.overlayedInteractivesContainer.setTopPushHeight(e)
            }));
            t.registerCloseHandler((() => this.closeOverlay(e.contentModelId)));
            return t
        }
        shouldCreateInteractiveOverlay(e) {
            return !(wi(e.contentModelId, e.displayFrequency) && !this.clickTriggerComponentMap.has(e.contentModelId)) && !!this.positionsOccupied.canBeInsertedIntoPosition(e)
        }
        listenToConfigUpdates() {
            this.configModel.store.subscribe(((e, t) => {
                if (this.environmentModel.isPreview && 1 === e.configs.size) {
                    this.createPreviewOverlayInteractive();
                    requestAnimationFrame((() => {
                        this.configModel.previewConfig && this.openOverlay(this.configModel.previewConfig.contentModelId)
                    }))
                } else if (0 === t.configs.size && e.configs.size > 0) setTimeout((() => {
                    this.createOverlayInteractivesWithAudience();
                    this.createOverlayInteractivesWithNoAudience();
                    this.overlay && this.overlay.enableDisableBodyScroll()
                }));
                else if (e.templateConfig) {
                    this.createTemplateOverlayInteractive();
                    requestAnimationFrame((() => {
                        this.openOverlay(Ve)
                    }))
                } else {
                    e.configs.size > t.configs.size && this.createOverlayInteractivesWithNoAudience();
                    if (this.triggeredCTAFromCallback) {
                        const [t, i] = this.triggeredCTAFromCallback;
                        if (e.configs.has(t)) {
                            this.triggeredCTAFromCallback = null;
                            this.shouldCloseCalloutCTA(i) && this.closeOverlay(i)
                        }
                    }
                }
            }))
        }
        listenForOpenCTAMessage() {
            window.addEventListener("message", (t => {
                t && t.data && t.data.type === e.DISPLAY_CALL_TO_ACTION && this.openOverlay(t.data.id)
            }))
        }
        openOverlay(t, s = !1) {
            const n = this.interactiveComponentMap.get(t);
            if (n) {
                n.isTopBanner && this.overlayedInteractivesContainer.showPushBanner(n.container.clientHeight);
                s && n.setAnimationForClickTrigger();
                n.open().then((() => {
                    n.isTopBanner && this.overlayedInteractivesContainer.showPushBanner(n.container.clientHeight);
                    if (n.containerType === se.MODAL) {
                        this.shownModal = t;
                        this.overlay.show()
                    }
                    this.handleView(t);
                    Ns.broadcast(t, {
                        type: e.SHOWING_CTA,
                        payload: {}
                    })
                })).catch((e => {
                    i("Error opening overlay", e)
                }))
            }
        }
        messageCTAClosed(t) {
            Ns.broadcast(t, {
                type: e.HAS_CLOSED,
                payload: {}
            });
            this.eventManager.emit(Rs.HAS_CLOSED, {
                id: t
            })
        }
        shouldCloseCalloutCTA(e) {
            const t = this.configModel.configs.get(e);
            return !!t && t.isDismissable
        }
    }

    function ks(e) {
        return class extends e {
            constructor(e) {
                super(e);
                this.processConfigResponse = e => {
                    if (!e) return;
                    const t = e.sortedAudienceConfigs,
                        i = this.getShowingCTAIds(),
                        s = [];
                    for (const e of i) {
                        if (!t.find((t => t.contentModelId === e))) {
                            s.push(e);
                            continue
                        }
                        t.findLast((t => {
                            var i;
                            return t.contentModelId !== e && (null === (i = this.positionsOccupied) || void 0 === i ? void 0 : i.wouldConflictWithPosition(t, e, this.configModel))
                        })) && s.push(e)
                    }
                    this.handleRemovingCTAs(s);
                    this.createCTAsFromConfigs(t.reverse())
                };
                this.registerEventManagerEventHandlers()
            }
            registerEventManagerEventHandlers() {
                this.eventManager.on(Ls.REFRESH, (() => {
                    this.handleRefresh().catch((e => {
                        i("Error calling refresh handler:", e)
                    }))
                }));
                this.eventManager.on(Ls.CLOSE, (({
                    id: e
                }) => this.closeOverlay(e)));
                this.eventManager.on(Ls.CLOSE_ALL, (() => this.handleCloseAll()))
            }
            handleCloseAll() {
                this.getShowingCTAIds().forEach((e => this.closeOverlay(e)))
            }
            async handleRefresh() {
                this.environmentModel.refresh();
                await this.analyticsModel.refresh();
                const e = await this.configModel.init(Ue.buildConfigRequest(this.environmentModel, [], this.analyticsModel.store.state));
                this.processConfigResponse(e)
            }
            getShowingCTAIds() {
                return this.positionsOccupied ? this.positionsOccupied.getAllIds() : []
            }
            handleRemovingCTAs(e) {
                for (const t of e) {
                    this.closeOverlay(t);
                    const e = this.interactiveComponentMap.get(t);
                    e && e.remove();
                    this.interactiveComponentMap.delete(t);
                    this.positionsOccupied && this.positionsOccupied.removeCTA(t);
                    for (const [e, i] of this.triggerMap) {
                        e === t && i.forEach((e => e.remove()));
                        this.triggerMap.delete(t)
                    }
                }
            }
            createCTAsFromConfigs(e) {
                for (const t of e) this.createOverlayInteractiveFromAudience(t)
            }
        }
    }
    var Hs = ks(Fs);
    const Ds = "hs-cta-embed__loaded";
    class Vs {
        constructor({
            contentId: e,
            embedContainer: t,
            iframeSrc: i,
            useResponsiveStyling: s,
            srcdoc: n,
            isActiveAbTest: o,
            isPersonalizationEnabled: r
        }) {
            this.handleStart = e => {
                if (!this.isActiveAbTest && !this.isPersonalizationEnabled) return;
                if (!e.containerStyles) return;
                const t = e.containerStyles,
                    i = Ue.getStylesFromContainerStyles(t),
                    s = Ue.getStylesForIframe(t),
                    n = t.scaleHeightToFitContent || Boolean(t.isSingleModuleOnly);
                this.setStyles(i, s, n)
            };
            this.listenForLoad();
            this.frameComponent = y({
                id: e,
                container: t,
                iframeSrc: i,
                resizeHeight: !0,
                onFrameReady: this.resolveFrameload,
                useResponsiveStyling: s,
                extraAttributes: {
                    "aria-label": "Embedded CTA",
                    title: "Embedded CTA",
                    allow: "autoplay; fullscreen; clipboard-write"
                },
                srcdoc: n
            });
            this.frameComponent.iframe.setAttribute("data-test-id", "interactive-frame");
            this.frameComponent.iframe.classList.add(Mi);
            this.contentId = e;
            this.embedContainer = t;
            this.isActiveAbTest = o;
            this.isPersonalizationEnabled = r;
            this.listenForStart()
        }
        setStyles(e, i, s) {
            this.frameComponent.setShouldResize(s);
            t(this.embedContainer, e);
            this.frameComponent.setStyle(Object.assign({}, i));
            this.resolveConfig && this.resolveConfig()
        }
        listenForStart() {
            this.frameComponent.iframeCommunicator.registerHandlers({
                [e.STARTED]: this.handleStart
            })
        }
        showFrame() {
            this.frameComponent.setStyle({
                visibility: ""
            })
        }
        listenForLoad() {
            const e = new Promise((e => {
                    this.resolveFrameload = e
                })),
                t = new Promise((e => {
                    this.resolveConfig = e
                }));
            Promise.all([e, t]).then((() => {
                Array.from(this.embedContainer.children).forEach((e => {
                    e !== this.frameComponent.iframe && this.embedContainer.removeChild(e)
                }));
                this.embedContainer.classList.add(Ds);
                this.showFrame()
            })).catch((() => {}))
        }
    }
    class Bs {
        constructor({
            environmentModel: e,
            configStore: t,
            handleView: i,
            analyticsModel: s,
            scheduledCTAsModel: n
        }) {
            this.embeddedInteractives = new Map;
            this.elementObserver = j();
            this.styledComponentSet = new Set;
            this.flushScheduledCTAs = () => {
                for (const e of this.scheduledCTAsModel.scheduledCTAs) {
                    const t = this.configStore.embeddedConfigs.get(e);
                    if (!t || t.isHTMLVersionOnly) continue;
                    if (!this.scheduledCTAsModel.elementsForEmbeddedCTAs.has(e)) continue;
                    this.scheduledCTAsModel.elementsForEmbeddedCTAs.get(e).forEach((t => {
                        this.createView(e, t)
                    }));
                    this.handleView(e);
                    this.scheduledCTAsModel.removeCTA(e)
                }
            };
            this.environmentModel = e;
            this.configStore = t;
            this.scheduledCTAsModel = n;
            this.handleView = i;
            this.analyticsModel = s
        }
        init({
            embedContainers: e
        }) {
            this.embedContainers = e;
            this.environmentModel.isPreview || this.environmentModel.isTemplate || this.createViews();
            this.listenForConfigs();
            this.listenForElementViews();
            this.listenForScheduledCTAs()
        }
        listenForScheduledCTAs() {
            this.scheduledCTAsModel.subscribe(this.flushScheduledCTAs)
        }
        listenForElementViews() {
            if (this.embedContainers)
                for (const [e, t] of this.embedContainers)
                    for (const i of t) this.elementObserver.observe(i, (() => this.handleView(e)))
        }
        listenForConfigs() {
            this.configStore.configs.size > 0 ? this.setStylesOnContainer() : this.configStore.subscribe((() => {
                this.scheduledCTAsModel.scheduledCTAs.size > 0 && this.flushScheduledCTAs();
                if (this.configStore.embeddedConfigs.size > 0) {
                    (this.environmentModel.isPreview || this.environmentModel.isTemplate) && this.configStore.embeddedConfigs.size > 0 && this.createViews();
                    this.setStylesOnContainer()
                }
            }))
        }
        setStylesOnContainer() {
            for (const [e, t] of this.configStore.embeddedConfigs) {
                const i = this.embeddedInteractives.get(e);
                i && i.length && i.forEach((e => {
                    if (!this.styledComponentSet.has(e)) {
                        this.styledComponentSet.add(e);
                        e.isActiveAbTest = t.isActiveAbTest;
                        e.isPersonalizationEnabled = t.isPersonalizationEnabled;
                        e.setStyles(Ue.getStylesFromContainerStyles(t.containerStyles), Ue.getStylesForIframe(t.containerStyles), t.containerStyles.scaleHeightToFitContent || Boolean(t.containerStyles.isSingleModuleOnly))
                    }
                }))
            }
        }
        createViews() {
            for (const [e, t] of this.embedContainers) {
                let i;
                const s = this.configStore.embeddedConfigs.get(e);
                i = s ? s.iframeSrc : Te({
                    contentId: e,
                    portalId: this.environmentModel.portalId,
                    env: this.environmentModel.env,
                    hublet: this.environmentModel.hublet
                });
                i = i && Ce(i, this.environmentModel, this.analyticsModel);
                const n = [];
                t.forEach((t => {
                    const o = new Vs({
                        contentId: e,
                        embedContainer: t,
                        iframeSrc: i,
                        useResponsiveStyling: !!s && s.containerStyles.useResponsiveStyling,
                        srcdoc: null == s ? void 0 : s.srcdoc,
                        isActiveAbTest: null == s ? void 0 : s.isActiveAbTest,
                        isPersonalizationEnabled: null == s ? void 0 : s.isPersonalizationEnabled
                    });
                    n.push(o)
                }));
                this.embeddedInteractives.set(e, n)
            }
        }
        createView(e, t) {
            const i = this.configStore.embeddedConfigs.get(e);
            if (!i) return;
            const s = i.iframeSrc && Ce(i.iframeSrc, this.environmentModel, this.analyticsModel),
                n = new Vs({
                    contentId: e,
                    embedContainer: t,
                    iframeSrc: s,
                    useResponsiveStyling: i.containerStyles.useResponsiveStyling,
                    srcdoc: i.srcdoc,
                    isActiveAbTest: i.isActiveAbTest,
                    isPersonalizationEnabled: i.isPersonalizationEnabled
                }),
                o = this.embeddedInteractives.get(e) || [];
            this.embeddedInteractives.set(e, [...o, n]);
            this.setStylesOnContainer()
        }
    }
    const xs = "POP_OVER",
        Us = "hsCta";
    class $s {
        constructor({
            configStore: e,
            environmentModel: t
        }) {
            this.eventManager = Ps.getInstance();
            this.ignoreCta = ({
                id: e
            }) => {
                if (this.environmentModel.isPreview) return;
                const t = this.configStore.configs.get(e);
                if (t && t.containerType !== se.EMBEDDED) {
                    Ai(e, t.displayFrequency);
                    _i();
                    Oi()
                }
            };
            this.registerPopupPolice = ({
                id: e
            }) => {
                const t = this.configStore.configs.get(e);
                t && t.containerType === se.MODAL && window._registerAvailablePopup && window._registerAvailablePopup(Us, xs)
            };
            this.configStore = e;
            this.environmentModel = t;
            this.registerHandlers()
        }
        registerHandlers() {
            Ns.registerHandlers({
                [e.NAVIGATE_PAGE]: this.ignoreCta,
                [e.STARTED]: this.registerPopupPolice
            });
            this.eventManager.on(Rs.HAS_CLOSED, this.ignoreCta)
        }
    }

    function Gs(e) {
        return new $s(e)
    }
    const qs = Tt(["display:flex;justify-content:center;align-items:center;"]),
        js = "interactive-ready";
    class zs {
        constructor({
            environmentModel: e
        }) {
            this.environmentModel = e
        }
        init() {
            if (this.environmentModel.isPreview || this.environmentModel.isScreenshot || this.environmentModel.templatePath) {
                this.bodyWrapper = document.getElementsByClassName(et)[0];
                if (this.bodyWrapper) {
                    this.setupEmbedContainer();
                    this.setHeightForPreview();
                    this.listenForInteractiveLoaded()
                }
            }
        }
        setupEmbedContainer() {
            this.bodyWrapper.classList.add(qs);
            const e = this.environmentModel.previewId || 1;
            this.environmentModel.isTemplate ? this.bodyWrapper.innerHTML = `\n        <div class="${Ze} ${Ze}-NaN" data-hubspot-wrapper-cta-id="-1"></div>\n      ` : this.bodyWrapper.innerHTML = `\n        <div class="${Ze} ${Ze}-${e}">\n      `
        }
        setHeightForPreview() {
            this.bodyWrapper.style.height = "100vh"
        }
        listenForInteractiveLoaded() {
            Ns.registerHandlers({
                [e.STARTED]: () => document.body.classList.add(js)
            })
        }
    }

    function Ws({
        environmentModel: e
    }) {
        return new zs({
            environmentModel: e
        })
    }
    const Ys = e => {
            let t = 1,
                i = 0;
            for (; t > 0 && i !== e.length;) {
                const s = e[i];
                "{" === s ? t++ : "}" === s && t--;
                i++;
                if (i > e.length) return e.length
            }
            return i
        },
        Qs = e => window.matchMedia(e).matches,
        Xs = e => e.includes("width") ? "@media (min-width: 0px)" : e,
        Ks = (e, t = Qs) => {
            let i = "",
                s = e,
                n = s.indexOf("@media");
            if (-1 === n) return !1;
            for (; n > 0;) {
                i = `${i}${s.substring(0,n-1)}`;
                s = s.substring(n);
                const e = s.indexOf("{"),
                    o = s.substring(0, e);
                s = s.substring(e + 1);
                const r = Ys(s);
                if (t(o.replace("@media ", ""))) {
                    const e = s.substring(0, r - 1);
                    i = `${i}${Xs(o)} { ${e} }`
                }
                s = s.substring(r + 1);
                n = s.indexOf("@media")
            }
            return `${i}${s}`.trim()
        },
        Js = e => Object.keys(e).reduce(((t, i) => {
            const s = Ks(e[i]);
            return s ? Object.assign({}, t, {
                [i]: s
            }) : t
        }), {});
    var Zs = (e, t) => {
        let i = 0;
        return (...s) => {
            i && clearTimeout(i);
            i = setTimeout((() => {
                e(...s);
                i = 0
            }), t)
        }
    };
    const en = (...e) => {
        i("[ResponsiveController]", ...e)
    };
    class tn {
        constructor() {
            this.initialStylesheets = {}
        }
        init() {
            this.listenForStylesheetsHtml();
            const e = Zs((() => Object.keys(this.initialStylesheets).forEach((e => this.handleProcessStylesheets(Number(e))))), 100);
            window.addEventListener("resize", (() => {
                en("Resizing, reprocessing stylesheets");
                e()
            }))
        }
        listenForStylesheetsHtml() {
            Ns.registerHandlers({
                [e.SEND_STYLESHEETS]: e => {
                    this.initialStylesheets[e.id] = e.stylesheetsHtml;
                    this.handleProcessStylesheets(e.id)
                }
            })
        }
        handleProcessStylesheets(t) {
            if (!this.initialStylesheets[t]) return;
            const i = Js(this.initialStylesheets[t]);
            Ns.broadcast(t || 1, {
                type: e.RECEIVE_FILTERED_STYLESHEETS,
                payload: {
                    stylesheets: i
                }
            })
        }
    }

    function sn() {
        return new tn
    }

    function nn(e, t) {
        return "https://perf{region}.hsforms{env}.com/embed/v3/counters.gif".replace("{region}", `-${e}`).replace("{env}", "qa" === t ? "qa" : "")
    }
    const on = {
        CONFIG_LOADED_SUCCESS: "config-loaded-success",
        CONFIG_LOADED_FAILURE: "config-loaded-failure",
        INTERACTIVE_SHOWN: "interactive-shown",
        INTERACTIVE_CLOSED: "interactive-closed",
        INTERACTIVE_NAVIGATED: "interactive-navigated",
        INLINE_INTERACTIVE_RENDER_SUCCESS: "inline-interactive-render-success",
        INLINE_INTERACTIVE_RENDER_FAIL: "inline-interactive-render-fail",
        MOBILE_EXIT_INTENT_TRIGGERED: "mobile-exit-intent-triggered",
        MOBILE_EXIT_INTENT_CONVERTED: "mobile-exit-intent-converted"
    };
    class rn {
        constructor({
            environmentModel: e,
            configStore: t
        }) {
            this.eventManager = Ps.getInstance();
            this.perfUrl = "";
            this.mobileExitIntentTriggeredCTAs = new Set;
            this.environmentModel = e;
            this.configStore = t;
            this.registerHandlers();
            this.listenToConfigStore();
            this.listenToTriggerEvents()
        }
        init() {
            this.perfUrl = nn(this.environmentModel.hublet, this.environmentModel.env)
        }
        trackRender(e) {
            this.trackMetric(e ? on.INLINE_INTERACTIVE_RENDER_SUCCESS : on.INLINE_INTERACTIVE_RENDER_FAIL)
        }
        registerHandlers() {
            Ns.registerHandlers({
                [e.STARTED]: () => this.trackMetric(on.INTERACTIVE_SHOWN),
                [e.CLOSE_INTERACTIVE]: () => this.trackMetric(on.INTERACTIVE_CLOSED),
                [e.NAVIGATE_PAGE]: e => {
                    this.trackMetric(on.INTERACTIVE_NAVIGATED);
                    null != e && e.id && this.mobileExitIntentTriggeredCTAs.has(e.id) && this.trackMetric(on.MOBILE_EXIT_INTENT_CONVERTED)
                }
            })
        }
        listenToConfigStore() {
            this.configStore.subscribe((e => {
                e.requestError ? this.trackMetric(on.CONFIG_LOADED_FAILURE) : e.isLoaded && this.trackMetric(on.CONFIG_LOADED_SUCCESS)
            }))
        }
        listenToTriggerEvents() {
            this.eventManager.on(Rs.CTA_TRIGGERED, (({
                id: e,
                triggerType: t
            }) => {
                if (t === Es.MOBILE_EXIT_INTENT) {
                    this.trackMetric(on.MOBILE_EXIT_INTENT_TRIGGERED);
                    this.mobileExitIntentTriggeredCTAs.add(e)
                }
            }))
        }
        trackMetric(e) {
            if (!this.perfUrl.length) return;
            const t = `${this.perfUrl}?key=${e}&value=1`;
            (new Image).src = t
        }
    }

    function an(e) {
        return new rn(e)
    }

    function cn({
        env: e,
        hublet: t = ne
    }) {
        return Re({
            env: "prod" === e ? "" : e,
            hublet: t || ne,
            path: "track",
            contentIds: [],
            extraParams: {}
        })
    }
    const ln = (...e) => {
        i("[CTAAnalyticsController]", ...e)
    };
    class hn {
        constructor({
            analyticsStore: e,
            configsStore: t,
            environmentModel: i,
            ctaViewedStore: s
        }) {
            this.timingMap = new Map;
            this.viewQueue = I();
            this.variableContentViewQueueSet = new Set;
            this.hasViewed = new Set;
            this.eventManager = Ps.getInstance();
            this.embedIdToRenderedVariantIdMap = new Map;
            this.baseUrl = "";
            this.trackView = ({
                id: e
            }) => {
                if (!this.configStore.isLoaded) {
                    this.viewQueue.enqueue(e);
                    return
                }
                const t = this.configStore.configs.get(e);
                if (!(null != t && t.isActiveAbTest || null != t && t.isPersonalizationEnabled) || this.embedIdToRenderedVariantIdMap.has(e)) {
                    this.trackWithImage(e, "view");
                    this.timingMap.set(e, Date.now())
                } else this.variableContentViewQueueSet.add(e)
            };
            this.trackClose = ({
                id: e
            }) => {
                this.trackWithImage(e, "close")
            };
            this.trackTriggerClick = ({
                id: e
            }) => {
                this.trackNavigation({
                    id: e
                }, !0)
            };
            this.trackNavigation = ({
                id: e
            }, t = !1) => {
                const i = this.configStore.configs.get(e);
                if (!i) return;
                const s = new URL(this.attachTrackingParamsToUrl(`${this.baseUrl}/click`, e));
                (t || i.shouldUseJsTracking) && s.searchParams.set("beaconTrack", "true");
                s.searchParams.has("beaconTrack") && ("sendBeacon" in navigator ? navigator.sendBeacon(s) : fetch(s, {
                    method: "POST",
                    keepalive: !0
                }))
            };
            this.handleCTAStarted = ({
                id: e,
                contentId: t
            }) => {
                if (t) {
                    this.embedIdToRenderedVariantIdMap.set(e, t);
                    if (this.variableContentViewQueueSet.has(e)) {
                        this.variableContentViewQueueSet.delete(e);
                        this.trackView({
                            id: e
                        })
                    }
                }
            };
            this.handleMeetingsSuccess = ({
                id: e
            }) => {
                this.trackNavigation({
                    id: e
                }, !0)
            };
            this.analyticsStore = e;
            this.configStore = t;
            this.environmentModel = i;
            this.ctaViewedStore = s
        }
        init() {
            this.baseUrl = cn({
                env: this.environmentModel.env,
                hublet: this.environmentModel.hublet
            });
            if (!this.environmentModel.isPreview && !this.environmentModel.isTemplate) {
                this.registerHandlers();
                this.listenForStoreLoad();
                this.listenForViewChange();
                this.handleViews()
            }
        }
        registerHandlers() {
            Ns.registerHandlers({
                [e.CLOSE_INTERACTIVE]: this.trackClose,
                [e.NAVIGATE_PAGE]: this.trackNavigation,
                [e.TRIGGER_CTA]: this.trackTriggerClick,
                [e.STARTED]: this.handleCTAStarted,
                [e.MEETINGS_BOOKING_SUCCESS]: this.handleMeetingsSuccess
            });
            this.eventManager.on(Ls.TRIGGER_OPEN, (({
                ctaTrigger: e
            }) => this.trackTriggerClick({
                id: e
            })))
        }
        listenForStoreLoad() {
            this.configStore.subscribe(((e, t) => {
                e.isLoaded && !t.isLoaded && this.flushViewQueue()
            }))
        }
        listenForViewChange() {
            this.ctaViewedStore.subscribe((() => {
                this.handleViews()
            }))
        }
        handleViews() {
            for (const e of this.ctaViewedStore.viewed)
                if (!this.hasViewed.has(e)) {
                    this.trackView({
                        id: e
                    });
                    this.hasViewed.add(e)
                }
        }
        flushViewQueue() {
            do {
                const e = this.viewQueue.dequeue();
                e && this.trackView({
                    id: e
                })
            } while (this.viewQueue.peek())
        }
        trackWithImage(e, t) {
            ln("Tracking:", t, e);
            let i = `${this.baseUrl}/${t}`;
            i = this.attachTrackingParamsToUrl(i, e);
            (new Image).src = i
        }
        logMismatchedTrackingIdsSessionData(e, t, i, s) {
            ln("Logging potentially mismatched tracking IDs session data", e, t, i, {
                hutk: s
            });
            const n = JSON.stringify({
                portalId: this.environmentModel.portalId,
                contentIdPassed: e,
                contentIdAttached: t,
                webInteractiveIdAttached: i,
                hutk: s,
                embedIdToRenderedVariantIdMap: Object.fromEntries(this.embedIdToRenderedVariantIdMap),
                configs: Object.fromEntries(this.configStore.configs),
                variableContentViewQueueSet: Array.from(this.variableContentViewQueueSet),
                ctaViewedStore: Array.from(this.ctaViewedStore.viewed),
                communicators: JSON.stringify(Array.from(Ns.iframeCommunicators.entries()).map((([e, t]) => [e, t.map((e => [e.id, e.iframe.src]))])))
            });
            fetch(`${this.baseUrl}/log-mismatched-ids-session-data`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: n
            })
        }
        attachTrackingParamsToUrl(e, t) {
            const i = new URL(e),
                s = this.configStore.configs.get(t);
            if (!s) return i.href;
            i.searchParams.set("webInteractiveContentId", String(t));
            if ((s.isActiveAbTest || s.isPersonalizationEnabled) && this.embedIdToRenderedVariantIdMap.has(t)) {
                i.searchParams.set("webInteractiveContentId", String(this.embedIdToRenderedVariantIdMap.get(t)));
                if (this.environmentModel.patches.abTestingIdMisMatch) {
                    const e = this.analyticsStore.analytics;
                    this.logMismatchedTrackingIdsSessionData(t, Number(i.searchParams.get("webInteractiveContentId")), s.webInteractiveId, e.hutk)
                }
            }
            i.searchParams.set("webInteractiveId", String(s.webInteractiveId));
            i.searchParams.set("containerType", s.containerType);
            i.searchParams.set("portalId", String(this.environmentModel.portalId));
            i.searchParams.set("audienceId", String(s.audienceId));
            s.campaignGuid && i.searchParams.set("campaignId", s.campaignGuid);
            const n = this.analyticsStore.analytics;
            n && Object.entries(n).forEach((([e, t]) => {
                t && i.searchParams.set(e, String(t))
            }));
            const o = this.timingMap.get(t);
            if (o) {
                i.searchParams.set("timeStarted", String(o));
                i.searchParams.set("timeFinished", String(Date.now()))
            }
            return i.href
        }
    }

    function dn(e) {
        return new hn(e)
    }
    const un = ["elementToEmbed"];
    class mn {
        constructor({
            configModel: e,
            customerCtaOptions: t,
            scheduleCTA: i
        }) {
            this.defferedPromiseMap = new Map;
            this.handleCtaLoad = ({
                id: e
            }) => {
                if (!this.defferedPromiseMap.has(e)) return;
                this.defferedPromiseMap.get(e)(null);
                this.defferedPromiseMap.delete(e)
            };
            this.handleNavigate = ({
                id: e
            }) => {
                const t = this.customerCtaOptions.options.get(e);
                t && "function" == typeof t.onNavigate && t.onNavigate()
            };
            this.loadCta = e => new Promise(((t, i) => {
                e || i(new Error("Invalid options"));
                const {
                    contentId: s,
                    options: n
                } = e, {
                    elementToEmbed: o
                } = n, r = Ee(n, un);
                s || i(new Error("Invalid options"));
                this.scheduleCTA(s, Array.isArray(o) ? o : [o]);
                Object.keys(r).length && this.customerCtaOptions.setOption(s, r);
                this.defferedPromiseMap.set(s, t)
            }));
            this.configModel = e;
            this.customerCtaOptions = t;
            this.scheduleCTA = i;
            window.hsCtasOnReady = window.hsCtasOnReady || [];
            this.attachToWindow();
            this.registerHandlers()
        }
        init() {
            this.flushOnReadyQueue()
        }
        registerHandlers() {
            Ns.registerHandlers({
                [e.STARTED]: this.handleCtaLoad,
                [e.NAVIGATE_PAGE]: this.handleNavigate
            })
        }
        attachToWindow() {
            window.__PRIVATE__HubspotCtaClient = {
                loadCta: this.loadCta
            }
        }
        flushOnReadyQueue() {
            const e = window.hsCtasOnReady;
            for (; e.length;) {
                const t = e.shift();
                "function" == typeof t && t()
            }
            Object.defineProperty(window.hsCtasOnReady, "push", {
                value: e => {
                    "function" == typeof e && e()
                },
                writable: !0
            })
        }
    }

    function gn(e) {
        return new mn(e)
    }
    const pn = (...e) => {
        i("[NonFramedCTA]", ...e)
    };
    class fn {
        constructor({
            cta: e,
            onNavigate: t,
            onView: i
        }) {
            this.removeEventListenerCallbacks = [];
            this.elementObserver = j();
            this.hasView = !1;
            this.id = "";
            this.cta = e;
            this.id = this.cta.id;
            this.onNavigate = t;
            this.onView = i;
            this.listenForAnchorClicks();
            this.listenForView()
        }
        getCtaInstance() {
            this.cta && this.cta.parentNode || (this.cta = document.getElementById(this.id));
            return this.cta
        }
        replaceCtaInstance(e) {
            pn("Replacing html", e, this.id);
            const t = this.getCtaInstance();
            if (!t) return;
            const i = lt(t, e);
            this.removeExistingEventListeners();
            t.innerHTML = i.innerHTML;
            t.dataset.rendered = "true";
            this.reapplyEventListeners(t)
        }
        removeExistingEventListeners() {
            this.hasView || this.elementObserver.unobserve(this.cta);
            this.removeEventListenerCallbacks.forEach((e => e()));
            this.removeEventListenerCallbacks = []
        }
        reapplyEventListeners(e) {
            this.id = e.id;
            this.cta = e;
            this.listenForAnchorClicks();
            this.hasView || this.listenForView()
        }
        listenForAnchorClicks() {
            const e = [...this.cta.querySelectorAll("a")];
            "A" === this.cta.tagName && e.push(this.cta);
            for (const t of e) {
                const e = "_blank" === t.target,
                    i = e => {
                        e.preventDefault()
                    };
                let s;
                t.classList.contains("hs-cta-trigger-button") && (s = ot(t));
                const n = i => {
                        i.preventDefault();
                        ss(i) && this.onNavigate(t.href, e, s)
                    },
                    o = i => {
                        if ("Enter" === i.key) {
                            i.preventDefault();
                            this.onNavigate(t.href, e, s)
                        }
                    };
                t.addEventListener("click", i);
                t.addEventListener("mouseup", n);
                t.addEventListener("keydown", o);
                this.removeEventListenerCallbacks.push((() => {
                    t.removeEventListener("click", i);
                    t.removeEventListener("mouseup", n);
                    t.removeEventListener("keypress", o)
                }))
            }
        }
        listenForView() {
            this.elementObserver.observe(this.cta, (() => {
                this.onView();
                this.hasView = !0;
                this.elementObserver.unobserve(this.cta)
            }))
        }
    }

    function vn(e) {
        return new fn(e)
    }
    const Tn = (...e) => {
            i("[populateLinksWithTrackingParams]", ...e)
        },
        Cn = ["currentUrl", "referrer", "canon", "canonicalUrl", "pageUrl", "contentType", "encryptedPayload", "pageId", "analyticsPageId", "hutk", "hstc", "hssc", "hsfp", "utk", "containerType", "webInteractiveId", "webInteractiveContentId", "audienceId", "campaignGuid", "campaignId", "userAgent", "timeStarted", "timeFinished", "redirectUrl", "skip", "includeInitial", "pageTitle", "contentGroupId", "portalId", "hsCtaAttrib"],
        En = `https://${(new Date).getTime()}-dummy.com`,
        bn = (e, t) => {
            let i, s = !1;
            try {
                i = new URL(e)
            } catch (t) {
                Tn("[populateLinksWithTrackingParams]", "Checking for relative URL", e);
                s = !0
            }
            if (s) try {
                i = new URL(`${En}${e.startsWith("/"),""}${e}`)
            } catch (t) {
                Tn("Could not parse url for link", t);
                return e
            }
            Object.entries(t).forEach((([e, t]) => {
                Cn.includes(e) ? null != t && i.searchParams.set(e, String(t)) : Tn("Invalid analytics parameter passed", e)
            }));
            const n = i.href;
            return s ? n.replace(En, "") : n
        };
    var Sn = (e, t = [...document.querySelectorAll(".hs-web-interactive a")]) => {
        t.length && t.forEach((t => {
            const i = t.getAttribute("href");
            i && !i.startsWith("javascript") && t.setAttribute("href", bn(i, e))
        }))
    };
    const yn = ["isHubspotPage"],
        wn = "render/html";

    function An(e) {
        let {
            isHubspotPage: t
        } = e, i = Ee(e, yn);
        const s = {};
        t && (s.isHubspotPage = "true");
        return Re(Object.assign({}, i, {
            extraParams: s,
            path: wn
        }))
    }
    class In {
        constructor() {
            this.handleFetchFailed = () => {
                this.store.setState((e => Object.assign({}, e, {
                    requestError: !0
                })))
            };
            this.handleFetchSucceded = e => {
                this.store.setState((t => Object.assign({}, t, {
                    renderedHtmlMap: Object.assign({}, t.renderedHtmlMap, {
                        htmlMap: e
                    }),
                    isLoaded: !0
                })))
            };
            const e = {
                renderedHtmlMap: {},
                request: null,
                requestError: !1,
                isLoaded: !1
            };
            this.store = new w(e)
        }
        init(e) {
            this.store.setState((t => Object.assign({}, t, {
                request: e
            })));
            return this.fetchEmbeddedHtml()
        }
        subscribe(e) {
            this.store.subscribe(e)
        }
        get renderedHtmlMap() {
            return this.store.state.renderedHtmlMap
        }
        get isLoaded() {
            return this.store.state.isLoaded
        }
        fetch(e) {
            return fetch(e).then((e => {
                if (!e.ok) {
                    this.handleFetchFailed();
                    return Promise.resolve(null)
                }
                return e.json().then((e => {
                    this.handleFetchSucceded(e);
                    return e
                })).catch(this.handleFetchFailed)
            })).catch(this.handleFetchFailed)
        }
        fetchEmbeddedHtml() {
            const e = this.store.state.request;
            if (!e) return Promise.resolve(null);
            const t = An(e);
            return this.fetch(t)
        }
    }
    var _n = new In;
    const On = (...e) => {
        i("[NonFramedCTAController", ...e)
    };
    class Mn {
        constructor({
            handleView: e,
            configStore: t,
            handleNavigation: i,
            analyticsStore: s,
            environmentModel: n,
            metricsController: o,
            scheduledCTAsModel: r
        }) {
            this.componentMap = new Map;
            this.eventManager = Ps.getInstance();
            this.cleanupFuncs = [];
            this.flushScheduledCTAs = () => {
                for (const e of this.scheduledCTAsModel.scheduledCTAs) {
                    const t = this.configStore.embeddedConfigs.get(e);
                    if (!t || !t.isHTMLVersionOnly) return;
                    if (!this.scheduledCTAsModel.elementsForEmbeddedCTAs.has(e)) return;
                    const i = this.scheduledCTAsModel.elementsForEmbeddedCTAs.get(e);
                    let s = this.nonFramedCTAContainers.get(e);
                    s || (s = []);
                    this.nonFramedCTAContainers.set(e, [...s, ...i]);
                    this.createViewsForElements(e, i);
                    this.requestHTML();
                    this.scheduledCTAsModel.removeCTA(e)
                }
            };
            this.getAnchorsFromElements = e => {
                let t = [];
                e.forEach((e => {
                    "A" === e.tagName && (t = [...t, e]);
                    t = [...t, ...e.querySelectorAll("a")]
                }));
                return t
            };
            this.handleView = e;
            this.handleNavigation = i;
            this.configStore = t;
            this.analyticsStore = s;
            this.environmentModel = n;
            this.renderedHtmlStore = _n;
            this.metricsController = o;
            this.scheduledCTAsModel = r
        }
        init({
            nonFramedCTAContainers: e
        }) {
            this.nonFramedCTAContainers = e;
            e.size && this.requestHTML();
            this.listenForConfigs();
            this.listenForScheduledCTAs();
            this.environmentModel.isPreview || this.environmentModel.isPreviewPage || this.listenForAnalyticsUpdate()
        }
        listenForScheduledCTAs() {
            this.scheduledCTAsModel.subscribe(this.flushScheduledCTAs)
        }
        cleanup() {
            this.cleanupFuncs.forEach((e => e()))
        }
        requestHTML() {
            const e = e => {
                    if (!e) return;
                    this.metricsController.trackRender(!0);
                    Object.keys(e).forEach((t => {
                        const i = Number(t),
                            s = e[i],
                            n = this.componentMap.get(i);
                        if (n) n.forEach((e => {
                            e.replaceCtaInstance(s)
                        }));
                        else {
                            On("Views not created yet, just replacing existing elements");
                            const e = this.nonFramedCTAContainers.get(i);
                            e && e.length && e.forEach((e => {
                                const t = lt(e, s);
                                e.innerHTML = t.innerHTML;
                                e.dataset.rendered = "true"
                            }))
                        }
                        this.hydrateLinksWithAllData(i)
                    }));
                    const t = Object.keys(e).map(Number);
                    this.eventManager.emit(Ls.REPLACED_INLINE_HTML, {
                        ids: t
                    })
                },
                {
                    isPreview: t,
                    currentUrl: i,
                    portalId: s,
                    env: n,
                    hublet: o,
                    versionId: r
                } = this.environmentModel,
                a = [...this.nonFramedCTAContainers.keys()].filter((e => !this.renderedHtmlStore.renderedHtmlMap[e]));
            if (!a.length) return;
            const c = {
                contentIds: a,
                currentUrl: i,
                portalId: s,
                env: n,
                hublet: o,
                analytics: this.analyticsStore.analytics,
                isPreview: t,
                versionId: r,
                isHubspotPage: this.environmentModel.isCos()
            };
            On("Requesting HTML", c);
            this.renderedHtmlStore.init(c).then(e).catch((e => {
                On("Failed getting HTML", e);
                this.metricsController.trackRender(!1)
            }))
        }
        createViewsForElements(e, t) {
            const i = [];
            let s = 0;
            for (const n of t) {
                n.id = `hs-cta-${e}-${s++}`;
                const o = vn({
                    cta: n,
                    onNavigate: (t, i, s) => {
                        s ? this.eventManager.emit(Ls.TRIGGER_OPEN, {
                            ctaToOpen: s,
                            ctaTrigger: e
                        }) : this.handleNavigation(t, e, i)
                    },
                    onView: () => {
                        this.handleView(e)
                    }
                });
                i.push(o);
                const r = this.configStore.configs.get(e);
                if (r) {
                    const i = this.getAnchorsFromElements(t);
                    Sn({
                        webInteractiveContentId: e,
                        webInteractiveId: r.webInteractiveId,
                        audienceId: r.audienceId,
                        containerType: r.containerType,
                        campaignId: r.campaignGuid,
                        pageUrl: this.environmentModel.currentUrl,
                        portalId: this.environmentModel.portalId
                    }, i)
                }
            }
            const n = this.componentMap.get(e) || [];
            this.componentMap.set(e, [...n, ...i])
        }
        createViews() {
            for (const [e, t] of this.nonFramedCTAContainers) this.createViewsForElements(e, t)
        }
        hydrateLinksWithAllData(e) {
            let t = {};
            const i = this.configStore.configs.get(e);
            i && (t = {
                webInteractiveContentId: e,
                webInteractiveId: i.webInteractiveId,
                audienceId: i.audienceId,
                containerType: i.containerType,
                campaignId: i.campaignGuid,
                pageUrl: this.environmentModel.currentUrl,
                portalId: this.environmentModel.portalId
            });
            const s = this.analyticsStore.analytics;
            t = Object.assign({}, t, s);
            let n = [];
            for (const [, e] of this.nonFramedCTAContainers) n = [...n, ...this.getAnchorsFromElements(e)];
            Sn(t, n)
        }
        listenForConfigs() {
            this.cleanupFuncs.push(this.configStore.subscribe((() => {
                this.scheduledCTAsModel.scheduledCTAs.size > 0 && this.flushScheduledCTAs();
                this.createViews()
            })))
        }
        listenForAnalyticsUpdate() {
            const e = () => {
                let e = [];
                for (const [, t] of this.nonFramedCTAContainers) e = [...e, ...this.getAnchorsFromElements(t)];
                Sn(this.analyticsStore.analytics, e)
            };
            this.analyticsStore.analytics.isLoaded ? e() : this.cleanupFuncs.push(this.analyticsStore.subscribe(((t, i) => {
                !i.isLoaded && t.isLoaded && e()
            })))
        }
    }

    function Pn(e) {
        return new Mn(e)
    }
    const Ln = ["openInNewTab", "onNavigate"];
    class Rn {
        constructor() {
            const e = {
                options: new Map
            };
            this.store = new w(e)
        }
        subscribe(e) {
            this.store.subscribe(e)
        }
        setOption(e, t) {
            const {
                openInNewTab: i,
                onNavigate: s
            } = t;
            Ee(t, Ln);
            this.store.setState((t => {
                const n = structuredClone(t.options);
                n.set(e, {
                    openInNewTab: i,
                    onNavigate: s
                });
                return Object.assign({}, t, {
                    options: n
                })
            }))
        }
        get options() {
            return this.store.state.options
        }
    }

    function Nn() {
        return new Rn
    }
    class Fn {
        constructor() {
            const e = {
                scheduledCTAs: new Set,
                elementsForEmbeddedCTAs: new Map
            };
            this.store = new w(e)
        }
        subscribe(e) {
            this.store.subscribe(e)
        }
        scheduleCTA(e) {
            this.store.setState((t => Object.assign({}, t, {
                scheduledCTAs: new Set([...t.scheduledCTAs, e])
            })))
        }
        scheduleEmbeddedCTA(e, t) {
            this.store.setState((i => Object.assign({}, i, {
                scheduledCTAs: new Set([...i.scheduledCTAs, e]),
                elementsForEmbeddedCTAs: Y(i.elementsForEmbeddedCTAs, new Map([
                    [e, t]
                ]))
            })))
        }
        removeCTA(e) {
            this.store.setState((t => {
                const i = structuredClone(t.scheduledCTAs);
                i.delete(e);
                return Object.assign({}, t, {
                    scheduledCTAs: i,
                    elementsForEmbeddedCTAs: z(t.elementsForEmbeddedCTAs, ((t, i) => i !== e))
                })
            }))
        }
        get scheduledCTAs() {
            return this.store.state.scheduledCTAs
        }
        get elementsForEmbeddedCTAs() {
            return this.store.state.elementsForEmbeddedCTAs
        }
    }

    function kn() {
        return new Fn
    }
    const Hn = {
            onCallToActionReady: "onCallToActionReady",
            onCallToActionViewed: "onCallToActionViewed",
            onCallToActionNavigated: "onCallToActionNavigated",
            onCallToActionFormSubmitted: "onCallToActionFormSubmitted",
            onCallToActionReplacedInlineHTML: "onCallToActionReplacedInlineHTML",
            onCallToActionMeetingBooked: "onCallToActionMeetingBooked",
            onCallToActionClosed: "onCallToActionClosed"
        },
        Dn = "hsCallsToActionCallback",
        Vn = 1e3;
    class Bn {
        constructor({
            configModel: e
        }) {
            this.eventEmitter = n();
            this.eventManager = Ps.getInstance();
            this.refresh = X((() => {
                this.eventManager.emit(Ls.REFRESH, {})
            }), Vn);
            this.configModel = e;
            window.hsCallsToActionsReady = window.hsCallsToActionsReady || [];
            this.registerHandlers()
        }
        init() {
            this.attachToWindow();
            this.flushOnReadyQueue()
        }
        handleView(e) {
            this.handleEventCall({
                id: e
            }, Hn.onCallToActionViewed)
        }
        closeAll() {
            this.eventManager.emit(Ls.CLOSE_ALL, {})
        }
        close(e) {
            this.eventManager.emit(Ls.CLOSE, {
                id: e
            })
        }
        attachToWindow() {
            window.HubSpotCallsToActions = {
                on: this.eventEmitter.on.bind(this.eventEmitter),
                off: this.eventEmitter.off.bind(this.eventEmitter),
                refresh: this.refresh,
                closeAll: this.closeAll.bind(this),
                close: this.close.bind(this)
            }
        }
        flushOnReadyQueue() {
            const e = window.hsCallsToActionsReady;
            for (; e.length;) {
                const t = e.shift();
                "function" == typeof t && t()
            }
            Object.defineProperty(window.hsCallsToActionsReady, "push", {
                value: e => {
                    "function" == typeof e && e()
                },
                writable: !0
            })
        }
        handleEventCall(e, t) {
            this.eventEmitter.emit(t, e);
            window.postMessage({
                type: Dn,
                id: e.id,
                eventName: t,
                data: e
            })
        }
        registerHandlers() {
            Ns.registerHandlers({
                [e.STARTED]: e => this.handleEventCall(e, Hn.onCallToActionReady),
                [e.NAVIGATE_PAGE]: e => this.handleEventCall(e, Hn.onCallToActionNavigated),
                [e.CTA_FORM_SUBMITTED]: e => this.handleEventCall(e, Hn.onCallToActionFormSubmitted),
                [e.MEETINGS_BOOKING_SUCCESS]: e => this.handleEventCall({
                    id: null == e ? void 0 : e.id
                }, Hn.onCallToActionMeetingBooked),
                [e.CLOSE_INTERACTIVE]: e => this.handleEventCall(e, Hn.onCallToActionClosed)
            });
            this.eventManager.on(Ls.REPLACED_INLINE_HTML, (e => this.handleEventCall(e, Hn.onCallToActionReplacedInlineHTML)))
        }
    }

    function xn(e) {
        return new Bn(e)
    }
    class Un {
        constructor(e) {
            this.environmentModel = e.environmentModel;
            this.configStore = e.configsStore
        }
        init() {
            window.addEventListener("pageshow", (e => {
                e.persisted && this.shouldReloadPage() && window.location.reload()
            }))
        }
        shouldReloadPage() {
            return this.environmentModel.patches.bfCacheReload && this.configStore.configs.size > 0
        }
    }

    function $n(e) {
        return new Un(e)
    }
    const Gn = (...e) => {
        i("[WebInteractiveApplicationContainer]", ...e)
    };

    function qn(e) {
        const [t, i] = e.split("?");
        if (!i) return {
            location: t,
            queryParams: {}
        };
        return i.split("&").reduce(((e, t) => {
            const [i, s] = t.split("=");
            return Object.assign({
                [i]: s
            }, e)
        }), {})
    }
    class jn extends G {
        constructor({
            configStore: e,
            environmentModel: t
        }) {
            super();
            this.scheduleCTA = (e, t) => {
                t ? this.scheduledCTAs.scheduleEmbeddedCTA(e, t) : this.scheduledCTAs.scheduleCTA(e);
                this.configStore.fetchConfigsWithIds([e])
            };
            this.handleView = e => {
                this.viewedStore.markAsViewed(e);
                this.analyticsProxyController.flushViewQueue(e);
                this.thirdPartyApiController.handleView(e)
            };
            this.handleNavigation = (e, t, i = !1) => {
                _(this.getNavigationUrl({
                    url: e,
                    openNewTab: i
                }, t), i)
            };
            this.configStore = e;
            this.environmentModel = t;
            this.viewedStore = Ke();
            this.customerCTAOptions = Nn();
            this.scheduledCTAs = kn();
            this.overlayedInteractivesController = new Hs({
                configModel: this.configStore,
                environmentModel: t,
                analyticsModel: this.analyticsStore,
                scheduledCTAsModel: this.scheduledCTAs,
                handleView: this.handleView,
                scheduleCTA: this.scheduleCTA
            });
            this.embeddedInteractivesController = new Bs({
                environmentModel: t,
                configStore: e,
                scheduledCTAsModel: this.scheduledCTAs,
                analyticsModel: this.analyticsStore,
                handleView: this.handleView
            });
            this.ignorerController = Gs({
                configStore: e,
                environmentModel: t
            });
            this.previewController = Ws({
                environmentModel: this.environmentModel
            });
            this.responsiveController = sn();
            this.metricsController = an({
                environmentModel: this.environmentModel,
                configStore: e
            });
            this.ctaAnalyticsController = dn({
                configsStore: this.configStore,
                analyticsStore: this.analyticsStore,
                environmentModel: this.environmentModel,
                ctaViewedStore: this.viewedStore
            });
            this.apiClientController = gn({
                configModel: this.configStore,
                customerCtaOptions: this.customerCTAOptions,
                scheduleCTA: this.scheduleCTA
            });
            this.thirdPartyApiController = xn({
                configModel: this.configStore
            });
            this.nonFramedCTAController = Pn({
                configStore: this.configStore,
                handleView: this.handleView,
                analyticsStore: this.analyticsStore,
                handleNavigation: this.handleNavigation,
                environmentModel: this.environmentModel,
                metricsController: this.metricsController,
                scheduledCTAsModel: this.scheduledCTAs
            });
            this.bfCacheController = $n({
                environmentModel: this.environmentModel,
                configsStore: this.configStore
            });
            this.listenForConfigs()
        }
        init() {
            if (this.environmentModel.init()) {
                this.metricsController.init();
                this.previewController.init();
                this.responsiveController.init();
                this.parsedDomResults = ct();
                this.configStore.init(this._buildConfigRequest()).then((e => {
                    this.processConfigResponse(e)
                })).catch((e => {
                    Gn("Error fetching configs", e)
                }));
                this.embeddedInteractivesController.init({
                    embedContainers: this.parsedDomResults.embedContainers
                });
                this.nonFramedCTAController.init({
                    nonFramedCTAContainers: this.parsedDomResults.nonFramedCTAContainers
                });
                this.overlayedInteractivesController.init({
                    clickTriggerButtons: this.parsedDomResults.clickTriggerButtons
                });
                this.ctaAnalyticsController.init();
                this.apiClientController.init();
                this.thirdPartyApiController.init();
                this.bfCacheController.init()
            } else Gn("Environment failed to initialize, aborting web interactives init")
        }
        _buildConfigRequest() {
            let e = [];
            const {
                isPreview: t,
                previewId: i
            } = this.environmentModel;
            e = t && i ? [i] : [...this.parsedDomResults.uniqueIds];
            return Ue.buildConfigRequest(this.environmentModel, e, this.analyticsStore.store.state)
        }
        getNavigationUrl({
            url: e
        }, t) {
            const i = new URL(e);
            if (!i.searchParams.has("encryptedPayload")) return e;
            const s = qn(e),
                n = this.configStore.configs.get(t);
            if (!n) return e;
            i.searchParams.set("webInteractiveId", String(n.webInteractiveId));
            i.searchParams.set("containerType", n.containerType);
            n.campaignGuid && i.searchParams.set("campaignId", n.campaignGuid);
            n.contentModelId && i.searchParams.set("webInteractiveContentId", String(n.contentModelId));
            n.audienceId && i.searchParams.set("audienceId", String(n.audienceId));
            this.analyticsStore.analytics.hutk && i.searchParams.set("hutk", this.analyticsStore.analytics.hutk);
            this.environmentModel.language && i.searchParams.set("hsLang", this.environmentModel.language);
            i.searchParams.delete("encryptedPayload");
            return decodeURIComponent(s.encryptedPayload) === s.encryptedPayload ? `${i.href}&encryptedPayload=${encodeURIComponent(s.encryptedPayload)}` : `${i.href}&encryptedPayload=${s.encryptedPayload}`
        }
        getShouldOpenNewTab(e, t) {
            if (!this.customerCTAOptions.options.has(t)) return e.openNewTab;
            return this.customerCTAOptions.options.get(t).openInNewTab || !1
        }
        listenForConfigs() {
            this.configStore.subscribe(((t, i) => {
                setTimeout((() => {
                    if (t.configs.size !== i.configs.size)
                        for (const [t, i] of this.configStore.configs) Ns.broadcast(t, {
                            type: e.SEND_CTA_CONFIG,
                            payload: Object.assign({
                                portalId: this.environmentModel.portalId,
                                pageUrl: this.environmentModel.currentUrl,
                                pageTitle: document.title,
                                gates: this.environmentModel.gates,
                                pageId: this.environmentModel.pageId,
                                hutk: this.analyticsStore.analytics.hutk
                            }, i)
                        })
                }))
            }))
        }
        processConfigResponse(e) {
            if (e && Array.isArray(e.gates)) {
                Gn("Retrieved Gates from config response", e.gates);
                this.environmentModel.setGates(e.gates)
            }
        }
    }
    const zn = new jn({
        configStore: $e,
        environmentModel: Qe
    });
    window.__hsWebInteractiveInstance = zn;
    var Wn = zn;
    const Yn = () => !(!window.disabledHsPopups || !(window.disabledHsPopups.indexOf("LEADFLOW") > -1 || window.disabledHsPopups.indexOf("CTAS") > -1 || window.disabledHsPopups.indexOf("CALLS_TO_ACTION") > -1)) || !!window.hsInEditor;

    function Qn() {
        document.querySelectorAll(".hs-cta-embed").forEach((e => {
            e.classList.add("hs-cta-embed__loaded");
            const t = e.querySelector(".hs-cta-loading-dot__container");
            t && t.remove();
            const i = e.querySelector(".hs-cta-embed__skeleton");
            i && i.remove()
        }))
    }

    function Xn() {
        Qn();
        new MutationObserver((e => {
            for (const t of e) "childList" === t.type && t.addedNodes.forEach((e => {
                1 === e.nodeType && e instanceof HTMLElement && e.querySelector(".hs-cta-embed") && Qn()
            }))
        })).observe(document.body, {
            childList: !0,
            subtree: !0
        })
    }
    const Kn = async () => {
            if (Yn()) {
                if (window.hsInEditor) try {
                    Xn()
                } catch (e) {
                    console.error("Error marking cta embed preview as loaded", e)
                }
            } else if (window.hubspot_web_interactives_running) console.error("duplicate instance of web interactives app exists");
            else {
                window.hubspot_web_interactives_running = !0;
                try {
                    vi() && await hi()
                } catch (e) {
                    console.error("Error eagerly loading saved frequency rules", e)
                }
                Wn.init()
            }
        },
        Jn = () => {
            Kn().catch((e => {
                console.error("Error initializing web interactives", e)
            }));
            document.removeEventListener("DOMContentLoaded", Jn)
        };
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", Jn) : Kn().catch((e => {
        console.error("Error initializing web interactives", e)
    }))
}();