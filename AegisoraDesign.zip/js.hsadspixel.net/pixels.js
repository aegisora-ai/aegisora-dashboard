! function() {
    "use strict";
    const e = "na1",
        t = {
            APP: "app",
            APP_API: "app-api"
        };

    function n(t, n) {
        const i = n && n.hubletOverride ? n.hubletOverride : t,
            o = n && !0 === n.hubletizeNa1;
        return i !== e || o ? `-${i}` : ""
    }

    function i(e, i, o) {
        if (o && o.hubletPostfixLocation && "domain" === o.hubletPostfixLocation) return i;
        i === t.APP_API && (i = t.APP);
        return `${i}${n(e,o)}`
    }

    function o(e, t, n) {
        return `${r(n)}${a(t,n)}${s(e,n)}`
    }

    function a(e, t) {
        return "qa" === (t && t.envOverride ? t.envOverride : e) ? "qa" : ""
    }

    function r(e) {
        return e && e.domainOverride ? e.domainOverride : "hubspot"
    }

    function s(e, t) {
        return t && t.hubletPostfixLocation && "domain" === t.hubletPostfixLocation ? n(e, t) : ""
    }

    function d(e) {
        return e && e.tldOverride ? e.tldOverride : "com"
    }

    function c(e) {
        return e === t.APP_API ? "/api" : ""
    }

    function l(e, t, n, a) {
        return `https://${i(t,e,a)}.${o(t,n,a)}.${d(a)}${c(e)}`
    }
    const u = "data-hsjs-portal",
        p = "data-hsjs-env",
        f = "data-hsjs-hublet",
        w = {
            PROD: "prod",
            QA: "qa"
        };

    function h(e) {
        if (!e) return null;
        const t = document.querySelectorAll(`script[${e}]`);
        return t.length ? t[0].getAttribute(e) : null
    }

    function m() {
        return h(p) || w.PROD
    }

    function g() {
        let e = h(u);
        e = parseInt(e, 10);
        if (!e) throw new Error(`HS Pixel Loader can't identify portalId via ${u}`);
        return e
    }

    function v() {
        return h(f) || e
    }

    function b() {
        return "withCredentials" in new XMLHttpRequest
    }

    function y() {
        return l("api", v(), m(), {
            domainOverride: "hubapi"
        }).split("https://")[1]
    }

    function _(e, t) {
        ! function(e, t, n, i, o, a, r) {
            if (!e.fbq) {
                o = e.fbq = function() {
                    o.callMethod ? o.callMethod.apply(o, arguments) : o.queue.push(arguments)
                };
                e._fbq || (e._fbq = o);
                o.push = o;
                o.loaded = !0;
                o.version = "2.0";
                o.queue = [];
                (a = t.createElement(n)).async = !0;
                a.src = i;
                (r = t.getElementsByTagName(n)[0]).parentNode.insertBefore(a, r)
            }
        }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
        for (var n = 0; n < e.length; n++) {
            e[n].limitedDataUseEnabled && fbq("dataProcessingOptions", ["LDU"], 0, 0);
            fbq("init", `${e[n].pixelId}`, {
                external_id: t
            });
            fbq("set", "agent", "hubspot", `${e[n].pixelId}`)
        }
        fbq("track", "PageView")
    }

    function I(e) {
        const t = document.createElement("script");
        t.async = !0;
        t.src = `https://www.googletagmanager.com/gtag/js?id=AW-${e}`;
        document.head.appendChild(t)
    }

    function E(e) {
        window.dataLayer = window.dataLayer || [];
        var t = "qa" === m() ? "dZWU5Zm" : "dZTQ1Zm";

        function n() {
            dataLayer.push(arguments)
        }
        n("js", new Date);
        n("set", "developer_id." + t, !0);
        for (var i = 0; i < e.length; i++) n("config", `AW-${e[i].pixelId}`)
    }

    function P(e) {
        for (var t = 0; t < e.length; t++) {
            const n = e[t].pixelId;
            window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
            window._linkedin_data_partner_ids.push(n)
        }! function() {
            var e = document.getElementsByTagName("script")[0],
                t = document.createElement("script");
            t.type = "text/javascript";
            t.async = !0;
            t.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
            e.parentNode.insertBefore(t, e)
        }()
    }

    function q(e) {
        ! function(t, n, i) {
            t.TiktokAnalyticsObject = i;
            var o = t[i] = t[i] || [];
            o.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie", "holdConsent", "revokeConsent", "grantConsent"], o.setAndDefer = function(e, t) {
                e[t] = function() {
                    e.push([t].concat(Array.prototype.slice.call(arguments, 0)))
                }
            };
            for (var a = 0; a < o.methods.length; a++) o.setAndDefer(o, o.methods[a]);
            o.instance = function(e) {
                for (var t = o._i[e] || [], n = 0; n < o.methods.length; n++) o.setAndDefer(t, o.methods[n]);
                return t
            }, o.load = function(e, t) {
                var n = "https://analytics.tiktok.com/i18n/pixel/events.js";
                t && t.partner;
                o._i = o._i || {}, o._i[e] = [], o._i[e]._u = n, o._t = o._t || {}, o._t[e] = +new Date, o._o = o._o || {}, o._o[e] = t || {};
                (t = document.createElement("script")).type = "text/javascript", t.async = !0, t.src = n + "?sdkid=" + e + "&lib=" + i;
                (e = document.getElementsByTagName("script")[0]).parentNode.insertBefore(t, e)
            };
            for (var r = 0; r < e.length; r++) o.load(e[r].pixelInitializer);
            o.page();
            window.ttq = o
        }(window, document, "ttq")
    }

    function A(e) {
        e.bingUetState = e.bingUetState || {
            queueNames: [],
            queueNamesByPixelInitializer: {}
        };
        return e.bingUetState
    }

    function x(e, t) {
        A(e).queueNames.forEach((e => {
            const n = window[e];
            n && "function" == typeof n.push && n.push.apply(n, t)
        }))
    }

    function S(e, t) {
        return 0 === t ? "uetq" : `uetq_${e.pixelInitializer}`
    }

    function k(e, t) {
        const n = A(t),
            i = [],
            o = {};
        e.forEach((e => {
            if (!o[e.pixelInitializer]) {
                o[e.pixelInitializer] = !0;
                i.push(e)
            }
        }));
        n.queueNames = i.map(S);
        n.queueNamesByPixelInitializer = i.reduce(((e, t, i) => {
            e[t.pixelInitializer] = n.queueNames[i];
            return e
        }), {});
        n.queueNames.forEach((e => {
            window[e] = window[e] || []
        }));
        return i
    }

    function C(e, t) {
        if (!t) return;
        const n = A(e);
        n.visitorId = t;
        n.ready && x(e, ["set", {
            vid: t
        }])
    }

    function O(e, t, n) {
        C(t, n);
        const i = k(e, t),
            o = A(t);
        ! function(e, t, n, a, r) {
            r.ts = (new Date).getTime();
            var s = t.createElement(n);
            s.src = "https://bat.bing.net/bat.js?ti=" + r.ti + ("uetq" != a ? "&q=" + a : "");
            s.async = 1;
            s.onload = s.onreadystatechange = function() {
                var t = this.readyState;
                if (!t || "loaded" === t || "complete" === t) {
                    i.forEach(((t, n) => {
                        const i = o.queueNames[n],
                            a = {
                                ti: t.pixelInitializer,
                                enableAutoSpaTracking: !0
                            };
                        if ("function" == typeof e.UET_init) e.UET_init(i, a);
                        else {
                            a.q = e[i];
                            e[i] = new e.UET(a)
                        }
                        o.adStorageConsent && e[i].push("consent", "update", {
                            ad_storage: o.adStorageConsent
                        });
                        o.visitorId && e[i].push("set", {
                            vid: o.visitorId
                        });
                        e[i].push("pageLoad")
                    }));
                    o.ready = !0;
                    s.onload = s.onreadystatechange = null
                }
            };
            var d = t.getElementsByTagName(n)[0];
            d.parentNode.insertBefore(s, d)
        }(window, document, "script", "uetq", {
            ti: i[0].pixelInitializer,
            enableAutoSpaTracking: !0
        })
    }

    function N(e, t, n, i) {
        const o = e && e.bingUetState,
            a = o ? o.queueNamesByPixelInitializer[t] : "uetq",
            r = window[a];
        r && "function" == typeof r.push && r.push("event", n, i)
    }

    function T(e) {
        ! function(e, t, n, i) {
            if (!e.oaiq) {
                var o = function e() {
                    e.q.push(arguments)
                };
                o.q = [];
                e.oaiq = o;
                var a = t.createElement(n);
                a.async = 1;
                a.src = i;
                var r = t.getElementsByTagName(n)[0];
                r.parentNode.insertBefore(a, r)
            }
        }(window, document, "script", "https://bzrcdn.openai.com/sdk/oaiq.min.js");
        for (var t = 0; t < e.length; t++) window.oaiq("init", {
            pixelId: e[t].pixelInitializer
        })
    }

    function B(e) {
        ! function(t, n) {
            if (!t.rdt) {
                var i = t.rdt = function() {
                    i.sendEvent ? i.sendEvent.apply(i, arguments) : i.callQueue.push(arguments)
                };
                i.callQueue = [];
                var o = n.createElement("script");
                o.src = `https://www.redditstatic.com/ads/pixel.js?pixel_id=${e[0].pixelId}`;
                o.async = !0;
                var a = n.getElementsByTagName("script")[0];
                a.parentNode.insertBefore(o, a)
            }
        }(window, document);
        window.rdt("init", `${e[0].pixelId}`);
        window.rdt("track", "PageVisit")
    }

    function D(e, t) {
        for (var n in e)
            if (e.hasOwnProperty(n) && Array.isArray(e[n]) && e[n].length > 0) {
                var i = e[n];
                switch (n) {
                    case "FACEBOOK":
                        if (t && !e.loadedFbPixel) {
                            _(i, t);
                            e.loadedFbPixel = !0
                        }
                        break;
                    case "ADWORDS":
                        I(i[0].pixelId);
                        E(i);
                        break;
                    case "LINKEDIN":
                        P(i);
                        break;
                    case "TIKTOK":
                        q(i);
                        break;
                    case "BING":
                        if (!e.loadedBingPixel) {
                            O(i, e, t);
                            e.loadedBingPixel = !0
                        }
                        break;
                    case "CHATGPT":
                        T(i);
                        break;
                    case "REDDIT":
                        if (!e.loadedRedditPixel) {
                            B(i);
                            e.loadedRedditPixel = !0
                        }
                }
            }
    }

    function $(e, t) {
        for (var n in e)
            if (e.hasOwnProperty(n) && Array.isArray(e[n]) && e[n].length > 0) switch (n) {
                case "FACEBOOK":
                    if (!e.loadedFbPixel) {
                        _(e[n], t);
                        e.loadedFbPixel = !0
                    }
                    break;
                case "BING":
                    C(e, t)
            }
    }

    function L(e, t) {
        for (var n in e)
            if (e.hasOwnProperty(n) && Array.isArray(e[n]) && e[n].length > 0) switch (n) {
                case "FACEBOOK":
                    fbq("consent", "grant");
                    break;
                case "ADWORDS":
                    dataLayer.push("consent", "update", {
                        ad_storage: "granted",
                        analytics_storage: "granted"
                    });
                    break;
                case "TIKTOK":
                    window.ttq && ttq.grantConsent();
                    break;
                case "BING":
                    if (e.loadedBingPixel) {
                        const t = A(e);
                        t.adStorageConsent = "granted";
                        t.ready && x(e, ["consent", "update", {
                            ad_storage: "granted"
                        }])
                    } else {
                        A(e).adStorageConsent = "granted";
                        O(e.BING, e, t);
                        e.loadedBingPixel = !0
                    }
                    break;
                case "CHATGPT":
                    "function" == typeof window.oaiq ? window.oaiq("consent", !0) : T(e.CHATGPT);
                    break;
                case "REDDIT":
                    "function" == typeof window.rdt && window.rdt("enableFirstPartyCookies")
            }
    }

    function j(e, t = (() => window.location.reload())) {
        if (e.hasOwnProperty("LINKEDIN")) t();
        else
            for (var n in e)
                if (e.hasOwnProperty(n) && Array.isArray(e[n]) && e[n].length > 0) switch (n) {
                    case "FACEBOOK":
                        fbq("consent", "revoke");
                        break;
                    case "ADWORDS":
                        dataLayer.push("consent", "update", {
                            ad_storage: "denied",
                            analytics_storage: "denied"
                        });
                        break;
                    case "TIKTOK":
                        window.ttq && ttq.revokeConsent();
                        break;
                    case "BING":
                        if (e.loadedBingPixel) {
                            const t = A(e);
                            t.adStorageConsent = "denied";
                            t.ready && x(e, ["consent", "update", {
                                ad_storage: "denied"
                            }])
                        }
                        break;
                    case "CHATGPT":
                        "function" == typeof window.oaiq && window.oaiq("consent", !1);
                        break;
                    case "REDDIT":
                        "function" == typeof window.rdt && window.rdt("disableFirstPartyCookies")
                }
    }
    const F = function(e) {
            return `https://${e}?portalId=${g()}`
        },
        G = function(e, t) {
            const n = new XMLHttpRequest;
            n.addEventListener("load", (() => {
                const e = JSON.parse(n.responseText);
                t(e)
            }));
            n.open("GET", F(e));
            n.send()
        },
        R = e => `hubspotJsonpCallbackName${e}`,
        U = function(e, t) {
            return `https://${e}?${[`portalId=${g()}`,`callback=${t}`].join("&")}`
        },
        z = function(e, t, n) {
            const i = document.createElement("script"),
                o = R(n);
            window[o] = function(e) {
                t(e);
                document.body.removeChild(i);
                delete window[o]
            };
            i.src = U(e, o);
            document.body.appendChild(i)
        };

    function K({
        jsonUrl: e,
        jsonpUrl: t
    }, n, i) {
        if (!e && !t) throw new Error("Missing jsonUrl and jsonpUrl args");
        b() ? G(e, n) : z(t, n, i)
    }
    const H = ["fbclid", "li_fat_id", "gclid", "ttclid"],
        W = /javascript\s*:/i;

    function X() {
        const e = new URL(window.location.href);
        let t = !1;
        H.forEach((n => {
            const i = e.searchParams.get(n);
            if (null !== i && W.test(i)) {
                e.searchParams.delete(n);
                console.warn(`HubSpot removed the malicious ${n} parameter`);
                t = !0
            }
        }));
        t && window.history && window.history.replaceState && window.history.replaceState(null, "", e.toString())
    }
    const M = e => e.split("_").map((e => e.charAt(0).toUpperCase() + e.slice(1).toLowerCase())).join(""),
        Q = function() {
            X();
            const e = y();
            let t, n = null,
                i = null;
            window.enabledEventSettings = {
                FACEBOOK: [],
                ADWORDS: [],
                BING: [],
                CHATGPT: []
            };
            if (!(window.disabledHsPopups && window.disabledHsPopups.indexOf("ADS") > -1)) {
                window._hsp = window._hsp || [];
                window._hsp.push(["addPrivacyConsentListener", function(t) {
                    t.categories.advertisement ? n ? L(n, i) : K({
                        jsonUrl: `${e}/hs-script-loader-public/v2/config/pixels-and-events/json`,
                        jsonpUrl: `${e}/hs-script-loader-public/v2/config/pixels-and-events/jsonp`
                    }, (e => {
                        n = e.pixels;
                        D(e.pixels, i);
                        window.enabledEventSettings = e.enhancedConversionEventSettings
                    }), "addPixels") : n && j(n)
                }]);
                window._hsq = window._hsq || [];
                window._hsq.push(["addUserTokenListener", function(e) {
                    i = e;
                    n && $(n, i)
                }]);
                window.addEventListener("hs-form-event:on-submission:success", (e => {
                    const t = HubSpotFormsV4.getFormFromEvent(e);
                    d({
                        conversionId: t.getConversionId(),
                        formGuid: t.getFormId()
                    })
                }));
                window.addEventListener("message", (e => {
                    e.data && "hsFormCallback" === e.data.type && "onFormSubmitted" === e.data.eventName && d(e.data.data)
                }), !1);
                window.addEventListener("message", (e => {
                    if (e.data && "hsCallsToActionCallback" === e.data.type && "onCallToActionFormSubmitted" === e.data.eventName) {
                        const {
                            formId: t,
                            conversionId: n
                        } = e.data.data || {};
                        t && d({
                            conversionId: n,
                            formGuid: t
                        })
                    }
                }), !1)
            }

            function o(e, t) {
                if (void 0 === window.fbq) return;
                const {
                    hubSpotFormId: n,
                    eventCategory: i
                } = e, {
                    conversionId: o,
                    formGuid: a
                } = t;
                if (a === n) {
                    const e = M(i);
                    window.fbq("track", e, {}, {
                        eventID: o
                    })
                }
            }

            function a(e, n) {
                const {
                    hubSpotFormId: i,
                    pixelId: o,
                    conversionLabel: a
                } = e, {
                    conversionId: r,
                    formGuid: s
                } = n;
                t = function() {
                    window.dataLayer.push(arguments)
                };
                s === i && null !== a && t("event", "conversion", {
                    send_to: `AW-${o}/${a}`,
                    transaction_id: r
                })
            }

            function r(e, t) {
                const {
                    hubSpotFormId: i,
                    pixelInitializer: o
                } = e, {
                    conversionId: a,
                    formGuid: r
                } = t;
                r === i && N(n, o, `hs_form_${i}`, {
                    event_id: a
                })
            }

            function s(e, t) {
                if ("function" != typeof window.oaiq) return;
                const {
                    hubSpotFormId: n,
                    pixelInitializer: i,
                    eventCategory: o,
                    conversionLabel: a
                } = e, {
                    conversionId: r,
                    formGuid: s
                } = t, d = {
                    lead_created: "customer_action",
                    registration_completed: "customer_action",
                    appointment_scheduled: "customer_action",
                    checkout_started: "contents",
                    contents_viewed: "contents",
                    items_added: "contents",
                    order_created: "contents",
                    page_viewed: "contents",
                    subscription_created: "plan_enrollment",
                    trial_started: "plan_enrollment",
                    custom: "custom"
                }[o];
                if (s !== n || !r || !d || "custom" === o && !a) return;
                const c = {
                    event_id: r
                };
                "custom" === o && (c.custom_event_name = a);
                window.oaiq("measureSingle", i, o, {
                    type: d
                }, c)
            }

            function d(e) {
                window.enabledEventSettings.FACEBOOK && window.enabledEventSettings.FACEBOOK.forEach((t => {
                    o(t, e)
                }));
                window.enabledEventSettings.ADWORDS && window.enabledEventSettings.ADWORDS.forEach((t => {
                    a(t, e)
                }));
                window.enabledEventSettings.BING && window.enabledEventSettings.BING.forEach((t => {
                    r(t, e)
                }));
                window.enabledEventSettings.CHATGPT && window.enabledEventSettings.CHATGPT.forEach((t => {
                    s(t, e)
                }))
            }
        };
    window.PIXELS_RAN = window.PIXELS_RAN || !1;
    if (!window.PIXELS_RAN) {
        window.PIXELS_RAN = !0;
        Q()
    }
}();
//# sourceMappingURL=//static.hsappstatic.net/adsscriptloaderstatic/static-1.3417/bundles/pixels-release.js.map