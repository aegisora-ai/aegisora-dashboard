var OneTrustStub = (e => {
    var G = function(e, t) {
        return (G = Object.setPrototypeOf || ({
                __proto__: []
            }
            instanceof Array ? function(e, t) {
                e.__proto__ = t
            } : function(e, t) {
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
            }))(e, t)
    };

    function t(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

        function i() {
            this.constructor = e
        }
        G(e, t), e.prototype = null === t ? Object.create(t) : (i.prototype = t.prototype, new i)
    }
    var a = function() {
        return (a = Object.assign || function(e) {
            for (var t, i = 1, n = arguments.length; i < n; i++)
                for (var s in t = arguments[i]) Object.prototype.hasOwnProperty.call(t, s) && (e[s] = t[s]);
            return e
        }).apply(this, arguments)
    };

    function M(e, a, r, l) {
        return new(r = r || Promise)(function(i, t) {
            function n(e) {
                try {
                    o(l.next(e))
                } catch (e) {
                    t(e)
                }
            }

            function s(e) {
                try {
                    o(l.throw(e))
                } catch (e) {
                    t(e)
                }
            }

            function o(e) {
                var t;
                e.done ? i(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                    e(t)
                })).then(n, s)
            }
            o((l = l.apply(e, a || [])).next())
        })
    }

    function F(n, s) {
        var o, a, r, l = {
                label: 0,
                sent: function() {
                    if (1 & r[0]) throw r[1];
                    return r[1]
                },
                trys: [],
                ops: []
            },
            c = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
        return c.next = e(0), c.throw = e(1), c.return = e(2), "function" == typeof Symbol && (c[Symbol.iterator] = function() {
            return this
        }), c;

        function e(i) {
            return function(e) {
                var t = [i, e];
                if (o) throw new TypeError("Generator is already executing.");
                for (; l = c && t[c = 0] ? 0 : l;) try {
                    if (o = 1, a && (r = 2 & t[0] ? a.return : t[0] ? a.throw || ((r = a.return) && r.call(a), 0) : a.next) && !(r = r.call(a, t[1])).done) return r;
                    switch (a = 0, (t = r ? [2 & t[0], r.value] : t)[0]) {
                        case 0:
                        case 1:
                            r = t;
                            break;
                        case 4:
                            return l.label++, {
                                value: t[1],
                                done: !1
                            };
                        case 5:
                            l.label++, a = t[1], t = [0];
                            continue;
                        case 7:
                            t = l.ops.pop(), l.trys.pop();
                            continue;
                        default:
                            if (!(r = 0 < (r = l.trys).length && r[r.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                l = 0;
                                continue
                            }
                            if (3 === t[0] && (!r || t[1] > r[0] && t[1] < r[3])) l.label = t[1];
                            else if (6 === t[0] && l.label < r[1]) l.label = r[1], r = t;
                            else {
                                if (!(r && l.label < r[2])) {
                                    r[2] && l.ops.pop(), l.trys.pop();
                                    continue
                                }
                                l.label = r[2], l.ops.push(t)
                            }
                    }
                    t = s.call(n, l)
                } catch (e) {
                    t = [6, e], a = 0
                } finally {
                    o = r = 0
                }
                if (5 & t[0]) throw t[1];
                return {
                    value: t[0] ? t[1] : void 0,
                    done: !0
                }
            }
        }
    }
    var r, i, s, o, l, u = new function() {
            this.optanonCookieName = "OptanonConsent", this.optanonHtmlGroupData = [], this.optanonHostData = [], this.genVendorsData = [], this.vendorsServiceData = [], this.IABCookieValue = "", this.oneTrustIABCookieName = "eupubconsent", this.oneTrustIsIABCrossConsentEnableParam = "isIABGlobal", this.isStubReady = !0, this.geolocationCookiesParam = "geolocation", this.EUCOUNTRIES = ["BE", "BG", "CZ", "DK", "DE", "EE", "IE", "GR", "ES", "FR", "IT", "CY", "LV", "LT", "LU", "HU", "MT", "NL", "AT", "PL", "PT", "RO", "SI", "SK", "FI", "SE", "GB", "HR", "LI", "NO", "IS"], this.stubFileName = "otSDKStub", this.DATAFILEATTRIBUTE = "data-domain-script", this.bannerScriptName = "otBannerSdk.js", this.domPurifyScriptName = "otDomPurify.js", this.mobileOnlineURL = [], this.isMigratedURL = !1, this.migratedCCTID = "[[OldCCTID]]", this.migratedDomainId = "[[NewDomainId]]", this.userLocation = {
                country: "",
                state: "",
                stateName: ""
            }
        },
        U = ((T = B = B || {})[T.Days = 1] = "Days", T[T.Weeks = 7] = "Weeks", T[T.Months = 30] = "Months", T[T.Years = 365] = "Years", (T = V = V || {}).GDPR = "GDPR", T.CCPA = "CCPA", T.IAB2 = "IAB2", T.IAB2V2 = "IAB2V2", T.GENERIC = "GENERIC", T.LGPD = "LGPD", T.GENERIC_PROMPT = "GENERIC_PROMPT", T.CPRA = "CPRA", T.CDPA = "CDPA", T.DELAWARE = "DELAWARE", T.IOWA = "IOWA", T.NEBRASKA = "NEBRASKA", T.USNATIONAL = "USNATIONAL", T.CUSTOM = "CUSTOM", T.FLORIDA = "FLORIDA", T.COLORADO = "COLORADO", T.CONNECTICUT = "CTDPA", T.MONTANA = "MONTANA", T.TEXAS = "TEXAS", T.OREGON = "OREGON", T.TENNESSEE = "TENNESSEE", T.NEWJERSEY = "NEWJERSEY", T.NEWHAMPSHIRE = "NEWHAMPSHIRE", T.UCPA = "UCPA", T.VIRGINIA = "VIRGINIA", T.MARYLAND = "MARYLAND", T.INDIANA = "INDIANA", T.KENTUCKY = "KENTUCKY", T.RHODEISLAND = "RHODEISLAND", T.MINNESOTA = "MINNESOTA", V.CCPA, V.CPRA, V.USNATIONAL, V.VIRGINIA, V.COLORADO, V.CONNECTICUT, V.UCPA, V.OREGON, V.MARYLAND, V.CDPA, V.TEXAS, V.FLORIDA, V.MONTANA, V.MINNESOTA, V.INDIANA, V.CPRA, V.CDPA, V.COLORADO, V.OREGON, V.CONNECTICUT, V.FLORIDA, V.MONTANA, V.TEXAS, V.DELAWARE, V.IOWA, V.NEBRASKA, V.TENNESSEE, V.NEWJERSEY, V.NEWHAMPSHIRE, V.UCPA, V.MARYLAND, V.INDIANA, V.KENTUCKY, V.RHODEISLAND, V.MINNESOTA, (T = R = R || {}).Name = "OTGPPConsent", T[T.ChunkSize = 4e3] = "ChunkSize", T.ChunkCountParam = "GPPCookiesCount", T.gppSid = "gppSid", (V = r = r || {}).MspaCoveredTransaction = "IsMSPAEnabled", V.MspaOptOutOptionMode = "Opt-Out", V.MspaServiceProviderMode = "Service Provider", (T = i = i || {}).GpcSegmentType = "GpcSegmentType", T.Gpc = "Gpc", (V = s = s || {}).SensitiveDataProcessing = "SensitiveDataProcessing", V.KnownChildSensitiveDataConsents = "KnownChildSensitiveDataConsents", (T = o = o || {}).CPRA = "usca", T.CCPA = "usca", T.CDPA = "usva", T.OREGON = "usor", T.USNATIONAL = "usnat", T.COLORADO = "usco", T.FLORIDA = "usfl", T.CTDPA = "usct", T.MONTANA = "usmt", T.TEXAS = "ustx", T.DELAWARE = "usde", T.IOWA = "usia", T.NEBRASKA = "usne", T.TENNESSEE = "ustn", T.NEWJERSEY = "usnj", T.NEWHAMPSHIRE = "usnh", T.UCPA = "usut", T.VIRGINIA = "usva", T.MARYLAND = "usmd", T.INDIANA = "usin", T.KENTUCKY = "usky", T.RHODEISLAND = "usri", T.MINNESOTA = "usmn", T.IAB2V2 = "tcfeuv2", T.USPV1 = "uspv1", (V = l = l || {})[V.CPRA = 8] = "CPRA", V[V.CCPA = 8] = "CCPA", V[V.CDPA = 9] = "CDPA", V[V.OREGON = 15] = "OREGON", V[V.USNATIONAL = 7] = "USNATIONAL", V[V.COLORADO = 10] = "COLORADO", V[V.FLORIDA = 13] = "FLORIDA", V[V.MONTANA = 14] = "MONTANA", V[V.TEXAS = 16] = "TEXAS", V[V.DELAWARE = 17] = "DELAWARE", V[V.IOWA = 18] = "IOWA", V[V.NEBRASKA = 19] = "NEBRASKA", V[V.NEWHAMPSHIRE = 20] = "NEWHAMPSHIRE", V[V.NEWJERSEY = 21] = "NEWJERSEY", V[V.TENNESSEE = 22] = "TENNESSEE", V[V.UCPA = 11] = "UCPA", V[V.VIRGINIA = 9] = "VIRGINIA", V[V.CTDPA = 12] = "CTDPA", V[V.MARYLAND = 24] = "MARYLAND", V[V.INDIANA = 25] = "INDIANA", V[V.KENTUCKY = 26] = "KENTUCKY", V[V.RHODEISLAND = 27] = "RHODEISLAND", V[V.MINNESOTA = 23] = "MINNESOTA", V[V.IAB2V2 = 2] = "IAB2V2", V[V.USPV1 = 6] = "USPV1", "geo"),
        H = "browserGpcFlag",
        k = "otpreview",
        _ = (R.Name, "LOCAL"),
        x = "PRODUCTION",
        j = (0, B.Days, B.Weeks, B.Months, B.Years, n.prototype.camelize = function(e) {
            return (e = e.replace("--", "")).split("-").map(function(e, t) {
                var i = e ? e[0].toUpperCase() + e.slice(1) : "";
                return 0 === t ? e : i
            }).join("")
        }, n.prototype.strToObj = function(e) {
            for (var t = {}, i = e.split(";").map(function(e) {
                    return e.trim()
                }), n = 0, s = void 0; n < i.length; ++n)
                if (/:/.test(i[n])) {
                    if (!(s = i[n].split(/:(.+)/))[1]) return null;
                    t[this.camelize(s[0])] = s[1].trim()
                }
            return t
        }, n);

    function n() {
        var e = this;
        this.implementThePolyfill = function() {
            var s = e,
                o = Element.prototype.setAttribute;
            return Element.prototype.setAttribute = function(e, t) {
                if ("style" !== ("string" == typeof e ? e.toLowerCase() : "")) o.apply(this, [e, t]);
                else if (null == this.style) o.apply(this, [e, t]);
                else if (t) {
                    this.removeAttribute("style");
                    var i, n = s.strToObj(t);
                    for (i in n) this.style[i] = n[i]
                } else this.removeAttribute("style")
            }, !0
        }
    }

    function W(e, t, i) {
        void 0 === i && (i = !1);

        function n(e) {
            return e ? (";" !== (e = e.trim()).charAt(e.length - 1) && (e += ";"), e.trim()) : null
        }
        var o = n(e.getAttribute("style")),
            a = n(t),
            t = "",
            t = i && o ? (() => {
                for (var e = o.split(";").concat(a.split(";")).filter(function(e) {
                        return 0 !== e.length
                    }), t = "", i = "", n = e.length - 1; 0 <= n; n--) {
                    var s = e[n].substring(0, e[n].indexOf(":") + 1).trim();
                    t.indexOf(s) < 0 && (t += s, i += e[n] + ";")
                }
                return i
            })() : a;
        e.setAttribute("style", t)
    }
    var c, d, p, D, g, C, h, I, S, v, O, A, P, m, f, q, Y, J, z, Q, X, Z, $, ee, te, ie, ne, se, oe, ae, re, le, ce, ue, de, pe, De, ge, Ce, he, Ie, Se, ve, Oe, Ae, Pe, me, fe, Te, we, ye, be, Ne, Re, Ee, Le, Be, Ke, Ve, Ge, Me, Fe, Ue, He, ke, _e, xe, je, We, qe, Ye, Je, ze, Qe, Xe, Ze, $e, et, tt, it, nt, st, ot, at, rt, lt, ct, ut, dt, pt, Dt, gt, Ct, ht, It, St, vt = new function() {},
        T = ((T = c = c || {}).SaleOptOut = "SaleOptOutCID", T.SharingOptOut = "SharingOptOutCID", T.PersonalDataConsents = "PersonalDataCID", (V = d = d || {}).SharingOptOutNotice = "SharingOptOutCID", V.SaleOptOutNotice = "SaleOptOutCID", V.SensitiveDataLimitUseNotice = "SensitivePICID || SensitiveSICID || GeolocationCID || RREPInfoCID || CommunicationCID || GeneticCID|| BiometricCID || HealthCID || SexualOrientationCID", (R = p = p || {}).KnownChildSensitiveDataConsents1 = "KnownChildSellPICID", R.KnownChildSensitiveDataConsents2 = "KnownChildSharePICID", (B = D = D || {}).SensitiveDataProcessing1 = "SensitivePICID", B.SensitiveDataProcessing2 = "SensitiveSICID", B.SensitiveDataProcessing3 = "GeolocationCID", B.SensitiveDataProcessing4 = "RREPInfoCID", B.SensitiveDataProcessing5 = "CommunicationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "HealthCID", B.SensitiveDataProcessing9 = "SexualOrientationCID", 0, w.prototype.getFieldsValues = function(e, t, i, n, s, o) {
            void 0 === s && (s = !1), void 0 === o && (o = !1);
            e = this.getSectionFieldsMapping(e), t = this.getSectionFieldsMapping(t, !0), i = this.getDynamicFields(i, n), n = o ? this.getMSPAModeFieldValue() : this.getMSPASectionFieldValue(), o = s ? this.getGpcSectionFieldValue() : {};
            return y.IsMSPAEnabled && y.MSPAOptionMode === r.MspaServiceProviderMode && vt.fp.CookieIABGPPV2 ? this.serviceProviderMode(e, t, i, n, o) : a(a(a(a(a({}, e), t), i), n), o)
        }, w.prototype.serviceProviderMode = function(e, t, i, n, s) {
            e = this.getNotApplicableValue(e), t = this.getNotApplicableValue(t), i = this.getNotApplicableValue(i);
            return a(a(a(a(a({}, e), t), i), n), s)
        }, w.prototype.getNotApplicableValue = function(e) {
            var i = {};
            return Object.entries(e).forEach(function(e) {
                var t = e[0],
                    e = e[1];
                Array.isArray(e) ? i[t] = e.map(function(e) {
                    return 0
                }) : i[t] = 0
            }), i
        }, w.prototype.getGpcSectionFieldValue = function() {
            var e = {};
            return e[i.GpcSegmentType] = 1, e[i.Gpc] = (void 0).gpcEnabled, e
        }, w.prototype.getMSPAModeFieldValue = function() {
            var e = {};
            return y.IsMSPAEnabled ? (e.MspaVersion = 1, e.MspaCoveredTransaction = 1, y.MSPAOptionMode === r.MspaServiceProviderMode ? e.MspaMode = 2 : y.MSPAOptionMode === r.MspaOptOutOptionMode ? e.MspaMode = 1 : e.MspaMode = 0) : (e.MspaCoveredTransaction = 2, e.MspaMode = 0), e
        }, w.prototype.getMSPASectionFieldValue = function() {
            var e = {};
            return y.IsMSPAEnabled ? (e.MspaCoveredTransaction = 1, y.MSPAOptionMode === r.MspaServiceProviderMode ? (e.MspaServiceProviderMode = 1, e.MspaOptOutOptionMode = 2) : y.MSPAOptionMode === r.MspaOptOutOptionMode ? (e.MspaServiceProviderMode = 2, e.MspaOptOutOptionMode = 1) : (e.MspaServiceProviderMode = 2, e.MspaOptOutOptionMode = 2)) : (e.MspaCoveredTransaction = 2, e.MspaServiceProviderMode = 0, e.MspaOptOutOptionMode = 0), e
        }, w.prototype.getDynamicArrayFieldsValue = function(e, t) {
            for (var i = {}, n = [], s = this.getSectionFieldsMapping(t), o = 1; o <= Object.keys(s).length; o++) n.push(s[e + o]);
            return i[e] = n, i
        }, w.prototype.getDynamicFields = function(e, t) {
            var i, n = {};
            return y.IsGPPKnownChildApplicable && e && (i = this.getDynamicArrayFieldsValue(s.KnownChildSensitiveDataConsents, e), n = a(a({}, n), i)), y.IsGPPDataProcessingApplicable && t && (i = this.getDynamicArrayFieldsValue(s.SensitiveDataProcessing, t), n = a(a({}, n), i)), n
        }, w.prototype.getSectionFieldsMapping = function(e, i) {
            var n = this,
                s = (void 0 === i && (i = !1), {});
            return vt.fp, Object.entries(e).forEach(function(e) {
                var t = e[0],
                    e = n.evaluateValueOperators(e[1]);
                s[t] = n.calculateFieldValue(e, i)
            }), s
        }, w.prototype.evaluateValueOperators = function(e) {
            var t, i, n = "",
                s = [];
            return e && (t = e.split(" && "), i = e.split(" || "), s = (1 < t.length ? (n = "&&", t) : 1 < i.length ? (n = "||", i) : (n = "", [e])).map(function(e) {
                return y.GPPPurposes[e] || ""
            })), {
                values: s,
                operator: n
            }
        }, w.prototype.calculateFieldValue = function(e, t) {
            var i;
            if (e.values.length) switch (e.operator) {
                case "&&":
                    i = this.calculateAndFieldValue(e.values, t);
                    break;
                case "||":
                    i = this.calculateOrFieldValue(e.values, t);
                    break;
                default:
                    i = this.calculateSingleFieldValue(e.values[0], t)
            } else i = 0;
            return i
        }, w.prototype.calculateOrFieldValue = function(e, t) {
            var i = this;
            return this.isNotApplicable(e) ? 0 : (e = e.filter(function(e) {
                return "" !== e.trim()
            }).some(function(e) {
                return i.fieldValueCondition(e, t)
            }), this.calculateFieldValueFromBit(e, t))
        }, w.prototype.calculateAndFieldValue = function(e, t) {
            var i = this;
            return this.isNotApplicable(e) ? 0 : (e = e.every(function(e) {
                return i.fieldValueCondition(e, t)
            }), this.calculateFieldValueFromBit(e, t))
        }, w.prototype.calculateSingleFieldValue = function(e, t) {
            return e && _t(e) ? (e = this.fieldValueCondition(e, t), this.calculateFieldValueFromBit(e, t)) : 0
        }, w.prototype.calculateFieldValueFromBit = function(e, t) {
            t = t ? e ? 1 : 0 : e ? 2 : 1;
            return t
        }, w.prototype.isNotApplicable = function(e) {
            return !e.some(function(e) {
                return Boolean(e) && _t(e)
            })
        }, w.prototype.fieldValueCondition = function(e, t) {
            return t ? Boolean(e) : (void 0).isCategoryActive(e)
        }, w);

    function w() {}

    function Ot() {
        return null !== g && g.apply(this, arguments) || this
    }

    function At() {
        return null !== S && S.apply(this, arguments) || this
    }

    function Pt() {
        return null !== m && m.apply(this, arguments) || this
    }

    function mt() {
        return null !== J && J.apply(this, arguments) || this
    }

    function ft() {
        return null !== $ && $.apply(this, arguments) || this
    }

    function Tt() {
        return null !== se && se.apply(this, arguments) || this
    }

    function wt() {
        return null !== le && le.apply(this, arguments) || this
    }

    function yt() {
        return null !== De && De.apply(this, arguments) || this
    }

    function bt() {
        return null !== Se && Se.apply(this, arguments) || this
    }

    function Nt() {
        return null !== Pe && Pe.apply(this, arguments) || this
    }

    function Rt() {
        return null !== we && we.apply(this, arguments) || this
    }

    function Et() {
        return null !== Re && Re.apply(this, arguments) || this
    }

    function Lt() {
        return null !== Ve && Ve.apply(this, arguments) || this
    }

    function Bt() {
        return null !== He && He.apply(this, arguments) || this
    }

    function Kt() {
        return null !== je && je.apply(this, arguments) || this
    }

    function Vt() {
        return null !== Je && Je.apply(this, arguments) || this
    }

    function Gt() {
        return null !== Xe && Xe.apply(this, arguments) || this
    }

    function Mt() {
        return null !== tt && tt.apply(this, arguments) || this
    }

    function Ft() {
        return null !== ot && ot.apply(this, arguments) || this
    }

    function Ut() {
        return null !== ct && ct.apply(this, arguments) || this
    }

    function Ht() {
        return null !== Dt && Dt.apply(this, arguments) || this
    }

    function kt() {
        return null !== St && St.apply(this, arguments) || this
    }
    t(Ot, g = T), Ot.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(c, d, p, D, !0)
    }, (V = C = C || {}).SaleOptOut = "SaleOptOutCID", V.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (R = h = h || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = I = I || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", t(At, S = T), At.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(C, h, null, I, !1)
    }, (V = v = v || {}).SaleOptOut = "SaleOptOutCID", V.SharingOptOut = "SharingOptOutCID", V.PersonalDataConsents = "PersonalDataCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (R = O = O || {}).SharingNotice = "SharingOptOutCID", R.SaleOptOutNotice = "SaleOptOutCID", R.SharingOptOutNotice = "SharingOptOutCID", R.SensitiveDataProcessingOptOutNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID || SensitivePICID || SensitiveSICID || UnionMembershipCID || CommunicationCID || ConsumerHealthCID || CrimeVictimCID || NationalOriginCID || TransgenderCID", R.SensitiveDataLimitUseNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID || SensitivePICID || SensitiveSICID || UnionMembershipCID || CommunicationCID || ConsumerHealthCID || CrimeVictimCID || NationalOriginCID || TransgenderCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = A = A || {}).KnownChildSensitiveDataConsents1 = "PDCAboveAgeCID", B.KnownChildSensitiveDataConsents2 = "PDCBelowAgeCID", B.KnownChildSensitiveDataConsents3 = "KnownChildProcessAge16To17CID", (V = P = P || {}).SensitiveDataProcessing1 = "RaceCID", V.SensitiveDataProcessing2 = "ReligionCID", V.SensitiveDataProcessing3 = "HealthCID", V.SensitiveDataProcessing4 = "SexualOrientationCID", V.SensitiveDataProcessing5 = "ImmigrationCID", V.SensitiveDataProcessing6 = "GeneticCID", V.SensitiveDataProcessing7 = "BiometricCID", V.SensitiveDataProcessing8 = "GeolocationCID", V.SensitiveDataProcessing9 = "SensitivePICID", V.SensitiveDataProcessing10 = "SensitiveSICID", V.SensitiveDataProcessing11 = "UnionMembershipCID", V.SensitiveDataProcessing12 = "CommunicationCID", V.SensitiveDataProcessing13 = "ConsumerHealthCID", V.SensitiveDataProcessing14 = "CrimeVictimCID", V.SensitiveDataProcessing15 = "NationalOriginCID", V.SensitiveDataProcessing16 = "TransgenderCID", t(Pt, m = T), Pt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(v, O, A, P, !0)
    }, (R = f = f || {}).SaleOptOut = "SaleOptOutCID", R.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", R.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (B = q = q || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (V = Y = Y || {}).SensitiveDataProcessing1 = "RaceCID", V.SensitiveDataProcessing2 = "ReligionCID", V.SensitiveDataProcessing3 = "HealthCID", V.SensitiveDataProcessing4 = "SexualOrientationCID", V.SensitiveDataProcessing5 = "ImmigrationCID", V.SensitiveDataProcessing6 = "GeneticCID", V.SensitiveDataProcessing7 = "BiometricCID", t(mt, J = T), mt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(f, q, null, Y, !0)
    }, (R = z = z || {}).SaleOptOut = "SaleOptOutCID", R.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (B = Q = Q || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (V = X = X || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", V.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", V.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (R = Z = Z || {}).SensitiveDataProcessing1 = "RaceCID", R.SensitiveDataProcessing2 = "ReligionCID", R.SensitiveDataProcessing3 = "HealthCID", R.SensitiveDataProcessing4 = "SexualOrientationCID", R.SensitiveDataProcessing5 = "ImmigrationCID", R.SensitiveDataProcessing6 = "GeneticCID", R.SensitiveDataProcessing7 = "BiometricCID", R.SensitiveDataProcessing8 = "GeolocationCID", t(ft, $ = T), ft.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(z, Q, X, Z, !0)
    }, (B = ee = ee || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", B.AdditionalDataProcessingConsent = "PersonalDataCID", (V = te = te || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", V.SaleOptOutNotice = "SaleOptOutCID", V.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (R = ie = ie || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", R.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", R.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (B = ne = ne || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", t(Tt, se = T), Tt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ee, te, ie, ne, !0)
    }, (V = oe = oe || {}).SaleOptOut = "SaleOptOutCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", V.AdditionalDataProcessingConsent = "PersonalDataCID", V.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (R = ae = ae || {}).ProcessingNotice = "PersonalDataCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = re = re || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", t(wt, le = T), wt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(oe, ae, null, re, !0)
    }, (V = ce = ce || {}).SaleOptOut = "SaleOptOutCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (R = ue = ue || {}).ProcessingNotice = V.AdditionalDataProcessingConsent = "PersonalDataCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = de = de || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessBelowAge13CID", B.KnownChildSensitiveDataConsents2 = "KnownChildProcessBetweenAge13To16CID", B.KnownChildSensitiveDataConsents3 = "KnownChildProcessBetweenAge16To18CID", (V = pe = pe || {}).SensitiveDataProcessing1 = "RaceCID", V.SensitiveDataProcessing2 = "ReligionCID", V.SensitiveDataProcessing3 = "HealthCID", V.SensitiveDataProcessing4 = "SexualOrientationCID", V.SensitiveDataProcessing5 = "ImmigrationCID", V.SensitiveDataProcessing6 = "GeneticCID", V.SensitiveDataProcessing7 = "BiometricCID", V.SensitiveDataProcessing8 = "GeolocationCID", t(yt, De = T), yt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ce, ue, de, pe, !1)
    }, (R = ge = ge || {}).SaleOptOut = "SaleOptOutCID", R.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (B = Ce = Ce || {}).ProcessingNotice = R.AdditionalDataProcessingConsent = "PersonalDataCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (V = he = he || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", V.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", V.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", V.KnownChildSensitiveDataConsents4 = "KnownChildSellAge16To18CID", V.KnownChildSensitiveDataConsents5 = "KnownChildProcessAge16To18CID", (R = Ie = Ie || {}).SensitiveDataProcessing1 = "RaceCID", R.SensitiveDataProcessing2 = "ReligionCID", R.SensitiveDataProcessing3 = "HealthCID", R.SensitiveDataProcessing4 = "SexualOrientationCID", R.SensitiveDataProcessing5 = "ImmigrationCID", R.SensitiveDataProcessing6 = "GeneticCID", R.SensitiveDataProcessing7 = "BiometricCID", R.SensitiveDataProcessing8 = "GeolocationCID", R.SensitiveDataProcessing9 = "TransgenderCID", t(bt, Se = T), bt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ge, Ce, he, Ie, !0)
    }, (B = ve = ve || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", B.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (V = Oe = Oe || {}).ProcessingNotice = "AdditionalDataCID", V.SaleOptOutNotice = "SaleOptOutCID", V.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", V.SensitiveDataOptOutNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID", (R = Ae = Ae || {}).SensitiveDataProcessing1 = "RaceCID", R.SensitiveDataProcessing2 = "ReligionCID", R.SensitiveDataProcessing3 = "HealthCID", R.SensitiveDataProcessing4 = "SexualOrientationCID", R.SensitiveDataProcessing5 = "ImmigrationCID", R.SensitiveDataProcessing6 = "GeneticCID", R.SensitiveDataProcessing7 = "BiometricCID", R.SensitiveDataProcessing8 = "GeolocationCID", t(Nt, Pe = T), Nt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ve, Oe, null, Ae, !0)
    }, (B = me = me || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", B.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (V = fe = fe || {}).ProcessingNotice = B.AdditionalDataProcessingConsent = "PersonalDataCID", V.SaleOptOutNotice = "SaleOptOutCID", V.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (R = Te = Te || {}).SensitiveDataProcessing1 = "RaceCID", R.SensitiveDataProcessing2 = "ReligionCID", R.SensitiveDataProcessing3 = "HealthCID", R.SensitiveDataProcessing4 = "SexualOrientationCID", R.SensitiveDataProcessing5 = "ImmigrationCID", R.SensitiveDataProcessing6 = "GeneticCID", R.SensitiveDataProcessing7 = "BiometricCID", R.SensitiveDataProcessing8 = "GeolocationCID", t(Rt, we = T), Rt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(me, fe, null, Te, !0)
    }, (B = ye = ye || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", B.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (V = be = be || {}).ProcessingNotice = B.AdditionalDataProcessingConsent = "PersonalDataCID", V.SaleOptOutNotice = "SaleOptOutCID", V.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (R = Ne = Ne || {}).SensitiveDataProcessing1 = "RaceCID", R.SensitiveDataProcessing2 = "ReligionCID", R.SensitiveDataProcessing3 = "HealthCID", R.SensitiveDataProcessing4 = "SexualOrientationCID", R.SensitiveDataProcessing5 = "ImmigrationCID", R.SensitiveDataProcessing6 = "GeneticCID", R.SensitiveDataProcessing7 = "BiometricCID", R.SensitiveDataProcessing8 = "GeolocationCID", t(Et, Re = T), Et.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ye, be, null, Ne, !0)
    }, (B = Ee = Ee || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (V = Le = Le || {}).ProcessingNotice = B.AdditionalDataProcessingConsent = "PersonalDataCID", V.SaleOptOutNotice = "SaleOptOutCID", V.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (R = Be = Be || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", R.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", R.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", R.KnownChildSensitiveDataConsents4 = "KnownChildSellAge16To17CID", R.KnownChildSensitiveDataConsents5 = "KnownChildProcessAge16To17CID", (B = Ke = Ke || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", B.SensitiveDataProcessing9 = "TransgenderCID", B.SensitiveDataProcessing10 = "SensitiveSICID", t(Lt, Ve = T), Lt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ee, Le, Be, Ke, !0)
    }, (V = Ge = Ge || {}).SaleOptOut = "SaleOptOutCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (R = Me = Me || {}).ProcessingNotice = V.AdditionalDataProcessingConsent = "PersonalDataCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = Fe = Fe || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", B.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", B.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (V = Ue = Ue || {}).SensitiveDataProcessing1 = "RaceCID", V.SensitiveDataProcessing2 = "ReligionCID", V.SensitiveDataProcessing3 = "HealthCID", V.SensitiveDataProcessing4 = "SexualOrientationCID", V.SensitiveDataProcessing5 = "ImmigrationCID", V.SensitiveDataProcessing6 = "GeneticCID", V.SensitiveDataProcessing7 = "BiometricCID", V.SensitiveDataProcessing8 = "GeolocationCID", t(Bt, He = T), Bt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ge, Me, Fe, Ue, !0)
    }, (R = ke = ke || {}).SaleOptOut = "SaleOptOutCID", R.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", R.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (B = _e = _e || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (V = xe = xe || {}).SensitiveDataProcessing1 = "RaceCID", V.SensitiveDataProcessing2 = "ReligionCID", V.SensitiveDataProcessing3 = "SexualOrientationCID", V.SensitiveDataProcessing4 = "ImmigrationCID", V.SensitiveDataProcessing5 = "HealthCID", V.SensitiveDataProcessing6 = "GeneticCID", V.SensitiveDataProcessing7 = "BiometricCID", V.SensitiveDataProcessing8 = "GeolocationCID", t(Kt, je = T), Kt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ke, _e, null, xe, !1)
    }, (R = We = We || {}).SaleOptOut = "SaleOptOutCID", R.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", R.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (B = qe = qe || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", B.SensitiveDataProcessingOptOutNotice = "RaceCID || ReligionCID || SexualOrientationCID || ImmigrationCID || HealthCID || GeneticCID || BiometricCID || GeolocationCID", (V = Ye = Ye || {}).SensitiveDataProcessing1 = "RaceCID", V.SensitiveDataProcessing2 = "ReligionCID", V.SensitiveDataProcessing3 = "SexualOrientationCID", V.SensitiveDataProcessing4 = "ImmigrationCID", V.SensitiveDataProcessing5 = "HealthCID", V.SensitiveDataProcessing6 = "GeneticCID", V.SensitiveDataProcessing7 = "BiometricCID", V.SensitiveDataProcessing8 = "GeolocationCID", t(Vt, Je = T), Vt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(We, qe, null, Ye, !1)
    }, (R = ze = ze || {}).SaleOptOut = "SaleOptOutCID", R.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (B = Qe = Qe || {}).ProcessingNotice = R.AdditionalDataProcessingConsent = "PersonalDataCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", t(Gt, Xe = T), Gt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ze, Qe, null, null, !0, !0)
    }, (V = Ze = Ze || {}).SaleOptOut = "SaleOptOutCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", V.AdditionalDataProcessingConsent = "PersonalDataCID", V.KnownChildSensitiveDataConsents = "KnownChildSellPICID", (R = $e = $e || {}).ProcessingNotice = "PersonalDataCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = et = et || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", t(Mt, tt = T), Mt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ze, $e, null, et, !1, !0)
    }, (V = it = it || {}).SaleOptOut = "SaleOptOutCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", V.AdditionalDataProcessingConsent = "PersonalDataCID", V.KnownChildSensitiveDataConsents = "KnownChildSellPICID", (R = nt = nt || {}).ProcessingNotice = "PersonalDataCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = st = st || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", t(Ft, ot = T), Ft.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(it, nt, null, st, !1, !0)
    }, (V = at = at || {}).SaleOptOut = "SaleOptOutCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", V.AdditionalDataProcessingConsent = "PersonalDataCID", V.KnownChildSensitiveDataConsents = "KnownChildSellPICID", (R = rt = rt || {}).ProcessingNotice = "PersonalDataCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = lt = lt || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", t(Ut, ct = T), Ut.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(at, rt, null, lt, !1, !0)
    }, (V = ut = ut || {}).SaleOptOut = "SaleOptOutCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", V.AdditionalDataProcessingConsent = "PersonalDataCID", V.KnownChildSensitiveDataConsents = "KnownChildSellPICID", (R = dt = dt || {}).ProcessingNotice = "PersonalDataCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = pt = pt || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", t(Ht, Dt = T), Ht.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ut, dt, null, pt, !0)
    }, (V = gt = gt || {}).SaleOptOut = "SaleOptOutCID", V.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (R = Ct = Ct || {}).ProcessingNotice = V.AdditionalDataProcessingConsent = "PersonalDataCID", R.SaleOptOutNotice = "SaleOptOutCID", R.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = ht = ht || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", B.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", B.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (V = It = It || {}).SensitiveDataProcessing1 = "RaceCID", V.SensitiveDataProcessing2 = "ReligionCID", V.SensitiveDataProcessing3 = "HealthCID", V.SensitiveDataProcessing4 = "SexualOrientationCID", V.SensitiveDataProcessing5 = "TransgenderCID", V.SensitiveDataProcessing6 = "ImmigrationCID", V.SensitiveDataProcessing7 = "NationalOriginCID", V.SensitiveDataProcessing8 = "CrimeVictimCID", V.SensitiveDataProcessing9 = "GeneticCID", V.SensitiveDataProcessing10 = "BiometricCID", V.SensitiveDataProcessing11 = "GeolocationCID", t(kt, St = T), kt.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(gt, Ct, ht, It, !0)
    };
    var y = {};

    function b() {
        this.otSDKVersion = "202610.1.0", this.isAMP = !1, this.ampData = {}, this.otCookieData = window.OneTrust && window.OneTrust.otCookieData || [], this.syncRequired = !1, this.isIabSynced = !1, this.isGacSynced = !1, this.grpsSynced = [], this.syncedValidGrp = !1, this.groupsConsent = [], this.initialGroupsConsent = [], this.hostsConsent = [], this.initialHostConsent = [], this.genVendorsConsent = {}, this.vsConsent = new Map, this.initialGenVendorsConsent = {}, this.vendors = {
            list: [],
            searchParam: "",
            vendorTemplate: null,
            selectedVendors: [],
            selectedPurpose: [],
            selectedLegInt: [],
            selectedLegIntVendors: [],
            selectedSpecialFeatures: []
        }, this.initialVendors = {
            list: [],
            searchParam: "",
            vendorTemplate: null,
            selectedVendors: [],
            selectedPurpose: [],
            selectedLegInt: [],
            selectedLegIntVendors: [],
            selectedSpecialFeatures: []
        }, this.oneTrustIABConsent = {
            purpose: [],
            legimateInterest: [],
            features: [],
            specialFeatures: [],
            specialPurposes: [],
            vendors: [],
            legIntVendors: [],
            vendorList: null,
            IABCookieValue: ""
        }, this.initialOneTrustIABConsent = {
            purpose: [],
            legimateInterest: [],
            features: [],
            specialFeatures: [],
            specialPurposes: [],
            vendors: [],
            legIntVendors: [],
            vendorList: null,
            IABCookieValue: ""
        }, this.addtlVendors = {
            vendorConsent: [],
            vendorSelected: {}
        }, this.initialAddtlVendors = {
            vendorConsent: [],
            vendorSelected: {}
        }, this.addtlConsentVersion = "2~", this.deletedGoogleVendors = {}, this.initialAddtlVendorsList = {}, this.isAddtlConsent = !1, this.currentGlobalFilteredList = [], this.filterByIABCategories = [], this.filterByCategories = [], this.hosts = {
            hostTemplate: null,
            hostCookieTemplate: null
        }, this.generalVendors = {
            gvTemplate: null,
            gvCookieTemplate: null
        }, this.oneTrustAlwaysActiveHosts = [], this.alwaysActiveGenVendors = [], this.softOptInGenVendors = [], this.optInGenVendors = [], this.optanonHostList = [], this.srcExecGrps = [], this.htmlExecGrps = [], this.srcExecGrpsTemp = [], this.htmlExecGrpsTemp = [], this.isPCVisible = !1, this.wasBannerVisible = !1, this.pcClosedFromCloseBtn = !1, this.dataGroupState = [], this.makeInitialTxnCall = !1, this.userLocation = {
            country: "",
            state: "",
            stateName: ""
        }, this.vendorsSetting = {}, this.dsParams = {}, this.noConsentGrps = [], this.isV2Stub = !1, this.fireOnetrustGrp = !1, this.showVendorService = !1, this.showGeneralVendors = !1, this.genVenOptOutEnabled = !1, this.gpcConsentTxn = !1, this.dntConsentTxn = !1, this.vsIsActiveAndOptOut = !1, this.bAsset = {}, this.pcAsset = {}, this.csBtnAsset = {}, this.ccpaIconAsset = {}, this.cStyles = {}, this.vendorDomInit = !1, this.genVendorDomInit = !1, this.syncNtfyContent = {}, this.ntfyRequired = !1, this.skipAddingHTML = !1, this.bnrAnimationInProg = !1, this.isPreview = !1, this.geoFromUrl = "", this.hideBanner = !1, this.setAttributePolyfillIsActive = !1, this.storageBaseURL = "", this.isKeyboardUser = !1, this.isBotHeader = !1, this.isBotHeaderDomain = !1, this.customerStyles = new Map, this.showTrackingTech = !1, this.currentTrackingTech = {}
    }
    b.prototype.getVendorsInDomain = function() {
        var e, t;
        return E._vendorsInDomain || (e = new Map, t = null != (t = y.Groups) ? t : [], E.setVendorServicesMap(t, e), E._vendorsInDomain = e), E._vendorsInDomain
    }, b.prototype.setVendorServicesMap = function(e, t) {
        for (var i, n = 0, s = e; n < s.length; n++) {
            var o = s[n];
            o.SubGroups && 0 < o.SubGroups.length && E.setVendorServicesMap(o.SubGroups, t);
            for (var a = 0, r = null != (i = o.VendorServices) ? i : []; a < r.length; a++) {
                var l = r[a],
                    c = Object.assign({}, o);
                delete c.VendorServices, l.groupRef = c, t.set(l.CustomVendorServiceId, l)
            }
        }
    }, b.prototype.clearVendorsInDomain = function() {
        E._vendorsInDomain = null
    }, b.prototype.checkVendorConsent = function(e) {
        return E.vendorsSetting[e] && E.vendorsSetting[e].consent
    };
    var N, R, E = new b,
        _t = function(e) {
            e = e ? (void 0).getGroupById(e) : null;
            return !!e && Boolean((void 0).isValidConsentNoticeGroup(e, y.IsIabEnabled))
        },
        xt = ((R = N = N || {}).ping = "ping", R.addEventListener = "addEventListener", R.removeEventListener = "removeEventListener", R.hasSection = "hasSection", R.getSection = "getSection", R.getField = "getField", R.getGPPData = "getGPPData", new function() {
            var a = this;
            this.LOCATOR_NAME = "__gppLocator", this.win = window, this.customInit = "CUSTOMINIT", this.init = function() {
                a.win.__gpp && "function" == typeof a.win.__gpp || (a.win.__gpp = a.executeGppApi, window.addEventListener("message", a.messageHandler, !1), a.addFrame(a.LOCATOR_NAME))
            }, this.removeGppApi = function() {
                delete a.win.__gpp;
                var e = document.querySelectorAll("iframe[name=" + a.LOCATOR_NAME + "]")[0];
                e && e.parentElement.removeChild(e)
            }, this.executeGppApi = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                var i = null == (i = a.win) ? void 0 : i.__gpp;
                if (i.queue = i.queue || [], i.events = i.events || [], !e.length || 1 === e.length && "queue" === e[0]) return i.queue;
                if (1 === e.length && "events" === e[0]) return i.events;
                var n = e[0],
                    s = 1 < e.length ? e[1] : null,
                    o = 2 < e.length ? e[2] : null;
                switch (n) {
                    case N.ping:
                        return a.getPingRequest(s);
                    case N.addEventListener:
                        return a.addEventListener(s, o);
                    case N.removeEventListener:
                        return a.removeEventListener(o);
                    default:
                        return void a.addToQueue(n, s, o)
                }
            }, this.getPingRequest = function(e) {
                var i, n, t = {
                    gppVersion: 1.1,
                    cmpStatus: "stub",
                    cmpDisplayStatus: "hidden",
                    signalStatus: "not ready",
                    supportedAPIs: (i = [], n = {}, Object.keys(l).forEach(function(e) {
                        var t = {},
                            e = (t[e] = l[e], Object.assign(t, n));
                        n = e
                    }), Object.keys(o).map(function(e) {
                        return {
                            name: e,
                            value: o[e]
                        }
                    }).forEach(function(e) {
                        e = n[e.name] + ":" + e.value;
                        i.push(e)
                    }), i.filter(function(e, t) {
                        return i.indexOf(e) === t
                    })),
                    currentAPI: "",
                    cmpId: Number.parseInt("28"),
                    sectionList: [],
                    applicableSections: [0],
                    gppString: "",
                    parsedSections: {}
                };
                return e && e(t, !0), t
            }, this.addFrame = function(e) {
                var t, i = a.win.document,
                    n = Boolean(a.win.frames[e]);
                return n || (i.body ? ((t = i.createElement("iframe")).style.cssText = "display:none", t.name = e, t.setAttribute("title", "GPP Locator"), i.body.appendChild(t)) : setTimeout(function() {
                    a.addFrame(e)
                }, 5)), !n
            }, this.addEventListener = function(e, t) {
                var i, n = a.win.__gpp;
                return n.events = n.events || [], null != (i = n) && i.lastId || (n.lastId = 0), n.lastId++, n.events.push({
                    id: n.lastId,
                    callback: e,
                    parameter: t
                }), {
                    eventName: "listenerRegistered",
                    listenerId: n.lastId,
                    data: !0,
                    pingData: a.getPingRequest()
                }
            }, this.removeEventListener = function(t) {
                var i = !1,
                    e = a.win.__gpp;
                return e.events = e.events || [], e.events = e.events.filter(function(e) {
                    return e.id.toString() !== t.toString() || !(i = !0)
                }), {
                    eventName: "listenerRemoved",
                    listenerId: t,
                    data: i,
                    pingData: a.getPingRequest()
                }
            }, this.addToQueue = function(e, t, i) {
                var n = a.win.__gpp;
                n.queue = n.queue || [], n.queue.push([e, t, i])
            }, this.messageHandler = function(i) {
                var t, n, s = "string" == typeof i.data;
                try {
                    t = s ? JSON.parse(i.data) : i.data
                } catch (e) {
                    t = null
                }
                t && t.__gppCall && (n = t.__gppCall, (0, a.win.__gpp)(n.command, function(e, t) {
                    e = {
                        __gppReturn: {
                            returnValue: e,
                            success: t,
                            callId: n.callId
                        }
                    };
                    i && i.source && i.source.postMessage && (t = (e => {
                        if ("string" != typeof e || !e || "null" === e) return !1;
                        try {
                            return new URL(e).origin === e
                        } catch (e) {
                            return !1
                        }
                    })(i.origin) ? i.origin : "*", i.source.postMessage(s ? JSON.stringify(e) : e, t))
                }, n.parameter))
            }, this.customInit || this.init()
        }),
        jt = (L.initCSPTrustedType = function(e) {
            var n = new URL(e, location.origin);
            window.DOMPurify && window.trustedTypes && window.trustedTypes.createPolicy && (window.OtTrustedType.TrustedTypePolicy = window.trustedTypes.createPolicy("ot-trusted-type-policy", {
                createHTML: function(e) {
                    return window.DOMPurify.sanitize(e)
                },
                createScript: function(e) {
                    return window.DOMPurify.sanitize(e)
                },
                createScriptURL: function(e) {
                    var t, i = [document.location.hostname, n.hostname];
                    try {
                        t = new URL(e, location.origin)
                    } catch (e) {
                        return "about:blank#error"
                    }
                    return t.hostname && !i.includes(t.hostname) ? "about:blank#blocked" : t.href
                }
            }))
        }, L.isCspTrustedType = function() {
            var e;
            return (null == (e = window.OtTrustedType) ? void 0 : e.isCspTrustedTypeEnabled) && (null == (e = window.OtTrustedType) ? void 0 : e.TrustedTypePolicy)
        }, L.createScriptURL = function(e) {
            return L.isCspTrustedType() ? window.OtTrustedType.TrustedTypePolicy.createScriptURL(e) : e
        }, L.checkAndAssignCspTrustedTypeEnabled = function(e) {
            e = null == (e = e.TenantFeatures) ? void 0 : e.CookieV2CSPTrustedType;
            return window.OtTrustedType = {
                isCspTrustedTypeEnabled: e
            }, e
        }, L);

    function L() {}
    K.prototype.initConsentSDK = function() {
        this.initCustomEventPolyfill(), this.setStubScriptElement(), this.setOTDataLayer(), this.getParam(), this.fetchBannerSDKDependency(), this.captureNonce(), this.captureShopify()
    }, K.prototype.captureNonce = function() {
        this.nonce = u.stubScriptElement.nonce || u.stubScriptElement.getAttribute("nonce") || null
    }, K.prototype.captureShopify = function() {
        this.isShopify = u.stubScriptElement.hasAttribute("data-shopify-consent-mapping")
    }, K.prototype.fetchBannerSDKDependency = function() {
        this.setDomainDataFileURL(), this.crossOrigin = u.stubScriptElement.getAttribute("crossorigin") || null, this.previewMode = "true" === u.stubScriptElement.getAttribute("data-preview-mode"), this.otFetch(u.bannerDataParentURL, this.getLocation.bind(this), !1, null, null, !0)
    }, K.prototype.setDomainIfBulkDomainEnabled = function(e) {
        var t = e && e.TenantFeatures,
            i = window.location.hostname,
            n = e.Domain,
            s = e.BulkDomainCheckUrl;
        t && t.CookieV2BulkDomainManagement && i !== n && e.ScriptType === x && ((t = window.sessionStorage) && t.getItem("bulkDomainMgmtEnabled") ? this.handleBulkDomainMgmt({
            isValid: "true" === window.sessionStorage.getItem("bulkDomainMgmtEnabled")
        }, e) : (n = {
            location: u.storageBaseURL.replace(/^https?:\/\//, ""),
            domainId: this.domainId,
            url: i
        }, this.otFetch(s, this.handleBulkDomainMgmt, !1, n, e)))
    }, K.prototype.getLocation = function(e) {
        if (this.setDomainIfBulkDomainEnabled(e), this.updateVersion(e), this.subDomainEnabled = e.SubDomainEnabled || !1, this.domainHashValue = e.DomainHashValue || "", this.scriptType = e.ScriptType || "", this.ensureHtmlGroupDataInitialised(), (e.TenantFeatures && e.TenantFeatures.CookieV2CSP || e.CookieV2CSPEnabled) && this.nonce && (this.setAttributePolyfillIsActive = !0, (new j).implementThePolyfill()), jt.checkAndAssignCspTrustedTypeEnabled(e) && jt.initCSPTrustedType(u.storageBaseURL), !e.RuleSet[0].Type) return this.iabTypeAdded = !1, window.__tcfapi = this.executeTcfApi, this.intializeIabStub(), this.addBannerSDKScript(e);
        var t, i = window;
        i.OneTrust && i.OneTrust.geolocationResponse ? (i = i.OneTrust.geolocationResponse, this.setGeoLocation(i.countryCode, i.stateCode, i.stateName), this.addBannerSDKScript(e)) : (i = this.readCookieParam(u.optanonCookieName, u.geolocationCookiesParam)) || e.SkipGeolocation ? (t = i.split(";")[0], i = i.split(";")[1], this.setGeoLocation(t, i), this.addBannerSDKScript(e)) : this.getGeoLocation(e)
    }, K.prototype.handleBulkDomainMgmt = function(e, t) {
        window.sessionStorage && window.sessionStorage.setItem("bulkDomainMgmtEnabled", JSON.stringify(e.isValid)), e.isValid && (t.Domain = window.location.hostname)
    }, K.prototype.getGeolocationURL = function(e) {
        e.TenantFeatures;
        var t = "" + u.stubScriptElement.getAttribute("src").split(u.stubFileName)[0] + e.Version;
        return new RegExp("^file://", "i").test(t) && e.MobileSDK ? (t = "/" + e.GeolocationUrl.replace(/^(http|https):\/\//, "").split("/").slice(1).join("/") + ".js", u.storageBaseURL + t) : e.GeolocationUrl
    }, K.prototype.geoLocationJsonCallback = function(e, t) {
        t && this.setGeoLocation(t.country, t.state, t.stateName), this.addBannerSDKScript(e)
    }, K.prototype.getGeoLocation = function(e) {
        var t = this.getGeolocationURL(e);
        this.otFetch(t, this.geoLocationJsonCallback.bind(this, e), !0)
    }, K.prototype.setOTDataLayer = function() {
        var e = "data-dLayer-ignore",
            t = u.stubScriptElement.hasAttribute(e),
            e = u.stubScriptElement.getAttribute(e);
        this.otDataLayer = {
            ignore: t && "true" === e || t && "" === e,
            name: this.getStubAttrOrQueryParam("data-dLayer-name") || "dataLayer"
        }
    }, K.prototype.setGeoLocation = function(e, t, i) {
        u.userLocation = {
            country: e,
            state: t = void 0 === t ? "" : t,
            stateName: i = void 0 === i ? "" : i
        }
    }, K.prototype.getSriHashBaseUrl = function(e) {
        return e.ScriptType === _ ? u.storageBaseURL : e.CDNLocation
    }, K.prototype.otFetch = function(e, i, t, n, s, o) {
        void 0 === t && (t = !1), void 0 === n && (n = null), void 0 === o && (o = !1);
        var a = window.sessionStorage && window.sessionStorage.getItem("otPreviewData");
        if (new RegExp("^file://", "i").test(e)) this.otFetchOfflineFile(e, i);
        else if (0 <= e.indexOf("/consent/") && this.previewMode && a) {
            a = JSON.parse(a).domainJson;
            i(a)
        } else {
            u.mobileOnlineURL.push(e);
            var r = new XMLHttpRequest,
                l = this;
            if (r.onload = function(e) {
                    var t;
                    this && this.responseText ? t = this.responseText : e && e.target && (t = e.target.responseText), o && this && this.getResponseHeader && (e = this.getResponseHeader("X-OneTrust-IsBot"), l.isBotHeaderDomain = !!e && "true" === e.toLowerCase()), s ? i(JSON.parse(t), s) : i(JSON.parse(t))
                }, r.onerror = function() {
                    i()
                }, r.open("GET", e), r.withCredentials = !1, t && r.setRequestHeader("accept", "application/json"), n)
                for (var c in n) r.setRequestHeader(c, n[c]);
            r.send()
        }
    }, K.prototype.otFetchOfflineFile = function(e, t) {
        var i = (e = e.replace(".json", ".js")).split("/"),
            n = i[i.length - 1].split(".js")[0];
        this.jsonp(e, function() {
            t(window[n])
        })
    }, K.prototype.jsonp = function(e, t, i, n) {
        void 0 === i && (i = !1), void 0 === n && (n = "");
        var s = document.createElement("script"),
            o = jt.createScriptURL(e);
        s.setAttribute("src", o), this.nonce && s.setAttribute("nonce", this.nonce), s.async = !0, s.type = "text/javascript", i && n && (s.integrity = n), this.crossOrigin && s.setAttribute("crossorigin", this.crossOrigin), document.getElementsByTagName("head")[0].appendChild(s), new RegExp("^file://", "i").test(e) || u.mobileOnlineURL.push(e), t && (s.onload = s.onerror = function() {
            t()
        })
    }, K.prototype.getRegionSet = function(e) {
        var t, i, n, s = u.userLocation,
            o = e.RuleSet.filter(function(e) {
                return !0 === e.Default
            });
        if (!s.country && !s.state) return o && 0 < o.length ? o[0] : null;
        for (var a = s.state.toLowerCase(), r = s.country.toLowerCase(), l = 0; l < e.RuleSet.length; l++)
            if (!0 === e.RuleSet[l].Global) n = e.RuleSet[l];
            else {
                var c = e.RuleSet[l].States;
                if (c[r] && 0 <= c[r].indexOf(a)) {
                    i = e.RuleSet[l];
                    break
                }
                0 <= e.RuleSet[l].Countries.indexOf(r) && (t = e.RuleSet[l])
            }
        return i || t || n
    }, K.prototype.ensureHtmlGroupDataInitialised = function() {
        this.initializeIABData(), this.initializeGroupData(), this.initializeHostData(), this.initializeGenVenData()
    }, K.prototype.initializeGroupData = function() {
        var e = this.readCookieParam(u.optanonCookieName, "groups");
        e && (u.optanonHtmlGroupData = this.deserialiseStringToArray(e))
    }, K.prototype.initializeHostData = function() {
        var e = this.readCookieParam(u.optanonCookieName, "hosts");
        e && (u.optanonHostData = this.deserialiseStringToArray(e))
    }, K.prototype.initializeGenVenData = function() {
        var e = this.readCookieParam(u.optanonCookieName, "genVendors");
        e && (u.genVendorsData = this.deserialiseStringToArray(e))
    }, K.prototype.initializeIABData = function() {
        this.validateIABGDPRApplied(), this.validateIABGlobalScope()
    }, K.prototype.validateIABGlobalScope = function() {
        var e = this.readCookieParam(u.optanonCookieName, u.oneTrustIsIABCrossConsentEnableParam);
        e ? "true" === e ? (u.hasIABGlobalScope = !0, u.isStubReady = !1) : (u.hasIABGlobalScope = !1, u.IABCookieValue = this.getCookie(u.oneTrustIABCookieName)) : u.isStubReady = !1
    }, K.prototype.validateIABGDPRApplied = function() {
        var e = this.readCookieParam(u.optanonCookieName, u.geolocationCookiesParam).split(";")[0];
        e ? this.isBoolean(e) ? u.oneTrustIABgdprAppliesGlobally = "true" === e : u.oneTrustIABgdprAppliesGlobally = 0 <= u.EUCOUNTRIES.indexOf(e) : u.isStubReady = !1
    }, K.prototype.isBoolean = function(e) {
        return "true" === e || "false" === e
    }, K.prototype.readCookieParam = function(e, t) {
        var i, n, s, o, e = this.getCookie(e);
        if (e) {
            for (n = {}, s = e.split("&"), i = 0; i < s.length; i += 1) o = s[i].split("="), n[decodeURIComponent(o[0])] = decodeURIComponent(o[1]).replace(/\+/g, " ");
            return t && n[t] ? n[t] : t && !n[t] ? "" : n
        }
        return ""
    }, K.prototype.getCookieNameSuffix = function() {
        return (this.scriptType === x || this.scriptType === _) && this.subDomainEnabled && this.domainHashValue ? "_" + this.domainHashValue : ""
    }, K.prototype.getCookie = function(e) {
        if (this.isAmp) {
            var t = JSON.parse(window.localStorage.getItem(this.domainId)) || {};
            if (t) return t[e] || null
        }
        for (var i = "" + e + this.getCookieNameSuffix() + "=", n = 0, s = document.cookie.split(";"); n < s.length; n++) {
            var o = s[n].trim();
            if (0 === o.indexOf(i)) return o.substring(i.length)
        }
        return null
    }, K.prototype.isGpcSignalUnaccountedFor = function() {
        return !!navigator.globalPrivacyControl != ("1" === this.readCookieParam(u.optanonCookieName, H))
    }, K.prototype.updateGtmMacros = function() {
        for (var e = [], t = u.optanonHtmlGroupData.length, i = 0; i < t; i++) this.endsWith(u.optanonHtmlGroupData[i], ":1") && e.push(u.optanonHtmlGroupData[i].replace(":1", ""));
        for (t = u.optanonHostData.length, i = 0; i < t; i++) this.endsWith(u.optanonHostData[i], ":1") && e.push(u.optanonHostData[i].replace(":1", ""));
        for (t = u.genVendorsData.length, i = 0; i < t; i++) this.endsWith(u.genVendorsData[i], ":1") && e.push(u.genVendorsData[i].replace(":1", ""));
        for (t = u.vendorsServiceData.length, i = 0; i < t; i++) this.endsWith(u.vendorsServiceData[i], ":1") && e.push(u.vendorsServiceData[i].replace(":1", ""));
        var n, s = "," + this.serialiseArrayToString(e) + ",",
            o = (window.OnetrustActiveGroups = s, window.OptanonActiveGroups = s, window),
            a = (this.otDataLayer.ignore || void 0 === o[this.otDataLayer.name] ? this.otDataLayer.ignore || (o[this.otDataLayer.name] = [{
                event: "OneTrustLoaded",
                OnetrustActiveGroups: s
            }, {
                event: "OptanonLoaded",
                OptanonActiveGroups: s
            }]) : o[this.otDataLayer.name].constructor === Array && (o[this.otDataLayer.name].push({
                event: "OneTrustLoaded",
                OnetrustActiveGroups: s
            }), o[this.otDataLayer.name].push({
                event: "OptanonLoaded",
                OptanonActiveGroups: s
            })), new CustomEvent("consent.onetrust", {
                detail: e
            }));
        !this.otDataLayer.ignore && e.length && (o[this.otDataLayer.name].constructor === Array && o[this.otDataLayer.name].push({
            event: "OneTrustGroupsUpdated",
            OnetrustActiveGroups: s
        }), n = new CustomEvent("OneTrustGroupsUpdated", {
            detail: e
        })), setTimeout(function() {
            e.length && window.dispatchEvent(a), n && window.dispatchEvent(n)
        })
    }, K.prototype.deserialiseStringToArray = function(e) {
        return e ? e.split(",") : []
    }, K.prototype.endsWith = function(e, t) {
        return -1 !== e.indexOf(t, e.length - t.length)
    }, K.prototype.serialiseArrayToString = function(e) {
        return e.toString()
    }, K.prototype.getStubAttrOrQueryParam = function(e) {
        var t = u.stubScriptElement,
            i = t && t.getAttribute(e);
        return i || (i = t && t.getAttribute("src"), this.getStubQueryParam(i, e))
    }, K.prototype.getStubQueryParam = function(e, t) {
        return !e || (e = e.split("?")).length < 2 ? null : new URLSearchParams(e[1]).get(t)
    }, K.prototype.setStubScriptElement = function() {
        u.stubScriptElement = document.querySelector("script[src*='" + u.stubFileName + "']");
        var e = u.stubScriptElement && u.stubScriptElement.getAttribute("src"),
            e = e && this.getStubQueryParam(e, "did");
        u.stubScriptElement && u.stubScriptElement.hasAttribute(u.DATAFILEATTRIBUTE) ? this.domainId = u.stubScriptElement.getAttribute(u.DATAFILEATTRIBUTE).trim() : e ? this.domainId = e : u.stubScriptElement || (u.stubScriptElement = document.querySelector("script[src*='" + u.migratedCCTID + "']"), u.stubScriptElement && (u.isMigratedURL = !0, this.domainId = u.migratedDomainId.trim()))
    }, K.prototype.setDomainDataFileURL = function() {
        var e = u.stubScriptElement.getAttribute("src"),
            t = -1 < e.indexOf("/consent");
        e && (u.isMigratedURL ? u.storageBaseURL = e.split("/consent/" + u.migratedCCTID)[0] : u.storageBaseURL = (t ? e.split("/consent") : e.split("/scripttemplates/" + u.stubFileName))[0]), this.storageBaseURL = u.storageBaseURL, this.isPreview && -1 === this.domainId.indexOf("test") ? this.domainId = this.domainId + "-test" : this.isPreview = !1, u.bannerBaseDataURL = u.storageBaseURL && u.storageBaseURL + "/consent/" + this.domainId, u.bannerDataParentURL = u.bannerBaseDataURL + "/" + this.domainId + ".json"
    }, K.prototype.initCustomEventPolyfill = function() {
        if ("function" == typeof window.CustomEvent) return !1;

        function e(e, t) {
            t = t || {
                bubbles: !1,
                cancelable: !1,
                detail: void 0
            };
            var i = document.createEvent("CustomEvent");
            return i.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), i
        }
        e.prototype = window.Event.prototype, window.CustomEvent = e
    }, K.prototype.removeTcf = function() {
        delete window.__tcfapi;
        var e = document.querySelectorAll("iframe[name='__tcfapiLocator']")[0];
        e && e.parentElement.removeChild(e)
    }, K.prototype.getParamForIE = function() {
        return {
            get: function(e) {
                e = new RegExp("[?&]" + e + "=([^&#]*)").exec(window.location.search);
                return null === e ? null : decodeURI(e[1]) || ""
            }
        }
    }, K.prototype.getParam = function() {
        window.document.documentMode || !window.URLSearchParams ? this.urlParams = this.getParamForIE() : this.urlParams = new URLSearchParams(window.location.search);
        var e = "true" === this.urlParams.get("otreset"),
            t = "true" === this.urlParams.get("otpreview"),
            i = (this.geoFromUrl = (this.urlParams.get("otgeo") || "").toLowerCase(), this.readCookieParam(k, "expiry")),
            n = this.readCookieParam(k, U);
        this.isReset = e || i && new Date(i) < new Date, this.isPreview = !this.isReset && (t || i && new Date(i) > new Date), this.setGeoParam(this.geoFromUrl || n)
    }, K.prototype.setGeoParam = function(e) {
        var t;
        e && ((t = window).OneTrust || (t.OneTrust = {}), e = e.split(","), t.OneTrust.geolocationResponse = {
            countryCode: e[0],
            stateCode: e[1]
        })
    }, K.prototype.updateVersion = function(e) {
        "debug" !== this.buildType && "cybuild" !== this.buildType || (e.Version = "202610.1.0")
    };
    var B = K;

    function K() {
        var r = this;
        this.iabType = null, this.iabTypeAdded = !0, this.crossOrigin = null, this.isAmp = !1, this.domainId = "", this.isReset = !1, this.isPreview = !1, this.geoFromUrl = "", this.nonce = "", this.setAttributePolyfillIsActive = !1, this.storageBaseURL = "", this.charset = null, this.isShopify = !1, this.isBotHeaderDomain = !1, this.subDomainEnabled = !1, this.domainHashValue = "", this.scriptType = "", this.buildType = "undefined", this.addBannerSDKScript = function(a) {
            return M(r, void 0, void 0, function() {
                var t, i, n, s, o;
                return F(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return ((t = this.getRegionSet(a)).GCEnable || this.isGpcSignalUnaccountedFor() || (this.updateGtmMacros(), this.gtmUpdated = !0), this.iabTypeAdded && ("IAB2" !== t.Type && "IAB2V2" !== t.Type || (this.iabType = t.Type, this.intializeIabStub()), "IAB2" !== t.Type) && "IAB2V2" !== t.Type && this.removeTcf(), t.IsGPPEnabled ? xt.init() : xt.removeGppApi(), i = u.stubScriptElement.cloneNode(!0), n = "", n = a.UseSDKRefactor ? (u.isMigratedURL && (i.src = u.storageBaseURL + "/scripttemplates/new/scripttemplates/" + u.stubFileName + ".js"), u.storageBaseURL + "/scripttemplates/new/scripttemplates/" + a.Version + "/" + u.bannerScriptName) : "5.11.0" === a.Version ? (u.isMigratedURL && (i.src = u.storageBaseURL + "/scripttemplates/old/scripttemplates/" + u.stubFileName + ".js"), u.storageBaseURL + "/scripttemplates/old/scripttemplates/5.11.0/" + u.bannerScriptName) : (u.isMigratedURL && (i.src = u.storageBaseURL + "/scripttemplates/" + u.stubFileName + ".js"), u.storageBaseURL + "/scripttemplates/" + a.Version + "/" + u.bannerScriptName), ["charset", "data-language", "data-document-language", "data-domain-script", "crossorigin", "data-ignore-ga"].forEach(function(e) {
                                u.stubScriptElement.getAttribute(e) && i.setAttribute(e, u.stubScriptElement.getAttribute(e))
                            }), this.charset = u.stubScriptElement.getAttribute("charset"), this.isAmp = !!u.stubScriptElement.getAttribute("amp"), u.stubScriptElement.getAttribute("integrity")) ? (o = this.getSriHashBaseUrl(a) + "/scripttemplates/" + a.Version + "/sri-hashes.json", [4, this.fetchSriHash(o)]) : [3, 2];
                        case 1:
                            return s = e.sent(), [3, 3];
                        case 2:
                            s = null, e.label = 3;
                        case 3:
                            return window.otStubData = {
                                bannerBaseDataURL: u.bannerBaseDataURL,
                                crossOrigin: this.crossOrigin,
                                domainData: a,
                                domainId: this.domainId,
                                geoFromUrl: this.geoFromUrl,
                                isAmp: this.isAmp,
                                isPreview: this.isPreview,
                                isReset: this.isReset,
                                mobileOnlineURL: u.mobileOnlineURL,
                                nonce: this.nonce,
                                otDataLayer: this.otDataLayer,
                                regionRule: t,
                                setAttributePolyfillIsActive: this.setAttributePolyfillIsActive,
                                storageBaseURL: this.storageBaseURL,
                                stubElement: i,
                                urlParams: this.urlParams,
                                userLocation: u.userLocation,
                                gtmUpdated: this.gtmUpdated,
                                previewMode: this.previewMode,
                                charset: this.charset,
                                stubUrl: u.stubScriptElement.getAttribute("src"),
                                sriHash: s,
                                isShopify: this.isShopify,
                                isBotHeaderDomain: this.isBotHeaderDomain
                            }, this.jsonp(n, null, !0, null == (o = s) ? void 0 : o["otBannerSdk.js"]), [2]
                    }
                })
            })
        }, this.fetchSriHash = function(i) {
            return M(r, void 0, void 0, function() {
                var t;
                return F(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return e.trys.push([0, 4, , 5]), [4, fetch(i)];
                        case 1:
                            return (t = e.sent()).ok ? [4, t.json()] : [3, 3];
                        case 2:
                            return [2, e.sent()];
                        case 3:
                            return [3, 5];
                        case 4:
                            return t = e.sent(), console.error("Error fetching SRI hash:", t), [3, 5];
                        case 5:
                            return [2, null]
                    }
                })
            })
        }, this.intializeIabStub = function() {
            var e = window;
            r.iabTypeAdded ? (void 0 === e.__tcfapi && (window.__tcfapi = r.executeTcfApi), r.addIabFrame()) : r.addBackwardIabFrame(), e.receiveOTMessage = r.receiveIabMessage, (e.attachEvent || window.addEventListener)("message", e.receiveOTMessage, !1)
        }, this.addIabFrame = function() {
            var e = window,
                t = "__tcfapiLocator";
            !e.frames[t] && (e.document.body ? r.addLocator(t, "CMP") : setTimeout(r.addIabFrame, 5))
        }, this.addBackwardIabFrame = function() {
            var e = window,
                t = "__tcfapiLocator";
            !e.frames[t] && (e.document.body ? r.addLocator(t, "TCF") : setTimeout(r.addIabFrame, 5))
        }, this.addLocator = function(e, t) {
            var i = window,
                n = i.document.createElement("iframe");
            W(n, "display: none;", !0), n.name = e, n.setAttribute("title", t + " Locator"), i.document.body.appendChild(n)
        }, this.receiveIabMessage = function(i) {
            var n, s, e, o = "string" == typeof i.data,
                t = {};
            try {
                t = o ? JSON.parse(i.data) : i.data
            } catch (e) {}
            t.__cmpCall && "IAB2" === r.iabType && console.log("Expecting IAB TCF v2.0 vendor iFrame call; Received IAB TCF v1.1"), t.__tcfapiCall && "IAB2" === r.iabType && (n = t.__tcfapiCall.callId, s = t.__tcfapiCall.command, e = t.__tcfapiCall.parameter, t = t.__tcfapiCall.version, r.executeTcfApi(s, e, function(e, t) {
                e = {
                    __tcfapiReturn: {
                        returnValue: e,
                        success: t,
                        callId: n,
                        command: s
                    }
                };
                i && i.source && i.source.postMessage && i.source.postMessage(o ? JSON.stringify(e) : e, "*")
            }, t))
        }, this.executeTcfApi = function() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            if (r.iabType = "IAB2", !e.length) return window.__tcfapi.a || [];
            var i = e[0],
                n = e[1],
                s = e[2],
                o = e[3];
            "function" == typeof s && i && ("ping" === i ? r.getPingRequest(s) : r.addToQueue(i, n, s, o))
        }, this.addToQueue = function(e, t, i, n) {
            var s = window,
                o = "__tcfapi";
            s[o].a = s[o].a || [], s[o].a.push([e, t, i, n])
        }, this.getPingRequest = function(e, t) {
            var i, n;
            e && (n = !(i = {}), "IAB2" !== r.iabType && "IAB2V2" !== r.iabType || (i = {
                gdprApplies: u.oneTrustIABgdprAppliesGlobally,
                cmpLoaded: !1,
                cmpStatus: "stub",
                displayStatus: "stub",
                apiVersion: "2.0",
                cmpVersion: void 0,
                cmpId: void 0,
                gvlVersion: void 0,
                tcfPolicyVersion: void 0
            }, n = !0), e(i, n))
        }, this.getConsentDataRequest = function(e) {
            e && u.IABCookieValue && e({
                gdprApplies: u.oneTrustIABgdprAppliesGlobally,
                hasGlobalScope: u.hasIABGlobalScope,
                consentData: u.IABCookieValue
            }, !0)
        }, this.initConsentSDK()
    }
    var V = new B;
    return e.OtSDKStub = B, e.otSdkStub = V, Object.defineProperty(e, "__esModule", {
        value: !0
    }), e
})({});